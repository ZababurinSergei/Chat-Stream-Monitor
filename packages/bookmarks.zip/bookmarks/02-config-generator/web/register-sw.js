// register-sw.js - Регистрация Service Worker с перезагрузкой
// ОБНОВЛЕНО: Автоматическая перезагрузка после регистрации

(function () {
  'use strict';

  console.log('📦 Регистрация Service Worker...');

  if (!('serviceWorker' in navigator)) {
    console.warn('❌ Service Workers не поддерживаются в этом браузере');
    return;
  }

  // Флаг, чтобы не перезагружать несколько раз
  let isReloading = false;
  let reloadTimeout = null;

  // Слушаем сообщения от SW
  navigator.serviceWorker.addEventListener('message', event => {
    console.log('📨 Сообщение от SW:', event.data);

    if (event.data && event.data.type === 'SW_RELOAD') {
      if (!isReloading) {
        isReloading = true;
        console.log('🔄 Перезагрузка страницы по запросу SW...');
        clearTimeout(reloadTimeout);
        reloadTimeout = setTimeout(() => {
          location.reload();
        }, 300);
      }
    }

    if (event.data && event.data.type === 'SW_READY') {
      console.log('✅ Service Worker готов, заголовки:', event.data.headers);

      // Проверяем, нужно ли перезагрузить страницу
      if (!isReloading && !window.crossOriginIsolated) {
        isReloading = true;
        console.log('🔄 Перезагрузка страницы для применения заголовков...');
        clearTimeout(reloadTimeout);
        reloadTimeout = setTimeout(() => {
          location.reload();
        }, 500);
      }
    }
  });

  // Регистрируем Service Worker
  navigator.serviceWorker
    .register('./sw.js', {
      scope: './',
      updateViaCache: 'none',
    })
    .then(registration => {
      console.log('✅ Service Worker зарегистрирован:', registration);
      console.log('  📍 Scope:', registration.scope);
      console.log('  📍 State:', registration.active ? 'active' : 'installing');

      // Если SW уже активен - проверяем статус
      if (registration.active) {
        console.log('✅ Service Worker активен');
        checkStatus(registration);
      } else {
        // Ждем активации
        registration.addEventListener('statechange', function onStateChange() {
          console.log(`  📌 Состояние SW: ${this.state}`);
          if (this.state === 'activated') {
            console.log('✅ Service Worker активирован');
            checkStatus(registration);
            this.removeEventListener('statechange', onStateChange);
          }
        });
      }

      return registration;
    })
    .catch(error => {
      console.error('❌ Ошибка регистрации Service Worker:', error);
      console.warn('💡 Проверьте:');
      console.warn('  1. Файл sw.js существует');
      console.warn('  2. Путь к sw.js корректен');
      console.warn('  3. HTTPS или localhost используется');
    });

  // ============================================================
  //  ПРОВЕРКА СТАТУСА
  // ============================================================

  function checkStatus(registration) {
    // Проверяем заголовки
    fetch('/')
      .then(response => {
        const coop = response.headers.get('Cross-Origin-Opener-Policy');
        const coep = response.headers.get('Cross-Origin-Embedder-Policy');

        console.log('📋 Проверка заголовков:');
        console.log(`  Cross-Origin-Opener-Policy: ${coop || '❌ отсутствует'}`);
        console.log(`  Cross-Origin-Embedder-Policy: ${coep || '❌ отсутствует'}`);
        console.log(
          `  Cross-Origin Isolation: ${window.crossOriginIsolated ? '✅ Включена' : '❌ Выключена'}`
        );

        if (coop === 'same-origin' && coep === 'require-corp') {
          console.log('✅ Все заголовки применены!');
          console.log('  SharedMemory теперь должен работать');

          // Проверяем SharedMemory
          checkSharedMemory();
        } else {
          console.warn('⚠️ Заголовки не применены');
          console.warn('  🔄 Попробуйте перезагрузить страницу вручную');
        }
      })
      .catch(error => {
        console.warn('⚠️ Не удалось проверить заголовки:', error);
      });

    // Отправляем сообщение для получения заголовков
    if (registration.active) {
      sendMessageToSW(registration);
    }
  }

  // ============================================================
  //  ОТПРАВКА СООБЩЕНИЯ В SW
  // ============================================================

  function sendMessageToSW(registration) {
    const channel = new MessageChannel();

    channel.port1.onmessage = event => {
      console.log('📨 Получен ответ от SW:', event.data);
      if (event.data && event.data.type === 'HEADERS') {
        console.log('📋 Заголовки от SW:', event.data.headers);
      }
    };

    try {
      registration.active.postMessage({ type: 'GET_HEADERS' }, [channel.port2]);
    } catch (e) {
      console.warn('⚠️ Не удалось отправить сообщение в SW:', e.message);
    }
  }

  // ============================================================
  //  ПРОВЕРКА SHAREDMEMORY
  // ============================================================

  function checkSharedMemory() {
    const hasSAB = typeof SharedArrayBuffer !== 'undefined';
    const hasAtomics = typeof Atomics !== 'undefined';
    const isIsolated = window.crossOriginIsolated || false;

    console.log('📊 SharedMemory статус:');
    console.log(`  SharedArrayBuffer: ${hasSAB ? '✅' : '❌'}`);
    console.log(`  Atomics: ${hasAtomics ? '✅' : '❌'}`);
    console.log(`  Cross-Origin Isolation: ${isIsolated ? '✅' : '❌'}`);

    if (hasSAB && hasAtomics && isIsolated) {
      console.log('🎉 SharedMemory ПОЛНОСТЬЮ РАБОТАЕТ!');
      window.sharedMemoryAvailable = true;
      return true;
    } else {
      console.warn('⚠️ SharedMemory НЕ РАБОТАЕТ');
      if (!isIsolated) {
        console.warn('  🔄 Попробуйте перезагрузить страницу');
      }
      window.sharedMemoryAvailable = false;
      return false;
    }
  }

  // ============================================================
  //  ЭКСПОРТ ФУНКЦИЙ ДЛЯ КОНСОЛИ
  // ============================================================

  window.registerSW = function () {
    console.log('🔄 Принудительная перерегистрация Service Worker...');

    if (!('serviceWorker' in navigator)) {
      console.warn('❌ Service Workers не поддерживаются');
      return;
    }

    navigator.serviceWorker
      .getRegistrations()
      .then(registrations => {
        const promises = registrations.map(reg => reg.unregister());
        return Promise.all(promises);
      })
      .then(() => {
        console.log('🗑️ Старые регистрации удалены');
        return navigator.serviceWorker.register('./sw.js', {
          scope: './',
          updateViaCache: 'none',
        });
      })
      .then(registration => {
        console.log('✅ Service Worker перерегистрирован');
        console.log('  📍 Scope:', registration.scope);

        if (registration.active) {
          checkStatus(registration);
        } else {
          registration.addEventListener('statechange', function onStateChange() {
            if (this.state === 'activated') {
              console.log('✅ Service Worker активирован');
              checkStatus(registration);
              this.removeEventListener('statechange', onStateChange);
            }
          });
        }
        return registration;
      })
      .catch(error => {
        console.error('❌ Ошибка перерегистрации:', error);
      });
  };

  window.reloadPage = function () {
    console.log('🔄 Перезагрузка страницы...');
    location.reload();
  };

  window.checkSW = function () {
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.getRegistration().then(registration => {
        if (registration) {
          console.log(`✅ Service Worker: активен (${registration.scope})`);
          console.log(`  📌 Состояние: ${registration.active ? 'active' : 'installing'}`);
          checkStatus(registration);
        } else {
          console.log('❌ Service Worker: не зарегистрирован');
        }
      });
    } else {
      console.log('❌ Service Workers: не поддерживаются');
    }
  };

  // ============================================================
  //  ИНИЦИАЛИЗАЦИЯ
  // ============================================================

  console.log('📋 Доступные команды:');
  console.log('  registerSW()   - перерегистрировать Service Worker');
  console.log('  reloadPage()   - перезагрузить страницу');
  console.log('  checkSW()      - проверить статус Service Worker');
  console.log('');

  // Проверяем статус через 2 секунды
  setTimeout(() => {
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.getRegistration().then(registration => {
        if (registration && registration.active) {
          checkStatus(registration);
        }
      });
    }
  }, 2000);
})();
