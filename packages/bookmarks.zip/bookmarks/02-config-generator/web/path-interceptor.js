// web/path-interceptor.js
// Автоматическое добавление pathname к ресурсным запросам

(function() {
  'use strict';

  // ============================================================
  // 1. ПОЛУЧЕНИЕ ТЕКУЩЕГО PATHNAME
  // ============================================================

  function getCurrentPathname() {
    return window.location.pathname || '/';
  }

  function getCurrentPathInfo() {
    const pathname = getCurrentPathname();
    const isRoot = pathname === '/';
    const isFile = /\/[^/]+\.[a-zA-Z0-9]+$/.test(pathname);
    const dirname = pathname.substring(0, pathname.lastIndexOf('/') + 1) || '/';

    return {
      pathname,
      isRoot,
      isFile,
      dirname,
      filename: isFile ? pathname.substring(pathname.lastIndexOf('/') + 1) : null,
      extension: isFile ? pathname.split('.').pop() : null,
    };
  }

  // ============================================================
  // 2. ДЕБАГ-ЛОГГЕР
  // ============================================================

  const DEBUG = localStorage.getItem('path-interceptor-debug') === 'true';

  function log(message, data = null) {
    if (!DEBUG) {return;}
    const timestamp = new Date().toISOString().slice(11, 19);
    console.log(`%c[${timestamp}] %c[PathInterceptor] ${message}`,
      'color: #636e72;',
      'color: #667eea; font-weight: bold;',
      data || '',
    );
  }

  function enableDebug() {
    localStorage.setItem('path-interceptor-debug', 'true');
    console.log('🔍 PathInterceptor: debug enabled');
  }

  function disableDebug() {
    localStorage.removeItem('path-interceptor-debug');
    console.log('🔍 PathInterceptor: debug disabled');
  }

  // ============================================================
  // 3. НОРМАЛИЗАЦИЯ ПУТИ
  // ============================================================

  function normalizePath(url, currentPathInfo) {
    // Если URL уже абсолютный или начинается с http/https
    if (/^https?:\/\//.test(url)) {
      return url;
    }

    // Если URL начинается с '/', это абсолютный путь от корня
    if (url.startsWith('/')) {
      return url;
    }

    // Если URL начинается с './' или '../'
    if (url.startsWith('./') || url.startsWith('../')) {
      return url;
    }

    // Для root-страницы: /index.html → добавляем ' ./'
    if (currentPathInfo.isRoot) {
      // Специальная обработка для index.html
      if (url === 'index.html' || url === '/index.html') {
        return `/ ${url}`;
      }
      // Все остальные файлы: /customData.mjs → ' ./customData.mjs'
      return `/ ./${url}`;
    }

    // Для файловых страниц: /customData.mjs → добавляем путь к файлу
    if (currentPathInfo.isFile) {
      // Если запрашиваем тот же файл
      if (url === currentPathInfo.filename) {
        return `${currentPathInfo.pathname}  ${url}`;
      }
      // Если запрашиваем другой файл в той же директории
      return `${currentPathInfo.dirname}${url}`;
    }

    // Для обычных директорий
    return `${currentPathInfo.pathname}${url}`;
  }

  // ============================================================
  // 4. ОСНОВНОЙ КЛАСС-ИНТЕРЦЕПТОР
  // ============================================================

  class PathInterceptor {
    constructor() {
      this._originalFetch = window.fetch;
      this._originalXHROpen = XMLHttpRequest.prototype.open;
      this._originalXHRSend = XMLHttpRequest.prototype.send;
      this._enabled = true;
      this._handlers = new Map();
      this._history = [];
      this._maxHistory = 100;
      this._currentPathInfo = getCurrentPathInfo();

      // Инициализация
      this._init();
    }

    _init() {
      log('🚀 Инициализация PathInterceptor');
      log(`📌 Current path: ${this._currentPathInfo.pathname}`);
      log(`📌 Is root: ${this._currentPathInfo.isRoot}`);
      log(`📌 Is file: ${this._currentPathInfo.isFile}`);
      if (this._currentPathInfo.isFile) {
        log(`📌 Filename: ${this._currentPathInfo.filename}`);
        log(`📌 Extension: ${this._currentPathInfo.extension}`);
      }

      this._interceptFetch();
      this._interceptXHR();
      this._setupEvents();

      log('✅ PathInterceptor инициализирован');
    }

    // ============================================================
    // 4.1 ПЕРЕХВАТ FETCH
    // ============================================================

    _interceptFetch() {
      const self = this;

      window.fetch = function(url, options = {}) {
        // Пропускаем специальные запросы
        if (self._shouldSkip(url)) {
          return self._originalFetch.call(this, url, options);
        }

        const currentPathInfo = getCurrentPathInfo();
        const originalUrl = url;
        const modifiedUrl = self._processUrl(url, currentPathInfo);

        log(`📤 Fetch: ${originalUrl} → ${modifiedUrl}`);

        // Сохраняем в историю
        self._addHistory({
          type: 'fetch',
          originalUrl,
          modifiedUrl,
          pathInfo: currentPathInfo,
          timestamp: Date.now(),
        });

        // Если URL изменился, добавляем заголовок с оригинальным URL
        if (modifiedUrl !== originalUrl) {
          options.headers = options.headers || {};
          // Важно: используем новый Headers если есть
          if (options.headers instanceof Headers) {
            options.headers.set('X-Original-Url', originalUrl);
            options.headers.set('X-Request-Path', currentPathInfo.pathname);
          } else {
            options.headers['X-Original-Url'] = originalUrl;
            options.headers['X-Request-Path'] = currentPathInfo.pathname;
          }
        }

        // Вызываем обработчики
        self._emit('beforeRequest', {
          url: modifiedUrl,
          originalUrl,
          options,
          pathInfo: currentPathInfo,
        });

        const result = self._originalFetch.call(this, modifiedUrl, options);

        result.then(response => {
          self._emit('afterRequest', {
            url: modifiedUrl,
            originalUrl,
            response,
            pathInfo: currentPathInfo,
          });
        }).catch(error => {
          self._emit('error', {
            url: modifiedUrl,
            originalUrl,
            error,
            pathInfo: currentPathInfo,
          });
        });

        return result;
      };

      log('✅ Fetch перехвачен');
    }

    // ============================================================
    // 4.2 ПЕРЕХВАТ XMLHttpRequest
    // ============================================================

    _interceptXHR() {
      const self = this;

      // Перехватываем open для сохранения URL
      XMLHttpRequest.prototype.open = function(method, url, ...args) {
        this._originalUrl = url;
        this._method = method;
        this._pathInfo = getCurrentPathInfo();

        // Пропускаем специальные запросы
        if (!self._shouldSkip(url)) {
          this._modifiedUrl = self._processUrl(url, this._pathInfo);
          log(`📤 XHR: ${url} → ${this._modifiedUrl}`);
        } else {
          this._modifiedUrl = url;
        }

        return self._originalXHROpen.call(this, method, this._modifiedUrl, ...args);
      };

      // Перехватываем send для добавления заголовков
      XMLHttpRequest.prototype.send = function(body) {
        const self = this;

        // Добавляем заголовки если URL изменился
        if (this._originalUrl && this._modifiedUrl && this._modifiedUrl !== this._originalUrl) {
          try {
            this.setRequestHeader('X-Original-Url', this._originalUrl);
            this.setRequestHeader('X-Request-Path', this._pathInfo.pathname);
          } catch (e) {
            // Игнорируем ошибки (например, если уже отправлено)
          }
        }

        // Сохраняем в историю
        if (this._originalUrl) {
          self._addHistory({
            type: 'xhr',
            method: this._method,
            originalUrl: this._originalUrl,
            modifiedUrl: this._modifiedUrl,
            pathInfo: this._pathInfo,
            timestamp: Date.now(),
          });
        }

        // Вызываем обработчики
        self._emit('beforeRequest', {
          url: this._modifiedUrl,
          originalUrl: this._originalUrl,
          options: { method: this._method, body },
          pathInfo: this._pathInfo,
          type: 'xhr',
        });

        // Слушаем завершение
        const originalOnReadyStateChange = this.onreadystatechange;
        this.onreadystatechange = function(...args) {
          if (this.readyState === 4) {
            self._emit('afterRequest', {
              url: this._modifiedUrl,
              originalUrl: this._originalUrl,
              response: this,
              pathInfo: this._pathInfo,
              type: 'xhr',
            });
          }
          if (originalOnReadyStateChange) {
            return originalOnReadyStateChange.apply(this, args);
          }
        };

        return self._originalXHRSend.call(this, body);
      };

      log('✅ XHR перехвачен');
    }

    // ============================================================
    // 4.3 ОБРАБОТКА URL
    // ============================================================

    _processUrl(url, pathInfo) {
      // Если URL уже имеет префикс с пробелом, не обрабатываем повторно
      if (/\s/.test(url) && !url.startsWith('http')) {
        return url;
      }

      // Нормализуем путь
      const normalized = normalizePath(url, pathInfo);

      // Если путь не изменился, возвращаем как есть
      if (normalized === url) {
        return url;
      }

      // Для root-страницы добавляем пробел
      if (pathInfo.isRoot && !url.startsWith('/')) {
        // Проверяем, не начинается ли уже с '/ ./'
        if (!url.startsWith('/ ./')) {
          return `/ ./${url}`;
        }
        return url;
      }

      return normalized;
    }

    // ============================================================
    // 4.4 ПРОВЕРКА НА ПРОПУСК
    // ============================================================

    _shouldSkip(url) {
      if (!this._enabled) {return true;}

      // Пропускаем абсолютные URL с http/https
      if (/^https?:\/\//.test(url)) {
        return true;
      }

      // Пропускаем URL с пробелом (уже обработаны)
      if (/\s/.test(url) && !url.startsWith('http')) {
        return true;
      }

      // Пропускаем data: и blob: URL
      if (url.startsWith('data:') || url.startsWith('blob:')) {
        return true;
      }

      // Пропускаем chrome-extension:
      if (url.startsWith('chrome-extension:')) {
        return true;
      }

      return false;
    }

    // ============================================================
    // 4.5 СОБЫТИЯ
    // ============================================================

    on(event, handler) {
      if (!this._handlers.has(event)) {
        this._handlers.set(event, []);
      }
      this._handlers.get(event).push(handler);
      return () => this.off(event, handler);
    }

    off(event, handler) {
      if (this._handlers.has(event)) {
        const handlers = this._handlers.get(event);
        const index = handlers.indexOf(handler);
        if (index !== -1) {
          handlers.splice(index, 1);
        }
        if (handlers.length === 0) {
          this._handlers.delete(event);
        }
      }
    }

    _emit(event, data) {
      if (this._handlers.has(event)) {
        const handlers = this._handlers.get(event);
        for (const handler of handlers) {
          try {
            handler(data);
          } catch (error) {
            log(`⚠️ Ошибка в обработчике ${event}: ${error.message}`);
          }
        }
      }
    }

    // ============================================================
    // 4.6 ИСТОРИЯ
    // ============================================================

    _addHistory(entry) {
      this._history.push(entry);
      if (this._history.length > this._maxHistory) {
        this._history.shift();
      }
    }

    getHistory() {
      return [...this._history];
    }

    clearHistory() {
      this._history = [];
    }

    // ============================================================
    // 4.7 НАСТРОЙКА СОБЫТИЙ
    // ============================================================

    _setupEvents() {
      // Обновляем pathInfo при навигации
      const self = this;
      document.addEventListener('DOMContentLoaded', () => {
        self._currentPathInfo = getCurrentPathInfo();
        log(`🔄 Обновлен pathInfo: ${self._currentPathInfo.pathname}`);
      });

      // Обновляем при изменении URL (SPA)
      const originalPushState = history.pushState;
      const originalReplaceState = history.replaceState;

      history.pushState = function(...args) {
        originalPushState.apply(this, args);
        self._currentPathInfo = getCurrentPathInfo();
        log(`🔄 History pushState: ${self._currentPathInfo.pathname}`);
        self._emit('pathChange', self._currentPathInfo);
      };

      history.replaceState = function(...args) {
        originalReplaceState.apply(this, args);
        self._currentPathInfo = getCurrentPathInfo();
        log(`🔄 History replaceState: ${self._currentPathInfo.pathname}`);
        self._emit('pathChange', self._currentPathInfo);
      };

      window.addEventListener('popstate', () => {
        self._currentPathInfo = getCurrentPathInfo();
        log(`🔄 popstate: ${self._currentPathInfo.pathname}`);
        self._emit('pathChange', self._currentPathInfo);
      });

      log('✅ События настроены');
    }

    // ============================================================
    // 4.8 УПРАВЛЕНИЕ
    // ============================================================

    enable() {
      this._enabled = true;
      log('✅ PathInterceptor включен');
    }

    disable() {
      this._enabled = false;
      log('⏹️ PathInterceptor выключен');
    }

    isEnabled() {
      return this._enabled;
    }

    getPathInfo() {
      return { ...this._currentPathInfo };
    }

    // Восстановление оригинальных методов
    restore() {
      window.fetch = this._originalFetch;
      XMLHttpRequest.prototype.open = this._originalXHROpen;
      XMLHttpRequest.prototype.send = this._originalXHRSend;
      log('🔄 Оригинальные методы восстановлены');
    }

    // ============================================================
    // 4.9 СТАТИСТИКА
    // ============================================================

    getStats() {
      const total = this._history.length;
      const byType = {};
      const byPath = {};

      for (const entry of this._history) {
        byType[entry.type] = (byType[entry.type] || 0) + 1;
        const key = entry.pathInfo?.pathname || 'unknown';
        byPath[key] = (byPath[key] || 0) + 1;
      }

      return {
        total,
        byType,
        byPath,
        enabled: this._enabled,
        currentPath: this._currentPathInfo,
        handlers: Array.from(this._handlers.keys()),
      };
    }
  }

  // ============================================================
  // 5. СОЗДАНИЕ ГЛОБАЛЬНОГО ЭКЗЕМПЛЯРА
  // ============================================================

  let interceptorInstance = null;

  function getPathInterceptor() {
    if (!interceptorInstance) {
      interceptorInstance = new PathInterceptor();
      window.__pathInterceptor = interceptorInstance;
    }
    return interceptorInstance;
  }

  // ============================================================
  // 6. ✅ ЭКСПОРТЫ (ТОЛЬКО ИМЕНОВАННЫЕ)
  // ============================================================

  // Создаём экземпляр по умолчанию
  const defaultInterceptor = getPathInterceptor();

  // Глобальные функции для отладки
  window.__pathDebug = {
    enable: enableDebug,
    disable: disableDebug,
    getHistory: () => defaultInterceptor.getHistory(),
    clearHistory: () => defaultInterceptor.clearHistory(),
    getStats: () => defaultInterceptor.getStats(),
    getPathInfo: () => defaultInterceptor.getPathInfo(),
    enableInterceptor: () => defaultInterceptor.enable(),
    disableInterceptor: () => defaultInterceptor.disable(),
    restore: () => defaultInterceptor.restore(),
    on: defaultInterceptor.on.bind(defaultInterceptor),
    off: defaultInterceptor.off.bind(defaultInterceptor),
  };
  

  // ============================================================
  // 8. ЛОГИРОВАНИЕ ПРИ ЗАГРУЗКЕ
  // ============================================================

  console.log('╔═══════════════════════════════════════════════════════════════════╗');
  console.log('║              📦 PATH INTERCEPTOR v1.0                           ║');
  console.log('╠═══════════════════════════════════════════════════════════════════╣');
  console.log(`║  📌 Current path: ${defaultInterceptor.getPathInfo().pathname}`);
  console.log(`║  📌 Is root: ${defaultInterceptor.getPathInfo().isRoot}`);
  console.log(`║  📌 Is file: ${defaultInterceptor.getPathInfo().isFile}`);
  if (defaultInterceptor.getPathInfo().isFile) {
    console.log(`║  📌 Filename: ${defaultInterceptor.getPathInfo().filename}`);
  }
  console.log('╠═══════════════════════════════════════════════════════════════════╣');
  console.log('║  📋 Команды в консоли:                                          ║');
  console.log('║    __pathDebug.enable()         - включить debug логи           ║');
  console.log('║    __pathDebug.getHistory()     - показать историю запросов     ║');
  console.log('║    __pathDebug.getStats()       - статистика                    ║');
  console.log('║    __pathDebug.getPathInfo()    - информация о текущем пути     ║');
  console.log('║    __pathDebug.enableInterceptor()  - включить перехват         ║');
  console.log('║    __pathDebug.disableInterceptor() - выключить перехват        ║');
  console.log('║    __pathDebug.restore()        - восстановить оригинальные    ║');
  console.log('║    __pathDebug.on(event, cb)    - подписка на события           ║');
  console.log('╠═══════════════════════════════════════════════════════════════════╣');
  console.log('║  📡 Примеры:                                                    ║');
  console.log('║    fetch("./customData.mjs")                                    ║');
  console.log('║    // → fetch("/ ./customData.mjs") для root                    ║');
  console.log('║    // → fetch("/customData.mjs  /customData.mjs") для файла     ║');
  console.log('╚═══════════════════════════════════════════════════════════════════╝');

})();
