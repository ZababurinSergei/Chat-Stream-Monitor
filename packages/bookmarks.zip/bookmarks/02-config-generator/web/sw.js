// sw.js - МИНИМАЛЬНЫЙ Service Worker ТОЛЬКО для заголовков
// С автоматической перезагрузкой страницы после установки

// ============================================================
// 1. ЗАГОЛОВКИ ДЛЯ CROSS-ORIGIN ISOLATION
// ============================================================

const CROSS_ORIGIN_HEADERS = {
  'Cross-Origin-Opener-Policy': 'same-origin',
  'Cross-Origin-Embedder-Policy': 'require-corp',
  'Cross-Origin-Resource-Policy': 'same-origin',
};

// ============================================================
// 2. ПРОСТОЙ ЛОГГЕР
// ============================================================

function swLog(message, data = null) {
  const timestamp = new Date().toISOString().slice(11, 19);
  if (data !== null && data !== undefined) {
    console.log(`[SW] ${timestamp} ${message}`, data);
  } else {
    console.log(`[SW] ${timestamp} ${message}`);
  }
}

// ============================================================
// 3. УСТАНОВКА
// ============================================================

self.addEventListener('install', event => {
  swLog('📦 Установка Service Worker...');
  // Пропускаем ожидание, активируем сразу
  self.skipWaiting();
});

// ============================================================
// 4. АКТИВАЦИЯ С ПЕРЕЗАГРУЗКОЙ СТРАНИЦЫ
// ============================================================

self.addEventListener('activate', event => {
  swLog('🔄 Активация Service Worker...');

  event.waitUntil(
    // Захватываем контроль над всеми клиентами
    clients.claim().then(() => {
      swLog('✅ Контроль над клиентами установлен');

      // Отправляем сообщение всем клиентам о готовности SW
      return clients.matchAll().then(clients => {
        swLog(`📨 Отправка уведомления ${clients.length} клиентам...`);

        console.log('>>>>>>>>>>>>>>> client.postMessage', clients);
        clients.forEach(client => {
          client.postMessage({
            type: 'SW_READY',
            headers: CROSS_ORIGIN_HEADERS,
            timestamp: Date.now(),
          });
        });

        // ПЕРЕЗАГРУЗКА СТРАНИЦЫ ПОСЛЕ АКТИВАЦИИ SW
        swLog('🔄 Перезагрузка страниц после активации SW...');

        clients.forEach(client => {
          // Перезагружаем каждую вкладку
          try {
            client.navigate(client.url);
            swLog(`✅ Перезагрузка: ${client.url}`);
          } catch (e) {
            swLog(`⚠️ Ошибка перезагрузки: ${e.message}`);
          }
        });

        // Альтернативный способ - через 500мс после активации
        setTimeout(() => {
          clients.matchAll().then(allClients => {
            allClients.forEach(client => {
              try {
                // Используем reload через postMessage, если navigate не сработал
                client.postMessage({
                  type: 'SW_RELOAD',
                  timestamp: Date.now(),
                });
              } catch (e) {
                // Игнорируем
              }
            });
          });
        }, 500);

        return clients;
      });
    }),
  );
});

// ============================================================
// 5. ОБРАБОТКА ЗАПРОСОВ - ТОЛЬКО ДОБАВЛЕНИЕ ЗАГОЛОВКОВ
// ============================================================

self.addEventListener('fetch', event => {
  const url = new URL(event.request.url);

  // ============================================================
  // 1. ПРОПУСКАЕМ НЕПОДДЕРЖИВАЕМЫЕ ПРОТОКОЛЫ
  // ============================================================
  if (
    url.protocol === 'chrome-extension:' ||
    url.protocol === 'chrome:' ||
    url.protocol === 'about:' ||
    url.protocol === 'data:' ||
    url.protocol === 'blob:' ||
    url.protocol === 'file:'
  ) {
    return;
  }

  // ============================================================
  // 2. ПРОПУСКАЕМ ЗАПРОСЫ К ВНЕШНИМ РЕСУРСАМ
  // ============================================================
  if (url.origin !== self.location.origin) {
    event.respondWith(
      fetch(event.request).catch(() => new Response(null, {
        status: 404,
        statusText: 'Not Found',
      })),
    );
    return;
  }

  // ============================================================
  // 3. ДЛЯ ВСЕХ СВОИХ ЗАПРОСОВ - ДОБАВЛЯЕМ ЗАГОЛОВКИ
  // ============================================================
  event.respondWith(
    fetch(event.request)
      .then(response => {
        if (!response || !response.ok) {
          return response;
        }

        try {
          const newResponse = new Response(response.body, {
            status: response.status,
            statusText: response.statusText,
            headers: response.headers,
          });

          for (const [key, value] of Object.entries(CROSS_ORIGIN_HEADERS)) {
            try {
              newResponse.headers.set(key, value);
            } catch (e) {
              // Некоторые заголовки могут быть read-only
            }
          }

          return newResponse;
        } catch (error) {
          swLog(`⚠️ Ошибка добавления заголовков: ${error.message}`);
          return response;
        }
      })
      .catch(error => {
        swLog(`⚠️ Ошибка fetch: ${url.pathname}`, error.message);
        return new Response(null, {
          status: 404,
          statusText: 'Not Found',
          headers: CROSS_ORIGIN_HEADERS,
        });
      }),
  );
});

// ============================================================
// 6. ОБРАБОТКА СООБЩЕНИЙ
// ============================================================

self.addEventListener('message', event => {
  swLog(`📨 Получено сообщение:`, event.data);

  if (event.data && event.data.type === 'GET_HEADERS') {
    if (event.ports && event.ports.length > 0) {
      event.ports[0].postMessage({
        type: 'HEADERS',
        headers: CROSS_ORIGIN_HEADERS,
      });
    }
  }

  // Обработка запроса на перезагрузку
  if (event.data && event.data.type === 'RELOAD_PAGE') {
    if (event.ports && event.ports.length > 0) {
      event.ports[0].postMessage({
        type: 'RELOAD_CONFIRMED',
        timestamp: Date.now(),
      });
    }
    // Перезагружаем страницу
    if (event.source && event.source.url) {
      try {
        event.source.navigate(event.source.url);
        swLog(`🔄 Перезагрузка по запросу: ${event.source.url}`);
      } catch (e) {
        swLog(`⚠️ Ошибка перезагрузки: ${e.message}`);
      }
    }
  }
});

// ============================================================
// 7. ИНИЦИАЛИЗАЦИЯ
// ============================================================

swLog('═══════════════════════════════════════════════════════════');
swLog('📦 Service Worker загружен');
swLog('📌 ТОЛЬКО заголовки для Cross-Origin Isolation');
swLog('📌 БЕЗ кеширования');
swLog('📌 АВТОМАТИЧЕСКАЯ ПЕРЕЗАГРУЗКА после активации');
swLog('═══════════════════════════════════════════════════════════');
