// bookmarklet-path-converter.mjs - Конвертер путей в букмарклетах (ES6 модуль)

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import * as cheerio from 'cheerio';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// ============================================================
//  ДЕБАГЕР
// ============================================================

const DEBUG_NAMESPACE = 'bookmarklet-converter';

function debugLog(message, data = null, level = 'info') {
  const timestamp = new Date().toISOString();
  const prefix = `[${timestamp}] [${DEBUG_NAMESPACE}] [${level}]`;

  if (data !== null) {
    console.log(`${prefix} ${message}`);
    if (typeof data === 'object') {
      console.log(`${' '.repeat(prefix.length + 1)} ${JSON.stringify(data, null, 2)}`);
    } else {
      console.log(`${' '.repeat(prefix.length + 1)} ${data}`);
    }
  } else {
    console.log(`${prefix} ${message}`);
  }
}

// ============================================================
//  КОНФИГУРАЦИЯ
// ============================================================

export const CONFIG = {
  baseUrl: 'http://localhost:8081',
  bookmarkletPath: '/Bookmarklet/',
  extensions: ['.js', '.mjs'],
};

// ============================================================
//  ПАРСЕР HTML BOOKMARKS С CHEERIO (ИСПРАВЛЕННЫЙ)
// ============================================================

export function parseBookmarksHTML(html) {
  debugLog('Начинаем парсинг HTML...');
  debugLog('Длина HTML:', html.length);

  const $ = cheerio.load(html, {
    xml: {
      decodeEntities: false,
    },
    recognizeSelfClosing: true,
  });

  const bookmarks = [];
  let foundCount = 0;

  // Ищем все A теги с href содержащим javascript:
  $('a[href]').each((i, el) => {
    const $el = $(el);
    let href = $el.attr('href');

    // Декодируем HTML-сущности в href
    if (href) {
      href = href
        .replace(/&amp;/g, '&')
        .replace(/&lt;/g, '<')
        .replace(/&gt;/g, '>')
        .replace(/&quot;/g, '"')
        .replace(/&#39;/g, "'")
        .replace(/&#x2F;/g, '/');
    }

    // Проверяем, содержит ли href javascript:
    if (href && href.includes('javascript:')) {
      foundCount++;
      // Извлекаем код после javascript:
      const code = href.replace(/^javascript:/i, '').trim();

      const bookmark = {
        href: href,
        code: code,
        title: $el.text().trim(),
        addDate: $el.attr('ADD_DATE') || $el.attr('add_date') || String(Date.now()),
        icon: $el.attr('ICON') || $el.attr('icon') || '',
      };

      bookmarks.push(bookmark);

      debugLog(`Найден букмарклет #${foundCount}: "${bookmark.title}"`, {
        hrefLength: href.length,
        codeLength: code.length,
        codePreview: code.substring(0, 80) + (code.length > 80 ? '...' : ''),
      });
    }
  });

  // Если не найдено через a[href], пробуем через все теги с href
  if (foundCount === 0) {
    debugLog('Первый проход не дал результатов, пробуем альтернативный парсинг...');

    // Ищем все теги с href через регулярное выражение
    const linkRegex = /<A\s+[^>]*?HREF\s*=\s*["']([^"']*)["'][^>]*?>/gi;
    let match;
    let altCount = 0;

    while ((match = linkRegex.exec(html)) !== null) {
      const href = match[1];
      if (href && href.includes('javascript:')) {
        altCount++;
        const code = href.replace(/^javascript:/i, '').trim();

        // Находим текст между <A> и </A>
        const textRegex = new RegExp(
          `<A[^>]*?HREF\\s*=\\s*["']${match[1].replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}["'][^>]*?>(.*?)<\\/A>`,
          'i'
        );
        const textMatch = html.match(textRegex);
        const title = textMatch ? textMatch[1].trim() : `Букмарклет ${altCount}`;

        bookmarks.push({
          href: href,
          code: code,
          title: title,
          addDate: String(Date.now()),
          icon: '',
        });

        debugLog(`Найден букмарклет #${altCount} (альтернативный): "${title}"`);
      }
    }

    if (altCount > 0) {
      debugLog(`Альтернативный парсинг нашел ${altCount} букмарклетов`);
    }
  }

  debugLog(`Всего найдено букмарклетов: ${bookmarks.length}`);

  return {
    bookmarks: bookmarks,
    $: $,
  };
}

// ============================================================
//  КОНВЕРТЕР ПУТЕЙ
// ============================================================

export class BookmarkletPathConverter {
  constructor(baseUrl = CONFIG.baseUrl) {
    this.baseUrl = baseUrl;
    debugLog('Инициализация конвертера', { baseUrl });

    this.patterns = {
      fullUrl: new RegExp(`${this.baseUrl}${CONFIG.bookmarkletPath}([^'"\\s]+)`, 'g'),
      fullUrlWithQuote: new RegExp(
        `["']${this.baseUrl}${CONFIG.bookmarkletPath}([^'"\\s]+)["']`,
        'g'
      ),
      relativeWithPath: /['"]\.\/Bookmarklet\/([^'"\s]+)['"]/g,
      relativeSimple: /['"]\.\/([^'"\s]+)['"]/g,
      httpUrl: /https?:\/\/[^'"\s]+\/Bookmarklet\/([^'"\s]+)/g,
      templateLiteral: /\$\{.*?\}\/Bookmarklet\/([^'"\s]+)/g,
    };
  }

  toRelative(code) {
    debugLog('Конвертация в относительные пути...');
    let result = code;
    let replacements = 0;

    result = result.replace(this.patterns.fullUrl, (match, filePath) => {
      const cleanPath = filePath.split('?')[0];
      const newPath = `'./Bookmarklet/${cleanPath}'`;
      replacements++;
      debugLog(`  Замена fullUrl: ${match} → ${newPath}`);
      return newPath;
    });

    result = result.replace(this.patterns.fullUrlWithQuote, (match, filePath) => {
      const cleanPath = filePath.split('?')[0];
      const newPath = `'./Bookmarklet/${cleanPath}'`;
      replacements++;
      debugLog(`  Замена fullUrlWithQuote: ${match} → ${newPath}`);
      return newPath;
    });

    result = result.replace(this.patterns.httpUrl, (match, filePath) => {
      const cleanPath = filePath.split('?')[0];
      const newPath = `'./Bookmarklet/${cleanPath}'`;
      replacements++;
      debugLog(`  Замена httpUrl: ${match} → ${newPath}`);
      return newPath;
    });

    debugLog(`Всего замен в toRelative: ${replacements}`);
    return result;
  }

  toAbsolute(code) {
    debugLog('Конвертация в абсолютные пути...');
    let result = code;
    let replacements = 0;

    result = result.replace(this.patterns.relativeWithPath, (match, filePath) => {
      const cleanPath = filePath.split('?')[0];
      const newPath = `'${this.baseUrl}${CONFIG.bookmarkletPath}${cleanPath}'`;
      replacements++;
      debugLog(`  Замена relativeWithPath: ${match} → ${newPath}`);
      return newPath;
    });

    result = result.replace(this.patterns.relativeSimple, (match, filePath) => {
      if (filePath.startsWith('Bookmarklet/')) {
        const cleanPath = filePath.split('?')[0];
        const newPath = `'${this.baseUrl}${CONFIG.bookmarkletPath}${cleanPath.replace('Bookmarklet/', '')}'`;
        replacements++;
        debugLog(`  Замена relativeSimple (Bookmarklet/): ${match} → ${newPath}`);
        return newPath;
      }
      return match;
    });

    result = result.replace(this.patterns.templateLiteral, (match, filePath) => {
      const cleanPath = filePath.split('?')[0];
      const newPath = `\`${this.baseUrl}${CONFIG.bookmarkletPath}${cleanPath}\``;
      replacements++;
      debugLog(`  Замена templateLiteral: ${match} → ${newPath}`);
      return newPath;
    });

    debugLog(`Всего замен в toAbsolute: ${replacements}`);
    return result;
  }

  detectPathType(code) {
    const hasAbsolute =
      code.includes(this.baseUrl) || /https?:\/\/[^'"\s]+\/Bookmarklet\//.test(code);
    const hasRelativeWithPath = /['"]\.\/Bookmarklet\//.test(code);
    const hasRelativeSimple = /['"]\.\/(?!Bookmarklet\/)/.test(code);
    const hasTemplate = /\$\{.*?\}\/Bookmarklet\//.test(code);

    let type = 'none';
    if ((hasAbsolute || hasTemplate) && (hasRelativeWithPath || hasRelativeSimple)) {
      type = 'mixed';
    } else if (hasAbsolute || hasTemplate) {
      type = 'absolute';
    } else if (hasRelativeWithPath || hasRelativeSimple) {
      type = 'relative';
    }

    return type;
  }

  convertBookmarklet(code, direction = 'relative') {
    debugLog(`Конвертация букмарклета (${direction})...`);
    debugLog(
      'Исходный код (первые 200 символов):',
      code.substring(0, 200) + (code.length > 200 ? '...' : '')
    );

    let result;
    if (direction === 'relative') {
      result = this.toRelative(code);
    } else if (direction === 'absolute') {
      result = this.toAbsolute(code);
    } else {
      result = code;
    }

    if (result !== code) {
      debugLog('✅ Код изменен');
    } else {
      debugLog('ℹ️ Код не требует изменений');
    }

    return result;
  }

  processBookmarksHTML(html, direction = 'relative') {
    debugLog(`Начинаем обработку HTML (${direction})...`);

    const { $, bookmarks } = parseBookmarksHTML(html);
    let convertedCount = 0;
    let totalCount = bookmarks.length;

    debugLog(`Всего букмарклетов для обработки: ${totalCount}`);

    // Обрабатываем каждый букмарклет
    bookmarks.forEach((bookmark, index) => {
      debugLog(`Обработка букмарклета #${index + 1}: "${bookmark.title}"`);

      const newCode = this.convertBookmarklet(bookmark.code, direction);
      if (newCode !== bookmark.code) {
        const newHref = 'javascript:' + newCode;
        convertedCount++;
        debugLog(`  ✅ Обновлен`);
        debugLog(`     Было: ${bookmark.code.substring(0, 80)}...`);
        debugLog(`     Стало: ${newCode.substring(0, 80)}...`);

        // Обновляем в DOM
        const escapedHref = bookmark.href.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        const selector = `a[href="${escapedHref}"]`;
        const $el = $(selector);
        if ($el.length > 0) {
          $el.attr('href', newHref);
        }
      } else {
        debugLog(`  ℹ️ Без изменений`);
      }
    });

    debugLog(`✅ Конвертировано ${convertedCount} из ${totalCount} букмарклетов`);

    const resultHtml = $.html();
    debugLog(`Результирующий HTML размер: ${resultHtml.length} символов`);

    return resultHtml;
  }

  analyzeBookmarksHTML(html) {
    debugLog('Начинаем анализ букмарклетов...');

    const { bookmarks } = parseBookmarksHTML(html);
    const results = {
      total: 0,
      absolute: 0,
      relative: 0,
      mixed: 0,
      none: 0,
      bookmarks: [],
    };

    bookmarks.forEach((bookmark, index) => {
      const type = this.detectPathType(bookmark.code);
      results.total++;
      if (type === 'absolute') results.absolute++;
      else if (type === 'relative') results.relative++;
      else if (type === 'mixed') results.mixed++;
      else results.none++;

      results.bookmarks.push({
        title: bookmark.title,
        type: type,
        code: bookmark.code.substring(0, 150) + (bookmark.code.length > 150 ? '...' : ''),
        addDate: bookmark.addDate,
        icon: bookmark.icon,
      });
    });

    debugLog('Результаты анализа:', results);
    return results;
  }

  exportBookmarksHTML(bookmarks, title = 'Bookmarks') {
    debugLog(`Экспорт ${bookmarks.length} букмарклетов в HTML...`);

    let html = `<!DOCTYPE NETSCAPE-Bookmark-file-1>\n`;
    html += `<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">\n`;
    html += `<TITLE>${title}</TITLE>\n`;
    html += `<H1>${title}</H1>\n`;
    html += `<DL><p>\n`;

    bookmarks.forEach((bookmark, index) => {
      const addDate = bookmark.addDate || Date.now();
      const icon = bookmark.icon ? ` ICON="${bookmark.icon}"` : '';
      html += `    <DT><A HREF="${bookmark.href}" ADD_DATE="${addDate}"${icon}>${bookmark.title}</A>\n`;
    });

    html += `</DL><p>\n`;
    return html;
  }

  importBookmarksHTML(html) {
    return parseBookmarksHTML(html).bookmarks;
  }
}

// ============================================================
//  КОМАНДНАЯ СТРОКА
// ============================================================

export function printHelp() {
  console.log(`
📦 Bookmarklet Path Converter v2.0 (with Cheerio)

Использование:
  node bookmarklet-path-converter.mjs [опции] <файл>

Опции:
  -r, --relative    Конвертировать абсолютные пути в относительные (по умолчанию)
  -a, --absolute    Конвертировать относительные пути в абсолютные
  -o, --output      Выходной файл (если не указан, вывод в stdout)
  -h, --help        Показать эту справку
  -c, --check       Только проверить и показать анализ
  -b, --base        Указать базовый URL (по умолчанию: http://localhost:8081)
  -f, --format      Формат вывода: html (по умолчанию) или json
  -d, --debug       Включить подробный вывод отладочной информации

Примеры:
  node bookmarklet-path-converter.mjs bookmarks.html
  node bookmarklet-path-converter.mjs -a bookmarks.html -o bookmarks-absolute.html
  node bookmarklet-path-converter.mjs -r bookmarks.html -o bookmarks-relative.html
  node bookmarklet-path-converter.mjs -c bookmarks.html
  node bookmarklet-path-converter.mjs -d bookmarks.html
`);
}

// ============================================================
//  CLI ЗАПУСК
// ============================================================

export function runCLI() {
  const args = process.argv.slice(2);
  let inputFile = null;
  let outputFile = null;
  let direction = 'relative';
  let checkOnly = false;
  let baseUrl = CONFIG.baseUrl;
  let format = 'html';
  let debug = false;

  for (let i = 0; i < args.length; i++) {
    switch (args[i]) {
      case '-r':
      case '--relative':
        direction = 'relative';
        break;
      case '-a':
      case '--absolute':
        direction = 'absolute';
        break;
      case '-c':
      case '--check':
        checkOnly = true;
        break;
      case '-b':
      case '--base':
        baseUrl = args[++i];
        break;
      case '-f':
      case '--format':
        format = args[++i];
        break;
      case '-d':
      case '--debug':
        debug = true;
        break;
      case '-o':
      case '--output':
        outputFile = args[++i];
        break;
      case '-h':
      case '--help':
        printHelp();
        process.exit(0);
        break;
      default:
        if (!inputFile && !args[i].startsWith('-')) {
          inputFile = args[i];
        }
    }
  }

  if (!debug) {
    Object.assign(globalThis, { debugLog: () => {} });
  } else {
    console.log('🐛 Режим отладки ВКЛЮЧЕН');
    console.log(`📋 Namespace: ${DEBUG_NAMESPACE}`);
    console.log('═'.repeat(60));
  }

  if (!inputFile) {
    console.error('❌ Ошибка: не указан входной файл');
    printHelp();
    process.exit(1);
  }

  if (!fs.existsSync(inputFile)) {
    console.error(`❌ Ошибка: файл "${inputFile}" не найден`);
    process.exit(1);
  }

  try {
    const html = fs.readFileSync(inputFile, 'utf-8');
    debugLog('Файл загружен', { size: html.length, path: inputFile });

    const converter = new BookmarkletPathConverter(baseUrl);

    if (checkOnly) {
      const analysis = converter.analyzeBookmarksHTML(html);

      console.log('\n📊 АНАЛИЗ БУКМАРКЛЕТОВ');
      console.log('═'.repeat(60));
      console.log(`  📦 Всего букмарклетов:  ${analysis.total}`);
      console.log(`  🔗 Абсолютных:          ${analysis.absolute}`);
      console.log(`  📁 Относительных:       ${analysis.relative}`);
      console.log(`  🔀 Смешанных:           ${analysis.mixed}`);
      console.log(`  ❓ Без путей:           ${analysis.none}`);
      console.log(`  📍 Базовый URL:         ${baseUrl}`);
      console.log('\n📋 Детали:');
      console.log('─'.repeat(60));

      analysis.bookmarks.forEach((b, i) => {
        const icons = {
          absolute: '🔗',
          relative: '📁',
          mixed: '🔀',
          none: '❓',
        };
        const icon = icons[b.type] || '📄';
        console.log(`  ${String(i + 1).padStart(3)}. ${icon} ${b.title}`);
        console.log(`     Тип: ${b.type}`);
        console.log(`     ${b.code.substring(0, 120)}${b.code.length > 120 ? '...' : ''}`);
      });

      if (format === 'json') {
        console.log('\n' + JSON.stringify(analysis, null, 2));
      }

      process.exit(0);
    }

    debugLog(`Начинаем конвертацию в направлении: ${direction}`);
    let result = converter.processBookmarksHTML(html, direction);

    if (outputFile) {
      fs.writeFileSync(outputFile, result, 'utf-8');
      console.log(`✅ Конвертация завершена!`);
      console.log(`   📁 Входной файл:  ${inputFile}`);
      console.log(`   📄 Выходной файл: ${outputFile}`);
      console.log(`   📍 Базовый URL:   ${baseUrl}`);
      console.log(
        `   📌 Направление:   ${direction === 'relative' ? '📁 относительные' : '🔗 абсолютные'}`
      );
      console.log(
        `   📊 Пример: ${
          direction === 'relative'
            ? 'http://localhost:8081/Bookmarklet/file.js → ./Bookmarklet/file.js'
            : './Bookmarklet/file.js → http://localhost:8081/Bookmarklet/file.js'
        }`
      );

      if (debug) {
        const analysis = converter.analyzeBookmarksHTML(result);
        console.log(`   📊 Результат: ${analysis.total} букмарклетов`);
        console.log(`      🔗 Абсолютных: ${analysis.absolute}`);
        console.log(`      📁 Относительных: ${analysis.relative}`);
      }
    } else {
      console.log(result);
    }

    debugLog('Конвертация завершена успешно');
  } catch (error) {
    console.error('❌ Ошибка:', error.message);
    if (debug) {
      console.error(error.stack);
    }
    process.exit(1);
  }
}

// ============================================================
//  БРАУЗЕРНАЯ ВЕРСИЯ
// ============================================================

export function createBrowserAPI() {
  const api = {
    converter: new BookmarkletPathConverter(),
    debug: false,

    enableDebug() {
      this.debug = true;
      console.log('🐛 Режим отладки ВКЛЮЧЕН');
      return this;
    },

    disableDebug() {
      this.debug = false;
      console.log('🐛 Режим отладки ВЫКЛЮЧЕН');
      return this;
    },

    convertPage(direction = 'relative') {
      if (this.debug) console.log('🔍 Конвертация страницы...');

      const links = document.querySelectorAll('a[href]');
      let count = 0;

      links.forEach(link => {
        let href = link.getAttribute('href');
        if (href && href.includes('javascript:')) {
          const code = href.replace(/^javascript:/i, '').trim();
          const newCode = this.converter.convertBookmarklet(code, direction);
          if (newCode !== code) {
            link.setAttribute('href', 'javascript:' + newCode);
            count++;
            if (this.debug) {
              console.log(
                `  ✅ ${link.textContent}: ${code.substring(0, 50)}... → ${newCode.substring(0, 50)}...`
              );
            }
          }
        }
      });

      console.log(`✅ Конвертировано ${count} букмарклетов (${direction})`);
      return count;
    },

    copyBookmarks() {
      const links = document.querySelectorAll('a[href]');
      let result = '';

      links.forEach(link => {
        const href = link.getAttribute('href');
        if (href && href.includes('javascript:')) {
          const title = link.textContent || 'Букмарклет';
          const addDate = link.getAttribute('ADD_DATE') || Date.now();
          const icon = link.getAttribute('ICON') || '';
          const iconAttr = icon ? ` ICON="${icon}"` : '';
          result += `<DT><A HREF="${href}" ADD_DATE="${addDate}"${iconAttr}>${title}</A>\n`;
        }
      });

      navigator.clipboard
        .writeText(result)
        .then(() => {
          console.log(`✅ Скопировано букмарклетов`);
        })
        .catch(() => {
          console.log('📋 Скопируйте вручную:\n', result);
        });

      return result;
    },

    analyzePage() {
      const links = document.querySelectorAll('a[href]');
      const results = [];

      links.forEach(link => {
        let href = link.getAttribute('href');
        if (href && href.includes('javascript:')) {
          href = href.replace(/^javascript:/i, '').trim();
          const type = this.converter.detectPathType(href);
          const title = link.textContent || 'Без названия';

          results.push({
            title: title,
            type: type,
            code: href.substring(0, 100) + (href.length > 100 ? '...' : ''),
          });
        }
      });

      const stats = {
        total: results.length,
        absolute: results.filter(r => r.type === 'absolute').length,
        relative: results.filter(r => r.type === 'relative').length,
        mixed: results.filter(r => r.type === 'mixed').length,
        none: results.filter(r => r.type === 'none').length,
      };

      console.log('\n📊 АНАЛИЗ БУКМАРКЛЕТОВ НА СТРАНИЦЕ');
      console.log('═'.repeat(50));
      console.log(`  📦 Всего:    ${stats.total}`);
      console.log(`  🔗 Абсолютных: ${stats.absolute}`);
      console.log(`  📁 Относительных: ${stats.relative}`);
      console.log(`  🔀 Смешанных: ${stats.mixed}`);
      console.log(`  ❓ Без путей: ${stats.none}`);
      console.log('\n📋 Детали:');
      console.log('─'.repeat(50));

      results.forEach((r, i) => {
        const icons = {
          absolute: '🔗',
          relative: '📁',
          mixed: '🔀',
          none: '❓',
        };
        console.log(`  ${i + 1}. ${icons[r.type] || '📄'} ${r.title} (${r.type})`);
      });

      return { stats, results };
    },

    async loadBookmarksFile(file) {
      const text = await file.text();
      return this.converter.analyzeBookmarksHTML(text);
    },

    importBookmarks(text) {
      return this.converter.importBookmarksHTML(text);
    },

    exportBookmarks(bookmarks, title = 'Bookmarks') {
      return this.converter.exportBookmarksHTML(bookmarks, title);
    },

    setBaseUrl(url) {
      this.converter.baseUrl = url;
      console.log(`📍 Базовый URL установлен: ${url}`);
    },

    getBaseUrl() {
      return this.converter.baseUrl;
    },
  };

  return api;
}

// ============================================================
//  ЗАПУСК CLI
// ============================================================

if (import.meta.url === `file://${process.argv[1]}`) {
  runCLI();
}

// ============================================================
//  ЭКСПОРТ
// ============================================================

export default BookmarkletPathConverter;

// Браузерная инициализация
if (typeof window !== 'undefined') {
  const api = createBrowserAPI();
  window.convertBookmarklets = api;

  console.log('📦 BookmarkletPathConverter (with Cheerio) загружен');
  console.log('📋 Доступные команды:');
  console.log('  convertBookmarklets.enableDebug()           - включить отладку');
  console.log('  convertBookmarklets.disableDebug()          - выключить отладку');
  console.log('  convertBookmarklets.convertPage("relative") - конвертировать в относительные');
  console.log('  convertBookmarklets.convertPage("absolute") - конвертировать в абсолютные');
  console.log('  convertBookmarklets.copyBookmarks()         - копировать букмарклеты');
  console.log('  convertBookmarklets.analyzePage()          - анализ букмарклетов');
  console.log('  convertBookmarklets.setBaseUrl(url)        - установить базовый URL');
  console.log('  convertBookmarklets.getBaseUrl()           - получить базовый URL');
}
