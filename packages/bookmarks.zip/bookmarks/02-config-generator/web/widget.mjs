// widget.js - Основная логика виджета с оптимизированным перетаскиванием и пресетами

import ENV from './env.mjs';
import debug from './debug.mjs';

// Добавьте это в ваш существующий JavaScript
async function loadRemoteStore(serverUrl) {
  try {
    // Динамический импорт
    const { globalStore, STORE_SYMBOL } = await import(`${serverUrl}/src/core/store.js`);

    // Сохраняем в глобальный объект
    window[STORE_SYMBOL] = globalStore;
    window.__store = globalStore;

    // Добавляем удобные методы
    window.__store.sendMessage = globalStore.sendMessage.bind(globalStore);
    window.__store.broadcastMessage = globalStore.broadcastMessage.bind(globalStore);
    window.__store.getMessages = globalStore.getMessages.bind(globalStore);
    window.__store.getState = globalStore.getState.bind(globalStore);
    window.__store.getMetrics = globalStore.getMetrics.bind(globalStore);
    window.__store.setStatus = globalStore.setStatus.bind(globalStore);
    window.__store.appendDataBatch = globalStore.appendDataBatch.bind(globalStore);
    window.__store.clearStore = globalStore.clearStore.bind(globalStore);
    window.__store.subscribe = globalStore.subscribe.bind(globalStore);
    window.__store.healthCheck = globalStore.healthCheck.bind(globalStore);

    // Загружаем стрим-сервис
    try {
      const { getStreamService } = await import(`${serverUrl}/src/core/stream-service.js`);
      const streamService = getStreamService();
      if (streamService) {
        window.__streamService = streamService;
        window.__streamService.start = streamService.start.bind(streamService);
        window.__streamService.stop = streamService.stop.bind(streamService);
        window.__streamService.emit = streamService.emit.bind(streamService);
        window.__streamService.getStatus = streamService.getStatus.bind(streamService);
        window.__streamService.getStats = streamService.getStats.bind(streamService);
      }
    } catch (e) {
      console.warn('⚠️ Stream Service не загружен:', e.message);
    }

    console.log('✅ Store успешно загружен с', serverUrl);
    console.log('📋 Используйте window.__store для доступа');

    // Оповещаем о готовности
    window.dispatchEvent(new CustomEvent('store-ready', {
      detail: { store: globalStore, serverUrl, timestamp: Date.now() }
    }));

    return globalStore;
  } catch (error) {
    console.error('❌ Ошибка загрузки Store:', error);
    throw error;
  }
}

loadRemoteStore('http://localhost:3000');
const GLOBAL = typeof globalThis !== 'undefined' ? globalThis : window;
GLOBAL.ENV = ENV;

// ============================================================
//  УПРАВЛЕНИЕ СОСТОЯНИЕМ
// ============================================================

const STORAGE_KEY = 'widget-state';
const PRESETS_KEY = 'widget-presets';

// Состояние по умолчанию
const DEFAULT_STATE = {
  width: 480,
  height: 400,
  left: 50,
  top: 50,
  isMinimized: false,
  isMaximized: false,
  activeTab: 'generate',
  debugNamespace: '',
};

// Загрузка сохраненного состояния
function loadState() {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      const state = JSON.parse(saved);
      return { ...DEFAULT_STATE, ...state };
    }
  } catch (e) {
    console.warn('⚠️ Ошибка загрузки состояния:', e);
  }
  return { ...DEFAULT_STATE };
}

// Сохранение состояния
function saveState() {
  try {
    const state = {
      width: widget.offsetWidth,
      height: widget.offsetHeight,
      left: parseInt(widget.style.left) || widget.offsetLeft,
      top: parseInt(widget.style.top) || widget.offsetTop,
      isMinimized: isMinimized,
      isMaximized: isMaximized || isFullscreen,
      activeTab: getActiveTab(),
      debugNamespace: ENV.DEBUG.namespace || '',
    };
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch (e) {
    console.warn('⚠️ Ошибка сохранения состояния:', e);
  }
}

function getActiveTab() {
  const active = document.querySelector('.tab-btn.active');
  return active?.dataset?.tab || 'generate';
}

// ============================================================
//  УПРАВЛЕНИЕ ПРЕСЕТАМИ
// ============================================================

function loadPresets() {
  try {
    const saved = localStorage.getItem(PRESETS_KEY);
    if (saved) {
      return JSON.parse(saved);
    }
  } catch (e) {
    console.warn('⚠️ Ошибка загрузки пресетов:', e);
  }
  return [];
}

function savePresets(presets) {
  try {
    localStorage.setItem(PRESETS_KEY, JSON.stringify(presets));
  } catch (e) {
    console.warn('⚠️ Ошибка сохранения пресетов:', e);
  }
}

function getCurrentState() {
  return {
    name: '',
    timestamp: new Date().toISOString(),
    state: {
      width: widget.offsetWidth,
      height: widget.offsetHeight,
      left: parseInt(widget.style.left) || widget.offsetLeft,
      top: parseInt(widget.style.top) || widget.offsetTop,
      isMinimized: isMinimized,
      isMaximized: isMaximized || isFullscreen,
      activeTab: getActiveTab(),
      debugNamespace: ENV.DEBUG.namespace || '',
    },
  };
}

function applyPresetState(state) {
  if (!state) return;

  // Размер и позиция
  widget.style.width = state.width + 'px';
  widget.style.height = state.height + 'px';
  widget.style.left = state.left + 'px';
  widget.style.top = state.top + 'px';

  // Минимизация
  if (state.isMinimized) {
    widget.classList.add('minimized');
    isMinimized = true;
    minimizeBtn.textContent = '□';
  } else {
    widget.classList.remove('minimized');
    isMinimized = false;
    minimizeBtn.textContent = '─';
  }

  // Максимизация
  if (state.isMaximized) {
    enterFullscreen();
  } else if (isFullscreen) {
    exitFullscreen();
  }

  // Активная вкладка
  const tabBtns = document.querySelectorAll('.tab-btn');
  tabBtns.forEach(btn => {
    btn.classList.toggle('active', btn.dataset.tab === state.activeTab);
  });
  Object.entries(tabPanels).forEach(([key, panel]) => {
    panel.classList.toggle('active', key === state.activeTab);
  });

  // DEBUG namespace
  if (state.debugNamespace) {
    ENV.debug.enable(state.debugNamespace);
  } else {
    ENV.debug.disable();
  }

  updateDebugUI();
  saveState();
}

// ============================================================
//  УПРАВЛЕНИЕ ФОКУСОМ
// ============================================================

let maxZIndex = 99999;

function bringToFront(element) {
  const allWindows = document.querySelectorAll(
    '.widget-window, #widget-app, #logs-control-panel, #debug-control-panel, #debug-control-panel-v2, #env-control-panel'
  );
  let maxZ = 99999;

  allWindows.forEach(win => {
    if (win !== element && win.style.display !== 'none') {
      const z = parseInt(win.style.zIndex) || 0;
      if (z > maxZ) maxZ = z;
    }
  });

  const newZ = maxZ + 1;
  element.style.zIndex = newZ;

  allWindows.forEach(win => {
    win.classList.remove('active-window');
  });
  element.classList.add('active-window');

  maxZIndex = Math.max(maxZIndex, newZ);
  saveStateDebounced();
}

// ============================================================
//  ВИДЖЕТ
// ============================================================

const widget = document.getElementById('widget-app');
const header = document.getElementById('widget-header');
const resizeHandle = document.getElementById('widget-resize');
const minimizeBtn = document.getElementById('widget-minimize');
const maximizeBtn = document.getElementById('widget-maximize');
const closeBtn = document.getElementById('widget-close');

let isMinimized = false;
let isMaximized = false;
let isFullscreen = false;

// ============================================================
//  ФОКУСИРОВКА ВИДЖЕТА
// ============================================================

// При клике на виджет - выводим на передний план
widget.addEventListener('mousedown', e => {
  if (e.target.closest('.widget-controls')) return;
  bringToFront(widget);
});

// При клике на шапку - выводим на передний план
header.addEventListener('mousedown', e => {
  if (e.target.closest('.widget-controls')) return;
  bringToFront(widget);
});

// При клике на кнопки управления - выводим на передний план
document
  .querySelectorAll('.ctrl-btn, .form-actions button, .option-label, .form-control')
  .forEach(el => {
    el.addEventListener('mousedown', () => {
      bringToFront(widget);
    });
  });

// ============================================================
//  ОПТИМИЗИРОВАННОЕ ПЕРЕТАСКИВАНИЕ (с requestAnimationFrame)
// ============================================================

let dragData = null;
let rafId = null;

header.addEventListener('mousedown', e => {
  if (e.target.closest('.widget-controls')) return;
  if (e.target.closest('.presets-container')) return;
  if (isFullscreen) return;
  if (e.button !== 0) return; // только левая кнопка

  // Выводим на передний план при начале перетаскивания
  bringToFront(widget);

  e.preventDefault();

  const rect = widget.getBoundingClientRect();
  dragData = {
    offsetX: e.clientX - rect.left,
    offsetY: e.clientY - rect.top,
    startX: rect.left,
    startY: rect.top,
  };

  // Добавляем класс для отключения transition
  widget.classList.add('resizing');
  document.body.style.cursor = 'grabbing';
  document.body.style.userSelect = 'none';

  document.addEventListener('mousemove', onDragOptimized);
  document.addEventListener('mouseup', onDragEndOptimized);
});

function onDragOptimized(e) {
  if (!dragData) return;
  e.preventDefault();

  // Используем requestAnimationFrame для плавности
  if (rafId) {
    cancelAnimationFrame(rafId);
  }

  rafId = requestAnimationFrame(() => {
    const newLeft = e.clientX - dragData.offsetX;
    const newTop = e.clientY - dragData.offsetY;

    // Ограничиваем положение
    const maxX = window.innerWidth - widget.offsetWidth;
    const maxY = window.innerHeight - widget.offsetHeight;

    widget.style.left = Math.max(0, Math.min(maxX, newLeft)) + 'px';
    widget.style.top = Math.max(0, Math.min(maxY, newTop)) + 'px';

    rafId = null;
  });
}

function onDragEndOptimized() {
  if (dragData) {
    dragData = null;
    widget.classList.remove('resizing');
    document.body.style.cursor = '';
    document.body.style.userSelect = '';
    document.removeEventListener('mousemove', onDragOptimized);
    document.removeEventListener('mouseup', onDragEndOptimized);
    saveStateDebounced();
  }
  if (rafId) {
    cancelAnimationFrame(rafId);
    rafId = null;
  }
}

// ============================================================
//  ОПТИМИЗИРОВАННЫЙ РЕСАЙЗ
// ============================================================

let resizeData = null;
let resizeRafId = null;

resizeHandle.addEventListener('mousedown', e => {
  if (isFullscreen) return;
  e.stopPropagation();
  e.preventDefault();

  // Выводим на передний план при начале ресайза
  bringToFront(widget);

  resizeData = {
    startX: e.clientX,
    startY: e.clientY,
    width: widget.offsetWidth,
    height: widget.offsetHeight,
  };

  widget.classList.add('resizing');
  document.body.style.cursor = 'nwse-resize';
  document.body.style.userSelect = 'none';

  document.addEventListener('mousemove', onResizeOptimized);
  document.addEventListener('mouseup', onResizeEndOptimized);
});

function onResizeOptimized(e) {
  if (!resizeData) return;
  e.preventDefault();

  if (resizeRafId) {
    cancelAnimationFrame(resizeRafId);
  }

  resizeRafId = requestAnimationFrame(() => {
    const dx = e.clientX - resizeData.startX;
    const dy = e.clientY - resizeData.startY;

    const newWidth = Math.max(320, Math.min(window.innerWidth * 0.9, resizeData.width + dx));
    const newHeight = Math.max(300, Math.min(window.innerHeight * 0.9, resizeData.height + dy));

    widget.style.width = newWidth + 'px';
    widget.style.height = newHeight + 'px';

    resizeRafId = null;
  });
}

function onResizeEndOptimized() {
  if (resizeData) {
    resizeData = null;
    widget.classList.remove('resizing');
    document.body.style.cursor = '';
    document.body.style.userSelect = '';
    document.removeEventListener('mousemove', onResizeOptimized);
    document.removeEventListener('mouseup', onResizeEndOptimized);
    saveStateDebounced();
  }
  if (resizeRafId) {
    cancelAnimationFrame(resizeRafId);
    resizeRafId = null;
  }
}

// ============================================================
//  DEBOUNCE ДЛЯ СОХРАНЕНИЯ
// ============================================================

let saveTimeout = null;

function saveStateDebounced() {
  if (saveTimeout) clearTimeout(saveTimeout);
  saveTimeout = setTimeout(() => {
    saveState();
    saveTimeout = null;
  }, 300);
}

// ============================================================
//  ПОЛНОЭКРАННЫЙ РЕЖИМ
// ============================================================

function enterFullscreen() {
  isFullscreen = true;
  isMaximized = true;
  widget.classList.add('fullscreen');
  widget.style.width = '100vw';
  widget.style.height = '100vh';
  widget.style.top = '0';
  widget.style.left = '0';
  widget.style.borderRadius = '0';
  widget.style.border = 'none';
  widget.style.maxWidth = '100vw';
  widget.style.maxHeight = '100vh';
  widget.style.minWidth = '100vw';
  widget.style.minHeight = '100vh';
  maximizeBtn.textContent = '⧉';
  document.body.style.overflow = 'hidden';
  document.body.style.margin = '0';
  document.body.style.padding = '0';
  bringToFront(widget);
  saveState();
}

function exitFullscreen() {
  isFullscreen = false;
  isMaximized = false;
  widget.classList.remove('fullscreen');
  const state = loadState();
  widget.style.width = (state.width || 480) + 'px';
  widget.style.height = (state.height || 400) + 'px';
  widget.style.top = (state.top || 50) + 'px';
  widget.style.left = (state.left || 50) + 'px';
  widget.style.borderRadius = '12px';
  widget.style.border = '1px solid var(--border-color)';
  widget.style.maxWidth = '90vw';
  widget.style.maxHeight = '90vh';
  widget.style.minWidth = '320px';
  widget.style.minHeight = '300px';
  maximizeBtn.textContent = '□';
  document.body.style.overflow = '';
  document.body.style.margin = '';
  document.body.style.padding = '';
  saveState();
}

// ============================================================
//  УПРАВЛЕНИЕ ОКНОМ
// ============================================================

// Минимизация
minimizeBtn.addEventListener('click', e => {
  e.stopPropagation();
  bringToFront(widget);
  if (isFullscreen) exitFullscreen();
  isMinimized = !isMinimized;
  widget.classList.toggle('minimized', isMinimized);
  minimizeBtn.textContent = isMinimized ? '□' : '─';
  saveState();
});

// Максимизация
maximizeBtn.addEventListener('click', e => {
  e.stopPropagation();
  bringToFront(widget);
  if (isFullscreen) {
    exitFullscreen();
  } else {
    enterFullscreen();
  }
  saveState();
});

// Закрытие
closeBtn.addEventListener('click', e => {
  e.stopPropagation();
  widget.style.display = 'none';
  saveState();
});

function showWidget() {
  widget.style.display = 'flex';
  bringToFront(widget);
  saveState();
}

// ============================================================
//  ПРЕСЕТЫ - UI
// ============================================================

// Создаем контейнер для пресетов в шапке
const presetsContainer = document.createElement('div');
presetsContainer.className = 'presets-container';
presetsContainer.innerHTML = `
    <button class="preset-btn" id="preset-save" title="Сохранить пресет">💾</button>
    <button class="preset-btn" id="preset-load" title="Загрузить пресет">📂</button>
    <button class="preset-btn" id="preset-export" title="Экспортировать все пресеты">📤</button>
    <button class="preset-btn" id="preset-import" title="Импортировать пресеты">📥</button>
    <select class="preset-select" id="preset-select">
        <option value="">📋 Пресеты</option>
    </select>
`;

// Вставляем в шапку после заголовка
const title = header.querySelector('.widget-title');
title.after(presetsContainer);

// ============================================================
//  ЛОГИКА ПРЕСЕТОВ
// ============================================================

// Загрузка списка пресетов
function renderPresetList() {
  const presets = loadPresets();
  const select = document.getElementById('preset-select');
  if (!select) return;

  // Сохраняем текущее значение
  const currentValue = select.value;

  // Очищаем, оставляя первый option
  select.innerHTML = '<option value="">📋 Пресеты</option>';

  if (presets.length === 0) {
    select.innerHTML += '<option value="" disabled>— нет пресетов —</option>';
  } else {
    // Группируем по дате
    const sorted = [...presets].sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
    sorted.forEach((preset, index) => {
      const date = new Date(preset.timestamp);
      const dateStr = date.toLocaleString();
      const name = preset.name || `Пресет ${index + 1}`;
      const opt = document.createElement('option');
      opt.value = index;
      opt.textContent = `${name} (${dateStr})`;
      select.appendChild(opt);
    });
  }

  // Восстанавливаем выбранное значение если оно еще существует
  if (currentValue && select.querySelector(`option[value="${currentValue}"]`)) {
    select.value = currentValue;
  }
}

// Сохранение пресета
document.getElementById('preset-save')?.addEventListener('click', () => {
  const name = prompt('Введите имя пресета:', `Пресет ${new Date().toLocaleString()}`);
  if (name === null) return;

  const presets = loadPresets();
  const currentState = getCurrentState();
  currentState.name = name || `Пресет ${presets.length + 1}`;

  presets.push(currentState);
  savePresets(presets);
  renderPresetList();

  console.log(`✅ Пресет "${currentState.name}" сохранен`);
});

// Загрузка пресета
document.getElementById('preset-load')?.addEventListener('click', () => {
  const select = document.getElementById('preset-select');
  const index = parseInt(select.value);

  if (isNaN(index) || index < 0) {
    alert('Выберите пресет из списка');
    return;
  }

  const presets = loadPresets();
  if (index >= presets.length) {
    alert('Пресет не найден');
    return;
  }

  const preset = presets[index];
  if (preset && preset.state) {
    applyPresetState(preset.state);
    console.log(`✅ Загружен пресет "${preset.name}"`);
    // Сбрасываем выбор
    select.value = '';
  }
});

// Выбор пресета из списка (двойной клик для загрузки)
document.getElementById('preset-select')?.addEventListener('dblclick', () => {
  document.getElementById('preset-load')?.click();
});

// ============================================================
//  ЭКСПОРТ/ИМПОРТ ПРЕСЕТОВ (JSON)
// ============================================================

// Экспорт всех пресетов в JSON
document.getElementById('preset-export')?.addEventListener('click', () => {
  const presets = loadPresets();
  if (presets.length === 0) {
    alert('Нет пресетов для экспорта');
    return;
  }

  const data = JSON.stringify(presets, null, 2);
  const blob = new Blob([data], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `widget-presets-${new Date().toISOString().slice(0, 10)}.json`;
  a.click();
  URL.revokeObjectURL(url);
});

// Импорт пресетов из JSON
document.getElementById('preset-import')?.addEventListener('click', () => {
  const input = document.createElement('input');
  input.type = 'file';
  input.accept = '.json';
  input.onchange = e => {
    const file = e.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = event => {
      try {
        const imported = JSON.parse(event.target.result);
        if (!Array.isArray(imported)) {
          throw new Error('Неверный формат: ожидается массив пресетов');
        }

        const current = loadPresets();
        const merged = [...current, ...imported];
        savePresets(merged);
        renderPresetList();

        alert(`✅ Импортировано ${imported.length} пресетов`);
      } catch (error) {
        alert(`❌ Ошибка импорта: ${error.message}`);
      }
    };
    reader.readAsText(file);
  };
  input.click();
});

// ============================================================
//  ВКЛАДКИ
// ============================================================

const tabBtns = document.querySelectorAll('.tab-btn');
const tabPanels = {
  generate: document.getElementById('tab-generate'),
};

tabBtns.forEach(btn => {
  btn.addEventListener('click', () => {
    tabBtns.forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    const tab = btn.dataset.tab;
    Object.entries(tabPanels).forEach(([key, panel]) => {
      panel.classList.toggle('active', key === tab);
    });
    saveState();
  });
});

// ============================================================
//  ОБНОВЛЕНИЕ СТАТУСА DEBUG
// ============================================================

function updateDebugUI() {
  const current = ENV.DEBUG.namespace || '';
  const isEnabled = !!current;

  const statusEl = document.getElementById('debug-status');
  if (statusEl) {
    statusEl.textContent = isEnabled ? `🔍 ${current}` : '🔍 off';
    statusEl.className = `debug-status ${isEnabled ? 'on' : 'off'}`;
  }

  saveStateDebounced();
}

// ============================================================
//  ГЕНЕРАЦИЯ ФАЙЛОВ
// ============================================================

document.getElementById('btn-generate')?.addEventListener('click', async () => {
  const format = document.getElementById('gen-format')?.value || 'json';
  const filename = document.getElementById('gen-filename')?.value || 'config';
  const minify = document.getElementById('gen-minify')?.checked || false;
  const showPreview = document.getElementById('gen-preview')?.checked || false;

  const resultDiv = document.getElementById('gen-result');
  const contentDiv = document.getElementById('gen-result-content');

  resultDiv.style.display = 'block';
  contentDiv.innerHTML =
    '<div style="padding:10px;text-align:center;color:var(--text-muted);">⏳ Генерация...</div>';

  try {
    if (!GLOBAL.WasmAPI || !GLOBAL.WasmAPI.isReady()) {
      throw new Error('WASM модуль не загружен');
    }

    const results = {};
    if (format === 'json' || format === 'all') {
      results.json = GLOBAL.WasmAPI.generateJSON();
      if (minify && results.json) {
        try {
          results.json = JSON.stringify(JSON.parse(results.json));
        } catch {}
      }
    }
    if (format === 'c' || format === 'all') {
      results.c = GLOBAL.WasmAPI.generateC();
    }
    if (format === 'env' || format === 'all') {
      results.env = GLOBAL.WasmAPI.generateEnv();
    }

    let html = '';
    const files = [];
    for (const [key, value] of Object.entries(results)) {
      if (value) {
        const ext = key === 'json' ? '.json' : key === 'c' ? '.h' : '.env';
        const size = value.length;
        const sizeStr = size > 1024 ? `${(size / 1024).toFixed(2)}KB` : `${size}B`;
        files.push({ name: `${filename}${ext}`, content: value, size: sizeStr });
        html += `
                    <div class="file-item">
                        <span class="file-name">📄 ${filename}${ext}</span>
                        <span class="file-size">${sizeStr}</span>
                        <span class="file-status success">✅</span>
                    </div>
                `;
      }
    }

    if (showPreview && files.length > 0) {
      const preview = files[0];
      const previewContent =
        preview.content.length > 300 ? preview.content.slice(0, 300) + '...' : preview.content;
      html += `
                <div style="margin-top:6px;padding:6px;background:rgba(0,0,0,0.3);border-radius:4px;max-height:80px;overflow-y:auto;font-size:10px;">
                    <strong>📎 ${preview.name}</strong>
                    <pre style="margin:2px 0 0 0;white-space:pre-wrap;word-break:break-all;">${escapeHtml(previewContent)}</pre>
                </div>
            `;
    }

    contentDiv.innerHTML = html || '<div style="color:var(--text-muted);">Нет данных</div>';

    // Авто-скачивание
    for (const file of files) {
      const blob = new Blob([file.content], { type: 'text/plain' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = file.name;
      a.click();
      URL.revokeObjectURL(url);
    }
  } catch (error) {
    contentDiv.innerHTML = `<div style="color:var(--danger);padding:8px;">❌ ${error.message}</div>`;
  }
});

document.getElementById('btn-clear-gen')?.addEventListener('click', () => {
  document.getElementById('gen-result').style.display = 'none';
  document.getElementById('gen-result-content').innerHTML = '';
  saveState();
});

// ============================================================
//  ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ
// ============================================================

function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

// ============================================================
//  ВОССТАНОВЛЕНИЕ СОСТОЯНИЯ
// ============================================================

// Восстановление состояния
const savedState = loadState();

// Применяем сохраненное состояние
function applyState(state) {
  // Размер и позиция
  widget.style.width = state.width + 'px';
  widget.style.height = state.height + 'px';
  widget.style.left = state.left + 'px';
  widget.style.top = state.top + 'px';

  // Минимизация
  if (state.isMinimized) {
    widget.classList.add('minimized');
    isMinimized = true;
    minimizeBtn.textContent = '□';
  }

  // Максимизация (полноэкранный режим)
  if (state.isMaximized) {
    enterFullscreen();
  }

  // Активная вкладка
  const tabBtns = document.querySelectorAll('.tab-btn');
  tabBtns.forEach(btn => {
    btn.classList.toggle('active', btn.dataset.tab === state.activeTab);
  });
  Object.entries(tabPanels).forEach(([key, panel]) => {
    panel.classList.toggle('active', key === state.activeTab);
  });

  // DEBUG namespace
  if (state.debugNamespace) {
    ENV.debug.enable(state.debugNamespace);
  }

  updateDebugUI();
}

applyState(savedState);
renderPresetList();

// ============================================================
//  ОБРАБОТКА ИЗМЕНЕНИЯ РАЗМЕРА ОКНА
// ============================================================

let resizeTimeout = null;
window.addEventListener('resize', () => {
  if (isFullscreen) {
    widget.style.width = '100vw';
    widget.style.height = '100vh';
    widget.style.top = '0';
    widget.style.left = '0';
  } else {
    const maxW = window.innerWidth * 0.9;
    const maxH = window.innerHeight * 0.9;
    const currentW = parseInt(widget.style.width) || widget.offsetWidth;
    const currentH = parseInt(widget.style.height) || widget.offsetHeight;

    if (currentW > maxW) {
      widget.style.width = maxW + 'px';
    }
    if (currentH > maxH) {
      widget.style.height = maxH + 'px';
    }

    const left = parseInt(widget.style.left) || widget.offsetLeft;
    const top = parseInt(widget.style.top) || widget.offsetTop;
    const w = parseInt(widget.style.width) || widget.offsetWidth;
    const h = parseInt(widget.style.height) || widget.offsetHeight;

    if (left + w > window.innerWidth) {
      widget.style.left = Math.max(0, window.innerWidth - w - 10) + 'px';
    }
    if (top + h > window.innerHeight) {
      widget.style.top = Math.max(0, window.innerHeight - h - 10) + 'px';
    }

    clearTimeout(resizeTimeout);
    resizeTimeout = setTimeout(() => saveState(), 500);
  }
});

// ============================================================
//  ГОРЯЧИЕ КЛАВИШИ
// ============================================================

document.addEventListener('keydown', e => {
  // Alt+W - показать/скрыть виджет
  if (e.altKey && e.key === 'w') {
    e.preventDefault();
    if (widget.style.display === 'none') {
      showWidget();
    } else {
      closeBtn.click();
    }
  }
  // Escape - выход из полноэкранного режима
  if (e.key === 'Escape' && isFullscreen) {
    exitFullscreen();
    saveState();
  }
  // F11 - переключить полноэкранный режим
  if (e.key === 'F11') {
    e.preventDefault();
    maximizeBtn.click();
  }
});

// ============================================================
//  ЗАГРУЗКА WASM МОДУЛЯ
// ============================================================

document.getElementById('status-text').textContent = '⏳ Загрузка WASM...';

import('./app.mjs')
  .then(module => {
    console.log('✅ app.mjs загружен');
    document.getElementById('status-text').textContent = '✅ Готов';
    if (module.setEnv) module.setEnv(ENV);
  })
  .catch(error => {
    console.error('❌ Ошибка загрузки:', error);
    document.getElementById('status-text').textContent = '❌ Ошибка загрузки';
  });

// ============================================================
//  ИНИЦИАЛИЗАЦИЯ
// ============================================================

console.log('🔧 Виджет загружен. Используйте __widget для управления');
console.log('  __widget.enableDebug("wasm:*") - включить логи');
console.log('  __widget.disableDebug() - отключить логи');
console.log('  __widget.resize(600, 500) - изменить размер');
console.log('  __widget.fullscreen() - полноэкранный режим');
console.log('  __widget.focus() - вывести на передний план');
console.log('  __widget.minimize() - свернуть');
console.log('  __widget.maximize() - развернуть');
console.log('  __widget.getState() - получить состояние');
console.log('  __widget.resetState() - сбросить настройки');
console.log('  __widget.show() - показать виджет');
console.log('');
console.log('📋 Управление пресетами:');
console.log('  __widget.presets.save("Мой пресет") - сохранить пресет');
console.log('  __widget.presets.load(0) - загрузить пресет по индексу');
console.log('  __widget.presets.list() - список пресетов');
console.log('  __widget.presets.delete(0) - удалить пресет');
console.log('  __widget.presets.export() - экспортировать все пресеты в JSON');
console.log('  __widget.presets.import(jsonString) - импортировать пресеты из JSON');
console.log('  __widget.presets.clear() - удалить все пресеты');
console.log('');
console.log('⌨️ Горячие клавиши:');
console.log('  Alt+W - показать/скрыть виджет');
console.log('  F11 - переключить полноэкранный режим');
console.log('  Escape - выйти из полноэкранного режима');
console.log('  Двойной клик по пресету - загрузить');
console.log('  Клик по виджету - вывести на передний план');

// ============================================================
//  ЭКСПОРТ ДЛЯ ОТЛАДКИ
// ============================================================

GLOBAL.__widget = {
  addLog: (level, ...args) => console[level]?.(...args) || console.log(...args),
  enableDebug: ns => {
    ENV.debug.enable(ns);
    updateDebugUI();
    saveState();
  },
  disableDebug: () => {
    ENV.debug.disable();
    updateDebugUI();
    saveState();
  },
  minimize: () => minimizeBtn.click(),
  maximize: () => maximizeBtn.click(),
  close: () => closeBtn.click(),
  show: showWidget,
  focus: () => bringToFront(widget),
  resize: (w, h) => {
    if (isFullscreen) exitFullscreen();
    const maxW = window.innerWidth * 0.9;
    const maxH = window.innerHeight * 0.9;
    widget.style.width = Math.max(320, Math.min(maxW, w)) + 'px';
    widget.style.height = Math.max(300, Math.min(maxH, h)) + 'px';
    saveState();
  },
  fullscreen: () => {
    if (isFullscreen) {
      exitFullscreen();
    } else {
      enterFullscreen();
    }
    saveState();
  },
  getState: () => ({
    width: widget.offsetWidth,
    height: widget.offsetHeight,
    left: parseInt(widget.style.left) || widget.offsetLeft,
    top: parseInt(widget.style.top) || widget.offsetTop,
    isMinimized: isMinimized,
    isMaximized: isMaximized || isFullscreen,
    isFullscreen: isFullscreen,
    activeTab: getActiveTab(),
    debugNamespace: ENV.DEBUG.namespace || '',
    zIndex: parseInt(widget.style.zIndex) || 99999,
  }),
  resetState: () => {
    localStorage.removeItem(STORAGE_KEY);
    location.reload();
  },
  // Управление пресетами
  presets: {
    save: name => {
      const presets = loadPresets();
      const currentState = getCurrentState();
      currentState.name = name || `Пресет ${presets.length + 1}`;
      presets.push(currentState);
      savePresets(presets);
      renderPresetList();
      return currentState;
    },
    load: index => {
      const presets = loadPresets();
      if (index >= 0 && index < presets.length) {
        const preset = presets[index];
        if (preset && preset.state) {
          applyPresetState(preset.state);
          return preset;
        }
      }
      return null;
    },
    list: () => loadPresets(),
    delete: index => {
      const presets = loadPresets();
      if (index >= 0 && index < presets.length) {
        const removed = presets.splice(index, 1);
        savePresets(presets);
        renderPresetList();
        return removed[0];
      }
      return null;
    },
    export: () => {
      const presets = loadPresets();
      if (presets.length === 0) return null;
      return JSON.stringify(presets, null, 2);
    },
    import: json => {
      try {
        const imported = JSON.parse(json);
        if (!Array.isArray(imported)) throw new Error('Неверный формат');
        const current = loadPresets();
        const merged = [...current, ...imported];
        savePresets(merged);
        renderPresetList();
        return imported.length;
      } catch (e) {
        throw new Error(`Ошибка импорта: ${e.message}`);
      }
    },
    clear: () => {
      savePresets([]);
      renderPresetList();
    },
  },
};
