// ./core/config.js - Конфигурация букмарклета (100% СИМВОЛЫ)
// Версия: 1.0.0

// ============================================================
// 1. ПРИВАТНЫЕ СИМВОЛЫ ДЛЯ КОНФИГА
// ============================================================

export const CONFIG_SYMBOLS = {
  // Основные символы
  VERSION: Symbol('config.version'),
  BUILD: Symbol('config.build'),
  DEBUG: Symbol('config.debug'),
  BASE_PATH: Symbol('config.basePath'),
  TIMEOUT: Symbol('config.timeout'),
  MAX_RETRIES: Symbol('config.maxRetries'),
  RETRY_DELAY: Symbol('config.retryDelay'),
  FALLBACK_ENABLED: Symbol('config.fallbackEnabled'),
  LOG_ACTIVE_COMPONENT: Symbol('config.logActiveComponent'),
  SINGLETON: Symbol('config.singleton'),
  MAX_RECURSION: Symbol('config.maxRecursion'),
  RECURSION_DELAY: Symbol('config.recursionDelay'),

  // Имена и типы
  NAME: Symbol('config.name'),
  TYPE: Symbol('config.type'),
};

// ============================================================
// 2. КОНФИГУРАЦИЯ ПО УМОЛЧАНИЮ
// ============================================================

export const DEFAULT_CONFIG = {
  name: 'Bookmarklet',
  type: 'main',
  version: '3.5.1',
  build: '2026-07-20',
  debug: true,
  basePath: './Bookmarklet/',
  timeout: 5000,
  maxRetries: 3,
  retryDelay: 1000,
  fallbackEnabled: true,
  logActiveComponent: true,
  singleton: true,
  maxRecursion: 100,
  recursionDelay: 500,
};

// ============================================================
// 3. КАРТА СКРИПТОВ
// ============================================================

export const SCRIPT_MAP = {
  'env': './Bookmarklet/src/env-panel.js',
  'logs': './Bookmarklet/src/logs-panel.js',
  'debug': './Bookmarklet/src/debug-panel.js',
  'manager': './Bookmarklet/src/manager.html',
  'widget': './Bookmarklet/widget.mjs',
  'main': './Bookmarklet/bookmarklet.js',
};

// ============================================================
// 4. КАРТА ТИПОВ
// ============================================================

export const TYPE_MAP = {
  ENV: 'env',
  LOGS: 'logs',
  DEBUG: 'debug',
  MANAGER: 'manager',
  WIDGET: 'widget',
  MAIN: 'main',
};

export const VALID_TYPES = Object.values(TYPE_MAP);

// ============================================================
// 5. КОНФИГУРАЦИЯ ЛОГГЕРА
// ============================================================

export const LOGGER_CONFIG = {
  maxHistory: 200,
  defaultDebug: true,
  defaultInstanceId: 'Bookmarklet',
};

// ============================================================
// 6. КОНФИГУРАЦИЯ РЕКУРСИИ
// ============================================================

export const RECURSION_CONFIG = {
  defaultMaxRecursion: 100,
  defaultRecursionDelay: 500,
  minRecursionDelay: 100,
  maxRecursionDelay: 10000,
};

// ============================================================
// 7. КОНФИГУРАЦИЯ ПАНЕЛИ
// ============================================================

export const PANEL_CONFIG = {
  defaultWidth: 420,
  defaultHeight: 520,
  defaultPosition: { x: 100, y: 100 },
  minWidth: 320,
  minHeight: 300,
  maxWidth: '90vw',
  maxHeight: '90vh',
  zIndex: 99996,
  animations: true,
  animationDuration: 300,
};

// ============================================================
// 8. КОНФИГУРАЦИЯ КАНАЛА
// ============================================================

export const CHANNEL_CONFIG = {
  name: 'bookmarklet-channel',
  debug: true,
  maxHistory: 100,
  timeout: 5000,
  broadcast: true,
  postMessage: true,
  customEvent: true,
  storage: true,
};

// ============================================================
// 9. КОНФИГУРАЦИЯ ДЕБАГА
// ============================================================

export const DEBUG_CONFIG = {
  defaultNamespace: '',
  presets: {
    all: 'wasm:*',
    flow: 'wasm:flow:*',
    memory: 'wasm:memory:*',
    generate: 'wasm:generate:*',
    api: 'wasm:api:*',
    errors: 'wasm:error:*',
    allExceptMemory: '*,-wasm:memory:*',
    full: 'wasm:flow:*,wasm:generate:*,wasm:memory:*',
  },
};

// ============================================================
// 10. КОНФИГУРАЦИЯ СЖАТИЯ
// ============================================================

export const COMPRESSION_CONFIG = {
  enabled: true,
  minify: true,
  removeComments: true,
  shortenVariables: true,
  compressBooleans: true,
  aggressiveCompression: true,
  maxUrlLength: 2000,
  fallbackToUncompressed: true,
};

// ============================================================
// 11. КОНФИГУРАЦИЯ ОБНОВЛЕНИЙ
// ============================================================

export const UPDATE_CONFIG = {
  enabled: true,
  autoUpdate: true,
  updateInterval: 60000,
  generateNewCode: true,
  updateOnlyChanged: true,
  batchSize: 10,
  delayBetween: 500,
};

// ============================================================
// 12. КОНФИГУРАЦИЯ БУКМАРКЛЕТА
// ============================================================

export const BOOKMARKLET_CONFIG = {
  basePath: './Bookmarklet/',
  defaultType: 'main',
  autoShow: true,
  fallbackEnabled: true,
  timeout: 5000,
  maxRetries: 3,
  retryDelay: 1000,
  updateBookmarkUrl: true,
  preserveOriginalUrl: false,
  useUniversalLoader: true,
  loaderPath: './Bookmarklet/src/universal-loader.js',
};

// ============================================================
// 13. КОНФИГУРАЦИЯ ПО УМОЛЧАНИЮ (ПОЛНАЯ)
// ============================================================

export const FULL_DEFAULT_CONFIG = {
  ...DEFAULT_CONFIG,
  logger: LOGGER_CONFIG,
  recursion: RECURSION_CONFIG,
  panel: PANEL_CONFIG,
  channel: CHANNEL_CONFIG,
  debug: DEBUG_CONFIG,
  compression: COMPRESSION_CONFIG,
  update: UPDATE_CONFIG,
  bookmarklet: BOOKMARKLET_CONFIG,
  scriptMap: SCRIPT_MAP,
  typeMap: TYPE_MAP,
  validTypes: VALID_TYPES,
};

// ============================================================
// 14. ФУНКЦИИ-ПОМОЩНИКИ ДЛЯ КОНФИГА
// ============================================================

/**
 * Получить конфиг по ключу
 * @param {string} key - Ключ конфига
 * @param {*} defaultValue - Значение по умолчанию
 * @returns {*} Значение конфига
 */
export function getConfig(key, defaultValue = null) {
  if (key in FULL_DEFAULT_CONFIG) {
    return FULL_DEFAULT_CONFIG[key];
  }
  if (key in DEFAULT_CONFIG) {
    return DEFAULT_CONFIG[key];
  }
  return defaultValue;
}

/**
 * Получить вложенный конфиг по пути
 * @param {string} path - Путь через точку (например, 'panel.width')
 * @param {*} defaultValue - Значение по умолчанию
 * @returns {*} Значение конфига
 */
export function getConfigPath(path, defaultValue = null) {
  const parts = path.split('.');
  let current = FULL_DEFAULT_CONFIG;

  for (const part of parts) {
    if (current && typeof current === 'object' && part in current) {
      current = current[part];
    } else {
      return defaultValue;
    }
  }

  return current;
}

/**
 * Получить скрипт по типу
 * @param {string} type - Тип скрипта
 * @returns {string} Путь к скрипту
 */
export function getScriptByType(type) {
  return SCRIPT_MAP[type] || SCRIPT_MAP.main;
}

/**
 * Проверить валидность типа
 * @param {string} type - Тип для проверки
 * @returns {boolean} Валидный ли тип
 */
export function isValidType(type) {
  return VALID_TYPES.includes(type);
}

// ============================================================
// 15. ЭКСПОРТ ПО УМОЛЧАНИЮ
// ============================================================

export default {
  DEFAULT_CONFIG,
  SCRIPT_MAP,
  TYPE_MAP,
  VALID_TYPES,
  LOGGER_CONFIG,
  RECURSION_CONFIG,
  PANEL_CONFIG,
  CHANNEL_CONFIG,
  DEBUG_CONFIG,
  COMPRESSION_CONFIG,
  UPDATE_CONFIG,
  BOOKMARKLET_CONFIG,
  FULL_DEFAULT_CONFIG,
  getConfig,
  getConfigPath,
  getScriptByType,
  isValidType,
  CONFIG_SYMBOLS,
};

// ============================================================
// 16. ГЛОБАЛЬНАЯ РЕГИСТРАЦИЯ (для браузера)
// ============================================================

if (typeof window !== 'undefined') {
  window.__config = {
    DEFAULT_CONFIG,
    SCRIPT_MAP,
    TYPE_MAP,
    VALID_TYPES,
    LOGGER_CONFIG,
    RECURSION_CONFIG,
    PANEL_CONFIG,
    CHANNEL_CONFIG,
    DEBUG_CONFIG,
    COMPRESSION_CONFIG,
    UPDATE_CONFIG,
    BOOKMARKLET_CONFIG,
    FULL_DEFAULT_CONFIG,
    getConfig,
    getConfigPath,
    getScriptByType,
    isValidType,
    CONFIG_SYMBOLS,
  };

  window.__configSymbols = CONFIG_SYMBOLS;

  console.log('📦 ./core/config.js загружен (100% СИМВОЛЫ)');
  console.log('📋 Приватных символов:', Object.keys(CONFIG_SYMBOLS).length);
  console.log('📋 Доступные команды:');
  console.log('  window.__config.getConfig("panel") - получить конфиг');
  console.log('  window.__config.getConfigPath("panel.width") - получить вложенный конфиг');
  console.log('  window.__config.getScriptByType("env") - получить путь к скрипту');
  console.log('  window.__config.isValidType("env") - проверить тип');
}
