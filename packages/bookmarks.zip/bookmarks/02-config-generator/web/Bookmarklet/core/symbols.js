// web/Bookmarklet/core/symbols.js - 100% СИМВОЛЫ (ПОЛНАЯ ВЕРСИЯ)
// Версия: 3.5.2
// Все приватные и публичные символы для Bookmarklet
// ОБНОВЛЕНО: Добавлены недостающие символы для panel-manager.js

// ============================================================
// 1. ПРИВАТНЫЕ СИМВОЛЫ (100% изоляция)
// ============================================================

export const PRIVATE = {
  // ============================================================
  // ОСНОВНЫЕ СИМВОЛЫ (10)
  // ============================================================
  CONFIG: Symbol('bookmarklet.config'),
  LOGGER: Symbol('bookmarklet.logger'),
  STATE: Symbol('bookmarklet.state'),
  CACHE: Symbol('bookmarklet.cache'),
  VERSION: Symbol('bookmarklet.version'),
  BUILD: Symbol('bookmarklet.build'),
  INITIALIZED: Symbol('bookmarklet.initialized'),
  IS_RUNNING: Symbol('bookmarklet.isRunning'),
  IS_DESTROYED: Symbol('bookmarklet.isDestroyed'),
  IS_SINGLETON: Symbol('bookmarklet.isSingleton'),

  // ============================================================
  // ДАННЫЕ (10)
  // ============================================================
  NAME: Symbol('bookmarklet.name'),
  TYPE: Symbol('bookmarklet.type'),
  ID: Symbol('bookmarklet.id'),
  TIMESTAMP: Symbol('bookmarklet.timestamp'),
  PROPS: Symbol('bookmarklet.props'),
  RESULT: Symbol('bookmarklet.result'),
  CALLBACK: Symbol('bookmarklet.callback'),
  SCRIPT: Symbol('bookmarklet.script'),
  SCRIPT_PATH: Symbol('bookmarklet.scriptPath'),
  DATA: Symbol('bookmarklet.data'),

  // ============================================================
  // РЕКУРСИЯ (6)
  // ============================================================
  PREVIOUS_RESULT: Symbol('bookmarklet.previousResult'),
  IS_RECURSIVE: Symbol('bookmarklet.isRecursive'),
  TARGET_STATE: Symbol('bookmarklet.targetState'),
  MAX_RECURSION: Symbol('bookmarklet.maxRecursion'),
  RECURSION_DELAY: Symbol('bookmarklet.recursionDelay'),
  IS_COMPLETE: Symbol('bookmarklet.isComplete'),

  // ============================================================
  // МЕТАДАННЫЕ (4)
  // ============================================================
  METADATA: Symbol('bookmarklet.metadata'),
  CONTEXT: Symbol('bookmarklet.context'),
  LOG_HISTORY: Symbol('bookmarklet.logHistory'),
  ACTIVE_COMPONENT: Symbol('bookmarklet.activeComponent'),

  // ============================================================
  // БЕЗОПАСНОСТЬ (2)
  // ============================================================
  SECURE: Symbol('bookmarklet.secure'),
  VALIDATOR: Symbol('bookmarklet.validator'),

  // ============================================================
  // ПАНЕЛЬ (4)
  // ============================================================
  PANEL: Symbol('bookmarklet.panel'),
  PANEL_TYPE: Symbol('bookmarklet.panelType'),
  PANEL_LOADED: Symbol('bookmarklet.panelLoaded'),
  PANEL_VISIBLE: Symbol('bookmarklet.panelVisible'),

  // ============================================================
  // ★★★ МЕТОДЫ (ПРИВАТНЫЕ) - 22 ★★★
  // ============================================================
  INIT: Symbol('bookmarklet.init'),
  RUN: Symbol('bookmarklet.run'),
  EXECUTE_SCRIPT: Symbol('bookmarklet.executeScript'),
  LOG_ACTIVE_COMPONENT: Symbol('bookmarklet.logActiveComponent'),
  SHOW_ERROR: Symbol('bookmarklet.showError'),
  GET_STATE: Symbol('bookmarklet.getState'),
  GET_STATS: Symbol('bookmarklet.getStats'),
  RESET: Symbol('bookmarklet.reset'),
  DESTROY: Symbol('bookmarklet.destroy'),
  EXPORT_SYMBOLS: Symbol('bookmarklet.exportSymbols'),
  GET_SCRIPT_PATH: Symbol('bookmarklet.getScriptPath'),
  DETECT_SCRIPT: Symbol('bookmarklet.detectScript'),
  HANDLE_CALLBACK: Symbol('bookmarklet.handleCallback'),
  GET_INSTANCE: Symbol('bookmarklet.getInstance'),
  CREATE_INSTANCE: Symbol('bookmarklet.createInstance'),
  UPDATE: Symbol('bookmarklet.update'),
  RECURSIVE: Symbol('bookmarklet.recursive'),
  CHECK_STATE: Symbol('bookmarklet.checkState'),
  RECURSIVE_LOOP: Symbol('bookmarklet.recursiveLoop'),
  VALIDATE_INSTANCE: Symbol('bookmarklet.validateInstance'),

  // ★★★ НОВЫЕ СИМВОЛЫ ДЛЯ PANEL-MANAGER ★★★
  TOGGLE_PANEL: Symbol('bookmarklet.togglePanel'),
  SHOW_PANEL: Symbol('bookmarklet.showPanel'),
  HIDE_PANEL: Symbol('bookmarklet.hidePanel'),
  CHECK_PANEL: Symbol('bookmarklet.checkPanel'),
  GET_PANEL_STATE: Symbol('bookmarklet.getPanelState'),
  ANIMATE_PANEL: Symbol('bookmarklet.animatePanel'),
  REMOVE_ERROR: Symbol('bookmarklet.removeError'),
  ERROR_TIMEOUT: Symbol('bookmarklet.errorTimeout'),

  // ============================================================
  // ★★★ ДОПОЛНИТЕЛЬНЫЕ СИМВОЛЫ ДЛЯ УПРАВЛЕНИЯ ★★★
  // ============================================================
  SYNC: Symbol('bookmarklet.sync'),
  EXPORT: Symbol('bookmarklet.export'),
  IMPORT: Symbol('bookmarklet.import'),
  CLEAR: Symbol('bookmarklet.clear'),
  RELOAD: Symbol('bookmarklet.reload'),
  FOCUS: Symbol('bookmarklet.focus'),
  MINIMIZE: Symbol('bookmarklet.minimize'),
  MAXIMIZE: Symbol('bookmarklet.maximize'),
  FULLSCREEN: Symbol('bookmarklet.fullscreen'),
  DRAG: Symbol('bookmarklet.drag'),
  RESIZE: Symbol('bookmarklet.resize'),
  Z_INDEX: Symbol('bookmarklet.zIndex'),
  POSITION: Symbol('bookmarklet.position'),
  SIZE: Symbol('bookmarklet.size'),
};

// ============================================================
// 2. ПУБЛИЧНЫЕ СИМВОЛЫ (доступны через Symbol.for)
// ============================================================

export const PUBLIC = {
  // ============================================================
  // ОСНОВНЫЕ API (11)
  // ============================================================
  API: Symbol.for('bookmarklet.api'),
  STATE: Symbol.for('bookmarklet.state'),
  CONFIG: Symbol.for('bookmarklet.config'),
  LOGGER: Symbol.for('bookmarklet.logger'),
  INSTANCE: Symbol.for('bookmarklet.instance'),
  EVENTS: Symbol.for('bookmarklet.events'),
  MAIN: Symbol.for('bookmarklet.main'),
  ACTIVE: Symbol.for('bookmarklet.active'),
  SINGLETON: Symbol.for('bookmarklet.singleton'),
  RECURSIVE: Symbol.for('bookmarklet.recursive'),
  RECURSIVE_LOOP: Symbol.for('bookmarklet.recursiveLoop'),

  // ============================================================
  // ★★★ PANEL-MANAGER СИМВОЛЫ (9) ★★★
  // ============================================================
  PANEL: Symbol.for('bookmarklet.panel'),
  PANEL_STATE: Symbol.for('bookmarklet.panel.state'),
  PANEL_CONFIG: Symbol.for('bookmarklet.panel.config'),
  PANEL_EVENTS: Symbol.for('bookmarklet.panel.events'),
  PANEL_API: Symbol.for('bookmarklet.panel.api'),
  PANEL_CONTROLS: Symbol.for('bookmarklet.panel.controls'),
  PANEL_HEADER: Symbol.for('bookmarklet.panel.header'),
  PANEL_BODY: Symbol.for('bookmarklet.panel.body'),
  PANEL_RESIZE: Symbol.for('bookmarklet.panel.resize'),

  // ============================================================
  // ★★★ УПРАВЛЕНИЕ (6) ★★★
  // ============================================================
  SYNC: Symbol.for('bookmarklet.sync'),
  EXPORT: Symbol.for('bookmarklet.export'),
  IMPORT: Symbol.for('bookmarklet.import'),
  RESET: Symbol.for('bookmarklet.reset'),
  DESTROY: Symbol.for('bookmarklet.destroy'),
  RELOAD: Symbol.for('bookmarklet.reload'),

  // ============================================================
  // ★★★ РЕКУРСИЯ (3) ★★★
  // ============================================================
  CHECK_STATE: Symbol.for('bookmarklet.checkState'),
  RECURSIVE_STEP: Symbol.for('bookmarklet.recursive.step'),
  RECURSIVE_LOOP_EXT: Symbol.for('bookmarklet.recursive.loop'),

  // ============================================================
  // ★★★ ДАННЫЕ (5) ★★★
  // ============================================================
  BOOKMARKS: Symbol.for('bookmarklet.bookmarks'),
  BOOKMARKLETS: Symbol.for('bookmarklet.bookmarklets'),
  FOLDERS: Symbol.for('bookmarklet.folders'),
  HISTORY: Symbol.for('bookmarklet.history'),
  STATS: Symbol.for('bookmarklet.stats'),
};

// ============================================================
// 3. ★★★ ДОПОЛНИТЕЛЬНЫЕ СИМВОЛЫ ДЛЯ PANEL-MANAGER ★★★
// ============================================================

export const PANEL_SYMBOLS = {
  // Приватные символы панели (только для panel-manager)
  PANEL_ID: Symbol('panel-manager.panelId'),
  PANEL_ELEMENT: Symbol('panel-manager.panelElement'),
  PANEL_VISIBLE: Symbol('panel-manager.panelVisible'),
  PANEL_ANIMATION: Symbol('panel-manager.panelAnimation'),
  PANEL_TIMEOUT: Symbol('panel-manager.panelTimeout'),
  PANEL_CONFIG: Symbol('panel-manager.config'),
  PANEL_STATE: Symbol('panel-manager.state'),

  // Символы методов
  TOGGLE_PANEL: Symbol('panel-manager.togglePanel'),
  SHOW_PANEL: Symbol('panel-manager.showPanel'),
  HIDE_PANEL: Symbol('panel-manager.hidePanel'),
  CHECK_PANEL: Symbol('panel-manager.checkPanel'),
  GET_PANEL_STATE: Symbol('panel-manager.getPanelState'),
  ANIMATE_PANEL: Symbol('panel-manager.animatePanel'),
  SHOW_ERROR: Symbol('panel-manager.showError'),
  REMOVE_ERROR: Symbol('panel-manager.removeError'),
  ERROR_TIMEOUT: Symbol('panel-manager.errorTimeout'),
};

// ============================================================
// 4. ПУБЛИЧНЫЕ СИМВОЛЫ PANEL-MANAGER
// ============================================================

export const PUBLIC_PANEL_SYMBOLS = {
  API: Symbol.for('panel-manager.api'),
  STATE: Symbol.for('panel-manager.state'),
  CONFIG: Symbol.for('panel-manager.config'),
  EVENTS: Symbol.for('panel-manager.events'),
};

// ============================================================
// 5. ЭКСПОРТ ПО УМОЛЧАНИЮ
// ============================================================

export default {
  PRIVATE,
  PUBLIC,
  PANEL_SYMBOLS,
  PUBLIC_PANEL_SYMBOLS,
};

// ============================================================
// 6. ГЛОБАЛЬНАЯ РЕГИСТРАЦИЯ (для браузера)
// ============================================================

if (typeof window !== 'undefined') {
  window.__symbols = {
    PRIVATE: { ...PRIVATE },
    PUBLIC: { ...PUBLIC },
    PANEL_SYMBOLS: { ...PANEL_SYMBOLS },
    PUBLIC_PANEL_SYMBOLS: { ...PUBLIC_PANEL_SYMBOLS },
    count: {
      private: Object.keys(PRIVATE).length,
      public: Object.keys(PUBLIC).length,
      panel: Object.keys(PANEL_SYMBOLS).length,
      publicPanel: Object.keys(PUBLIC_PANEL_SYMBOLS).length,
      total: Object.keys(PRIVATE).length +
          Object.keys(PUBLIC).length +
          Object.keys(PANEL_SYMBOLS).length +
          Object.keys(PUBLIC_PANEL_SYMBOLS).length,
    },
  };

  console.log('╔═══════════════════════════════════════════════════════════════════════════════╗');
  console.log('║              🔑 SYMBOLS MODULE (100% СИМВОЛЫ) v3.5.2                        ║');
  console.log('╠═══════════════════════════════════════════════════════════════════════════════╣');
  console.log(`║  📦 Приватных символов:        ${String(Object.keys(PRIVATE).length).padStart(3)}                                    ║`);
  console.log(`║  🔓 Публичных символов:         ${String(Object.keys(PUBLIC).length).padStart(3)}                                    ║`);
  console.log(`║  📦 Panel приватных:            ${String(Object.keys(PANEL_SYMBOLS).length).padStart(3)}                                    ║`);
  console.log(`║  🔓 Panel публичных:           ${String(Object.keys(PUBLIC_PANEL_SYMBOLS).length).padStart(3)}                                    ║`);
  console.log(`║  📊 Всего символов:             ${String(Object.keys(PRIVATE).length + Object.keys(PUBLIC).length + Object.keys(PANEL_SYMBOLS).length + Object.keys(PUBLIC_PANEL_SYMBOLS).length).padStart(3)}                                    ║`);
  console.log('║                                                                               ║');
  console.log('║  📋 Доступно в window.__symbols:                                             ║');
  console.log('║    __symbols.PRIVATE           - все приватные символы                       ║');
  console.log('║    __symbols.PUBLIC            - все публичные символы                       ║');
  console.log('║    __symbols.PANEL_SYMBOLS     - символы panel-manager                       ║');
  console.log('║    __symbols.PUBLIC_PANEL_SYMBOLS - публичные символы panel-manager          ║');
  console.log('║    __symbols.count             - количество символов                         ║');
  console.log('╚═══════════════════════════════════════════════════════════════════════════════╝');

  console.log('📋 КОМАНДЫ ОТЛАДКИ:');
  console.log('  Object.keys(__symbols.PRIVATE).length  - количество приватных символов');
  console.log('  Object.keys(__symbols.PUBLIC).length   - количество публичных символов');
  console.log('  Object.keys(__symbols.PANEL_SYMBOLS).length - количество символов panel');
  console.log('  __symbols.PRIVATE.TOGGLE_PANEL        - символ для togglePanel');
  console.log('  __symbols.PANEL_SYMBOLS.TOGGLE_PANEL  - символ panel-manager для togglePanel');
}
