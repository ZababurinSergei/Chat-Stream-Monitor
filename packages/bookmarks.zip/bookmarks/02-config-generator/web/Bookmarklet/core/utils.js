// core/utils.js - Вспомогательные функции для букмарклета (100% СИМВОЛЫ)
// Версия: 1.0.0

// ============================================================
// 1. ПРИВАТНЫЕ СИМВОЛЫ (100% изоляция)
// ============================================================

const PRIVATE = {
  // Символы для внутреннего использования
  SCRIPT_MAP: Symbol('utils.scriptMap'),
  BASE_PATH: Symbol('utils.basePath'),
  CACHE: Symbol('utils.cache'),
  VALIDATE: Symbol('utils.validate'),
  SANITIZE: Symbol('utils.sanitize'),
  IS_INSTANCE: Symbol('utils.isInstance'),
  GET_SCRIPT: Symbol('utils.getScript'),
  DETECT_SCRIPT: Symbol('utils.detectScript'),
  GET_PATH: Symbol('utils.getPath'),
  PARSE_PARAMS: Symbol('utils.parseParams'),
  CHECK_STORAGE: Symbol('utils.checkStorage'),
  CHECK_DOM: Symbol('utils.checkDom'),
  CHECK_WINDOW: Symbol('utils.checkWindow'),
};

// ============================================================
// 2. ПУБЛИЧНЫЕ СИМВОЛЫ (доступны через Symbol.for)
// ============================================================

const PUBLIC = {
  UTILS: Symbol.for('bookmarklet.utils'),
  HELPERS: Symbol.for('bookmarklet.helpers'),
  VALIDATORS: Symbol.for('bookmarklet.validators'),
};

// ============================================================
// 3. КОНФИГУРАЦИЯ
// ============================================================

const DEFAULT_CONFIG = {
  basePath: './Bookmarklet/',
  cacheTTL: 30000,
  maxCacheSize: 100,
};

// ============================================================
// 4. КАРТА СКРИПТОВ
// ============================================================

const SCRIPT_MAP = {
  'env': './Bookmarklet/src/env-panel.js',
  'logs': './Bookmarklet/src/logs-panel.js',
  'debug': './Bookmarklet/src/debug-panel.js',
  'manager': './Bookmarklet/src/manager.html',
  'widget': './Bookmarklet/widget.mjs',
  'main': './Bookmarklet/bookmarklet.js',
};

// ============================================================
// 5. ЛОГГЕР ДЛЯ УТИЛИТ
// ============================================================

const LOGGER_SYMBOLS = {
  HISTORY: Symbol('logger.history'),
  MAX_HISTORY: Symbol('logger.maxHistory'),
  DEBUG: Symbol('logger.debug'),
  INSTANCE_ID: Symbol('logger.instanceId'),
};

function createLogger(debug = true, instanceId = 'Utils') {
  const state = {
    [LOGGER_SYMBOLS.HISTORY]: [],
    [LOGGER_SYMBOLS.MAX_HISTORY]: 50,
    [LOGGER_SYMBOLS.DEBUG]: debug,
    [LOGGER_SYMBOLS.INSTANCE_ID]: instanceId,
  };

  const logMethod = function (level, message, data = null) {
    if (!this[LOGGER_SYMBOLS.DEBUG] && level !== 'error') {
      return;
    }

    const timestamp = new Date().toISOString().slice(11, 23);
    const prefix = `[${timestamp}] [${this[LOGGER_SYMBOLS.INSTANCE_ID]}]`;

    this[LOGGER_SYMBOLS.HISTORY].push({ timestamp, level, message, data });
    if (this[LOGGER_SYMBOLS.HISTORY].length > this[LOGGER_SYMBOLS.MAX_HISTORY]) {
      this[LOGGER_SYMBOLS.HISTORY].shift();
    }

    if (data !== null && data !== undefined) {
      console.log(`${prefix} ${message}`, data);
    } else {
      console.log(`${prefix} ${message}`);
    }
  };

  const boundLog = logMethod.bind(state);

  const methods = {
    error: (msg, d) => boundLog('error', `❌ ${msg}`, d),
    warn: (msg, d) => boundLog('warn', `⚠️ ${msg}`, d),
    info: (msg, d) => boundLog('info', `ℹ️ ${msg}`, d),
    debug: (msg, d) => boundLog('debug', `🔍 ${msg}`, d),
    success: (msg, d) => boundLog('info', `✅ ${msg}`, d),
  };

  const logger = {};
  for (const [key, fn] of Object.entries(methods)) {
    logger[key] = fn.bind(state);
  }

  logger[LOGGER_SYMBOLS.HISTORY] = state[LOGGER_SYMBOLS.HISTORY];
  logger[LOGGER_SYMBOLS.MAX_HISTORY] = state[LOGGER_SYMBOLS.MAX_HISTORY];
  logger[LOGGER_SYMBOLS.DEBUG] = state[LOGGER_SYMBOLS.DEBUG];
  logger[LOGGER_SYMBOLS.INSTANCE_ID] = state[LOGGER_SYMBOLS.INSTANCE_ID];

  return logger;
}

// ============================================================
// 6. ОСНОВНЫЕ ФУНКЦИИ
// ============================================================

/**
 * Проверяет, является ли объект экземпляром Bookmarklet
 * @param {*} instance - Проверяемый объект
 * @param {*} BookmarkletClass - Класс Bookmarklet для проверки
 * @returns {boolean} - true если экземпляр валидный
 */
export function isBookmarkletInstance(instance, BookmarkletClass) {
  const logger = createLogger(false, 'Utils');

  try {
    const isValid = instance &&
            typeof instance === 'object' &&
            instance instanceof BookmarkletClass;

    if (isValid) {
      logger.debug('✅ Экземпляр валидный');
    } else {
      logger.debug('❌ Экземпляр невалидный', {
        type: typeof instance,
        isObject: instance && typeof instance === 'object',
        isInstance: instance instanceof BookmarkletClass,
      });
    }

    return isValid;
  } catch (error) {
    logger.error(`❌ Ошибка проверки экземпляра: ${error.message}`);
    return false;
  }
}

/**
 * Получает путь к скрипту с учетом базового пути
 * @param {string} script - Путь к скрипту
 * @param {string} basePath - Базовый путь (по умолчанию './Bookmarklet/')
 * @returns {string} - Полный путь к скрипту
 */
export function getScriptPath(script, basePath = './Bookmarklet/') {
  const logger = createLogger(false, 'Utils');

  if (!script) {
    logger.debug('ℹ️ Скрипт не указан');
    return script;
  }

  // Абсолютные пути
  if (script.startsWith('http') || script.startsWith('/')) {
    logger.debug(`📌 Абсолютный путь: ${script}`);
    return script;
  }

  // Относительные пути с Bookmarklet
  if (script.startsWith('./Bookmarklet/') ||
        script.startsWith('./') ||
        script.startsWith('../')) {
    logger.debug(`📌 Относительный путь: ${script}`);
    return script;
  }

  // Добавляем базовый путь
  const fullPath = basePath + script;
  logger.debug(`📌 Путь с basePath: ${fullPath}`);
  return fullPath;
}

/**
 * Определяет скрипт из props или из окружения
 * @param {Object} props - Свойства с параметрами
 * @param {Object} scriptMap - Карта скриптов по типу
 * @param {string} basePath - Базовый путь
 * @returns {string} - Путь к скрипту
 */
export function detectScript(props, scriptMap = SCRIPT_MAP, basePath = './Bookmarklet/') {
  const logger = createLogger(false, 'Utils');
  logger.debug('🔍 Определение скрипта...');

  // 1. Проверяем props.script
  if (props && props.script && typeof props.script === 'string') {
    logger.debug(`📌 Скрипт найден в props.script: ${props.script}`);
    return getScriptPath(props.script, basePath);
  }

  // 2. Проверяем URL параметры
  const scriptFromUrl = getScriptFromURL();
  if (scriptFromUrl) {
    logger.debug(`📌 Скрипт найден в URL: ${scriptFromUrl}`);
    return getScriptPath(scriptFromUrl, basePath);
  }

  // 3. Проверяем DOM атрибуты
  const scriptFromDom = getScriptFromDOM();
  if (scriptFromDom) {
    logger.debug(`📌 Скрипт найден в DOM: ${scriptFromDom}`);
    return getScriptPath(scriptFromDom, basePath);
  }

  // 4. Проверяем localStorage
  const scriptFromStorage = getScriptFromStorage();
  if (scriptFromStorage) {
    logger.debug(`📌 Скрипт найден в localStorage: ${scriptFromStorage}`);
    return getScriptPath(scriptFromStorage, basePath);
  }

  // 5. Определяем по типу
  const type = props?.type || 'main';
  const defaultScript = scriptMap[type] || scriptMap.main;
  logger.debug(`📌 Скрипт определен по типу "${type}": ${defaultScript}`);
  return getScriptPath(defaultScript, basePath);
}

/**
 * Получает скрипт из URL параметров
 * @returns {string|null} - Путь к скрипту или null
 */
export function getScriptFromURL() {
  const logger = createLogger(false, 'Utils');

  try {
    if (typeof window === 'undefined' || !window.location) {
      return null;
    }

    const params = new URLSearchParams(window.location.search);

    const scriptParam = params.get('script');
    if (scriptParam) {
      logger.debug(`📌 script параметр: ${scriptParam}`);
      return decodeURIComponent(scriptParam);
    }

    const srcParam = params.get('src');
    if (srcParam) {
      logger.debug(`📌 src параметр: ${srcParam}`);
      return decodeURIComponent(srcParam);
    }

    return null;
  } catch (error) {
    logger.error(`❌ Ошибка получения скрипта из URL: ${error.message}`);
    return null;
  }
}

/**
 * Получает скрипт из DOM атрибутов
 * @returns {string|null} - Путь к скрипту или null
 */
export function getScriptFromDOM() {
  const logger = createLogger(false, 'Utils');

  try {
    if (typeof document === 'undefined') {
      return null;
    }

    // Ищем скрипты с data-bookmarklet-script
    const scripts = document.querySelectorAll('script[data-bookmarklet-script]');
    for (const script of scripts) {
      if (script.dataset.bookmarkletScript) {
        logger.debug(`📌 data-bookmarklet-script: ${script.dataset.bookmarkletScript}`);
        return script.dataset.bookmarkletScript;
      }
    }

    // Ищем скрипты с data-bookmarklet-src
    const srcScripts = document.querySelectorAll('script[data-bookmarklet-src]');
    for (const script of srcScripts) {
      if (script.dataset.bookmarkletSrc) {
        logger.debug(`📌 data-bookmarklet-src: ${script.dataset.bookmarkletSrc}`);
        return script.dataset.bookmarkletSrc;
      }
    }

    return null;
  } catch (error) {
    logger.error(`❌ Ошибка получения скрипта из DOM: ${error.message}`);
    return null;
  }
}

/**
 * Получает скрипт из localStorage
 * @param {string} key - Ключ для localStorage
 * @returns {string|null} - Путь к скрипту или null
 */
export function getScriptFromStorage(key = 'bookmarklet-script') {
  const logger = createLogger(false, 'Utils');

  try {
    if (typeof localStorage === 'undefined') {
      return null;
    }

    const saved = localStorage.getItem(key);
    if (saved) {
      logger.debug(`📌 Скрипт из localStorage: ${saved}`);
      return saved;
    }

    return null;
  } catch (error) {
    logger.error(`❌ Ошибка получения скрипта из localStorage: ${error.message}`);
    return null;
  }
}

/**
 * Парсит параметры из URL
 * @param {string} url - URL для парсинга
 * @returns {Object} - Объект с параметрами
 */
export function parseURLParams(url) {
  const logger = createLogger(false, 'Utils');

  try {
    const urlObj = new URL(url || (typeof window !== 'undefined' ? window.location.href : ''));
    const params = {};

    for (const [key, value] of urlObj.searchParams) {
      params[key] = value;
    }

    logger.debug(`📌 Распарсены параметры URL:`, params);
    return params;
  } catch (error) {
    logger.error(`❌ Ошибка парсинга URL: ${error.message}`);
    return {};
  }
}

/**
 * Получает значение из localStorage с проверкой
 * @param {string} key - Ключ
 * @param {*} defaultValue - Значение по умолчанию
 * @returns {*} - Значение из localStorage или default
 */
export function getStorageValue(key, defaultValue = null) {
  const logger = createLogger(false, 'Utils');

  try {
    if (typeof localStorage === 'undefined') {
      return defaultValue;
    }

    const value = localStorage.getItem(key);
    if (value === null) {
      return defaultValue;
    }

    // Пытаемся распарсить JSON
    try {
      return JSON.parse(value);
    } catch {
      return value;
    }
  } catch (error) {
    logger.error(`❌ Ошибка получения из localStorage: ${error.message}`);
    return defaultValue;
  }
}

/**
 * Устанавливает значение в localStorage
 * @param {string} key - Ключ
 * @param {*} value - Значение
 * @returns {boolean} - Успешно ли сохранено
 */
export function setStorageValue(key, value) {
  const logger = createLogger(false, 'Utils');

  try {
    if (typeof localStorage === 'undefined') {
      return false;
    }

    const stringValue = typeof value === 'string' ? value : JSON.stringify(value);
    localStorage.setItem(key, stringValue);

    logger.debug(`📌 Сохранено в localStorage: ${key}`);
    return true;
  } catch (error) {
    logger.error(`❌ Ошибка сохранения в localStorage: ${error.message}`);
    return false;
  }
}

/**
 * Удаляет значение из localStorage
 * @param {string} key - Ключ
 * @returns {boolean} - Успешно ли удалено
 */
export function removeStorageValue(key) {
  const logger = createLogger(false, 'Utils');

  try {
    if (typeof localStorage === 'undefined') {
      return false;
    }

    localStorage.removeItem(key);
    logger.debug(`📌 Удалено из localStorage: ${key}`);
    return true;
  } catch (error) {
    logger.error(`❌ Ошибка удаления из localStorage: ${error.message}`);
    return false;
  }
}

/**
 * Проверяет, доступно ли окружение (window, document, localStorage)
 * @returns {Object} - Объект с флагами доступности
 */
export function checkEnvironment() {
  const env = {
    hasWindow: typeof window !== 'undefined',
    hasDocument: typeof document !== 'undefined',
    hasNavigator: typeof navigator !== 'undefined',
    hasLocalStorage: typeof localStorage !== 'undefined',
    hasSessionStorage: typeof sessionStorage !== 'undefined',
    hasChrome: typeof chrome !== 'undefined',
    hasBroadcastChannel: typeof BroadcastChannel !== 'undefined',
  };

  return env;
}

/**
 * Получает информацию о текущей странице
 * @returns {Object} - Информация о странице
 */
export function getPageInfo() {
  const logger = createLogger(false, 'Utils');

  try {
    const info = {
      url: typeof window !== 'undefined' ? window.location.href : '',
      origin: typeof window !== 'undefined' ? window.location.origin : '',
      pathname: typeof window !== 'undefined' ? window.location.pathname : '',
      search: typeof window !== 'undefined' ? window.location.search : '',
      hash: typeof window !== 'undefined' ? window.location.hash : '',
      title: typeof document !== 'undefined' ? document.title : '',
      referrer: typeof document !== 'undefined' ? document.referrer : '',
      userAgent: typeof navigator !== 'undefined' ? navigator.userAgent : '',
      platform: typeof navigator !== 'undefined' ? navigator.platform : '',
      language: typeof navigator !== 'undefined' ? navigator.language : '',
      timestamp: Date.now(),
    };

    logger.debug('📌 Информация о странице:', info);
    return info;
  } catch (error) {
    logger.error(`❌ Ошибка получения информации о странице: ${error.message}`);
    return {
      url: '',
      title: '',
      timestamp: Date.now(),
      error: error.message,
    };
  }
}

/**
 * Создает уникальный ID
 * @param {string} prefix - Префикс для ID
 * @returns {string} - Уникальный ID
 */
export function generateId(prefix = 'id') {
  const timestamp = Date.now().toString(36);
  const random = Math.random().toString(36).substr(2, 6);
  const hash = Math.random().toString(36).substr(2, 4);
  return `${prefix}-${timestamp}-${random}-${hash}`;
}

/**
 * Клонирует объект с защитой от циклических ссылок
 * @param {*} obj - Объект для клонирования
 * @returns {*} - Клон объекта
 */
export function safeClone(obj) {
  const logger = createLogger(false, 'Utils');

  try {
    return JSON.parse(JSON.stringify(obj));
  } catch (error) {
    logger.error(`❌ Ошибка клонирования: ${error.message}`);
    return obj;
  }
}

/**
 * Объединяет объекты с защитой от мутации
 * @param {Object} target - Целевой объект
 * @param {Object} source - Исходный объект
 * @returns {Object} - Новый объединенный объект
 */
export function safeMerge(target, source) {
  return { ...target, ...source };
}

/**
 * Проверяет, является ли значение функцией
 * @param {*} value - Проверяемое значение
 * @returns {boolean} - true если функция
 */
export function isFunction(value) {
  return typeof value === 'function';
}

/**
 * Проверяет, является ли значение объектом
 * @param {*} value - Проверяемое значение
 * @returns {boolean} - true если объект
 */
export function isObject(value) {
  return value && typeof value === 'object' && !Array.isArray(value);
}

/**
 * Проверяет, является ли значение строкой
 * @param {*} value - Проверяемое значение
 * @returns {boolean} - true если строка
 */
export function isString(value) {
  return typeof value === 'string';
}

/**
 * Проверяет, является ли значение числом
 * @param {*} value - Проверяемое значение
 * @returns {boolean} - true если число
 */
export function isNumber(value) {
  return typeof value === 'number' && !isNaN(value);
}

/**
 * Проверяет, является ли значение boolean
 * @param {*} value - Проверяемое значение
 * @returns {boolean} - true если boolean
 */
export function isBoolean(value) {
  return typeof value === 'boolean';
}

/**
 * Проверяет, является ли значение undefined или null
 * @param {*} value - Проверяемое значение
 * @returns {boolean} - true если undefined или null
 */
export function isNil(value) {
  return value === null || value === undefined;
}

// ============================================================
// 7. КЕШИРОВАНИЕ
// ============================================================

const cache = new Map();
const cacheTimestamps = new Map();

/**
 * Сохраняет значение в кеш
 * @param {string} key - Ключ
 * @param {*} value - Значение
 * @param {number} ttl - Время жизни в мс (по умолчанию 30000)
 */
export function setCache(key, value, ttl = 30000) {
  const logger = createLogger(false, 'Utils');

  try {
    // Очищаем старые записи если кеш переполнен
    if (cache.size >= 100) {
      const oldestKey = cacheTimestamps.keys().next().value;
      if (oldestKey) {
        cache.delete(oldestKey);
        cacheTimestamps.delete(oldestKey);
      }
    }

    cache.set(key, value);
    cacheTimestamps.set(key, Date.now() + ttl);

    logger.debug(`📌 Кеш сохранен: ${key}`);
  } catch (error) {
    logger.error(`❌ Ошибка сохранения в кеш: ${error.message}`);
  }
}

/**
 * Получает значение из кеша
 * @param {string} key - Ключ
 * @returns {*} - Значение или null если просрочено
 */
export function getCache(key) {
  const logger = createLogger(false, 'Utils');

  try {
    if (!cache.has(key)) {
      return null;
    }

    const expires = cacheTimestamps.get(key);
    if (Date.now() > expires) {
      cache.delete(key);
      cacheTimestamps.delete(key);
      logger.debug(`📌 Кеш просрочен: ${key}`);
      return null;
    }

    const value = cache.get(key);
    logger.debug(`📌 Кеш получен: ${key}`);
    return value;
  } catch (error) {
    logger.error(`❌ Ошибка получения из кеша: ${error.message}`);
    return null;
  }
}

/**
 * Очищает кеш
 * @param {string} key - Ключ для удаления (если не указан - очищает все)
 */
export function clearCache(key = null) {
  const logger = createLogger(false, 'Utils');

  try {
    if (key) {
      cache.delete(key);
      cacheTimestamps.delete(key);
      logger.debug(`📌 Кеш удален: ${key}`);
    } else {
      cache.clear();
      cacheTimestamps.clear();
      logger.debug('📌 Кеш полностью очищен');
    }
  } catch (error) {
    logger.error(`❌ Ошибка очистки кеша: ${error.message}`);
  }
}

/**
 * Получает статистику кеша
 * @returns {Object} - Статистика кеша
 */
export function getCacheStats() {
  const size = cache.size;
  const entries = Array.from(cache.entries()).map(([key, value]) => ({
    key,
    size: JSON.stringify(value).length,
    expires: new Date(cacheTimestamps.get(key)).toISOString(),
  }));

  return {
    size,
    entries,
    maxSize: 100,
  };
}

// ============================================================
// 8. ЭКСПОРТ ПО УМОЛЧАНИЮ
// ============================================================

export default {
  // Проверки
  isBookmarkletInstance,
  isFunction,
  isObject,
  isString,
  isNumber,
  isBoolean,
  isNil,

  // Скрипты
  getScriptPath,
  detectScript,
  getScriptFromURL,
  getScriptFromDOM,
  getScriptFromStorage,

  // Парсинг
  parseURLParams,

  // Storage
  getStorageValue,
  setStorageValue,
  removeStorageValue,

  // Окружение
  checkEnvironment,
  getPageInfo,

  // Утилиты
  generateId,
  safeClone,
  safeMerge,

  // Кеш
  setCache,
  getCache,
  clearCache,
  getCacheStats,

  // Константы
  SCRIPT_MAP,
  DEFAULT_CONFIG,
  PRIVATE,
  PUBLIC,
};

// ============================================================
// 9. ГЛОБАЛЬНАЯ РЕГИСТРАЦИЯ
// ============================================================

if (typeof window !== 'undefined') {
  window.__utils = {
    isBookmarkletInstance,
    getScriptPath,
    detectScript,
    getScriptFromURL,
    getScriptFromDOM,
    getScriptFromStorage,
    parseURLParams,
    getStorageValue,
    setStorageValue,
    removeStorageValue,
    checkEnvironment,
    getPageInfo,
    generateId,
    safeClone,
    safeMerge,
    setCache,
    getCache,
    clearCache,
    getCacheStats,
    SCRIPT_MAP,
    DEFAULT_CONFIG,
    PRIVATE,
    PUBLIC,
  };

  window[PUBLIC.UTILS] = window.__utils;
  window[PUBLIC.HELPERS] = {
    isFunction,
    isObject,
    isString,
    isNumber,
    isBoolean,
    isNil,
  };

  console.log('📦 core/utils.js загружен (100% СИМВОЛЫ)');
  console.log(`🔑 ПРИВАТНЫХ СИМВОЛОВ: ${Object.keys(PRIVATE).length}`);
  console.log(`🔑 ПУБЛИЧНЫХ СИМВОЛОВ: ${Object.keys(PUBLIC).length}`);
  console.log('📋 Доступные команды:');
  console.log('  __utils.isBookmarkletInstance(instance, Class) - проверка экземпляра');
  console.log('  __utils.getScriptPath(script) - получить путь к скрипту');
  console.log('  __utils.detectScript(props) - определить скрипт');
  console.log('  __utils.getCache(key) - получить из кеша');
  console.log('  __utils.setCache(key, value) - сохранить в кеш');
  console.log('  __utils.clearCache() - очистить кеш');
  console.log('  __utils.getPageInfo() - информация о странице');
  console.log('  __utils.checkEnvironment() - проверка окружения');
  console.log('  __utils.generateId() - сгенерировать ID');
  console.log('  __utils.SCRIPT_MAP - карта скриптов');
  console.log('  __utils.DEFAULT_CONFIG - конфигурация по умолчанию');
}

// ============================================================
// 10. КОМАНДЫ ДЛЯ ОТЛАДКИ
// ============================================================

if (typeof window !== 'undefined') {
  window.__utilsDebug = {
    getCache,
    setCache,
    clearCache,
    getCacheStats,
    getScriptFromURL,
    getScriptFromDOM,
    getScriptFromStorage,
    checkEnvironment,
    getPageInfo,
    generateId,
    isBookmarkletInstance,
    getScriptPath,
    detectScript,
    parseURLParams,
    getStorageValue,
    setStorageValue,
    removeStorageValue,
    safeClone,
    safeMerge,
    isFunction,
    isObject,
    isString,
    isNumber,
    isBoolean,
    isNil,
    SCRIPT_MAP,
    DEFAULT_CONFIG,
    PRIVATE,
    PUBLIC,
  };

  console.log('📋 КОМАНДЫ ОТЛАДКИ (__utilsDebug):');
  console.log('  __utilsDebug.getCache(key) - получить из кеша');
  console.log('  __utilsDebug.setCache(key, value) - сохранить в кеш');
  console.log('  __utilsDebug.clearCache() - очистить кеш');
  console.log('  __utilsDebug.getCacheStats() - статистика кеша');
  console.log('  __utilsDebug.getScriptFromURL() - скрипт из URL');
  console.log('  __utilsDebug.getScriptFromDOM() - скрипт из DOM');
  console.log('  __utilsDebug.getScriptFromStorage() - скрипт из localStorage');
  console.log('  __utilsDebug.checkEnvironment() - проверка окружения');
  console.log('  __utilsDebug.getPageInfo() - информация о странице');
  console.log('  __utilsDebug.generateId() - сгенерировать ID');
  console.log('  __utilsDebug.isBookmarkletInstance(inst, Class) - проверка экземпляра');
  console.log('  __utilsDebug.getScriptPath(script) - получить путь к скрипту');
  console.log('  __utilsDebug.detectScript(props) - определить скрипт');
}
