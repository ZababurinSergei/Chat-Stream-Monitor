// web/Bookmarklet/core/global-registry.js - Глобальная регистрация символов и API
// Версия: 1.0.5
// ИСПРАВЛЕНО: Ошибка "Неизвестное действие: undefined"
// ИСПРАВЛЕНО: Ошибка "logger.header is not a function"
// ИСПРАВЛЕНО: Автоматический вызов API при инициализации
// ДОБАВЛЕНО: Группировка логов через console.group()
// ДОБАВЛЕНО: console.trace() для отладки
// ДОБАВЛЕНО: Полная валидация всех входящих параметров
// ДОБАВЛЕНО: Фабрика API с проверкой аргументов

// ============================================================
// 1. ИМПОРТЫ СИМВОЛОВ
// ============================================================

import { PRIVATE, PUBLIC } from './symbols.js';
import { createLogger } from './logger.js';

// ============================================================
// 2. СИМВОЛЫ ГЛОБАЛЬНОГО РЕГИСТРА
// ============================================================

// Приватные символы для внутреннего использования
const GLOBAL_SYMBOLS = {
  // Основные символы
  REGISTRY: Symbol('global-registry.registry'),
  INSTANCES: Symbol('global-registry.instances'),
  LISTENERS: Symbol('global-registry.listeners'),
  HANDLERS: Symbol('global-registry.handlers'),
  CACHE: Symbol('global-registry.cache'),
  METADATA: Symbol('global-registry.metadata'),
  LOGGER: Symbol('global-registry.logger'),
  VERSION: Symbol('global-registry.version'),
  BUILD: Symbol('global-registry.build'),
  INITIALIZED: Symbol('global-registry.initialized'),
  IS_DESTROYED: Symbol('global-registry.isDestroyed'),

  // Методы регистрации
  REGISTER: Symbol('global-registry.register'),
  UNREGISTER: Symbol('global-registry.unregister'),
  GET: Symbol('global-registry.get'),
  SET: Symbol('global-registry.set'),
  HAS: Symbol('global-registry.has'),
  DELETE: Symbol('global-registry.delete'),
  CLEAR: Symbol('global-registry.clear'),
  GET_STATE: Symbol('global-registry.getState'),
  GET_STATS: Symbol('global-registry.getStats'),
  RESET: Symbol('global-registry.reset'),
  DESTROY: Symbol('global-registry.destroy'),

  // Глобальные функции
  REGISTER_GLOBALS: Symbol('global-registry.registerGlobals'),
  HANDLE_AUTO_START: Symbol('global-registry.handleAutoStart'),
  PRINT_BANNER: Symbol('global-registry.printBanner'),
  EXPORT_SYMBOLS: Symbol('global-registry.exportSymbols'),
  IMPORT_SYMBOLS: Symbol('global-registry.importSymbols'),
  SYNC_SYMBOLS: Symbol('global-registry.syncSymbols'),

  // События
  ON: Symbol('global-registry.on'),
  OFF: Symbol('global-registry.off'),
  EMIT: Symbol('global-registry.emit'),

  // ★★★ НОВЫЕ СИМВОЛЫ ДЛЯ ВАЛИДАЦИИ ★★★
  VALIDATE_ACTION: Symbol('global-registry.validateAction'),
  VALIDATE_CALLBACK: Symbol('global-registry.validateCallback'),
  VALIDATE_ID: Symbol('global-registry.validateId'),
  VALIDATE_INSTANCE: Symbol('global-registry.validateInstance'),

  // ★★★ НОВЫЙ СИМВОЛ ДЛЯ API ★★★
  API: Symbol('global-registry.api'),
  API_WRAPPER: Symbol('global-registry.apiWrapper'),

  // ★★★ НОВЫЕ СИМВОЛЫ ДЛЯ ГРУППИРОВКИ ★★★
  LOG_GROUP: Symbol('global-registry.logGroup'),
  LOG_GROUP_END: Symbol('global-registry.logGroupEnd'),
  LOG_TRACE: Symbol('global-registry.logTrace'),
};

// ============================================================
// 3. ПУБЛИЧНЫЕ СИМВОЛЫ (доступны через Symbol.for)
// ============================================================

const PUBLIC_GLOBAL = {
  REGISTRY: Symbol.for('global-registry.registry'),
  INSTANCES: Symbol.for('global-registry.instances'),
  STATE: Symbol.for('global-registry.state'),
  CONFIG: Symbol.for('global-registry.config'),
  LOGGER: Symbol.for('global-registry.logger'),
  API: Symbol.for('global-registry.api'),
  EVENTS: Symbol.for('global-registry.events'),
  VERSION: Symbol.for('global-registry.version'),
};

// ============================================================
// 4. ★★★ ВСПОМОГАТЕЛЬНАЯ ФУНКЦИЯ ДЛЯ ЛОГГЕРА ★★★
// ============================================================

function createBannerLogger(debug = true, instanceId = 'Banner') {
  const logger = createLogger(debug, instanceId);

  // ★★★ ДОБАВЛЯЕМ МЕТОДЫ, КОТОРЫХ НЕТ В БАЗОВОМ ЛОГГЕРЕ ★★★
  logger.header = function(title) {
    console.log('%c' + '═'.repeat(70), 'color: #636e72;');
    console.log(
      '%c  📦 ' + title,
      'background: #1a1a2e; color: #fff; padding: 4px 12px; border-radius: 4px; font-weight: bold;',
    );
    console.log('%c' + '═'.repeat(70), 'color: #636e72;');
  };

  logger.separator = function() {
    console.log('%c' + '─'.repeat(70), 'color: #636e72;');
  };

  // ★★★ НОВЫЕ МЕТОДЫ ДЛЯ ГРУППИРОВКИ ★★★
  logger.group = function(title, collapsed = true) {
    if (collapsed) {
      console.groupCollapsed(`%c📂 ${title}`, 'color: #667eea; font-weight: bold;');
    } else {
      console.group(`%c📂 ${title}`, 'color: #667eea; font-weight: bold;');
    }
    return logger;
  };

  logger.groupEnd = function() {
    console.groupEnd();
    return logger;
  };

  logger.trace = function(message, data = null) {
    console.log(`%c🔍 ${message}`, 'color: #fdcb6e; font-weight: bold;', data || '');
    console.trace('📍 Stack trace:');
    return logger;
  };

  logger.logWithGroup = function(title, message, data = null, collapsed = true) {
    logger.group(title, collapsed);
    if (data !== null && data !== undefined) {
      console.log(`  ${message}`, data);
    } else {
      console.log(`  ${message}`);
    }
    logger.trace(`  📍 Вызов: ${title}`);
    logger.groupEnd();
    return logger;
  };

  return logger;
}

// ============================================================
// 5. ГЛОБАЛЬНЫЙ РЕГИСТР (КЛАСС С СИМВОЛАМИ)
// ============================================================

class GlobalRegistry {
  // Статические символы
  static [GLOBAL_SYMBOLS.INSTANCES] = new Map();
  static [GLOBAL_SYMBOLS.REGISTRY] = new Map();
  static [GLOBAL_SYMBOLS.LISTENERS] = new Map();
  static [GLOBAL_SYMBOLS.HANDLERS] = new Map();
  static [GLOBAL_SYMBOLS.CACHE] = new Map();
  static [GLOBAL_SYMBOLS.METADATA] = {
    created: Date.now(),
    lastUpdate: Date.now(),
    totalRegistrations: 0,
    totalUnregistrations: 0,
    apiCalls: 0,
    apiErrors: 0,
  };
  static [GLOBAL_SYMBOLS.LOGGER] = createLogger(true, 'GlobalRegistry');
  static [GLOBAL_SYMBOLS.VERSION] = '1.0.5';
  static [GLOBAL_SYMBOLS.BUILD] = '2026-07-21';
  static [GLOBAL_SYMBOLS.INITIALIZED] = false;
  static [GLOBAL_SYMBOLS.IS_DESTROYED] = false;

  // ============================================================
  // 5.1 ★★★ ИНИЦИАЛИЗАЦИЯ (ИСПРАВЛЕННАЯ) ★★★
  // ============================================================

  static [GLOBAL_SYMBOLS.INITIALIZE]() {
    if (this[GLOBAL_SYMBOLS.INITIALIZED]) {return;}

    const logger = this[GLOBAL_SYMBOLS.LOGGER];

    // ★★★ ГРУППА: ИНИЦИАЛИЗАЦИЯ ★★★
    console.groupCollapsed('%c📦 ИНИЦИАЛИЗАЦИЯ ГЛОБАЛЬНОГО РЕГИСТРА', 'color: #667eea; font-weight: bold;');
    console.log('%c📌 Версия: ' + this[GLOBAL_SYMBOLS.VERSION], 'color: #74b9ff;');
    console.log('%c📌 Сборка: ' + this[GLOBAL_SYMBOLS.BUILD], 'color: #74b9ff;');
    console.trace('📍 Stack trace инициализации:');
    console.groupEnd();

    logger.info('📦 Инициализация глобального регистра (100% СИМВОЛЫ)');
    logger.info(`📌 Версия: ${this[GLOBAL_SYMBOLS.VERSION]}`);
    logger.info(`📌 Сборка: ${this[GLOBAL_SYMBOLS.BUILD]}`);

    if (typeof window !== 'undefined') {
      // ★★★ БЕЗОПАСНЫЕ ЭКСПОРТЫ (без автоматических вызовов) ★★★
      window[PUBLIC_GLOBAL.REGISTRY] = this;
      window[PUBLIC_GLOBAL.INSTANCES] = this[GLOBAL_SYMBOLS.INSTANCES];
      window[PUBLIC_GLOBAL.STATE] = this[GLOBAL_SYMBOLS.GET_STATE].bind(this);
      window[PUBLIC_GLOBAL.CONFIG] = this[GLOBAL_SYMBOLS.GET_CONFIG].bind(this);
      window[PUBLIC_GLOBAL.LOGGER] = this[GLOBAL_SYMBOLS.LOGGER];
      window[PUBLIC_GLOBAL.EVENTS] = {
        on: this[GLOBAL_SYMBOLS.ON].bind(this),
        off: this[GLOBAL_SYMBOLS.OFF].bind(this),
        emit: this[GLOBAL_SYMBOLS.EMIT].bind(this),
      };
      window[PUBLIC_GLOBAL.VERSION] = this[GLOBAL_SYMBOLS.VERSION];

      // ★★★ ★★★ ИСПРАВЛЕНО: API через фабрику с проверкой аргументов ★★★ ★★★
      Object.defineProperty(window, PUBLIC_GLOBAL.API, {
        get: () =>
          // Возвращаем функцию-обёртку с проверкой аргументов
          (action, ...args) => {
            // ★★★ ГРУППА: API ВЫЗОВ ★★★
            console.groupCollapsed(`%c🔧 API ВЫЗОВ: ${action || '(empty)'}`, 'color: #fdcb6e; font-weight: bold;');
            console.log(`%c📌 Аргументы:`, 'color: #74b9ff;', args);
            console.trace('📍 Stack trace вызова API:');

            // ★★★ ПРОВЕРКА: action === undefined/null ★★★
            if (action === undefined || action === null) {
              const logger = this[GLOBAL_SYMBOLS.LOGGER];
              logger.warn('⚠️ API вызван без указания действия');
              console.log('%c❌ Ошибка: Действие не указано', 'color: #ff6b6b;');
              console.groupEnd();
              return {
                success: false,
                error: 'Действие не указано',
                action: null,
                code: 'ACTION_EMPTY',
              };
            }

            // ★★★ ПРОВЕРКА: action не строка ★★★
            if (typeof action !== 'string') {
              const logger = this[GLOBAL_SYMBOLS.LOGGER];
              logger.warn(`⚠️ API вызван с нестроковым действием: ${typeof action}`);
              console.log(`%c❌ Ошибка: Действие должно быть строкой, получено: ${typeof action}`, 'color: #ff6b6b;');
              console.groupEnd();
              return {
                success: false,
                error: `Действие должно быть строкой, получено: ${typeof action}`,
                action: String(action),
                code: 'ACTION_NOT_STRING',
              };
            }

            // ★★★ ПРОВЕРКА: action пустая строка ★★★
            if (action.trim() === '') {
              const logger = this[GLOBAL_SYMBOLS.LOGGER];
              logger.warn('⚠️ API вызван с пустым действием');
              console.log('%c❌ Ошибка: Действие не может быть пустой строкой', 'color: #ff6b6b;');
              console.groupEnd();
              return {
                success: false,
                error: 'Действие не может быть пустой строкой',
                action,
                code: 'ACTION_EMPTY_STRING',
              };
            }

            // ★★★ ВЫЗЫВАЕМ РЕАЛЬНЫЙ МЕТОД ★★★
            const result = this[GLOBAL_SYMBOLS.API](action, ...args);
            console.log(`%c✅ Результат:`, 'color: #00b894;', result);
            console.groupEnd();
            return result;
          }
        ,
        configurable: true,
        enumerable: true,
      });

      // ★★★ ГЛОБАЛЬНЫЕ КОМАНДЫ (с защитой) ★★★
      window.__globalRegistry = this;
      window.__globalRegistryCommands = {
        getState: () => {
          console.groupCollapsed('%c📊 getState', 'color: #74b9ff; font-weight: bold;');
          console.trace('📍 Stack trace getState:');
          const result = this[GLOBAL_SYMBOLS.GET_STATE]();
          console.log('%c✅ Результат:', 'color: #00b894;', result);
          console.groupEnd();
          return result;
        },
        getStats: () => {
          console.groupCollapsed('%c📊 getStats', 'color: #74b9ff; font-weight: bold;');
          console.trace('📍 Stack trace getStats:');
          const result = this[GLOBAL_SYMBOLS.GET_STATS]();
          console.log('%c✅ Результат:', 'color: #00b894;', result);
          console.groupEnd();
          return result;
        },
        register: (id, instance, metadata) => {
          console.groupCollapsed(`%c📝 register: ${id}`, 'color: #fdcb6e; font-weight: bold;');
          console.log(`%c📌 ID: ${id}`, 'color: #74b9ff;');
          console.log(`%c📌 Instance:`, 'color: #74b9ff;', instance);
          console.log(`%c📌 Metadata:`, 'color: #74b9ff;', metadata);
          console.trace('📍 Stack trace register:');
          const result = this[GLOBAL_SYMBOLS.REGISTER](id, instance, metadata);
          console.log(`%c✅ Результат:`, 'color: #00b894;', result);
          console.groupEnd();
          return result;
        },
        unregister: id => {
          console.groupCollapsed(`%c🗑️ unregister: ${id}`, 'color: #ff6b6b; font-weight: bold;');
          console.log(`%c📌 ID: ${id}`, 'color: #74b9ff;');
          console.trace('📍 Stack trace unregister:');
          const result = this[GLOBAL_SYMBOLS.UNREGISTER](id);
          console.log(`%c✅ Результат:`, 'color: #00b894;', result);
          console.groupEnd();
          return result;
        },
        get: id => {
          console.groupCollapsed(`%c🔍 get: ${id}`, 'color: #74b9ff; font-weight: bold;');
          console.log(`%c📌 ID: ${id}`, 'color: #74b9ff;');
          console.trace('📍 Stack trace get:');
          const result = this[GLOBAL_SYMBOLS.GET](id);
          console.log(`%c✅ Результат:`, 'color: #00b894;', result);
          console.groupEnd();
          return result;
        },
        has: id => {
          console.groupCollapsed(`%c❓ has: ${id}`, 'color: #74b9ff; font-weight: bold;');
          console.log(`%c📌 ID: ${id}`, 'color: #74b9ff;');
          console.trace('📍 Stack trace has:');
          const result = this[GLOBAL_SYMBOLS.HAS](id);
          console.log(`%c✅ Результат: ${result}`, 'color: #00b894;');
          console.groupEnd();
          return result;
        },
        set: (key, value) => {
          console.groupCollapsed(`%c✏️ set: ${key}`, 'color: #fdcb6e; font-weight: bold;');
          console.log(`%c📌 Key: ${key}`, 'color: #74b9ff;');
          console.log(`%c📌 Value:`, 'color: #74b9ff;', value);
          console.trace('📍 Stack trace set:');
          const result = this[GLOBAL_SYMBOLS.SET](key, value);
          console.log(`%c✅ Результат:`, 'color: #00b894;', result);
          console.groupEnd();
          return result;
        },
        delete: key => {
          console.groupCollapsed(`%c🗑️ delete: ${key}`, 'color: #ff6b6b; font-weight: bold;');
          console.log(`%c📌 Key: ${key}`, 'color: #74b9ff;');
          console.trace('📍 Stack trace delete:');
          const result = this[GLOBAL_SYMBOLS.DELETE](key);
          console.log(`%c✅ Результат: ${result}`, 'color: #00b894;');
          console.groupEnd();
          return result;
        },
        clear: () => {
          console.groupCollapsed('%c🧹 clear', 'color: #ff6b6b; font-weight: bold;');
          console.trace('📍 Stack trace clear:');
          const result = this[GLOBAL_SYMBOLS.CLEAR]();
          console.log(`%c✅ Результат: ${result}`, 'color: #00b894;');
          console.groupEnd();
          return result;
        },
        reset: () => {
          console.groupCollapsed('%c🔄 reset', 'color: #ff6b6b; font-weight: bold;');
          console.trace('📍 Stack trace reset:');
          const result = this[GLOBAL_SYMBOLS.RESET]();
          console.log(`%c✅ Результат:`, 'color: #00b894;', result);
          console.groupEnd();
          return result;
        },
        destroy: () => {
          console.groupCollapsed('%c💥 destroy', 'color: #ff6b6b; font-weight: bold;');
          console.trace('📍 Stack trace destroy:');
          const result = this[GLOBAL_SYMBOLS.DESTROY]();
          console.log(`%c✅ Результат:`, 'color: #00b894;', result);
          console.groupEnd();
          return result;
        },
        on: (event, callback) => {
          console.groupCollapsed(`%c👂 on: ${event}`, 'color: #74b9ff; font-weight: bold;');
          console.log(`%c📌 Event: ${event}`, 'color: #74b9ff;');
          console.log(`%c📌 Callback:`, 'color: #74b9ff;', callback);
          console.trace('📍 Stack trace on:');
          const result = this[GLOBAL_SYMBOLS.ON](event, callback);
          console.log(`%c✅ Результат:`, 'color: #00b894;', result);
          console.groupEnd();
          return result;
        },
        off: (event, callback) => {
          console.groupCollapsed(`%c👂 off: ${event}`, 'color: #74b9ff; font-weight: bold;');
          console.log(`%c📌 Event: ${event}`, 'color: #74b9ff;');
          console.log(`%c📌 Callback:`, 'color: #74b9ff;', callback);
          console.trace('📍 Stack trace off:');
          const result = this[GLOBAL_SYMBOLS.OFF](event, callback);
          console.log(`%c✅ Результат:`, 'color: #00b894;', result);
          console.groupEnd();
          return result;
        },
        emit: (event, data) => {
          console.groupCollapsed(`%c📤 emit: ${event}`, 'color: #fdcb6e; font-weight: bold;');
          console.log(`%c📌 Event: ${event}`, 'color: #74b9ff;');
          console.log(`%c📌 Data:`, 'color: #74b9ff;', data);
          console.trace('📍 Stack trace emit:');
          const result = this[GLOBAL_SYMBOLS.EMIT](event, data);
          console.log(`%c✅ Результат:`, 'color: #00b894;', result);
          console.groupEnd();
          return result;
        },
        // ★★★ API с защитой от undefined ★★★
        api: (action, ...args) => {
          // ★★★ ГРУППА: API ЧЕРЕЗ КОМАНДЫ ★★★
          console.groupCollapsed(`%c🔧 api: ${action || '(empty)'}`, 'color: #fdcb6e; font-weight: bold;');
          console.log(`%c📌 Action: ${action}`, 'color: #74b9ff;');
          console.log(`%c📌 Аргументы:`, 'color: #74b9ff;', args);
          console.trace('📍 Stack trace api:');

          if (action === undefined || action === null) {
            console.warn('⚠️ API вызван без указания действия');
            console.log('%c❌ Ошибка: Действие не указано', 'color: #ff6b6b;');
            console.groupEnd();
            return {
              success: false,
              error: 'Действие не указано',
              action: null,
              code: 'ACTION_EMPTY',
            };
          }
          if (typeof action !== 'string') {
            console.warn(`⚠️ API вызван с нестроковым действием: ${typeof action}`);
            console.log(`%c❌ Ошибка: Действие должно быть строкой, получено: ${typeof action}`, 'color: #ff6b6b;');
            console.groupEnd();
            return {
              success: false,
              error: `Действие должно быть строкой, получено: ${typeof action}`,
              action: String(action),
              code: 'ACTION_NOT_STRING',
            };
          }
          if (action.trim() === '') {
            console.warn('⚠️ API вызван с пустым действием');
            console.log('%c❌ Ошибка: Действие не может быть пустой строкой', 'color: #ff6b6b;');
            console.groupEnd();
            return {
              success: false,
              error: 'Действие не может быть пустой строкой',
              action,
              code: 'ACTION_EMPTY_STRING',
            };
          }
          const result = this[GLOBAL_SYMBOLS.API](action, ...args);
          console.log(`%c✅ Результат:`, 'color: #00b894;', result);
          console.groupEnd();
          return result;
        },
        getSymbols: () => {
          console.groupCollapsed('%c🔑 getSymbols', 'color: #a29bfe; font-weight: bold;');
          console.trace('📍 Stack trace getSymbols:');
          const result = {
            GLOBAL_SYMBOLS: { ...GLOBAL_SYMBOLS },
            PUBLIC_GLOBAL: { ...PUBLIC_GLOBAL },
            PRIVATE: { ...PRIVATE },
            PUBLIC: { ...PUBLIC },
          };
          console.log('%c✅ Результат:', 'color: #00b894;', Object.keys(result));
          console.groupEnd();
          return result;
        },
      };
    }

    this[GLOBAL_SYMBOLS.INITIALIZED] = true;
    logger.success('✅ Глобальный регистр инициализирован');
  }

  // ============================================================
  // 5.2 ★★★ ВАЛИДАТОРЫ (НОВЫЕ СИМВОЛЫ) ★★★
  // ============================================================

  static [GLOBAL_SYMBOLS.VALIDATE_ACTION](action) {
    // ★★★ ПРОВЕРКА: если action === undefined или null ★★★
    if (action === undefined || action === null) {
      return { valid: false, error: 'Действие не указано (undefined/null)' };
    }

    // ★★★ ПРОВЕРКА: если action не строка ★★★
    if (typeof action !== 'string') {
      return { valid: false, error: `Действие должно быть строкой, получено: ${typeof action}` };
    }

    // ★★★ ПРОВЕРКА: если action пустая строка ★★★
    if (action.trim() === '') {
      return { valid: false, error: 'Действие не может быть пустой строкой' };
    }

    return { valid: true, error: null };
  }

  static [GLOBAL_SYMBOLS.VALIDATE_CALLBACK](callback) {
    if (callback === undefined || callback === null) {
      return { valid: false, error: 'Callback не указан' };
    }

    if (typeof callback !== 'function') {
      return { valid: false, error: `Callback должен быть функцией, получено: ${typeof callback}` };
    }

    return { valid: true, error: null };
  }

  static [GLOBAL_SYMBOLS.VALIDATE_ID](id) {
    if (id === undefined || id === null) {
      return { valid: false, error: 'ID не указан' };
    }

    if (typeof id !== 'string') {
      return { valid: false, error: `ID должен быть строкой, получено: ${typeof id}` };
    }

    if (id.trim() === '') {
      return { valid: false, error: 'ID не может быть пустой строкой' };
    }

    return { valid: true, error: null };
  }

  static [GLOBAL_SYMBOLS.VALIDATE_INSTANCE](instance) {
    if (instance === undefined || instance === null) {
      return { valid: false, error: 'Экземпляр не указан' };
    }

    if (typeof instance !== 'object') {
      return { valid: false, error: `Экземпляр должен быть объектом, получено: ${typeof instance}` };
    }

    return { valid: true, error: null };
  }

  // ============================================================
  // 5.3 ★★★ РЕГИСТРАЦИЯ ЭКЗЕМПЛЯРА ★★★
  // ============================================================

  static [GLOBAL_SYMBOLS.REGISTER](id, instance, metadata = {}) {
    // ★★★ ГРУППА: РЕГИСТРАЦИЯ ★★★
    console.groupCollapsed(`%c📝 РЕГИСТРАЦИЯ: ${id}`, 'color: #fdcb6e; font-weight: bold;');
    console.log(`%c📌 ID: ${id}`, 'color: #74b9ff;');
    console.log(`%c📌 Instance:`, 'color: #74b9ff;', instance);
    console.log(`%c📌 Metadata:`, 'color: #74b9ff;', metadata);
    console.trace('📍 Stack trace регистрации:');

    const logger = this[GLOBAL_SYMBOLS.LOGGER];
    const instances = this[GLOBAL_SYMBOLS.INSTANCES];
    const registry = this[GLOBAL_SYMBOLS.REGISTRY];

    // ★★★ ВАЛИДАЦИЯ ★★★
    const idValidation = this[GLOBAL_SYMBOLS.VALIDATE_ID](id);
    if (!idValidation.valid) {
      logger.error(`❌ ${idValidation.error}`);
      console.log(`%c❌ Ошибка: ${idValidation.error}`, 'color: #ff6b6b;');
      console.groupEnd();
      return null;
    }

    const instanceValidation = this[GLOBAL_SYMBOLS.VALIDATE_INSTANCE](instance);
    if (!instanceValidation.valid) {
      logger.error(`❌ ${instanceValidation.error}`);
      console.log(`%c❌ Ошибка: ${instanceValidation.error}`, 'color: #ff6b6b;');
      console.groupEnd();
      return null;
    }

    if (instances.has(id)) {
      logger.warn(`⚠️ Экземпляр ${id} уже зарегистрирован, обновляем`);
      console.log(`%c⚠️ Экземпляр уже зарегистрирован, обновляем`, 'color: #fdcb6e;');
      this[GLOBAL_SYMBOLS.UNREGISTER](id);
    }

    instances.set(id, instance);
    registry.set(id, {
      id,
      instance,
      metadata: {
        ...metadata,
        registeredAt: Date.now(),
        lastAccess: Date.now(),
      },
      type: metadata.type || 'unknown',
      name: metadata.name || 'Unnamed',
      version: metadata.version || '1.0.0',
      status: 'active',
    });

    const meta = this[GLOBAL_SYMBOLS.METADATA];
    meta.totalRegistrations++;
    meta.lastUpdate = Date.now();

    this[GLOBAL_SYMBOLS.EMIT]('register', { id, instance, metadata });

    logger.success(`✅ Экземпляр ${id} зарегистрирован`);
    logger.info(`📊 Всего экземпляров: ${instances.size}`);

    this[GLOBAL_SYMBOLS.CACHE].set(`instance:${id}`, {
      instance,
      metadata,
      timestamp: Date.now(),
    });

    console.log(`%c✅ Экземпляр ${id} зарегистрирован`, 'color: #00b894;');
    console.log(`%c📊 Всего экземпляров: ${instances.size}`, 'color: #74b9ff;');
    console.groupEnd();

    return instance;
  }

  // ============================================================
  // 5.4 ★★★ ОТМЕНА РЕГИСТРАЦИИ ★★★
  // ============================================================

  static [GLOBAL_SYMBOLS.UNREGISTER](id) {
    // ★★★ ГРУППА: ОТМЕНА РЕГИСТРАЦИИ ★★★
    console.groupCollapsed(`%c🗑️ ОТМЕНА РЕГИСТРАЦИИ: ${id}`, 'color: #ff6b6b; font-weight: bold;');
    console.log(`%c📌 ID: ${id}`, 'color: #74b9ff;');
    console.trace('📍 Stack trace отмены регистрации:');

    const logger = this[GLOBAL_SYMBOLS.LOGGER];
    const instances = this[GLOBAL_SYMBOLS.INSTANCES];
    const registry = this[GLOBAL_SYMBOLS.REGISTRY];

    const idValidation = this[GLOBAL_SYMBOLS.VALIDATE_ID](id);
    if (!idValidation.valid) {
      logger.error(`❌ ${idValidation.error}`);
      console.log(`%c❌ Ошибка: ${idValidation.error}`, 'color: #ff6b6b;');
      console.groupEnd();
      return false;
    }

    if (!instances.has(id)) {
      logger.warn(`⚠️ Экземпляр ${id} не найден`);
      console.log(`%c⚠️ Экземпляр не найден`, 'color: #fdcb6e;');
      console.groupEnd();
      return false;
    }

    const instance = instances.get(id);
    const regData = registry.get(id);

    instances.delete(id);
    registry.delete(id);
    this[GLOBAL_SYMBOLS.CACHE].delete(`instance:${id}`);

    const meta = this[GLOBAL_SYMBOLS.METADATA];
    meta.totalUnregistrations++;
    meta.lastUpdate = Date.now();

    this[GLOBAL_SYMBOLS.EMIT]('unregister', { id, instance, regData });

    logger.success(`🗑️ Экземпляр ${id} удален из регистра`);
    logger.info(`📊 Осталось экземпляров: ${instances.size}`);

    console.log(`%c✅ Экземпляр ${id} удален`, 'color: #00b894;');
    console.log(`%c📊 Осталось экземпляров: ${instances.size}`, 'color: #74b9ff;');
    console.groupEnd();

    return true;
  }

  // ============================================================
  // 5.5 ★★★ ПОЛУЧЕНИЕ ЭКЗЕМПЛЯРА ★★★
  // ============================================================

  static [GLOBAL_SYMBOLS.GET](id) {
    // ★★★ ГРУППА: ПОЛУЧЕНИЕ ★★★
    console.groupCollapsed(`%c🔍 ПОЛУЧЕНИЕ: ${id}`, 'color: #74b9ff; font-weight: bold;');
    console.log(`%c📌 ID: ${id}`, 'color: #74b9ff;');
    console.trace('📍 Stack trace получения:');

    const instances = this[GLOBAL_SYMBOLS.INSTANCES];
    const registry = this[GLOBAL_SYMBOLS.REGISTRY];

    const idValidation = this[GLOBAL_SYMBOLS.VALIDATE_ID](id);
    if (!idValidation.valid) {
      this[GLOBAL_SYMBOLS.LOGGER].error(`❌ ${idValidation.error}`);
      console.log(`%c❌ Ошибка: ${idValidation.error}`, 'color: #ff6b6b;');
      console.groupEnd();
      return null;
    }

    const cached = this[GLOBAL_SYMBOLS.CACHE].get(`instance:${id}`);
    if (cached) {
      registry.get(id).metadata.lastAccess = Date.now();
      console.log(`%c📦 Из кеша:`, 'color: #00b894;', cached.instance);
      console.groupEnd();
      return cached.instance;
    }

    if (!instances.has(id)) {
      this[GLOBAL_SYMBOLS.LOGGER].warn(`⚠️ Экземпляр ${id} не найден`);
      console.log(`%c⚠️ Экземпляр не найден`, 'color: #fdcb6e;');
      console.groupEnd();
      return null;
    }

    const regData = registry.get(id);
    if (regData) {
      regData.metadata.lastAccess = Date.now();
    }

    const result = instances.get(id);
    console.log(`%c✅ Экземпляр получен:`, 'color: #00b894;', result);
    console.groupEnd();
    return result;
  }

  // ============================================================
  // 5.6 ★★★ ПРОВЕРКА НАЛИЧИЯ ★★★
  // ============================================================

  static [GLOBAL_SYMBOLS.HAS](id) {
    // ★★★ ГРУППА: ПРОВЕРКА ★★★
    console.groupCollapsed(`%c❓ ПРОВЕРКА: ${id}`, 'color: #74b9ff; font-weight: bold;');
    console.log(`%c📌 ID: ${id}`, 'color: #74b9ff;');
    console.trace('📍 Stack trace проверки:');

    const idValidation = this[GLOBAL_SYMBOLS.VALIDATE_ID](id);
    if (!idValidation.valid) {
      console.log(`%c❌ Ошибка: ${idValidation.error}`, 'color: #ff6b6b;');
      console.groupEnd();
      return false;
    }
    const result = this[GLOBAL_SYMBOLS.INSTANCES].has(id);
    console.log(`%c✅ Результат: ${result}`, 'color: #00b894;');
    console.groupEnd();
    return result;
  }

  // ============================================================
  // 5.7 ★★★ УСТАНОВКА ДАННЫХ ★★★
  // ============================================================

  static [GLOBAL_SYMBOLS.SET](key, value) {
    // ★★★ ГРУППА: УСТАНОВКА ★★★
    console.groupCollapsed(`%c✏️ УСТАНОВКА: ${key}`, 'color: #fdcb6e; font-weight: bold;');
    console.log(`%c📌 Key: ${key}`, 'color: #74b9ff;');
    console.log(`%c📌 Value:`, 'color: #74b9ff;', value);
    console.trace('📍 Stack trace установки:');

    const registry = this[GLOBAL_SYMBOLS.REGISTRY];
    const oldValue = registry.get(key);
    registry.set(key, value);

    this[GLOBAL_SYMBOLS.METADATA].lastUpdate = Date.now();
    this[GLOBAL_SYMBOLS.EMIT]('set', { key, value, oldValue });

    console.log(`%c✅ Установлено:`, 'color: #00b894;', value);
    console.groupEnd();
    return value;
  }

  // ============================================================
  // 5.8 ★★★ УДАЛЕНИЕ ДАННЫХ ★★★
  // ============================================================

  static [GLOBAL_SYMBOLS.DELETE](key) {
    // ★★★ ГРУППА: УДАЛЕНИЕ ★★★
    console.groupCollapsed(`%c🗑️ УДАЛЕНИЕ: ${key}`, 'color: #ff6b6b; font-weight: bold;');
    console.log(`%c📌 Key: ${key}`, 'color: #74b9ff;');
    console.trace('📍 Stack trace удаления:');

    const registry = this[GLOBAL_SYMBOLS.REGISTRY];
    const value = registry.get(key);
    const result = registry.delete(key);

    if (result) {
      this[GLOBAL_SYMBOLS.METADATA].lastUpdate = Date.now();
      this[GLOBAL_SYMBOLS.EMIT]('delete', { key, value });
    }

    console.log(`%c✅ Результат: ${result}`, 'color: #00b894;');
    console.groupEnd();
    return result;
  }

  // ============================================================
  // 5.9 ★★★ ОЧИСТКА ★★★
  // ============================================================

  static [GLOBAL_SYMBOLS.CLEAR]() {
    // ★★★ ГРУППА: ОЧИСТКА ★★★
    console.groupCollapsed('%c🧹 ОЧИСТКА', 'color: #ff6b6b; font-weight: bold;');
    console.trace('📍 Stack trace очистки:');

    const logger = this[GLOBAL_SYMBOLS.LOGGER];
    const count = this[GLOBAL_SYMBOLS.INSTANCES].size;

    this[GLOBAL_SYMBOLS.INSTANCES].clear();
    this[GLOBAL_SYMBOLS.REGISTRY].clear();
    this[GLOBAL_SYMBOLS.CACHE].clear();

    this[GLOBAL_SYMBOLS.METADATA].lastUpdate = Date.now();
    this[GLOBAL_SYMBOLS.EMIT]('clear', { count });

    logger.info(`🗑️ Очищено ${count} экземпляров`);
    console.log(`%c✅ Очищено ${count} экземпляров`, 'color: #00b894;');
    console.groupEnd();
    return count;
  }

  // ============================================================
  // 5.10 ★★★ ПОЛУЧЕНИЕ СОСТОЯНИЯ ★★★
  // ============================================================

  static [GLOBAL_SYMBOLS.GET_STATE]() {
    // ★★★ ГРУППА: СОСТОЯНИЕ ★★★
    console.groupCollapsed('%c📊 СОСТОЯНИЕ', 'color: #74b9ff; font-weight: bold;');
    console.trace('📍 Stack trace получения состояния:');

    const instances = this[GLOBAL_SYMBOLS.INSTANCES];
    const registry = this[GLOBAL_SYMBOLS.REGISTRY];
    const cache = this[GLOBAL_SYMBOLS.CACHE];
    const meta = this[GLOBAL_SYMBOLS.METADATA];

    const result = {
      version: this[GLOBAL_SYMBOLS.VERSION],
      build: this[GLOBAL_SYMBOLS.BUILD],
      initialized: this[GLOBAL_SYMBOLS.INITIALIZED],
      destroyed: this[GLOBAL_SYMBOLS.IS_DESTROYED],
      totalInstances: instances.size,
      totalRegistry: registry.size,
      totalCache: cache.size,
      metadata: { ...meta },
      instances: Array.from(instances.keys()),
      registry: Array.from(registry.keys()),
      listeners: this[GLOBAL_SYMBOLS.LISTENERS].size,
      handlers: this[GLOBAL_SYMBOLS.HANDLERS].size,
    };

    console.log(`%c✅ Состояние:`, 'color: #00b894;', result);
    console.groupEnd();
    return result;
  }

  // ============================================================
  // 5.11 ★★★ ПОЛУЧЕНИЕ СТАТИСТИКИ ★★★
  // ============================================================

  static [GLOBAL_SYMBOLS.GET_STATS]() {
    // ★★★ ГРУППА: СТАТИСТИКА ★★★
    console.groupCollapsed('%c📊 СТАТИСТИКА', 'color: #74b9ff; font-weight: bold;');
    console.trace('📍 Stack trace получения статистики:');

    const instances = this[GLOBAL_SYMBOLS.INSTANCES];
    const registry = this[GLOBAL_SYMBOLS.REGISTRY];
    const meta = this[GLOBAL_SYMBOLS.METADATA];

    const types = {};
    for (const [id, data] of registry) {
      const type = data.type || 'unknown';
      types[type] = (types[type] || 0) + 1;
    }

    const result = {
      version: this[GLOBAL_SYMBOLS.VERSION],
      build: this[GLOBAL_SYMBOLS.BUILD],
      totalInstances: instances.size,
      totalRegistry: registry.size,
      totalRegistrations: meta.totalRegistrations,
      totalUnregistrations: meta.totalUnregistrations,
      apiCalls: meta.apiCalls || 0,
      apiErrors: meta.apiErrors || 0,
      types,
      uptime: Date.now() - meta.created,
      lastUpdate: meta.lastUpdate,
    };

    console.log(`%c✅ Статистика:`, 'color: #00b894;', result);
    console.groupEnd();
    return result;
  }

  // ============================================================
  // 5.12 ★★★ СБРОС ★★★
  // ============================================================

  static [GLOBAL_SYMBOLS.RESET]() {
    // ★★★ ГРУППА: СБРОС ★★★
    console.groupCollapsed('%c🔄 СБРОС', 'color: #ff6b6b; font-weight: bold;');
    console.trace('📍 Stack trace сброса:');

    const logger = this[GLOBAL_SYMBOLS.LOGGER];
    logger.warn('🔄 Сброс глобального регистра...');

    this[GLOBAL_SYMBOLS.INSTANCES].clear();
    this[GLOBAL_SYMBOLS.REGISTRY].clear();
    this[GLOBAL_SYMBOLS.CACHE].clear();
    this[GLOBAL_SYMBOLS.LISTENERS].clear();
    this[GLOBAL_SYMBOLS.HANDLERS].clear();

    this[GLOBAL_SYMBOLS.METADATA] = {
      created: Date.now(),
      lastUpdate: Date.now(),
      totalRegistrations: 0,
      totalUnregistrations: 0,
      apiCalls: 0,
      apiErrors: 0,
    };

    this[GLOBAL_SYMBOLS.INITIALIZED] = false;
    this[GLOBAL_SYMBOLS.EMIT]('reset', { timestamp: Date.now() });

    logger.success('✅ Глобальный регистр сброшен');
    console.log('%c✅ Глобальный регистр сброшен', 'color: #00b894;');
    console.groupEnd();
    return this;
  }

  // ============================================================
  // 5.13 ★★★ УНИЧТОЖЕНИЕ ★★★
  // ============================================================

  static [GLOBAL_SYMBOLS.DESTROY]() {
    // ★★★ ГРУППА: УНИЧТОЖЕНИЕ ★★★
    console.groupCollapsed('%c💥 УНИЧТОЖЕНИЕ', 'color: #ff6b6b; font-weight: bold;');
    console.trace('📍 Stack trace уничтожения:');

    const logger = this[GLOBAL_SYMBOLS.LOGGER];

    if (this[GLOBAL_SYMBOLS.IS_DESTROYED]) {
      logger.warn('⚠️ Глобальный регистр уже уничтожен');
      console.log('%c⚠️ Глобальный регистр уже уничтожен', 'color: #fdcb6e;');
      console.groupEnd();
      return;
    }

    logger.warn('🗑️ Уничтожение глобального регистра...');

    this[GLOBAL_SYMBOLS.CLEAR]();
    this[GLOBAL_SYMBOLS.LISTENERS].clear();
    this[GLOBAL_SYMBOLS.HANDLERS].clear();
    this[GLOBAL_SYMBOLS.CACHE].clear();

    if (typeof window !== 'undefined') {
      delete window[PUBLIC_GLOBAL.REGISTRY];
      delete window[PUBLIC_GLOBAL.INSTANCES];
      delete window[PUBLIC_GLOBAL.STATE];
      delete window[PUBLIC_GLOBAL.CONFIG];
      delete window[PUBLIC_GLOBAL.LOGGER];
      delete window[PUBLIC_GLOBAL.API];
      delete window[PUBLIC_GLOBAL.EVENTS];
      delete window[PUBLIC_GLOBAL.VERSION];
      delete window.__globalRegistry;
      delete window.__globalRegistryCommands;
      delete window.__globalRegistrySymbols;
    }

    this[GLOBAL_SYMBOLS.IS_DESTROYED] = true;
    this[GLOBAL_SYMBOLS.INITIALIZED] = false;

    logger.success('✅ Глобальный регистр уничтожен');
    console.log('%c✅ Глобальный регистр уничтожен', 'color: #00b894;');
    console.groupEnd();
  }

  // ============================================================
  // 5.14 ★★★ СОБЫТИЯ ★★★
  // ============================================================

  static [GLOBAL_SYMBOLS.ON](event, callback) {
    // ★★★ ГРУППА: ПОДПИСКА ★★★
    console.groupCollapsed(`%c👂 ПОДПИСКА: ${event}`, 'color: #74b9ff; font-weight: bold;');
    console.log(`%c📌 Event: ${event}`, 'color: #74b9ff;');
    console.log(`%c📌 Callback:`, 'color: #74b9ff;', callback);
    console.trace('📍 Stack trace подписки:');

    const validation = this[GLOBAL_SYMBOLS.VALIDATE_CALLBACK](callback);
    if (!validation.valid) {
      this[GLOBAL_SYMBOLS.LOGGER].warn(`⚠️ ${validation.error}`);
      console.log(`%c❌ Ошибка: ${validation.error}`, 'color: #ff6b6b;');
      console.groupEnd();
      return () => {};
    }

    if (!this[GLOBAL_SYMBOLS.LISTENERS].has(event)) {
      this[GLOBAL_SYMBOLS.LISTENERS].set(event, []);
    }
    this[GLOBAL_SYMBOLS.LISTENERS].get(event).push(callback);

    const unsubscribe = () => this[GLOBAL_SYMBOLS.OFF](event, callback);
    console.log(`%c✅ Подписка добавлена`, 'color: #00b894;');
    console.groupEnd();
    return unsubscribe;
  }

  static [GLOBAL_SYMBOLS.OFF](event, callback) {
    // ★★★ ГРУППА: ОТПИСКА ★★★
    console.groupCollapsed(`%c👂 ОТПИСКА: ${event}`, 'color: #74b9ff; font-weight: bold;');
    console.log(`%c📌 Event: ${event}`, 'color: #74b9ff;');
    console.log(`%c📌 Callback:`, 'color: #74b9ff;', callback);
    console.trace('📍 Stack trace отписки:');

    if (this[GLOBAL_SYMBOLS.LISTENERS].has(event)) {
      const listeners = this[GLOBAL_SYMBOLS.LISTENERS].get(event);
      const index = listeners.indexOf(callback);
      if (index !== -1) {
        listeners.splice(index, 1);
      }
      if (listeners.length === 0) {
        this[GLOBAL_SYMBOLS.LISTENERS].delete(event);
      }
      console.log(`%c✅ Отписка выполнена`, 'color: #00b894;');
    } else {
      console.log(`%c⚠️ Слушатель не найден`, 'color: #fdcb6e;');
    }
    console.groupEnd();
  }

  static [GLOBAL_SYMBOLS.EMIT](event, data) {
    // ★★★ ГРУППА: СОБЫТИЕ ★★★
    console.groupCollapsed(`%c📤 СОБЫТИЕ: ${event}`, 'color: #fdcb6e; font-weight: bold;');
    console.log(`%c📌 Event: ${event}`, 'color: #74b9ff;');
    console.log(`%c📌 Data:`, 'color: #74b9ff;', data);
    console.trace('📍 Stack trace события:');

    if (this[GLOBAL_SYMBOLS.LISTENERS].has(event)) {
      const listeners = this[GLOBAL_SYMBOLS.LISTENERS].get(event);
      for (const callback of listeners) {
        try {
          callback(data);
        } catch (error) {
          this[GLOBAL_SYMBOLS.LOGGER].error(`❌ Ошибка в обработчике ${event}:`, error);
          console.log(`%c❌ Ошибка в обработчике: ${error.message}`, 'color: #ff6b6b;');
        }
      }
      console.log(`%c✅ Событие отправлено ${listeners.length} слушателям`, 'color: #00b894;');
    } else {
      console.log(`%c⚠️ Нет слушателей для события ${event}`, 'color: #fdcb6e;');
    }
    console.groupEnd();
  }

  // ============================================================
  // 5.15 ★★★ ★★★ API ДЛЯ ВНЕШНЕГО ИСПОЛЬЗОВАНИЯ (ИСПРАВЛЕННЫЙ) ★★★ ★★★
  // ============================================================

  static [GLOBAL_SYMBOLS.API](action, ...args) {
    // ★★★ ГРУППА: API ВЫЗОВ ★★★
    console.groupCollapsed(`%c🔧 API: ${action || '(empty)'}`, 'color: #fdcb6e; font-weight: bold;');
    console.log(`%c📌 Action: ${action}`, 'color: #74b9ff;');
    console.log(`%c📌 Аргументы:`, 'color: #74b9ff;', args);
    console.trace('📍 Stack trace API:');

    const logger = this[GLOBAL_SYMBOLS.LOGGER];
    const meta = this[GLOBAL_SYMBOLS.METADATA];

    // ★★★ ★★★ ПРОВЕРКА: action === undefined/null ★★★ ★★★
    if (action === undefined || action === null) {
      meta.apiErrors = (meta.apiErrors || 0) + 1;
      const errorMsg = '❌ API вызван без указания действия';
      logger.error(errorMsg);
      console.log(`%c❌ ${errorMsg}`, 'color: #ff6b6b;');
      console.groupEnd();
      return {
        success: false,
        error: 'Действие не указано',
        action: null,
        code: 'ACTION_EMPTY',
      };
    }

    // ★★★ ПРОВЕРКА: action не строка ★★★
    if (typeof action !== 'string') {
      meta.apiErrors = (meta.apiErrors || 0) + 1;
      const errorMsg = `❌ API вызван с нестроковым действием: ${typeof action}`;
      logger.error(errorMsg);
      console.log(`%c❌ ${errorMsg}`, 'color: #ff6b6b;');
      console.groupEnd();
      return {
        success: false,
        error: `Действие должно быть строкой, получено: ${typeof action}`,
        action: String(action),
        code: 'ACTION_NOT_STRING',
      };
    }

    // ★★★ ПРОВЕРКА: action пустая строка ★★★
    if (action.trim() === '') {
      meta.apiErrors = (meta.apiErrors || 0) + 1;
      const errorMsg = '❌ API вызван с пустым действием';
      logger.error(errorMsg);
      console.log(`%c❌ ${errorMsg}`, 'color: #ff6b6b;');
      console.groupEnd();
      return {
        success: false,
        error: 'Действие не может быть пустой строкой',
        action,
        code: 'ACTION_EMPTY_STRING',
      };
    }

    // ★★★ УВЕЛИЧИВАЕМ СЧЁТЧИК ВЫЗОВОВ ★★★
    meta.apiCalls = (meta.apiCalls || 0) + 1;

    // ★★★ ЛОГИРУЕМ ВЫЗОВ ★★★
    logger.debug(`🔧 API вызов: ${action}`);

    // ★★★ ВЫПОЛНЯЕМ ДЕЙСТВИЕ ★★★
    try {
      let result = null;

      switch (action) {
        case 'register':
          result = this[GLOBAL_SYMBOLS.REGISTER](...args);
          break;
        case 'unregister':
          result = this[GLOBAL_SYMBOLS.UNREGISTER](...args);
          break;
        case 'get':
          result = this[GLOBAL_SYMBOLS.GET](...args);
          break;
        case 'has':
          result = this[GLOBAL_SYMBOLS.HAS](...args);
          break;
        case 'set':
          result = this[GLOBAL_SYMBOLS.SET](...args);
          break;
        case 'delete':
          result = this[GLOBAL_SYMBOLS.DELETE](...args);
          break;
        case 'clear':
          result = this[GLOBAL_SYMBOLS.CLEAR](...args);
          break;
        case 'getState':
          result = this[GLOBAL_SYMBOLS.GET_STATE](...args);
          break;
        case 'getStats':
          result = this[GLOBAL_SYMBOLS.GET_STATS](...args);
          break;
        case 'reset':
          result = this[GLOBAL_SYMBOLS.RESET](...args);
          break;
        case 'destroy':
          result = this[GLOBAL_SYMBOLS.DESTROY](...args);
          break;
        case 'on':
          result = this[GLOBAL_SYMBOLS.ON](...args);
          break;
        case 'off':
          result = this[GLOBAL_SYMBOLS.OFF](...args);
          break;
        case 'emit':
          result = this[GLOBAL_SYMBOLS.EMIT](...args);
          break;
        default:
          meta.apiErrors = (meta.apiErrors || 0) + 1;
          const unknownMsg = `❌ Неизвестное действие: ${String(action)}`;
          logger.error(unknownMsg);
          logger.debug(`  📌 Доступные действия: register, unregister, get, has, set, delete, clear, getState, getStats, reset, destroy, on, off, emit`);
          console.log(`%c❌ ${unknownMsg}`, 'color: #ff6b6b;');
          console.log(`%c📌 Доступные действия: register, unregister, get, has, set, delete, clear, getState, getStats, reset, destroy, on, off, emit`, 'color: #74b9ff;');
          console.groupEnd();
          return {
            success: false,
            error: `Неизвестное действие: ${String(action)}`,
            action: String(action),
            code: 'UNKNOWN_ACTION',
            availableActions: ['register', 'unregister', 'get', 'has', 'set', 'delete', 'clear', 'getState', 'getStats', 'reset', 'destroy', 'on', 'off', 'emit'],
          };
      }

      logger.debug(`✅ API вызов ${action} выполнен успешно`);
      console.log(`%c✅ API вызов ${action} выполнен успешно`, 'color: #00b894;');
      console.groupEnd();
      return result;

    } catch (error) {
      meta.apiErrors = (meta.apiErrors || 0) + 1;
      logger.error(`❌ Ошибка выполнения API (${action}): ${error.message}`);
      logger.debug(`  📌 Stack: ${error.stack}`);
      console.log(`%c❌ Ошибка выполнения API: ${error.message}`, 'color: #ff6b6b;');
      console.groupEnd();
      return {
        success: false,
        error: error.message,
        action: String(action),
        code: 'EXECUTION_ERROR',
        stack: error.stack,
      };
    }
  }

  // ============================================================
  // 5.16 ★★★ ЭКСПОРТ СИМВОЛОВ ★★★
  // ============================================================

  static [GLOBAL_SYMBOLS.EXPORT_SYMBOLS]() {
    if (typeof window === 'undefined') {return;}

    window.__globalRegistrySymbols = {
      GLOBAL_SYMBOLS: { ...GLOBAL_SYMBOLS },
      PUBLIC_GLOBAL: { ...PUBLIC_GLOBAL },
      PRIVATE: { ...PRIVATE },
      PUBLIC: { ...PUBLIC },
      version: this[GLOBAL_SYMBOLS.VERSION],
      build: this[GLOBAL_SYMBOLS.BUILD],
      state: this[GLOBAL_SYMBOLS.GET_STATE](),
      stats: this[GLOBAL_SYMBOLS.GET_STATS](),
    };
  }
}

// ============================================================
// 6. ★★★ ФУНКЦИИ ГЛОБАЛЬНОЙ РЕГИСТРАЦИИ ★★★
// ============================================================

// ============================================================
// 6.1 ★★★ РЕГИСТРАЦИЯ ГЛОБАЛЬНЫХ API ★★★
// ============================================================

export function registerGlobals(instance, BookmarkletClass) {
  if (typeof window === 'undefined') {return;}

  // ★★★ ГРУППА: РЕГИСТРАЦИЯ ГЛОБАЛЬНЫХ API ★★★
  console.groupCollapsed('%c📦 РЕГИСТРАЦИЯ ГЛОБАЛЬНЫХ API', 'color: #667eea; font-weight: bold;');
  console.log(`%c📌 Instance:`, 'color: #74b9ff;', instance);
  console.log(`%c📌 BookmarkletClass:`, 'color: #74b9ff;', BookmarkletClass);
  console.trace('📍 Stack trace регистрации глобальных API:');

  const logger = createLogger(true, 'GlobalRegistry');

  if (instance && typeof instance === 'object') {
    const instanceId = instance[PRIVATE.ID] || instance._id || 'bookmarklet';
    const instanceType = instance[PRIVATE.TYPE] || instance._type || 'main';
    const instanceName = instance[PRIVATE.NAME] || instance._name || 'Bookmarklet';
    const instanceVersion = instance[PRIVATE.VERSION] || instance._version || '3.5.2';

    GlobalRegistry[GLOBAL_SYMBOLS.REGISTER](
      instanceId,
      instance,
      {
        type: instanceType,
        name: instanceName,
        version: instanceVersion,
      },
    );

    window.__bookmarklet = instance;
    window.__bookmarkletInstance = instance;
    window[PUBLIC.API] = instance;

    window[PUBLIC.STATE] = typeof instance.getState === 'function'
      ? instance.getState.bind(instance)
      : null;

    window[PUBLIC.CONFIG] = instance._config || null;
    window[PUBLIC.LOGGER] = logger;
    window[PUBLIC.INSTANCE] = instance;

    window[PUBLIC.MAIN] = typeof instance[PRIVATE.RUN] === 'function'
      ? instance[PRIVATE.RUN].bind(instance)
      : null;

    window[PUBLIC.RECURSIVE] = typeof instance[PRIVATE.RECURSIVE] === 'function'
      ? instance[PRIVATE.RECURSIVE].bind(instance)
      : null;

    window[PUBLIC.RECURSIVE_LOOP] = typeof instance[PRIVATE.RECURSIVE_LOOP] === 'function'
      ? instance[PRIVATE.RECURSIVE_LOOP].bind(instance)
      : null;

    window[PUBLIC.ACTIVE] = instance._activeComponent || null;
    window[PUBLIC.SINGLETON] = BookmarkletClass ? BookmarkletClass[PRIVATE.INSTANCE] : null;

    window[PUBLIC.EVENTS] = typeof instance.on === 'function' ? {
      on: instance.on.bind(instance),
      off: instance.off.bind(instance),
      emit: instance.emit.bind(instance),
    } : null;

    window.__bookmarkletSymbols = {
      PRIVATE: { ...PRIVATE },
      PUBLIC: { ...PUBLIC },
      version: instance[PRIVATE.VERSION] || instance._version || null,
      build: instance[PRIVATE.BUILD] || instance._build || null,
      active: instance._activeComponent || null,
      isSingleton: BookmarkletClass ? BookmarkletClass[PRIVATE.IS_SINGLETON] : null,
      isRecursive: instance[PRIVATE.IS_RECURSIVE] || instance._isRecursive || null,
      targetState: instance[PRIVATE.TARGET_STATE] || instance._targetState || null,
      maxRecursion: instance[PRIVATE.MAX_RECURSION] || instance._maxRecursion || null,
    };

    window.__bm = {
      instance,
      config: instance._config || null,
      getState: typeof instance.getState === 'function' ? instance.getState.bind(instance) : null,
      reset: typeof instance.reset === 'function' ? instance.reset.bind(instance) : null,
      destroy: typeof instance.destroy === 'function' ? instance.destroy.bind(instance) : null,
      run: typeof instance[PRIVATE.RUN] === 'function' ? instance[PRIVATE.RUN].bind(instance) : null,
      recursive: typeof instance[PRIVATE.RECURSIVE] === 'function' ? instance[PRIVATE.RECURSIVE].bind(instance) : null,
      recursiveLoop: typeof instance[PRIVATE.RECURSIVE_LOOP] === 'function' ? instance[PRIVATE.RECURSIVE_LOOP].bind(instance) : null,
      getInstance: BookmarkletClass ? BookmarkletClass.getInstance.bind(BookmarkletClass) : null,
      createInstance: BookmarkletClass ? BookmarkletClass.createInstance.bind(BookmarkletClass) : null,
      destroyInstance: BookmarkletClass ? BookmarkletClass.destroyInstance.bind(BookmarkletClass) : null,
      isSingleton: BookmarkletClass ? BookmarkletClass.isSingleton.bind(BookmarkletClass) : null,
      getSymbols: () => ({
        PRIVATE: { ...PRIVATE },
        PUBLIC: { ...PUBLIC },
        GLOBAL_SYMBOLS: { ...GLOBAL_SYMBOLS },
        PUBLIC_GLOBAL: { ...PUBLIC_GLOBAL },
      }),
    };

    logger.success('✅ Глобальные API зарегистрированы');
    logger.info(`📌 Экземпляр: ${instanceId}`);
    logger.info(`📌 Singleton: ${BookmarkletClass ? BookmarkletClass[PRIVATE.IS_SINGLETON] : 'не найден'}`);

    console.log(`%c✅ Глобальные API зарегистрированы`, 'color: #00b894;');
    console.log(`%c📌 Экземпляр: ${instanceId}`, 'color: #74b9ff;');

  } else {
    logger.warn('⚠️ Экземпляр не передан или невалидный, создаем базовую регистрацию');
    console.log(`%c⚠️ Экземпляр не передан или невалидный, создаем базовую регистрацию`, 'color: #fdcb6e;');

    window.__bookmarklet = null;
    window.__bookmarkletInstance = null;
    window[PUBLIC.API] = null;
    window[PUBLIC.STATE] = null;
    window[PUBLIC.CONFIG] = null;
    window[PUBLIC.LOGGER] = logger;
    window[PUBLIC.INSTANCE] = null;
    window[PUBLIC.MAIN] = null;
    window[PUBLIC.RECURSIVE] = null;
    window[PUBLIC.RECURSIVE_LOOP] = null;
    window[PUBLIC.ACTIVE] = null;
    window[PUBLIC.SINGLETON] = null;
    window[PUBLIC.EVENTS] = null;

    window.__bookmarkletSymbols = {
      PRIVATE: { ...PRIVATE },
      PUBLIC: { ...PUBLIC },
      version: null,
      build: null,
      active: null,
      isSingleton: null,
      isRecursive: null,
      targetState: null,
      maxRecursion: null,
    };

    window.__bm = {
      instance: null,
      config: null,
      getState: null,
      reset: null,
      destroy: null,
      run: null,
      recursive: null,
      recursiveLoop: null,
      getInstance: null,
      createInstance: null,
      destroyInstance: null,
      isSingleton: null,
      getSymbols: () => ({
        PRIVATE: { ...PRIVATE },
        PUBLIC: { ...PUBLIC },
        GLOBAL_SYMBOLS: { ...GLOBAL_SYMBOLS },
        PUBLIC_GLOBAL: { ...PUBLIC_GLOBAL },
      }),
    };

    logger.warn('⚠️ Базовые API зарегистрированы (экземпляр отсутствует)');
    console.log(`%c⚠️ Базовые API зарегистрированы (экземпляр отсутствует)`, 'color: #fdcb6e;');
  }

  window.__globalRegistry = GlobalRegistry;
  window.__globalRegistrySymbols = {
    GLOBAL_SYMBOLS: { ...GLOBAL_SYMBOLS },
    PUBLIC_GLOBAL: { ...PUBLIC_GLOBAL },
  };

  console.log(`%c✅ Глобальный регистр обновлён`, 'color: #00b894;');
  console.groupEnd();
}

// ============================================================
// 6.2 ★★★ ОБРАБОТЧИК АВТОМАТИЧЕСКОГО ЗАПУСКА ★★★
// ============================================================

export function handleAutoStart(bookmarkletMain) {
  if (typeof document === 'undefined') {return;}

  // ★★★ ГРУППА: АВТОЗАПУСК ★★★
  console.groupCollapsed('%c🚀 АВТОЗАПУСК', 'color: #667eea; font-weight: bold;');
  console.trace('📍 Stack trace автозапуска:');

  const script = document.querySelector('script[data-bookmarklet-auto]');
  if (!script) {
    console.log('%c⚠️ Скрипт с data-bookmarklet-auto не найден', 'color: #fdcb6e;');
    console.groupEnd();
    return;
  }

  const logger = createLogger(true, 'AutoStart');
  logger.info('🚀 Обнаружен авто-запуск букмарклета');

  const config = {
    name: script.dataset.name || 'Bookmarklet',
    type: script.dataset.type || 'main',
    id: script.dataset.id || 'bm-' + Date.now(),
    version: script.dataset.version || '3.5.2',
    data: script.dataset.data ? JSON.parse(script.dataset.data) : null,
    callback: script.dataset.callback ? new Function('return ' + script.dataset.callback)() : null,
    recursive: script.dataset.recursive === 'true',
    targetState: script.dataset.targetState ? JSON.parse(script.dataset.targetState) : null,
    maxRecursion: parseInt(script.dataset.maxRecursion) || 100,
    recursionDelay: parseInt(script.dataset.recursionDelay) || 500,
  };

  logger.info(`📌 Имя: ${config.name}`);
  logger.info(`📌 Тип: ${config.type}`);
  logger.info(`📌 ID: ${config.id}`);
  logger.info(`📌 Recursive: ${config.recursive}`);
  logger.info(`📌 TargetState: ${config.targetState ? '✅' : '❌'}`);

  console.log(`%c📌 Имя: ${config.name}`, 'color: #74b9ff;');
  console.log(`%c📌 Тип: ${config.type}`, 'color: #74b9ff;');
  console.log(`%c📌 ID: ${config.id}`, 'color: #74b9ff;');
  console.log(`%c📌 Recursive: ${config.recursive}`, 'color: #74b9ff;');

  if (!bookmarkletMain || typeof bookmarkletMain !== 'function') {
    logger.error('❌ bookmarkletMain не функция или отсутствует');
    console.log(`%c❌ bookmarkletMain не функция или отсутствует`, 'color: #ff6b6b;');
    console.groupEnd();
    return;
  }

  if (config.recursive && config.targetState) {
    if (typeof bookmarkletMain.recursiveLoop === 'function') {
      bookmarkletMain.recursiveLoop(config).then(result => {
        console.log('✅ Автозапуск (бесконечная рекурсия) выполнен:', result);
        logger.success('✅ Автозапуск (бесконечная рекурсия) выполнен');
        console.log(`%c✅ Автозапуск (бесконечная рекурсия) выполнен`, 'color: #00b894;', result);
        console.groupEnd();
      }).catch(error => {
        logger.error(`❌ Ошибка автозапуска: ${error.message}`);
        console.log(`%c❌ Ошибка автозапуска: ${error.message}`, 'color: #ff6b6b;');
        console.groupEnd();
      });
    } else {
      logger.error('❌ bookmarkletMain.recursiveLoop не функция');
      console.log(`%c❌ bookmarkletMain.recursiveLoop не функция`, 'color: #ff6b6b;');
      console.groupEnd();
    }
  } else if (config.recursive) {
    if (typeof bookmarkletMain.recursive === 'function') {
      bookmarkletMain.recursive(config).then(result => {
        console.log('✅ Автозапуск (рекурсивный) выполнен:', result);
        logger.success('✅ Автозапуск (рекурсивный) выполнен');
        console.log(`%c✅ Автозапуск (рекурсивный) выполнен`, 'color: #00b894;', result);
        console.groupEnd();
      }).catch(error => {
        logger.error(`❌ Ошибка автозапуска: ${error.message}`);
        console.log(`%c❌ Ошибка автозапуска: ${error.message}`, 'color: #ff6b6b;');
        console.groupEnd();
      });
    } else {
      logger.error('❌ bookmarkletMain.recursive не функция');
      console.log(`%c❌ bookmarkletMain.recursive не функция`, 'color: #ff6b6b;');
      console.groupEnd();
    }
  } else {
    bookmarkletMain(config).then(result => {
      console.log('✅ Автозапуск выполнен:', result);
      logger.success('✅ Автозапуск выполнен');
      console.log(`%c✅ Автозапуск выполнен`, 'color: #00b894;', result);
      console.groupEnd();
    }).catch(error => {
      logger.error(`❌ Ошибка автозапуска: ${error.message}`);
      console.log(`%c❌ Ошибка автозапуска: ${error.message}`, 'color: #ff6b6b;');
      console.groupEnd();
    });
  }
}

// ============================================================
// 6.3 ★★★ ПЕЧАТЬ БАННЕРА (ИСПРАВЛЕННАЯ) ★★★
// ============================================================

export function printBanner(PRIVATE_SYMBOLS, PUBLIC_SYMBOLS) {
  // ★★★ ИСПРАВЛЕНО: Используем специальную функцию для баннера ★★★
  const logger = createBannerLogger(true, 'Banner');

  // ★★★ ГРУППА: БАННЕР ★★★
  console.groupCollapsed('%c📦 БУКМАРКЛЕТ (100% СИМВОЛЫ)', 'color: #667eea; font-weight: bold;');
  console.trace('📍 Stack trace баннера:');

  console.log('╔═══════════════════════════════════════════════════════════════════════════════╗');
  console.log('║         📦 BOOKMARKLET (100% СИМВОЛЫ + SINGLETON + БЕСКОНЕЧНАЯ РЕКУРСИЯ) v3.5.2 ║');
  console.log('╠═══════════════════════════════════════════════════════════════════════════════╣');
  console.log('║  ✅ ТОЛЬКО ОДИН ЭКЗЕМПЛЯР - Singleton паттерн                               ║');
  console.log('║  ✅ Бесконечная рекурсия до достижения целевого состояния                   ║');
  console.log('║  ✅ Проверка состояния на каждом шаге                                      ║');
  console.log('║  ✅ Поддержка targetState: объект, строка, функция                          ║');
  console.log('║  ✅ Лимит рекурсии и задержка между шагами                                  ║');
  console.log('║  ✅ m.default = m.init + m.recursive + m.recursiveLoop                      ║');
  console.log('║  ✅ Поддержка callback - функция вызывается после выполнения                ║');
  console.log('║  ✅ Все зависимости вынесены в core/                                       ║');
  console.log('║  ✅ Глобальный регистр с 100% символами                                    ║');
  console.log('║  ✅ ИСПРАВЛЕНА: ошибка регистрации при отсутствии экземпляра               ║');
  console.log('║  ✅ ИСПРАВЛЕНА: ошибка logger.header                                       ║');
  console.log('║  ✅ ИСПРАВЛЕНА: ошибка "Неизвестное действие: undefined"                   ║');
  console.log('║  ✅ ИСПРАВЛЕНА: автоматический вызов API при инициализации                 ║');
  console.log('║  ✅ ДОБАВЛЕНА: Группировка логов через console.group()                     ║');
  console.log('║  ✅ ДОБАВЛЕНА: console.trace() для отладки                                 ║');
  console.log('╚═══════════════════════════════════════════════════════════════════════════════╝');

  console.log('📋 ДОСТУПНЫЕ КОМАНДЫ:');
  console.log('  await __bookmarkletMain({ name: "ENV Control", type: "env" })');
  console.log('  await __bookmarkletRecursive({ data: { step: 2 } })');
  console.log('  await __bookmarkletRecursiveLoop({ targetState: { status: "complete" }, maxRecursion: 50 })');
  console.log('');
  console.log('📋 БЕСКОНЕЧНАЯ РЕКУРСИЯ:');
  console.log('  targetState - целевое состояние (объект, строка или функция)');
  console.log('  maxRecursion - максимальное количество итераций (по умолчанию: 100)');
  console.log('  recursionDelay - задержка между итерациями в мс (по умолчанию: 500)');
  console.log('');
  console.log('📋 ПРИМЕРЫ targetState:');
  console.log('  { status: "complete" } - объект');
  console.log('  "{\\"status\\":\\"complete\\"}" - JSON строка');
  console.log('  (state) => state.status === "complete" - функция');
  console.log('');
  console.log('📋 API ГЛОБАЛЬНОГО РЕГИСТРА (БЕЗОПАСНЫЙ):');
  console.log('  window[Symbol.for("global-registry.api")]("getState")');
  console.log('  window[Symbol.for("global-registry.api")]("getStats")');
  console.log('  window[Symbol.for("global-registry.api")]("register", id, instance)');
  console.log('  window.__globalRegistryCommands.api("getState")');
  console.log('  window.__globalRegistryCommands.api("getStats")');
  console.log('');
  console.log('📋 ПРИВАТНЫХ СИМВОЛОВ:', Object.keys(PRIVATE_SYMBOLS || {}).length);
  console.log('📋 ПУБЛИЧНЫХ СИМВОЛОВ:', Object.keys(PUBLIC_SYMBOLS || {}).length);
  console.log('📋 ГЛОБАЛЬНЫХ СИМВОЛОВ:', Object.keys(GLOBAL_SYMBOLS).length);
  console.log('📋 ПУБЛИЧНЫХ ГЛОБАЛЬНЫХ СИМВОЛОВ:', Object.keys(PUBLIC_GLOBAL).length);

  logger.header('ГОТОВ (ожидает вызова)');
  console.groupEnd();
}

// ============================================================
// 7. ★★★ ИНИЦИАЛИЗАЦИЯ ПРИ ЗАГРУЗКЕ ★★★
// ============================================================

if (typeof window !== 'undefined') {
  // ★★★ ГРУППА: ИНИЦИАЛИЗАЦИЯ МОДУЛЯ ★★★
  console.groupCollapsed('%c📦 ГЛОБАЛЬНЫЙ РЕГИСТР v1.0.5', 'color: #667eea; font-weight: bold;');
  console.trace('📍 Stack trace загрузки модуля:');

  GlobalRegistry[GLOBAL_SYMBOLS.INITIALIZE]();
  GlobalRegistry[GLOBAL_SYMBOLS.EXPORT_SYMBOLS]();

  console.log('📋 КОМАНДЫ ГЛОБАЛЬНОГО РЕГИСТРА (__globalRegistryCommands):');
  console.log('  __globalRegistryCommands.getState()       - состояние (с группой)');
  console.log('  __globalRegistryCommands.getStats()       - статистика (с группой)');
  console.log('  __globalRegistryCommands.register(id, inst) - регистрация (с группой)');
  console.log('  __globalRegistryCommands.unregister(id)   - отмена регистрации (с группой)');
  console.log('  __globalRegistryCommands.get(id)          - получить экземпляр (с группой)');
  console.log('  __globalRegistryCommands.has(id)          - проверить наличие (с группой)');
  console.log('  __globalRegistryCommands.set(key, value)  - установить данные (с группой)');
  console.log('  __globalRegistryCommands.delete(key)      - удалить данные (с группой)');
  console.log('  __globalRegistryCommands.clear()          - очистить (с группой)');
  console.log('  __globalRegistryCommands.reset()          - сбросить (с группой)');
  console.log('  __globalRegistryCommands.destroy()        - уничтожить (с группой)');
  console.log('  __globalRegistryCommands.on(event, cb)    - подписка (с группой)');
  console.log('  __globalRegistryCommands.off(event, cb)   - отписка (с группой)');
  console.log('  __globalRegistryCommands.emit(event, data)- событие (с группой)');
  console.log('  __globalRegistryCommands.api(action, ...) - универсальный API (с группой)');
  console.log('  __globalRegistryCommands.getSymbols()     - получить символы (с группой)');
  console.log('');
  console.log('🔧 API проверка (с группировкой):');
  console.log('  __globalRegistryCommands.api("getState") - ✅ работает (с группой и trace)');
  console.log('  __globalRegistryCommands.api()           - ❌ ошибка (с группой и trace)');
  console.log('  __globalRegistryCommands.api(null)       - ❌ ошибка (с группой и trace)');
  console.log('  __globalRegistryCommands.api(123)        - ❌ ошибка (с группой и trace)');
  console.log('  __globalRegistryCommands.api("unknown")  - ❌ ошибка (с группой и trace)');
  console.log('');
  console.log('🔧 Публичный API (через Symbol):');
  console.log('  window[Symbol.for("global-registry.api")]("getState") - ✅ работает (с группой и trace)');
  console.log('  window[Symbol.for("global-registry.api")]()           - ❌ ошибка (с группой и trace)');

  console.groupEnd();
}

// ============================================================
// 8. ★★★ ЭКСПОРТЫ ★★★
// ============================================================
