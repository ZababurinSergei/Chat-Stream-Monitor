// web/Bookmarklet/core/script-executor.js - Выполнение скриптов (100% СИМВОЛЫ)
// Версия: 1.0.2
// ИСПРАВЛЕНО: Дублирование пути Bookmarklet/core/Bookmarklet/
// ДОБАВЛЕНО: Полная нормализация путей
// ДОБАВЛЕНО: Группировка логов через console.group()
// ДОБАВЛЕНО: console.trace() для отладки

// ============================================================
// 1. ПРИВАТНЫЕ СИМВОЛЫ (100% изоляция)
// ============================================================

const MODULE_PRIVATE = {
  // Основные символы
  EXECUTE_MODULE: Symbol('script-executor.executeModule'),
  EXECUTE_FUNCTION: Symbol('script-executor.executeFunction'),
  EXECUTE_CODE: Symbol('script-executor.executeCode'),
  LOAD_VIA_SCRIPT_TAG: Symbol('script-executor.loadViaScriptTag'),
  HANDLE_IMPORT_ERROR: Symbol('script-executor.handleImportError'),
  HANDLE_MODULE_EXPORTS: Symbol('script-executor.handleModuleExports'),
  CHECK_SCRIPT_TYPE: Symbol('script-executor.checkScriptType'),
  NORMALIZE_SCRIPT: Symbol('script-executor.normalizeScript'),
  GET_FULL_URL: Symbol('script-executor.getFullUrl'),
  CREATE_FALLBACK_SCRIPT: Symbol('script-executor.createFallbackScript'),
  NORMALIZE_PATH: Symbol('script-executor.normalizePath'),
  IS_VALID_SCRIPT: Symbol('script-executor.isValidScript'),
  GET_SCRIPT_TYPE: Symbol('script-executor.getScriptType'),
  LOG_EXECUTION: Symbol('script-executor.logExecution'),
  TRACE_EXECUTION: Symbol('script-executor.traceExecution'),
};

// ============================================================
// 2. ПУБЛИЧНЫЕ СИМВОЛЫ (доступны через Symbol.for)
// ============================================================

const PUBLIC_EXECUTOR = {
  API: Symbol.for('script-executor.api'),
  STATE: Symbol.for('script-executor.state'),
  CONFIG: Symbol.for('script-executor.config'),
  LOGGER: Symbol.for('script-executor.logger'),
  INSTANCE: Symbol.for('script-executor.instance'),
};

// ============================================================
// 3. КОНФИГУРАЦИЯ
// ============================================================

const DEFAULT_CONFIG = {
  debug: true,
  timeout: 30000,
  retryCount: 3,
  retryDelay: 1000,
  fallbackEnabled: true,
  cacheEnabled: true,
  cacheTTL: 60000,
  maxCacheSize: 100,
};

// ============================================================
// 4. ★★★ НОРМАЛИЗАЦИЯ ПУТИ (ИСПРАВЛЕНА) ★★★
// ============================================================

/**
 * Нормализует путь скрипта, исправляя дублирование
 * @param {string} script - Путь к скрипту
 * @returns {string} Нормализованный путь
 */
function normalizePath(script) {
  if (!script || typeof script !== 'string') return script;

  let normalized = script;

  // ★★★ ИСПРАВЛЯЕМ ДУБЛИРОВАНИЕ Bookmarklet/core/Bookmarklet/ ★★★
  if (normalized.includes('Bookmarklet/core/Bookmarklet/')) {
    normalized = normalized.replace(/Bookmarklet\/core\/Bookmarklet\//g, 'Bookmarklet/');
  }

  // ★★★ ИСПРАВЛЯЕМ ./Bookmarklet/core/Bookmarklet/ ★★★
  if (normalized.includes('./Bookmarklet/core/Bookmarklet/')) {
    normalized = normalized.replace(/\.\/Bookmarklet\/core\/Bookmarklet\//g, './Bookmarklet/');
  }

  // ★★★ ИСПРАВЛЯЕМ /Bookmarklet/core/Bookmarklet/ ★★★
  if (normalized.includes('/Bookmarklet/core/Bookmarklet/')) {
    normalized = normalized.replace(/\/Bookmarklet\/core\/Bookmarklet\//g, '/Bookmarklet/');
  }

  // Убираем лишние слэши
  normalized = normalized.replace(/\/\//g, '/');

  // Убираем лишние точки
  normalized = normalized.replace(/\.\.\//g, '');

  return normalized;
}

/**
 * Проверяет, является ли путь абсолютным
 */
function isAbsolutePath(path) {
  return path.startsWith('http://') ||
      path.startsWith('https://') ||
      path.startsWith('/') ||
      path.startsWith('file://');
}

/**
 * Добавляет префикс ./ если нужно
 */
function ensureRelativePrefix(path) {
  if (!path) return path;
  if (isAbsolutePath(path)) return path;
  if (path.startsWith('./') || path.startsWith('../')) return path;
  return './' + path;
}

// ============================================================
// 5. ★★★ ПОЛУЧЕНИЕ ПОЛНОГО URL (ИСПРАВЛЕНО) ★★★
// ============================================================

function getFullUrl(modulePath) {
  // ★★★ НОРМАЛИЗУЕМ ПУТЬ ★★★
  let path = normalizePath(modulePath);

  // ★★★ ИСПРАВЛЯЕМ ДУБЛИРОВАНИЕ ★★★
  if (path.includes('Bookmarklet/core/Bookmarklet/')) {
    path = path.replace(/Bookmarklet\/core\/Bookmarklet\//g, 'Bookmarklet/');
  }

  if (path.startsWith('http://') || path.startsWith('https://')) {
    return path;
  }

  let urlPath = path;
  if (urlPath.startsWith('./')) {
    urlPath = urlPath.substring(2);
  }

  if (urlPath.startsWith('/')) {
    return urlPath;
  }

  if (typeof window !== 'undefined') {
    // ★★★ ДОПОЛНИТЕЛЬНАЯ ПРОВЕРКА ★★★
    if (urlPath.includes('Bookmarklet/core/Bookmarklet/')) {
      urlPath = urlPath.replace(/Bookmarklet\/core\/Bookmarklet\//g, 'Bookmarklet/');
    }
    return new URL(urlPath, window.location.origin).href;
  }

  return urlPath;
}

// ============================================================
// 6. ОПРЕДЕЛЕНИЕ ТИПА СКРИПТА
// ============================================================

function detectScriptType(script) {
  if (!script || typeof script !== 'string') return 'unknown';

  // Проверка на ES модуль
  if (script.endsWith('.js') || script.endsWith('.mjs') || script.endsWith('.cjs')) {
    return 'module';
  }

  // Проверка на функцию
  if (script.trim().startsWith('function') || script.includes('=>')) {
    return 'function';
  }

  // По умолчанию - код
  return 'code';
}

// ============================================================
// 7. ЛОГГЕР
// ============================================================

const LOGGER_SYMBOLS = {
  HISTORY: Symbol('logger.history'),
  MAX_HISTORY: Symbol('logger.maxHistory'),
  DEBUG: Symbol('logger.debug'),
  INSTANCE_ID: Symbol('logger.instanceId'),
};

function createLogger(debug = true, instanceId = 'ScriptExecutor') {
  const state = {
    [LOGGER_SYMBOLS.HISTORY]: [],
    [LOGGER_SYMBOLS.MAX_HISTORY]: 200,
    [LOGGER_SYMBOLS.DEBUG]: debug,
    [LOGGER_SYMBOLS.INSTANCE_ID]: instanceId,
  };

  const logMethod = function (level, message, data = null) {
    if (!this[LOGGER_SYMBOLS.DEBUG] && level !== 'error') {
      return;
    }

    const timestamp = new Date().toISOString().slice(11, 23);
    const prefix = `[${timestamp}] [${this[LOGGER_SYMBOLS.INSTANCE_ID]}]`;

    this[LOGGER_SYMBOLS.HISTORY].push({ timestamp, level, message, data });
    if (this[LOGGER_SYMBOLS.HISTORY].length > this[LOGGER_SYMBOLS.MAX_HISTORY]) {
      this[LOGGER_SYMBOLS.HISTORY].shift();
    }

    if (data !== null && data !== undefined) {
      console.log(`${prefix} ${message}`, data);
    } else {
      console.log(`${prefix} ${message}`);
    }
  };

  const boundLog = logMethod.bind(state);

  const methods = {
    error: function (msg, d) {
      boundLog('error', `❌ ${msg}`, d);
    },
    warn: function (msg, d) {
      boundLog('warn', `⚠️ ${msg}`, d);
    },
    info: function (msg, d) {
      boundLog('info', `ℹ️ ${msg}`, d);
    },
    debug: function (msg, d) {
      boundLog('debug', `🔍 ${msg}`, d);
    },
    success: function (msg, d) {
      boundLog('info', `✅ ${msg}`, d);
    },

    header: function (title) {
      console.log('%c' + '═'.repeat(70), 'color: #636e72;');
      console.log(
          '%c  📦 ' + title,
          'background: #1a1a2e; color: #fff; padding: 4px 12px; border-radius: 4px; font-weight: bold;'
      );
      console.log('%c' + '═'.repeat(70), 'color: #636e72;');
    },

    separator: function () {
      console.log('%c' + '─'.repeat(70), 'color: #636e72;');
    },

    group: function (title, collapsed = true) {
      if (collapsed) {
        console.groupCollapsed(`%c📂 ${title}`, 'color: #667eea; font-weight: bold;');
      } else {
        console.group(`%c📂 ${title}`, 'color: #667eea; font-weight: bold;');
      }
      return this;
    },

    groupEnd: function () {
      console.groupEnd();
      return this;
    },

    trace: function (message, data = null) {
      console.log(`%c🔍 ${message}`, 'color: #fdcb6e; font-weight: bold;', data || '');
      console.trace('📍 Stack trace:');
      return this;
    },

    symbol: function (name, symbol) {
      console.log(`  🔑 ${name}: ${String(symbol)}`);
    },

    private: function (name, symbol) {
      console.log(`  🔒 ${name}: ${String(symbol)}`);
    },

    getHistory: function () {
      return [...this[LOGGER_SYMBOLS.HISTORY]];
    },

    clearHistory: function () {
      this[LOGGER_SYMBOLS.HISTORY] = [];
      return this;
    },

    setDebug: function (enabled) {
      this[LOGGER_SYMBOLS.DEBUG] = enabled;
      return this;
    },
  };

  const logger = {};
  for (const [key, fn] of Object.entries(methods)) {
    logger[key] = fn.bind(state);
  }

  logger[LOGGER_SYMBOLS.HISTORY] = state[LOGGER_SYMBOLS.HISTORY];
  logger[LOGGER_SYMBOLS.MAX_HISTORY] = state[LOGGER_SYMBOLS.MAX_HISTORY];
  logger[LOGGER_SYMBOLS.DEBUG] = state[LOGGER_SYMBOLS.DEBUG];
  logger[LOGGER_SYMBOLS.INSTANCE_ID] = state[LOGGER_SYMBOLS.INSTANCE_ID];

  return logger;
}

// ============================================================
// 8. ОСНОВНАЯ ФУНКЦИЯ ЭКСПОРТА
// ============================================================

export async function executeScript(script, props, context) {
  const logger = context._logger || createLogger(true, 'ScriptExecutor');
  const callback = context._callback;

  // ★★★ ГРУППА: ВЫПОЛНЕНИЕ СКРИПТА ★★★
  logger.group('ВЫПОЛНЕНИЕ СКРИПТА', true);
  logger.trace(`📍 Вызов executeScript: ${script}`);

  // ★★★ НОРМАЛИЗУЕМ ПУТЬ ★★★
  const normalizedScript = normalizePath(script);

  if (normalizedScript !== script) {
    logger.debug(`🔄 Путь нормализован: ${script} → ${normalizedScript}`);
  }

  console.log(`  🔍 _executeScript получил script:`, normalizedScript);
  console.log(`  🔍 Тип script: ${typeof normalizedScript}`);
  console.log(`  🔍 Длина script: ${normalizedScript ? normalizedScript.length : 0}`);
  console.log(`  🔍 Props:`, props);
  console.log(`  🔍 Callback: ${typeof callback === 'function' ? '✅' : '❌'}`);
  console.log(`  🔍 Recursive: ${props.isRecursive ? '✅' : '❌'}`);
  console.log(`  🔍 TargetState: ${props.targetState ? '✅' : '❌'}`);
  console.log(`  🔍 Iteration: ${props.recursionIteration || 0}`);

  // ★★★ ПРОВЕРКА ВАЛИДНОСТИ ★★★
  if (!normalizedScript || typeof normalizedScript !== 'string') {
    const error = 'Script is undefined or invalid';
    logger.error(`❌ ${error}`);
    logger.groupEnd();

    const result = {
      success: false,
      error,
      message: 'Скрипт не указан',
      isSingleton: context[PRIVATE.IS_SINGLETON],
      isRecursive: props.isRecursive || false,
    };

    if (typeof callback === 'function') {
      try {
        callback(result);
      } catch (cbError) {
        logger.error(`❌ Ошибка в callback: ${cbError.message}`);
      }
    }
    return result;
  }

  logger.info(`📜 Выполнение скрипта: ${normalizedScript.substring(0, 50)}...`);

  try {
    // ★★★ ОПРЕДЕЛЯЕМ ТИП ★★★
    const scriptType = detectScriptType(normalizedScript);
    logger.debug(`📌 Тип скрипта: ${scriptType}`);

    let result;

    switch (scriptType) {
      case 'module':
        result = await executeModule(normalizedScript, props, context);
        break;
      case 'function':
        result = await executeFunction(normalizedScript, props, context);
        break;
      case 'code':
        result = await executeCode(normalizedScript, props, context);
        break;
      default:
        throw new Error(`Неизвестный тип скрипта: ${scriptType}`);
    }

    logger.groupEnd();
    return result;

  } catch (error) {
    logger.error('❌ Ошибка выполнения скрипта:', error.message);
    logger.trace('📍 Stack trace ошибки:');

    const errorResult = {
      success: false,
      error: error.message,
      stack: error.stack,
      isSingleton: context[PRIVATE.IS_SINGLETON],
      isRecursive: props.isRecursive || false,
    };

    if (typeof callback === 'function') {
      try {
        callback(errorResult);
      } catch (cbError) {
        logger.error(`❌ Ошибка в callback: ${cbError.message}`);
      }
    }

    logger.groupEnd();
    return errorResult;
  }
}

// ============================================================
// 9. ★★★ ВЫПОЛНЕНИЕ ES МОДУЛЯ (ИСПРАВЛЕНО) ★★★
// ============================================================

async function executeModule(script, props, context) {
  const logger = context._logger || createLogger(true, 'ScriptExecutor');
  const callback = context._callback;

  // ★★★ НОРМАЛИЗУЕМ ПУТЬ ★★★
  let modulePath = normalizePath(script);

  // ★★★ ИСПРАВЛЯЕМ ДУБЛИРОВАНИЕ ★★★
  if (modulePath.includes('Bookmarklet/core/Bookmarklet/')) {
    modulePath = modulePath.replace(/Bookmarklet\/core\/Bookmarklet\//g, 'Bookmarklet/');
  }

  // Добавляем ./ если нужно
  if (!modulePath.startsWith('./') && !modulePath.startsWith('http') && !modulePath.startsWith('/') && !modulePath.startsWith('file://')) {
    modulePath = './' + modulePath;
  }

  logger.group(`ЗАГРУЗКА МОДУЛЯ: ${modulePath}`, true);
  logger.trace(`📍 Stack trace загрузки модуля`);
  logger.debug(`📂 Загрузка модуля: ${modulePath}`);
  console.log(`  📦 Загрузка модуля: ${modulePath}`);

  try {
    // ★★★ ПОЛУЧЕНИЕ ПОЛНОГО URL ★★★
    const fullUrl = getFullUrl(modulePath);
    console.log(`  📍 Полный URL: ${fullUrl}`);
    logger.debug(`📍 Полный URL: ${fullUrl}`);

    // Динамический импорт с кеш-бастером
    const module = await import(fullUrl + '?t=' + Date.now());
    console.log(`  📦 Модуль загружен, экспорты:`, Object.keys(module));
    logger.debug(`📦 Модуль загружен, экспорты: ${Object.keys(module).join(', ')}`);

    const result = await handleModuleExports(module, modulePath, props, context);
    logger.groupEnd();
    return result;

  } catch (importError) {
    logger.error(`❌ Ошибка import(): ${importError.message}`);
    console.log(`  ❌ Ошибка загрузки модуля: ${importError.message}`);
    console.log(`  🔄 Fallback: загрузка через script тег`);
    logger.trace(`📍 Stack trace ошибки импорта:`);

    const errorResult = {
      success: false,
      error: importError.message,
      stack: importError.stack,
      module: script,
      fallback: true,
      isSingleton: context[PRIVATE.IS_SINGLETON],
      isRecursive: props.isRecursive || false,
    };

    if (typeof callback === 'function') {
      try {
        callback(errorResult);
      } catch (cbError) {
        logger.error(`❌ Ошибка в callback: ${cbError.message}`);
      }
    }

    // ★★★ FALLBACK ЧЕРЕЗ СКРИПТ ТЕГ ★★★
    const fallbackResult = await loadViaScriptTag(modulePath, props, context);
    logger.groupEnd();
    return fallbackResult;
  }
}

// ============================================================
// 10. ОБРАБОТКА ЭКСПОРТОВ МОДУЛЯ
// ============================================================

async function handleModuleExports(module, modulePath, props, context) {
  const logger = context._logger || createLogger(true, 'ScriptExecutor');
  const callback = context._callback;

  // ★★★ ПРОВЕРКА ЭКСПОРТА ПО УМОЛЧАНИЮ ★★★
  if (module.default && typeof module.default === 'function') {
    console.log(`  ▶️ Вызов экспорта по умолчанию: ${modulePath}`);
    logger.debug(`▶️ Вызов экспорта по умолчанию`);

    try {
      const result = await module.default(props, callback);
      console.log(`  ✅ Модуль выполнен: ${modulePath}`);
      logger.success('✅ Модуль выполнен');

      if (typeof callback === 'function') {
        try {
          callback(result);
        } catch (cbError) {
          logger.error(`❌ Ошибка в callback: ${cbError.message}`);
        }
      }
      return result;
    } catch (moduleError) {
      console.error(`  ❌ Ошибка выполнения модуля: ${modulePath}`, moduleError);
      logger.error(`❌ Ошибка выполнения модуля: ${moduleError.message}`);
      logger.trace(`📍 Stack trace ошибки модуля:`);

      const errorResult = {
        success: false,
        error: moduleError.message,
        stack: moduleError.stack,
        module: modulePath,
        isSingleton: context[PRIVATE.IS_SINGLETON],
        isRecursive: props.isRecursive || false,
      };

      if (typeof callback === 'function') {
        try {
          callback(errorResult);
        } catch (cbError) {
          logger.error(`❌ Ошибка в callback: ${cbError.message}`);
        }
      }
      return errorResult;
    }
  }

  // ★★★ ПРОВЕРКА ДРУГИХ ЭКСПОРТОВ ★★★
  for (const [key, value] of Object.entries(module)) {
    if (typeof value === 'function' && key !== 'default') {
      console.log(`  ▶️ Вызов экспорта: ${key}`);
      logger.debug(`▶️ Вызов экспорта: ${key}`);

      try {
        const result = await value(props, callback);
        console.log(`  ✅ Модуль выполнен через ${key}`);
        logger.success(`✅ Модуль выполнен через ${key}`);

        if (typeof callback === 'function') {
          try {
            callback(result);
          } catch (cbError) {
            logger.error(`❌ Ошибка в callback: ${cbError.message}`);
          }
        }
        return result;
      } catch (moduleError) {
        console.error(`  ❌ Ошибка выполнения ${key}:`, moduleError);
        logger.error(`❌ Ошибка выполнения ${key}: ${moduleError.message}`);
        logger.trace(`📍 Stack trace ошибки ${key}:`);

        const errorResult = {
          success: false,
          error: moduleError.message,
          stack: moduleError.stack,
          module: modulePath,
          export: key,
          isSingleton: context[PRIVATE.IS_SINGLETON],
          isRecursive: props.isRecursive || false,
        };

        if (typeof callback === 'function') {
          try {
            callback(errorResult);
          } catch (cbError) {
            logger.error(`❌ Ошибка в callback: ${cbError.message}`);
          }
        }
        return errorResult;
      }
    }
  }

  // ★★★ ЕСЛИ ЭКСПОРТЫ НЕ НАЙДЕНЫ ★★★
  console.log(`  ✅ Модуль загружен: ${modulePath}`);
  logger.success('✅ Модуль загружен');

  const result = {
    success: true,
    module,
    isSingleton: context[PRIVATE.IS_SINGLETON],
    isRecursive: props.isRecursive || false,
    message: 'Модуль загружен, но экспорт не найден',
  };

  if (typeof callback === 'function') {
    try {
      callback(result);
    } catch (cbError) {
      logger.error(`❌ Ошибка в callback: ${cbError.message}`);
    }
  }
  return result;
}

// ============================================================
// 11. ★★★ FALLBACK ЧЕРЕЗ SCRIPT ТЕГ (ИСПРАВЛЕНО) ★★★
// ============================================================

function loadViaScriptTag(modulePath, props, context) {
  const logger = context._logger || createLogger(true, 'ScriptExecutor');
  const callback = context._callback;

  // ★★★ НОРМАЛИЗУЕМ ПУТЬ ДЛЯ SCRIPT ТЕГА ★★★
  let scriptPath = normalizePath(modulePath);

  // ★★★ ИСПРАВЛЯЕМ ДУБЛИРОВАНИЕ ★★★
  if (scriptPath.includes('Bookmarklet/core/Bookmarklet/')) {
    scriptPath = scriptPath.replace(/Bookmarklet\/core\/Bookmarklet\//g, 'Bookmarklet/');
  }

  // Убираем ./ если есть
  if (scriptPath.startsWith('./')) {
    scriptPath = scriptPath.substring(2);
  }

  // Добавляем / если нужно
  if (!scriptPath.startsWith('/') && !scriptPath.startsWith('http') && !scriptPath.startsWith('file://')) {
    scriptPath = '/' + scriptPath;
  }

  // ★★★ ФИНАЛЬНАЯ ПРОВЕРКА ★★★
  if (scriptPath.includes('Bookmarklet/core/Bookmarklet/')) {
    scriptPath = scriptPath.replace(/Bookmarklet\/core\/Bookmarklet\//g, 'Bookmarklet/');
  }

  logger.group(`ЗАГРУЗКА ЧЕРЕЗ SCRIPT ТЕГ`, true);
  logger.info(`📍 Путь: ${scriptPath}`);
  logger.trace(`📍 Stack trace загрузки через script тег`);
  console.log(`  📍 Загрузка через script тег: ${scriptPath}`);

  return new Promise(resolve => {
    const scriptEl = document.createElement('script');
    scriptEl.type = 'module';
    scriptEl.src = scriptPath + '?t=' + Date.now();

    // Data атрибуты
    scriptEl.dataset.bookmarkletName = context._name;
    scriptEl.dataset.bookmarkletId = context._id;
    scriptEl.dataset.bookmarkletType = context._type;
    scriptEl.dataset.bookmarkletData = props.data ? JSON.stringify(props.data) : '';
    scriptEl.dataset.bookmarkletSingleton = String(context[PRIVATE.IS_SINGLETON]);
    scriptEl.dataset.bookmarkletRecursive = String(props.isRecursive || false);
    scriptEl.dataset.bookmarkletTargetState = props.targetState ? JSON.stringify(props.targetState) : '';
    scriptEl.dataset.bookmarkletIteration = String(props.recursionIteration || 0);

    if (typeof context._callback === 'function') {
      scriptEl.dataset.bookmarkletCallback = 'true';
    }

    const timeout = setTimeout(() => {
      console.log(`  ⏱️ Таймаут загрузки: ${scriptPath}`);
      logger.warn(`⏱️ Таймаут загрузки: ${scriptPath}`);

      const timeoutResult = {
        success: false,
        error: 'Таймаут загрузки скрипта',
        module: modulePath,
        loadedVia: 'script-timeout',
        isSingleton: context[PRIVATE.IS_SINGLETON],
        isRecursive: props.isRecursive || false,
      };

      if (typeof callback === 'function') {
        try {
          callback(timeoutResult);
        } catch (cbError) {
          logger.error(`❌ Ошибка в callback: ${cbError.message}`);
        }
      }
      logger.groupEnd();
      resolve(timeoutResult);
    }, 3000);

    scriptEl.onload = () => {
      clearTimeout(timeout);
      console.log(`  ✅ Загружен через script тег: ${scriptPath}`);
      logger.success(`✅ Загружен через script тег: ${scriptPath}`);

      // Проверка экспортов
      const exports = {
        envPanel: window.__envPanel,
        logsPanel: window.__logsPanel,
        debugPanel: window.__debugPanelV2,
        bookmarkletExports: window.__bookmarkletExports,
        activeComponent: window.__activeComponent,
      };

      console.log(`  📦 Проверка экспортов:`, Object.keys(exports).filter(k => exports[k]));
      logger.debug(`📦 Проверка экспортов: ${Object.keys(exports).filter(k => exports[k]).join(', ')}`);

      // ★★★ ПОИСК И ВЫЗОВ ЭКСПОРТОВ ★★★
      for (const [key, value] of Object.entries(exports)) {
        if (typeof value === 'function') {
          console.log(`  ▶️ Вызов экспорта: ${key}`);
          logger.debug(`▶️ Вызов экспорта: ${key}`);

          try {
            const result = value(props, callback);
            if (result && typeof result.then === 'function') {
              result.then(r => {
                const successResult = {
                  success: true,
                  result: r,
                  loadedVia: 'script',
                  isSingleton: context[PRIVATE.IS_SINGLETON],
                  isRecursive: props.isRecursive || false,
                };
                if (typeof callback === 'function') {
                  try {
                    callback(successResult);
                  } catch (cbError) {
                    logger.error(`❌ Ошибка в callback: ${cbError.message}`);
                  }
                }
                logger.groupEnd();
                resolve(successResult);
              }).catch(err => {
                const errorResult = {
                  success: false,
                  error: err.message,
                  stack: err.stack,
                  loadedVia: 'script',
                  export: key,
                  isSingleton: context[PRIVATE.IS_SINGLETON],
                  isRecursive: props.isRecursive || false,
                };
                if (typeof callback === 'function') {
                  try {
                    callback(errorResult);
                  } catch (cbError) {
                    logger.error(`❌ Ошибка в callback: ${cbError.message}`);
                  }
                }
                logger.groupEnd();
                resolve(errorResult);
              });
            } else {
              const successResult = {
                success: true,
                result,
                loadedVia: 'script',
                isSingleton: context[PRIVATE.IS_SINGLETON],
                isRecursive: props.isRecursive || false,
              };
              if (typeof callback === 'function') {
                try {
                  callback(successResult);
                } catch (cbError) {
                  logger.error(`❌ Ошибка в callback: ${cbError.message}`);
                }
              }
              logger.groupEnd();
              resolve(successResult);
            }
            return;
          } catch (err) {
            const errorResult = {
              success: false,
              error: err.message,
              stack: err.stack,
              loadedVia: 'script',
              export: key,
              isSingleton: context[PRIVATE.IS_SINGLETON],
              isRecursive: props.isRecursive || false,
            };
            if (typeof callback === 'function') {
              try {
                callback(errorResult);
              } catch (cbError) {
                logger.error(`❌ Ошибка в callback: ${cbError.message}`);
              }
            }
            logger.groupEnd();
            resolve(errorResult);
            return;
          }
        }
      }

      // ★★★ УПРАВЛЕНИЕ ПАНЕЛЬЮ (FALLBACK) ★★★
      const panel = window.__envPanel || window.__logsPanel || window.__debugPanelV2;
      if (panel && typeof panel === 'object' && panel.toggle) {
        console.log(`  ▶️ Управление панелью: toggle`);
        logger.debug(`▶️ Управление панелью: toggle`);
        panel.toggle();
        const successResult = {
          success: true,
          panel,
          loadedVia: 'script',
          isSingleton: context[PRIVATE.IS_SINGLETON],
          isRecursive: props.isRecursive || false,
        };
        if (typeof callback === 'function') {
          try {
            callback(successResult);
          } catch (cbError) {
            logger.error(`❌ Ошибка в callback: ${cbError.message}`);
          }
        }
        logger.groupEnd();
        resolve(successResult);
        return;
      }

      // ★★★ ЕСЛИ ЭКСПОРТЫ НЕ НАЙДЕНЫ ★★★
      const successResult = {
        success: true,
        loadedVia: 'script',
        message: 'Скрипт загружен, экспорты проверены',
        isSingleton: context[PRIVATE.IS_SINGLETON],
        isRecursive: props.isRecursive || false,
      };
      if (typeof callback === 'function') {
        try {
          callback(successResult);
        } catch (cbError) {
          logger.error(`❌ Ошибка в callback: ${cbError.message}`);
        }
      }
      logger.groupEnd();
      resolve(successResult);
    };

    scriptEl.onerror = error => {
      clearTimeout(timeout);
      console.log(`  ❌ Ошибка загрузки через script тег:`, error);
      logger.error(`❌ Ошибка загрузки через script тег: ${error.message || 'Неизвестная ошибка'}`);
      logger.trace(`📍 Stack trace ошибки загрузки:`);

      const errorResult = {
        success: false,
        error: error.message || 'Ошибка загрузки скрипта',
        loadedVia: 'script-error',
        isSingleton: context[PRIVATE.IS_SINGLETON],
        isRecursive: props.isRecursive || false,
      };
      if (typeof callback === 'function') {
        try {
          callback(errorResult);
        } catch (cbError) {
          logger.error(`❌ Ошибка в callback: ${cbError.message}`);
        }
      }
      logger.groupEnd();
      resolve(errorResult);
    };

    document.head.appendChild(scriptEl);
  });
}

// ============================================================
// 12. ВЫПОЛНЕНИЕ ФУНКЦИИ
// ============================================================

async function executeFunction(script, props, context) {
  const logger = context._logger || createLogger(true, 'ScriptExecutor');
  const callback = context._callback;

  logger.group(`ВЫПОЛНЕНИЕ ФУНКЦИИ`, true);
  logger.trace(`📍 Stack trace выполнения функции`);
  console.log(`  ▶️ Выполнение функции`);

  try {
    // ★★★ СОЗДАНИЕ ФУНКЦИИ ИЗ КОДА ★★★
    const fn = new Function('props', 'callback', `return (${script})(props, callback);`);
    const result = fn(props, callback);

    console.log(`  ✅ Функция выполнена`);
    logger.success('✅ Функция выполнена');

    if (typeof callback === 'function') {
      try {
        callback({
          success: true,
          result,
          isSingleton: context[PRIVATE.IS_SINGLETON],
          isRecursive: props.isRecursive || false,
        });
      } catch (cbError) {
        logger.error(`❌ Ошибка в callback: ${cbError.message}`);
      }
    }
    logger.groupEnd();
    return result;
  } catch (fnError) {
    console.error(`  ❌ Ошибка выполнения функции:`, fnError);
    logger.error(`❌ Ошибка выполнения функции: ${fnError.message}`);
    logger.trace(`📍 Stack trace ошибки функции:`);

    const errorResult = {
      success: false,
      error: fnError.message,
      stack: fnError.stack,
      isSingleton: context[PRIVATE.IS_SINGLETON],
      isRecursive: props.isRecursive || false,
    };
    if (typeof callback === 'function') {
      try {
        callback(errorResult);
      } catch (cbError) {
        logger.error(`❌ Ошибка в callback: ${cbError.message}`);
      }
    }
    logger.groupEnd();
    return errorResult;
  }
}

// ============================================================
// 13. ВЫПОЛНЕНИЕ КОДА
// ============================================================

async function executeCode(script, props, context) {
  const logger = context._logger || createLogger(true, 'ScriptExecutor');
  const callback = context._callback;

  logger.group(`ВЫПОЛНЕНИЕ КОДА`, true);
  logger.trace(`📍 Stack trace выполнения кода`);
  console.log(`  ▶️ Выполнение кода`);

  try {
    // ★★★ СОЗДАНИЕ ФУНКЦИИ ИЗ КОДА ★★★
    const fn = new Function('props', 'callback', script);
    const result = fn(props, callback);

    console.log(`  ✅ Код выполнен`);
    logger.success('✅ Код выполнен');

    if (typeof callback === 'function') {
      try {
        callback({
          success: true,
          result,
          isSingleton: context[PRIVATE.IS_SINGLETON],
          isRecursive: props.isRecursive || false,
        });
      } catch (cbError) {
        logger.error(`❌ Ошибка в callback: ${cbError.message}`);
      }
    }
    logger.groupEnd();
    return result;
  } catch (codeError) {
    console.error(`  ❌ Ошибка выполнения кода:`, codeError);
    logger.error(`❌ Ошибка выполнения кода: ${codeError.message}`);
    logger.trace(`📍 Stack trace ошибки кода:`);

    const errorResult = {
      success: false,
      error: codeError.message,
      stack: codeError.stack,
      isSingleton: context[PRIVATE.IS_SINGLETON],
      isRecursive: props.isRecursive || false,
    };
    if (typeof callback === 'function') {
      try {
        callback(errorResult);
      } catch (cbError) {
        logger.error(`❌ Ошибка в callback: ${cbError.message}`);
      }
    }
    logger.groupEnd();
    return errorResult;
  }
}

// ============================================================
// 14. ДОПОЛНИТЕЛЬНЫЕ ЭКСПОРТЫ
// ============================================================

export {
  MODULE_PRIVATE,
  PUBLIC_EXECUTOR,
  DEFAULT_CONFIG,
  normalizePath,
  detectScriptType,
  getFullUrl,
  handleModuleExports,
  executeModule,
  executeFunction,
  executeCode,
  loadViaScriptTag,
  createLogger,
};

// ============================================================
// 15. ГЛОБАЛЬНАЯ РЕГИСТРАЦИЯ
// ============================================================

if (typeof window !== 'undefined') {
  window.__scriptExecutor = {
    executeScript,
    normalizePath,
    detectScriptType,
    getFullUrl,
    MODULE_PRIVATE,
    PUBLIC_EXECUTOR,
    DEFAULT_CONFIG,
  };

  console.log('╔═══════════════════════════════════════════════════════════════════╗');
  console.log('║              📦 SCRIPT EXECUTOR (100% СИМВОЛЫ)                  ║');
  console.log('╠═══════════════════════════════════════════════════════════════════╣');
  console.log('║  📋 Все логи выводятся в консоль с цветовой разметкой           ║');
  console.log('║  🔑 Полная изоляция через приватные символы                     ║');
  console.log('║  🔓 Публичные символы через Symbol.for                          ║');
  console.log('║  📦 Выполнение ES модулей, функций и кода                       ║');
  console.log('║  🔄 Fallback через script тег                                  ║');
  console.log('║  🛠️ Нормализация путей (исправлено дублирование)              ║');
  console.log('║  📊 Группировка логов через console.group()                   ║');
  console.log('║  🔍 console.trace() для отладки                               ║');
  console.log('╚═══════════════════════════════════════════════════════════════════╝');

  console.log('📋 ДОСТУПНЫЕ КОМАНДЫ:');
  console.log('  __scriptExecutor.executeScript(script, props, context)');
  console.log('  __scriptExecutor.normalizePath(path)');
  console.log('  __scriptExecutor.detectScriptType(script)');
  console.log('  __scriptExecutor.getFullUrl(path)');
  console.log('');
  console.log('📋 ПРИВАТНЫХ СИМВОЛОВ:', Object.keys(MODULE_PRIVATE).length);
  console.log('📋 ПУБЛИЧНЫХ СИМВОЛОВ:', Object.keys(PUBLIC_EXECUTOR).length);
}
