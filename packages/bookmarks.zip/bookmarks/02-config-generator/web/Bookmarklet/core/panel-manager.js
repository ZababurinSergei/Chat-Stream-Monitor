// web/Bookmarklet/core/panel-manager.js
// ============================================================
// УПРАВЛЕНИЕ ПАНЕЛЬЮ - 100% СИМВОЛЫ
// Версия: 1.0.1
// ИСПРАВЛЕНО: Ошибка ReferenceError: TOGGLE_PANEL is not defined
// ============================================================

// ============================================================
// 1. ИМПОРТЫ СИМВОЛОВ
// ============================================================

import { PRIVATE } from './symbols.js';

// ============================================================
// 2. ПРИВАТНЫЕ СИМВОЛЫ ДЛЯ PANEL-MANAGER
// ============================================================

const PANEL_SYMBOLS = {
  // Основные символы панели
  PANEL_ID: Symbol('panel-manager.panelId'),
  PANEL_ELEMENT: Symbol('panel-manager.panelElement'),
  PANEL_VISIBLE: Symbol('panel-manager.panelVisible'),
  PANEL_ANIMATION: Symbol('panel-manager.panelAnimation'),
  PANEL_TIMEOUT: Symbol('panel-manager.panelTimeout'),

  // Символы конфигурации
  PANEL_CONFIG: Symbol('panel-manager.config'),
  PANEL_STATE: Symbol('panel-manager.state'),

  // Символы методов
  TOGGLE_PANEL: Symbol('panel-manager.togglePanel'),
  SHOW_PANEL: Symbol('panel-manager.showPanel'),
  HIDE_PANEL: Symbol('panel-manager.hidePanel'),
  CHECK_PANEL: Symbol('panel-manager.checkPanel'),
  GET_PANEL_STATE: Symbol('panel-manager.getPanelState'),
  ANIMATE_PANEL: Symbol('panel-manager.animatePanel'),

  // Символы утилит
  SHOW_ERROR: Symbol('panel-manager.showError'),
  REMOVE_ERROR: Symbol('panel-manager.removeError'),
  ERROR_TIMEOUT: Symbol('panel-manager.errorTimeout'),
};

// ============================================================
// 3. ПУБЛИЧНЫЕ СИМВОЛЫ ДЛЯ PANEL-MANAGER
// ============================================================

export const PUBLIC_PANEL_SYMBOLS = {
  API: Symbol.for('panel-manager.api'),
  STATE: Symbol.for('panel-manager.state'),
  CONFIG: Symbol.for('panel-manager.config'),
  EVENTS: Symbol.for('panel-manager.events'),
};

// ============================================================
// 4. КОНФИГУРАЦИЯ ПАНЕЛИ
// ============================================================

const PANEL_CONFIG = {
  [PANEL_SYMBOLS.PANEL_ID]: 'env-control-panel',
  [PANEL_SYMBOLS.PANEL_ANIMATION]: {
    duration: 300,
    scaleIn: 0.95,
    scaleOut: 0.8,
    opacityIn: 1,
    opacityOut: 0,
  },
  [PANEL_SYMBOLS.PANEL_TIMEOUT]: {
    errorDisplay: 8000,
    animationDelay: 50,
  },
  [PANEL_SYMBOLS.PANEL_STATE]: {
    visible: false,
    minimized: false,
    fullscreen: false,
    zIndex: 99999,
  },
};

// ============================================================
// 5. ВНУТРЕННЕЕ СОСТОЯНИЕ (ЧЕРЕЗ СИМВОЛЫ)
// ============================================================

const state = {
  [PANEL_SYMBOLS.PANEL_ELEMENT]: null,
  [PANEL_SYMBOLS.PANEL_VISIBLE]: false,
  [PANEL_SYMBOLS.PANEL_CONFIG]: PANEL_CONFIG,
  [PANEL_SYMBOLS.PANEL_STATE]: { ...PANEL_CONFIG[PANEL_SYMBOLS.PANEL_STATE] },
  [PANEL_SYMBOLS.ERROR_TIMEOUT]: null,
};

// ============================================================
// 6. ЛОГГЕР ДЛЯ PANEL-MANAGER
// ============================================================

const LOGGER_SYMBOLS = {
  HISTORY: Symbol('panel-logger.history'),
  MAX_HISTORY: Symbol('panel-logger.maxHistory'),
  DEBUG: Symbol('panel-logger.debug'),
  INSTANCE_ID: Symbol('panel-logger.instanceId'),
};

function createPanelLogger(debug = true, instanceId = 'PanelManager') {
  const logState = {
    [LOGGER_SYMBOLS.HISTORY]: [],
    [LOGGER_SYMBOLS.MAX_HISTORY]: 50,
    [LOGGER_SYMBOLS.DEBUG]: debug,
    [LOGGER_SYMBOLS.INSTANCE_ID]: instanceId,
  };

  const logMethod = function (level, message, data = null) {
    if (!this[LOGGER_SYMBOLS.DEBUG] && level !== 'error') {
      return;
    }

    const timestamp = new Date().toISOString().slice(11, 23);
    const prefix = `[${timestamp}] [${this[LOGGER_SYMBOLS.INSTANCE_ID]}]`;

    this[LOGGER_SYMBOLS.HISTORY].push({ timestamp, level, message, data });
    if (this[LOGGER_SYMBOLS.HISTORY].length > this[LOGGER_SYMBOLS.MAX_HISTORY]) {
      this[LOGGER_SYMBOLS.HISTORY].shift();
    }

    if (data !== null && data !== undefined) {
      console.log(`${prefix} ${message}`, data);
    } else {
      console.log(`${prefix} ${message}`);
    }
  };

  const boundLog = logMethod.bind(logState);

  return {
    [LOGGER_SYMBOLS.HISTORY]: logState[LOGGER_SYMBOLS.HISTORY],
    [LOGGER_SYMBOLS.MAX_HISTORY]: logState[LOGGER_SYMBOLS.MAX_HISTORY],
    [LOGGER_SYMBOLS.DEBUG]: logState[LOGGER_SYMBOLS.DEBUG],
    [LOGGER_SYMBOLS.INSTANCE_ID]: logState[LOGGER_SYMBOLS.INSTANCE_ID],

    error(msg, d) {
      boundLog('error', `❌ ${msg}`, d);
    },
    warn(msg, d) {
      boundLog('warn', `⚠️ ${msg}`, d);
    },
    info(msg, d) {
      boundLog('info', `ℹ️ ${msg}`, d);
    },
    debug(msg, d) {
      boundLog('debug', `🔍 ${msg}`, d);
    },
    success(msg, d) {
      boundLog('info', `✅ ${msg}`, d);
    },

    header(title) {
      console.log('%c' + '═'.repeat(70), 'color: #636e72;');
      console.log(
        '%c  📦 ' + title,
        'background: #1a1a2e; color: #fff; padding: 4px 12px; border-radius: 4px; font-weight: bold;',
      );
      console.log('%c' + '═'.repeat(70), 'color: #636e72;');
    },

    separator() {
      console.log('%c' + '─'.repeat(70), 'color: #636e72;');
    },

    getHistory() {
      return [...this[LOGGER_SYMBOLS.HISTORY]];
    },

    clearHistory() {
      this[LOGGER_SYMBOLS.HISTORY] = [];
      return this;
    },

    setDebug(enabled) {
      this[LOGGER_SYMBOLS.DEBUG] = enabled;
      return this;
    },
  };
}

// Создаем логгер для panel-manager
const logger = createPanelLogger(true, 'PanelManager');

// ============================================================
// 7. ОСНОВНЫЕ ФУНКЦИИ (100% СИМВОЛЫ) - ИСПРАВЛЕННЫЕ
// ============================================================

/**
 * ★★★ ПЕРЕКЛЮЧЕНИЕ ПАНЕЛИ (СИМВОЛ TOGGLE_PANEL) ★★★
 * ИСПРАВЛЕНО: Правильный доступ к символу через PANEL_SYMBOLS.TOGGLE_PANEL
 */
export function togglePanel(context) {
  return PANEL_SYMBOLS[PANEL_SYMBOLS.TOGGLE_PANEL](context);
}

PANEL_SYMBOLS[PANEL_SYMBOLS.TOGGLE_PANEL] = function (context) {
  const loggerInstance = logger;
  loggerInstance.info('🔄 Переключение панели...');

  const panelId = PANEL_CONFIG[PANEL_SYMBOLS.PANEL_ID];
  const panel = document.getElementById(panelId);

  // ★★★ ПРОВЕРКА СУЩЕСТВОВАНИЯ ПАНЕЛИ ★★★
  if (!panel) {
    loggerInstance.warn(`⚠️ Панель с ID "${panelId}" не найдена`);
    const result = {
      success: false,
      error: 'Панель не найдена',
      code: 'PANEL_NOT_FOUND',
    };
    return result;
  }

  // ★★★ ПОЛУЧЕНИЕ ТЕКУЩЕГО СОСТОЯНИЯ ★★★
  const isVisible = panel.style.display !== 'none';
  state[PANEL_SYMBOLS.PANEL_VISIBLE] = !isVisible;

  // ★★★ АНИМАЦИЯ ПЕРЕКЛЮЧЕНИЯ ★★★
  if (!isVisible) {
    PANEL_SYMBOLS[PANEL_SYMBOLS.SHOW_PANEL](panel, context);
  } else {
    PANEL_SYMBOLS[PANEL_SYMBOLS.HIDE_PANEL](panel, context);
  }

  const result = {
    success: true,
    action: 'toggle',
    visible: !isVisible,
    panelId,
    timestamp: Date.now(),
  };

  loggerInstance.success(`🔄 Панель ${isVisible ? 'скрыта' : 'показана'}`);

  // ★★★ ОБНОВЛЕНИЕ СОСТОЯНИЯ ★★★
  state[PANEL_SYMBOLS.PANEL_STATE].visible = !isVisible;

  return result;
};

/**
 * ★★★ ПОКАЗ ПАНЕЛИ (СИМВОЛ SHOW_PANEL) ★★★
 */
PANEL_SYMBOLS[PANEL_SYMBOLS.SHOW_PANEL] = function (panel, context) {
  const loggerInstance = logger;
  const config = PANEL_CONFIG[PANEL_SYMBOLS.PANEL_ANIMATION];
  const timeout = PANEL_CONFIG[PANEL_SYMBOLS.PANEL_TIMEOUT];

  loggerInstance.info('👁️ Показ панели...');

  // ★★★ УСТАНОВКА СТИЛЕЙ ★★★
  panel.style.display = 'flex';
  panel.style.transform = `scale(${config.scaleIn})`;
  panel.style.opacity = config.opacityOut;
  panel.style.pointerEvents = 'auto';

  // ★★★ АНИМАЦИЯ ПОЯВЛЕНИЯ ★★★
  setTimeout(() => {
    panel.style.transform = 'scale(1)';
    panel.style.opacity = config.opacityIn;
    panel.style.transition = `all ${config.duration}ms ease`;

    // ★★★ ВЫЗОВ CALLBACK ПРИ ПОКАЗЕ ★★★
    if (context && typeof context.onPanelShow === 'function') {
      try {
        context.onPanelShow({
          panel,
          timestamp: Date.now(),
        });
      } catch (error) {
        loggerInstance.error(`❌ Ошибка в onPanelShow: ${error.message}`);
      }
    }

    state[PANEL_SYMBOLS.PANEL_VISIBLE] = true;
    loggerInstance.success('✅ Панель показана');
  }, timeout.animationDelay);

  return true;
};

/**
 * ★★★ СКРЫТИЕ ПАНЕЛИ (СИМВОЛ HIDE_PANEL) ★★★
 */
PANEL_SYMBOLS[PANEL_SYMBOLS.HIDE_PANEL] = function (panel, context) {
  const loggerInstance = logger;
  const config = PANEL_CONFIG[PANEL_SYMBOLS.PANEL_ANIMATION];
  const timeout = PANEL_CONFIG[PANEL_SYMBOLS.PANEL_TIMEOUT];

  loggerInstance.info('🙈 Скрытие панели...');

  // ★★★ АНИМАЦИЯ ИСЧЕЗНОВЕНИЯ ★★★
  panel.style.transform = `scale(${config.scaleOut})`;
  panel.style.opacity = config.opacityOut;
  panel.style.transition = `all ${config.duration}ms ease`;

  // ★★★ СКРЫТИЕ ПОСЛЕ АНИМАЦИИ ★★★
  setTimeout(() => {
    panel.style.display = 'none';
    panel.style.transform = 'scale(1)';
    panel.style.opacity = config.opacityIn;

    // ★★★ ВЫЗОВ CALLBACK ПРИ СКРЫТИИ ★★★
    if (context && typeof context.onPanelHide === 'function') {
      try {
        context.onPanelHide({
          panel,
          timestamp: Date.now(),
        });
      } catch (error) {
        loggerInstance.error(`❌ Ошибка в onPanelHide: ${error.message}`);
      }
    }

    state[PANEL_SYMBOLS.PANEL_VISIBLE] = false;
    loggerInstance.success('✅ Панель скрыта');
  }, config.duration + timeout.animationDelay);

  return true;
};

/**
 * ★★★ ПРОВЕРКА ПАНЕЛИ (СИМВОЛ CHECK_PANEL) ★★★
 */
PANEL_SYMBOLS[PANEL_SYMBOLS.CHECK_PANEL] = function (panelId = null) {
  const loggerInstance = logger;
  const id = panelId || PANEL_CONFIG[PANEL_SYMBOLS.PANEL_ID];

  loggerInstance.debug(`🔍 Проверка панели: ${id}`);

  const panel = document.getElementById(id);
  const exists = !!panel;
  const visible = exists ? panel.style.display !== 'none' : false;

  const result = {
    exists,
    visible,
    id,
    panel,
    state: exists
      ? {
        display: panel.style.display,
        opacity: panel.style.opacity,
        transform: panel.style.transform,
        zIndex: panel.style.zIndex,
      }
      : null,
  };

  loggerInstance.debug(`📊 Состояние панели:`, result);
  return result;
};

/**
 * ★★★ ПОЛУЧЕНИЕ СОСТОЯНИЯ ПАНЕЛИ (СИМВОЛ GET_PANEL_STATE) ★★★
 */
PANEL_SYMBOLS[PANEL_SYMBOLS.GET_PANEL_STATE] = function () {
  const loggerInstance = logger;
  loggerInstance.debug('📊 Получение состояния панели...');

  const stateData = {
    [PANEL_SYMBOLS.PANEL_VISIBLE]: state[PANEL_SYMBOLS.PANEL_VISIBLE],
    [PANEL_SYMBOLS.PANEL_STATE]: { ...state[PANEL_SYMBOLS.PANEL_STATE] },
    [PANEL_SYMBOLS.PANEL_CONFIG]: { ...PANEL_CONFIG },
    panelElement: state[PANEL_SYMBOLS.PANEL_ELEMENT] ? 'exists' : 'null',
    timestamp: Date.now(),
  };

  return stateData;
};

/**
 * ★★★ АНИМАЦИЯ ПАНЕЛИ (СИМВОЛ ANIMATE_PANEL) ★★★
 */
PANEL_SYMBOLS[PANEL_SYMBOLS.ANIMATE_PANEL] = function (panel, animationType, options = {}) {
  const loggerInstance = logger;
  const config = PANEL_CONFIG[PANEL_SYMBOLS.PANEL_ANIMATION];
  const defaultDuration = config.duration;

  loggerInstance.debug(`🎬 Анимация: ${animationType}`);

  const animations = {
    'fade-in': {
      from: { opacity: 0, transform: `scale(0.95)` },
      to: { opacity: 1, transform: `scale(1)` },
    },
    'fade-out': {
      from: { opacity: 1, transform: `scale(1)` },
      to: { opacity: 0, transform: `scale(0.8)` },
    },
    'slide-in': {
      from: { opacity: 0, transform: 'translateY(20px)' },
      to: { opacity: 1, transform: 'translateY(0)' },
    },
    'slide-out': {
      from: { opacity: 1, transform: 'translateY(0)' },
      to: { opacity: 0, transform: 'translateY(20px)' },
    },
    'scale-in': {
      from: { opacity: 0, transform: `scale(${config.scaleIn})` },
      to: { opacity: 1, transform: `scale(1)` },
    },
    'scale-out': {
      from: { opacity: 1, transform: `scale(1)` },
      to: { opacity: 0, transform: `scale(${config.scaleOut})` },
    },
  };

  const animation = animations[animationType];
  if (!animation) {
    loggerInstance.warn(`⚠️ Неизвестный тип анимации: ${animationType}`);
    return false;
  }

  const duration = options.duration || defaultDuration;

  // ★★★ ПРИМЕНЕНИЕ СТИЛЕЙ ★★★
  Object.assign(panel.style, {
    transition: `all ${duration}ms ease`,
    ...animation.from,
  });

  // ★★★ ЗАПУСК АНИМАЦИИ ★★★
  setTimeout(() => {
    Object.assign(panel.style, animation.to);
  }, 50);

  // ★★★ ВЫЗОВ ПОСЛЕ АНИМАЦИИ ★★★
  if (options.onComplete) {
    setTimeout(() => {
      try {
        options.onComplete(panel);
      } catch (error) {
        loggerInstance.error(`❌ Ошибка в onComplete: ${error.message}`);
      }
    }, duration + 50);
  }

  loggerInstance.debug(`✅ Анимация ${animationType} запущена`);
  return true;
};

// ============================================================
// 8. УПРАВЛЕНИЕ ОШИБКАМИ (100% СИМВОЛЫ)
// ============================================================

/**
 * ★★★ ПОКАЗ ОШИБКИ (СИМВОЛ SHOW_ERROR) ★★★
 */
export function showError(message, options = {}) {
  return PANEL_SYMBOLS[PANEL_SYMBOLS.SHOW_ERROR](message, options);
}

PANEL_SYMBOLS[PANEL_SYMBOLS.SHOW_ERROR] = function (message, options = {}) {
  const loggerInstance = logger;
  const timeout = PANEL_CONFIG[PANEL_SYMBOLS.PANEL_TIMEOUT].errorDisplay;
  const duration = options.duration || timeout;

  loggerInstance.error(`❌ Показ ошибки: ${message}`);

  // ★★★ УДАЛЕНИЕ СТАРОЙ ОШИБКИ ★★★
  PANEL_SYMBOLS[PANEL_SYMBOLS.REMOVE_ERROR]();

  // ★★★ СОЗДАНИЕ ЭЛЕМЕНТА ОШИБКИ ★★★
  const errorDiv = document.createElement('div');
  errorDiv.id = 'bookmarklet-error';
  errorDiv.style.cssText = `
    position: fixed;
    bottom: 20px;
    right: 20px;
    background: rgba(255, 107, 107, 0.95);
    color: #fff;
    padding: 15px 20px;
    border-radius: 8px;
    font-family: monospace;
    font-size: 13px;
    max-width: 400px;
    z-index: 999999;
    box-shadow: 0 4px 20px rgba(0,0,0,0.5);
    border: 1px solid rgba(255,255,255,0.1);
    transform: translateX(100%);
    opacity: 0;
    transition: all 0.3s ease;
  `;

  // ★★★ КОНТЕНТ ОШИБКИ ★★★
  errorDiv.innerHTML = `
    <strong>❌ ${options.title || 'Ошибка букмарклета:'}</strong><br>
    ${message}
    ${options.details ? `<br><br><small style="color: rgba(255,255,255,0.7); font-size: 11px;">${options.details}</small>` : ''}
    <br><br>
    <button onclick="this.parentElement.remove()" style="
      background: rgba(255,255,255,0.2);
      border: none;
      color: #fff;
      padding: 4px 12px;
      border-radius: 4px;
      cursor: pointer;
      font-family: inherit;
    ">Закрыть</button>
  `;

  // ★★★ ДОБАВЛЕНИЕ В DOM ★★★
  document.body.appendChild(errorDiv);

  // ★★★ АНИМАЦИЯ ПОЯВЛЕНИЯ ★★★
  setTimeout(() => {
    errorDiv.style.transform = 'translateX(0)';
    errorDiv.style.opacity = '1';
  }, 50);

  // ★★★ АВТОМАТИЧЕСКОЕ УДАЛЕНИЕ ★★★
  state[PANEL_SYMBOLS.ERROR_TIMEOUT] = setTimeout(() => {
    PANEL_SYMBOLS[PANEL_SYMBOLS.REMOVE_ERROR]();
  }, duration);

  return errorDiv;
};

/**
 * ★★★ УДАЛЕНИЕ ОШИБКИ (СИМВОЛ REMOVE_ERROR) ★★★
 */
PANEL_SYMBOLS[PANEL_SYMBOLS.REMOVE_ERROR] = function () {
  const loggerInstance = logger;

  // ★★★ ОЧИСТКА ТАЙМАУТА ★★★
  if (state[PANEL_SYMBOLS.ERROR_TIMEOUT]) {
    clearTimeout(state[PANEL_SYMBOLS.ERROR_TIMEOUT]);
    state[PANEL_SYMBOLS.ERROR_TIMEOUT] = null;
  }

  // ★★★ ПОИСК И УДАЛЕНИЕ ★★★
  const errorDiv = document.getElementById('bookmarklet-error');
  if (errorDiv) {
    // ★★★ АНИМАЦИЯ ИСЧЕЗНОВЕНИЯ ★★★
    errorDiv.style.transform = 'translateX(100%)';
    errorDiv.style.opacity = '0';
    setTimeout(() => {
      if (errorDiv.parentNode) {
        errorDiv.parentNode.removeChild(errorDiv);
        loggerInstance.debug('🗑️ Ошибка удалена');
      }
    }, 300);
    return true;
  }

  return false;
};

// ============================================================
// 9. ДОПОЛНИТЕЛЬНЫЕ УТИЛИТЫ (100% СИМВОЛЫ)
// ============================================================

/**
 * ★★★ ПОЛУЧЕНИЕ КОНФИГУРАЦИИ ПАНЕЛИ ★★★
 */
export function getPanelConfig() {
  return {
    ...PANEL_CONFIG,
    [PANEL_SYMBOLS.PANEL_ID]: PANEL_CONFIG[PANEL_SYMBOLS.PANEL_ID],
    [PANEL_SYMBOLS.PANEL_ANIMATION]: { ...PANEL_CONFIG[PANEL_SYMBOLS.PANEL_ANIMATION] },
    [PANEL_SYMBOLS.PANEL_TIMEOUT]: { ...PANEL_CONFIG[PANEL_SYMBOLS.PANEL_TIMEOUT] },
    [PANEL_SYMBOLS.PANEL_STATE]: { ...state[PANEL_SYMBOLS.PANEL_STATE] },
  };
}

/**
 * ★★★ ОБНОВЛЕНИЕ КОНФИГУРАЦИИ ПАНЕЛИ ★★★
 */
export function updatePanelConfig(config) {
  const loggerInstance = logger;
  loggerInstance.info('⚙️ Обновление конфигурации панели...');

  if (config.panelId) {
    PANEL_CONFIG[PANEL_SYMBOLS.PANEL_ID] = config.panelId;
  }

  if (config.animation) {
    Object.assign(PANEL_CONFIG[PANEL_SYMBOLS.PANEL_ANIMATION], config.animation);
  }

  if (config.timeout) {
    Object.assign(PANEL_CONFIG[PANEL_SYMBOLS.PANEL_TIMEOUT], config.timeout);
  }

  if (config.state) {
    Object.assign(state[PANEL_SYMBOLS.PANEL_STATE], config.state);
  }

  loggerInstance.success('✅ Конфигурация обновлена');
  return getPanelConfig();
}

/**
 * ★★★ СБРОС СОСТОЯНИЯ ПАНЕЛИ ★★★
 */
export function resetPanelState() {
  const loggerInstance = logger;
  loggerInstance.warn('🔄 Сброс состояния панели...');

  // ★★★ СБРОС ВНУТРЕННЕГО СОСТОЯНИЯ ★★★
  state[PANEL_SYMBOLS.PANEL_VISIBLE] = false;
  state[PANEL_SYMBOLS.PANEL_STATE] = { ...PANEL_CONFIG[PANEL_SYMBOLS.PANEL_STATE] };
  state[PANEL_SYMBOLS.PANEL_ELEMENT] = null;

  // ★★★ ОЧИСТКА ОШИБОК ★★★
  PANEL_SYMBOLS[PANEL_SYMBOLS.REMOVE_ERROR]();

  // ★★★ ПОИСК И ОЧИСТКА ПАНЕЛИ ★★★
  const panel = document.getElementById(PANEL_CONFIG[PANEL_SYMBOLS.PANEL_ID]);
  if (panel) {
    panel.style.display = 'none';
    panel.style.opacity = '1';
    panel.style.transform = 'scale(1)';
  }

  loggerInstance.success('✅ Состояние панели сброшено');
  return true;
}

// ============================================================
// 10. ЭКСПОРТ СИМВОЛОВ
// ============================================================

export {
  PANEL_SYMBOLS,
  PANEL_CONFIG,
  state as PANEL_STATE,
  logger as PANEL_LOGGER,
};

// ============================================================
// 11. ГЛОБАЛЬНАЯ РЕГИСТРАЦИЯ (ЧЕРЕЗ СИМВОЛЫ)
// ============================================================

if (typeof window !== 'undefined') {
  // Регистрация через публичные символы
  window[PUBLIC_PANEL_SYMBOLS.API] = {
    togglePanel,
    showPanel: PANEL_SYMBOLS[PANEL_SYMBOLS.SHOW_PANEL],
    hidePanel: PANEL_SYMBOLS[PANEL_SYMBOLS.HIDE_PANEL],
    checkPanel: PANEL_SYMBOLS[PANEL_SYMBOLS.CHECK_PANEL],
    getPanelState: PANEL_SYMBOLS[PANEL_SYMBOLS.GET_PANEL_STATE],
    animatePanel: PANEL_SYMBOLS[PANEL_SYMBOLS.ANIMATE_PANEL],
    showError,
    removeError: PANEL_SYMBOLS[PANEL_SYMBOLS.REMOVE_ERROR],
    getConfig: getPanelConfig,
    updateConfig: updatePanelConfig,
    resetState: resetPanelState,
  };

  window[PUBLIC_PANEL_SYMBOLS.STATE] = PANEL_SYMBOLS[PANEL_SYMBOLS.GET_PANEL_STATE]();
  window[PUBLIC_PANEL_SYMBOLS.CONFIG] = PANEL_CONFIG;
  window[PUBLIC_PANEL_SYMBOLS.EVENTS] = {
    onPanelShow: null,
    onPanelHide: null,
    onPanelToggle: null,
    onError: null,
  };

  // ★★★ ЛОГИРОВАНИЕ ★★★
  const loggerInstance = logger;
  loggerInstance.header('PANEL-MANAGER ЗАГРУЖЕН (100% СИМВОЛЫ)');
  loggerInstance.info(`📌 PANEL_SYMBOLS: ${Object.keys(PANEL_SYMBOLS).length}`);
  loggerInstance.info(`📌 PUBLIC_SYMBOLS: ${Object.keys(PUBLIC_PANEL_SYMBOLS).length}`);
  loggerInstance.success('✅ Panel Manager готов к работе');
  loggerInstance.header('ГОТОВ');

  // ★★★ ЭКСПОРТ В ГЛОБАЛЬНЫЙ ОБЪЕКТ ДЛЯ ОТЛАДКИ ★★★
  window.__panelManager = {
    toggle: togglePanel,
    show: context => {
      const panel = document.getElementById(PANEL_CONFIG[PANEL_SYMBOLS.PANEL_ID]);
      if (panel) {
        return PANEL_SYMBOLS[PANEL_SYMBOLS.SHOW_PANEL](panel, context);
      }
      return false;
    },
    hide: context => {
      const panel = document.getElementById(PANEL_CONFIG[PANEL_SYMBOLS.PANEL_ID]);
      if (panel) {
        return PANEL_SYMBOLS[PANEL_SYMBOLS.HIDE_PANEL](panel, context);
      }
      return false;
    },
    check: PANEL_SYMBOLS[PANEL_SYMBOLS.CHECK_PANEL],
    getState: PANEL_SYMBOLS[PANEL_SYMBOLS.GET_PANEL_STATE],
    animate: PANEL_SYMBOLS[PANEL_SYMBOLS.ANIMATE_PANEL],
    error: showError,
    removeError: PANEL_SYMBOLS[PANEL_SYMBOLS.REMOVE_ERROR],
    config: getPanelConfig,
    updateConfig: updatePanelConfig,
    reset: resetPanelState,
    getSymbols: () => ({
      PANEL_SYMBOLS: { ...PANEL_SYMBOLS },
      PUBLIC_PANEL_SYMBOLS: { ...PUBLIC_PANEL_SYMBOLS },
      LOGGER_SYMBOLS: { ...LOGGER_SYMBOLS },
    }),
  };
}

// ============================================================
// 12. ВСЕ СИМВОЛЫ PANEL-MANAGER (100%)
// ============================================================

console.log('═══════════════════════════════════════════════════════════');
console.log('📋 100% СИМВОЛОВ PANEL-MANAGER:');
console.log('───────────────────────────────────────────────────────────');
console.log(`  🔒 ПРИВАТНЫХ: ${Object.keys(PANEL_SYMBOLS).length}`);
console.log(`  🔓 ПУБЛИЧНЫХ: ${Object.keys(PUBLIC_PANEL_SYMBOLS).length}`);
console.log(`  📝 ЛОГГЕР:    ${Object.keys(LOGGER_SYMBOLS).length}`);
console.log(
  `  📊 ВСЕГО:     ${Object.keys(PANEL_SYMBOLS).length + Object.keys(PUBLIC_PANEL_SYMBOLS).length + Object.keys(LOGGER_SYMBOLS).length}`,
);
console.log('═══════════════════════════════════════════════════════════');
