// core/recursion.js - Логика рекурсии и проверки состояния
// Версия: 1.0.0
// 100% СИМВОЛЫ - полная изоляция и безопасность
// ИСПРАВЛЕНО: удалены дублирующиеся экспорты и синтаксические ошибки

import { PRIVATE } from './symbols.js';

// ============================================================
// 1. СИМВОЛЫ РЕКУРСИИ (100% изоляция)
// ============================================================

// Приватные символы для внутреннего использования
const RECURSION_SYMBOLS = {
  // ──────────────────────────────────────────────────────────
  // ХРАНИЛИЩА (7)
  // ──────────────────────────────────────────────────────────
  CONTEXT: Symbol('recursion.context'), // Контекст выполнения
  STATE: Symbol('recursion.state'), // Состояние обсервера
  LOGGER: Symbol('recursion.logger'), // Логгер
  CONFIG: Symbol('recursion.config'), // Конфигурация
  RESULT: Symbol('recursion.result'), // Результат
  ERROR: Symbol('recursion.error'), // Ошибка
  STACK: Symbol('recursion.stack'), // Стек вызовов

  // ──────────────────────────────────────────────────────────
  // ИСТОРИЯ И КЕШ (3)
  // ──────────────────────────────────────────────────────────
  HISTORY: Symbol('recursion.history'), // История
  TIMERS: Symbol('recursion.timers'), // Таймеры
  CACHE: Symbol('recursion.cache'), // Кеш

  // ──────────────────────────────────────────────────────────
  // СОБЫТИЯ (2)
  // ──────────────────────────────────────────────────────────
  LISTENERS: Symbol('recursion.listeners'), // Слушатели
  EMIT: Symbol('recursion.emit'), // Отправка событий

  // ──────────────────────────────────────────────────────────
  // МЕТОДЫ (11)
  // ──────────────────────────────────────────────────────────
  STEP: Symbol('recursion.step'), // Шаг рекурсии
  LOOP: Symbol('recursion.loop'), // Цикл рекурсии
  CHECK: Symbol('recursion.check'), // Проверка состояния
  VALIDATE: Symbol('recursion.validate'), // Валидация
  RESET: Symbol('recursion.reset'), // Сброс
  DESTROY: Symbol('recursion.destroy'), // Уничтожение
  GET_STATE: Symbol('recursion.getState'), // Получить состояние
  GET_STATS: Symbol('recursion.getStats'), // Получить статистику
  ON: Symbol('recursion.on'), // Подписка
  OFF: Symbol('recursion.off'), // Отписка
};

// Публичные символы для внешнего доступа
const PUBLIC_RECURSION = {
  // ──────────────────────────────────────────────────────────
  // ПУБЛИЧНЫЕ API (6)
  // ──────────────────────────────────────────────────────────
  API: Symbol.for('recursion.api'), // API
  STATE: Symbol.for('recursion.state'), // Состояние
  CONFIG: Symbol.for('recursion.config'), // Конфигурация
  LOGGER: Symbol.for('recursion.logger'), // Логгер
  EVENTS: Symbol.for('recursion.events'), // События
  INSTANCE: Symbol.for('recursion.instance'), // Экземпляр
};

// ============================================================
// 2. ВСПОМОГАТЕЛЬНАЯ ФУНКЦИЯ ДЛЯ ПРОВЕРКИ СОСТОЯНИЯ
// ============================================================

export function checkState(currentState, targetState, logger) {
  // Проверка целевого состояния
  if (!targetState) {
    logger.debug('ℹ️ Целевое состояние не указано');
    return false;
  }

  // Проверка текущего состояния
  if (!currentState) {
    logger.debug('ℹ️ Текущее состояние не определено');
    return false;
  }

  // ★★★ targetState - ФУНКЦИЯ ★★★
  if (typeof targetState === 'function') {
    try {
      const result = targetState(currentState);
      if (typeof result === 'boolean') {return result;}
      if (typeof result === 'object' && result !== null) {
        return checkState(currentState, result, logger);
      }
      return !!result;
    } catch (error) {
      logger.error(`❌ Ошибка в функции проверки состояния: ${error.message}`);
      return false;
    }
  }

  // ★★★ targetState - СТРОКА (JSON) ★★★
  if (typeof targetState === 'string') {
    try {
      const parsed = JSON.parse(targetState);
      return checkState(currentState, parsed, logger);
    } catch {
      const currentStr = typeof currentState === 'string'
        ? currentState
        : JSON.stringify(currentState);
      const result = currentStr === targetState;
      if (result) {logger.success('✅ Состояние соответствует JSON строке');}
      return result;
    }
  }

  // ★★★ targetState - ОБЪЕКТ ★★★
  if (typeof targetState === 'object' && targetState !== null) {
    for (const [key, value] of Object.entries(targetState)) {
      // Проверка наличия ключа
      if (!(key in currentState)) {
        logger.debug(`📌 Ключ "${key}" отсутствует в текущем состоянии`);
        return false;
      }

      const currentValue = currentState[key];

      // Рекурсивная проверка для вложенных объектов
      if (typeof value === 'object' && value !== null) {
        if (!checkState(currentValue, value, logger)) {
          logger.debug(`📌 Вложенный объект "${key}" не соответствует`);
          return false;
        }
      } else if (currentValue !== value) {
        logger.debug(`📌 Значение "${key}" не соответствует: ${currentValue} !== ${value}`);
        return false;
      }
    }

    logger.success('✅ Все поля соответствуют целевому состоянию');
    return true;
  }

  // ★★★ ПРЯМОЕ СРАВНЕНИЕ ★★★
  const currentStr = typeof currentState === 'string'
    ? currentState
    : JSON.stringify(currentState);
  const targetStr = typeof targetState === 'string'
    ? targetState
    : JSON.stringify(targetState);
  const result = currentStr === targetStr;

  if (result) {logger.success('✅ Состояния совпадают');}

  return result;
}

// ============================================================
// 3. РЕКУРСИВНЫЙ ШАГ (ОДИН ШАГ)
// ============================================================

export async function recursiveStep(context, props = {}) {
  // Получение логгера через символы
  const logger = context._logger || console;
  logger.header('🔄 РЕКУРСИВНЫЙ РЕЖИМ (ОДИН ШАГ)');

  // Получение предыдущего результата
  const previousResult = context._result || context._previousResult || null;

  // Формирование рекурсивных данных
  const recursiveData = {
    ...context._data,
    previousResult,
    previousData: context._data,
    timestamp: Date.now(),
    recursiveCall: true,
    recursiveCount: (context._metadata.recursiveCount || 0) + 1,
    targetState: context._targetState,
    maxRecursion: context._maxRecursion,
    recursionIteration: context._recursionIteration,
  };

  // Обновление контекста
  context._data = recursiveData;
  context._previousResult = previousResult;
  context._isRecursive = true;
  context._metadata.recursiveCount = (context._metadata.recursiveCount || 0) + 1;
  context._recursionIteration = (context._recursionIteration || 0) + 1;

  // Логирование
  logger.info(`📌 Рекурсивный вызов #${context._metadata.recursiveCount}`);
  logger.info(`📌 Предыдущий результат: ${previousResult ? '✅' : '❌'}`);
  logger.debug('📌 Данные рекурсивного вызова:', recursiveData);

  // Запуск выполнения
  return context._run();
}

// ============================================================
// 4. БЕСКОНЕЧНАЯ РЕКУРСИЯ ДО ДОСТИЖЕНИЯ СОСТОЯНИЯ
// ============================================================

export async function recursiveLoop(context, props = {}) {
  const logger = context._logger || console;
  logger.header('🔄 БЕСКОНЕЧНАЯ РЕКУРСИЯ');

  // Получение целевого состояния
  const targetState = props.targetState || context._targetState;

  // Проверка наличия целевого состояния
  if (!targetState) {
    const error = 'Не указано целевое состояние для рекурсии';
    logger.error(`❌ ${error}`);
    const result = { success: false, error, message: error };
    if (context[PRIVATE.HANDLE_CALLBACK]) {
      context[PRIVATE.HANDLE_CALLBACK](result);
    }
    return Promise.resolve(result);
  }

  // Получение параметров рекурсии
  const maxRecursion = props.maxRecursion || context._maxRecursion || 100;
  const recursionDelay = props.recursionDelay || context._recursionDelay || 500;
  const callback = props.callback || context._callback;
  const data = props.data || context._data;

  // Логирование параметров
  logger.info(`📌 Целевое состояние:`, targetState);
  logger.info(`📌 Максимальное количество итераций: ${maxRecursion}`);
  logger.info(`📌 Задержка между итерациями: ${recursionDelay}ms`);

  // ★★★ ОСНОВНАЯ РЕКУРСИВНАЯ ФУНКЦИЯ ★★★
  const recursiveLoopFn = async (iteration = 0, previousResult = null) => {
    // ★★★ ПРОВЕРКА ЛИМИТА РЕКУРСИИ ★★★
    if (iteration >= maxRecursion) {
      logger.warn(`⚠️ Достигнут лимит рекурсии (${maxRecursion})`);
      const result = {
        success: false,
        error: 'Достигнут лимит рекурсии',
        iteration,
        maxRecursion,
        currentState: previousResult,
        targetState,
      };
      if (context[PRIVATE.HANDLE_CALLBACK]) {
        context[PRIVATE.HANDLE_CALLBACK](result);
      }
      return result;
    }

    // ★★★ ПРОВЕРКА ДОСТИЖЕНИЯ СОСТОЯНИЯ ★★★
    const isComplete = checkState(previousResult, targetState, logger);

    if (isComplete) {
      logger.success(`✅ Достигнуто целевое состояние на итерации #${iteration}`);
      context._isComplete = true;
      context._activeComponent.isComplete = true;

      const result = {
        success: true,
        message: 'Достигнуто целевое состояние',
        iteration,
        maxRecursion,
        currentState: previousResult,
        targetState,
        isComplete: true,
      };
      if (context[PRIVATE.HANDLE_CALLBACK]) {
        context[PRIVATE.HANDLE_CALLBACK](result);
      }
      return result;
    }

    // ★★★ ВЫПОЛНЕНИЕ ШАГА РЕКУРСИИ ★★★
    logger.info(`🔄 Итерация #${iteration + 1}`);

    const stepProps = {
      ...props,
      data: {
        ...data,
        iteration,
        previousResult,
        targetState,
        maxRecursion,
        recursionDelay,
        timestamp: Date.now(),
      },
      callback: stepResult => {
        logger.debug(`📊 Результат итерации #${iteration + 1}:`, stepResult);
        if (stepResult && stepResult.success === false) {
          logger.error(`❌ Ошибка на итерации #${iteration + 1}: ${stepResult.error}`);
          if (context[PRIVATE.HANDLE_CALLBACK]) {
            context[PRIVATE.HANDLE_CALLBACK](stepResult);
          }
          return stepResult;
        }
      },
    };

    // ★★★ ВЫЗОВ РЕКУРСИВНОГО ШАГА ★★★
    const stepResult = await recursiveStep(context, stepProps);

    // ★★★ ПРОВЕРКА РЕЗУЛЬТАТА ШАГА ★★★
    if (stepResult && stepResult.success === false) {
      logger.error(`❌ Ошибка на итерации #${iteration + 1}: ${stepResult.error}`);
      if (context[PRIVATE.HANDLE_CALLBACK]) {
        context[PRIVATE.HANDLE_CALLBACK](stepResult);
      }
      return stepResult;
    }

    // ★★★ ПРОВЕРКА СОСТОЯНИЯ ПОСЛЕ ШАГА ★★★
    const newState = stepResult || context._result || previousResult;
    const isCompleteAfterStep = checkState(newState, targetState, logger);

    if (isCompleteAfterStep) {
      logger.success(`✅ Достигнуто целевое состояние на итерации #${iteration + 1}`);
      context._isComplete = true;
      context._activeComponent.isComplete = true;

      const result = {
        success: true,
        message: 'Достигнуто целевое состояние',
        iteration: iteration + 1,
        maxRecursion,
        currentState: newState,
        targetState,
        isComplete: true,
      };
      if (context[PRIVATE.HANDLE_CALLBACK]) {
        context[PRIVATE.HANDLE_CALLBACK](result);
      }
      return result;
    }

    // ★★★ ЗАДЕРЖКА ПЕРЕД СЛЕДУЮЩЕЙ ИТЕРАЦИЕЙ ★★★
    logger.info(`⏳ Ожидание ${recursionDelay}ms перед следующей итерацией...`);
    await new Promise(resolve => setTimeout(resolve, recursionDelay));

    // ★★★ РЕКУРСИВНЫЙ ВЫЗОВ ★★★
    return recursiveLoopFn(iteration + 1, newState);
  };

  // ★★★ ЗАПУСК РЕКУРСИВНОЙ ФУНКЦИИ ★★★
  return recursiveLoopFn(0, null);
}

// ============================================================
// 5. КЛАСС ОБСЕРВЕРА ДЛЯ ОТСЛЕЖИВАНИЯ РЕКУРСИИ (100% СИМВОЛЫ)
// ============================================================

export class RecursionObserver {
  constructor(options = {}) {
    // ★★★ ИНИЦИАЛИЗАЦИЯ ЧЕРЕЗ СИМВОЛЫ ★★★

    // Символ контекста
    this[RECURSION_SYMBOLS.CONTEXT] = options.context || null;

    // Символ состояния
    this[RECURSION_SYMBOLS.STATE] = {
      isRunning: false, // Запущен
      isPaused: false, // На паузе
      isStopped: false, // Остановлен
      currentIteration: 0, // Текущая итерация
      maxIterations: options.maxIterations || 100, // Макс. итераций
      startTime: null, // Время старта
      endTime: null, // Время окончания
      results: [], // Результаты
      errors: [], // Ошибки
    };

    // Символ логгера
    this[RECURSION_SYMBOLS.LOGGER] = options.logger || console;

    // Символ конфигурации
    this[RECURSION_SYMBOLS.CONFIG] = {
      ...options,
      maxIterations: options.maxIterations || 100,
      delay: options.delay || 500,
      autoStart: options.autoStart || false,
    };

    // Символ результата
    this[RECURSION_SYMBOLS.RESULT] = null;

    // Символ ошибки
    this[RECURSION_SYMBOLS.ERROR] = null;

    // Символ стека
    this[RECURSION_SYMBOLS.STACK] = [];

    // Символ истории
    this[RECURSION_SYMBOLS.HISTORY] = [];

    // Символ таймеров
    this[RECURSION_SYMBOLS.TIMERS] = new Map();

    // Символ слушателей
    this[RECURSION_SYMBOLS.LISTENERS] = new Map();

    // Символ кеша
    this[RECURSION_SYMBOLS.CACHE] = new Map();

    // ★★★ АВТОЗАПУСК ★★★
    if (this[RECURSION_SYMBOLS.CONFIG].autoStart) {
      this.start();
    }
  }

  // ============================================================
  // 5.1 ★★★ ПУБЛИЧНЫЕ МЕТОДЫ (С ИСПОЛЬЗОВАНИЕМ СИМВОЛОВ) ★★★
  // ============================================================

  // ★★★ ЗАПУСК ★★★
  start() {
    const logger = this[RECURSION_SYMBOLS.LOGGER];
    logger.info('🚀 Запуск рекурсивного обсервера...');
    this[RECURSION_SYMBOLS.STATE].isRunning = true;
    this[RECURSION_SYMBOLS.STATE].startTime = Date.now();
    this[RECURSION_SYMBOLS.EMIT]('start', { timestamp: Date.now() });
    return this;
  }

  // ★★★ ОСТАНОВКА ★★★
  stop() {
    const logger = this[RECURSION_SYMBOLS.LOGGER];
    logger.info('⏹️ Остановка рекурсивного обсервера...');
    this[RECURSION_SYMBOLS.STATE].isRunning = false;
    this[RECURSION_SYMBOLS.STATE].isStopped = true;
    this[RECURSION_SYMBOLS.STATE].endTime = Date.now();
    this[RECURSION_SYMBOLS.EMIT]('stop', { timestamp: Date.now() });
    return this;
  }

  // ★★★ ПАУЗА ★★★
  pause() {
    const logger = this[RECURSION_SYMBOLS.LOGGER];
    logger.info('⏸️ Пауза рекурсивного обсервера...');
    this[RECURSION_SYMBOLS.STATE].isPaused = true;
    this[RECURSION_SYMBOLS.EMIT]('pause', { timestamp: Date.now() });
    return this;
  }

  // ★★★ ВОЗОБНОВЛЕНИЕ ★★★
  resume() {
    const logger = this[RECURSION_SYMBOLS.LOGGER];
    logger.info('▶️ Возобновление рекурсивного обсервера...');
    this[RECURSION_SYMBOLS.STATE].isPaused = false;
    this[RECURSION_SYMBOLS.EMIT]('resume', { timestamp: Date.now() });
    return this;
  }

  // ★★★ СБРОС ★★★
  reset() {
    const logger = this[RECURSION_SYMBOLS.LOGGER];
    logger.warn('🔄 Сброс рекурсивного обсервера...');
    this[RECURSION_SYMBOLS.STATE] = {
      isRunning: false,
      isPaused: false,
      isStopped: false,
      currentIteration: 0,
      maxIterations: this[RECURSION_SYMBOLS.CONFIG].maxIterations || 100,
      startTime: null,
      endTime: null,
      results: [],
      errors: [],
    };
    this[RECURSION_SYMBOLS.RESULT] = null;
    this[RECURSION_SYMBOLS.ERROR] = null;
    this[RECURSION_SYMBOLS.STACK] = [];
    this[RECURSION_SYMBOLS.HISTORY] = [];
    this[RECURSION_SYMBOLS.CACHE].clear();
    this[RECURSION_SYMBOLS.EMIT]('reset', { timestamp: Date.now() });
    return this;
  }

  // ★★★ УНИЧТОЖЕНИЕ ★★★
  destroy() {
    const logger = this[RECURSION_SYMBOLS.LOGGER];
    logger.warn('🗑️ Уничтожение рекурсивного обсервера...');
    this.stop();
    this[RECURSION_SYMBOLS.LISTENERS].clear();
    this[RECURSION_SYMBOLS.TIMERS].clear();
    this[RECURSION_SYMBOLS.CACHE].clear();
    this[RECURSION_SYMBOLS.EMIT]('destroy', { timestamp: Date.now() });
    return this;
  }

  // ============================================================
  // 5.2 ★★★ МЕТОДЫ ДЛЯ РАБОТЫ С РЕЗУЛЬТАТАМИ ★★★
  // ============================================================

  // ★★★ ДОБАВЛЕНИЕ РЕЗУЛЬТАТА ★★★
  addResult(result) {
    this[RECURSION_SYMBOLS.STATE].results.push(result);
    this[RECURSION_SYMBOLS.STATE].currentIteration++;
    this[RECURSION_SYMBOLS.EMIT]('result', {
      result,
      iteration: this[RECURSION_SYMBOLS.STATE].currentIteration,
    });
    return this;
  }

  // ★★★ ДОБАВЛЕНИЕ ОШИБКИ ★★★
  addError(error) {
    this[RECURSION_SYMBOLS.STATE].errors.push(error);
    this[RECURSION_SYMBOLS.EMIT]('error', {
      error,
      iteration: this[RECURSION_SYMBOLS.STATE].currentIteration,
    });
    return this;
  }

  // ★★★ ПОЛУЧЕНИЕ РЕЗУЛЬТАТОВ ★★★
  getResults() {
    return [...this[RECURSION_SYMBOLS.STATE].results];
  }

  // ★★★ ПОЛУЧЕНИЕ ОШИБОК ★★★
  getErrors() {
    return [...this[RECURSION_SYMBOLS.STATE].errors];
  }

  // ★★★ ПОЛУЧЕНИЕ ПОСЛЕДНЕГО РЕЗУЛЬТАТА ★★★
  getLastResult() {
    const results = this[RECURSION_SYMBOLS.STATE].results;
    return results.length > 0 ? results[results.length - 1] : null;
  }

  // ============================================================
  // 5.3 ★★★ СОБЫТИЯ (С ИСПОЛЬЗОВАНИЕМ СИМВОЛОВ) ★★★
  // ============================================================

  // ★★★ ПОДПИСКА ★★★
  on(event, callback) {
    if (typeof callback !== 'function') {
      this[RECURSION_SYMBOLS.LOGGER].warn(`⚠️ Некорректный callback для события ${event}`);
      return () => {};
    }

    if (!this[RECURSION_SYMBOLS.LISTENERS].has(event)) {
      this[RECURSION_SYMBOLS.LISTENERS].set(event, []);
    }
    this[RECURSION_SYMBOLS.LISTENERS].get(event).push(callback);

    return () => this.off(event, callback);
  }

  // ★★★ ОТПИСКА ★★★
  off(event, callback) {
    if (this[RECURSION_SYMBOLS.LISTENERS].has(event)) {
      const listeners = this[RECURSION_SYMBOLS.LISTENERS].get(event);
      const index = listeners.indexOf(callback);
      if (index !== -1) {
        listeners.splice(index, 1);
      }
      if (listeners.length === 0) {
        this[RECURSION_SYMBOLS.LISTENERS].delete(event);
      }
    }
  }

  // ★★★ ОТПРАВКА СОБЫТИЯ ★★★
  emit(event, data) {
    if (this[RECURSION_SYMBOLS.LISTENERS].has(event)) {
      const listeners = this[RECURSION_SYMBOLS.LISTENERS].get(event);
      for (const callback of listeners) {
        try {
          callback(data);
        } catch (error) {
          this[RECURSION_SYMBOLS.LOGGER].error(`❌ Ошибка в обработчике ${event}:`, error);
        }
      }
    }
  }

  // ============================================================
  // 5.4 ★★★ ПОЛУЧЕНИЕ СОСТОЯНИЯ И СТАТИСТИКИ ★★★
  // ============================================================

  // ★★★ ПОЛУЧЕНИЕ СОСТОЯНИЯ ★★★
  getState() {
    return {
      isRunning: this[RECURSION_SYMBOLS.STATE].isRunning,
      isPaused: this[RECURSION_SYMBOLS.STATE].isPaused,
      isStopped: this[RECURSION_SYMBOLS.STATE].isStopped,
      currentIteration: this[RECURSION_SYMBOLS.STATE].currentIteration,
      maxIterations: this[RECURSION_SYMBOLS.STATE].maxIterations,
      startTime: this[RECURSION_SYMBOLS.STATE].startTime,
      endTime: this[RECURSION_SYMBOLS.STATE].endTime,
      resultsCount: this[RECURSION_SYMBOLS.STATE].results.length,
      errorsCount: this[RECURSION_SYMBOLS.STATE].errors.length,
      config: { ...this[RECURSION_SYMBOLS.CONFIG] },
      stackSize: this[RECURSION_SYMBOLS.STACK].length,
      historySize: this[RECURSION_SYMBOLS.HISTORY].length,
      cacheSize: this[RECURSION_SYMBOLS.CACHE].size,
    };
  }

  // ★★★ ПОЛУЧЕНИЕ СТАТИСТИКИ ★★★
  getStats() {
    const state = this[RECURSION_SYMBOLS.STATE];
    const duration = state.startTime && state.endTime
      ? state.endTime - state.startTime
      : Date.now() - (state.startTime || Date.now());

    return {
      totalIterations: state.currentIteration,
      maxIterations: state.maxIterations,
      completionRate: state.maxIterations > 0
        ? (state.currentIteration / state.maxIterations * 100).toFixed(2) + '%'
        : '0%',
      results: state.results.length,
      errors: state.errors.length,
      errorRate: state.currentIteration > 0
        ? (state.errors.length / state.currentIteration * 100).toFixed(2) + '%'
        : '0%',
      duration,
      isRunning: state.isRunning,
      isPaused: state.isPaused,
      isStopped: state.isStopped,
    };
  }

  // ============================================================
  // 5.5 ★★★ ПУБЛИЧНЫЕ МЕТОДЫ (ОБЕРТКИ) ★★★
  // ============================================================

  // Эти методы уже определены выше, но мы их переопределяем для удобства
  // on, off, emit, getState, getStats - уже есть
}

// ============================================================
// 6. ★★★ ЭКСПОРТЫ (БЕЗ ДУБЛИКАТОВ) ★★★
// ============================================================

// ✅ СИМВОЛЫ
export {
  RECURSION_SYMBOLS,
  PUBLIC_RECURSION,
};

// ✅ ГРУППОВОЙ ЭКСПОРТ (без дубликатов)
export default {
  checkState,
  recursiveStep,
  recursiveLoop,
  RecursionObserver,
  RECURSION_SYMBOLS,
  PUBLIC_RECURSION,
};

// ============================================================
// 7. ★★★ ГЛОБАЛЬНАЯ РЕГИСТРАЦИЯ ★★★
// ============================================================

if (typeof window !== 'undefined') {
  // Создаем глобальный обсервер
  const defaultObserver = new RecursionObserver({
    logger: console,
    maxIterations: 100,
    delay: 500,
    autoStart: false,
  });

  window.__recursion = {
    // Функции
    checkState,
    recursiveStep,
    recursiveLoop,

    // Класс
    RecursionObserver,

    // Символы
    RECURSION_SYMBOLS,
    PUBLIC_RECURSION,

    // Обсервер
    observer: defaultObserver,

    // Команды
    createObserver: options => new RecursionObserver(options),
    getDefaultObserver: () => defaultObserver,
  };

  // Публичные символы
  window[PUBLIC_RECURSION.API] = {
    checkState,
    recursiveStep,
    recursiveLoop,
    RecursionObserver,
  };
  window[PUBLIC_RECURSION.STATE] = defaultObserver.getState.bind(defaultObserver);
  window[PUBLIC_RECURSION.CONFIG] = defaultObserver[RECURSION_SYMBOLS.CONFIG];
  window[PUBLIC_RECURSION.LOGGER] = console;
  window[PUBLIC_RECURSION.EVENTS] = {
    on: defaultObserver.on.bind(defaultObserver),
    off: defaultObserver.off.bind(defaultObserver),
    emit: defaultObserver.emit.bind(defaultObserver),
  };
  window[PUBLIC_RECURSION.INSTANCE] = defaultObserver;

  console.log('📦 core/recursion.js загружен (100% СИМВОЛЫ)');
  console.log(`📋 Приватных символов: ${Object.keys(RECURSION_SYMBOLS).length}`);
  console.log(`📋 Публичных символов: ${Object.keys(PUBLIC_RECURSION).length}`);
  console.log('📋 Команды для работы с рекурсией:');
  console.log('  window.__recursion.recursiveStep(context, props)');
  console.log('  window.__recursion.recursiveLoop(context, props)');
  console.log('  window.__recursion.checkState(state, target, logger)');
  console.log('  window.__recursion.createObserver(options)');
  console.log('  window.__recursion.observer.start()');
  console.log('  window.__recursion.observer.stop()');
}
