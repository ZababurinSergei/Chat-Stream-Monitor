// web/Bookmarklet/core/logger.js - Логгер с 100% символами
// Версия: 1.0.2
// ИСПРАВЛЕНО: Добавлены все методы для Bookmarklet (separator, header и др.)

// ============================================================
// 1. ПРИВАТНЫЕ СИМВОЛЫ ДЛЯ ЛОГГЕРА
// ============================================================

export const LOGGER_SYMBOLS = {
    HISTORY: Symbol('logger.history'),
    MAX_HISTORY: Symbol('logger.maxHistory'),
    DEBUG: Symbol('logger.debug'),
    INSTANCE_ID: Symbol('logger.instanceId'),
    LEVEL: Symbol('logger.level'),
    COLORS: Symbol('logger.colors'),
    TIMESTAMP: Symbol('logger.timestamp'),
    FORMATTERS: Symbol('logger.formatters'),
    FILTERS: Symbol('logger.filters'),
    OUTPUTS: Symbol('logger.outputs'),
    CONTEXT: Symbol('logger.context'),
    METADATA: Symbol('logger.metadata'),
    CHILDREN: Symbol('logger.children'),
    PARENT: Symbol('logger.parent'),
    SILENT: Symbol('logger.silent'),
    PRETTY: Symbol('logger.pretty'),
};

// ============================================================
// 2. КОНФИГУРАЦИЯ ЛОГГЕРА
// ============================================================

const DEFAULT_LEVELS = {
    ERROR: 0,
    WARN: 1,
    INFO: 2,
    DEBUG: 3,
    TRACE: 4,
    VERBOSE: 5,
};

const DEFAULT_CONFIG = {
    debug: true,
    maxHistory: 200,
    level: 'INFO',
    colors: true,
    timestamps: true,
    pretty: false,
    silent: false,
};

// ============================================================
// 3. ОСНОВНОЙ КЛАСС ЛОГГЕРА
// ============================================================

export class Logger {
    constructor(options = {}) {
        // ★★★ ИНИЦИАЛИЗАЦИЯ ПРИВАТНЫХ СВОЙСТВ ★★★
        this._instanceId = options.instanceId || 'Logger';
        this._debug = options.debug !== undefined ? options.debug : DEFAULT_CONFIG.debug;
        this._maxHistory = options.maxHistory || DEFAULT_CONFIG.maxHistory;
        this._level = options.level || DEFAULT_CONFIG.level;
        this._colors = options.colors !== undefined ? options.colors : DEFAULT_CONFIG.colors;
        this._timestamp = options.timestamps !== undefined ? options.timestamps : DEFAULT_CONFIG.timestamps;
        this._pretty = options.pretty !== undefined ? options.pretty : DEFAULT_CONFIG.pretty;
        this._silent = options.silent !== undefined ? options.silent : DEFAULT_CONFIG.silent;

        // Хранилища
        this._history = [];
        this._formatters = new Map();
        this._filters = new Map();
        this._outputs = new Map();
        this._context = new Map();
        this._metadata = new Map();
        this._children = new Map();
        this._parent = null;

        // ★★★ УРОВНИ ЛОГГИРОВАНИЯ ★★★
        this._levels = { ...DEFAULT_LEVELS };
        this._levelNames = Object.keys(DEFAULT_LEVELS);

        // ★★★ СТИЛИ ДЛЯ КОНСОЛИ ★★★
        this._styles = {
            error: 'color: #ff6b6b; font-weight: bold;',
            warn: 'color: #fdcb6e; font-weight: bold;',
            info: 'color: #74b9ff; font-weight: bold;',
            debug: 'color: #a29bfe;',
            trace: 'color: #dfe6e9; font-style: italic;',
            verbose: 'color: #636e72; font-size: 11px;',
            success: 'color: #00b894; font-weight: bold;',
        };

        // ★★★ ДОБАВЛЯЕМ ФОРМАТТЕРЫ ★★★
        this._addDefaultFormatters();

        // ★★★ ЛОГИРУЕМ СОЗДАНИЕ ★★★
        if (!this._silent) {
            this.info('📦 Логгер создан', {
                id: this._instanceId,
                level: this._level,
                debug: this._debug,
            });
        }
    }

    // ============================================================
    // 4. ПРИВАТНЫЕ МЕТОДЫ
    // ============================================================

    _addDefaultFormatters() {
        const formatters = this._formatters;

        formatters.set('timestamp', data => {
            if (!this._timestamp) return data;
            const time = new Date().toISOString().slice(11, 23);
            return `[${time}] ${data}`;
        });

        formatters.set('level', (data, level) => {
            const levelColors = {
                ERROR: '🔴',
                WARN: '🟡',
                INFO: '🔵',
                DEBUG: '🟣',
                TRACE: '⚪',
                VERBOSE: '⬜',
                SUCCESS: '🟢',
            };
            const icon = levelColors[level] || '📌';
            return `${icon} [${level}] ${data}`;
        });

        formatters.set('context', data => {
            const context = this._context;
            if (context.size === 0) return data;
            const ctx = {};
            for (const [key, value] of context) {
                ctx[key] = value;
            }
            return `${data} ${JSON.stringify(ctx)}`;
        });

        formatters.set('pretty', data => {
            if (!this._pretty) return data;
            const indent = '  ';
            try {
                if (typeof data === 'object') {
                    return JSON.stringify(data, null, 2).split('\n').map(line => indent + line).join('\n');
                }
                return data;
            } catch {
                return data;
            }
        });
    }

    _getLevelNumber(level) {
        const upper = level.toUpperCase();
        return this._levels[upper] !== undefined ? this._levels[upper] : this._levels.INFO;
    }

    _getLevelName(levelNumber) {
        for (const [name, num] of Object.entries(this._levels)) {
            if (num === levelNumber) return name;
        }
        return 'INFO';
    }

    _shouldLog(level) {
        const currentLevel = this._getLevelNumber(this._level);
        const messageLevel = this._getLevelNumber(level);
        return messageLevel <= currentLevel;
    }

    _formatMessage(level, message, data = null) {
        let formatted = String(message);

        const formatters = this._formatters;
        for (const [name, formatter] of formatters) {
            try {
                if (name === 'level') {
                    formatted = formatter(formatted, level);
                } else if (name === 'timestamp' || name === 'context' || name === 'pretty') {
                    formatted = formatter(formatted);
                }
            } catch (e) {
                // Игнорируем ошибки форматирования
            }
        }

        return { formatted, raw: message, data };
    }

    _log(level, message, data = null) {
        // ★★★ ПРОВЕРКА SILENT ★★★
        if (this._silent) return;

        // ★★★ ПРОВЕРКА УРОВНЯ ★★★
        if (!this._shouldLog(level)) return;

        // ★★★ ФОРМАТИРОВАНИЕ ★★★
        const { formatted, raw, data: logData } = this._formatMessage(level, message, data);

        // ★★★ СОХРАНЕНИЕ В ИСТОРИЮ ★★★
        const entry = {
            timestamp: new Date().toISOString(),
            level,
            message: raw,
            formatted,
            data: logData,
            context: Object.fromEntries(this._context),
            metadata: Object.fromEntries(this._metadata),
        };

        this._history.push(entry);
        if (this._history.length > this._maxHistory) {
            this._history.shift();
        }

        // ★★★ ВЫВОД В КОНСОЛЬ ★★★
        if (this._debug || level === 'ERROR') {
            this._outputToConsole(level, formatted, logData);
        }

        // ★★★ ВЫВОД В ДОПОЛНИТЕЛЬНЫЕ ВЫХОДЫ ★★★
        this._outputToHandlers(level, formatted, logData, entry);

        // ★★★ ПЕРЕДАЧА РОДИТЕЛЮ ★★★
        const parent = this._parent;
        if (parent && typeof parent._log === 'function') {
            parent._log(level, `[${this._instanceId}] ${message}`, data);
        }
    }

    _outputToConsole(level, message, data) {
        const styles = this._colors ? this._styles : {};
        const style = styles[level.toLowerCase()] || styles.info || '';
        const prefix = this._instanceId || 'Logger';

        if (data !== null && data !== undefined) {
            console.log(`%c[${prefix}] ${message}`, style, data);
        } else {
            console.log(`%c[${prefix}] ${message}`, style);
        }
    }

    _outputToHandlers(level, message, data, entry) {
        const outputs = this._outputs;
        for (const [name, handler] of outputs) {
            try {
                handler(level, message, data, entry);
            } catch (e) {
                console.error(`[Logger] Ошибка в выходе "${name}":`, e);
            }
        }
    }

    // ============================================================
    // 5. ПУБЛИЧНЫЕ МЕТОДЫ ЛОГГИРОВАНИЯ
    // ============================================================

    error(message, data = null) {
        this._log('ERROR', message, data);
        return this;
    }

    warn(message, data = null) {
        this._log('WARN', message, data);
        return this;
    }

    info(message, data = null) {
        this._log('INFO', message, data);
        return this;
    }

    debug(message, data = null) {
        this._log('DEBUG', message, data);
        return this;
    }

    trace(message, data = null) {
        this._log('TRACE', message, data);
        return this;
    }

    verbose(message, data = null) {
        this._log('VERBOSE', message, data);
        return this;
    }

    success(message, data = null) {
        this._log('SUCCESS', message, data);
        return this;
    }

    log(message, data = null) {
        this._log('INFO', message, data);
        return this;
    }

    // ============================================================
    // 6. ★★★ МЕТОДЫ ДЛЯ ФОРМАТИРОВАНИЯ ВЫВОДА ★★★
    // ============================================================

    /**
     * Печатает заголовок с рамкой
     */
    header(title) {
        const line = '═'.repeat(70);
        console.log('%c' + line, 'color: #636e72;');
        console.log(
            '%c  📦 ' + title,
            'background: #1a1a2e; color: #fff; padding: 4px 12px; border-radius: 4px; font-weight: bold;'
        );
        console.log('%c' + line, 'color: #636e72;');
        return this;
    }

    /**
     * Печатает разделитель
     */
    separator() {
        console.log('%c' + '─'.repeat(70), 'color: #636e72;');
        return this;
    }

    /**
     * Печатает символ с именем
     */
    symbol(name, symbol) {
        console.log(`  🔑 ${name}: ${String(symbol)}`);
        return this;
    }

    /**
     * Печатает приватный символ
     */
    private(name, symbol) {
        console.log(`  🔒 ${name}: ${String(symbol)}`);
        return this;
    }

    // ============================================================
    // 7. УПРАВЛЕНИЕ УРОВНЯМИ
    // ============================================================

    setLevel(level) {
        const upper = level.toUpperCase();
        if (this._levels[upper] !== undefined) {
            this._level = upper;
            this.info(`🔊 Уровень логирования установлен: ${upper}`);
            return true;
        }
        this.error(`❌ Неизвестный уровень: ${level}`);
        return false;
    }

    getLevel() {
        return this._level;
    }

    getLevelNumber(level) {
        return this._getLevelNumber(level);
    }

    getLevelName(levelNumber) {
        return this._getLevelName(levelNumber);
    }

    // ============================================================
    // 8. УПРАВЛЕНИЕ КОНТЕКСТОМ
    // ============================================================

    setContext(key, value) {
        this._context.set(key, value);
        return this;
    }

    getContext(key) {
        return this._context.get(key) || null;
    }

    clearContext() {
        this._context.clear();
        return this;
    }

    // ============================================================
    // 9. УПРАВЛЕНИЕ МЕТАДАННЫМИ
    // ============================================================

    setMetadata(key, value) {
        this._metadata.set(key, value);
        return this;
    }

    getMetadata(key) {
        return this._metadata.get(key) || null;
    }

    clearMetadata() {
        this._metadata.clear();
        return this;
    }

    // ============================================================
    // 10. УПРАВЛЕНИЕ ФОРМАТТЕРАМИ
    // ============================================================

    addFormatter(name, formatter) {
        if (typeof formatter === 'function') {
            this._formatters.set(name, formatter);
            this.debug(`📌 Добавлен форматтер: ${name}`);
            return this;
        }
        this.error(`❌ Форматтер "${name}" должен быть функцией`);
        return this;
    }

    removeFormatter(name) {
        const result = this._formatters.delete(name);
        if (result) {
            this.debug(`🗑️ Удален форматтер: ${name}`);
        }
        return result;
    }

    getFormatters() {
        return new Map(this._formatters);
    }

    // ============================================================
    // 11. УПРАВЛЕНИЕ ВЫХОДАМИ
    // ============================================================

    addOutput(name, handler) {
        if (typeof handler === 'function') {
            this._outputs.set(name, handler);
            this.debug(`📌 Добавлен выход: ${name}`);
            return this;
        }
        this.error(`❌ Выход "${name}" должен быть функцией`);
        return this;
    }

    removeOutput(name) {
        const result = this._outputs.delete(name);
        if (result) {
            this.debug(`🗑️ Удален выход: ${name}`);
        }
        return result;
    }

    getOutputs() {
        return new Map(this._outputs);
    }

    // ============================================================
    // 12. УПРАВЛЕНИЕ ФИЛЬТРАМИ
    // ============================================================

    addFilter(name, filter) {
        if (typeof filter === 'function') {
            this._filters.set(name, filter);
            this.debug(`📌 Добавлен фильтр: ${name}`);
            return this;
        }
        this.error(`❌ Фильтр "${name}" должен быть функцией`);
        return this;
    }

    removeFilter(name) {
        const result = this._filters.delete(name);
        if (result) {
            this.debug(`🗑️ Удален фильтр: ${name}`);
        }
        return result;
    }

    getFilters() {
        return new Map(this._filters);
    }

    // ============================================================
    // 13. УПРАВЛЕНИЕ ДОЧЕРНИМИ ЛОГГЕРАМИ
    // ============================================================

    child(name, options = {}) {
        const childLogger = new Logger({
            ...options,
            instanceId: `${this._instanceId}:${name}`,
            debug: this._debug,
            maxHistory: this._maxHistory,
            level: this._level,
            colors: this._colors,
            timestamps: this._timestamp,
            pretty: this._pretty,
            silent: this._silent,
        });

        childLogger._parent = this;
        this._children.set(name, childLogger);

        this.debug(`👶 Создан дочерний логгер: ${name}`);
        return childLogger;
    }

    getChild(name) {
        return this._children.get(name) || null;
    }

    getChildren() {
        return new Map(this._children);
    }

    removeChild(name) {
        const child = this._children.get(name);
        if (child) {
            child._parent = null;
            this._children.delete(name);
            this.debug(`🗑️ Удален дочерний логгер: ${name}`);
            return true;
        }
        return false;
    }

    // ============================================================
    // 14. УПРАВЛЕНИЕ ИСТОРИЕЙ
    // ============================================================

    getHistory(level = null) {
        const history = this._history;
        if (level) {
            return history.filter(entry => entry.level === level);
        }
        return [...history];
    }

    clearHistory() {
        this._history = [];
        this.debug('🗑️ История очищена');
        return this;
    }

    getHistorySize() {
        return this._history.length;
    }

    // ============================================================
    // 15. ЭКСПОРТ/ИМПОРТ
    // ============================================================

    exportHistory() {
        return JSON.stringify(this._history, null, 2);
    }

    importHistory(json) {
        try {
            const data = JSON.parse(json);
            if (Array.isArray(data)) {
                this._history = data;
                this.debug(`📥 Импортировано ${data.length} записей`);
                return true;
            }
            return false;
        } catch (e) {
            this.error(`❌ Ошибка импорта: ${e.message}`);
            return false;
        }
    }

    // ============================================================
    // 16. СТАТИСТИКА
    // ============================================================

    getStats() {
        const history = this._history;
        const stats = {
            total: history.length,
            byLevel: {},
            oldest: null,
            newest: null,
        };

        for (const entry of history) {
            stats.byLevel[entry.level] = (stats.byLevel[entry.level] || 0) + 1;
        }

        if (history.length > 0) {
            stats.oldest = history[0].timestamp;
            stats.newest = history[history.length - 1].timestamp;
        }

        return stats;
    }

    // ============================================================
    // 17. НАСТРОЙКИ
    // ============================================================

    setDebug(enabled) {
        this._debug = enabled;
        this.info(`🔍 Режим отладки: ${enabled ? 'включен' : 'выключен'}`);
        return this;
    }

    setColors(enabled) {
        this._colors = enabled;
        this.info(`🎨 Цвета: ${enabled ? 'включены' : 'выключены'}`);
        return this;
    }

    setTimestamps(enabled) {
        this._timestamp = enabled;
        this.info(`🕐 Временные метки: ${enabled ? 'включены' : 'выключены'}`);
        return this;
    }

    setPretty(enabled) {
        this._pretty = enabled;
        this.info(`📐 Pretty-print: ${enabled ? 'включен' : 'выключен'}`);
        return this;
    }

    setSilent(enabled) {
        this._silent = enabled;
        return this;
    }

    getConfig() {
        return {
            instanceId: this._instanceId,
            debug: this._debug,
            maxHistory: this._maxHistory,
            level: this._level,
            colors: this._colors,
            timestamps: this._timestamp,
            pretty: this._pretty,
            silent: this._silent,
            historySize: this._history.length,
            formatters: this._formatters.size,
            outputs: this._outputs.size,
            filters: this._filters.size,
            children: this._children.size,
            context: Object.fromEntries(this._context),
            metadata: Object.fromEntries(this._metadata),
        };
    }

    // ============================================================
    // 18. СПЕЦИАЛЬНЫЕ МЕТОДЫ
    // ============================================================

    group(label) {
        this.info(`📂 ${label}`);
        this._context.set('_group', label);
        return this;
    }

    groupEnd() {
        this._context.delete('_group');
        return this;
    }

    time(label) {
        const start = performance.now();
        this._context.set(`_time_${label}`, start);
        this.debug(`⏱️ Таймер запущен: ${label}`);
        return {
            end: () => {
                const end = performance.now();
                const startTime = this._context.get(`_time_${label}`);
                if (startTime) {
                    const elapsed = (end - startTime).toFixed(2);
                    this.info(`⏱️ ${label}: ${elapsed}ms`);
                    this._context.delete(`_time_${label}`);
                }
                return elapsed;
            },
            lap: name => {
                const end = performance.now();
                const startTime = this._context.get(`_time_${label}`);
                if (startTime) {
                    const elapsed = (end - startTime).toFixed(2);
                    this.debug(`⏱️ ${label} [${name}]: ${elapsed}ms`);
                }
            },
        };
    }

    // ============================================================
    // 19. ★★★ ГЕТТЕРЫ (ТОЛЬКО ДЛЯ ЧТЕНИЯ) ★★★
    // ============================================================

    get [LOGGER_SYMBOLS.INSTANCE_ID]() {
        return this._instanceId;
    }

    get [LOGGER_SYMBOLS.DEBUG]() {
        return this._debug;
    }

    get [LOGGER_SYMBOLS.MAX_HISTORY]() {
        return this._maxHistory;
    }

    get [LOGGER_SYMBOLS.LEVEL]() {
        return this._level;
    }

    get [LOGGER_SYMBOLS.HISTORY]() {
        return this._history;
    }

    get [LOGGER_SYMBOLS.CHILDREN]() {
        return this._children;
    }

    get [LOGGER_SYMBOLS.PARENT]() {
        return this._parent;
    }
}

// ============================================================
// 20. ФАБРИКА ДЛЯ СОЗДАНИЯ ЛОГГЕРА
// ============================================================

export function createLogger(debug = true, instanceId = 'Bookmarklet') {
    return new Logger({
        debug,
        instanceId,
        maxHistory: 200,
        level: 'INFO',
        colors: true,
        timestamps: true,
        pretty: false,
        silent: false,
    });
}

// ============================================================
// 21. ГЛОБАЛЬНЫЙ ЭКЗЕМПЛЯР ЛОГГЕРА
// ============================================================

let globalLogger = null;

export function getGlobalLogger() {
    if (!globalLogger) {
        globalLogger = createLogger(true, 'Global');
    }
    return globalLogger;
}

// ============================================================
// 22. ЭКСПОРТ ПО УМОЛЧАНИЮ
// ============================================================

export default Logger;

// ============================================================
// 23. ИНИЦИАЛИЗАЦИЯ ПРИ ЗАГРУЗКЕ
// ============================================================

if (typeof window !== 'undefined') {
    const logger = createLogger(true, 'Logger');

    window.__logger = {
        Logger,
        createLogger,
        getGlobalLogger,
        LOGGER_SYMBOLS,
        instance: logger,
    };

    console.log('╔═══════════════════════════════════════════════════════════════════╗');
    console.log('║              📦 LOGGER (100% СИМВОЛЫ) v1.0.2                    ║');
    console.log('╠═══════════════════════════════════════════════════════════════════╣');
    console.log('║  ✅ Полная изоляция через приватные символы                     ║');
    console.log('║  ✅ Поддержка уровней логирования                               ║');
    console.log('║  ✅ Контекст и метаданные                                       ║');
    console.log('║  ✅ Дочерние логгеры                                            ║');
    console.log('║  ✅ Форматтеры, фильтры, выходы                                 ║');
    console.log('║  ✅ Экспорт/импорт истории                                      ║');
    console.log('║  ✅ Статистика и конфигурация                                   ║');
    console.log('║  ✅ Методы header(), separator(), symbol(), private()           ║');
    console.log('║  ✅ ИСПРАВЛЕНА: ошибка геттеров                                 ║');
    console.log('║  ✅ ИСПРАВЛЕНА: ошибка separator                               ║');
    console.log('╚═══════════════════════════════════════════════════════════════════╝');

    console.log('📋 ДОСТУПНЫЕ КОМАНДЫ:');
    console.log('  const logger = createLogger(true, "MyApp")');
    console.log('  logger.info("Сообщение")');
    console.log('  logger.error("Ошибка", { code: 500 })');
    console.log('  logger.setLevel("DEBUG")');
    console.log('  logger.setContext("user", "admin")');
    console.log('  logger.child("sub")');
    console.log('  logger.getHistory()');
    console.log('  logger.getStats()');
    console.log('  logger.header("Заголовок")');
    console.log('  logger.separator()');
    console.log('  logger.symbol("name", symbol)');
    console.log('  logger.private("name", symbol)');
    console.log('');
    console.log('📋 ПРИВАТНЫХ СИМВОЛОВ:', Object.keys(LOGGER_SYMBOLS).length);
}
