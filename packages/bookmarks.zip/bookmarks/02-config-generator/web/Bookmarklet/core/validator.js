// ./core/validator.js - 100% СИМВОЛЫ
// Версия: 1.0.0
// Полная изоляция через приватные символы

// ============================================================
// 1. ИМПОРТЫ
// ============================================================

import { PRIVATE } from './symbols.js';

// ============================================================
// 2. ВАЛИДАТОР (100% СИМВОЛЫ)
// ============================================================

export const VALIDATOR = {
  // ★★★ ВАЛИДАТОР СИМВОЛОВ ★★★
  [PRIVATE.VALIDATOR]: {
    /**
         * Проверка ID
         */
    isValidId: id => id && typeof id === 'string' && id.length > 0,

    /**
         * Проверка имени
         */
    isValidName: name => name && typeof name === 'string' && name.length > 0,

    /**
         * Проверка типа букмарклета
         */
    isValidType: type => ['main', 'env', 'logs', 'debug', 'manager', 'widget'].includes(type),

    /**
         * Проверка конфигурации
         */
    isValidConfig: config => config && typeof config === 'object',

    /**
         * Проверка callback функции
         */
    isValidCallback: fn => typeof fn === 'function',

    /**
         * Проверка скрипта
         */
    isValidScript: script => script && typeof script === 'string' && script.length > 0,

    /**
         * Проверка данных
         */
    isValidData: data => data && typeof data === 'object',

    /**
         * Проверка рекурсивной функции
         */
    isValidRecursive: fn => typeof fn === 'function',

    /**
         * Проверка целевого состояния
         */
    isValidTargetState: state => state && typeof state === 'object',

    /**
         * ★★★ ПРОВЕРКА ЭКЗЕМПЛЯРА BOOKMARKLET ★★★
         * Проверяет, является ли объект экземпляром Bookmarklet
         */
    isValidInstance: instance => {
      // Проверяем что instance существует
      if (!instance) {return false;}

      // Проверяем что это объект
      if (typeof instance !== 'object') {return false;}

      // Проверяем что это экземпляр Bookmarklet
      // Используем Symbol для проверки (если доступен)
      try {
        // Проверяем наличие символов PRIVATE
        const hasPrivateSymbols = Object.getOwnPropertySymbols(instance).some(
          sym => String(sym).includes('bookmarklet'),
        );

        // Проверяем наличие ключевых методов
        const hasMethods =
                    typeof instance.getState === 'function' &&
                    typeof instance.update === 'function' &&
                    typeof instance.recursive === 'function' &&
                    typeof instance.recursiveLoop === 'function';

        // Проверяем наличие ключевых свойств
        const hasProperties =
                    instance._id &&
                    instance._name &&
                    instance._type &&
                    instance._logger;

        return hasPrivateSymbols && hasMethods && hasProperties;
      } catch (error) {
        // Если ошибка - возвращаем false
        return false;
      }
    },

    /**
         * ★★★ РАСШИРЕННАЯ ПРОВЕРКА ЭКЗЕМПЛЯРА ★★★
         * Проверяет состояние экземпляра
         */
    isValidInstanceState: instance => {
      if (!VALIDATOR[PRIVATE.VALIDATOR].isValidInstance(instance)) {
        return false;
      }

      // Проверяем состояние
      const state = instance.getState ? instance.getState() : null;
      if (!state) {return false;}

      // Проверяем ключевые поля состояния
      const requiredStateFields = [
        'id', 'name', 'type', 'version',
        'initialized', 'running', 'destroyed',
        'hasScript', 'hasCallback', 'hasData',
        'isSingleton', 'isRecursive',
      ];

      for (const field of requiredStateFields) {
        if (!(field in state)) {
          return false;
        }
      }

      return true;
    },

    /**
         * ★★★ ПРОВЕРКА КОНФИГА ★★★
         */
    isValidConfigFull: config => {
      if (!config || typeof config !== 'object') {return false;}

      const requiredFields = ['name', 'type', 'version', 'debug', 'basePath'];
      for (const field of requiredFields) {
        if (!(field in config)) {
          return false;
        }
      }

      return true;
    },

    /**
         * ★★★ ПРОВЕРКА ТАРГЕТА ★★★
         */
    isValidTarget: target => {
      if (!target) {return false;}

      // Проверяем что это объект, строка или функция
      const targetType = typeof target;
      if (targetType === 'object') {
        // Для объекта проверяем что не null и имеет ключи
        return target !== null && Object.keys(target).length > 0;
      }
      if (targetType === 'string') {
        // Для строки проверяем что не пустая
        return target.length > 0;
      }
      if (targetType === 'function') {
        // Для функции проверяем что это функция
        return true;
      }

      return false;
    },

    /**
         * ★★★ ПРОВЕРКА ДАННЫХ ДЛЯ РЕКУРСИИ ★★★
         */
    isValidRecursiveData: data => {
      if (!data || typeof data !== 'object') {return false;}

      // Проверяем наличие ключевых полей
      const hasRequired =
                'previousResult' in data ||
                'previousData' in data ||
                'recursiveCall' in data ||
                'recursiveCount' in data;

      return hasRequired;
    },

    /**
         * ★★★ ПРОВЕРКА ПАРАМЕТРОВ РЕКУРСИИ ★★★
         */
    isValidRecursiveParams: params => {
      if (!params || typeof params !== 'object') {return false;}

      // Проверяем maxRecursion
      if (params.maxRecursion !== undefined) {
        if (typeof params.maxRecursion !== 'number' || params.maxRecursion <= 0) {
          return false;
        }
      }

      // Проверяем recursionDelay
      if (params.recursionDelay !== undefined) {
        if (typeof params.recursionDelay !== 'number' || params.recursionDelay < 0) {
          return false;
        }
      }

      // Проверяем targetState
      if (params.targetState !== undefined) {
        if (!VALIDATOR[PRIVATE.VALIDATOR].isValidTarget(params.targetState)) {
          return false;
        }
      }

      return true;
    },

    /**
         * ★★★ ПРОВЕРКА CALLBACK С РЕЗУЛЬТАТОМ ★★★
         */
    isValidCallbackResult: result => {
      if (!result || typeof result !== 'object') {return false;}

      // Проверяем наличие success
      if (!('success' in result)) {return false;}

      // Проверяем что success - булево
      if (typeof result.success !== 'boolean') {return false;}

      return true;
    },

    /**
         * ★★★ ПРОВЕРКА СТЕКА РЕКУРСИИ ★★★
         */
    isValidRecursionStack: stack => {
      if (!stack || typeof stack !== 'object') {return false;}

      // Проверяем наличие ключевых полей
      const requiredFields = [
        'iteration', 'maxRecursion', 'currentState', 'targetState',
      ];

      for (const field of requiredFields) {
        if (!(field in stack)) {
          return false;
        }
      }

      // Проверяем типы
      if (typeof stack.iteration !== 'number' || stack.iteration < 0) {
        return false;
      }

      if (typeof stack.maxRecursion !== 'number' || stack.maxRecursion <= 0) {
        return false;
      }

      return true;
    },
  },

  // ★★★ БЕЗОПАСНОСТЬ ★★★
  [PRIVATE.SECURE]: {
    /**
         * Санитайзинг значения
         */
    sanitize: value => {
      if (value === null || value === undefined) {return null;}

      if (typeof value === 'string') {
        return value.replace(/[<>]/g, '');
      }

      if (typeof value === 'object') {
        try {
          return JSON.parse(JSON.stringify(value));
        } catch {
          return null;
        }
      }

      return value;
    },

    /**
         * Валидация значения по схеме
         */
    validate: (value, schema) => {
      if (!schema) {return true;}

      // Проверка типа
      if (schema.type && typeof value !== schema.type) {
        return false;
      }

      // Проверка минимума
      if (schema.min !== undefined && value < schema.min) {
        return false;
      }

      // Проверка максимума
      if (schema.max !== undefined && value > schema.max) {
        return false;
      }

      // Проверка паттерна
      if (schema.pattern && !schema.pattern.test(value)) {
        return false;
      }

      // Проверка enum
      if (schema.enum && !schema.enum.includes(value)) {
        return false;
      }

      // Проверка required
      if (schema.required && schema.required.length > 0) {
        if (typeof value !== 'object' || value === null) {
          return false;
        }
        for (const field of schema.required) {
          if (!(field in value)) {
            return false;
          }
        }
      }

      return true;
    },

    /**
         * ★★★ БЕЗОПАСНОЕ ПОЛУЧЕНИЕ ЗНАЧЕНИЯ ★★★
         */
    safeGet: (obj, path, defaultValue = null) => {
      if (!obj || typeof obj !== 'object') {return defaultValue;}

      const keys = path.split('.');
      let current = obj;

      for (const key of keys) {
        if (current === null || current === undefined || typeof current !== 'object') {
          return defaultValue;
        }
        if (!(key in current)) {
          return defaultValue;
        }
        current = current[key];
      }

      return current !== undefined ? current : defaultValue;
    },

    /**
         * ★★★ БЕЗОПАСНОЕ УСТАНОВЛЕНИЕ ЗНАЧЕНИЯ ★★★
         */
    safeSet: (obj, path, value) => {
      if (!obj || typeof obj !== 'object') {return false;}

      const keys = path.split('.');
      let current = obj;

      for (let i = 0; i < keys.length - 1; i++) {
        const key = keys[i];
        if (!(key in current) || typeof current[key] !== 'object') {
          current[key] = {};
        }
        current = current[key];
      }

      const lastKey = keys[keys.length - 1];
      current[lastKey] = value;

      return true;
    },

    /**
         * ★★★ ГЛУБОКОЕ КЛОНИРОВАНИЕ ★★★
         */
    deepClone: obj => {
      if (obj === null || obj === undefined) {return obj;}

      if (typeof obj !== 'object') {return obj;}

      if (obj instanceof Date) {return new Date(obj.getTime());}

      if (obj instanceof Array) {
        return obj.map(item => VALIDATOR[PRIVATE.SECURE].deepClone(item));
      }

      if (obj instanceof Map) {
        const cloned = new Map();
        for (const [key, value] of obj) {
          cloned.set(key, VALIDATOR[PRIVATE.SECURE].deepClone(value));
        }
        return cloned;
      }

      if (obj instanceof Set) {
        const cloned = new Set();
        for (const value of obj) {
          cloned.add(VALIDATOR[PRIVATE.SECURE].deepClone(value));
        }
        return cloned;
      }

      const cloned = {};
      for (const key in obj) {
        if (Object.prototype.hasOwnProperty.call(obj, key)) {
          try {
            cloned[key] = VALIDATOR[PRIVATE.SECURE].deepClone(obj[key]);
          } catch (error) {
            cloned[key] = obj[key];
          }
        }
      }

      return cloned;
    },

    /**
         * ★★★ БЕЗОПАСНОЕ СРАВНЕНИЕ ★★★
         */
    deepEqual: (a, b) => {
      if (a === b) {return true;}

      if (a === null || b === null) {return false;}

      if (typeof a !== typeof b) {return false;}

      if (typeof a !== 'object') {return a === b;}

      if (a instanceof Date && b instanceof Date) {
        return a.getTime() === b.getTime();
      }

      if (a instanceof Array && b instanceof Array) {
        if (a.length !== b.length) {return false;}
        for (let i = 0; i < a.length; i++) {
          if (!VALIDATOR[PRIVATE.SECURE].deepEqual(a[i], b[i])) {
            return false;
          }
        }
        return true;
      }

      if (a instanceof Map && b instanceof Map) {
        if (a.size !== b.size) {return false;}
        for (const [key, value] of a) {
          if (!b.has(key)) {return false;}
          if (!VALIDATOR[PRIVATE.SECURE].deepEqual(value, b.get(key))) {
            return false;
          }
        }
        return true;
      }

      if (a instanceof Set && b instanceof Set) {
        if (a.size !== b.size) {return false;}
        for (const value of a) {
          if (!b.has(value)) {return false;}
        }
        return true;
      }

      const keysA = Object.keys(a);
      const keysB = Object.keys(b);

      if (keysA.length !== keysB.length) {return false;}

      for (const key of keysA) {
        if (!Object.prototype.hasOwnProperty.call(b, key)) {
          return false;
        }
        if (!VALIDATOR[PRIVATE.SECURE].deepEqual(a[key], b[key])) {
          return false;
        }
      }

      return true;
    },

    /**
         * ★★★ ФИЛЬТРАЦИЯ ОБЪЕКТА ★★★
         */
    filterObject: (obj, allowedKeys) => {
      if (!obj || typeof obj !== 'object') {return {};}

      const filtered = {};
      for (const key of allowedKeys) {
        if (key in obj) {
          try {
            filtered[key] = VALIDATOR[PRIVATE.SECURE].deepClone(obj[key]);
          } catch (error) {
            filtered[key] = obj[key];
          }
        }
      }

      return filtered;
    },

    /**
         * ★★★ ОГРАНИЧЕНИЕ ГЛУБИНЫ ОБЪЕКТА ★★★
         */
    limitDepth: (obj, maxDepth = 3, currentDepth = 0) => {
      if (currentDepth >= maxDepth) {
        if (typeof obj === 'object' && obj !== null) {
          return '[Object]';
        }
        return obj;
      }

      if (obj === null || typeof obj !== 'object') {return obj;}

      if (obj instanceof Date) {return obj.toISOString();}

      if (obj instanceof Array) {
        return obj.map(item => VALIDATOR[PRIVATE.SECURE].limitDepth(item, maxDepth, currentDepth + 1));
      }

      const result = {};
      for (const key in obj) {
        if (Object.prototype.hasOwnProperty.call(obj, key)) {
          try {
            result[key] = VALIDATOR[PRIVATE.SECURE].limitDepth(obj[key], maxDepth, currentDepth + 1);
          } catch (error) {
            result[key] = '[Error]';
          }
        }
      }

      return result;
    },
  },
};

// ============================================================
// 3. ЭКСПОРТ ДОПОЛНИТЕЛЬНЫХ ФУНКЦИЙ
// ============================================================

/**
 * ★★★ УДОБНАЯ ОБЕРТКА ДЛЯ ПРОВЕРКИ ЭКЗЕМПЛЯРА ★★★
 */
export function isValidBookmarkletInstance(instance) {
  return VALIDATOR[PRIVATE.VALIDATOR].isValidInstance(instance);
}

/**
 * ★★★ УДОБНАЯ ОБЕРТКА ДЛЯ ПРОВЕРКИ СОСТОЯНИЯ ★★★
 */
export function isValidBookmarkletState(instance) {
  return VALIDATOR[PRIVATE.VALIDATOR].isValidInstanceState(instance);
}

/**
 * ★★★ УДОБНАЯ ОБЕРТКА ДЛЯ САНИТАЙЗИНГА ★★★
 */
export function sanitizeValue(value) {
  return VALIDATOR[PRIVATE.SECURE].sanitize(value);
}

/**
 * ★★★ УДОБНАЯ ОБЕРТКА ДЛЯ ВАЛИДАЦИИ ★★★
 */
export function validateValue(value, schema) {
  return VALIDATOR[PRIVATE.SECURE].validate(value, schema);
}

/**
 * ★★★ УДОБНАЯ ОБЕРТКА ДЛЯ ГЛУБОКОГО КЛОНИРОВАНИЯ ★★★
 */
export function deepClone(obj) {
  return VALIDATOR[PRIVATE.SECURE].deepClone(obj);
}

/**
 * ★★★ УДОБНАЯ ОБЕРТКА ДЛЯ СРАВНЕНИЯ ★★★
 */
export function deepEqual(a, b) {
  return VALIDATOR[PRIVATE.SECURE].deepEqual(a, b);
}

/**
 * ★★★ УДОБНАЯ ОБЕРТКА ДЛЯ БЕЗОПАСНОГО ПОЛУЧЕНИЯ ★★★
 */
export function safeGet(obj, path, defaultValue = null) {
  return VALIDATOR[PRIVATE.SECURE].safeGet(obj, path, defaultValue);
}

/**
 * ★★★ УДОБНАЯ ОБЕРТКА ДЛЯ БЕЗОПАСНОГО УСТАНОВЛЕНИЯ ★★★
 */
export function safeSet(obj, path, value) {
  return VALIDATOR[PRIVATE.SECURE].safeSet(obj, path, value);
}

/**
 * ★★★ УДОБНАЯ ОБЕРТКА ДЛЯ ОГРАНИЧЕНИЯ ГЛУБИНЫ ★★★
 */
export function limitDepth(obj, maxDepth = 3) {
  return VALIDATOR[PRIVATE.SECURE].limitDepth(obj, maxDepth);
}

// ============================================================
// 4. ГЛОБАЛЬНАЯ РЕГИСТРАЦИЯ
// ============================================================

if (typeof window !== 'undefined') {
  window.__validator = {
    VALIDATOR,
    isValidBookmarkletInstance,
    isValidBookmarkletState,
    sanitizeValue,
    validateValue,
    deepClone,
    deepEqual,
    safeGet,
    safeSet,
    limitDepth,
    getSymbols: () => ({
      PRIVATE: { ...PRIVATE },
    }),
  };

  console.log('╔═══════════════════════════════════════════════════════════════════════════════╗');
  console.log('║              📦 VALIDATOR (100% СИМВОЛЫ)                                    ║');
  console.log('╠═══════════════════════════════════════════════════════════════════════════════╣');
  console.log('║  ✅ Полная изоляция через приватные символы                                 ║');
  console.log('║  ✅ Валидация экземпляров Bookmarklet                                       ║');
  console.log('║  ✅ Санитайзинг и безопасность данных                                       ║');
  console.log('║  ✅ Глубокое клонирование и сравнение                                       ║');
  console.log('║  ✅ Ограничение глубины объектов                                            ║');
  console.log('║  ✅ Безопасное получение и установка значений                               ║');
  console.log('╚═══════════════════════════════════════════════════════════════════════════════╝');

  console.log('📋 ДОСТУПНЫЕ КОМАНДЫ:');
  console.log('  __validator.isValidBookmarkletInstance(instance) - проверка экземпляра');
  console.log('  __validator.isValidBookmarkletState(instance)    - проверка состояния');
  console.log('  __validator.sanitizeValue(value)                 - санитайзинг');
  console.log('  __validator.validateValue(value, schema)         - валидация');
  console.log('  __validator.deepClone(obj)                       - глубокое клонирование');
  console.log('  __validator.deepEqual(a, b)                      - сравнение');
  console.log('  __validator.safeGet(obj, path)                   - безопасное получение');
  console.log('  __validator.safeSet(obj, path, value)            - безопасное установление');
  console.log('  __validator.limitDepth(obj, maxDepth)            - ограничение глубины');
}

// ============================================================
// 5. ЭКСПОРТ ПО УМОЛЧАНИЮ
// ============================================================

export default VALIDATOR;
