// manager.js - Управление букмарклетом
// 100% СИМВОЛЫ — полная изоляция и безопасность
// Версия: 2.1.0
// ИСПРАВЛЕНО: Добавлены await для асинхронных операций
// ИСПРАВЛЕНО: Полная изоляция через приватные символы

// ============================================================
// 1. ПРИВАТНЫЕ СИМВОЛЫ (100% изоляция)
// ============================================================

const PRIVATE = {
  // Основные символы
  CONFIG: Symbol('manager.config'),
  LOGGER: Symbol('manager.logger'),
  STATE: Symbol('manager.state'),
  CACHE: Symbol('manager.cache'),
  VERSION: Symbol('manager.version'),
  BUILD: Symbol('manager.build'),
  INITIALIZED: Symbol('manager.initialized'),
  IS_RUNNING: Symbol('manager.isRunning'),
  IS_DESTROYED: Symbol('manager.isDestroyed'),

  // DOM элементы
  LOG_CONTAINER: Symbol('manager.logContainer'),
  SW_STATUS: Symbol('manager.swStatus'),
  SM_STATUS: Symbol('manager.smStatus'),
  COI_STATUS: Symbol('manager.coiStatus'),
  INSTANCES_COUNT: Symbol('manager.instancesCount'),
  INSTANCES_LIST: Symbol('manager.instancesList'),
  BOOKMARKLET_STATUS: Symbol('manager.bookmarkletStatus'),
  BOOKMARKLET_CODE: Symbol('manager.bookmarkletCode'),

  // Данные
  LOGS: Symbol('manager.logs'),
  MAX_LOGS: Symbol('manager.maxLogs'),
  INSTANCES: Symbol('manager.instances'),
  CURRENT_INSTANCE: Symbol('manager.currentInstance'),
  BOOKMARKLETS: Symbol('manager.bookmarklets'),
  REGISTRATION: Symbol('manager.registration'),

  // Таймеры
  TIMERS: Symbol('manager.timers'),
  CHECK_INTERVAL: Symbol('manager.checkInterval'),

  // Слушатели
  LISTENERS: Symbol('manager.listeners'),
  EVENT_HANDLERS: Symbol('manager.eventHandlers'),
  STORAGE_LISTENER: Symbol('manager.storageListener'),
  SW_LISTENER: Symbol('manager.swListener'),

  // Методы (приватные)
  INIT: Symbol('manager.init'),
  ADD_LOG: Symbol('manager.addLog'),
  CLEAR_LOGS: Symbol('manager.clearLogs'),
  CHECK_ALL: Symbol('manager.checkAll'),
  CHECK_SW: Symbol('manager.checkSW'),
  CHECK_SHARED_MEMORY: Symbol('manager.checkSharedMemory'),
  CHECK_INSTANCES: Symbol('manager.checkInstances'),
  CHECK_BOOKMARKLET: Symbol('manager.checkBookmarklet'),
  REGISTER_SW: Symbol('manager.registerSW'),
  RUN_BOOKMARKLET: Symbol('manager.runBookmarklet'),
  CLEAR_CACHE: Symbol('manager.clearCache'),
  RESET_ALL: Symbol('manager.resetAll'),
  COPY_BOOKMARKLET: Symbol('manager.copyBookmarklet'),
  COPY_MANAGER_BOOKMARKLET: Symbol('manager.copyManagerBookmarklet'),
  UPDATE_STATUS: Symbol('manager.updateStatus'),
  SAVE_STATE: Symbol('manager.saveState'),
  LOAD_STATE: Symbol('manager.loadState'),
  DESTROY: Symbol('manager.destroy'),
  EMIT: Symbol('manager.emit'),
  ON: Symbol('manager.on'),
  OFF: Symbol('manager.off'),
  LOG: Symbol('manager.log'),
  DEBUG: Symbol('manager.debug'),
  ERROR: Symbol('manager.error'),
  WARN: Symbol('manager.warn'),
  INFO: Symbol('manager.info'),
  SUCCESS: Symbol('manager.success'),
  TRACE: Symbol('manager.trace'),
};

// ============================================================
// 2. ПУБЛИЧНЫЕ СИМВОЛЫ (доступны через Symbol.for)
// ============================================================

const PUBLIC = {
  API: Symbol.for('manager.api'),
  STATE: Symbol.for('manager.state'),
  CONFIG: Symbol.for('manager.config'),
  LOGGER: Symbol.for('manager.logger'),
  EVENTS: Symbol.for('manager.events'),
  INSTANCE: Symbol.for('manager.instance'),
  ACTIONS: Symbol.for('manager.actions'),
  STATS: Symbol.for('manager.stats'),
};

// ============================================================
// 3. КОНФИГУРАЦИЯ (100% СИМВОЛЫ)
// ============================================================

const CONFIG_SYMBOLS = {
  MAX_LOGS: Symbol('config.maxLogs'),
  CHECK_INTERVAL: Symbol('config.checkInterval'),
  STORAGE_KEY: Symbol('config.storageKey'),
  SW_SCOPE: Symbol('config.swScope'),
  SW_URL: Symbol('config.swUrl'),
  BOOKMARKLET_PATH: Symbol('config.bookmarkletPath'),
  MANAGER_PATH: Symbol('config.managerPath'),
  VERSION: Symbol('config.version'),
  BUILD: Symbol('config.build'),
  DEBUG: Symbol('config.debug'),
};

const CONFIG = {
  [CONFIG_SYMBOLS.MAX_LOGS]: 50,
  [CONFIG_SYMBOLS.CHECK_INTERVAL]: 10000,
  [CONFIG_SYMBOLS.STORAGE_KEY]: 'manager-state',
  [CONFIG_SYMBOLS.SW_SCOPE]: './',
  [CONFIG_SYMBOLS.SW_URL]: './sw.js',
  [CONFIG_SYMBOLS.BOOKMARKLET_PATH]: './Bookmarklet/bookmarklet.js',
  [CONFIG_SYMBOLS.MANAGER_PATH]: './Bookmarklet/manager.html',
  [CONFIG_SYMBOLS.VERSION]: '2.1.0',
  [CONFIG_SYMBOLS.BUILD]: '2026-07-22',
  [CONFIG_SYMBOLS.DEBUG]: true,
};

// ============================================================
// 4. ЛОГГЕР (100% СИМВОЛЫ)
// ============================================================

const LOGGER_SYMBOLS = {
  HISTORY: Symbol('logger.history'),
  MAX_HISTORY: Symbol('logger.maxHistory'),
  DEBUG: Symbol('logger.debug'),
  INSTANCE_ID: Symbol('logger.instanceId'),
  LEVEL: Symbol('logger.level'),
  TIMESTAMP: Symbol('logger.timestamp'),
  COLORS: Symbol('logger.colors'),
  OUTPUT: Symbol('logger.output'),
  CONTEXT: Symbol('logger.context'),
  METADATA: Symbol('logger.metadata'),
  FILTERS: Symbol('logger.filters'),
  FORMATTERS: Symbol('logger.formatters'),
  SILENT: Symbol('logger.silent'),
  PRETTY: Symbol('logger.pretty'),
  GROUP_LEVEL: Symbol('logger.groupLevel'),
  INDENT: Symbol('logger.indent'),
};

function createManagerLogger(debug = true, instanceId = 'Manager') {
  const loggerState = {
    [LOGGER_SYMBOLS.HISTORY]: [],
    [LOGGER_SYMBOLS.MAX_HISTORY]: 200,
    [LOGGER_SYMBOLS.DEBUG]: debug,
    [LOGGER_SYMBOLS.INSTANCE_ID]: instanceId,
    [LOGGER_SYMBOLS.LEVEL]: 'info',
    [LOGGER_SYMBOLS.TIMESTAMP]: true,
    [LOGGER_SYMBOLS.COLORS]: true,
    [LOGGER_SYMBOLS.OUTPUT]: console,
    [LOGGER_SYMBOLS.CONTEXT]: new Map(),
    [LOGGER_SYMBOLS.METADATA]: new Map(),
    [LOGGER_SYMBOLS.FILTERS]: new Map(),
    [LOGGER_SYMBOLS.FORMATTERS]: new Map(),
    [LOGGER_SYMBOLS.SILENT]: false,
    [LOGGER_SYMBOLS.PRETTY]: false,
    [LOGGER_SYMBOLS.GROUP_LEVEL]: 0,
    [LOGGER_SYMBOLS.INDENT]: 0,
  };

  const logMethod = function (level, message, data = null) {
    if (this[LOGGER_SYMBOLS.SILENT]) return;
    if (!this[LOGGER_SYMBOLS.DEBUG] && level !== 'error' && level !== 'fatal') return;

    const levels = { error: 0, warn: 1, info: 2, debug: 3, trace: 4, verbose: 5 };
    const currentLevel = levels[this[LOGGER_SYMBOLS.LEVEL]] || 2;
    const messageLevel = levels[level] || 2;
    if (messageLevel > currentLevel) return;

    const timestamp = this[LOGGER_SYMBOLS.TIMESTAMP]
        ? `[${new Date().toISOString().slice(11, 23)}]`
        : '';
    const indent = '  '.repeat(this[LOGGER_SYMBOLS.INDENT] || 0);
    const prefix = `${timestamp} [${this[LOGGER_SYMBOLS.INSTANCE_ID]}]${indent}`;
    const output = this[LOGGER_SYMBOLS.OUTPUT];

    // Проверяем фильтры
    let shouldLog = true;
    for (const [name, filter] of this[LOGGER_SYMBOLS.FILTERS]) {
      try {
        if (!filter(level, message, data)) {
          shouldLog = false;
          break;
        }
      } catch (e) {}
    }
    if (!shouldLog) return;

    this[LOGGER_SYMBOLS.HISTORY].push({ timestamp, level, message, data });
    if (this[LOGGER_SYMBOLS.HISTORY].length > this[LOGGER_SYMBOLS.MAX_HISTORY]) {
      this[LOGGER_SYMBOLS.HISTORY].shift();
    }

    // Форматирование
    let formattedMessage = message;
    for (const [name, formatter] of this[LOGGER_SYMBOLS.FORMATTERS]) {
      try {
        formattedMessage = formatter(formattedMessage, data);
      } catch (e) {}
    }

    const styles = this[LOGGER_SYMBOLS.COLORS]
        ? {
          error: 'color: #ff6b6b; font-weight: bold;',
          fatal: 'color: #ff0000; font-weight: bold; font-size: 14px;',
          warn: 'color: #fdcb6e; font-weight: bold;',
          info: 'color: #74b9ff; font-weight: bold;',
          debug: 'color: #a29bfe;',
          trace: 'color: #dfe6e9; font-style: italic;',
          verbose: 'color: #636e72; font-size: 11px;',
          success: 'color: #00b894; font-weight: bold;',
        }
        : {};

    const style = styles[level] || styles.info;

    // Контекст
    let contextStr = '';
    if (this[LOGGER_SYMBOLS.CONTEXT].size > 0) {
      const ctx = {};
      for (const [key, value] of this[LOGGER_SYMBOLS.CONTEXT]) {
        ctx[key] = value;
      }
      contextStr = ` [${JSON.stringify(ctx)}]`;
    }

    if (data !== null && data !== undefined) {
      if (typeof data === 'object' && this[LOGGER_SYMBOLS.PRETTY]) {
        output.log(`%c${prefix}${formattedMessage}${contextStr}`, style);
        output.log('%c  📦 ' + JSON.stringify(data, null, 2), 'color: #fdcb6e;');
      } else if (typeof data === 'object') {
        output.log(`%c${prefix}${formattedMessage}${contextStr}`, style, data);
      } else {
        output.log(`%c${prefix}${formattedMessage}${contextStr}`, style, data);
      }
    } else {
      output.log(`%c${prefix}${formattedMessage}${contextStr}`, style);
    }
  };

  const boundLog = logMethod.bind(loggerState);

  const logger = {
        // Основные методы логирования
        error: (msg, d) => boundLog('error', `❌ ${msg}`, d),
        warn: (msg, d) => boundLog('warn', `⚠️ ${msg}`, d),
        info: (msg, d) => boundLog('info', `ℹ️ ${msg}`, d),
        debug: (msg, d) => boundLog('debug', `🔍 ${msg}`, d),
        success: (msg, d) => boundLog('info', `✅ ${msg}`, d),
        trace: (msg, d) => boundLog('trace', `🔎 ${msg}`, d),
        verbose: (msg, d) => boundLog('verbose', `📝 ${msg}`, d),
        fatal: (msg, d) => boundLog('fatal', `💀 ${msg}`, d),

        // Заголовок и разделители
        header: (title) => {
          const output = loggerState[LOGGER_SYMBOLS.OUTPUT];
          output.log('%c' + '═'.repeat(70), 'color: #636e72;');
          output.log(
              '%c  📦 ' + title,
              'background: #1a1a2e; color: #fff; padding: 4px 12px; border-radius: 4px; font-weight: bold;'
          );
          output.log('%c' + '═'.repeat(70), 'color: #636e72;');
        },

        separator: () => {
          const output = loggerState[LOGGER_SYMBOLS.OUTPUT];
          output.log('%c' + '─'.repeat(70), 'color: #636e72;');
        },

        subheader: (title) => {
          const output = loggerState[LOGGER_SYMBOLS.OUTPUT];
          output.log('%c' + '┌' + '─'.repeat(68) + '┐', 'color: #636e72;');
          output.log(`%c│  📌 ${title.padEnd(65)}│`, 'color: #74b9ff;');
          output.log('%c' + '└' + '─'.repeat(68) + '┘', 'color: #636e72;');
        },

        // Управление отступами
        indent: () => {
          loggerState[LOGGER_SYMBOLS.INDENT] = (loggerState[LOGGER_SYMBOLS.INDENT] || 0) + 1;
          return logger;
        },

        outdent: () => {
          loggerState[LOGGER_SYMBOLS.INDENT] = Math.max(0, (loggerState[LOGGER_SYMBOLS.INDENT] || 0) - 1);
          return logger;
        },

        // Группировка
        group: (title, collapsed = true) => {
          const output = loggerState[LOGGER_SYMBOLS.OUTPUT];
          const level = loggerState[LOGGER_SYMBOLS.GROUP_LEVEL] || 0;
          const indent = '  '.repeat(level);

          if (collapsed) {
            output.groupCollapsed(`${indent}📂 ${title}`);
          } else {
            output.group(`${indent}📂 ${title}`);
          }
          loggerState[LOGGER_SYMBOLS.GROUP_LEVEL] = (loggerState[LOGGER_SYMBOLS.GROUP_LEVEL] || 0) + 1;
          return logger;
        },

        groupEnd: () => {
          const output = loggerState[LOGGER_SYMBOLS.OUTPUT};
        output.groupEnd();
        loggerState[LOGGER_SYMBOLS.GROUP_LEVEL] = Math.max(0, (loggerState[LOGGER_SYMBOLS.GROUP_LEVEL] || 1) - 1);
        return logger;
      },

      // Управление контекстом
      setContext: (key, value) => {
        loggerState[LOGGER_SYMBOLS.CONTEXT].set(key, value);
        return logger;
      },

      getContext: (key) => {
        return loggerState[LOGGER_SYMBOLS.CONTEXT].get(key) || null;
      },

      clearContext: () => {
        loggerState[LOGGER_SYMBOLS.CONTEXT].clear();
        return logger;
      },

      // Управление метаданными
      setMetadata: (key, value) => {
        loggerState[LOGGER_SYMBOLS.METADATA].set(key, value);
        return logger;
      },

      getMetadata: (key) => {
        return loggerState[LOGGER_SYMBOLS.METADATA].get(key) || null;
      },

      clearMetadata: () => {
        loggerState[LOGGER_SYMBOLS.METADATA].clear();
        return logger;
      },

      // Управление фильтрами
      addFilter: (name, filter) => {
        if (typeof filter === 'function') {
    loggerState[LOGGER_SYMBOLS.FILTERS].set(name, filter);
  }
  return logger;
},

  removeFilter: (name) => {
    loggerState[LOGGER_SYMBOLS.FILTERS].delete(name);
    return logger;
  },

      // Управление форматтерами
      addFormatter: (name, formatter) => {
    if (typeof formatter === 'function') {
      loggerState[LOGGER_SYMBOLS.FORMATTERS].set(name, formatter);
    }
    return logger;
  },

      removeFormatter: (name) => {
    loggerState[LOGGER_SYMBOLS.FORMATTERS].delete(name);
    return logger;
  },

      // История
      getHistory: (filter = null) => {
    const history = loggerState[LOGGER_SYMBOLS.HISTORY];
    if (filter) {
      return history.filter(entry => entry.level === filter || entry.message.includes(filter));
    }
    return [...history];
  },

      clearHistory: () => {
    loggerState[LOGGER_SYMBOLS.HISTORY] = [];
    return logger;
  },

      // Настройки
      setDebug: (enabled) => {
    loggerState[LOGGER_SYMBOLS.DEBUG] = enabled;
    return logger;
  },

      setLevel: (level) => {
    loggerState[LOGGER_SYMBOLS.LEVEL] = level;
    return logger;
  },

      getLevel: () => loggerState[LOGGER_SYMBOLS.LEVEL],

      setOutput: (output) => {
    loggerState[LOGGER_SYMBOLS.OUTPUT] = output;
    return logger;
  },

      setSilent: (silent) => {
    loggerState[LOGGER_SYMBOLS.SILENT] = silent;
    return logger;
  },

      setPretty: (pretty) => {
    loggerState[LOGGER_SYMBOLS.PRETTY] = pretty;
    return logger;
  },

      setTimestamp: (enabled) => {
    loggerState[LOGGER_SYMBOLS.TIMESTAMP] = enabled;
    return logger;
  },

      setColors: (enabled) => {
    loggerState[LOGGER_SYMBOLS.COLORS] = enabled;
    return logger;
  },

      // Статистика
      getStats: () => {
    const history = loggerState[LOGGER_SYMBOLS.HISTORY];
    const stats = {
      total: history.length,
      byLevel: {},
      oldest: null,
      newest: null,
      contextSize: loggerState[LOGGER_SYMBOLS.CONTEXT].size,
      metadataSize: loggerState[LOGGER_SYMBOLS.METADATA].size,
      filtersCount: loggerState[LOGGER_SYMBOLS.FILTERS].size,
      formattersCount: loggerState[LOGGER_SYMBOLS.FORMATTERS].size,
    };

    for (const entry of history) {
      stats.byLevel[entry.level] = (stats.byLevel[entry.level] || 0) + 1;
    }

    if (history.length > 0) {
      stats.oldest = history[0].timestamp;
      stats.newest = history[history.length - 1].timestamp;
    }

    return stats;
  },

      // Экспорт/Импорт
      exportHistory: () => {
    return JSON.stringify(loggerState[LOGGER_SYMBOLS.HISTORY], null, 2);
  },

      importHistory: (json) => {
    try {
      const data = JSON.parse(json);
      if (Array.isArray(data)) {
        loggerState[LOGGER_SYMBOLS.HISTORY] = data;
        return true;
      }
      return false;
    } catch {
      return false;
    }
  },

      // Дочерние логгеры
      child: (name) => {
    const childId = `${loggerState[LOGGER_SYMBOLS.INSTANCE_ID]}:${name}`;
    return createManagerLogger(loggerState[LOGGER_SYMBOLS.DEBUG], childId);
  },

      // Таймеры
      time: (label) => {
    const start = performance.now();
    const key = `_time_${label}`;
    loggerState[LOGGER_SYMBOLS.METADATA].set(key, start);
    return {
      end: (message = '') => {
        const startTime = loggerState[LOGGER_SYMBOLS.METADATA].get(key);
        if (startTime) {
          const elapsed = (performance.now() - startTime).toFixed(2);
          logger.info(`⏱️ ${label}${message ? ' ' + message : ''}: ${elapsed}ms`);
          loggerState[LOGGER_SYMBOLS.METADATA].delete(key);
          return elapsed;
        }
        return null;
      },
      lap: (name) => {
        const startTime = loggerState[LOGGER_SYMBOLS.METADATA].get(key);
        if (startTime) {
          const elapsed = (performance.now() - startTime).toFixed(2);
          logger.debug(`⏱️ ${label} [${name}]: ${elapsed}ms`);
          return elapsed;
        }
        return null;
      },
    };
  },
};

return logger;
}

// ============================================================
// 5. ВАЛИДАТОР (100% СИМВОЛЫ)
// ============================================================

const VALIDATOR_SYMBOLS = {
  IS_VALID_STRING: Symbol('validator.isValidString'),
  IS_VALID_NUMBER: Symbol('validator.isValidNumber'),
  IS_VALID_BOOLEAN: Symbol('validator.isValidBoolean'),
  IS_VALID_OBJECT: Symbol('validator.isValidObject'),
  IS_VALID_ARRAY: Symbol('validator.isValidArray'),
  IS_VALID_FUNCTION: Symbol('validator.isValidFunction'),
  IS_VALID_ELEMENT: Symbol('validator.isValidElement'),
  IS_VALID_STATE: Symbol('validator.isValidState'),
  IS_VALID_CONFIG: Symbol('validator.isValidConfig'),
  SANITIZE: Symbol('validator.sanitize'),
  CHECK_DOM: Symbol('validator.checkDom'),
  CHECK_ID: Symbol('validator.checkId'),
  CHECK_SW: Symbol('validator.checkSW'),
  CHECK_SM: Symbol('validator.checkSM'),
};

const VALIDATOR = {
  [VALIDATOR_SYMBOLS.IS_VALID_STRING]: (value) => {
    return typeof value === 'string';
  },

  [VALIDATOR_SYMBOLS.IS_VALID_NUMBER]: (value) => {
    return typeof value === 'number' && !isNaN(value) && isFinite(value);
  },

  [VALIDATOR_SYMBOLS.IS_VALID_BOOLEAN]: (value) => {
    return typeof value === 'boolean';
  },

  [VALIDATOR_SYMBOLS.IS_VALID_OBJECT]: (value) => {
    return value && typeof value === 'object' && !Array.isArray(value);
  },

  [VALIDATOR_SYMBOLS.IS_VALID_ARRAY]: (value) => {
    return Array.isArray(value);
  },

  [VALIDATOR_SYMBOLS.IS_VALID_FUNCTION]: (value) => {
    return typeof value === 'function';
  },

  [VALIDATOR_SYMBOLS.IS_VALID_ELEMENT]: (el) => {
    return el && typeof el === 'object' && el instanceof HTMLElement;
  },

  [VALIDATOR_SYMBOLS.IS_VALID_STATE]: (state) => {
    if (!state || typeof state !== 'object') return false;
    const required = ['initialized', 'isRunning', 'isDestroyed'];
    for (const key of required) {
      if (!(key in state)) return false;
    }
    return true;
  },

  [VALIDATOR_SYMBOLS.IS_VALID_CONFIG]: (config) => {
    if (!config || typeof config !== 'object') return false;
    return true;
  },

  [VALIDATOR_SYMBOLS.SANITIZE]: (value) => {
    if (value === null || value === undefined) return null;
    if (typeof value === 'string') {
      return value.replace(/[<>]/g, '').trim();
    }
    if (typeof value === 'object') {
      try {
        return JSON.parse(JSON.stringify(value));
      } catch {
        return null;
      }
    }
    return value;
  },

  [VALIDATOR_SYMBOLS.CHECK_DOM]: (el) => {
    if (!el) return false;
    return document.body.contains(el);
  },

  [VALIDATOR_SYMBOLS.CHECK_ID]: (id) => {
    return id && typeof id === 'string' && id.length > 0;
  },

  [VALIDATOR_SYMBOLS.CHECK_SW]: (registration) => {
    if (!registration) return false;
    return registration.active && registration.active.state === 'activated';
  },

  [VALIDATOR_SYMBOLS.CHECK_SM]: () => {
    const hasSAB = typeof SharedArrayBuffer !== 'undefined';
    const hasAtomics = typeof Atomics !== 'undefined';
    const isIsolated = window.crossOriginIsolated || false;
    return hasSAB && hasAtomics && isIsolated;
  },
};

// ============================================================
// 6. ОСНОВНОЙ КЛАСС MANAGER (100% СИМВОЛЫ)
// ============================================================

class Manager {
  constructor(options = {}) {
    // ============================================================
    // 6.1 ИНИЦИАЛИЗАЦИЯ
    // ============================================================

    const debug = options.debug !== false;
    const config = { ...CONFIG, ...options.config };

    // Создаём логгер
    this[PRIVATE.LOGGER] = createManagerLogger(debug, 'Manager');
    const logger = this[PRIVATE.LOGGER];

    // ============================================================
    // 6.2 КОНФИГУРАЦИЯ
    // ============================================================

    this[PRIVATE.CONFIG] = config;
    this[PRIVATE.VERSION] = options.version || CONFIG[CONFIG_SYMBOLS.VERSION];
    this[PRIVATE.BUILD] = options.build || CONFIG[CONFIG_SYMBOLS.BUILD];

    // ============================================================
    // 6.3 СОСТОЯНИЕ
    // ============================================================

    this[PRIVATE.STATE] = {
      initialized: false,
      isRunning: false,
      isDestroyed: false,
      swStatus: null,
      smStatus: null,
      coiStatus: null,
      instances: [],
      currentInstance: null,
      bookmarklets: [],
      lastCheck: null,
    };

    // ============================================================
    // 6.4 КЕШ
    // ============================================================

    this[PRIVATE.CACHE] = new Map();

    // ============================================================
    // 6.5 DOM ЭЛЕМЕНТЫ
    // ============================================================

    this[PRIVATE.LOG_CONTAINER] = document.getElementById('log-container');
    this[PRIVATE.SW_STATUS] = document.getElementById('sw-status');
    this[PRIVATE.SM_STATUS] = document.getElementById('sm-status');
    this[PRIVATE.COI_STATUS] = document.getElementById('coi-status');
    this[PRIVATE.INSTANCES_COUNT] = document.getElementById('instances-count');
    this[PRIVATE.INSTANCES_LIST] = document.getElementById('instances-list');
    this[PRIVATE.BOOKMARKLET_STATUS] = document.getElementById('bookmarklet-status');
    this[PRIVATE.BOOKMARKLET_CODE] = document.getElementById('bookmarklet-code');

    // ============================================================
    // 6.6 ДАННЫЕ
    // ============================================================

    this[PRIVATE.LOGS] = [];
    this[PRIVATE.MAX_LOGS] = CONFIG[CONFIG_SYMBOLS.MAX_LOGS];
    this[PRIVATE.INSTANCES] = [];
    this[PRIVATE.CURRENT_INSTANCE] = null;
    this[PRIVATE.BOOKMARKLETS] = [];
    this[PRIVATE.REGISTRATION] = null;

    // ============================================================
    // 6.7 ТАЙМЕРЫ
    // ============================================================

    this[PRIVATE.TIMERS] = new Map();
    this[PRIVATE.CHECK_INTERVAL] = CONFIG[CONFIG_SYMBOLS.CHECK_INTERVAL];

    // ============================================================
    // 6.8 СЛУШАТЕЛИ
    // ============================================================

    this[PRIVATE.LISTENERS] = [];
    this[PRIVATE.EVENT_HANDLERS] = new Map();
    this[PRIVATE.STORAGE_LISTENER] = null;
    this[PRIVATE.SW_LISTENER] = null;

    // ============================================================
    // 6.9 МЕТАДАННЫЕ
    // ============================================================

    this[PRIVATE.METADATA] = {
      created: Date.now(),
      lastAccess: Date.now(),
      lastUpdate: Date.now(),
      runCount: 0,
      errorCount: 0,
      successCount: 0,
    };

    // ============================================================
    // 6.10 КОНТЕКСТ
    // ============================================================

    this[PRIVATE.CONTEXT] = {
      url: typeof window !== 'undefined' ? window.location.href : '',
      title: typeof window !== 'undefined' ? document.title : '',
      userAgent: typeof navigator !== 'undefined' ? navigator.userAgent : '',
      platform: typeof navigator !== 'undefined' ? navigator.platform : '',
      origin: typeof window !== 'undefined' ? window.location.origin : '',
    };

    // ============================================================
    // 6.11 ЗАГРУЗКА СОСТОЯНИЯ
    // ============================================================

    this[PRIVATE.LOAD_STATE]();

    // ============================================================
    // 6.12 ИНИЦИАЛИЗАЦИЯ
    // ============================================================

    logger.header('СОЗДАНИЕ MANAGER (100% СИМВОЛЫ)');
    logger.info(`📦 Версия: ${this[PRIVATE.VERSION]}`);
    logger.info(`📅 Сборка: ${this[PRIVATE.BUILD]}`);
    logger.info(`📌 Отладка: ${debug ? '✅' : '❌'}`);

    this[PRIVATE.INIT]();

    // ============================================================
    // 6.13 ЭКСПОРТ СИМВОЛОВ
    // ============================================================

    this._exportSymbols();

    // ============================================================
    // 6.14 ФИНАЛЬНАЯ ИНИЦИАЛИЗАЦИЯ
    // ============================================================

    this[PRIVATE.STATE].initialized = true;
    this[PRIVATE.STATE].isRunning = true;

    logger.success('✅ Manager инициализирован (100% символы)');
    logger.header('ГОТОВ');

    // ============================================================
    // 6.15 ПЕРВОНАЧАЛЬНАЯ ПРОВЕРКА
    // ============================================================

    // ★★★ ИСПРАВЛЕНО: добавлен await через IIFE ★★★
    (async () => {
      await this[PRIVATE.CHECK_ALL]();
    })();

    // Устанавливаем периодическую проверку
    this[PRIVATE.TIMERS].set(
        'check',
        setInterval(() => {
          if (!this[PRIVATE.STATE].isDestroyed) {
            this[PRIVATE.CHECK_ALL]();
          }
        }, this[PRIVATE.CHECK_INTERVAL])
    );
  }

  // ============================================================
  // 7. ★★★ ЭКСПОРТ СИМВОЛОВ ★★★
  // ============================================================

  _exportSymbols() {
    if (typeof window === 'undefined') return;

    window[PUBLIC.API] = this;
    window[PUBLIC.STATE] = this.getState.bind(this);
    window[PUBLIC.CONFIG] = this[PRIVATE.CONFIG];
    window[PUBLIC.LOGGER] = this[PRIVATE.LOGGER];
    window[PUBLIC.INSTANCE] = this;
    window[PUBLIC.ACTIONS] = {
      checkAll: this[PRIVATE.CHECK_ALL].bind(this),
      checkSW: this[PRIVATE.CHECK_SW].bind(this),
      checkSharedMemory: this[PRIVATE.CHECK_SHARED_MEMORY].bind(this),
      checkInstances: this[PRIVATE.CHECK_INSTANCES].bind(this),
      registerSW: this[PRIVATE.REGISTER_SW].bind(this),
      runBookmarklet: this[PRIVATE.RUN_BOOKMARKLET].bind(this),
      clearCache: this[PRIVATE.CLEAR_CACHE].bind(this),
      resetAll: this[PRIVATE.RESET_ALL].bind(this),
      copyBookmarklet: this[PRIVATE.COPY_BOOKMARKLET].bind(this),
    };
    window[PUBLIC.EVENTS] = {
      on: this.on.bind(this),
      off: this.off.bind(this),
      emit: this.emit.bind(this),
    };
    window[PUBLIC.STATS] = this.getStats.bind(this);

    window.__manager = this;
    window.__managerSymbols = {
      PRIVATE: { ...PRIVATE },
      PUBLIC: { ...PUBLIC },
      CONFIG_SYMBOLS: { ...CONFIG_SYMBOLS },
      LOGGER_SYMBOLS: { ...LOGGER_SYMBOLS },
      VALIDATOR_SYMBOLS: { ...VALIDATOR_SYMBOLS },
      version: this[PRIVATE.VERSION],
      build: this[PRIVATE.BUILD],
    };
  }

  // ============================================================
  // 8. ★★★ ИНИЦИАЛИЗАЦИЯ ★★★
  // ============================================================

  [PRIVATE.INIT]() {
    const logger = this[PRIVATE.LOGGER];
    logger.info('🔧 Инициализация...');

    // Настройка слушателей
    this._setupStorageListener();
    this._setupSWListener();
    this._setupErrorListeners();

    logger.success('✅ Инициализация завершена');
  }

  // ============================================================
  // 9. ★★★ НАСТРОЙКА СЛУШАТЕЛЕЙ ★★★
  // ============================================================

  _setupStorageListener() {
    const logger = this[PRIVATE.LOGGER];

    this[PRIVATE.STORAGE_LISTENER] = (event) => {
      if (event.key === 'env-panel-instances' || event.key === 'env-panel-current-instance') {
        this[PRIVATE.CHECK_INSTANCES]();
      }
      if (event.key === 'env-panel-visible') {
        this[PRIVATE.ADD_LOG](
            `📌 Видимость панели: ${event.newValue === 'true' ? 'показана' : 'скрыта'}`,
            'info'
        );
      }
    };

    window.addEventListener('storage', this[PRIVATE.STORAGE_LISTENER]);
    logger.debug('✅ Storage listener настроен');
  }

  _setupSWListener() {
    const logger = this[PRIVATE.LOGGER];

    if ('serviceWorker' in navigator) {
      this[PRIVATE.SW_LISTENER] = (event) => {
        this[PRIVATE.ADD_LOG](`📨 Сообщение от SW: ${JSON.stringify(event.data)}`, 'info');
      };

      navigator.serviceWorker.addEventListener('message', this[PRIVATE.SW_LISTENER]);

      navigator.serviceWorker.addEventListener('controllerchange', () => {
        this[PRIVATE.ADD_LOG]('🔄 Контроллер SW изменился', 'info');
        setTimeout(() => this[PRIVATE.CHECK_ALL](), 500);
      });

      logger.debug('✅ SW listener настроен');
    }
  }

  _setupErrorListeners() {
    const logger = this[PRIVATE.LOGGER];

    window.addEventListener('error', (event) => {
      this[PRIVATE.ADD_LOG](`❌ Ошибка: ${event.message}`, 'error');
      logger.error(`Глобальная ошибка: ${event.message}`);
    });

    window.addEventListener('unhandledrejection', (event) => {
      this[PRIVATE.ADD_LOG](`❌ Unhandled rejection: ${event.reason}`, 'error');
      logger.error(`Необработанное обещание: ${event.reason}`);
    });

    logger.debug('✅ Error listeners настроены');
  }

  // ============================================================
  // 10. ★★★ ЛОГГИРОВАНИЕ ★★★
  // ============================================================

  [PRIVATE.ADD_LOG](message, type = 'info') {
    const container = this[PRIVATE.LOG_CONTAINER];
    if (!container) return;

    const time = new Date().toLocaleTimeString();
    const div = document.createElement('div');
    div.className = 'log-entry';
    div.innerHTML = `<span class="time">[${time}]</span><span class="${type}">${message}</span>`;
    container.appendChild(div);
    container.scrollTop = container.scrollHeight;

    while (container.children.length > this[PRIVATE.MAX_LOGS]) {
      container.removeChild(container.firstChild);
    }

    this[PRIVATE.LOGS].push({ time, message, type });
    if (this[PRIVATE.LOGS].length > this[PRIVATE.MAX_LOGS]) {
      this[PRIVATE.LOGS].shift();
    }
  }

  [PRIVATE.CLEAR_LOGS]() {
    const container = this[PRIVATE.LOG_CONTAINER];
    if (container) {
      container.innerHTML = '';
    }
    this[PRIVATE.LOGS] = [];
    this[PRIVATE.ADD_LOG]('🧹 Логи очищены', 'info');
  }

  // ============================================================
  // 11. ★★★ ПРОВЕРКА ВСЕХ КОМПОНЕНТОВ ★★★
  // ============================================================

  [PRIVATE.CHECK_ALL] = async function() {
    const logger = this[PRIVATE.LOGGER];
    logger.info('🔍 Проверка всех компонентов...');
    this[PRIVATE.ADD_LOG]('🔍 Проверка всех компонентов...', 'info');

    try {
      // ★★★ ИСПРАВЛЕНО: добавлен await ★★★
      await this[PRIVATE.CHECK_SW]();
      await this[PRIVATE.CHECK_SHARED_MEMORY]();
      await this[PRIVATE.CHECK_INSTANCES]();
      this[PRIVATE.CHECK_BOOKMARKLET]();

      this[PRIVATE.STATE].lastCheck = Date.now();
      this[PRIVATE.METADATA].lastUpdate = Date.now();
      this[PRIVATE.METADATA].successCount++;

      logger.success('✅ Проверка всех компонентов завершена');
    } catch (error) {
      logger.error(`❌ Ошибка проверки: ${error.message}`);
      this[PRIVATE.METADATA].errorCount++;
    }
  };

  // ============================================================
  // 12. ★★★ ПРОВЕРКА SERVICE WORKER ★★★
  // ============================================================

  [PRIVATE.CHECK_SW] = async function() {
    const el = this[PRIVATE.SW_STATUS];
    const logger = this[PRIVATE.LOGGER];

    if (!('serviceWorker' in navigator)) {
      el.textContent = '❌ Не поддерживается';
      el.className = 'value fail';
      this[PRIVATE.ADD_LOG]('❌ Service Workers не поддерживаются', 'error');
      this[PRIVATE.STATE].swStatus = 'unsupported';
      return;
    }

    try {
      // ★★★ ИСПРАВЛЕНО: добавлен await ★★★
      const registration = await navigator.serviceWorker.getRegistration('/');

      if (registration && registration.active) {
        el.textContent = '✅ Активен';
        el.className = 'value ok';
        this[PRIVATE.ADD_LOG]('✅ Service Worker активен', 'success');
        this[PRIVATE.STATE].swStatus = 'active';
        this[PRIVATE.REGISTRATION] = registration;
      } else if (registration) {
        el.textContent = '⏳ Устанавливается';
        el.className = 'value warn';
        this[PRIVATE.ADD_LOG]('⏳ Service Worker устанавливается', 'warn');
        this[PRIVATE.STATE].swStatus = 'installing';
      } else {
        el.textContent = '❌ Не зарегистрирован';
        el.className = 'value fail';
        this[PRIVATE.ADD_LOG]('❌ Service Worker не зарегистрирован', 'error');
        this[PRIVATE.STATE].swStatus = 'unregistered';
      }
    } catch (error) {
      el.textContent = '❌ Ошибка';
      el.className = 'value fail';
      this[PRIVATE.ADD_LOG](`❌ Ошибка проверки SW: ${error.message}`, 'error');
      this[PRIVATE.STATE].swStatus = 'error';
      logger.error(`Ошибка проверки SW: ${error.message}`);
    }
  };

  // ============================================================
  // 13. ★★★ ПРОВЕРКА SHARED MEMORY ★★★
  // ============================================================

  [PRIVATE.CHECK_SHARED_MEMORY] = async function() {
    const el = this[PRIVATE.SM_STATUS];
    const coiEl = this[PRIVATE.COI_STATUS];
    const logger = this[PRIVATE.LOGGER];

    const hasSAB = typeof SharedArrayBuffer !== 'undefined';
    const hasAtomics = typeof Atomics !== 'undefined';
    const isIsolated = window.crossOriginIsolated || false;

    // Проверяем заголовки
    let coop = null,
        coep = null;
    try {
      // ★★★ ИСПРАВЛЕНО: добавлен await ★★★
      const response = await fetch('./', { cache: 'no-store' });
      coop = response.headers.get('Cross-Origin-Opener-Policy');
      coep = response.headers.get('Cross-Origin-Embedder-Policy');
    } catch (e) {}

    const fullySupported = hasSAB && hasAtomics && isIsolated;

    if (fullySupported) {
      el.textContent = '✅ Работает';
      el.className = 'value ok';
      coiEl.textContent = '✅ Включена';
      coiEl.className = 'value ok';
      this[PRIVATE.ADD_LOG]('✅ SharedMemory работает', 'success');
      if (coop) {
        this[PRIVATE.ADD_LOG](`  COOP: ${coop}`, 'info');
      }
      if (coep) {
        this[PRIVATE.ADD_LOG](`  COEP: ${coep}`, 'info');
      }
      this[PRIVATE.STATE].smStatus = 'supported';
      this[PRIVATE.STATE].coiStatus = 'enabled';
    } else {
      el.textContent = hasSAB && hasAtomics ? '⚠️ Частично' : '❌ Не работает';
      el.className = hasSAB && hasAtomics ? 'value warn' : 'value fail';
      coiEl.textContent = isIsolated ? '⚠️ Частично' : '❌ Выключена';
      coiEl.className = isIsolated ? 'value warn' : 'value fail';

      if (!hasSAB) {
        this[PRIVATE.ADD_LOG]('❌ SharedArrayBuffer не доступен', 'error');
      }
      if (!hasAtomics) {
        this[PRIVATE.ADD_LOG]('❌ Atomics не доступны', 'error');
      }
      if (!isIsolated) {
        this[PRIVATE.ADD_LOG]('❌ Cross-Origin Isolation не включена', 'error');
        this[PRIVATE.ADD_LOG]('  💡 Добавьте заголовки или используйте Service Worker', 'warn');
        this[PRIVATE.ADD_LOG]('  💡 После установки Service Worker перезагрузите страницу', 'warn');
      }
      this[PRIVATE.STATE].smStatus = hasSAB && hasAtomics ? 'partial' : 'unsupported';
      this[PRIVATE.STATE].coiStatus = isIsolated ? 'partial' : 'disabled';
    }
  };

  // ============================================================
  // 14. ★★★ ПРОВЕРКА ЭКЗЕМПЛЯРОВ ★★★
  // ============================================================

  [PRIVATE.CHECK_INSTANCES] = async function() {
    const el = this[PRIVATE.INSTANCES_COUNT];
    const listEl = this[PRIVATE.INSTANCES_LIST];
    const logger = this[PRIVATE.LOGGER];

    try {
      let instances = [];
      try {
        instances = JSON.parse(localStorage.getItem('env-panel-instances') || '[]');
      } catch {
        instances = [];
      }

      const current = localStorage.getItem('env-panel-current-instance');

      this[PRIVATE.INSTANCES] = instances;
      this[PRIVATE.CURRENT_INSTANCE] = current;

      el.textContent = instances.length;

      if (instances.length === 0) {
        listEl.innerHTML = '<span style="color:#636e72;font-size:12px;">Нет активных экземпляров</span>';
      } else {
        listEl.innerHTML = instances
            .map(
                id =>
                    `<span class="instance-tag ${id === current ? 'active' : ''}">${id.slice(-8)}${id === current ? ' ⭐' : ''}</span>`
            )
            .join('');
      }

      if (instances.length > 0) {
        this[PRIVATE.ADD_LOG](`📊 Активных экземпляров: ${instances.length}`, 'info');
        logger.info(`📊 Активных экземпляров: ${instances.length}`);
      }
    } catch (error) {
      el.textContent = '?';
      this[PRIVATE.ADD_LOG](`❌ Ошибка получения экземпляров: ${error.message}`, 'error');
      logger.error(`Ошибка получения экземпляров: ${error.message}`);
    }
  };

  // ============================================================
  // 15. ★★★ ПРОВЕРКА БУКМАРКЛЕТА ★★★
  // ============================================================

  [PRIVATE.CHECK_BOOKMARKLET]() {
    const el = this[PRIVATE.BOOKMARKLET_STATUS];
    if (!el) return;

    const scripts = document.querySelectorAll('script[src*="bookmarklet.js"]');
    const hasBookmarklet = scripts.length > 0;
    const hasInstance = !!(window.__bookmarkletInstance || window.R);

    if (hasBookmarklet || hasInstance) {
      el.textContent = '✅ Загружен';
      el.className = 'value ok';
      if (hasInstance) {
        const id = window.__bookmarkletInstance?.id || window.R?.id || 'unknown';
        el.textContent = `✅ Активен (${id.slice(-8)})`;
      }
      this[PRIVATE.STATE].bookmarkletStatus = 'loaded';
    } else {
      el.textContent = '❌ Не загружен';
      el.className = 'value fail';
      this[PRIVATE.STATE].bookmarkletStatus = 'unloaded';
    }
  }

  // ============================================================
  // 16. ★★★ РЕГИСТРАЦИЯ SERVICE WORKER ★★★
  // ============================================================

  [PRIVATE.REGISTER_SW] = async function() {
    const logger = this[PRIVATE.LOGGER];
    this[PRIVATE.ADD_LOG]('🔄 Регистрация Service Worker...', 'info');

    if (!('serviceWorker' in navigator)) {
      this[PRIVATE.ADD_LOG]('❌ Service Workers не поддерживаются', 'error');
      return;
    }

    try {
      // Удаляем старую регистрацию
      // ★★★ ИСПРАВЛЕНО: добавлен await ★★★
      const oldReg = await navigator.serviceWorker.getRegistration('/');
      if (oldReg) {
        // ★★★ ИСПРАВЛЕНО: добавлен await ★★★
        await oldReg.unregister();
        this[PRIVATE.ADD_LOG]('🗑️ Старый Service Worker удален', 'info');
      }

      // ★★★ ИСПРАВЛЕНО: добавлен await ★★★
      const registration = await navigator.serviceWorker.register(
          CONFIG[CONFIG_SYMBOLS.SW_URL],
          {
            scope: CONFIG[CONFIG_SYMBOLS.SW_SCOPE],
            updateViaCache: 'none',
          }
      );

      // Ждем активации
      if (registration.active) {
        this[PRIVATE.ADD_LOG]('✅ Service Worker зарегистрирован и активен', 'success');
      } else {
        await new Promise(resolve => {
          if (registration.active) {
            resolve();
          } else {
            registration.addEventListener('statechange', function onStateChange() {
              if (this.state === 'activated') {
                this[PRIVATE.ADD_LOG]('✅ Service Worker активирован', 'success');
                this.removeEventListener('statechange', onStateChange);
                resolve();
              }
            });
          }
        });
      }

      this[PRIVATE.ADD_LOG]('💡 Перезагрузите страницу для применения заголовков', 'warn');
      this[PRIVATE.REGISTRATION] = registration;

      // ★★★ ИСПРАВЛЕНО: добавлен await ★★★
      await this[PRIVATE.CHECK_ALL]();
    } catch (error) {
      this[PRIVATE.ADD_LOG](`❌ Ошибка регистрации: ${error.message}`, 'error');
      logger.error(`Ошибка регистрации SW: ${error.message}`);
    }
  };

  // ============================================================
  // 17. ★★★ ЗАПУСК БУКМАРКЛЕТА ★★★
  // ============================================================

  [PRIVATE.RUN_BOOKMARKLET] = async function() {
    const logger = this[PRIVATE.LOGGER];
    this[PRIVATE.ADD_LOG]('🚀 Запуск букмарклета...', 'info');

    try {
      // Проверяем, есть ли уже экземпляр
      const existing = document.querySelector('script[src*="bookmarklet.js"]');
      if (existing) {
        this[PRIVATE.ADD_LOG]('⚠️ Букмарклет уже загружен, перезагружаем...', 'warn');
        existing.remove();
        if (window.__bookmarkletInstance?.destroy) {
          window.__bookmarkletInstance.destroy();
        }
        delete window.__bookmarkletInstance;
        delete window.R;
      }

      // ★★★ ИСПРАВЛЕНО: используем Promise вместо callback ★★★
      const script = document.createElement('script');
      script.type = 'module';
      script.src = CONFIG[CONFIG_SYMBOLS.BOOKMARKLET_PATH];

      await new Promise((resolve, reject) => {
        script.onload = resolve;
        script.onerror = reject;
        document.head.appendChild(script);
      });

      this[PRIVATE.ADD_LOG]('✅ Букмарклет загружен', 'success');
      await this[PRIVATE.CHECK_ALL]();

      if (window.R) {
        this[PRIVATE.ADD_LOG](`📦 Экземпляр: ${window.R.id || 'unknown'}`, 'info');
        logger.info(`📦 Экземпляр: ${window.R.id || 'unknown'}`);
      }
    } catch (error) {
      this[PRIVATE.ADD_LOG](`❌ Ошибка: ${error.message}`, 'error');
      logger.error(`Ошибка запуска букмарклета: ${error.message}`);
    }
  };

  // ============================================================
  // 18. ★★★ ОЧИСТКА КЕША ★★★
  // ============================================================

  [PRIVATE.CLEAR_CACHE] = async function() {
    const logger = this[PRIVATE.LOGGER];
    this[PRIVATE.ADD_LOG]('🗑️ Очистка кеша...', 'info');

    try {
      if ('serviceWorker' in navigator) {
        // ★★★ ИСПРАВЛЕНО: добавлен await ★★★
        const registrations = await navigator.serviceWorker.getRegistrations();
        for (const reg of registrations) {
          // ★★★ ИСПРАВЛЕНО: добавлен await ★★★
          await reg.unregister();
          this[PRIVATE.ADD_LOG](`✅ Service Worker удален`, 'success');
        }
      }

      const keys = await caches.keys();
      for (const key of keys) {
        await caches.delete(key);
        this[PRIVATE.ADD_LOG](`🗑️ Кеш "${key}" удален`, 'ok');
      }

      this[PRIVATE.ADD_LOG]('✅ Кеш очищен', 'success');
      this[PRIVATE.ADD_LOG]('💡 Перезагрузите страницу', 'warn');

      // ★★★ ИСПРАВЛЕНО: добавлен await ★★★
      await this[PRIVATE.CHECK_ALL]();
    } catch (error) {
      this[PRIVATE.ADD_LOG](`❌ Ошибка очистки: ${error.message}`, 'error');
      logger.error(`Ошибка очистки кеша: ${error.message}`);
    }
  };

  // ============================================================
  // 19. ★★★ СБРОС ВСЕГО ★★★
  // ============================================================

  [PRIVATE.RESET_ALL] = async function() {
    const logger = this[PRIVATE.LOGGER];

    if (
        !confirm(
            '⚠️ Сбросить всё состояние?\n\nЭто удалит:\n- Все данные localStorage (настройки, состояние)\n- Service Worker\n- Кеш браузера\n\nПродолжить?'
        )
    ) {
      return;
    }

    this[PRIVATE.ADD_LOG]('🔄 Сброс всех данных...', 'warn');

    try {
      // Очищаем localStorage
      const keys = Object.keys(localStorage);
      let count = 0;
      for (const key of keys) {
        if (
            key.startsWith('env-panel-') ||
            key.startsWith('shared_') ||
            key.startsWith('bookmarklet-')
        ) {
          localStorage.removeItem(key);
          count++;
        }
      }
      this[PRIVATE.ADD_LOG](`🗑️ Удалено ${count} записей из localStorage`, 'info');

      // Удаляем экземпляры из глобального объекта
      if (window.__bookmarkletInstance?.destroy) {
        window.__bookmarkletInstance.destroy();
      }
      delete window.__bookmarkletInstance;
      delete window.R;
      delete window.globalState;
      delete window.__globalState;

      // Очищаем кеш
      // ★★★ ИСПРАВЛЕНО: добавлен await ★★★
      await this[PRIVATE.CLEAR_CACHE]();

      this[PRIVATE.ADD_LOG]('✅ Сброс выполнен', 'success');
      this[PRIVATE.ADD_LOG]('🔄 Перезагрузка страницы через 2 секунды...', 'info');

      setTimeout(() => {
        location.reload();
      }, 2000);
    } catch (error) {
      this[PRIVATE.ADD_LOG](`❌ Ошибка сброса: ${error.message}`, 'error');
      logger.error(`Ошибка сброса: ${error.message}`);
    }
  };

  // ============================================================
  // 20. ★★★ КОПИРОВАНИЕ БУКМАРКЛЕТА ★★★
  // ============================================================

  [PRIVATE.COPY_BOOKMARKLET]() {
    const codeEl = this[PRIVATE.BOOKMARKLET_CODE];
    if (!codeEl) return;

    const text = codeEl.textContent.trim();

    navigator.clipboard
        .writeText(text)
        .then(() => {
          this[PRIVATE.ADD_LOG]('📋 Букмарклет скопирован в буфер обмена', 'success');
        })
        .catch(() => {
          const range = document.createRange();
          range.selectNode(codeEl);
          window.getSelection().removeAllRanges();
          window.getSelection().addRange(range);
          try {
            document.execCommand('copy');
            this[PRIVATE.ADD_LOG]('📋 Букмарклет скопирован (fallback)', 'success');
          } catch (error) {
            this[PRIVATE.ADD_LOG]('❌ Не удалось скопировать', 'error');
          }
          window.getSelection().removeAllRanges();
        });
  }

  [PRIVATE.COPY_MANAGER_BOOKMARKLET]() {
    const text = `javascript:window.open('${CONFIG[CONFIG_SYMBOLS.MANAGER_PATH]}','_blank','width=900,height=800');`;

    navigator.clipboard
        .writeText(text)
        .then(() => {
          this[PRIVATE.ADD_LOG]('📋 Менеджер скопирован в буфер обмена', 'success');
        })
        .catch(() => {
          const input = document.createElement('input');
          input.value = text;
          document.body.appendChild(input);
          input.select();
          document.execCommand('copy');
          input.remove();
          this[PRIVATE.ADD_LOG]('📋 Менеджер скопирован (fallback)', 'success');
        });
  }

  // ============================================================
  // 21. ★★★ УПРАВЛЕНИЕ СОСТОЯНИЕМ ★★★
  // ============================================================

  [PRIVATE.SAVE_STATE]() {
    try {
      const state = {
        logs: this[PRIVATE.LOGS],
        instances: this[PRIVATE.INSTANCES],
        currentInstance: this[PRIVATE.CURRENT_INSTANCE],
        metadata: this[PRIVATE.METADATA],
        timestamp: Date.now(),
        version: this[PRIVATE.VERSION],
      };
      localStorage.setItem(CONFIG[CONFIG_SYMBOLS.STORAGE_KEY], JSON.stringify(state));
    } catch (error) {
      this[PRIVATE.LOGGER].debug('⚠️ Не удалось сохранить состояние:', error.message);
    }
  }

  [PRIVATE.LOAD_STATE]() {
    try {
      const saved = localStorage.getItem(CONFIG[CONFIG_SYMBOLS.STORAGE_KEY]);
      if (saved) {
        const state = JSON.parse(saved);
        if (state.logs) {
          this[PRIVATE.LOGS] = state.logs;
          for (const log of state.logs) {
            this[PRIVATE.ADD_LOG](log.message, log.type || 'info');
          }
        }
        if (state.metadata) {
          Object.assign(this[PRIVATE.METADATA], state.metadata);
        }
        this[PRIVATE.LOGGER].debug('✅ Состояние загружено');
      }
    } catch (error) {
      this[PRIVATE.LOGGER].debug('⚠️ Не удалось загрузить состояние:', error.message);
    }
  }

  // ============================================================
  // 22. ★★★ ПУБЛИЧНЫЕ МЕТОДЫ ★★★
  // ============================================================

  getState() {
    return {
      version: this[PRIVATE.VERSION],
      build: this[PRIVATE.BUILD],
      initialized: this[PRIVATE.STATE].initialized,
      isRunning: this[PRIVATE.STATE].isRunning,
      isDestroyed: this[PRIVATE.STATE].isDestroyed,
      swStatus: this[PRIVATE.STATE].swStatus,
      smStatus: this[PRIVATE.STATE].smStatus,
      coiStatus: this[PRIVATE.STATE].coiStatus,
      instances: this[PRIVATE.INSTANCES],
      currentInstance: this[PRIVATE.CURRENT_INSTANCE],
      bookmarkletStatus: this[PRIVATE.STATE].bookmarkletStatus,
      lastCheck: this[PRIVATE.STATE].lastCheck,
      metadata: { ...this[PRIVATE.METADATA] },
      context: { ...this[PRIVATE.CONTEXT] },
      logsCount: this[PRIVATE.LOGS].length,
      config: { ...this[PRIVATE.CONFIG] },
    };
  }

  getStats() {
    return {
      ...this.getState(),
      metadata: { ...this[PRIVATE.METADATA] },
      timersCount: this[PRIVATE.TIMERS].size,
      listenersCount: this[PRIVATE.LISTENERS].length,
      eventHandlersCount: this[PRIVATE.EVENT_HANDLERS].size,
      cacheSize: this[PRIVATE.CACHE].size,
      logsCount: this[PRIVATE.LOGS].length,
    };
  }

  getLogger() {
    return this[PRIVATE.LOGGER];
  }

  getConfig() {
    return { ...this[PRIVATE.CONFIG] };
  }

  // ============================================================
  // 23. ★★★ СОБЫТИЯ ★★★
  // ============================================================

  on(event, callback) {
    if (typeof callback !== 'function') {
      this[PRIVATE.LOGGER].warn(`⚠️ Некорректный callback для события ${event}`);
      return () => {};
    }

    const handlers = this[PRIVATE.EVENT_HANDLERS];
    if (!handlers.has(event)) {
      handlers.set(event, []);
    }
    handlers.get(event).push(callback);

    return () => this.off(event, callback);
  }

  off(event, callback) {
    const handlers = this[PRIVATE.EVENT_HANDLERS];
    if (handlers.has(event)) {
      const list = handlers.get(event);
      const index = list.indexOf(callback);
      if (index !== -1) {
        list.splice(index, 1);
      }
      if (list.length === 0) {
        handlers.delete(event);
      }
    }
  }

  [PRIVATE.EMIT](event, data) {
    const handlers = this[PRIVATE.EVENT_HANDLERS];
    if (handlers.has(event)) {
      const list = handlers.get(event);
      for (const callback of list) {
        try {
          callback(data);
        } catch (error) {
          this[PRIVATE.LOGGER].error(`❌ Ошибка в обработчике ${event}:`, error.message);
        }
      }
    }
  }

  emit(event, data) {
    this[PRIVATE.EMIT](event, data);
  }

  // ============================================================
  // 24. ★★★ УНИЧТОЖЕНИЕ ★★★
  // ============================================================

  [PRIVATE.DESTROY]() {
    if (this[PRIVATE.STATE].isDestroyed) {
      this[PRIVATE.LOGGER].warn('⚠️ Manager уже уничтожен');
      return;
    }

    const logger = this[PRIVATE.LOGGER];
    logger.warn('🗑️ Уничтожение Manager...');

    // Очищаем таймеры
    for (const [key, timer] of this[PRIVATE.TIMERS]) {
      clearInterval(timer);
      clearTimeout(timer);
    }
    this[PRIVATE.TIMERS].clear();

    // Очищаем слушатели
    if (this[PRIVATE.STORAGE_LISTENER]) {
      window.removeEventListener('storage', this[PRIVATE.STORAGE_LISTENER]);
      this[PRIVATE.STORAGE_LISTENER] = null;
    }

    if (this[PRIVATE.SW_LISTENER] && 'serviceWorker' in navigator) {
      navigator.serviceWorker.removeEventListener('message', this[PRIVATE.SW_LISTENER]);
      this[PRIVATE.SW_LISTENER] = null;
    }

    // Очищаем данные
    this[PRIVATE.CACHE].clear();
    this[PRIVATE.LISTENERS] = [];
    this[PRIVATE.EVENT_HANDLERS].clear();
    this[PRIVATE.LOGS] = [];

    // Удаляем глобальные ссылки
    if (typeof window !== 'undefined') {
      delete window[PUBLIC.API];
      delete window[PUBLIC.STATE];
      delete window[PUBLIC.CONFIG];
      delete window[PUBLIC.LOGGER];
      delete window[PUBLIC.INSTANCE];
      delete window[PUBLIC.ACTIONS];
      delete window[PUBLIC.EVENTS];
      delete window[PUBLIC.STATS];
      delete window.__manager;
      delete window.__managerSymbols;
    }

    this[PRIVATE.STATE].isDestroyed = true;
    this[PRIVATE.STATE].isRunning = false;
    this[PRIVATE.STATE].initialized = false;

    this[PRIVATE.EMIT]('destroy', { timestamp: Date.now() });

    logger.success('✅ Manager уничтожен');
  }

  destroy() {
    this[PRIVATE.DESTROY]();
  }
}

// ============================================================
// 25. ★★★ СОЗДАНИЕ ЭКЗЕМПЛЯРА ★★★
// ============================================================

let managerInstance = null;

function getManagerInstance(options = {}) {
  if (!managerInstance) {
    managerInstance = new Manager(options);
    if (typeof window !== 'undefined') {
      window.__managerInstance = managerInstance;
    }
  }
  return managerInstance;
}

// ============================================================
// 26. ★★★ ЭКСПОРТЫ ★★★
// ============================================================

export {
  PRIVATE,
  PUBLIC,
  CONFIG_SYMBOLS,
  LOGGER_SYMBOLS,
  VALIDATOR_SYMBOLS,
  CONFIG,
  Manager,
  getManagerInstance,
};

// ============================================================
// 27. ★★★ ДЕФОЛТНЫЙ ЭКСПОРТ ★★★
// ============================================================

export default Manager;

// ============================================================
// 28. ★★★ ГЛОБАЛЬНАЯ РЕГИСТРАЦИЯ ★★★
// ============================================================

if (typeof window !== 'undefined') {
  const manager = getManagerInstance({
    debug: true,
    version: '2.1.0',
    build: '2026-07-22',
  });

  console.log('╔═══════════════════════════════════════════════════════════════════════════════╗');
  console.log('║              📦 MANAGER (100% СИМВОЛЫ) v2.1.0                               ║');
  console.log('╠═══════════════════════════════════════════════════════════════════════════════╣');
  console.log('║  📋 Все логи выводятся в консоль с цветовой разметкой                       ║');
  console.log('║  🔑 Полная изоляция через приватные символы                                 ║');
  console.log('║  🔓 Публичные символы через Symbol.for                                      ║');
  console.log('║  🔄 Управление букмарклетами и Service Worker                              ║');
  console.log('║  📊 Полная статистика работы                                                ║');
  console.log('║  ✅ ИСПРАВЛЕНЫ все асинхронные вызовы (await)                              ║');
  console.log('║  ✅ ИСПРАВЛЕНА проверка Service Worker                                     ║');
  console.log('║  ✅ ИСПРАВЛЕНА проверка SharedMemory                                       ║');
  console.log('║  ✅ ИСПРАВЛЕНА регистрация SW                                              ║');
  console.log('║  ✅ ИСПРАВЛЕНА очистка кеша                                                ║');
  console.log('║  ✅ ИСПРАВЛЕН сброс всех данных                                            ║');
  console.log('╚═══════════════════════════════════════════════════════════════════════════════╝');

  console.log('📋 ДОСТУПНЫЕ КОМАНДЫ (__manager):');
  console.log('  __manager.checkAll()           - проверить все компоненты');
  console.log('  __manager.checkSW()            - проверить Service Worker');
  console.log('  __manager.checkSharedMemory()  - проверить SharedMemory');
  console.log('  __manager.checkInstances()     - проверить экземпляры');
  console.log('  __manager.registerSW()         - зарегистрировать SW');
  console.log('  __manager.runBookmarklet()     - запустить букмарклет');
  console.log('  __manager.clearCache()         - очистить кеш');
  console.log('  __manager.resetAll()           - сбросить всё');
  console.log('  __manager.copyBookmarklet()    - скопировать букмарклет');
  console.log('  __manager.getState()           - получить состояние');
  console.log('  __manager.getStats()           - получить статистику');
  console.log('  __manager.on(event, cb)        - подписка на события');
  console.log('  __manager.off(event, cb)       - отписка');
  console.log('  __manager.emit(event, data)    - отправка события');
  console.log('  __manager.destroy()            - уничтожить');
  console.log('  __manager.getLogger()          - получить логгер');
  console.log('  __manager.getConfig()          - получить конфиг');
  console.log('');

  console.log('📋 ПРИВАТНЫХ СИМВОЛОВ:', Object.keys(PRIVATE).length);
  console.log('📋 ПУБЛИЧНЫХ СИМВОЛОВ:', Object.keys(PUBLIC).length);
  console.log('📋 КОНФИГ СИМВОЛОВ:', Object.keys(CONFIG_SYMBOLS).length);
  console.log('📋 ЛОГГЕР СИМВОЛОВ:', Object.keys(LOGGER_SYMBOLS).length);
  console.log('📋 ВАЛИДАТОР СИМВОЛОВ:', Object.keys(VALIDATOR_SYMBOLS).length);
  console.log('═══════════════════════════════════════════════════════════════════════════════');

  // Глобальный доступ через window
  window.manager = manager;

  // Добавляем быстрые команды
  window.checkAll = () => manager.checkAll();
  window.registerSW = () => manager.registerSW();
  window.runBookmarklet = () => manager.runBookmarklet();
  window.clearCache = () => manager.clearCache();
  window.resetAll = () => manager.resetAll();
  window.copyBookmarklet = () => manager.copyBookmarklet();
}
