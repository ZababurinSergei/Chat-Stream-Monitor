// background-core.js - Основной код с 100% символами
// ИСПРАВЛЕННАЯ ВЕРСИЯ: использует вынесенный генератор шаблонов
// Версия: 2.0.1
// ИСПРАВЛЕНО: Добавлены await для всех асинхронных вызовов загрузки букмарклетов
// ИСПРАВЛЕНО: Генерация компактных букмарклетов через единую точку входа

// ============================================================
// 1. ИМПОРТ ГЕНЕРАТОРА ШАБЛОНОВ
// ============================================================

import BookmarkletTemplateGenerator, {
  getTemplateGenerator,
} from './bookmarklet-template-generator.js';

// ============================================================
// 2. ПРИВАТНЫЕ СИМВОЛЫ (100% изоляция)
// ============================================================

const PRIVATE = {
  // Основные символы
  CONFIG: Symbol('background.config'),
  LOGGER: Symbol('background.logger'),
  STATE: Symbol('background.state'),
  CACHE: Symbol('background.cache'),
  VERSION: Symbol('background.version'),
  BUILD: Symbol('background.build'),
  INITIALIZED: Symbol('background.initialized'),
  IS_RUNNING: Symbol('background.isRunning'),
  IS_DESTROYED: Symbol('background.isDestroyed'),

  // Букмарклеты
  BOOKMARKLETS: Symbol('background.bookmarklets'),
  BOOKMARKLETS_LIST: Symbol('background.bookmarkletsList'),
  BOOKMARKS: Symbol('background.bookmarks'),
  FOLDERS: Symbol('background.folders'),
  RESULTS: Symbol('background.results'),
  LAST_UPDATE: Symbol('background.lastUpdate'),
  AUTO_UPDATE_DONE: Symbol('background.autoUpdateDone'),
  IS_UPDATING: Symbol('background.isUpdating'),
  UPDATE_RESULTS: Symbol('background.updateResults'),
  BOOKMARK_URL_CACHE: Symbol('background.bookmarkUrlCache'),

  // Генератор
  GENERATOR: Symbol('background.generator'),
  GENERATOR_LOADED: Symbol('background.generatorLoaded'),
  DETECT_TYPE: Symbol('background.detectType'),
  GENERATE_CODE: Symbol('background.generateCode'),
  GENERATE_UNIVERSAL_BOOKMARKLET: Symbol('background.generateUniversalBookmarklet'),
  UPDATE_BOOKMARK: Symbol('background.updateBookmark'),
  UPDATE_BOOKMARK_URL: Symbol('background.updateBookmarkUrl'),
  UPDATE_ALL: Symbol('background.updateAll'),
  GET_LIST: Symbol('background.getList'),
  REFRESH: Symbol('background.refresh'),
  FORCE_UPDATE: Symbol('background.forceUpdate'),
  GET_SCRIPT_PATH: Symbol('background.getScriptPath'),

  // Состояние и конфигурация
  GLOBAL_STATE: Symbol('background.globalState'),
  CHANNEL_MANAGER: Symbol('background.channelManager'),
  ENV_PANEL: Symbol('background.envPanel'),
  DYNAMIC_CONFIG: Symbol('background.dynamicConfig'),
  EXTENSION_STATE: Symbol('background.extensionState'),
  LAST_SYNC: Symbol('background.lastSync'),
  SYNC_INTERVAL: Symbol('background.syncInterval'),

  // Управление
  TIMERS: Symbol('background.timers'),
  LISTENERS: Symbol('background.listeners'),
  BOOKMARKLET_TEMPLATE: Symbol('background.bookmarkletTemplate'),

  // Безопасность
  SECURE: Symbol('background.secure'),
  VALIDATOR: Symbol('background.validator'),
  DEBUG: Symbol('background.debug'),
  LOG_HISTORY: Symbol('background.logHistory'),

  // Внутренние
  INTERNAL: Symbol('background.internal'),
  URL_UPDATER: Symbol('background.urlUpdater'),

  // Логгер
  LOG_HISTORY_ARRAY: Symbol('logger.history'),
  LOG_MAX_HISTORY: Symbol('logger.maxHistory'),
  LOG_DEBUG_ENABLED: Symbol('logger.debug'),
  LOG_INSTANCE_ID: Symbol('logger.instanceId'),

  // Универсальный загрузчик
  UNIVERSAL_LOADER: Symbol('background.universalLoader'),
  LOADER_SCRIPTS: Symbol('background.loaderScripts'),
  LOADER_CACHE: Symbol('background.loaderCache'),

  // Сжатие
  COMPRESSOR: Symbol('background.compressor'),
  COMPRESS_CACHE: Symbol('background.compressCache'),
  MINIFY_CODE: Symbol('background.minifyCode'),
  COMPRESS_CODE: Symbol('background.compressCode'),
  DECOMPRESS_CODE: Symbol('background.decompressCode'),
  ENCODE_URL: Symbol('background.encodeUrl'),
  DECODE_URL: Symbol('background.decodeUrl'),
  COMPRESSION_STATS: Symbol('background.compressionStats'),

  // Генератор шаблонов
  TEMPLATE_GENERATOR: Symbol('background.templateGenerator'),
  TEMPLATE_GENERATOR_LOADED: Symbol('background.templateGeneratorLoaded'),

  // Экспорт
  EXPORTED: Symbol('background.exported'),
  IS_MODULE: Symbol('background.isModule'),

  // Привязка методов
  BIND_METHODS: Symbol('background.bindMethods'),

  // Методы обработчиков
  SETUP_LISTENERS: Symbol('background.setupListeners'),
  SETUP_TIMERS: Symbol('background.setupTimers'),
  LOAD_BOOKMARKS: Symbol('background.loadBookmarks'),
  HANDLE_MESSAGE: Symbol('background.handleMessage'),
  AUTO_UPDATE_BOOKMARKS: Symbol('background.autoUpdateBookmarks'),
  FORCE_UPDATE: Symbol('background.forceUpdate'),
  OPEN_POPUP: Symbol('background.openPopup'),
  SAVE_STATE: Symbol('background.saveState'),
  LOAD_STATE: Symbol('background.loadState'),
  GET_STATE: Symbol('background.getState'),
  GET_CONFIG: Symbol('background.getConfig'),
  GET_DYNAMIC_CONFIG: Symbol('background.getDynamicConfig'),
  UPDATE_DYNAMIC_CONFIG: Symbol('background.updateDynamicConfig'),
  GET_LOGGER: Symbol('background.getLogger'),
  GET_GENERATOR: Symbol('background.getGenerator'),
  GET_GLOBAL_STATE: Symbol('background.getGlobalState'),
  GET_CHANNEL_MANAGER: Symbol('background.getChannelManager'),
  GET_UNIVERSAL_LOADER: Symbol('background.getUniversalLoader'),
  GET_COMPRESSOR: Symbol('background.getCompressor'),
  GET_TEMPLATE_GENERATOR: Symbol('background.getTemplateGenerator'),
  IS_GENERATOR_LOADED: Symbol('background.isGeneratorLoaded'),
  IS_TEMPLATE_GENERATOR_LOADED: Symbol('background.isTemplateGeneratorLoaded'),
  REFRESH: Symbol('background.refresh'),
  UPDATE_ALL: Symbol('background.updateAll'),
  UPDATE_BOOKMARK_URL: Symbol('background.updateBookmarkUrl'),
  GENERATE_UNIVERSAL_BOOKMARKLET: Symbol('background.generateUniversalBookmarklet'),
  GENERATE_ALL_TEMPLATES: Symbol('background.generateAllTemplates'),
  EXPORT_TEMPLATES: Symbol('background.exportTemplates'),
  IMPORT_TEMPLATES: Symbol('background.importTemplates'),
  COMPRESS_CODE: Symbol('background.compressCode'),
  MINIFY_CODE: Symbol('background.minifyCode'),
  OPEN_POPUP: Symbol('background.openPopup'),
  SYNC_STATE: Symbol('background.syncState'),
  RESET_ALL: Symbol('background.resetAll'),
  ON: Symbol('background.on'),
  OFF: Symbol('background.off'),
  EMIT: Symbol('background.emit'),
  DESTROY: Symbol('background.destroy'),
};

// ============================================================
// 3. ПУБЛИЧНЫЕ СИМВОЛЫ (доступны через Symbol.for)
// ============================================================

const PUBLIC = {
  API: Symbol.for('background.api'),
  STATE: Symbol.for('background.state'),
  CONFIG: Symbol.for('background.config'),
  LOGGER: Symbol.for('background.logger'),
  GENERATOR: Symbol.for('background.generator'),
  UPDATER: Symbol.for('background.updater'),
  REFRESHER: Symbol.for('background.refresher'),
  INSTANCE: Symbol.for('background.instance'),
  EVENTS: Symbol.for('background.events'),
  GLOBAL_STATE: Symbol.for('background.globalState'),
  CHANNEL: Symbol.for('background.channel'),
  ENV_PANEL: Symbol.for('background.envPanel'),
  BOOKMARKS: Symbol.for('background.bookmarks'),
  DYNAMIC_CONFIG: Symbol.for('background.dynamicConfig'),
  UNIVERSAL_LOADER: Symbol.for('background.universalLoader'),
  COMPRESSOR: Symbol.for('background.compressor'),
  TEMPLATE_GENERATOR: Symbol.for('background.templateGenerator'),
};

// ============================================================
// 4. ДИНАМИЧЕСКАЯ КОНФИГУРАЦИЯ
// ============================================================

const DEFAULT_DYNAMIC_CONFIG = {
  version: '2.0.1',
  build: '2026-07-22',
  debug: true,

  bookmarklet: {
    basePath: './Bookmarklet/',
    defaultType: 'main',
    autoShow: true,
    fallbackEnabled: true,
    timeout: 5000,
    maxRetries: 3,
    retryDelay: 1000,
    updateBookmarkUrl: true,
    preserveOriginalUrl: false,
    useUniversalLoader: true,
    loaderPath: './Bookmarklet/src/universal-loader.js',
    defaultCallback: '(r)=>console.log("✅",r)',
  },

  panel: {
    defaultWidth: 420,
    defaultHeight: 520,
    defaultPosition: { x: 20, y: 20 },
    minWidth: 320,
    minHeight: 300,
    maxWidth: '90vw',
    maxHeight: '90vh',
    zIndex: 99996,
    animations: true,
    animationDuration: 300,
  },

  channel: {
    name: 'bookmarklet-channel',
    debug: true,
    maxHistory: 100,
    timeout: 5000,
    broadcast: true,
    postMessage: true,
    customEvent: true,
    storage: true,
  },

  state: {
    storageKey: 'bookmarklet-state',
    autoSave: true,
    saveInterval: 5000,
    maxHistory: 100,
    syncInterval: 30000,
  },

  debug: {
    defaultNamespace: '',
    presets: {
      all: 'wasm:*',
      flow: 'wasm:flow:*',
      memory: 'wasm:memory:*',
      generate: 'wasm:generate:*',
      api: 'wasm:api:*',
      errors: 'wasm:error:*',
      allExceptMemory: '*,-wasm:memory:*',
      full: 'wasm:flow:*,wasm:generate:*,wasm:memory:*',
    },
  },

  extension: {
    autoUpdate: true,
    updateInterval: 300000,
    checkInterval: 60000,
    maxBookmarklets: 100,
    syncWithStorage: true,
  },

  compression: {
    enabled: true,
    minify: true,
    removeComments: true,
    shortenVariables: true,
    compressBooleans: true,
    encodeUrl: true,
    maxUrlLength: 2000,
    fallbackToUncompressed: true,
    aggressiveCompression: true,
  },
};

// ============================================================
// 5. КОНФИГУРАЦИЯ
// ============================================================

const DEFAULT_CONFIG = {
  debug: true,
  basePath: './Bookmarklet/',
  files: {
    env: 'src/env-panel.js',
    logs: 'src/logs-panel.js',
    debug: 'src/debug-panel.js',
    main: 'bookmarklet.js',
    manager: 'src/manager.html',
    widget: 'widget.mjs',
    universal: 'src/universal-loader.js',
  },
  source: 'my-bookmarklet',
  extensionSource: 'my-extension-bridge',
  responseType: 'BOOKMARK_DATA_RESPONSE',
  timeout: 5000,
  version: '2.0.1',
  maxRetries: 3,
  retryDelay: 1000,
  autoUpdate: true,
  defaultCallback: '(r)=>console.log("✅",r)',
};

// ============================================================
// 6. ФУНКЦИЯ ЛОГГЕРА
// ============================================================

function createLogger(debug = true, instanceId = 'background') {
  const logger = {};

  logger[PRIVATE.LOG_HISTORY_ARRAY] = [];
  logger[PRIVATE.LOG_MAX_HISTORY] = 200;
  logger[PRIVATE.LOG_DEBUG_ENABLED] = debug;
  logger[PRIVATE.LOG_INSTANCE_ID] = instanceId;

  logger._log = function (level, message, data = null) {
    if (!this[PRIVATE.LOG_DEBUG_ENABLED] && level !== 'error') return;

    const timestamp = new Date().toISOString().slice(11, 23);
    const prefix = `[${timestamp}] [${this[PRIVATE.LOG_INSTANCE_ID]}]`;

    this[PRIVATE.LOG_HISTORY_ARRAY].push({ timestamp, level, message, data });
    if (this[PRIVATE.LOG_HISTORY_ARRAY].length > this[PRIVATE.LOG_MAX_HISTORY]) {
      this[PRIVATE.LOG_HISTORY_ARRAY].shift();
    }

    if (data !== null && data !== undefined) {
      console.log(`${prefix} ${message}`, data);
    } else {
      console.log(`${prefix} ${message}`);
    }
  };

  logger.error = function (msg, d) {
    this._log('error', `❌ ${msg}`, d);
  };
  logger.warn = function (msg, d) {
    this._log('warn', `⚠️ ${msg}`, d);
  };
  logger.info = function (msg, d) {
    this._log('info', `ℹ️ ${msg}`, d);
  };
  logger.debug = function (msg, d) {
    this._log('debug', `🔍 ${msg}`, d);
  };
  logger.success = function (msg, d) {
    this._log('info', `✅ ${msg}`, d);
  };

  logger.header = function (title) {
    console.log('═'.repeat(70));
    console.log(`  🚀 ${title}`);
    console.log('═'.repeat(70));
  };

  logger.separator = function () {
    console.log('─'.repeat(70));
  };

  logger.symbol = function (name, symbol) {
    console.log(`  🔑 ${name}: ${String(symbol)}`);
  };

  logger.private = function (name, symbol) {
    console.log(`  🔒 ${name}: ${String(symbol)}`);
  };

  logger.getHistory = function () {
    return [...this[PRIVATE.LOG_HISTORY_ARRAY]];
  };

  logger.clearHistory = function () {
    this[PRIVATE.LOG_HISTORY_ARRAY] = [];
    return this;
  };

  logger.setDebug = function (enabled) {
    this[PRIVATE.LOG_DEBUG_ENABLED] = enabled;
    return this;
  };

  return logger;
}

// ============================================================
// 7. ГЕНЕРАТОР БУКМАРКЛЕТОВ (100% СИМВОЛЫ - ИСПРАВЛЕННАЯ ВЕРСИЯ)
// ============================================================

class BookmarkletGenerator {
  constructor(options = {}) {
    this[PRIVATE.CONFIG] = { ...DEFAULT_CONFIG, ...options };
    this[PRIVATE.LOGGER] = createLogger(options.debug !== false, 'Generator');
    this[PRIVATE.CACHE] = new Map();
    this[PRIVATE.BOOKMARKLETS] = [];
    this[PRIVATE.RESULTS] = null;
    this[PRIVATE.INITIALIZED] = false;
    this[PRIVATE.IS_UPDATING] = false;
    this[PRIVATE.LAST_UPDATE] = null;
    this[PRIVATE.VERSION] = options.version || DEFAULT_CONFIG.version;
    this[PRIVATE.DYNAMIC_CONFIG] = { ...DEFAULT_DYNAMIC_CONFIG, ...options.dynamicConfig };
    this[PRIVATE.GLOBAL_STATE] = options.globalState || null;
    this[PRIVATE.CHANNEL_MANAGER] = options.channelManager || null;
    this[PRIVATE.BOOKMARK_URL_CACHE] = new Map();
    this[PRIVATE.COMPRESS_CACHE] = new Map();
    this[PRIVATE.COMPRESSION_STATS] = {
      total: 0,
      saved: 0,
      originalSize: 0,
      compressedSize: 0,
      ratio: 0,
    };
    this[PRIVATE.LOADER_CACHE] = new Map();
    this[PRIVATE.LOADER_SCRIPTS] = new Map();
    this[PRIVATE.EXTENSION_STATE] = {
      isActive: true,
      lastPing: Date.now(),
      connectedClients: 0,
      errors: [],
      lastError: null,
    };
    this[PRIVATE.TEMPLATE_GENERATOR_LOADED] = false;
    this[PRIVATE.TEMPLATE_GENERATOR] = null;

    // Привязываем методы
    this[PRIVATE.BIND_METHODS]();

    const logger = this[PRIVATE.LOGGER];
    logger.header('СОЗДАНИЕ ГЕНЕРАТОРА (100% СИМВОЛЫ)');
    logger.info(`📦 Версия: ${this[PRIVATE.VERSION]}`);
    logger.info(`📌 Динамическая конфигурация:`, this[PRIVATE.DYNAMIC_CONFIG]);
    logger.info(
      `📌 Универсальный загрузчик: ${this[PRIVATE.DYNAMIC_CONFIG].bookmarklet.useUniversalLoader}`
    );
    logger.info(`📌 Сжатие: ${this[PRIVATE.DYNAMIC_CONFIG].compression.enabled}`);

    // Инициализируем генератор шаблонов
    this._initTemplateGenerator();

    this[PRIVATE.INITIALIZED] = true;
    logger.success('✅ Генератор создан');
  }

  // ============================================================
  // 8. ИНИЦИАЛИЗАЦИЯ ГЕНЕРАТОРА ШАБЛОНОВ
  // ============================================================

  _initTemplateGenerator() {
    const logger = this[PRIVATE.LOGGER];
    logger.info('📦 Инициализация генератора шаблонов...');

    try {
      this[PRIVATE.TEMPLATE_GENERATOR] = getTemplateGenerator({
        debug: this[PRIVATE.DYNAMIC_CONFIG].debug,
        basePath: this[PRIVATE.DYNAMIC_CONFIG].bookmarklet.basePath,
        version: this[PRIVATE.VERSION],
        compression: this[PRIVATE.DYNAMIC_CONFIG].compression,
      });
      this[PRIVATE.TEMPLATE_GENERATOR_LOADED] = true;
      logger.success('✅ Генератор шаблонов инициализирован');
    } catch (error) {
      logger.error('❌ Ошибка инициализации генератора шаблонов:', error.message);
      this[PRIVATE.TEMPLATE_GENERATOR_LOADED] = false;
    }
  }

  // ============================================================
  // 9. ПРИВЯЗКА МЕТОДОВ
  // ============================================================

  [PRIVATE.BIND_METHODS]() {
    const self = this;

    // Основные методы
    this[PRIVATE.DETECT_TYPE] = this[PRIVATE.DETECT_TYPE].bind(this);
    this[PRIVATE.MINIFY_CODE] = this[PRIVATE.MINIFY_CODE].bind(this);
    this[PRIVATE.ENCODE_URL] = this[PRIVATE.ENCODE_URL].bind(this);
    this[PRIVATE.DECODE_URL] = this[PRIVATE.DECODE_URL].bind(this);
    this[PRIVATE.COMPRESS_CODE] = this[PRIVATE.COMPRESS_CODE].bind(this);
    this[PRIVATE.GENERATE_CODE] = this[PRIVATE.GENERATE_CODE].bind(this);
    this[PRIVATE.GENERATE_UNIVERSAL_BOOKMARKLET] =
      this[PRIVATE.GENERATE_UNIVERSAL_BOOKMARKLET].bind(this);
    this[PRIVATE.UPDATE_BOOKMARK_URL] = this[PRIVATE.UPDATE_BOOKMARK_URL].bind(this);
    this[PRIVATE.UPDATE_BOOKMARK] = this[PRIVATE.UPDATE_BOOKMARK].bind(this);
    this[PRIVATE.UPDATE_ALL] = this[PRIVATE.UPDATE_ALL].bind(this);
    this[PRIVATE.GET_LIST] = this[PRIVATE.GET_LIST].bind(this);
    this[PRIVATE.REFRESH] = this[PRIVATE.REFRESH].bind(this);
    this[PRIVATE.FORCE_UPDATE] = this[PRIVATE.FORCE_UPDATE].bind(this);
    this[PRIVATE.GET_SCRIPT_PATH] = this[PRIVATE.GET_SCRIPT_PATH].bind(this);

    // Публичные методы
    this.generateCode = this.generateCode.bind(this);
    this.generateUniversalBookmarklet = this.generateUniversalBookmarklet.bind(this);
    this.updateBookmark = this.updateBookmark.bind(this);
    this.updateBookmarkUrl = this.updateBookmarkUrl.bind(this);
    this.updateAll = this.updateAll.bind(this);
    this.getList = this.getList.bind(this);
    this.refresh = this.refresh.bind(this);
    this.compressBookmarklet = this.compressBookmarklet.bind(this);
    this.minifyBookmarklet = this.minifyBookmarklet.bind(this);
    this.encodeUrl = this.encodeUrl.bind(this);
    this.decodeUrl = this.decodeUrl.bind(this);
    this.getCompressionStats = this.getCompressionStats.bind(this);
    this.clearCompressionCache = this.clearCompressionCache.bind(this);
    this.getState = this.getState.bind(this);
    this.getConfig = this.getConfig.bind(this);
    this.getDynamicConfig = this.getDynamicConfig.bind(this);
    this.updateDynamicConfig = this.updateDynamicConfig.bind(this);
    this.getBookmarklets = this.getBookmarklets.bind(this);
    this.getBookmarkUrlCache = this.getBookmarkUrlCache.bind(this);
    this.clearCache = this.clearCache.bind(this);
    this.reset = this.reset.bind(this);
    this.getTemplateGeneratorStats = this.getTemplateGeneratorStats.bind(this);
    this.generateAllTemplates = this.generateAllTemplates.bind(this);
    this.exportTemplates = this.exportTemplates.bind(this);
    this.importTemplates = this.importTemplates.bind(this);
  }

  // ============================================================
  // 10. ОПРЕДЕЛЕНИЕ ТИПА БУКМАРКЛЕТА
  // ============================================================

  [PRIVATE.DETECT_TYPE](title) {
    const lower = title.toLowerCase();
    let type = 'main';
    if (lower.includes('env') || lower.includes('control')) {
      type = 'env';
    } else if (lower.includes('log')) {
      type = 'logs';
    } else if (lower.includes('debug')) {
      type = 'debug';
    } else if (lower.includes('manager')) {
      type = 'manager';
    } else if (lower.includes('widget')) {
      type = 'widget';
    } else if (lower.includes('sw') || lower.includes('service')) {
      type = 'sw';
    } else if (lower.includes('reset') || lower.includes('сброс')) {
      type = 'reset';
    }
    return type;
  }

  // ============================================================
  // 11. ★★★ ПОЛУЧЕНИЕ ПУТИ К СКРИПТУ ★★★
  // ============================================================

  [PRIVATE.GET_SCRIPT_PATH](type) {
    const scriptMap = {
      env: './Bookmarklet/src/env-panel.js',
      logs: './Bookmarklet/src/logs-panel.js',
      debug: './Bookmarklet/src/debug-panel.js',
      manager: './Bookmarklet/src/manager.html',
      widget: './Bookmarklet/widget.mjs',
      main: './Bookmarklet/bookmarklet.js',
      sw: './register-sw.js',
      reset: './reset-all.js',
    };
    return scriptMap[type] || scriptMap.main;
  }

  // ============================================================
  // 12. МИНИФИКАЦИЯ КОДА
  // ============================================================

  [PRIVATE.MINIFY_CODE](code) {
    if (!code || typeof code !== 'string') return code;

    const logger = this[PRIVATE.LOGGER];
    logger.debug('🔧 Минификация кода букмарклета...');

    let result = code;
    const compressionConfig = this[PRIVATE.DYNAMIC_CONFIG].compression;

    // 1. Удаляем комментарии
    if (compressionConfig.removeComments) {
      result = result.replace(/\/\*[\s\S]*?\*\//g, '');
      result = result.replace(/\/\/.*$/gm, '');
    }

    // 2. Удаляем лишние пробелы и переносы
    result = result.replace(/\s+/g, ' ');
    result = result.replace(/\s*([{}()\[\];,:])\s*/g, '$1');
    result = result.replace(/;\s*}/g, '}');
    result = result.replace(/{\s+/g, '{');
    result = result.replace(/\s+}/g, '}');
    result = result.replace(/\(\s+/g, '(');
    result = result.replace(/\s+\)/g, ')');
    result = result.replace(/\[\s+/g, '[');
    result = result.replace(/\s+]/g, ']');

    // 3. Сокращаем переменные
    if (compressionConfig.shortenVariables) {
      const varMap = new Map();
      let counter = 0;
      const varRegex = /(?:var|let|const)\s+([a-zA-Z_$][a-zA-Z0-9_$]*)/g;
      let match;
      const varNames = [];
      while ((match = varRegex.exec(result)) !== null) {
        const name = match[1];
        if (name.length > 2 && !['if', 'for', 'while', 'switch', 'try', 'catch'].includes(name)) {
          varNames.push(name);
        }
      }

      varNames.sort((a, b) => b.length - a.length);

      const shortNames = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
      for (const name of varNames) {
        if (!varMap.has(name)) {
          let short = shortNames[counter % shortNames.length];
          if (counter >= shortNames.length) {
            short += Math.floor(counter / shortNames.length);
          }
          varMap.set(name, short);
          counter++;
        }
      }

      for (const [oldName, newName] of varMap) {
        const regex = new RegExp('\\b' + oldName + '\\b', 'g');
        result = result.replace(regex, newName);
      }
    }

    // 4. Сокращаем true/false
    if (compressionConfig.compressBooleans) {
      result = result.replace(/\btrue\b/g, '!0');
      result = result.replace(/\bfalse\b/g, '!1');
      result = result.replace(/\bundefined\b/g, 'void 0');
    }

    // 5. Удаляем лишние точки с запятой
    result = result.replace(/;\s*}/g, '}');
    result = result.replace(/;\s*;/g, ';');
    result = result.replace(/}\s*;/g, '}');

    // 6. Агрессивное сжатие
    if (compressionConfig.aggressiveCompression) {
      result = result.replace(/\"([^\"\\]*)\"/g, (match, str) => {
        if (str.length > 0 && !str.includes("'") && !str.includes('"')) {
          return "'" + str + "'";
        }
        return match;
      });
      result = result.replace(/}\s*else/g, '}else');
      result = result.replace(/;\s*}/g, '}');
      result = result.replace(/}\s*;/g, '}');
    }

    // 7. Удаляем все переносы строк и лишние пробелы
    result = result.replace(/\n/g, ' ');
    result = result.replace(/\r/g, ' ');
    result = result.replace(/\s+/g, ' ');
    result = result.trim();

    logger.debug(
      `📊 Размер до: ${code.length}, после: ${result.length} (${((1 - result.length / code.length) * 100).toFixed(1)}% сжатие)`
    );

    return result;
  }

  // ============================================================
  // 13. КОДИРОВАНИЕ ДЛЯ URL
  // ============================================================

  [PRIVATE.ENCODE_URL](code) {
    try {
      let cleaned = code;

      cleaned = cleaned.replace(/\/\*[\s\S]*?\*\//g, '');
      cleaned = cleaned.replace(/\/\/.*$/gm, '');

      cleaned = cleaned.replace(/\s+/g, ' ');
      cleaned = cleaned.replace(/\s*([{}()\[\];,:])\s*/g, '$1');
      cleaned = cleaned.replace(/;\s*}/g, '}');
      cleaned = cleaned.replace(/{\s+/g, '{');
      cleaned = cleaned.replace(/\s+}/g, '}');
      cleaned = cleaned.replace(/\(\s+/g, '(');
      cleaned = cleaned.replace(/\s+\)/g, ')');
      cleaned = cleaned.replace(/\[\s+/g, '[');
      cleaned = cleaned.replace(/\s+]/g, ']');

      const encoded = encodeURIComponent(cleaned);

      return encoded;
    } catch (error) {
      console.error('❌ Ошибка кодирования URL:', error.message);
      return encodeURIComponent(code);
    }
  }

  // ============================================================
  // 14. ДЕКОДИРОВАНИЕ ИЗ URL
  // ============================================================

  [PRIVATE.DECODE_URL](encoded) {
    try {
      const code = encoded.replace(/^javascript:/i, '');
      const decoded = decodeURIComponent(code);
      return decoded;
    } catch (error) {
      console.error('❌ Ошибка декодирования URL:', error.message);
      return encoded;
    }
  }

  // ============================================================
  // 15. СЖАТИЕ КОДА ДЛЯ URL
  // ============================================================

  [PRIVATE.COMPRESS_CODE](code) {
    if (!code || typeof code !== 'string') return code;

    const logger = this[PRIVATE.LOGGER];
    logger.debug('🗜️ Сжатие кода для URL...');

    try {
      const cacheKey = code.length + '-' + code.substring(0, 100);
      if (this[PRIVATE.COMPRESS_CACHE].has(cacheKey)) {
        const cached = this[PRIVATE.COMPRESS_CACHE].get(cacheKey);
        logger.debug(`📦 Используем кеш сжатия: ${cached.length} байт`);
        return cached;
      }

      let compressed = this[PRIVATE.MINIFY_CODE](code);

      compressed = compressed.replace(/^javascript:/i, '');

      compressed = compressed.replace(/\s+/g, ' ');
      compressed = compressed.replace(/;\s*}/g, '}');
      compressed = compressed.replace(/{\s+/g, '{');
      compressed = compressed.replace(/\s+}/g, '}');
      compressed = compressed.replace(/\(\s+/g, '(');
      compressed = compressed.replace(/\s+\)/g, ')');

      compressed = compressed.replace(/\n/g, '');
      compressed = compressed.replace(/\r/g, '');

      const encoded = this[PRIVATE.ENCODE_URL](compressed);

      const result = 'javascript:' + encoded;

      this[PRIVATE.COMPRESS_CACHE].set(cacheKey, result);

      const stats = this[PRIVATE.COMPRESSION_STATS];
      stats.total++;
      stats.originalSize += code.length;
      stats.compressedSize += result.length;
      stats.saved += code.length - result.length;
      stats.ratio = (1 - stats.compressedSize / stats.originalSize) * 100;

      logger.info(
        `📊 Сжатие: ${code.length} → ${result.length} байт (${((1 - result.length / code.length) * 100).toFixed(1)}% сжатие)`
      );

      return result;
    } catch (error) {
      logger.error('❌ Ошибка сжатия:', error.message);
      return 'javascript:' + encodeURIComponent(code.replace(/^javascript:/i, ''));
    }
  }

  // ============================================================
  // 16. ★★★ ГЕНЕРАЦИЯ КОДА (УПРОЩЕННАЯ ВЕРСИЯ) ★★★
  // ============================================================

  [PRIVATE.GENERATE_CODE](bookmarkData, options = {}) {
    const logger = this[PRIVATE.LOGGER];
    const title = bookmarkData?.title || options.title || 'Bookmarklet';
    const type = options.type || this[PRIVATE.DETECT_TYPE](title);
    const componentId =
      options.componentId || 'bm-' + Date.now() + '-' + Math.random().toString(36).substr(2, 4);
    const version = options.version || this[PRIVATE.VERSION];

    // Базовый объект props
    const props = {
      name: title,
      type: type,
      id: componentId,
      version: version,
      debug: options.debug !== false,
      script: this[PRIVATE.GET_SCRIPT_PATH](type),
      data: options.data || null,
      position: options.position || { x: 100, y: 100 },
      size: options.size || { width: 420, height: 520 },
      recursive: options.recursive || false,
      targetState: options.targetState || null,
      maxRecursion: options.maxRecursion || 100,
      recursionDelay: options.recursionDelay || 500,
    };

    // Добавляем callback если есть
    let callbackStr = '';
    if (options.callback || this[PRIVATE.CONFIG].defaultCallback) {
      const cb = options.callback || this[PRIVATE.CONFIG].defaultCallback;
      callbackStr = `,callback:${cb}`;
    }

    // ✅ Генерируем компактный букмарклет
    const code = `javascript:import("./Bookmarklet/bookmarklet.js").then(m=>m.default({name:"${title.replace(/"/g, '\\"')}",type:"${type}",id:"${componentId}",version:"${version}",debug:${props.debug},script:"${props.script}"${props.data ? `,data:${JSON.stringify(props.data)}` : ''}${props.position ? `,position:${JSON.stringify(props.position)}` : ''}${props.size ? `,size:${JSON.stringify(props.size)}` : ''}${props.recursive ? `,recursive:true` : ''}${props.targetState ? `,targetState:${JSON.stringify(props.targetState)}` : ''}${props.maxRecursion ? `,maxRecursion:${props.maxRecursion}` : ''}${props.recursionDelay ? `,recursionDelay:${props.recursionDelay}` : ''}${callbackStr}}))`;

    logger.info(`📝 Сгенерирован компактный букмарклет: ${code.length} байт`);
    logger.debug(`📌 ${title} (${type}) → ${code.substring(0, 80)}...`);

    // Кешируем
    this[PRIVATE.BOOKMARK_URL_CACHE].set(componentId, {
      title,
      type,
      code,
      timestamp: Date.now(),
      version,
    });

    return code;
  }

  // ============================================================
  // 17. УНИВЕРСАЛЬНЫЙ ГЕНЕРАТОР БУКМАРКЛЕТА
  // ============================================================

  [PRIVATE.GENERATE_UNIVERSAL_BOOKMARKLET](bookmarkData, options = {}) {
    const logger = this[PRIVATE.LOGGER];
    const title = bookmarkData?.title || options.title || 'Bookmarklet';
    const type = options.type || this[PRIVATE.DETECT_TYPE](title);

    // Проверяем, загружен ли генератор шаблонов
    if (!this[PRIVATE.TEMPLATE_GENERATOR_LOADED] || !this[PRIVATE.TEMPLATE_GENERATOR]) {
      logger.warn('⚠️ Генератор шаблонов не загружен, используем стандартный метод');
      return this[PRIVATE.GENERATE_CODE](bookmarkData, options);
    }

    try {
      // Используем генератор шаблонов
      const template = this[PRIVATE.TEMPLATE_GENERATOR].generateCompressedTemplate(
        { title, id: options.componentId },
        { type, title, ...options }
      );

      logger.success(`✅ Букмарклет "${title}" сгенерирован через TemplateGenerator`);
      logger.info(
        `📊 Размер: ${template.code.length} байт (сжатый: ${template.compressed.length} байт)`
      );

      // Сохраняем в кеш
      this[PRIVATE.BOOKMARK_URL_CACHE].set(template.id, {
        title: template.title,
        type: template.type,
        code: template.code,
        compressed: template.compressed,
        timestamp: Date.now(),
        universal: true,
        size: template.compression,
      });

      return template.compressed;
    } catch (error) {
      logger.error('❌ Ошибка генерации через TemplateGenerator:', error.message);
      logger.info('🔄 Используем стандартный метод');
      return this[PRIVATE.GENERATE_CODE](bookmarkData, options);
    }
  }

  // ============================================================
  // 18. ОБНОВЛЕНИЕ URL БУКМАРКЛЕТА
  // ============================================================

  [PRIVATE.UPDATE_BOOKMARK_URL](bookmarkId, newCode) {
    return new Promise((resolve, reject) => {
      if (!bookmarkId) {
        reject(new Error('bookmarkId is required'));
        return;
      }
      if (!newCode || !newCode.startsWith('javascript:')) {
        reject(new Error('newCode must start with "javascript:"'));
        return;
      }

      const logger = this[PRIVATE.LOGGER];
      logger.info(`📝 Обновление URL букмарклета ${bookmarkId}...`);

      let finalCode = newCode;
      if (newCode.length > 2000) {
        const compressed = this[PRIVATE.COMPRESS_CODE](newCode);
        if (compressed.length < newCode.length) {
          finalCode = compressed;
          logger.info(`📊 Сжатие: ${newCode.length} → ${compressed.length} байт`);
        }
      }

      chrome.bookmarks.get(bookmarkId, result => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
          return;
        }

        const current = result[0];
        if (!current) {
          reject(new Error('Bookmark not found'));
          return;
        }

        if (current.url === finalCode) {
          logger.info(`ℹ️ URL букмарклета "${current.title}" уже актуален`);
          resolve({ ...current, unchanged: true });
          return;
        }

        chrome.bookmarks.update(
          bookmarkId,
          {
            url: finalCode,
            title: current.title,
          },
          updated => {
            if (chrome.runtime.lastError) {
              reject(new Error(chrome.runtime.lastError.message));
              return;
            }

            logger.success(`✅ URL букмарклета "${updated.title}" обновлен (сжатый)`);
            resolve({ ...updated, updated: true });
          }
        );
      });
    });
  }

  [PRIVATE.UPDATE_BOOKMARK](bookmarkId, newCode) {
    return new Promise((resolve, reject) => {
      if (!bookmarkId) {
        reject(new Error('bookmarkId is required'));
        return;
      }
      if (!newCode || !newCode.startsWith('javascript:')) {
        reject(new Error('newCode must start with "javascript:"'));
        return;
      }

      const logger = this[PRIVATE.LOGGER];
      logger.info(`📝 Обновление букмарклета ${bookmarkId}...`);

      this[PRIVATE.UPDATE_BOOKMARK_URL](bookmarkId, newCode)
        .then(result => {
          resolve(result);
        })
        .catch(error => {
          logger.error('❌ Ошибка обновления:', error.message);
          reject(error);
        });
    });
  }

  [PRIVATE.UPDATE_ALL](bookmarklets) {
    const results = {
      total: bookmarklets.length,
      updated: 0,
      unchanged: 0,
      failed: 0,
      errors: [],
      details: [],
      timestamp: Date.now(),
    };

    const logger = this[PRIVATE.LOGGER];

    return new Promise(resolve => {
      let processed = 0;
      const total = bookmarklets.length;

      if (total === 0) {
        resolve(results);
        return;
      }

      for (const bm of bookmarklets) {
        if (!bm.url || !bm.url.startsWith('javascript:')) {
          processed++;
          if (processed === total) {
            resolve(results);
          }
          continue;
        }

        const type = this[PRIVATE.DETECT_TYPE](bm.title);
        const newCode = this[PRIVATE.GENERATE_CODE](
          { id: bm.id, title: bm.title },
          { type, title: bm.title }
        );

        this[PRIVATE.UPDATE_BOOKMARK](bm.id, newCode)
          .then(result => {
            if (result.unchanged) {
              results.unchanged++;
            } else {
              results.updated++;
            }
            results.details.push({
              id: bm.id,
              title: bm.title,
              type,
              success: true,
              unchanged: result.unchanged || false,
            });
            if (result.updated) {
              logger.success(`✅ Обновлён: "${bm.title}" (${type})`);
            }
          })
          .catch(error => {
            results.failed++;
            results.errors.push({ id: bm.id, title: bm.title, error: error.message });
            logger.error(`❌ Ошибка "${bm.title}":`, error.message);
          })
          .finally(() => {
            processed++;
            if (processed === total) {
              logger.info(
                `📊 Результат: ${results.updated} обновлено, ${results.unchanged} без изменений, ${results.failed} ошибок`
              );
              resolve(results);
            }
          });
      }
    });
  }

  // ============================================================
  // 19. ★★★ ПОЛУЧЕНИЕ СПИСКА (ИСПРАВЛЕНО) ★★★
  // ============================================================

  [PRIVATE.GET_LIST]() {
    return new Promise((resolve, reject) => {
      try {
        if (typeof chrome === 'undefined' || !chrome.bookmarks) {
          reject(new Error('Chrome bookmarks API not available'));
          return;
        }

        const logger = this[PRIVATE.LOGGER];
        logger.info('📑 Получение списка букмарклетов...');

        chrome.bookmarks.getTree(tree => {
          if (chrome.runtime.lastError) {
            logger.error('❌ Ошибка получения закладок:', chrome.runtime.lastError.message);
            reject(new Error(chrome.runtime.lastError.message));
            return;
          }

          const bookmarklets = [];

          function traverseBookmarks(node, path = '') {
            if (node.url && node.url.startsWith('javascript:')) {
              bookmarklets.push({
                id: node.id,
                title: node.title || 'Без названия',
                url: node.url,
                path: path || 'Корень',
                isBookmarklet: true,
                type: 'bookmarklet',
                parentId: node.parentId,
                isUniversal:
                  node.url.includes('useUniversalLoader') || node.url.includes('universal-loader'),
                size: node.url.length,
              });
            }

            if (node.children) {
              const currentPath = path
                ? `${path} > ${node.title || 'Корень'}`
                : node.title || 'Корень';
              for (const child of node.children) {
                traverseBookmarks(child, currentPath);
              }
            }
          }

          for (const root of tree) {
            traverseBookmarks(root, '');
          }

          logger.info(`📦 Найдено ${bookmarklets.length} букмарклетов`);
          resolve(bookmarklets);
        });
      } catch (error) {
        this[PRIVATE.LOGGER].error('❌ Ошибка получения списка:', error.message);
        reject(error);
      }
    });
  }

  // ============================================================
  // 20. ★★★ ОБНОВЛЕНИЕ (REFRESH) - ИСПРАВЛЕНО ★★★
  // ============================================================

  [PRIVATE.REFRESH]() {
    if (this[PRIVATE.IS_UPDATING]) {
      return Promise.resolve(this[PRIVATE.RESULTS]);
    }

    this[PRIVATE.IS_UPDATING] = true;

    return this[PRIVATE.GET_LIST]()
      .then(bookmarklets => {
        this[PRIVATE.BOOKMARKLETS] = bookmarklets;
        return this[PRIVATE.UPDATE_ALL](bookmarklets);
      })
      .then(results => {
        this[PRIVATE.RESULTS] = results;
        this[PRIVATE.LAST_UPDATE] = Date.now();
        this[PRIVATE.IS_UPDATING] = false;
        return results;
      })
      .catch(error => {
        this[PRIVATE.IS_UPDATING] = false;
        throw error;
      });
  }

  // ============================================================
  // 21. НОВЫЕ ПУБЛИЧНЫЕ МЕТОДЫ ДЛЯ ШАБЛОНОВ
  // ============================================================

  getTemplateGeneratorStats() {
    if (!this[PRIVATE.TEMPLATE_GENERATOR_LOADED] || !this[PRIVATE.TEMPLATE_GENERATOR]) {
      return { error: 'Template generator not loaded' };
    }
    return this[PRIVATE.TEMPLATE_GENERATOR].getStats();
  }

  generateAllTemplates(options = {}) {
    if (!this[PRIVATE.TEMPLATE_GENERATOR_LOADED] || !this[PRIVATE.TEMPLATE_GENERATOR]) {
      this[PRIVATE.LOGGER].error('❌ Генератор шаблонов не загружен');
      return null;
    }
    return this[PRIVATE.TEMPLATE_GENERATOR].generateAllTemplates(options);
  }

  exportTemplates() {
    if (!this[PRIVATE.TEMPLATE_GENERATOR_LOADED] || !this[PRIVATE.TEMPLATE_GENERATOR]) {
      this[PRIVATE.LOGGER].error('❌ Генератор шаблонов не загружен');
      return null;
    }
    return this[PRIVATE.TEMPLATE_GENERATOR].exportToJSON();
  }

  importTemplates(json) {
    if (!this[PRIVATE.TEMPLATE_GENERATOR_LOADED] || !this[PRIVATE.TEMPLATE_GENERATOR]) {
      this[PRIVATE.LOGGER].error('❌ Генератор шаблонов не загружен');
      return null;
    }
    return this[PRIVATE.TEMPLATE_GENERATOR].importFromJSON(json);
  }

  // ============================================================
  // 22. ПУБЛИЧНЫЕ МЕТОДЫ
  // ============================================================

  generateCode(bookmarkData, options = {}) {
    return this[PRIVATE.GENERATE_CODE](bookmarkData, options);
  }

  generateUniversalBookmarklet(bookmarkData, options = {}) {
    return this[PRIVATE.GENERATE_UNIVERSAL_BOOKMARKLET](bookmarkData, options);
  }

  updateBookmark(bookmarkId, newCode) {
    return this[PRIVATE.UPDATE_BOOKMARK](bookmarkId, newCode);
  }

  updateBookmarkUrl(bookmarkId, newCode) {
    return this[PRIVATE.UPDATE_BOOKMARK_URL](bookmarkId, newCode);
  }

  updateAll(bookmarklets) {
    return this[PRIVATE.UPDATE_ALL](bookmarklets);
  }

  getList() {
    return this[PRIVATE.GET_LIST]();
  }

  refresh() {
    return this[PRIVATE.REFRESH]();
  }

  compressBookmarklet(code) {
    return this[PRIVATE.COMPRESS_CODE](code);
  }

  minifyBookmarklet(code) {
    return this[PRIVATE.MINIFY_CODE](code);
  }

  encodeUrl(code) {
    return this[PRIVATE.ENCODE_URL](code);
  }

  decodeUrl(encoded) {
    return this[PRIVATE.DECODE_URL](encoded);
  }

  getCompressionStats() {
    return { ...this[PRIVATE.COMPRESSION_STATS] };
  }

  clearCompressionCache() {
    const size = this[PRIVATE.COMPRESS_CACHE].size;
    this[PRIVATE.COMPRESS_CACHE].clear();
    this[PRIVATE.LOGGER].info(`🗑️ Кеш сжатия очищен (${size} записей)`);
    return size;
  }

  getState() {
    return {
      initialized: this[PRIVATE.INITIALIZED],
      isUpdating: this[PRIVATE.IS_UPDATING],
      bookmarklets: this[PRIVATE.BOOKMARKLETS].length,
      results: this[PRIVATE.RESULTS],
      lastUpdate: this[PRIVATE.LAST_UPDATE],
      version: this[PRIVATE.VERSION],
      dynamicConfig: this[PRIVATE.DYNAMIC_CONFIG],
      extensionState: this[PRIVATE.EXTENSION_STATE],
      urlCacheSize: this[PRIVATE.BOOKMARK_URL_CACHE].size,
      universalLoaderEnabled: this[PRIVATE.DYNAMIC_CONFIG].bookmarklet.useUniversalLoader,
      universalBookmarklets: this[PRIVATE.BOOKMARKLETS].filter(b => b.isUniversal).length,
      compressionStats: this[PRIVATE.COMPRESSION_STATS],
      compressionCacheSize: this[PRIVATE.COMPRESS_CACHE].size,
      templateGeneratorLoaded: this[PRIVATE.TEMPLATE_GENERATOR_LOADED],
      templateGeneratorStats: this[PRIVATE.TEMPLATE_GENERATOR_LOADED]
        ? this[PRIVATE.TEMPLATE_GENERATOR]?.getStats()
        : null,
    };
  }

  getConfig() {
    return { ...this[PRIVATE.CONFIG] };
  }

  getDynamicConfig() {
    return { ...this[PRIVATE.DYNAMIC_CONFIG] };
  }

  updateDynamicConfig(config) {
    this[PRIVATE.DYNAMIC_CONFIG] = { ...this[PRIVATE.DYNAMIC_CONFIG], ...config };
    this[PRIVATE.LOGGER].info(
      '📌 Динамическая конфигурация обновлена:',
      this[PRIVATE.DYNAMIC_CONFIG]
    );

    if (this[PRIVATE.TEMPLATE_GENERATOR_LOADED] && this[PRIVATE.TEMPLATE_GENERATOR]) {
      this[PRIVATE.TEMPLATE_GENERATOR][PRIVATE.CONFIG] = {
        ...this[PRIVATE.TEMPLATE_GENERATOR][PRIVATE.CONFIG],
        basePath: this[PRIVATE.DYNAMIC_CONFIG].bookmarklet.basePath,
        compression: this[PRIVATE.DYNAMIC_CONFIG].compression,
      };
    }

    return this[PRIVATE.DYNAMIC_CONFIG];
  }

  getBookmarklets() {
    return [...this[PRIVATE.BOOKMARKLETS]];
  }

  getBookmarkUrlCache() {
    return new Map(this[PRIVATE.BOOKMARK_URL_CACHE]);
  }

  clearCache() {
    this[PRIVATE.CACHE].clear();
    this[PRIVATE.BOOKMARK_URL_CACHE].clear();
    this[PRIVATE.COMPRESS_CACHE].clear();
    this[PRIVATE.LOADER_CACHE].clear();
    if (this[PRIVATE.TEMPLATE_GENERATOR_LOADED] && this[PRIVATE.TEMPLATE_GENERATOR]) {
      this[PRIVATE.TEMPLATE_GENERATOR].clearAll();
    }
    return this;
  }

  reset() {
    this[PRIVATE.BOOKMARKLETS] = [];
    this[PRIVATE.RESULTS] = null;
    this[PRIVATE.CACHE].clear();
    this[PRIVATE.BOOKMARK_URL_CACHE].clear();
    this[PRIVATE.COMPRESS_CACHE].clear();
    this[PRIVATE.LOADER_CACHE].clear();
    this[PRIVATE.COMPRESSION_STATS] = {
      total: 0,
      saved: 0,
      originalSize: 0,
      compressedSize: 0,
      ratio: 0,
    };
    if (this[PRIVATE.TEMPLATE_GENERATOR_LOADED] && this[PRIVATE.TEMPLATE_GENERATOR]) {
      this[PRIVATE.TEMPLATE_GENERATOR].clearAll();
    }
    this[PRIVATE.IS_UPDATING] = false;
    this[PRIVATE.LAST_UPDATE] = null;
    return this;
  }
}

// ============================================================
// 23. ОСНОВНОЙ КЛАСС BACKGROUND SERVICE
// ============================================================

class BackgroundService {
  constructor(options = {}) {
    const debug = options.debug !== false;
    this[PRIVATE.LOGGER] = createLogger(debug, 'Background');
    const logger = this[PRIVATE.LOGGER];

    this[PRIVATE.CONFIG] = { ...DEFAULT_CONFIG, ...options };
    this[PRIVATE.VERSION] = options.version || DEFAULT_CONFIG.version;
    this[PRIVATE.BUILD] = options.build || '2026-07-22';
    this[PRIVATE.DYNAMIC_CONFIG] = { ...DEFAULT_DYNAMIC_CONFIG, ...options.dynamicConfig };
    this[PRIVATE.INITIALIZED] = false;
    this[PRIVATE.IS_RUNNING] = false;
    this[PRIVATE.IS_DESTROYED] = false;
    this[PRIVATE.EXPORTED] = false;
    this[PRIVATE.IS_MODULE] = false;

    this[PRIVATE.CACHE] = new Map();
    this[PRIVATE.BOOKMARKS] = [];
    this[PRIVATE.BOOKMARKLETS_LIST] = [];
    this[PRIVATE.FOLDERS] = [];
    this[PRIVATE.RESULTS] = null;
    this[PRIVATE.LAST_UPDATE] = null;
    this[PRIVATE.AUTO_UPDATE_DONE] = false;
    this[PRIVATE.IS_UPDATING] = false;
    this[PRIVATE.TIMERS] = new Map();
    this[PRIVATE.LISTENERS] = new Map();
    this[PRIVATE.BOOKMARK_URL_CACHE] = new Map();
    this[PRIVATE.COMPRESS_CACHE] = new Map();
    this[PRIVATE.LOADER_CACHE] = new Map();
    this[PRIVATE.LOADER_SCRIPTS] = new Map();

    this[PRIVATE.GLOBAL_STATE] = null;
    this[PRIVATE.CHANNEL_MANAGER] = null;
    this[PRIVATE.ENV_PANEL] = null;
    this[PRIVATE.LAST_SYNC] = null;
    this[PRIVATE.SYNC_INTERVAL] = null;
    this[PRIVATE.BOOKMARKLET_TEMPLATE] = null;
    this[PRIVATE.URL_UPDATER] = null;
    this[PRIVATE.UNIVERSAL_LOADER] = null;
    this[PRIVATE.COMPRESSOR] = null;
    this[PRIVATE.TEMPLATE_GENERATOR] = null;
    this[PRIVATE.TEMPLATE_GENERATOR_LOADED] = false;

    this[PRIVATE.EXTENSION_STATE] = {
      isActive: true,
      lastPing: Date.now(),
      connectedClients: 0,
      errors: [],
      lastError: null,
    };

    logger.header('ЗАПУСК BACKGROUND SERVICE (100% СИМВОЛЫ)');
    logger.info(`📦 Версия: ${this[PRIVATE.VERSION]}`);
    logger.info(`📅 Сборка: ${this[PRIVATE.BUILD]}`);
    logger.info(`📌 Динамическая конфигурация:`, this[PRIVATE.DYNAMIC_CONFIG]);
    logger.info(
      `📌 Универсальный загрузчик: ${this[PRIVATE.DYNAMIC_CONFIG].bookmarklet.useUniversalLoader}`
    );
    logger.info(`📌 Сжатие: ${this[PRIVATE.DYNAMIC_CONFIG].compression.enabled}`);

    logger.separator();
    logger.info(`🔑 ПРИВАТНЫХ СИМВОЛОВ: ${Object.keys(PRIVATE).length}`);
    logger.info(`🔑 ПУБЛИЧНЫХ СИМВОЛОВ: ${Object.keys(PUBLIC).length}`);
    logger.separator();

    // Создаем генератор
    this[PRIVATE.GENERATOR] = new BookmarkletGenerator({
      ...this[PRIVATE.CONFIG],
      dynamicConfig: this[PRIVATE.DYNAMIC_CONFIG],
      globalState: this[PRIVATE.GLOBAL_STATE],
      channelManager: this[PRIVATE.CHANNEL_MANAGER],
    });
    this[PRIVATE.GENERATOR_LOADED] = true;
    logger.success('✅ Генератор создан');

    // Инициализируем генератор шаблонов
    this._initTemplateGenerator();

    this._exportSymbols();
    this[PRIVATE.INIT]();
    this._initGlobalState();
    this._initChannel();
    this._setupUrlUpdater();
    this._initUniversalLoader();
    this._initCompressor();

    logger.success('✅ Background Service инициализирован (100% символы)');
    logger.header('ГОТОВ');
  }

  // ============================================================
  // 24. ПРИВАТНЫЕ МЕТОДЫ
  // ============================================================

  _initTemplateGenerator() {
    const logger = this[PRIVATE.LOGGER];
    logger.info('📦 Инициализация генератора шаблонов...');

    try {
      this[PRIVATE.TEMPLATE_GENERATOR] = getTemplateGenerator({
        debug: this[PRIVATE.DYNAMIC_CONFIG].debug,
        basePath: this[PRIVATE.DYNAMIC_CONFIG].bookmarklet.basePath,
        version: this[PRIVATE.VERSION],
        compression: this[PRIVATE.DYNAMIC_CONFIG].compression,
      });
      this[PRIVATE.TEMPLATE_GENERATOR_LOADED] = true;
      logger.success('✅ Генератор шаблонов инициализирован');
    } catch (error) {
      logger.error('❌ Ошибка инициализации генератора шаблонов:', error.message);
      this[PRIVATE.TEMPLATE_GENERATOR_LOADED] = false;
    }
  }

  _exportSymbols() {
    const logger = this[PRIVATE.LOGGER];

    if (typeof self !== 'undefined') {
      self[PUBLIC.API] = this;
      self[PUBLIC.STATE] = this.getState.bind(this);
      self[PUBLIC.CONFIG] = this.getConfig.bind(this);
      self[PUBLIC.LOGGER] = this[PRIVATE.LOGGER];
      self[PUBLIC.GENERATOR] = this[PRIVATE.GENERATOR];
      self[PUBLIC.UPDATER] = this.updateAll.bind(this);
      self[PUBLIC.REFRESHER] = this.refresh.bind(this);
      self[PUBLIC.INSTANCE] = this;
      self[PUBLIC.EVENTS] = {
        on: this.on.bind(this),
        off: this.off.bind(this),
        emit: this.emit.bind(this),
      };
      self[PUBLIC.GLOBAL_STATE] = this[PRIVATE.GLOBAL_STATE];
      self[PUBLIC.CHANNEL] = this[PRIVATE.CHANNEL_MANAGER];
      self[PUBLIC.ENV_PANEL] = this[PRIVATE.ENV_PANEL];
      self[PUBLIC.BOOKMARKS] = this[PRIVATE.BOOKMARKS];
      self[PUBLIC.DYNAMIC_CONFIG] = this[PRIVATE.DYNAMIC_CONFIG];
      self[PUBLIC.UNIVERSAL_LOADER] = this[PRIVATE.UNIVERSAL_LOADER];
      self[PUBLIC.COMPRESSOR] = this[PRIVATE.COMPRESSOR];
      self[PUBLIC.TEMPLATE_GENERATOR] = this[PRIVATE.TEMPLATE_GENERATOR];

      self.__backgroundSymbols = {
        PRIVATE: { ...PRIVATE },
        PUBLIC: { ...PUBLIC },
        version: this[PRIVATE.VERSION],
        dynamicConfig: this[PRIVATE.DYNAMIC_CONFIG],
      };

      this[PRIVATE.EXPORTED] = true;
    }
  }

  _initCompressor() {
    const logger = this[PRIVATE.LOGGER];
    logger.info('🗜️ Инициализация компрессора...');

    this[PRIVATE.COMPRESSOR] = {
      enabled: this[PRIVATE.DYNAMIC_CONFIG].compression.enabled,
      minify: code => this[PRIVATE.GENERATOR].minifyBookmarklet(code),
      compress: code => this[PRIVATE.GENERATOR].compressBookmarklet(code),
      encode: code => this[PRIVATE.GENERATOR].encodeUrl(code),
      decode: encoded => this[PRIVATE.GENERATOR].decodeUrl(encoded),
      getStats: () => this[PRIVATE.GENERATOR].getCompressionStats(),
      clearCache: () => this[PRIVATE.GENERATOR].clearCompressionCache(),
    };

    logger.success('✅ Компрессор инициализирован');
  }

  _initUniversalLoader() {
    const logger = this[PRIVATE.LOGGER];
    logger.info('🔄 Инициализация универсального загрузчика...');

    this[PRIVATE.UNIVERSAL_LOADER] = {
      enabled: this[PRIVATE.DYNAMIC_CONFIG].bookmarklet.useUniversalLoader,
      path: this[PRIVATE.DYNAMIC_CONFIG].bookmarklet.loaderPath,
      cache: this[PRIVATE.LOADER_CACHE],
      scripts: this[PRIVATE.LOADER_SCRIPTS],

      load: (panelType, panelPath, config) =>
        new Promise((resolve, reject) => {
          const cacheKey = `${panelType}:${panelPath}`;

          if (this[PRIVATE.LOADER_CACHE].has(cacheKey)) {
            logger.info(`📦 Загрузчик из кеша: ${cacheKey}`);
            resolve(this[PRIVATE.LOADER_CACHE].get(cacheKey));
            return;
          }

          logger.info(`📦 Загрузка универсального загрузчика: ${cacheKey}`);

          const script = document.createElement('script');
          script.type = 'module';
          script.src = this[PRIVATE.UNIVERSAL_LOADER].path + '?t=' + Date.now();
          script.dataset.panelType = panelType;
          script.dataset.panelPath = panelPath;
          script.dataset.config = JSON.stringify(config);

          script.onload = () => {
            logger.success(`✅ Универсальный загрузчик загружен: ${cacheKey}`);
            this[PRIVATE.LOADER_CACHE].set(cacheKey, { loaded: true, timestamp: Date.now() });
            resolve({ success: true, cacheKey });
          };

          script.onerror = () => {
            logger.error(`❌ Ошибка загрузки универсального загрузчика: ${cacheKey}`);
            reject(new Error(`Failed to load universal loader: ${cacheKey}`));
          };

          document.head.appendChild(script);
          this[PRIVATE.LOADER_SCRIPTS].set(cacheKey, script);
        }),

      getStats: () => ({
        enabled: this[PRIVATE.UNIVERSAL_LOADER].enabled,
        cacheSize: this[PRIVATE.LOADER_CACHE].size,
        scriptsCount: this[PRIVATE.LOADER_SCRIPTS].size,
        path: this[PRIVATE.UNIVERSAL_LOADER].path,
      }),

      clearCache: () => {
        this[PRIVATE.LOADER_CACHE].clear();
        this[PRIVATE.LOADER_SCRIPTS].clear();
        logger.info('🗑️ Кеш универсального загрузчика очищен');
      },
    };

    logger.success('✅ Универсальный загрузчик инициализирован');
  }

  // ============================================================
  // 25. ★★★ ИНИЦИАЛИЗАЦИЯ ★★★
  // ============================================================

  [PRIVATE.INIT]() {
    const logger = this[PRIVATE.LOGGER];
    logger.info('🔧 Инициализация...');

    this[PRIVATE.SETUP_LISTENERS]();
    this[PRIVATE.LOAD_BOOKMARKS]();
    this[PRIVATE.SETUP_TIMERS]();
    this._initDynamicConfig();

    this[PRIVATE.INITIALIZED] = true;
    logger.success('✅ Инициализация завершена');
  }

  // ============================================================
  // 26. ★★★ НАСТРОЙКА СЛУШАТЕЛЕЙ ★★★
  // ============================================================

  [PRIVATE.SETUP_LISTENERS]() {
    const logger = this[PRIVATE.LOGGER];
    logger.info('👂 Настройка слушателей...');

    // Слушатель сообщений от расширения
    if (typeof chrome !== 'undefined' && chrome.runtime) {
      chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
        this[PRIVATE.HANDLE_MESSAGE](message, sender, sendResponse);
        return true; // Асинхронный ответ
      });
      logger.success('✅ Слушатель сообщений настроен');
    }

    // Слушатель изменения закладок
    if (typeof chrome !== 'undefined' && chrome.bookmarks) {
      chrome.bookmarks.onCreated.addListener((id, bookmark) => {
        logger.debug(`📑 Создана закладка: ${bookmark.title}`);
        this[PRIVATE.LOAD_BOOKMARKS]();
      });

      chrome.bookmarks.onRemoved.addListener((id, removeInfo) => {
        logger.debug(`🗑️ Удалена закладка: ${id}`);
        this[PRIVATE.LOAD_BOOKMARKS]();
      });

      chrome.bookmarks.onChanged.addListener((id, changeInfo) => {
        logger.debug(`✏️ Изменена закладка: ${id}`);
        this[PRIVATE.LOAD_BOOKMARKS]();
      });

      chrome.bookmarks.onMoved.addListener((id, moveInfo) => {
        logger.debug(`📂 Перемещена закладка: ${id}`);
        this[PRIVATE.LOAD_BOOKMARKS]();
      });

      logger.success('✅ Слушатели закладок настроены');
    }

    // Слушатель изменений хранилища
    if (typeof chrome !== 'undefined' && chrome.storage) {
      chrome.storage.onChanged.addListener((changes, areaName) => {
        if (areaName === 'local') {
          logger.debug('💾 Изменено хранилище:', changes);
        }
      });
      logger.success('✅ Слушатель хранилища настроен');
    }

    logger.success('✅ Все слушатели настроены');
  }

  // ============================================================
  // 27. ★★★ ОБРАБОТКА СООБЩЕНИЙ ★★★
  // ============================================================

  [PRIVATE.HANDLE_MESSAGE](message, sender, sendResponse) {
    const logger = this[PRIVATE.LOGGER];
    logger.debug(`📨 Получено сообщение: ${message.action || 'unknown'}`);

    try {
      switch (message.action) {
        case 'ping':
          sendResponse({ status: 'ok', timestamp: Date.now() });
          break;

        case 'get_state':
          sendResponse({ success: true, data: this[PRIVATE.GET_STATE]() });
          break;

        case 'get_bookmarks':
          sendResponse({ success: true, data: this[PRIVATE.BOOKMARKS] });
          break;

        case 'get_bookmarklets':
          sendResponse({ success: true, data: this[PRIVATE.BOOKMARKLETS_LIST] });
          break;

        case 'update_bookmarklet':
          const { bookmarkId, newCode } = message;
          this[PRIVATE.UPDATE_BOOKMARK](bookmarkId, newCode)
            .then(result => sendResponse({ success: true, data: result }))
            .catch(error => sendResponse({ success: false, error: error.message }));
          return true;

        case 'refresh_bookmarklets':
          this[PRIVATE.REFRESH]()
            .then(results => sendResponse({ success: true, data: results }))
            .catch(error => sendResponse({ success: false, error: error.message }));
          return true;

        case 'generate_bookmarklet':
          const { bookmarkData, options } = message;
          const code = this[PRIVATE.GENERATE_CODE](bookmarkData, options);
          sendResponse({ success: true, data: code });
          break;

        case 'generate_universal':
          const { bmData, opts } = message;
          const universalCode = this[PRIVATE.GENERATE_UNIVERSAL_BOOKMARKLET](bmData, opts);
          sendResponse({ success: true, data: universalCode });
          break;

        case 'get_dynamic_config':
          sendResponse({ success: true, data: this[PRIVATE.DYNAMIC_CONFIG] });
          break;

        case 'update_dynamic_config':
          const { config } = message;
          this[PRIVATE.UPDATE_DYNAMIC_CONFIG](config);
          sendResponse({ success: true, data: this[PRIVATE.DYNAMIC_CONFIG] });
          break;

        default:
          logger.warn(`⚠️ Неизвестное действие: ${message.action}`);
          sendResponse({ success: false, error: 'Unknown action' });
      }
    } catch (error) {
      logger.error(`❌ Ошибка обработки сообщения: ${error.message}`);
      sendResponse({ success: false, error: error.message });
    }
  }

  // ============================================================
  // 28. ★★★ ЗАГРУЗКА ЗАКЛАДОК ★★★
  // ============================================================

  [PRIVATE.LOAD_BOOKMARKS]() {
    const logger = this[PRIVATE.LOGGER];
    logger.info('📑 Загрузка закладок...');

    if (typeof chrome === 'undefined' || !chrome.bookmarks) {
      logger.warn('⚠️ Chrome bookmarks API не доступен');
      this[PRIVATE.BOOKMARKS] = [];
      this[PRIVATE.BOOKMARKLETS_LIST] = [];
      this[PRIVATE.FOLDERS] = [];
      return;
    }

    try {
      chrome.bookmarks.getTree(tree => {
        if (chrome.runtime.lastError) {
          logger.error('❌ Ошибка получения закладок:', chrome.runtime.lastError.message);
          return;
        }

        const bookmarks = [];
        const bookmarklets = [];
        const folders = [];

        function traverse(node, path = '') {
          if (node.url) {
            const isBookmarklet = node.url && node.url.startsWith('javascript:');
            const bookmark = {
              id: node.id,
              title: node.title || 'Без названия',
              url: node.url,
              path: path || 'Корень',
              parentId: node.parentId,
              isBookmarklet: isBookmarklet,
              type: isBookmarklet ? 'bookmarklet' : 'url',
              size: node.url ? node.url.length : 0,
              dateAdded: node.dateAdded,
              dateLastUsed: node.dateLastUsed,
              index: node.index,
            };
            bookmarks.push(bookmark);

            if (isBookmarklet) {
              bookmarklets.push(bookmark);
            }
          } else if (node.title && node.id !== '0' && node.id !== '1') {
            folders.push({
              id: node.id,
              title: node.title,
              path: path || 'Корень',
              childrenCount: node.children ? node.children.length : 0,
              parentId: node.parentId,
            });
          }

          if (node.children) {
            const currentPath = path
              ? `${path} > ${node.title || 'Корень'}`
              : node.title || 'Корень';
            for (const child of node.children) {
              traverse(child, currentPath);
            }
          }
        }

        for (const root of tree) {
          traverse(root, '');
        }

        this[PRIVATE.BOOKMARKS] = bookmarks;
        this[PRIVATE.BOOKMARKLETS_LIST] = bookmarklets;
        this[PRIVATE.FOLDERS] = folders;

        logger.info(
          `📦 Загружено: ${bookmarks.length} закладок, ${bookmarklets.length} букмарклетов, ${folders.length} папок`
        );

        // Авто-обновление букмарклетов если включено
        if (this[PRIVATE.DYNAMIC_CONFIG].extension.autoUpdate && !this[PRIVATE.AUTO_UPDATE_DONE]) {
          this[PRIVATE.AUTO_UPDATE_DONE] = true;
          setTimeout(() => {
            this[PRIVATE.AUTO_UPDATE_BOOKMARKS]();
          }, 5000);
        }
      });
    } catch (error) {
      logger.error('❌ Ошибка загрузки закладок:', error.message);
      this[PRIVATE.BOOKMARKS] = [];
      this[PRIVATE.BOOKMARKLETS_LIST] = [];
      this[PRIVATE.FOLDERS] = [];
    }
  }

  // ============================================================
  // 29. ★★★ НАСТРОЙКА ТАЙМЕРОВ ★★★
  // ============================================================

  [PRIVATE.SETUP_TIMERS]() {
    const logger = this[PRIVATE.LOGGER];
    logger.info('⏱️ Настройка таймеров...');

    // Очищаем старые таймеры
    for (const [key, timer] of this[PRIVATE.TIMERS]) {
      clearInterval(timer);
      clearTimeout(timer);
    }
    this[PRIVATE.TIMERS].clear();

    // Таймер статуса
    const statusTimer = setInterval(() => {
      this[PRIVATE.EXTENSION_STATE].lastPing = Date.now();
    }, 30000);
    this[PRIVATE.TIMERS].set('status', statusTimer);

    // Таймер обновления закладок
    const bookmarksTimer = setInterval(() => {
      if (this[PRIVATE.INITIALIZED] && !this[PRIVATE.IS_RUNNING]) {
        this[PRIVATE.LOAD_BOOKMARKS]();
      }
    }, this[PRIVATE.DYNAMIC_CONFIG].extension.checkInterval || 60000);
    this[PRIVATE.TIMERS].set('bookmarks', bookmarksTimer);

    // Таймер синхронизации
    const syncTimer = setInterval(() => {
      if (this[PRIVATE.INITIALIZED] && this[PRIVATE.DYNAMIC_CONFIG].state.autoSave) {
        this[PRIVATE.SAVE_STATE]();
      }
    }, this[PRIVATE.DYNAMIC_CONFIG].state.saveInterval || 5000);
    this[PRIVATE.TIMERS].set('sync', syncTimer);

    // Таймер авто-обновления букмарклетов
    if (this[PRIVATE.DYNAMIC_CONFIG].extension.autoUpdate) {
      const autoUpdateTimer = setInterval(() => {
        if (this[PRIVATE.INITIALIZED] && !this[PRIVATE.IS_UPDATING]) {
          this[PRIVATE.AUTO_UPDATE_BOOKMARKS]();
        }
      }, this[PRIVATE.DYNAMIC_CONFIG].extension.updateInterval || 300000);
      this[PRIVATE.TIMERS].set('autoUpdate', autoUpdateTimer);
    }

    logger.success(`✅ Таймеры настроены (${this[PRIVATE.TIMERS].size})`);
  }

  // ============================================================
  // 30. ★★★ АВТО-ОБНОВЛЕНИЕ БУКМАРКЛЕТОВ ★★★
  // ============================================================

  [PRIVATE.AUTO_UPDATE_BOOKMARKS]() {
    const logger = this[PRIVATE.LOGGER];
    logger.info('🔄 Авто-обновление букмарклетов...');

    if (this[PRIVATE.IS_UPDATING]) {
      logger.debug('⏳ Обновление уже выполняется');
      return;
    }

    const bookmarklets = this[PRIVATE.BOOKMARKLETS_LIST];
    if (bookmarklets.length === 0) {
      logger.info('ℹ️ Нет букмарклетов для авто-обновления');
      return;
    }

    this[PRIVATE.IS_UPDATING] = true;

    // Обновляем только букмарклеты, которые требуют обновления
    const outdated = bookmarklets.filter(bm => {
      // Проверяем по размеру или по наличию старых паттернов
      return (bm.url && bm.url.includes('CONFIG')) || bm.url.includes('loadChannelManager');
    });

    if (outdated.length === 0) {
      logger.info('ℹ️ Все букмарклеты актуальны');
      this[PRIVATE.IS_UPDATING] = false;
      return;
    }

    logger.info(`📦 Найдено ${outdated.length} букмарклетов для обновления`);

    this[PRIVATE.UPDATE_ALL](outdated)
      .then(results => {
        logger.success(`✅ Авто-обновление завершено: ${results.updated} обновлено`);
        this[PRIVATE.IS_UPDATING] = false;
        this[PRIVATE.AUTO_UPDATE_DONE] = true;
      })
      .catch(error => {
        logger.error(`❌ Ошибка авто-обновления: ${error.message}`);
        this[PRIVATE.IS_UPDATING] = false;
      });
  }

  // ============================================================
  // 31. ★★★ ПРИНУДИТЕЛЬНОЕ ОБНОВЛЕНИЕ ★★★
  // ============================================================

  [PRIVATE.FORCE_UPDATE]() {
    const logger = this[PRIVATE.LOGGER];
    logger.header('🔄 ПРИНУДИТЕЛЬНОЕ ОБНОВЛЕНИЕ');

    if (this[PRIVATE.IS_UPDATING]) {
      logger.warn('⚠️ Обновление уже выполняется');
      return Promise.resolve(this[PRIVATE.RESULTS]);
    }

    this[PRIVATE.IS_UPDATING] = true;

    return this[PRIVATE.GET_LIST]()
      .then(bookmarklets => {
        logger.info(`📦 Найдено ${bookmarklets.length} букмарклетов`);
        return this[PRIVATE.UPDATE_ALL](bookmarklets);
      })
      .then(results => {
        this[PRIVATE.RESULTS] = results;
        this[PRIVATE.LAST_UPDATE] = Date.now();
        this[PRIVATE.IS_UPDATING] = false;
        logger.success(`✅ Принудительное обновление завершено: ${results.updated} обновлено`);
        return results;
      })
      .catch(error => {
        this[PRIVATE.IS_UPDATING] = false;
        logger.error(`❌ Ошибка принудительного обновления: ${error.message}`);
        throw error;
      });
  }

  // ============================================================
  // 32. ★★★ СОХРАНЕНИЕ/ЗАГРУЗКА СОСТОЯНИЯ ★★★
  // ============================================================

  [PRIVATE.SAVE_STATE]() {
    const logger = this[PRIVATE.LOGGER];
    try {
      const state = {
        version: this[PRIVATE.VERSION],
        build: this[PRIVATE.BUILD],
        lastUpdate: this[PRIVATE.LAST_UPDATE],
        results: this[PRIVATE.RESULTS],
        autoUpdateDone: this[PRIVATE.AUTO_UPDATE_DONE],
        extensionState: this[PRIVATE.EXTENSION_STATE],
        lastSync: this[PRIVATE.LAST_SYNC],
        dynamicConfig: this[PRIVATE.DYNAMIC_CONFIG],
        timestamp: Date.now(),
      };

      if (typeof chrome !== 'undefined' && chrome.storage) {
        chrome.storage.local.set({ [this[PRIVATE.DYNAMIC_CONFIG].state.storageKey]: state }, () => {
          if (chrome.runtime.lastError) {
            logger.warn('Ошибка сохранения состояния:', chrome.runtime.lastError.message);
          }
        });
      }
    } catch (e) {
      logger.warn('Ошибка сохранения состояния:', e.message);
    }
  }

  [PRIVATE.LOAD_STATE]() {
    const logger = this[PRIVATE.LOGGER];
    try {
      if (typeof chrome !== 'undefined' && chrome.storage) {
        chrome.storage.local.get([this[PRIVATE.DYNAMIC_CONFIG].state.storageKey], result => {
          if (chrome.runtime.lastError) {
            logger.warn('Ошибка загрузки состояния:', chrome.runtime.lastError.message);
            return;
          }

          const saved = result[this[PRIVATE.DYNAMIC_CONFIG].state.storageKey];
          if (saved) {
            if (saved.lastUpdate) {
              this[PRIVATE.LAST_UPDATE] = saved.lastUpdate;
            }
            if (saved.results) {
              this[PRIVATE.RESULTS] = saved.results;
            }
            if (saved.autoUpdateDone !== undefined) {
              this[PRIVATE.AUTO_UPDATE_DONE] = saved.autoUpdateDone;
            }
            if (saved.extensionState) {
              this[PRIVATE.EXTENSION_STATE] = saved.extensionState;
            }
            if (saved.lastSync) {
              this[PRIVATE.LAST_SYNC] = saved.lastSync;
            }
            if (saved.dynamicConfig) {
              this[PRIVATE.DYNAMIC_CONFIG] = {
                ...this[PRIVATE.DYNAMIC_CONFIG],
                ...saved.dynamicConfig,
              };
            }
            logger.info('📥 Состояние загружено');
          }
        });
      }
    } catch (e) {
      logger.warn('Ошибка загрузки состояния:', e.message);
    }
  }

  // ============================================================
  // 33. ★★★ ОТКРЫТИЕ POPUP ★★★
  // ============================================================

  [PRIVATE.OPEN_POPUP]() {
    const logger = this[PRIVATE.LOGGER];
    logger.info('📂 Открытие popup...');

    if (typeof chrome === 'undefined' || !chrome.action) {
      logger.warn('⚠️ Chrome action API не доступен');
      return;
    }

    try {
      chrome.action.openPopup();
      logger.success('✅ Popup открыт');
    } catch (error) {
      logger.error('❌ Ошибка открытия popup:', error.message);
    }
  }

  // ============================================================
  // 34. ★★★ ПОЛУЧЕНИЕ СОСТОЯНИЯ ★★★
  // ============================================================

  [PRIVATE.GET_STATE]() {
    return {
      initialized: this[PRIVATE.INITIALIZED],
      isRunning: this[PRIVATE.IS_RUNNING],
      isDestroyed: this[PRIVATE.IS_DESTROYED],
      isUpdating: this[PRIVATE.IS_UPDATING],
      generatorLoaded: this[PRIVATE.GENERATOR_LOADED],
      bookmarksCount: this[PRIVATE.BOOKMARKS].length,
      bookmarkletsCount: this[PRIVATE.BOOKMARKLETS_LIST].length,
      foldersCount: this[PRIVATE.FOLDERS].length,
      lastUpdate: this[PRIVATE.LAST_UPDATE],
      updateResults: this[PRIVATE.RESULTS],
      autoUpdateDone: this[PRIVATE.AUTO_UPDATE_DONE],
      version: this[PRIVATE.VERSION],
      build: this[PRIVATE.BUILD],
      cacheSize: this[PRIVATE.CACHE].size,
      listenersCount: this[PRIVATE.LISTENERS].size,
      timersCount: this[PRIVATE.TIMERS].size,
      dynamicConfig: this[PRIVATE.DYNAMIC_CONFIG],
      globalState: this[PRIVATE.GLOBAL_STATE]?.getState(),
      extensionState: this[PRIVATE.EXTENSION_STATE],
      lastSync: this[PRIVATE.LAST_SYNC],
      urlUpdaterEnabled: this[PRIVATE.DYNAMIC_CONFIG].bookmarklet.updateBookmarkUrl,
      urlCacheSize: this[PRIVATE.BOOKMARK_URL_CACHE].size,
      universalLoaderEnabled: this[PRIVATE.DYNAMIC_CONFIG].bookmarklet.useUniversalLoader,
      universalLoaderStats: this[PRIVATE.UNIVERSAL_LOADER]?.getStats(),
      universalBookmarklets: this[PRIVATE.BOOKMARKLETS_LIST].filter(b => b.isUniversal).length,
      compressionEnabled: this[PRIVATE.DYNAMIC_CONFIG].compression.enabled,
      compressionStats: this[PRIVATE.COMPRESSOR]?.getStats(),
      compressionCacheSize: this[PRIVATE.COMPRESS_CACHE].size,
      templateGeneratorLoaded: this[PRIVATE.TEMPLATE_GENERATOR_LOADED],
      templateGeneratorStats: this[PRIVATE.TEMPLATE_GENERATOR_LOADED]
        ? this[PRIVATE.TEMPLATE_GENERATOR]?.getStats()
        : null,
      exported: this[PRIVATE.EXPORTED],
    };
  }

  // ============================================================
  // 35. ПУБЛИЧНЫЕ МЕТОДЫ
  // ============================================================

  getState() {
    return this[PRIVATE.GET_STATE]();
  }

  getConfig() {
    return { ...this[PRIVATE.CONFIG] };
  }

  getDynamicConfig() {
    return { ...this[PRIVATE.DYNAMIC_CONFIG] };
  }

  updateDynamicConfig(updates) {
    return this[PRIVATE.UPDATE_DYNAMIC_CONFIG](updates);
  }

  getLogger() {
    return this[PRIVATE.LOGGER];
  }

  getGenerator() {
    return this[PRIVATE.GENERATOR];
  }

  getGlobalState() {
    return this[PRIVATE.GLOBAL_STATE];
  }

  getChannelManager() {
    return this[PRIVATE.CHANNEL_MANAGER];
  }

  getUniversalLoader() {
    return this[PRIVATE.UNIVERSAL_LOADER];
  }

  getCompressor() {
    return this[PRIVATE.COMPRESSOR];
  }

  getTemplateGenerator() {
    return this[PRIVATE.TEMPLATE_GENERATOR];
  }

  isGeneratorLoaded() {
    return this[PRIVATE.GENERATOR_LOADED];
  }

  isTemplateGeneratorLoaded() {
    return this[PRIVATE.TEMPLATE_GENERATOR_LOADED];
  }

  refresh() {
    return this[PRIVATE.REFRESH]();
  }

  updateAll() {
    return this[PRIVATE.FORCE_UPDATE]();
  }

  updateBookmarkUrl(bookmarkId, newCode) {
    return this[PRIVATE.UPDATE_BOOKMARK_URL](bookmarkId, newCode);
  }

  generateUniversalBookmarklet(bookmarkData, options) {
    return this[PRIVATE.GENERATE_UNIVERSAL_BOOKMARKLET](bookmarkData, options);
  }

  generateAllTemplates(options = {}) {
    return this[PRIVATE.GENERATOR].generateAllTemplates(options);
  }

  exportTemplates() {
    return this[PRIVATE.GENERATOR].exportTemplates();
  }

  importTemplates(json) {
    return this[PRIVATE.GENERATOR].importTemplates(json);
  }

  compressCode(code) {
    return this[PRIVATE.COMPRESSOR]?.compress(code) || code;
  }

  minifyCode(code) {
    return this[PRIVATE.COMPRESSOR]?.minify(code) || code;
  }

  openPopup() {
    this[PRIVATE.OPEN_POPUP]();
  }

  syncState() {
    this[PRIVATE.SAVE_STATE]();
    this[PRIVATE.LAST_SYNC] = Date.now();
    return this[PRIVATE.GLOBAL_STATE]?.getState();
  }

  resetAll() {
    this[PRIVATE.GLOBAL_STATE]?.reset();
    this[PRIVATE.DYNAMIC_CONFIG] = { ...DEFAULT_DYNAMIC_CONFIG };
    this[PRIVATE.SAVE_STATE]();
    this[PRIVATE.CACHE].clear();
    this[PRIVATE.BOOKMARK_URL_CACHE].clear();
    this[PRIVATE.COMPRESS_CACHE].clear();
    this[PRIVATE.LOADER_CACHE].clear();
    this[PRIVATE.LOADER_SCRIPTS].clear();
    this[PRIVATE.COMPRESSION_STATS] = {
      total: 0,
      saved: 0,
      originalSize: 0,
      compressedSize: 0,
      ratio: 0,
    };
    if (this[PRIVATE.TEMPLATE_GENERATOR_LOADED] && this[PRIVATE.TEMPLATE_GENERATOR]) {
      this[PRIVATE.TEMPLATE_GENERATOR].clearAll();
    }
    this[PRIVATE.LOGGER].info('🔄 Все данные сброшены');
    return this;
  }

  on(event, callback) {
    if (!this[PRIVATE.LISTENERS].has(event)) {
      this[PRIVATE.LISTENERS].set(event, []);
    }
    this[PRIVATE.LISTENERS].get(event).push(callback);
    return () => this.off(event, callback);
  }

  off(event, callback) {
    if (this[PRIVATE.LISTENERS].has(event)) {
      const listeners = this[PRIVATE.LISTENERS].get(event);
      const index = listeners.indexOf(callback);
      if (index !== -1) {
        listeners.splice(index, 1);
      }
      if (listeners.length === 0) {
        this[PRIVATE.LISTENERS].delete(event);
      }
    }
  }

  emit(event, data) {
    if (this[PRIVATE.LISTENERS].has(event)) {
      const listeners = this[PRIVATE.LISTENERS].get(event);
      for (const callback of listeners) {
        try {
          callback(data);
        } catch (error) {
          // Игнорируем ошибки в слушателях
        }
      }
    }
  }

  // ============================================================
  // 36. ★★★ УНИЧТОЖЕНИЕ ★★★
  // ============================================================

  destroy() {
    if (this[PRIVATE.IS_DESTROYED]) {
      this[PRIVATE.LOGGER].warn('⚠️ Background Service уже уничтожен');
      return;
    }

    const logger = this[PRIVATE.LOGGER];
    logger.warn('🗑️ Уничтожение Background Service...');

    // Очищаем таймеры
    for (const [key, timer] of this[PRIVATE.TIMERS]) {
      clearInterval(timer);
      clearTimeout(timer);
    }
    this[PRIVATE.TIMERS].clear();

    // Очищаем слушатели
    this[PRIVATE.LISTENERS].clear();

    // Очищаем кеш
    this[PRIVATE.CACHE].clear();
    this[PRIVATE.BOOKMARK_URL_CACHE].clear();
    this[PRIVATE.COMPRESS_CACHE].clear();
    this[PRIVATE.LOADER_CACHE].clear();
    this[PRIVATE.LOADER_SCRIPTS].clear();

    // Уничтожаем генератор
    if (this[PRIVATE.GENERATOR]) {
      this[PRIVATE.GENERATOR].reset();
    }

    // Уничтожаем ChannelManager
    if (this[PRIVATE.CHANNEL_MANAGER]?.destroy) {
      this[PRIVATE.CHANNEL_MANAGER].destroy();
    }

    // Уничтожаем UniversalLoader
    if (this[PRIVATE.UNIVERSAL_LOADER]) {
      this[PRIVATE.UNIVERSAL_LOADER].clearCache();
    }

    // Уничтожаем Compressor
    if (this[PRIVATE.COMPRESSOR]) {
      this[PRIVATE.COMPRESSOR].clearCache();
    }

    // Уничтожаем TemplateGenerator
    if (this[PRIVATE.TEMPLATE_GENERATOR_LOADED] && this[PRIVATE.TEMPLATE_GENERATOR]) {
      this[PRIVATE.TEMPLATE_GENERATOR].destroy();
    }

    // Удаляем глобальные ссылки
    if (typeof self !== 'undefined') {
      delete self[PUBLIC.API];
      delete self[PUBLIC.STATE];
      delete self[PUBLIC.CONFIG];
      delete self[PUBLIC.LOGGER];
      delete self[PUBLIC.GENERATOR];
      delete self[PUBLIC.UPDATER];
      delete self[PUBLIC.REFRESHER];
      delete self[PUBLIC.INSTANCE];
      delete self[PUBLIC.EVENTS];
      delete self[PUBLIC.GLOBAL_STATE];
      delete self[PUBLIC.CHANNEL];
      delete self[PUBLIC.ENV_PANEL];
      delete self[PUBLIC.BOOKMARKS];
      delete self[PUBLIC.DYNAMIC_CONFIG];
      delete self[PUBLIC.UNIVERSAL_LOADER];
      delete self[PUBLIC.COMPRESSOR];
      delete self[PUBLIC.TEMPLATE_GENERATOR];
      delete self.__backgroundSymbols;
    }

    this[PRIVATE.IS_DESTROYED] = true;
    this[PRIVATE.INITIALIZED] = false;
    this[PRIVATE.EXPORTED] = false;

    logger.success('🗑️ Background Service уничтожен');
  }
}

// ============================================================
// 37. СОЗДАНИЕ ЭКЗЕМПЛЯРА
// ============================================================

let backgroundInstance = null;

function getBackgroundInstance(options = {}) {
  if (!backgroundInstance) {
    backgroundInstance = new BackgroundService(options);
    if (typeof self !== 'undefined') {
      self.__backgroundInstance = backgroundInstance;
    }
  }
  return backgroundInstance;
}

// ============================================================
// 38. ЭКСПОРТ
// ============================================================

export {
  PRIVATE,
  PUBLIC,
  DEFAULT_DYNAMIC_CONFIG,
  DEFAULT_CONFIG,
  createLogger,
  BookmarkletGenerator,
  BackgroundService,
  getBackgroundInstance,
};

// ============================================================
// 39. ИНИЦИАЛИЗАЦИЯ ПРИ ЗАГРУЗКЕ
// ============================================================

if (typeof self !== 'undefined') {
  const instance = getBackgroundInstance({
    debug: true,
    version: '2.0.1',
    build: '2026-07-22',
  });

  console.log('╔═══════════════════════════════════════════════════════════════════════════════╗');
  console.log('║              📦 BACKGROUND SERVICE (100% СИМВОЛЫ) v2.0.1                     ║');
  console.log('╠═══════════════════════════════════════════════════════════════════════════════╣');
  console.log('║  📋 Все логи выводятся в консоль с цветовой разметкой                       ║');
  console.log('║  🔑 Полная изоляция через приватные символы                                 ║');
  console.log('║  🔓 Публичные символы через Symbol.for                                      ║');
  console.log('║  📦 Генерация компактных букмарклетов через единую точку входа              ║');
  console.log('║  🔄 Автоматическое обновление букмарклетов                                  ║');
  console.log('║  📊 Полная статистика работы                                                ║');
  console.log('║  ✅ ИСПРАВЛЕНЫ: асинхронные вызовы загрузки букмарклетов                    ║');
  console.log('║  ✅ ИСПРАВЛЕНА: генерация компактных букмарклетов                           ║');
  console.log('║  ✅ ДОБАВЛЕНЫ: setupListeners, setupTimers, loadBookmarks, handleMessage    ║');
  console.log('╚═══════════════════════════════════════════════════════════════════════════════╝');

  console.log('📋 ДОСТУПНЫЕ КОМАНДЫ:');
  console.log('  __backgroundInstance.getState()                    - состояние');
  console.log('  __backgroundInstance.openPopup()                   - открыть окно');
  console.log('  __backgroundInstance.getGenerator()                - получить генератор');
  console.log('  __backgroundInstance.getTemplateGenerator()        - получить генератор шаблонов');
  console.log('  __backgroundInstance.refresh()                     - обновить');
  console.log('  __backgroundInstance.updateAll()                   - обновить все');
  console.log('  __backgroundInstance.compressCode()                - сжать код');
  console.log('  __backgroundInstance.minifyCode()                  - минифицировать код');
  console.log('  __backgroundInstance.generateAllTemplates()        - сгенерировать все шаблоны');
  console.log('  __backgroundInstance.exportTemplates()             - экспорт шаблонов');
  console.log('  __backgroundInstance.importTemplates(json)         - импорт шаблонов');
  console.log('  __backgroundInstance.on(event, cb)                 - подписка');
  console.log('  __backgroundInstance.emit(event)                   - событие');
  console.log('  __backgroundInstance.destroy()                     - уничтожить');
  console.log('  __backgroundInstance.getBookmarks()                - получить закладки');
  console.log('  __backgroundInstance.getBookmarklets()             - получить букмарклеты');
  console.log('  __backgroundInstance.clearCache()                  - очистить кеш');
  console.log('');
  console.log('📋 КОМАНДЫ ДЛЯ БУКМАРКЛЕТОВ:');
  console.log(
    '  __backgroundInstance.generateCode(data, opts)      - сгенерировать компактный букмарклет'
  );
  console.log('  __backgroundInstance.generateUniversalBookmarklet() - универсальный букмарклет');
  console.log('  __backgroundInstance.updateBookmark(id, code)      - обновить букмарклет');
  console.log('  __backgroundInstance.updateBookmarkUrl(id, code)   - обновить URL букмарклета');
  console.log(
    '  __backgroundInstance.getList()                     - получить список букмарклетов'
  );
  console.log('');
  console.log('📋 ПРИВАТНЫХ СИМВОЛОВ:', Object.keys(PRIVATE).length);
  console.log('📋 ПУБЛИЧНЫХ СИМВОЛОВ:', Object.keys(PUBLIC).length);
  console.log('═'.repeat(70));
}
