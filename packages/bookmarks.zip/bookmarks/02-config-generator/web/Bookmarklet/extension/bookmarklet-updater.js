// web/Bookmarklet/extension/bookmarklet-updater.js - ИСПРАВЛЕННАЯ ВЕРСИЯ
// Версия: 2.1.7
// 100% СИМВОЛЫ - полная изоляция и безопасность
// ИСПРАВЛЕНО: Логирование с использованием console.group и console.trace
// ИСПРАВЛЕНО: Добавлен await для LOAD_BOOKMARKLETS_FROM_CHROME

// ============================================================
// 1. ПРИВАТНЫЕ СИМВОЛЫ (100% изоляция)
// ============================================================

const PRIVATE = {
    // Основные символы
    CONFIG: Symbol('updater.config'),
    LOGGER: Symbol('updater.logger'),
    CACHE: Symbol('updater.cache'),
    VERSION: Symbol('updater.version'),
    BUILD: Symbol('updater.build'),
    INITIALIZED: Symbol('updater.initialized'),
    IS_RUNNING: Symbol('updater.isRunning'),
    IS_DESTROYED: Symbol('updater.isDestroyed'),
    EXPORTED: Symbol('updater.exported'),

    // Данные
    RESULTS: Symbol('updater.results'),
    STATS: Symbol('updater.stats'),
    UPDATE_DATA: Symbol('updater.updateData'),
    UPDATE_CONFIG: Symbol('updater.updateConfig'),
    BOOKMARKLETS: Symbol('updater.bookmarklets'),
    BOOKMARKLETS_MAP: Symbol('updater.bookmarkletsMap'),

    // Компоненты
    GENERATOR: Symbol('updater.generator'),
    BACKGROUND: Symbol('updater.background'),
    BACKGROUND_INSTANCE: Symbol('updater.backgroundInstance'),

    // Таймеры
    AUTO_TIMER: Symbol('updater.autoTimer'),
    TIMERS: Symbol('updater.timers'),
    UPDATE_TIMEOUT: Symbol('updater.updateTimeout'),

    // Метаданные
    METADATA: Symbol('updater.metadata'),
    CONTEXT: Symbol('updater.context'),
    LOG_HISTORY: Symbol('updater.logHistory'),

    // Слушатели
    LISTENERS: Symbol('updater.listeners'),
    EVENT_HANDLERS: Symbol('updater.eventHandlers'),

    // Безопасность
    SECURE: Symbol('updater.secure'),
    VALIDATOR: Symbol('updater.validator'),

    // ★★★ БЕЗОПАСНЫЙ ВЫЗОВ МЕТОДА ★★★
    SAFE_CALL: Symbol('updater.safeCall'),

    // Методы (приватные)
    LOAD_BOOKMARKLETS: Symbol('updater.loadBookmarklets'),
    LOAD_BOOKMARKLETS_FROM_CHROME: Symbol('updater.loadBookmarkletsFromChrome'),
    PROCESS_UPDATES: Symbol('updater.processUpdates'),
    PROCESS_BATCH: Symbol('updater.processBatch'),
    UPDATE_SINGLE: Symbol('updater.updateSingle'),
    DETECT_TYPE: Symbol('updater.detectType'),
    GET_BOOKMARK_BY_ID: Symbol('updater.getBookmarkById'),
    UPDATE_BOOKMARK_VIA_CHROME: Symbol('updater.updateBookmarkViaChrome'),
    SAVE_RESULTS: Symbol('updater.saveResults'),
    LOAD_UPDATE_DATA: Symbol('updater.loadUpdateData'),
    SAVE_UPDATE_DATA: Symbol('updater.saveUpdateData'),
    START_AUTO_UPDATE: Symbol('updater.startAutoUpdate'),
    STOP_AUTO_UPDATE: Symbol('updater.stopAutoUpdate'),
    DELAY: Symbol('updater.delay'),
    EMIT: Symbol('updater.emit'),
    NOTIFY: Symbol('updater.notify'),
    GET_STATE: Symbol('updater.getState'),
    RESET: Symbol('updater.reset'),
    DESTROY: Symbol('updater.destroy'),
    EXPORT_SYMBOLS: Symbol('updater.exportSymbols'),

    // ★★★ НОВЫЕ МЕТОДЫ ДЛЯ КОНФИГА ★★★
    INITIALIZE_WITH_CONFIG: Symbol('updater.initializeWithConfig'),
    PARSE_CONFIG_TO_UPDATE_DATA: Symbol('updater.parseConfigToUpdateData'),
    LOAD_UPDATE_CONFIG: Symbol('updater.loadUpdateConfig'),
    SAVE_UPDATE_CONFIG: Symbol('updater.saveUpdateConfig'),
    SET_UPDATE_CONFIG: Symbol('updater.setUpdateConfig'),
    GET_UPDATE_CONFIG: Symbol('updater.getUpdateConfig'),
    UPDATE_FROM_CONFIG: Symbol('updater.updateFromConfig'),

    // ★★★ НОВЫЕ ГЕТТЕРЫ/СЕТТЕРЫ ★★★
    SET_CONFIG: Symbol('updater.setConfig'),
    GET_CONFIG: Symbol('updater.getConfig'),
    SET_DATA: Symbol('updater.setData'),
    GET_DATA: Symbol('updater.getData'),

    // ★★★ БЕЗОПАСНОЕ ЛОГГИРОВАНИЕ ★★★
    SAFE_LOG: Symbol('updater.safeLog'),
    SAFE_ERROR: Symbol('updater.safeError'),
    SAFE_WARN: Symbol('updater.safeWarn'),
    SAFE_INFO: Symbol('updater.safeInfo'),
    SAFE_DEBUG: Symbol('updater.safeDebug'),
    SAFE_SUCCESS: Symbol('updater.safeSuccess'),

    // ★★★ ХРАНИЛИЩЕ ★★★
    SAFE_STORAGE_GET: Symbol('updater.safeStorageGet'),
    SAFE_STORAGE_SET: Symbol('updater.safeStorageSet'),

    // ★★★ НОВЫЕ СИМВОЛЫ ДЛЯ ЛОГГЕРА ★★★
    LOG_GROUP: Symbol('updater.logGroup'),
    LOG_GROUP_END: Symbol('updater.logGroupEnd'),
    LOG_TRACE: Symbol('updater.logTrace'),
    LOG_WITH_GROUP: Symbol('updater.logWithGroup'),
};

// ============================================================
// 2. ПУБЛИЧНЫЕ СИМВОЛЫ (доступны через Symbol.for)
// ============================================================

const PUBLIC = {
    API: Symbol.for('bookmarklet-updater.api'),
    STATE: Symbol.for('bookmarklet-updater.state'),
    CONFIG: Symbol.for('bookmarklet-updater.config'),
    LOGGER: Symbol.for('bookmarklet-updater.logger'),
    INSTANCE: Symbol.for('bookmarklet-updater.instance'),
    UPDATER: Symbol.for('bookmarklet-updater.updater'),
    RESULTS: Symbol.for('bookmarklet-updater.results'),
    STATS: Symbol.for('bookmarklet-updater.stats'),
    EVENTS: Symbol.for('bookmarklet-updater.events'),
    UPDATE_CONFIG: Symbol.for('bookmarklet-updater.updateConfig'),
};

// ============================================================
// 3. КОНФИГУРАЦИЯ
// ============================================================

const DEFAULT_CONFIG = {
    version: '2.1.7',
    build: '2026-07-22',
    debug: true,
    autoUpdate: true,
    updateInterval: 60000,
    generateNewCode: true,
    updateOnlyChanged: true,
    preserveTitle: false,
    batchSize: 10,
    delayBetween: 500,
    maxRetries: 3,
    retryDelay: 1000,
    timeout: 30000,
    saveResults: true,
    saveData: true,
    storageKey: 'bookmarklet-updater-data',
    resultsKey: 'bookmarklet-updater-results',
    configKey: 'bookmarklet-update-config',
};

// ============================================================
// 4. ЛОГГЕР С ПРИВЯЗКОЙ КОНТЕКСТА (100% СИМВОЛЫ) - ИСПРАВЛЕННЫЙ
// ============================================================

const LOGGER_SYMBOLS = {
    HISTORY: Symbol('logger.history'),
    MAX_HISTORY: Symbol('logger.maxHistory'),
    DEBUG: Symbol('logger.debug'),
    INSTANCE_ID: Symbol('logger.instanceId'),
};

function createLogger(debug = true, instanceId = 'Updater') {
    const logger = {};

    logger[LOGGER_SYMBOLS.HISTORY] = [];
    logger[LOGGER_SYMBOLS.MAX_HISTORY] = 200;
    logger[LOGGER_SYMBOLS.DEBUG] = debug;
    logger[LOGGER_SYMBOLS.INSTANCE_ID] = instanceId;

    // ★★★ ОСНОВНОЙ МЕТОД ЛОГГИРОВАНИЯ С GROUP + TRACE ★★★
    logger._log = function (level, message, data = null) {
        if (!this || typeof this !== 'object') {
            console.log(`[${level}] ${message}`, data || '');
            return;
        }

        const isDebugEnabled = this[LOGGER_SYMBOLS.DEBUG] !== undefined
            ? this[LOGGER_SYMBOLS.DEBUG]
            : true;

        if (!isDebugEnabled && level !== 'error') {
            return;
        }

        const history = this[LOGGER_SYMBOLS.HISTORY] || [];
        const maxHistory = this[LOGGER_SYMBOLS.MAX_HISTORY] || 200;

        const timestamp = new Date().toISOString().slice(11, 23);
        const instanceId = this[LOGGER_SYMBOLS.INSTANCE_ID] || 'Updater';
        const prefix = `[${timestamp}] [${instanceId}]`;

        // ★★★ СОХРАНЯЕМ В ИСТОРИЮ ★★★
        history.push({ timestamp, level, message, data });
        if (history.length > maxHistory) {
            history.shift();
        }

        // ★★★ ★★★ ГРУППА С TRACE ★★★ ★★★
        const groupTitle = `${prefix} ${message}`;

        // Создаём группу
        if (data !== null && data !== undefined) {
            console.groupCollapsed(`%c${groupTitle}`, 'color: #74b9ff; font-weight: bold;');
            // Выводим данные внутри группы
            console.log('%c📦 Данные:', 'color: #fdcb6e; font-weight: bold;', data);
        } else {
            console.groupCollapsed(`%c${groupTitle}`, 'color: #74b9ff; font-weight: bold;');
        }

        // ★★★ ВСЕГДА ДОБАВЛЯЕМ TRACE ★★★
        console.trace('📍 Стек вызовов:');

        // Если это ошибка - добавляем дополнительную информацию
        if (level === 'error' && data && data.stack) {
            console.log('%c📚 Stack:', 'color: #ff6b6b; font-weight: bold;', data.stack);
        }

        // Если это объект с дополнительными полями - показываем их
        if (data !== null && data !== undefined && typeof data === 'object') {
            if (data.stack && level === 'error') {
                // уже показали выше
            } else if (data.details) {
                console.log('%c📋 Детали:', 'color: #a29bfe; font-weight: bold;', data.details);
            }
        }

        // Закрываем группу
        console.groupEnd();
    };

    // ★★★ БЕЗОПАСНЫЕ МЕТОДЫ ЛОГГИРОВАНИЯ ★★★
    logger.error = function (msg, d) {
        if (typeof this._log === 'function') {
            this._log('error', `❌ ${msg}`, d);
        } else {
            console.error(`❌ ${msg}`, d);
        }
    };

    logger.warn = function (msg, d) {
        if (typeof this._log === 'function') {
            this._log('warn', `⚠️ ${msg}`, d);
        } else {
            console.warn(`⚠️ ${msg}`, d);
        }
    };

    logger.info = function (msg, d) {
        if (typeof this._log === 'function') {
            this._log('info', `ℹ️ ${msg}`, d);
        } else {
            console.log(`ℹ️ ${msg}`, d);
        }
    };

    logger.debug = function (msg, d) {
        if (typeof this._log === 'function') {
            this._log('debug', `🔍 ${msg}`, d);
        } else {
            console.log(`🔍 ${msg}`, d);
        }
    };

    logger.success = function (msg, d) {
        if (typeof this._log === 'function') {
            this._log('info', `✅ ${msg}`, d);
        } else {
            console.log(`✅ ${msg}`, d);
        }
    };

    // ★★★ СТИЛИЗОВАННЫЕ МЕТОДЫ ★★★
    logger.header = function (title) {
        console.log('%c' + '═'.repeat(70), 'color: #636e72;');
        console.log(
            '%c  📦 ' + title,
            'background: #1a1a2e; color: #fff; padding: 4px 12px; border-radius: 4px; font-weight: bold;'
        );
        console.log('%c' + '═'.repeat(70), 'color: #636e72;');
    };

    logger.separator = function () {
        console.log('%c' + '─'.repeat(70), 'color: #636e72;');
    };

    logger.symbol = function (name, symbol) {
        console.log(`  🔑 ${name}: ${String(symbol)}`);
    };

    logger.private = function (name, symbol) {
        console.log(`  🔒 ${name}: ${String(symbol)}`);
    };

    // ★★★ МЕТОД ДЛЯ ГРУППИРОВКИ С ТРАССИРОВКОЙ ★★★
    logger.group = function (title, data = null, collapsed = true) {
        const prefix = `[${new Date().toISOString().slice(11, 23)}] [${this[LOGGER_SYMBOLS.INSTANCE_ID]}]`;
        const groupTitle = `${prefix} ${title}`;

        if (collapsed) {
            console.groupCollapsed(`%c${groupTitle}`, 'color: #667eea; font-weight: bold;');
        } else {
            console.group(`%c${groupTitle}`, 'color: #667eea; font-weight: bold;');
        }

        if (data !== null && data !== undefined) {
            console.log('%c📦 Данные:', 'color: #fdcb6e; font-weight: bold;', data);
        }

        console.trace('📍 Стек вызовов:');
        return this;
    };

    logger.groupEnd = function () {
        console.groupEnd();
        return this;
    };

    // ★★★ МЕТОД ДЛЯ ЛОГИРОВАНИЯ С ГРУППОЙ ★★★
    logger.logWithGroup = function (level, message, data = null) {
        const prefix = `[${new Date().toISOString().slice(11, 23)}] [${this[LOGGER_SYMBOLS.INSTANCE_ID]}]`;
        const groupTitle = `${prefix} ${message}`;

        const isDebugEnabled = this[LOGGER_SYMBOLS.DEBUG] !== undefined
            ? this[LOGGER_SYMBOLS.DEBUG]
            : true;

        if (!isDebugEnabled && level !== 'error') {
            return this;
        }

        // Сохраняем в историю
        const history = this[LOGGER_SYMBOLS.HISTORY] || [];
        const maxHistory = this[LOGGER_SYMBOLS.MAX_HISTORY] || 200;
        history.push({ timestamp: new Date().toISOString(), level, message, data });
        if (history.length > maxHistory) {
            history.shift();
        }

        // Создаём группу
        const levelColors = {
            error: '#ff6b6b',
            warn: '#fdcb6e',
            info: '#74b9ff',
            debug: '#a29bfe',
            success: '#00b894',
        };
        const color = levelColors[level] || '#74b9ff';

        console.groupCollapsed(`%c${groupTitle}`, `color: ${color}; font-weight: bold;`);

        if (data !== null && data !== undefined) {
            console.log('%c📦 Данные:', 'color: #fdcb6e; font-weight: bold;', data);
        }

        console.trace('📍 Стек вызовов:');

        if (level === 'error' && data && data.stack) {
            console.log('%c📚 Stack:', 'color: #ff6b6b; font-weight: bold;', data.stack);
        }

        console.groupEnd();
        return this;
    };

    // ★★★ МЕТОД ДЛЯ TRACE ★★★
    logger.trace = function (message, data = null) {
        console.log(`%c🔍 ${message}`, 'color: #fdcb6e; font-weight: bold;', data || '');
        console.trace('📍 Стек вызовов:');
        return this;
    };

    logger.getHistory = function () {
        return [...(this[LOGGER_SYMBOLS.HISTORY] || [])];
    };

    logger.clearHistory = function () {
        this[LOGGER_SYMBOLS.HISTORY] = [];
        return this;
    };

    return logger;
}

// ============================================================
// 5. ВАЛИДАТОР (с приватными символами)
// ============================================================

const VALIDATOR = {
    [PRIVATE.VALIDATOR]: {
        isValidId: id => id && typeof id === 'string' && id.length > 0,
        isValidTitle: title => title && typeof title === 'string' && title.length > 0,
        isValidType: type => ['main', 'env', 'logs', 'debug', 'widget', 'sw', 'manager'].includes(type),
        isValidConfig: config => config && typeof config === 'object',
        isValidData: data => data && typeof data === 'object',
        isValidCallback: fn => typeof fn === 'function',
        isValidUrl: url => url && typeof url === 'string' && url.length > 0,
    },
    [PRIVATE.SECURE]: {
        sanitize: value => {
            if (value === null || value === undefined) {
                return null;
            }
            if (typeof value === 'string') {
                return value.replace(/[<>]/g, '');
            }
            if (typeof value === 'object') {
                try {
                    return JSON.parse(JSON.stringify(value));
                } catch {
                    return null;
                }
            }
            return value;
        },
        validate: (value, schema) => {
            if (!schema) {
                return true;
            }
            if (schema.type && typeof value !== schema.type) {
                return false;
            }
            if (schema.min !== undefined && value < schema.min) {
                return false;
            }
            if (schema.max !== undefined && value > schema.max) {
                return false;
            }
            if (schema.pattern && !schema.pattern.test(value)) {
                return false;
            }
            return true;
        },
    },
};

// ============================================================
// 6. ОСНОВНОЙ КЛАСС ОБНОВЛЯТОРА БУКМАРКЛЕТОВ (100% СИМВОЛЫ)
// ============================================================

class BookmarkletUpdater {
    constructor(options = {}) {
        // ============================================================
        // 6.1 ★★★ ИНИЦИАЛИЗАЦИЯ КОНФИГУРАЦИИ ★★★
        // ============================================================

        this._config = { ...DEFAULT_CONFIG, ...options };
        this._version = options.version || DEFAULT_CONFIG.version;
        this._build = options.build || DEFAULT_CONFIG.build;

        // ============================================================
        // 6.2 СОЗДАНИЕ ЛОГГЕРА
        // ============================================================

        this._logger = createLogger(this._config.debug !== false, 'Updater');
        const logger = this._logger;

        // ============================================================
        // 6.3 ИНИЦИАЛИЗАЦИЯ ХРАНИЛИЩ
        // ============================================================

        this._cache = new Map();
        this._bookmarklets = [];
        this._bookmarkletsMap = new Map();
        this._results = null;
        this._updateData = options.initialData || null;
        this._updateConfig = null;
        this._timers = new Map();
        this._listeners = [];
        this._eventHandlers = new Map();
        this._logHistory = [];

        // ============================================================
        // 6.4 ИНИЦИАЛИЗАЦИЯ КОМПОНЕНТОВ
        // ============================================================

        this._generator = null;
        this._background = null;
        this._backgroundInstance = null;

        // ============================================================
        // 6.5 ИНИЦИАЛИЗАЦИЯ ТАЙМЕРОВ
        // ============================================================

        this._autoTimer = null;
        this._updateTimeout = null;

        // ============================================================
        // 6.6 ИНИЦИАЛИЗАЦИЯ СТАТИСТИКИ
        // ============================================================

        this._stats = {
            total: 0,
            updated: 0,
            skipped: 0,
            failed: 0,
            startTime: null,
            endTime: null,
            duration: 0,
            errors: [],
            details: [],
        };

        // ============================================================
        // 6.7 ИНИЦИАЛИЗАЦИЯ МЕТАДАННЫХ
        // ============================================================

        this._metadata = {
            created: Date.now(),
            lastAccess: Date.now(),
            lastUpdate: Date.now(),
            updateCount: 0,
            errorCount: 0,
            lastSuccess: null,
            lastError: null,
        };

        this._context = {
            url: typeof window !== 'undefined' ? window.location.href : '',
            userAgent: typeof navigator !== 'undefined' ? navigator.userAgent : '',
            platform: typeof navigator !== 'undefined' ? navigator.platform : '',
        };

        // ============================================================
        // 6.8 ИНИЦИАЛИЗАЦИЯ ФЛАГОВ
        // ============================================================

        this._initialized = false;
        this._isRunning = false;
        this._isDestroyed = false;
        this._exported = false;

        // ============================================================
        // 6.9 ★★★ ЗАГРУЗКА ДАННЫХ ЕСЛИ ЕСТЬ ★★★
        // ============================================================

        if (options.initialData) {
            this._updateData = options.initialData;
            this._saveUpdateData();
        } else {
            this._loadUpdateData();
        }

        // ============================================================
        // 6.10 ★★★ ЗАГРУЗКА КОНФИГА ★★★
        // ============================================================

        try {
            this._loadUpdateConfig();
        } catch (error) {
            logger.error('❌ Ошибка загрузки конфига:', error.message);
            this._updateConfig = {};
        }

        // ============================================================
        // 6.11 ★★★ АСИНХРОННАЯ ЗАГРУЗКА БУКМАРКЛЕТОВ ИЗ CHROME ★★★
        // ============================================================

        // Загружаем букмарклеты напрямую из Chrome API
        this[PRIVATE.LOAD_BOOKMARKLETS_FROM_CHROME]().then(() => {
            logger.info(`✅ Букмарклеты загружены: ${this._bookmarklets.length}`);

            // Если есть данные для обновления
            if (this._updateData && Object.keys(this._updateData).length > 0) {
                logger.info('🔄 Запуск первого обновления...');
                setTimeout(() => {
                    this.update();
                }, 1000);
            }
        }).catch(error => {
            logger.error('❌ Ошибка загрузки букмарклетов:', error.message);
        });

        // ============================================================
        // 6.12 ЛОГИРОВАНИЕ
        // ============================================================

        logger.header('СОЗДАНИЕ ОБНОВЛЯТОРА БУКМАРКЛЕТОВ (100% СИМВОЛЫ)');
        logger.info(`📦 Версия: ${this._version}`);
        logger.info(`📅 Сборка: ${this._build}`);
        logger.info(`📌 Авто-обновление: ${this._config.autoUpdate ? '✅' : '❌'}`);
        logger.info(`📌 Интервал: ${this._config.updateInterval}ms`);
        logger.info(`📌 Генерировать код: ${this._config.generateNewCode ? '✅' : '❌'}`);
        logger.info(`📌 Обновлять только измененные: ${this._config.updateOnlyChanged ? '✅' : '❌'}`);
        logger.info(`📌 Размер батча: ${this._config.batchSize}`);
        logger.info(`📌 Данных для обновления: ${Object.keys(this._updateData || {}).length}`);

        logger.separator();
        logger.info(`🔑 ПРИВАТНЫХ СИМВОЛОВ: ${Object.keys(PRIVATE).length}`);
        logger.info(`🔑 ПУБЛИЧНЫХ СИМВОЛОВ: ${Object.keys(PUBLIC).length}`);
        logger.separator();

        // ============================================================
        // 6.13 ЭКСПОРТ СИМВОЛОВ
        // ============================================================

        this._exportSymbols();

        this._initialized = true;
        logger.success('✅ Обновлятор букмарклетов создан (100% символы)');
        logger.header('ГОТОВ');
    }

    // ============================================================
    // 7. ЭКСПОРТ СИМВОЛОВ
    // ============================================================

    _exportSymbols() {
        if (typeof window !== 'undefined') {
            window.__bookmarkletUpdater = this;
            window[PUBLIC.API] = this;
            window[PUBLIC.STATE] = this._getState.bind(this);
            window[PUBLIC.CONFIG] = this._getConfig.bind(this);
            window[PUBLIC.LOGGER] = this._logger;
            window[PUBLIC.INSTANCE] = this;
            window[PUBLIC.UPDATER] = this;
            window[PUBLIC.RESULTS] = this._results;
            window[PUBLIC.STATS] = this._stats;
            window[PUBLIC.UPDATE_CONFIG] = this._updateConfig;
            window[PUBLIC.EVENTS] = {
                on: this.on.bind(this),
                off: this.off.bind(this),
                emit: this.emit.bind(this),
            };

            window.__updaterSymbols = {
                PRIVATE: { ...PRIVATE },
                PUBLIC: { ...PUBLIC },
                version: this._version,
                build: this._build,
            };

            this._exported = true;
        }
    }

    // ============================================================
    // 8. ★★★ ГЕТТЕРЫ/СЕТТЕРЫ ДЛЯ КОНФИГА ★★★
    // ============================================================

    _getConfig() {
        return { ...this._config };
    }

    _setConfig(config) {
        if (!config || typeof config !== 'object') {
            this._logger.error('❌ Неверный формат конфига');
            return false;
        }
        this._config = { ...this._config, ...config };
        this._logger.info('📌 Конфиг обновлен');
        return true;
    }

    _getData() {
        return this._updateData || {};
    }

    _setData(data) {
        if (!data || typeof data !== 'object') {
            this._logger.error('❌ Неверный формат данных');
            return false;
        }
        this._updateData = data;
        this._saveUpdateData();
        this._logger.info(`📦 Данные установлены (${Object.keys(data).length} записей)`);
        return true;
    }

    // ============================================================
    // 9. ★★★ БЕЗОПАСНЫЙ ВЫЗОВ МЕТОДА ★★★
    // ============================================================

    _safeCall(obj, methodName, ...args) {
        if (obj && typeof obj === 'object' && typeof obj[methodName] === 'function') {
            try {
                return obj[methodName](...args);
            } catch (error) {
                this._logger.warn(`⚠️ Ошибка вызова ${methodName}:`, error.message);
                return null;
            }
        }
        return null;
    }

    // ============================================================
    // 10. ★★★ ИНИЦИАЛИЗАЦИЯ С КОМПОНЕНТАМИ ★★★
    // ============================================================

    async initialize(generator, background, updateData = null) {
        const logger = this._logger;
        logger.header('🔧 ИНИЦИАЛИЗАЦИЯ ОБНОВЛЯТОРА');

        logger.info('📦 Инициализация с компонентами...');

        this._generator = generator;
        this._background = background;
        this._backgroundInstance = background;

        if (!generator) {
            logger.warn('⚠️ Генератор не передан');
        } else {
            logger.info('✅ Генератор получен');
        }

        if (!background) {
            logger.warn('⚠️ Background не передан');
        } else {
            logger.info('✅ Background получен');
        }

        if (updateData) {
            this._updateData = updateData;
            this._saveUpdateData();
            logger.info(`📦 Данные обновлений установлены (${Object.keys(updateData).length} записей)`);
        }

        // ★★★ ИСПРАВЛЕНО: добавляем await ★★★
        await this[PRIVATE.LOAD_BOOKMARKLETS_FROM_CHROME]();
        logger.info(`✅ Букмарклеты загружены: ${this._bookmarklets.length}`);

        if (this._config.autoUpdate) {
            this._startAutoUpdate();
            logger.info(`✅ Авто-обновление включено (интервал: ${this._config.updateInterval}ms)`);
        } else {
            logger.info('ℹ️ Авто-обновление выключено');
        }

        if (this._updateData && Object.keys(this._updateData).length > 0) {
            logger.info('🔄 Запуск первого обновления...');
            setTimeout(() => {
                this.update();
            }, 1000);
        } else {
            logger.info('ℹ️ Нет данных для первого обновления');
        }

        this._metadata.lastUpdate = Date.now();
        logger.success('✅ Обновлятор инициализирован');
        logger.header('ГОТОВ');

        return this;
    }

    // ============================================================
    // 11. ★★★ ЗАГРУЗКА БУКМАРКЛЕТОВ ИЗ CHROME ★★★
    // ============================================================

    [PRIVATE.LOAD_BOOKMARKLETS_FROM_CHROME]() {
        const logger = this._logger;
        logger.info('📑 Загрузка букмарклетов из Chrome...');

        return new Promise(resolve => {
            if (typeof chrome === 'undefined' || !chrome.bookmarks) {
                logger.warn('⚠️ Chrome bookmarks API не доступен');
                this._bookmarklets = [];
                this._bookmarkletsMap.clear();
                resolve([]);
                return;
            }

            try {
                chrome.bookmarks.getTree(tree => {
                    if (chrome.runtime.lastError) {
                        logger.error('❌ Ошибка получения закладок:', chrome.runtime.lastError.message);
                        this._bookmarklets = [];
                        this._bookmarkletsMap.clear();
                        resolve([]);
                        return;
                    }

                    const bookmarklets = [];

                    function traverse(node, path = '') {
                        // Проверяем URL на букмарклет
                        if (node.url && node.url.startsWith('javascript:')) {
                            bookmarklets.push({
                                id: node.id,
                                title: node.title || 'Без названия',
                                url: node.url,
                                path: path || 'Корень',
                                parentId: node.parentId,
                                isBookmarklet: true,
                                type: 'bookmarklet',
                                size: node.url ? node.url.length : 0,
                            });
                        }

                        // Рекурсивно обходим детей
                        if (node.children) {
                            const currentPath = path
                                ? `${path} > ${node.title || 'Корень'}`
                                : node.title || 'Корень';
                            for (const child of node.children) {
                                traverse(child, currentPath);
                            }
                        }
                    }

                    for (const root of tree) {
                        traverse(root, '');
                    }

                    // Сохраняем букмарклеты
                    this._bookmarklets = bookmarklets;
                    this._bookmarkletsMap.clear();
                    for (const bm of bookmarklets) {
                        this._bookmarkletsMap.set(bm.id, bm);
                    }

                    logger.info(`📦 Загружено ${bookmarklets.length} букмарклетов из Chrome`);

                    // Логируем найденные букмарклеты для отладки
                    if (bookmarklets.length > 0) {
                        logger.debug('📋 Найденные букмарклеты:');
                        bookmarklets.forEach((bm, index) => {
                            logger.debug(`   ${index + 1}. ${bm.title} (${bm.id})`);
                        });
                    }

                    resolve(bookmarklets);
                });
            } catch (error) {
                logger.error('❌ Ошибка загрузки букмарклетов:', error.message);
                this._bookmarklets = [];
                this._bookmarkletsMap.clear();
                resolve([]);
            }
        });
    }

    // ============================================================
    // 12. ★★★ ИНИЦИАЛИЗАЦИЯ С КОНФИГОМ ★★★
    // ============================================================

    async initializeWithConfig(generator, background, config = {}, options = {}) {
        const logger = this._logger;
        logger.header('🔧 ИНИЦИАЛИЗАЦИЯ С КОНФИГОМ');

        // Сохраняем компоненты
        this._generator = generator;
        this._background = background;
        this._backgroundInstance = background;

        // Сохраняем конфиг
        this._updateConfig = config;

        // Формируем данные обновлений из конфига
        const updateData = this._parseConfigToUpdateData(config);
        this._updateData = updateData;

        // Обновляем конфиг
        this._config = { ...this._config, ...options };

        // ★★★ ИСПРАВЛЕНО: добавляем await ★★★
        await this[PRIVATE.LOAD_BOOKMARKLETS_FROM_CHROME]();
        logger.info(`✅ Букмарклеты загружены: ${this._bookmarklets.length}`);

        // Настраиваем авто-обновление
        if (this._config.autoUpdate) {
            this._startAutoUpdate();
            logger.info(`✅ Авто-обновление включено (интервал: ${this._config.updateInterval}ms)`);
        } else {
            logger.info('ℹ️ Авто-обновление выключено');
        }

        // Выполняем первое обновление
        if (updateData && Object.keys(updateData).length > 0) {
            logger.info(`📦 Найдено ${Object.keys(updateData).length} записей для обновления`);
            setTimeout(() => {
                this.update(updateData);
            }, 1000);
        } else {
            logger.info('ℹ️ Нет данных для обновления');
        }

        // Сохраняем конфиг
        this._saveUpdateConfig(config);

        this._metadata.lastUpdate = Date.now();
        logger.success('✅ Обновлятор инициализирован с конфигом');
        logger.header('ГОТОВ');

        return this;
    }

    // ============================================================
    // 13. ★★★ ПАРСИНГ КОНФИГА В ДАННЫЕ ★★★
    // ============================================================

    _parseConfigToUpdateData(config) {
        const logger = this._logger;
        const updateData = {};

        if (!config || typeof config !== 'object') {
            logger.warn('⚠️ Конфиг пуст или не является объектом');
            return updateData;
        }

        const defaults = config.defaults || { type: 'main' };
        const bookmarklets = config.bookmarklets || config;

        for (const [id, data] of Object.entries(bookmarklets)) {
            if (id === 'defaults') {continue;}

            updateData[id] = {
                title: data.title || data.name || 'Bookmarklet',
                url: data.url || data.code || null,
                type: data.type || defaults.type || 'main',
                description: data.description || '',
                preserveTitle: data.preserveTitle || false,
            };
        }

        logger.info(`📦 Распарсено ${Object.keys(updateData).length} записей из конфига`);
        return updateData;
    }

    // ============================================================
    // 14. ★★★ ЗАГРУЗКА/СОХРАНЕНИЕ КОНФИГА ★★★
    // ============================================================

    _loadUpdateConfig() {
        const logger = this._logger;

        try {
            const saved = this[PRIVATE.SAFE_STORAGE_GET](this._config.configKey);
            if (saved) {
                const config = typeof saved === 'string' ? JSON.parse(saved) : saved;
                this._updateConfig = config;
                const count = Object.keys(config.bookmarklets || config).length;
                logger.info(`📦 Загружен конфиг обновлений (${count} записей)`);
                return config;
            }

            this._updateConfig = {};
            logger.info('📦 Конфиг обновлений не найден, создан пустой');
            return {};

        } catch (error) {
            logger.error('❌ Ошибка загрузки конфига:', error.message);
            this._updateConfig = {};
            return {};
        }
    }

    _saveUpdateConfig(config) {
        try {
            this[PRIVATE.SAFE_STORAGE_SET](this._config.configKey, config);
        } catch (error) {}
    }

    // ============================================================
    // 15. ★★★ БЕЗОПАСНОЕ ХРАНИЛИЩЕ ★★★
    // ============================================================

    [PRIVATE.SAFE_STORAGE_GET](key) {
        try {
            // Пробуем chrome.storage
            if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
                return new Promise(resolve => {
                    chrome.storage.local.get([key], result => {
                        if (chrome.runtime.lastError) {
                            resolve(null);
                            return;
                        }
                        resolve(result[key] || null);
                    });
                });
            }

            // Пробуем localStorage
            if (typeof localStorage !== 'undefined') {
                const value = localStorage.getItem(key);
                if (value) {
                    try {
                        return JSON.parse(value);
                    } catch {
                        return value;
                    }
                }
            }

            return null;
        } catch (error) {
            return null;
        }
    }

    [PRIVATE.SAFE_STORAGE_SET](key, value) {
        try {
            // Пробуем chrome.storage
            if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
                chrome.storage.local.set({ [key]: value }, () => {
                    if (chrome.runtime.lastError) {
                        // Игнорируем ошибки
                    }
                });
                return true;
            }

            // Пробуем localStorage
            if (typeof localStorage !== 'undefined') {
                const stringValue = typeof value === 'string' ? value : JSON.stringify(value);
                localStorage.setItem(key, stringValue);
                return true;
            }

            return false;
        } catch (error) {
            return false;
        }
    }

    // ============================================================
    // 16. ★★★ УСТАНОВКА/ПОЛУЧЕНИЕ КОНФИГА ★★★
    // ============================================================

    _setUpdateConfig(config) {
        const logger = this._logger;

        if (!config || typeof config !== 'object') {
            logger.error('❌ Неверный формат конфига');
            return false;
        }

        this._updateConfig = config;
        this._saveUpdateConfig(config);

        // Парсим конфиг в данные для обновления
        const updateData = this._parseConfigToUpdateData(config);
        this._updateData = updateData;
        this._saveUpdateData();

        logger.info(`📦 Конфиг обновлений установлен (${Object.keys(updateData).length} записей)`);
        this._notify('config:set', config);

        return true;
    }

    _getUpdateConfig() {
        return this._updateConfig || {};
    }

    // ============================================================
    // 17. ★★★ ОБНОВЛЕНИЕ С КОНФИГОМ ★★★
    // ============================================================

    _updateFromConfig(config) {
        if (config) {
            this._setUpdateConfig(config);
        }
        return this.update(this._updateData);
    }

    // ============================================================
    // 18. ОСНОВНОЙ МЕТОД ОБНОВЛЕНИЯ - ИСПРАВЛЕННЫЙ ★★★
    // ============================================================

    async update(updateData = null) {
        const logger = this._logger;

        if (this._isRunning) {
            logger.warn('⚠️ Обновление уже выполняется');
            return this._results;
        }

        if (updateData) {
            this._updateData = updateData;
            this._saveUpdateData();
        }

        if (!this._updateData || Object.keys(this._updateData).length === 0) {
            logger.info('ℹ️ Нет данных для обновления');
            return {
                total: 0,
                updated: 0,
                skipped: 0,
                failed: 0,
                message: 'Нет данных для обновления',
            };
        }

        if (!this._generator) {
            logger.error('❌ Генератор не инициализирован');
            return {
                total: 0,
                updated: 0,
                skipped: 0,
                failed: 0,
                error: 'Generator not initialized',
            };
        }

        // ★★★ ИСПРАВЛЕНО: добавляем await ★★★
        await this[PRIVATE.LOAD_BOOKMARKLETS_FROM_CHROME]();

        this._isRunning = true;
        this._stats.startTime = Date.now();
        this._stats.errors = [];
        this._stats.details = [];

        logger.header('🔄 ОБНОВЛЕНИЕ БУКМАРКЛЕТОВ');

        try {
            const updateItems = Object.entries(this._updateData).map(([id, data]) => ({
                id,
                title: data.title || data.name || 'Bookmarklet',
                newTitle: data.title || data.name || 'Bookmarklet',
                newCode: data.url || data.code || null,
                type: data.type || 'main',
                description: data.description || '',
                preserveTitle: data.preserveTitle || this._config.preserveTitle,
            }));

            logger.info(`📦 Найдено ${updateItems.length} букмарклетов для обновления`);

            const results = await this._processUpdates(updateItems);

            this._stats.total = results.length;
            this._stats.updated = results.filter(r => r.updated).length;
            this._stats.skipped = results.filter(r => r.skipped).length;
            this._stats.failed = results.filter(r => r.failed).length;
            this._stats.endTime = Date.now();
            this._stats.duration = (this._stats.endTime - this._stats.startTime) / 1000;
            this._stats.details = results;

            this._results = {
                stats: { ...this._stats },
                results,
                duration: this._stats.duration.toFixed(2),
                timestamp: new Date().toISOString(),
                version: this._version,
            };

            this._saveResults();

            this._metadata.updateCount++;
            this._metadata.lastUpdate = Date.now();
            this._metadata.lastSuccess = Date.now();

            logger.separator();
            logger.info(`📊 РЕЗУЛЬТАТЫ ОБНОВЛЕНИЯ:`);
            logger.info(`   📦 Всего: ${this._stats.total}`);
            logger.info(`   ✅ Обновлено: ${this._stats.updated}`);
            logger.info(`   ⏭️ Пропущено: ${this._stats.skipped}`);
            logger.info(`   ❌ Ошибок: ${this._stats.failed}`);
            logger.info(`   ⏱️ Время: ${this._results.duration}s`);
            logger.separator();

            if (this._config.debug) {
                results.forEach(r => {
                    const icon = r.updated ? '✅' : r.skipped ? '⏭️' : '❌';
                    const msg = r.updated ? `Обновлен: ${r.newTitle || r.title}` :
                        r.skipped ? `Пропущен: ${r.title} (${r.reason || 'нет изменений'})` :
                            `Ошибка: ${r.title} (${r.error || 'неизвестная ошибка'})`;
                    logger.debug(`   ${icon} ${msg}`);
                });
            }

            this._notify('update:complete', this._results);

            logger.success(`✅ Обновление завершено!`);
            logger.header('ГОТОВ');

            this._isRunning = false;
            return this._results;
        } catch (error) {
            logger.error('❌ Ошибка обновления:', error.message);
            this._stats.errors.push(error.message);
            this._metadata.errorCount++;
            this._metadata.lastError = Date.now();

            this._notify('update:error', { error: error.message });

            this._isRunning = false;
            throw error;
        }
    }

    // ============================================================
    // 19. ОБРАБОТКА ОБНОВЛЕНИЙ
    // ============================================================

    _processUpdates(updateItems) {
        const logger = this._logger;
        const results = [];
        const batchSize = this._config.batchSize || 10;
        const delayBetween = this._config.delayBetween || 500;

        logger.info(`🔄 Обработка ${updateItems.length} обновлений...`);

        return new Promise(resolve => {
            let index = 0;

            const processNextBatch = async () => {
                if (index >= updateItems.length) {
                    resolve(results);
                    return;
                }

                const batch = updateItems.slice(index, index + batchSize);
                index += batchSize;

                logger.debug(`📦 Батч ${Math.floor(index / batchSize)}/${Math.ceil(updateItems.length / batchSize)} (${batch.length} элементов)`);

                const batchResults = await this._processBatch(batch);
                results.push(...batchResults);

                if (index < updateItems.length) {
                    setTimeout(processNextBatch, delayBetween);
                } else {
                    resolve(results);
                }
            };

            processNextBatch();
        });
    }

    // ============================================================
    // 20. ОБРАБОТКА БАТЧА
    // ============================================================

    _processBatch(batch) {
        const results = [];
        const logger = this._logger;

        return new Promise(resolve => {
            let completed = 0;
            const total = batch.length;

            for (const item of batch) {
                this._updateSingle(item)
                    .then(result => {
                        results.push(result);
                        completed++;
                        if (completed === total) {
                            resolve(results);
                        }
                    })
                    .catch(error => {
                        logger.error(`❌ Ошибка обновления ${item.title || item.id}:`, error.message);
                        results.push({
                            id: item.id,
                            title: item.title || 'Без названия',
                            updated: false,
                            failed: true,
                            error: error.message,
                        });
                        completed++;
                        if (completed === total) {
                            resolve(results);
                        }
                    });
            }

            if (total === 0) {
                resolve(results);
            }
        });
    }

    // ============================================================
    // 21. ★★★ ОБНОВЛЕНИЕ ОДНОГО БУКМАРКЛЕТА ★★★
    // ============================================================

    _updateSingle(item) {
        const logger = this._logger;
        const id = item.id;
        const oldTitle = item.title || 'Без названия';
        const newTitle = item.newTitle || item.title || oldTitle;
        const preserveTitle = item.preserveTitle || this._config.preserveTitle;

        return new Promise(async resolve => {
            try {
                const current = await this._getBookmarkById(id);

                if (!current) {
                    resolve({
                        id,
                        title: oldTitle,
                        updated: false,
                        skipped: true,
                        reason: 'Букмарклет не найден',
                    });
                    return;
                }

                if (!current.url || !current.url.startsWith('javascript:')) {
                    resolve({
                        id,
                        title: oldTitle,
                        updated: false,
                        skipped: true,
                        reason: 'Не является букмарклетом',
                    });
                    return;
                }

                let newCode = item.newCode || null;

                if (!newCode && this._config.generateNewCode) {
                    try {
                        const generator = this._generator;
                        if (!generator) {
                            throw new Error('Генератор не доступен');
                        }

                        const type = item.type || this._detectType(newTitle);
                        const bookmarkData = {
                            id,
                            title: newTitle,
                            type,
                        };

                        if (typeof generator.generateCode === 'function') {
                            newCode = generator.generateCode(bookmarkData, { type, title: newTitle });
                        } else if (typeof generator.generateUniversalBookmarklet === 'function') {
                            newCode = generator.generateUniversalBookmarklet(bookmarkData, { type, title: newTitle });
                        } else {
                            throw new Error('Generator не поддерживает генерацию кода');
                        }

                        logger.debug(`🔄 Сгенерирован код для "${newTitle}"`);
                    } catch (error) {
                        logger.error(`❌ Ошибка генерации кода для "${newTitle}":`, error.message);
                        resolve({
                            id,
                            title: oldTitle,
                            updated: false,
                            failed: true,
                            error: error.message,
                        });
                        return;
                    }
                }

                if (!newCode) {
                    resolve({
                        id,
                        title: oldTitle,
                        updated: false,
                        skipped: true,
                        reason: 'Нет кода для обновления',
                    });
                    return;
                }

                const titleChanged = preserveTitle ? false : (newTitle !== current.title);
                const codeChanged = current.url !== newCode;

                if (this._config.updateOnlyChanged && !titleChanged && !codeChanged) {
                    resolve({
                        id,
                        title: oldTitle,
                        updated: false,
                        skipped: true,
                        reason: 'Нет изменений',
                    });
                    return;
                }

                const updateData = {
                    title: preserveTitle ? current.title : newTitle,
                    url: newCode,
                };

                logger.debug(`🔄 Обновление "${oldTitle}" → "${updateData.title}"`);

                const result = await this._updateBookmarkViaChrome(id, updateData);

                this._cache.set(id, {
                    title: updateData.title,
                    url: updateData.url,
                    updatedAt: Date.now(),
                    oldTitle,
                    oldUrl: current.url,
                });

                logger.success(`✅ Обновлен: "${oldTitle}" → "${updateData.title}"`);

                resolve({
                    id,
                    oldTitle,
                    newTitle: updateData.title,
                    updated: true,
                    success: true,
                    result,
                    changed: {
                        title: titleChanged,
                        code: codeChanged,
                    },
                });
            } catch (error) {
                logger.error(`❌ Ошибка обновления "${oldTitle}":`, error.message);
                resolve({
                    id,
                    title: oldTitle,
                    updated: false,
                    failed: true,
                    error: error.message,
                });
            }
        });
    }

    // ============================================================
    // 22. ВСПОМОГАТЕЛЬНЫЕ МЕТОДЫ
    // ============================================================

    _detectType(title) {
        const lower = title.toLowerCase();
        if (lower.includes('env') || lower.includes('control')) {return 'env';}
        if (lower.includes('log')) {return 'logs';}
        if (lower.includes('debug')) {return 'debug';}
        if (lower.includes('manager')) {return 'manager';}
        if (lower.includes('widget')) {return 'widget';}
        if (lower.includes('sw') || lower.includes('service')) {return 'sw';}
        return 'main';
    }

    _delay(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    _getBookmarkById(id) {
        return new Promise((resolve, reject) => {
            if (typeof chrome === 'undefined' || !chrome.bookmarks) {
                reject(new Error('Chrome bookmarks API не доступен'));
                return;
            }

            chrome.bookmarks.get(id, result => {
                if (chrome.runtime.lastError) {
                    reject(new Error(chrome.runtime.lastError.message));
                    return;
                }
                resolve(result && result.length > 0 ? result[0] : null);
            });
        });
    }

    _updateBookmarkViaChrome(id, data) {
        return new Promise((resolve, reject) => {
            if (typeof chrome === 'undefined' || !chrome.bookmarks) {
                reject(new Error('Chrome bookmarks API не доступен'));
                return;
            }

            chrome.bookmarks.update(id, data, result => {
                if (chrome.runtime.lastError) {
                    reject(new Error(chrome.runtime.lastError.message));
                    return;
                }
                resolve(result);
            });
        });
    }

    // ============================================================
    // 23. УПРАВЛЕНИЕ ДАННЫМИ
    // ============================================================

    _loadUpdateData() {
        const logger = this._logger;

        try {
            const saved = this[PRIVATE.SAFE_STORAGE_GET](this._config.storageKey);
            if (saved) {
                const data = typeof saved === 'string' ? JSON.parse(saved) : saved;
                this._updateData = data;
                logger.info(`📦 Загружены данные обновлений (${Object.keys(data).length} записей)`);
                return;
            }

            this._updateData = {};
            logger.info('📦 Данные обновлений не найдены, созданы пустые');
        } catch (error) {
            logger.error('❌ Ошибка загрузки данных:', error.message);
            this._updateData = {};
        }
    }

    _saveUpdateData() {
        try {
            this[PRIVATE.SAFE_STORAGE_SET](this._config.storageKey, this._updateData);
        } catch (error) {}
    }

    _saveResults() {
        try {
            const data = {
                timestamp: new Date().toISOString(),
                results: this._results,
                config: this._config,
                stats: this._stats,
                metadata: this._metadata,
            };
            this[PRIVATE.SAFE_STORAGE_SET](this._config.resultsKey, data);
            this._notify('results:saved', data);
        } catch (error) {}
    }

    // ============================================================
    // 24. АВТО-ОБНОВЛЕНИЕ
    // ============================================================

    _startAutoUpdate() {
        const logger = this._logger;

        if (this._autoTimer) {
            clearInterval(this._autoTimer);
            this._autoTimer = null;
        }

        const interval = this._config.updateInterval || 60000;

        this._autoTimer = setInterval(() => {
            if (!this._isRunning && !this._isDestroyed) {
                // Загружаем актуальные букмарклеты перед обновлением
                this[PRIVATE.LOAD_BOOKMARKLETS_FROM_CHROME]().then(() => {
                    this.update();
                }).catch(() => {
                    this.update();
                });
            }
        }, interval);

        this._timers.set('auto', this._autoTimer);

        logger.info(`✅ Авто-обновление запущено (интервал: ${interval}ms)`);
    }

    _stopAutoUpdate() {
        if (this._autoTimer) {
            clearInterval(this._autoTimer);
            this._autoTimer = null;
            this._timers.delete('auto');
            const logger = this._logger;
            logger.info('⏹️ Авто-обновление остановлено');
        }
    }

    // ============================================================
    // 25. СОБЫТИЯ
    // ============================================================

    _emit(event, data) {
        if (this._eventHandlers.has(event)) {
            const handlers = this._eventHandlers.get(event);
            for (const callback of handlers) {
                try {
                    callback(data);
                } catch (error) {
                    const logger = this._logger;
                    logger.error(`❌ Ошибка в обработчике ${event}:`, error);
                }
            }
        }
    }

    _notify(event, data) {
        const logger = this._logger;
        logger.debug(`🔔 Уведомление: ${event}`, data);
        this._emit(event, data);
    }

    on(event, callback) {
        if (!VALIDATOR[PRIVATE.VALIDATOR].isValidCallback(callback)) {
            const logger = this._logger;
            logger.warn(`⚠️ Некорректный callback для события ${event}`);
            return () => {};
        }

        if (!this._eventHandlers.has(event)) {
            this._eventHandlers.set(event, []);
        }
        this._eventHandlers.get(event).push(callback);

        return () => this.off(event, callback);
    }

    off(event, callback) {
        if (this._eventHandlers.has(event)) {
            const handlers = this._eventHandlers.get(event);
            const index = handlers.indexOf(callback);
            if (index !== -1) {
                handlers.splice(index, 1);
            }
            if (handlers.length === 0) {
                this._eventHandlers.delete(event);
            }
        }
    }

    emit(event, data) {
        this._emit(event, data);
    }

    // ============================================================
    // 26. ПУБЛИЧНЫЕ МЕТОДЫ
    // ============================================================

    setData(data) {
        return this._setData(data);
    }

    getData() {
        return this._getData();
    }

    setUpdateConfig(config) {
        return this._setUpdateConfig(config);
    }

    getUpdateConfig() {
        return this._getUpdateConfig();
    }

    updateFromConfig(config) {
        return this._updateFromConfig(config);
    }

    getConfig() {
        return this._getConfig();
    }

    updateConfig(config) {
        return this._setConfig(config);
    }

    getResults() {
        return this._results;
    }

    getStats() {
        return { ...this._stats };
    }

    getCache() {
        return new Map(this._cache);
    }

    getBookmarklets() {
        return [...this._bookmarklets];
    }

    getStatus() {
        return {
            initialized: this._initialized,
            isRunning: this._isRunning,
            isDestroyed: this._isDestroyed,
            autoUpdate: this._config.autoUpdate,
            updateInterval: this._config.updateInterval,
            dataCount: Object.keys(this._updateData || {}).length,
            bookmarkletsCount: this._bookmarklets.length,
            cacheSize: this._cache.size,
            results: this._results,
            stats: this._stats,
            generatorAvailable: !!this._generator,
            backgroundAvailable: !!this._background,
            metadata: { ...this._metadata },
            config: { ...this._config },
            updateConfig: this._updateConfig,
            version: this._version,
            build: this._build,
            exported: this._exported,
        };
    }

    clearCache() {
        const size = this._cache.size;
        this._cache.clear();
        const logger = this._logger;
        logger.info(`🗑️ Кеш очищен (${size} записей)`);
        this._notify('cache:cleared', { size });
        return size;
    }

    reset() {
        const logger = this._logger;
        logger.warn('🔄 Сброс состояния...');

        this._results = null;
        this._stats = {
            total: 0,
            updated: 0,
            skipped: 0,
            failed: 0,
            startTime: null,
            endTime: null,
            duration: 0,
            errors: [],
            details: [],
        };
        this._cache.clear();
        this._bookmarklets = [];
        this._bookmarkletsMap.clear();

        this._metadata = {
            created: Date.now(),
            lastAccess: Date.now(),
            lastUpdate: Date.now(),
            updateCount: 0,
            errorCount: 0,
            lastSuccess: null,
            lastError: null,
        };

        this._notify('reset', { timestamp: Date.now() });

        logger.success('✅ Состояние сброшено');
        return this;
    }

    _getState() {
        return {
            version: this._version,
            build: this._build,
            initialized: this._initialized,
            isRunning: this._isRunning,
            isDestroyed: this._isDestroyed,
            exported: this._exported,
            config: this._config,
            updateConfig: this._updateConfig,
            stats: this._stats,
            results: this._results,
            updateData: this._updateData,
            bookmarklets: this._bookmarklets,
            cache: this._cache,
            metadata: this._metadata,
            context: this._context,
            generatorAvailable: !!this._generator,
            backgroundAvailable: !!this._background,
        };
    }

    getState() {
        return this._getState();
    }

    getGenerator() {
        return this._generator;
    }

    getBackground() {
        return this._background;
    }

    setAutoUpdate(enabled) {
        const logger = this._logger;
        this._config.autoUpdate = enabled;

        if (enabled) {
            this._startAutoUpdate();
            logger.info('✅ Авто-обновление включено');
        } else {
            this._stopAutoUpdate();
            logger.info('⏹️ Авто-обновление выключено');
        }

        this._notify('autoUpdate:changed', { enabled });
    }

    setUpdateInterval(interval) {
        const logger = this._logger;

        if (interval < 10000) {
            logger.warn('⚠️ Минимальный интервал 10 секунд');
            interval = 10000;
        }

        this._config.updateInterval = interval;

        if (this._config.autoUpdate) {
            this._startAutoUpdate();
        }

        logger.info(`📌 Интервал авто-обновления установлен: ${interval}ms`);
        this._notify('updateInterval:changed', { interval });
    }

    exportResults() {
        return JSON.stringify({
            results: this._results,
            stats: this._stats,
            metadata: this._metadata,
            config: this._config,
            updateConfig: this._updateConfig,
            version: this._version,
            timestamp: new Date().toISOString(),
        }, null, 2);
    }

    importResults(json) {
        try {
            const data = JSON.parse(json);
            if (data.results) {
                this._results = data.results;
            }
            if (data.stats) {
                this._stats = data.stats;
            }
            if (data.updateConfig) {
                this._updateConfig = data.updateConfig;
            }
            this._notify('results:imported', data);
            return data;
        } catch (error) {
            const logger = this._logger;
            logger.error('❌ Ошибка импорта:', error.message);
            throw error;
        }
    }

    // ============================================================
    // 27. УНИЧТОЖЕНИЕ
    // ============================================================

    destroy() {
        const logger = this._logger;

        if (this._isDestroyed) {
            logger.warn('⚠️ Обновлятор уже уничтожен');
            return;
        }

        logger.warn('🗑️ Уничтожение обновлятора...');

        this._stopAutoUpdate();

        for (const [key, timer] of this._timers) {
            clearInterval(timer);
            clearTimeout(timer);
        }
        this._timers.clear();

        this._eventHandlers.clear();
        this._listeners = [];

        this._cache.clear();
        this._bookmarklets = [];
        this._bookmarkletsMap.clear();

        this._generator = null;
        this._background = null;
        this._backgroundInstance = null;

        if (typeof window !== 'undefined') {
            if (window.__bookmarkletUpdater === this) {
                delete window.__bookmarkletUpdater;
            }
            delete window[PUBLIC.API];
            delete window[PUBLIC.STATE];
            delete window[PUBLIC.CONFIG];
            delete window[PUBLIC.LOGGER];
            delete window[PUBLIC.INSTANCE];
            delete window[PUBLIC.UPDATER];
            delete window[PUBLIC.RESULTS];
            delete window[PUBLIC.STATS];
            delete window[PUBLIC.UPDATE_CONFIG];
            delete window[PUBLIC.EVENTS];
            delete window.__updaterSymbols;
        }

        this._isDestroyed = true;
        this._initialized = false;
        this._exported = false;

        this._notify('destroyed', { timestamp: Date.now() });

        logger.success('🗑️ Обновлятор уничтожен');
    }

    // ============================================================
    // 28. ГЕТТЕРЫ ДЛЯ ПРИВАТНЫХ ДАННЫХ (только чтение)
    // ============================================================

    get [PRIVATE.CONFIG]() {
        return this._config;
    }

    get [PRIVATE.LOGGER]() {
        return this._logger;
    }

    get [PRIVATE.VERSION]() {
        return this._version;
    }

    get [PRIVATE.BUILD]() {
        return this._build;
    }

    get [PRIVATE.INITIALIZED]() {
        return this._initialized;
    }

    get [PRIVATE.IS_RUNNING]() {
        return this._isRunning;
    }

    get [PRIVATE.IS_DESTROYED]() {
        return this._isDestroyed;
    }

    get [PRIVATE.RESULTS]() {
        return this._results;
    }

    get [PRIVATE.STATS]() {
        return this._stats;
    }

    get [PRIVATE.CACHE]() {
        return this._cache;
    }

    get [PRIVATE.UPDATE_DATA]() {
        return this._updateData;
    }

    get [PRIVATE.UPDATE_CONFIG]() {
        return this._updateConfig;
    }

    get [PRIVATE.GENERATOR]() {
        return this._generator;
    }

    get [PRIVATE.BACKGROUND]() {
        return this._background;
    }

    get [PRIVATE.METADATA]() {
        return this._metadata;
    }

    get [PRIVATE.EXPORTED]() {
        return this._exported;
    }
}

// ============================================================
// 29. СОЗДАНИЕ ЭКЗЕМПЛЯРА
// ============================================================

let updaterInstance = null;

function getBookmarkletUpdater(options = {}) {
    if (!updaterInstance) {
        updaterInstance = new BookmarkletUpdater(options);
        if (typeof window !== 'undefined') {
            window.__bookmarkletUpdaterInstance = updaterInstance;
        }
        if (typeof self !== 'undefined') {
            self.__bookmarkletUpdater = updaterInstance;
        }
    }
    return updaterInstance;
}

// ============================================================
// 30. ЭКСПОРТ
// ============================================================

export default BookmarkletUpdater;
export {
    BookmarkletUpdater,
    getBookmarkletUpdater,
    PRIVATE,
    PUBLIC,
    DEFAULT_CONFIG,
};

// ============================================================
// 31. ИНИЦИАЛИЗАЦИЯ ПРИ ЗАГРУЗКЕ
// ============================================================

if (typeof window !== 'undefined') {
    const updater = getBookmarkletUpdater({
        debug: true,
        version: '2.1.7',
        build: '2026-07-22',
    });

    console.log('╔═══════════════════════════════════════════════════════════════════════════════╗');
    console.log('║              📦 BOOKMARKLET UPDATER (100% СИМВОЛЫ) v2.1.7                   ║');
    console.log('╠═══════════════════════════════════════════════════════════════════════════════╣');
    console.log('║  📋 Все логи выводятся в консоль с цветовой разметкой                       ║');
    console.log('║  🔑 Полная изоляция через приватные символы                                 ║');
    console.log('║  🔓 Публичные символы через Symbol.for                                      ║');
    console.log('║  🔄 Автоматическое обновление букмарклетов                                  ║');
    console.log('║  📊 Полная статистика работы                                                ║');
    console.log('║  🚀 Поддержка батчевой обработки                                            ║');
    console.log('║  💾 Кеширование и сохранение результатов                                    ║');
    console.log('║  📋 Поддержка конфига с обновляемыми данными (title, url)                   ║');
    console.log('║  ✅ ИСПРАВЛЕНА ошибка: this[Symbol(...)] is not a function                  ║');
    console.log('║  ✅ ИСПРАВЛЕНА ошибка: Cannot set property Symbol(updater.config)           ║');
    console.log('║  ✅ ИСПРАВЛЕНЫ ГЕТТЕРЫ/СЕТТЕРЫ для конфига                                  ║');
    console.log('║  ✅ ДОБАВЛЕНЫ безопасные методы storage                                     ║');
    console.log('║  ✅ ДОБАВЛЕН метод _safeCall для безопасного вызова методов                 ║');
    console.log('║  ✅ ВСЕ методы логгера проверяют существование _log                         ║');
    console.log('║  ✅ ЗАГРУЗКА БУКМАРКЛЕТОВ НАПРЯМУЮ ИЗ CHROME API                           ║');
    console.log('║  ✅ АСИНХРОННАЯ ЗАГРУЗКА БУКМАРКЛЕТОВ                                      ║');
    console.log('║  ✅ ДОБАВЛЕН await в LOAD_BOOKMARKLETS_FROM_CHROME                         ║');
    console.log('║  ✅ ЛОГГИРОВАНИЕ С console.group И console.trace                          ║');
    console.log('╚═══════════════════════════════════════════════════════════════════════════════╝');

    console.log('📋 ДОСТУПНЫЕ КОМАНДЫ:');
    console.log('  __bookmarkletUpdater.initialize(generator, background, data) - инициализация');
    console.log('  __bookmarkletUpdater.initializeWithConfig(generator, bg, config) - с конфигом');
    console.log('  __bookmarkletUpdater.update(data)          - запустить обновление');
    console.log('  __bookmarkletUpdater.setData(data)         - установить данные');
    console.log('  __bookmarkletUpdater.getData()             - получить данные');
    console.log('  __bookmarkletUpdater.setUpdateConfig(config) - установить конфиг');
    console.log('  __bookmarkletUpdater.getUpdateConfig()     - получить конфиг');
    console.log('  __bookmarkletUpdater.updateFromConfig(config) - обновить с конфигом');
    console.log('  __bookmarkletUpdater.getResults()          - получить результаты');
    console.log('  __bookmarkletUpdater.getStats()            - получить статистику');
    console.log('  __bookmarkletUpdater.getStatus()           - получить статус');
    console.log('  __bookmarkletUpdater.getCache()            - получить кеш');
    console.log('  __bookmarkletUpdater.clearCache()          - очистить кеш');
    console.log('  __bookmarkletUpdater.reset()               - сбросить состояние');
    console.log('  __bookmarkletUpdater.getState()            - получить состояние');
    console.log('  __bookmarkletUpdater.exportResults()       - экспорт результатов');
    console.log('  __bookmarkletUpdater.importResults(json)   - импорт результатов');
    console.log('  __bookmarkletUpdater.setAutoUpdate(true)   - включить авто-обновление');
    console.log('  __bookmarkletUpdater.setUpdateInterval(ms) - установить интервал');
    console.log('  __bookmarkletUpdater.on(event, cb)         - подписка на события');
    console.log('  __bookmarkletUpdater.off(event, cb)        - отписка от событий');
    console.log('  __bookmarkletUpdater.emit(event, data)     - отправка событий');
    console.log('  __bookmarkletUpdater.destroy()             - уничтожить');
    console.log('  window.PRIVATE_SYMBOLS                     - приватные символы');
    console.log('  window.PUBLIC_SYMBOLS                      - публичные символы');
    console.log('');
    console.log('📋 ПРИВАТНЫХ СИМВОЛОВ:', Object.keys(PRIVATE).length);
    console.log('📋 ПУБЛИЧНЫХ СИМВОЛОВ:', Object.keys(PUBLIC).length);
}

// ============================================================
// 32. КОМАНДЫ ДЛЯ ОТЛАДКИ
// ============================================================

if (typeof window !== 'undefined') {
    window.__updater = {
        instance: window.__bookmarkletUpdaterInstance || window.__bookmarkletUpdater,
        update: data => window.__bookmarkletUpdaterInstance?.update?.(data),
        setData: data => window.__bookmarkletUpdaterInstance?.setData?.(data),
        getData: () => window.__bookmarkletUpdaterInstance?.getData?.(),
        setUpdateConfig: config => window.__bookmarkletUpdaterInstance?.setUpdateConfig?.(config),
        getUpdateConfig: () => window.__bookmarkletUpdaterInstance?.getUpdateConfig?.(),
        updateFromConfig: config => window.__bookmarkletUpdaterInstance?.updateFromConfig?.(config),
        getResults: () => window.__bookmarkletUpdaterInstance?.getResults?.(),
        getStats: () => window.__bookmarkletUpdaterInstance?.getStats?.(),
        getStatus: () => window.__bookmarkletUpdaterInstance?.getStatus?.(),
        clearCache: () => window.__bookmarkletUpdaterInstance?.clearCache?.(),
        reset: () => window.__bookmarkletUpdaterInstance?.reset?.(),
        destroy: () => window.__bookmarkletUpdaterInstance?.destroy?.(),
        getSymbols: () => ({
            PRIVATE: { ...PRIVATE },
            PUBLIC: { ...PUBLIC },
        }),
        // ★★★ НОВЫЕ КОМАНДЫ ДЛЯ ЛОГГЕРА ★★★
        log: {
            group: (title, data) => window.__bookmarkletUpdaterInstance?._logger?.group?.(title, data),
            groupEnd: () => window.__bookmarkletUpdaterInstance?._logger?.groupEnd?.(),
            trace: (msg, data) => window.__bookmarkletUpdaterInstance?._logger?.trace?.(msg, data),
            logWithGroup: (level, msg, data) => window.__bookmarkletUpdaterInstance?._logger?.logWithGroup?.(level, msg, data),
        }
    };

    console.log('📋 КОМАНДЫ ОТЛАДКИ (__updater):');
    console.log('  __updater.update(data)              - запустить обновление');
    console.log('  __updater.setData(data)             - установить данные');
    console.log('  __updater.getData()                 - получить данные');
    console.log('  __updater.setUpdateConfig(config)   - установить конфиг');
    console.log('  __updater.getUpdateConfig()         - получить конфиг');
    console.log('  __updater.updateFromConfig(config)  - обновить с конфигом');
    console.log('  __updater.getResults()              - получить результаты');
    console.log('  __updater.getStats()                - получить статистику');
    console.log('  __updater.getStatus()               - получить статус');
    console.log('  __updater.clearCache()              - очистить кеш');
    console.log('  __updater.reset()                   - сбросить состояние');
    console.log('  __updater.destroy()                 - уничтожить');
    console.log('  __updater.getSymbols()              - получить символы');
    console.log('  __updater.log.group(title, data)    - создать группу с trace');
    console.log('  __updater.log.groupEnd()            - закрыть группу');
    console.log('  __updater.log.trace(msg, data)      - вывести trace');
    console.log('  __updater.log.logWithGroup(level, msg, data) - лог с группой');
}
