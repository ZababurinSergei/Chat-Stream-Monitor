// bookmarklet-generator.mjs - Генератор букмарклетов (100% СИМВОЛЫ)
// Исправленная версия - использует статический импорт вместо import()
// Версия: 2.0.0

// ============================================================
// 1. СТАТИЧЕСКИЙ ИМПОРТ (вместо динамического)
// ============================================================

// Импортируем ядро генератора шаблонов
import TemplateGeneratorCore from './template-generator-core.js';

// ============================================================
// 2. ПРИВАТНЫЕ СИМВОЛЫ (100% изоляция)
// ============================================================

const PRIVATE = {
  // Основные символы
  CONFIG: Symbol('generator.config'),
  LOGGER: Symbol('generator.logger'),
  CACHE: Symbol('generator.cache'),
  VERSION: Symbol('generator.version'),
  BUILD: Symbol('generator.build'),
  INITIALIZED: Symbol('generator.initialized'),
  IS_RUNNING: Symbol('generator.isRunning'),
  IS_DESTROYED: Symbol('generator.isDestroyed'),

  // Данные
  BOOKMARKLETS: Symbol('generator.bookmarklets'),
  RESULTS: Symbol('generator.results'),
  LAST_UPDATE: Symbol('generator.lastUpdate'),
  IS_UPDATING: Symbol('generator.isUpdating'),
  UPDATE_RESULTS: Symbol('generator.updateResults'),
  BOOKMARK_URL_CACHE: Symbol('generator.bookmarkUrlCache'),

  // Компрессия
  COMPRESS_CACHE: Symbol('generator.compressCache'),
  COMPRESSION_STATS: Symbol('generator.compressionStats'),

  // Загрузчик
  LOADER_CACHE: Symbol('generator.loaderCache'),
  LOADER_SCRIPTS: Symbol('generator.loaderScripts'),

  // Генератор шаблонов (теперь статически импортирован)
  TEMPLATE_GENERATOR: Symbol('generator.templateGenerator'),
  TEMPLATE_GENERATOR_LOADED: Symbol('generator.templateGeneratorLoaded'),

  // Конфигурация
  DYNAMIC_CONFIG: Symbol('generator.dynamicConfig'),
  EXTENSION_STATE: Symbol('generator.extensionState'),
  GLOBAL_STATE: Symbol('generator.globalState'),
  CHANNEL_MANAGER: Symbol('generator.channelManager'),
};

// ============================================================
// 3. ПУБЛИЧНЫЕ СИМВОЛЫ (доступны через Symbol.for)
// ============================================================

const PUBLIC = {
  API: Symbol.for('generator.api'),
  STATE: Symbol.for('generator.state'),
  CONFIG: Symbol.for('generator.config'),
  LOGGER: Symbol.for('generator.logger'),
  GENERATOR: Symbol.for('generator.generator'),
  UPDATER: Symbol.for('generator.updater'),
  REFRESHER: Symbol.for('generator.refresher'),
  INSTANCE: Symbol.for('generator.instance'),
};

// ============================================================
// 4. КОНФИГУРАЦИЯ
// ============================================================

const DEFAULT_CONFIG = {
  debug: true,
  version: '2.0.0',
  build: '2026-07-18',
  basePath: './Bookmarklet/',
  source: 'my-bookmarklet',
  extensionSource: 'my-extension-bridge',
  responseType: 'BOOKMARK_DATA_RESPONSE',
  timeout: 5000,
  maxRetries: 3,
  retryDelay: 1000,
  autoUpdate: true,
};

const DEFAULT_DYNAMIC_CONFIG = {
  bookmarklet: {
    basePath: './Bookmarklet/',
    useUniversalLoader: true,
    updateBookmarkUrl: true,
    fallbackEnabled: true,
    autoShow: true,
    timeout: 5000,
    maxRetries: 3,
    retryDelay: 1000,
  },
  compression: {
    enabled: true,
    minify: true,
    removeComments: true,
    shortenVariables: true,
    compressBooleans: true,
    aggressiveCompression: true,
    maxUrlLength: 2000,
    fallbackToUncompressed: true,
  },
  panel: {
    defaultWidth: 420,
    defaultHeight: 520,
    defaultPosition: { x: 20, y: 20 },
    minWidth: 320,
    minHeight: 300,
    zIndex: 99996,
    animations: true,
    animationDuration: 300,
  },
};

// ============================================================
// 5. ФУНКЦИЯ СОЗДАНИЯ ЛОГГЕРА
// ============================================================

function createLogger(debug = true) {
  const logger = {
    _debug: debug,
    _history: [],
    _maxHistory: 200,

    _log: function (level, message, data) {
      if (!this._debug && level !== 'error') return;
      const timestamp = new Date().toISOString().slice(11, 23);
      const prefix = `[${timestamp}] [Generator]`;
      this._history.push({ timestamp, level, message, data });
      if (this._history.length > this._maxHistory) {
        this._history.shift();
      }
      if (data !== null && data !== undefined) {
        console.log(`${prefix} ${message}`, data);
      } else {
        console.log(`${prefix} ${message}`);
      }
    },

    error: function (msg, d) {
      this._log('error', `❌ ${msg}`, d);
    },
    warn: function (msg, d) {
      this._log('warn', `⚠️ ${msg}`, d);
    },
    info: function (msg, d) {
      this._log('info', `ℹ️ ${msg}`, d);
    },
    debug: function (msg, d) {
      this._log('debug', `🔍 ${msg}`, d);
    },
    success: function (msg, d) {
      this._log('info', `✅ ${msg}`, d);
    },

    header: function (title) {
      console.log('═'.repeat(70));
      console.log(`  📦 ${title}`);
      console.log('═'.repeat(70));
    },

    separator: function () {
      console.log('─'.repeat(70));
    },

    getHistory: function () {
      return [...this._history];
    },

    clearHistory: function () {
      this._history = [];
      return this;
    },
  };

  return logger;
}

// ============================================================
// 6. КЛАСС ГЕНЕРАТОРА БУКМАРКЛЕТОВ
// ============================================================

class BookmarkletGenerator {
  constructor(options = {}) {
    // ============================================================
    // 1. САМОЕ ПЕРВОЕ - СОЗДАЕМ ЛОГГЕР
    // ============================================================

    const debug = options.debug !== false;
    this._logger = createLogger(debug);
    const logger = this._logger;

    // ============================================================
    // 2. ТЕПЕРЬ МОЖНО ИСПОЛЬЗОВАТЬ ЛОГГЕР
    // ============================================================

    logger.header('СОЗДАНИЕ ГЕНЕРАТОРА БУКМАРКЛЕТОВ (100% СИМВОЛЫ)');

    // ============================================================
    // 3. КОНФИГУРАЦИЯ
    // ============================================================

    this._config = { ...DEFAULT_CONFIG, ...options };
    this._version = options.version || DEFAULT_CONFIG.version;
    this._build = options.build || DEFAULT_CONFIG.build;
    this._dynamicConfig = { ...DEFAULT_DYNAMIC_CONFIG, ...options.dynamicConfig };

    logger.info(`📦 Версия: ${this._version}`);
    logger.info(`📅 Сборка: ${this._build}`);
    logger.info(`📌 Сжатие: ${this._dynamicConfig.compression.enabled ? '✅' : '❌'}`);
    logger.info(
      `📌 Универсальный загрузчик: ${this._dynamicConfig.bookmarklet.useUniversalLoader ? '✅' : '❌'}`
    );

    // ============================================================
    // 4. СОЗДАЕМ ГЕНЕРАТОР ШАБЛОНОВ (синхронно, без import())
    // ============================================================

    logger.info('📦 Создание генератора шаблонов...');

    try {
      // Используем статически импортированный TemplateGeneratorCore
      this._templateGenerator = new TemplateGeneratorCore({
        debug: this._config.debug,
        version: this._version,
        basePath: this._dynamicConfig.bookmarklet.basePath,
        compression: this._dynamicConfig.compression,
      });
      this._templateGeneratorLoaded = true;
      logger.success('✅ Генератор шаблонов создан');

      if (this._templateGenerator.getCodecStatus) {
        const status = this._templateGenerator.getCodecStatus();
        logger.debug(`  📊 Кодек: ${status.ready ? '✅ готов' : '⏳ загружается'}`);
      }
    } catch (error) {
      this._templateGenerator = null;
      this._templateGeneratorLoaded = false;
      logger.error('❌ Ошибка создания генератора шаблонов:', error.message);
      logger.debug('  Stack:', error.stack);
    }

    // ============================================================
    // 5. СОСТОЯНИЕ
    // ============================================================

    this._initialized = false;
    this._isRunning = false;
    this._isDestroyed = false;
    this._isUpdating = false;
    this._lastUpdate = null;
    this._results = null;
    this._updateResults = null;

    // ============================================================
    // 6. ХРАНИЛИЩА
    // ============================================================

    this._cache = new Map();
    this._bookmarklets = [];
    this._bookmarkUrlCache = new Map();
    this._compressCache = new Map();
    this._loaderCache = new Map();
    this._loaderScripts = new Map();

    // ============================================================
    // 7. СТАТИСТИКА
    // ============================================================

    this._compressionStats = {
      total: 0,
      saved: 0,
      originalSize: 0,
      compressedSize: 0,
      ratio: 0,
    };

    // ============================================================
    // 8. СОСТОЯНИЕ РАСШИРЕНИЯ
    // ============================================================

    this._extensionState = {
      isActive: true,
      lastPing: Date.now(),
      connectedClients: 0,
      errors: [],
      lastError: null,
    };

    // ============================================================
    // 9. ГЛОБАЛЬНОЕ СОСТОЯНИЕ
    // ============================================================

    this._globalState = options.globalState || null;
    this._channelManager = options.channelManager || null;

    // ============================================================
    // 10. ЭКСПОРТ СИМВОЛОВ
    // ============================================================

    this._exportSymbols();

    this._initialized = true;
    logger.success('✅ Генератор букмарклетов создан');
    logger.header('ГОТОВ');
  }

  // ============================================================
  // 7. ЭКСПОРТ СИМВОЛОВ
  // ============================================================

  _exportSymbols() {
    if (typeof window !== 'undefined') {
      window.__generator = this;
      window[PUBLIC.API] = this;
      window[PUBLIC.STATE] = this.getState.bind(this);
      window[PUBLIC.CONFIG] = this.getConfig.bind(this);
      window[PUBLIC.LOGGER] = this._logger;
      window[PUBLIC.GENERATOR] = this;
      window[PUBLIC.UPDATER] = this.updateAll.bind(this);
      window[PUBLIC.REFRESHER] = this.refresh.bind(this);
      window[PUBLIC.INSTANCE] = this;

      window.__generatorSymbols = {
        PRIVATE: { ...PRIVATE },
        PUBLIC: { ...PUBLIC },
        version: this._version,
        build: this._build,
      };
    }
  }

  // ============================================================
  // 8. ОПРЕДЕЛЕНИЕ ТИПА
  // ============================================================

  _detectType(title) {
    const lower = title.toLowerCase();
    let type = 'main';
    if (lower.includes('env') || lower.includes('control')) type = 'env';
    else if (lower.includes('log')) type = 'logs';
    else if (lower.includes('debug')) type = 'debug';
    else if (lower.includes('manager')) type = 'manager';
    else if (lower.includes('widget')) type = 'widget';
    else if (lower.includes('sw') || lower.includes('service')) type = 'sw';
    else if (lower.includes('reset') || lower.includes('сброс')) type = 'reset';
    return type;
  }

  // ============================================================
  // 9. МИНИФИКАЦИЯ
  // ============================================================

  _minifyCode(code) {
    if (!code || typeof code !== 'string') return code;

    const logger = this._logger;
    logger.debug('🔧 Минификация кода...');

    let result = code;

    // 1. Удаляем комментарии
    result = result.replace(/\/\*[\s\S]*?\*\//g, '');
    result = result.replace(/\/\/.*$/gm, '');

    // 2. Удаляем лишние пробелы
    result = result.replace(/\s+/g, ' ');
    result = result.replace(/\s*([{}()\[\];,:])\s*/g, '$1');
    result = result.replace(/;\s*}/g, '}');
    result = result.replace(/{\s+/g, '{');
    result = result.replace(/\s+}/g, '}');
    result = result.replace(/\(\s+/g, '(');
    result = result.replace(/\s+\)/g, ')');
    result = result.replace(/\[\s+/g, '[');
    result = result.replace(/\s+\]/g, ']');

    // 3. Сокращаем переменные
    if (this._dynamicConfig.compression.shortenVariables) {
      const varMap = new Map();
      let counter = 0;
      const varRegex = /(?:var|let|const)\s+([a-zA-Z_$][a-zA-Z0-9_$]*)/g;
      let match;
      const varNames = [];
      while ((match = varRegex.exec(result)) !== null) {
        const name = match[1];
        if (name.length > 2 && !['if', 'for', 'while', 'switch', 'try', 'catch'].includes(name)) {
          varNames.push(name);
        }
      }
      varNames.sort((a, b) => b.length - a.length);
      const shortNames = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
      for (const name of varNames) {
        if (!varMap.has(name)) {
          let short = shortNames[counter % shortNames.length];
          if (counter >= shortNames.length) {
            short += Math.floor(counter / shortNames.length);
          }
          varMap.set(name, short);
          counter++;
        }
      }
      for (const [oldName, newName] of varMap) {
        const regex = new RegExp('\\b' + oldName + '\\b', 'g');
        result = result.replace(regex, newName);
      }
    }

    // 4. Сокращаем true/false
    if (this._dynamicConfig.compression.compressBooleans) {
      result = result.replace(/\btrue\b/g, '!0');
      result = result.replace(/\bfalse\b/g, '!1');
      result = result.replace(/\bundefined\b/g, 'void 0');
    }

    // 5. Агрессивное сжатие
    if (this._dynamicConfig.compression.aggressiveCompression) {
      result = result.replace(/"([^"\\]*)"/g, (match, str) => {
        if (str.length > 0 && !str.includes("'") && !str.includes('"')) {
          return "'" + str + "'";
        }
        return match;
      });
      result = result.replace(/}\s*else/g, '}else');
      result = result.replace(/;\s*}/g, '}');
      result = result.replace(/}\s*;/g, '}');
    }

    // 6. Финальная очистка
    result = result.replace(/\n/g, ' ');
    result = result.replace(/\r/g, ' ');
    result = result.replace(/\s+/g, ' ');
    result = result.trim();

    logger.debug(`📊 Минификация: ${code.length} → ${result.length} байт`);
    return result;
  }

  // ============================================================
  // 10. СЖАТИЕ ДЛЯ URL
  // ============================================================

  _compressCode(code) {
    if (!code || typeof code !== 'string') return code;

    const logger = this._logger;
    logger.debug('🗜️ Сжатие кода для URL...');

    try {
      const cacheKey = code.length + '-' + code.substring(0, 100);

      if (this._compressCache.has(cacheKey)) {
        const cached = this._compressCache.get(cacheKey);
        logger.debug(`📦 Кеш сжатия: ${cached.length} байт`);
        return cached;
      }

      let compressed = this._minifyCode(code);
      compressed = compressed.replace(/^javascript:/i, '');
      compressed = compressed.replace(/\s+/g, ' ');
      compressed = compressed.replace(/;\s*}/g, '}');
      compressed = compressed.replace(/{\s+/g, '{');
      compressed = compressed.replace(/\s+}/g, '}');
      compressed = compressed.replace(/\(\s+/g, '(');
      compressed = compressed.replace(/\s+\)/g, ')');
      compressed = compressed.replace(/\n/g, '');
      compressed = compressed.replace(/\r/g, '');

      const encoded = encodeURIComponent(compressed);
      const result = 'javascript:' + encoded;

      this._compressCache.set(cacheKey, result);

      const stats = this._compressionStats;
      stats.total++;
      stats.originalSize += code.length;
      stats.compressedSize += result.length;
      stats.saved += code.length - result.length;
      stats.ratio =
        stats.originalSize > 0 ? (1 - stats.compressedSize / stats.originalSize) * 100 : 0;

      logger.info(
        `📊 Сжатие: ${code.length} → ${result.length} байт (${((1 - result.length / code.length) * 100).toFixed(1)}% сжатие)`
      );

      return result;
    } catch (error) {
      logger.error('❌ Ошибка сжатия:', error.message);
      return 'javascript:' + encodeURIComponent(code.replace(/^javascript:/i, ''));
    }
  }

  // ============================================================
  // 11. ГЕНЕРАЦИЯ КОДА
  // ============================================================

  _generateCode(bookmarkData, options = {}) {
    const logger = this._logger;
    const title = bookmarkData?.title || options.title || 'Bookmarklet';
    const type = options.type || this._detectType(title);
    const id =
      options.componentId || 'bm-' + Date.now() + '-' + Math.random().toString(36).substr(2, 4);
    const version = options.version || this._version;

    logger.debug(`📝 Генерация кода для "${title}" (${type})`);

    const code = `javascript:(function(){\n  'use strict';\n  \n  const CONFIG = {\n    title: '${title.replace(/'/g, "\\'")}',\n    type: '${type}',\n    id: '${id}',\n    version: '${version}',\n    debug: ${options.debug !== false}\n  };\n  \n  console.log('📌 Букмарклет "' + CONFIG.title + '" (' + CONFIG.type + ') запущен');\n  \n  const existingPanel = document.getElementById('env-control-panel');\n  if (existingPanel) {\n    const isVisible = existingPanel.style.display !== 'none';\n    if (!isVisible) {\n      existingPanel.style.display = 'flex';\n      existingPanel.style.transform = 'scale(0.95)';\n      existingPanel.style.opacity = '0';\n      setTimeout(() => {\n        existingPanel.style.transform = 'scale(1)';\n        existingPanel.style.opacity = '1';\n      }, 300);\n    } else {\n      existingPanel.style.display = 'none';\n    }\n    return;\n  }\n  \n  const s = document.createElement('script');\n  s.type = 'module';\n  s.src = './Bookmarklet/bookmarklet.js';\n  s.dataset.bookmarkletName = CONFIG.title;\n  s.dataset.bookmarkletType = CONFIG.type;\n  s.dataset.bookmarkletId = CONFIG.id;\n  document.head.appendChild(s);\n  \n  console.log('✅ Букмарклет "' + CONFIG.title + '" загружен');\n  \n})();`;

    const compressed = this._compressCode(code);

    this._bookmarkUrlCache.set(id, {
      title,
      type,
      code,
      compressed,
      timestamp: Date.now(),
      version,
    });

    logger.success(`✅ Код сгенерирован: ${code.length} байт (сжато: ${compressed.length} байт)`);
    return compressed;
  }

  // ============================================================
  // 12. УНИВЕРСАЛЬНАЯ ГЕНЕРАЦИЯ
  // ============================================================

  _generateUniversal(bookmarkData, options = {}) {
    const logger = this._logger;
    const title = bookmarkData?.title || options.title || 'Bookmarklet';
    const type = options.type || this._detectType(title);
    const id =
      options.componentId || 'bm-' + Date.now() + '-' + Math.random().toString(36).substr(2, 4);

    logger.debug(`📝 Генерация универсального букмарклета для "${title}" (${type})`);

    if (this._templateGeneratorLoaded && this._templateGenerator) {
      try {
        if (typeof this._templateGenerator.generateTemplate === 'function') {
          const template = this._templateGenerator.generateTemplate(
            { title, id },
            { type, title, componentId: id }
          );
          if (template && template.code) {
            const compressed = this._compressCode(template.code);
            logger.success(`✅ Универсальный букмарклет сгенерирован через шаблоны`);

            this._bookmarkUrlCache.set(id, {
              title,
              type,
              code: template.code,
              compressed,
              timestamp: Date.now(),
              universal: true,
            });

            return compressed;
          }
        }
      } catch (error) {
        logger.warn('⚠️ Ошибка генерации через шаблоны:', error.message);
      }
    }

    logger.debug('📊 Используем стандартную генерацию (fallback)');
    return this._generateCode(bookmarkData, options);
  }

  // ============================================================
  // 13. ОБНОВЛЕНИЕ БУКМАРКЛЕТА
  // ============================================================

  _updateBookmark(bookmarkId, newCode) {
    const logger = this._logger;

    return new Promise((resolve, reject) => {
      if (!bookmarkId) {
        reject(new Error('bookmarkId is required'));
        return;
      }
      if (!newCode || !newCode.startsWith('javascript:')) {
        reject(new Error('newCode must start with "javascript:"'));
        return;
      }

      logger.info(`📝 Обновление букмарклета ${bookmarkId}...`);

      if (typeof chrome === 'undefined' || !chrome.bookmarks) {
        reject(new Error('Chrome bookmarks API not available'));
        return;
      }

      chrome.bookmarks.update(bookmarkId, { url: newCode }, result => {
        if (chrome.runtime.lastError) {
          logger.error('❌ Ошибка обновления:', chrome.runtime.lastError.message);
          reject(new Error(chrome.runtime.lastError.message));
          return;
        }
        logger.success(`✅ Букмарклет обновлен: ${result.title}`);
        resolve(result);
      });
    });
  }

  // ============================================================
  // 14. ОБНОВЛЕНИЕ ВСЕХ
  // ============================================================

  _updateAll(bookmarklets) {
    const logger = this._logger;
    const results = {
      total: bookmarklets.length,
      updated: 0,
      unchanged: 0,
      failed: 0,
      errors: [],
      details: [],
      timestamp: Date.now(),
    };

    if (bookmarklets.length === 0) {
      logger.info('📦 Нет букмарклетов для обновления');
      return Promise.resolve(results);
    }

    logger.info(`🔄 Обновление ${bookmarklets.length} букмарклетов...`);

    return new Promise(resolve => {
      let processed = 0;
      const total = bookmarklets.length;

      for (const bm of bookmarklets) {
        if (!bm.url || !bm.url.startsWith('javascript:')) {
          processed++;
          if (processed === total) resolve(results);
          continue;
        }

        const type = this._detectType(bm.title);
        const newCode = this._generateCode(
          { id: bm.id, title: bm.title },
          { type, title: bm.title }
        );

        this._updateBookmark(bm.id, newCode)
          .then(result => {
            if (result.unchanged) {
              results.unchanged++;
            } else {
              results.updated++;
            }
            results.details.push({
              id: bm.id,
              title: bm.title,
              type,
              success: true,
              unchanged: result.unchanged || false,
            });
            logger.success(`✅ Обновлен: "${bm.title}" (${type})`);
          })
          .catch(error => {
            results.failed++;
            results.errors.push({ id: bm.id, title: bm.title, error: error.message });
            logger.error(`❌ Ошибка "${bm.title}":`, error.message);
          })
          .finally(() => {
            processed++;
            if (processed === total) {
              logger.info(
                `📊 Результат: ${results.updated} обновлено, ${results.unchanged} без изменений, ${results.failed} ошибок`
              );
              resolve(results);
            }
          });
      }
    });
  }

  // ============================================================
  // 15. ПОЛУЧЕНИЕ СПИСКА
  // ============================================================

  _getList() {
    const logger = this._logger;

    return new Promise((resolve, reject) => {
      if (typeof chrome === 'undefined' || !chrome.bookmarks) {
        reject(new Error('Chrome bookmarks API not available'));
        return;
      }

      logger.info('📑 Получение списка букмарклетов...');

      chrome.bookmarks.getTree(tree => {
        if (chrome.runtime.lastError) {
          logger.error('❌ Ошибка получения закладок:', chrome.runtime.lastError.message);
          reject(new Error(chrome.runtime.lastError.message));
          return;
        }

        const bookmarklets = [];

        function traverseBookmarks(node, path = '') {
          if (node.url && node.url.startsWith('javascript:')) {
            bookmarklets.push({
              id: node.id,
              title: node.title || 'Без названия',
              url: node.url,
              path: path || 'Корень',
              isBookmarklet: true,
              type: 'bookmarklet',
              parentId: node.parentId,
              isUniversal:
                node.url.includes('useUniversalLoader') || node.url.includes('universal-loader'),
              size: node.url.length,
            });
          }

          if (node.children) {
            const currentPath = path
              ? `${path} > ${node.title || 'Корень'}`
              : node.title || 'Корень';
            for (const child of node.children) {
              traverseBookmarks(child, currentPath);
            }
          }
        }

        for (const root of tree) {
          traverseBookmarks(root, '');
        }

        logger.info(`📦 Найдено ${bookmarklets.length} букмарклетов`);
        resolve(bookmarklets);
      });
    });
  }

  // ============================================================
  // 16. ОБНОВЛЕНИЕ (REFRESH)
  // ============================================================

  _refresh() {
    const logger = this._logger;

    if (this._isUpdating) {
      logger.warn('⚠️ Обновление уже выполняется');
      return Promise.resolve(this._results);
    }

    this._isUpdating = true;
    logger.info('🔄 Обновление букмарклетов...');

    return this._getList()
      .then(bookmarklets => {
        this._bookmarklets = bookmarklets;
        return this._updateAll(bookmarklets);
      })
      .then(results => {
        this._results = results;
        this._lastUpdate = Date.now();
        this._isUpdating = false;
        logger.success(`✅ Обновление завершено: ${results.updated} обновлено`);
        return results;
      })
      .catch(error => {
        this._isUpdating = false;
        logger.error('❌ Ошибка обновления:', error.message);
        throw error;
      });
  }

  // ============================================================
  // 17. ПОЛУЧЕНИЕ СОСТОЯНИЯ
  // ============================================================

  _getState() {
    return {
      initialized: this._initialized,
      isRunning: this._isRunning,
      isDestroyed: this._isDestroyed,
      isUpdating: this._isUpdating,
      bookmarklets: this._bookmarklets.length,
      results: this._results,
      lastUpdate: this._lastUpdate,
      version: this._version,
      build: this._build,
      cacheSize: this._cache.size,
      urlCacheSize: this._bookmarkUrlCache.size,
      compressCacheSize: this._compressCache.size,
      compressionStats: this._compressionStats,
      templateGeneratorLoaded: this._templateGeneratorLoaded,
      templateGeneratorAvailable: this._templateGenerator !== null,
      dynamicConfig: this._dynamicConfig,
      extensionState: this._extensionState,
    };
  }

  // ============================================================
  // 18. КОНФИГУРАЦИЯ
  // ============================================================

  _getConfig() {
    return { ...this._config };
  }

  _getDynamicConfig() {
    return { ...this._dynamicConfig };
  }

  _updateDynamicConfig(config) {
    this._dynamicConfig = { ...this._dynamicConfig, ...config };
    const logger = this._logger;
    logger.info('📌 Динамическая конфигурация обновлена');
    return this._dynamicConfig;
  }

  // ============================================================
  // 19. ДАННЫЕ
  // ============================================================

  _getBookmarklets() {
    return [...this._bookmarklets];
  }

  _getBookmarkUrlCache() {
    return new Map(this._bookmarkUrlCache);
  }

  _clearCache() {
    this._cache.clear();
    this._bookmarkUrlCache.clear();
    this._compressCache.clear();
    this._loaderCache.clear();
    const logger = this._logger;
    logger.info('🗑️ Кеш очищен');
    return this;
  }

  _getCompressionStats() {
    return { ...this._compressionStats };
  }

  _clearCompressionCache() {
    const size = this._compressCache.size;
    this._compressCache.clear();
    const logger = this._logger;
    logger.info(`🗑️ Кеш сжатия очищен (${size} записей)`);
    return size;
  }

  _reset() {
    this._bookmarklets = [];
    this._results = null;
    this._cache.clear();
    this._bookmarkUrlCache.clear();
    this._compressCache.clear();
    this._loaderCache.clear();
    this._isUpdating = false;
    this._lastUpdate = null;
    this._compressionStats = {
      total: 0,
      saved: 0,
      originalSize: 0,
      compressedSize: 0,
      ratio: 0,
    };
    const logger = this._logger;
    logger.info('🔄 Генератор сброшен');
    return this;
  }

  // ============================================================
  // 20. УНИЧТОЖЕНИЕ
  // ============================================================

  _destroy() {
    const logger = this._logger;

    if (this._isDestroyed) {
      logger.warn('⚠️ Генератор уже уничтожен');
      return;
    }

    this._cache.clear();
    this._bookmarkUrlCache.clear();
    this._compressCache.clear();
    this._loaderCache.clear();
    this._loaderScripts.clear();

    if (this._templateGeneratorLoaded && this._templateGenerator) {
      this._templateGenerator.destroy();
    }

    if (typeof window !== 'undefined') {
      delete window.__generator;
      delete window[PUBLIC.API];
      delete window[PUBLIC.STATE];
      delete window[PUBLIC.CONFIG];
      delete window[PUBLIC.LOGGER];
      delete window[PUBLIC.GENERATOR];
      delete window[PUBLIC.UPDATER];
      delete window[PUBLIC.REFRESHER];
      delete window[PUBLIC.INSTANCE];
      delete window.__generatorSymbols;
    }

    this._isDestroyed = true;
    this._initialized = false;
    this._isRunning = false;

    logger.success('🗑️ Генератор уничтожен');
  }

  // ============================================================
  // 21. ПУБЛИЧНЫЕ МЕТОДЫ (ОБЕРТКИ)
  // ============================================================

  generateCode(bookmarkData, options = {}) {
    return this._generateCode(bookmarkData, options);
  }

  generateUniversalBookmarklet(bookmarkData, options = {}) {
    return this._generateUniversal(bookmarkData, options);
  }

  updateBookmark(bookmarkId, newCode) {
    return this._updateBookmark(bookmarkId, newCode);
  }

  updateAll(bookmarklets) {
    return this._updateAll(bookmarklets);
  }

  getList() {
    return this._getList();
  }

  refresh() {
    return this._refresh();
  }

  getState() {
    return this._getState();
  }

  getConfig() {
    return this._getConfig();
  }

  getDynamicConfig() {
    return this._getDynamicConfig();
  }

  updateDynamicConfig(config) {
    return this._updateDynamicConfig(config);
  }

  getBookmarklets() {
    return this._getBookmarklets();
  }

  getBookmarkUrlCache() {
    return this._getBookmarkUrlCache();
  }

  clearCache() {
    return this._clearCache();
  }

  clearCompressionCache() {
    return this._clearCompressionCache();
  }

  getCompressionStats() {
    return this._getCompressionStats();
  }

  reset() {
    return this._reset();
  }

  destroy() {
    return this._destroy();
  }

  getTemplateGeneratorStatus() {
    return {
      loaded: this._templateGeneratorLoaded,
      available: this._templateGenerator !== null,
    };
  }
}

// ============================================================
// 22. СОЗДАНИЕ ЭКЗЕМПЛЯРА
// ============================================================

let generatorInstance = null;

function getGeneratorInstance(options = {}) {
  if (!generatorInstance) {
    generatorInstance = new BookmarkletGenerator(options);
    if (typeof window !== 'undefined') {
      window.__generatorInstance = generatorInstance;
    }
    if (typeof self !== 'undefined') {
      self.__generator = generatorInstance;
    }
  }
  return generatorInstance;
}

// ============================================================
// 23. ЭКСПОРТ
// ============================================================

export default BookmarkletGenerator;
export {
  BookmarkletGenerator,
  getGeneratorInstance,
  PRIVATE,
  PUBLIC,
  DEFAULT_CONFIG,
  DEFAULT_DYNAMIC_CONFIG,
};

// ============================================================
// 24. ИНИЦИАЛИЗАЦИЯ ПРИ ЗАГРУЗКЕ
// ============================================================

if (typeof window !== 'undefined') {
  const generator = getGeneratorInstance({
    debug: true,
    version: '2.0.0',
    build: '2026-07-18',
  });

  console.log('╔═══════════════════════════════════════════════════════════════════════════════╗');
  console.log('║              📦 BOOKMARKLET GENERATOR (100% СИМВОЛЫ)                        ║');
  console.log('╠═══════════════════════════════════════════════════════════════════════════════╣');
  console.log('║  📋 Все логи выводятся в консоль с цветовой разметкой                       ║');
  console.log('║  🔑 Полная изоляция через приватные символы                                 ║');
  console.log('║  🔓 Публичные символы через Symbol.for                                      ║');
  console.log('║  📦 Генерация сжатых букмарклетов                                           ║');
  console.log('║  📊 Полная статистика работы                                                ║');
  console.log('╚═══════════════════════════════════════════════════════════════════════════════╝');

  console.log('📋 ДОСТУПНЫЕ КОМАНДЫ:');
  console.log('  __generator.generateCode()                 - генерировать код');
  console.log('  __generator.generateUniversalBookmarklet() - универсальный букмарклет');
  console.log('  __generator.updateBookmark()              - обновить букмарклет');
  console.log('  __generator.updateAll()                   - обновить все');
  console.log('  __generator.refresh()                     - обновить список');
  console.log('  __generator.getList()                     - получить список');
  console.log('  __generator.getState()                    - получить состояние');
  console.log('  __generator.getConfig()                   - получить конфиг');
  console.log('  __generator.getDynamicConfig()            - получить динамическую конфигурацию');
  console.log('  __generator.updateDynamicConfig()         - обновить динамическую конфигурацию');
  console.log('  __generator.getBookmarklets()             - получить букмарклеты');
  console.log('  __generator.clearCache()                  - очистить кеш');
  console.log('  __generator.getCompressionStats()         - статистика сжатия');
  console.log('  __generator.clearCompressionCache()       - очистить кеш сжатия');
  console.log('  __generator.reset()                       - сбросить');
  console.log('  __generator.destroy()                     - уничтожить');
  console.log('  __generator.getTemplateGeneratorStatus()  - статус генератора шаблонов');
  console.log('');
  console.log('📋 ПРИВАТНЫХ СИМВОЛОВ:', Object.keys(PRIVATE).length);
  console.log('📋 ПУБЛИЧНЫХ СИМВОЛОВ:', Object.keys(PUBLIC).length);
}

// ============================================================
// 25. КОМАНДЫ ДЛЯ ОТЛАДКИ
// ============================================================

if (typeof window !== 'undefined') {
  window.__gen = {
    instance: window.__generatorInstance || window.__generator,
    getState: () => window.__generatorInstance?.getState?.(),
    refresh: () => window.__generatorInstance?.refresh?.(),
    generateCode: (data, opts) => window.__generatorInstance?.generateCode?.(data, opts),
    generateUniversal: (data, opts) =>
      window.__generatorInstance?.generateUniversalBookmarklet?.(data, opts),
    getBookmarklets: () => window.__generatorInstance?.getBookmarklets?.(),
    clearCache: () => window.__generatorInstance?.clearCache?.(),
    reset: () => window.__generatorInstance?.reset?.(),
    destroy: () => window.__generatorInstance?.destroy?.(),
    getSymbols: () => ({
      PRIVATE: { ...PRIVATE },
      PUBLIC: { ...PUBLIC },
    }),
  };

  console.log('📋 КОМАНДЫ ОТЛАДКИ (__gen):');
  console.log('  __gen.getState()         - состояние');
  console.log('  __gen.refresh()          - обновить');
  console.log('  __gen.generateCode()     - генерировать код');
  console.log('  __gen.generateUniversal() - универсальный букмарклет');
  console.log('  __gen.getBookmarklets()  - получить букмарклеты');
  console.log('  __gen.clearCache()       - очистить кеш');
  console.log('  __gen.reset()            - сбросить');
  console.log('  __gen.destroy()          - уничтожить');
  console.log('  __gen.getSymbols()       - получить символы');
}
