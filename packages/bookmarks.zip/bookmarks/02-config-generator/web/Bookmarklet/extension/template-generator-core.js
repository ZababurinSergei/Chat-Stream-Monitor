// template-generator-core.js - Ядро генератора шаблонов (100% СИМВОЛЫ)
// ИСПРАВЛЕННАЯ ВЕРСИЯ: Встроенный базовый генератор, единая точка входа с callback
// Версия: 2.0.7

// ============================================================
// 1. ПРИВАТНЫЕ СИМВОЛЫ (100% изоляция)
// ============================================================

const PRIVATE = {
  // Основные символы
  CONFIG: Symbol('tg.config'),
  LOGGER: Symbol('tg.logger'),
  CACHE: Symbol('tg.cache'),
  CODEC: Symbol('tg.codec'),
  BASE_GENERATOR: Symbol('tg.baseGenerator'),
  TEMPLATES: Symbol('tg.templates'),
  COMPRESSED_CACHE: Symbol('tg.compressedCache'),
  STATS: Symbol('tg.stats'),
  CODEC_READY: Symbol('tg.codecReady'),
  CODEC_LOADING: Symbol('tg.codecLoading'),
  CODEC_ERROR: Symbol('tg.codecError'),
  CODEC_PROMISE: Symbol('tg.codecPromise'),
  INITIALIZED: Symbol('tg.initialized'),
  VERSION: Symbol('tg.version'),
  BUILD: Symbol('tg.build'),

  // Символы для методов (приватные)
  LOAD_CODEC_LAZY: Symbol('tg.loadCodecLazy'),
  MINIFY_CODE: Symbol('tg.minifyCode'),
  FALLBACK_MINIFY: Symbol('tg.fallbackMinify'),
  COMPRESS_CODE: Symbol('tg.compressCode'),
  GENERATE_TEMPLATE: Symbol('tg.generateTemplate'),
  GENERATE_ALL: Symbol('tg.generateAll'),
  GET_TEMPLATE: Symbol('tg.getTemplate'),
  GET_TEMPLATE_BY_NAME: Symbol('tg.getTemplateByName'),
  GET_ALL_TEMPLATES: Symbol('tg.getAllTemplates'),
  DELETE_TEMPLATE: Symbol('tg.deleteTemplate'),
  CLEAR_ALL: Symbol('tg.clearAll'),
  GET_STATS: Symbol('tg.getStats'),
  GET_CODEC_STATUS: Symbol('tg.getCodecStatus'),
  EXPORT_JSON: Symbol('tg.exportJSON'),
  IMPORT_JSON: Symbol('tg.importJSON'),
  CLEAR_CACHE: Symbol('tg.clearCache'),
  DESTROY: Symbol('tg.destroy'),

  // ★★★ НОВЫЕ СИМВОЛЫ ★★★
  CREATE_BASE_GENERATOR: Symbol('tg.createBaseGenerator'),
  BASE_GENERATOR_READY: Symbol('tg.baseGeneratorReady'),
  GENERATE_BOOKMARKLET_CODE: Symbol('tg.generateBookmarkletCode'),
  DEFAULT_CALLBACK: Symbol('tg.defaultCallback'),
};

// ============================================================
// 2. ПУБЛИЧНЫЕ СИМВОЛЫ (доступны через Symbol.for)
// ============================================================

const PUBLIC = {
  API: Symbol.for('template-generator.api'),
  STATE: Symbol.for('template-generator.state'),
  CONFIG: Symbol.for('template-generator.config'),
  LOGGER: Symbol.for('template-generator.logger'),
  GENERATOR: Symbol.for('template-generator.generator'),
  TEMPLATES: Symbol.for('template-generator.templates'),
  STATS: Symbol.for('template-generator.stats'),
  INSTANCE: Symbol.for('template-generator.instance'),
};

// ============================================================
// 3. КОНФИГУРАЦИЯ
// ============================================================

const DEFAULT_CONFIG = {
  debug: true,
  basePath: './Bookmarklet/',
  version: '2.0.7',
  build: '2026-07-19',
  compression: {
    enabled: true,
    minify: true,
    removeComments: true,
    shortenVariables: true,
    compressBooleans: true,
    aggressiveCompression: true,
    maxUrlLength: 2000,
  },
  templates: {
    maxCacheSize: 100,
    autoCompress: true,
    defaultType: 'main',
  },
  // ★★★ НОВАЯ КОНФИГУРАЦИЯ ДЛЯ CALLBACK ★★★
  callback: {
    enabled: true,
    default: '(r)=>console.log("✅",r)',
    extended: '(r)=>{ if(r.success) { console.log("✅ Букмарклет выполнен:", r); } else { console.error("❌ Ошибка:", r.error); } }',
    full: '(r)=>{ if(r.success) { console.log("✅", r); const el=document.createElement("div"); el.style.cssText="position:fixed;bottom:20px;right:20px;background:rgba(0,184,148,0.9);color:#fff;padding:10px 20px;border-radius:8px;z-index:999999;font-family:monospace;font-size:13px;"; el.textContent="✅ "+(r.type||"Букмарклет")+" загружен"; document.body.appendChild(el); setTimeout(()=>el.remove(),3000); } else { console.error("❌", r.error); } }'
  }
};

// ============================================================
// 4. ВСТРОЕННЫЙ МИНИФИКАТОР (без внешних зависимостей)
// ============================================================

const BuiltinMinifier = {
  /**
   * Минифицирует код без использования внешних библиотек
   */
  minify(code) {
    if (!code || typeof code !== 'string') return code;

    let result = code;

    // 1. Удаляем комментарии
    result = result.replace(/\/\*[\s\S]*?\*\//g, '');
    result = result.replace(/\/\/.*$/gm, '');

    // 2. Удаляем лишние пробелы
    result = result.replace(/\s+/g, ' ');
    result = result.replace(/\s*([{}()\[\];,:])\s*/g, '$1');
    result = result.replace(/;\s*}/g, '}');
    result = result.replace(/{\s+/g, '{');
    result = result.replace(/\s+}/g, '}');
    result = result.replace(/\(\s+/g, '(');
    result = result.replace(/\s+\)/g, ')');
    result = result.replace(/\[\s+/g, '[');
    result = result.replace(/\s+]/g, ']');

    // 3. Сокращаем переменные
    const varMap = new Map();
    let counter = 0;
    const varRegex = /(?:var|let|const)\s+([a-zA-Z_$][a-zA-Z0-9_$]*)/g;
    let match;
    const varNames = [];
    while ((match = varRegex.exec(result)) !== null) {
      const name = match[1];
      if (name.length > 2 && !['if', 'for', 'while', 'switch', 'try', 'catch'].includes(name)) {
        varNames.push(name);
      }
    }

    varNames.sort((a, b) => b.length - a.length);
    const shortNames = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    for (const name of varNames) {
      if (!varMap.has(name)) {
        let short = shortNames[counter % shortNames.length];
        if (counter >= shortNames.length) {
          short += Math.floor(counter / shortNames.length);
        }
        varMap.set(name, short);
        counter++;
      }
    }

    for (const [oldName, newName] of varMap) {
      const regex = new RegExp('\\b' + oldName + '\\b', 'g');
      result = result.replace(regex, newName);
    }

    // 4. Сокращаем true/false
    result = result.replace(/\btrue\b/g, '!0');
    result = result.replace(/\bfalse\b/g, '!1');
    result = result.replace(/\bundefined\b/g, 'void 0');

    // 5. Финальная очистка
    result = result.replace(/\n/g, ' ');
    result = result.replace(/\r/g, ' ');
    result = result.replace(/\s+/g, ' ');
    result = result.trim();

    return result;
  },

  /**
   * Сжимает код для URL
   */
  compress(code) {
    if (!code || typeof code !== 'string') return code;

    const minified = this.minify(code);
    const cleaned = minified.replace(/^javascript:/i, '').replace(/\s+/g, ' ');
    const encoded = encodeURIComponent(cleaned);
    return 'javascript:' + encoded;
  },

  /**
   * Проверяет, доступен ли кодек
   */
  isAvailable() {
    return true;
  },

  /**
   * Получает статус
   */
  getStatus() {
    return { ready: true, type: 'builtin' };
  },
};

// ============================================================
// 5. ЛОГГЕР С ПРИВЯЗКОЙ КОНТЕКСТА (100% СИМВОЛЫ)
// ============================================================

const LOGGER_SYMBOLS = {
  HISTORY: Symbol('logger.history'),
  MAX_HISTORY: Symbol('logger.maxHistory'),
  DEBUG: Symbol('logger.debug'),
  INSTANCE_ID: Symbol('logger.instanceId'),
};

function createLogger(debug = true, instanceId = 'TemplateGenerator') {
  const state = {
    [LOGGER_SYMBOLS.HISTORY]: [],
    [LOGGER_SYMBOLS.MAX_HISTORY]: 200,
    [LOGGER_SYMBOLS.DEBUG]: debug,
    [LOGGER_SYMBOLS.INSTANCE_ID]: instanceId,
  };

  const logMethod = function (level, message, data = null) {
    if (!this[LOGGER_SYMBOLS.DEBUG] && level !== 'error') {
      return;
    }

    const timestamp = new Date().toISOString().slice(11, 23);
    const prefix = `[${timestamp}] [${this[LOGGER_SYMBOLS.INSTANCE_ID]}]`;

    this[LOGGER_SYMBOLS.HISTORY].push({ timestamp, level, message, data });
    if (this[LOGGER_SYMBOLS.HISTORY].length > this[LOGGER_SYMBOLS.MAX_HISTORY]) {
      this[LOGGER_SYMBOLS.HISTORY].shift();
    }

    if (data !== null && data !== undefined) {
      console.log(`${prefix} ${message}`, data);
    } else {
      console.log(`${prefix} ${message}`);
    }
  };

  const boundLog = logMethod.bind(state);

  const methods = {
    error: function (msg, d) {
      boundLog('error', `❌ ${msg}`, d);
    },
    warn: function (msg, d) {
      boundLog('warn', `⚠️ ${msg}`, d);
    },
    info: function (msg, d) {
      boundLog('info', `ℹ️ ${msg}`, d);
    },
    debug: function (msg, d) {
      boundLog('debug', `🔍 ${msg}`, d);
    },
    success: function (msg, d) {
      boundLog('info', `✅ ${msg}`, d);
    },

    header: function (title) {
      console.log('%c' + '═'.repeat(70), 'color: #636e72;');
      console.log(
          '%c  📦 ' + title,
          'background: #1a1a2e; color: #fff; padding: 4px 12px; border-radius: 4px; font-weight: bold;'
      );
      console.log('%c' + '═'.repeat(70), 'color: #636e72;');
    },

    separator: function () {
      console.log('%c' + '─'.repeat(70), 'color: #636e72;');
    },

    symbol: function (name, symbol) {
      console.log(`  🔑 ${name}: ${String(symbol)}`);
    },

    private: function (name, symbol) {
      console.log(`  🔒 ${name}: ${String(symbol)}`);
    },

    getHistory: function () {
      return [...this[LOGGER_SYMBOLS.HISTORY]];
    },

    clearHistory: function () {
      this[LOGGER_SYMBOLS.HISTORY] = [];
      return this;
    },

    setDebug: function (enabled) {
      this[LOGGER_SYMBOLS.DEBUG] = enabled;
      return this;
    },
  };

  const logger = {};
  for (const [key, fn] of Object.entries(methods)) {
    logger[key] = fn.bind(state);
  }

  logger[LOGGER_SYMBOLS.HISTORY] = state[LOGGER_SYMBOLS.HISTORY];
  logger[LOGGER_SYMBOLS.MAX_HISTORY] = state[LOGGER_SYMBOLS.MAX_HISTORY];
  logger[LOGGER_SYMBOLS.DEBUG] = state[LOGGER_SYMBOLS.DEBUG];
  logger[LOGGER_SYMBOLS.INSTANCE_ID] = state[LOGGER_SYMBOLS.INSTANCE_ID];

  return logger;
}

// ============================================================
// 6. ОСНОВНОЙ КЛАСС ЯДРА ГЕНЕРАТОРА ШАБЛОНОВ (100% СИМВОЛЫ)
// ============================================================

class TemplateGeneratorCore {
  constructor(options = {}) {
    // ============================================================
    // 6.1 ИНИЦИАЛИЗАЦИЯ КОНФИГУРАЦИИ
    // ============================================================

    this._config = {
      ...DEFAULT_CONFIG,
      ...options,
      compression: { ...DEFAULT_CONFIG.compression, ...options.compression },
      templates: { ...DEFAULT_CONFIG.templates, ...options.templates },
      callback: { ...DEFAULT_CONFIG.callback, ...options.callback },
    };

    this._version = this._config.version;
    this._build = this._config.build;
    this._initialized = false;

    // ============================================================
    // 6.2 СОЗДАНИЕ ЛОГГЕРА
    // ============================================================

    this._logger = createLogger(this._config.debug !== false, 'TemplateGenerator');
    const logger = this._logger;

    // ============================================================
    // 6.3 ИНИЦИАЛИЗАЦИЯ ХРАНИЛИЩ
    // ============================================================

    this._cache = new Map();
    this._templates = new Map();
    this._compressedCache = new Map();
    this._stats = {
      totalGenerated: 0,
      totalCompressed: 0,
      totalSaved: 0,
      averageRatio: 0,
      cacheHits: 0,
      cacheMisses: 0,
    };

    // ============================================================
    // 6.4 КОДЕК - ИСПОЛЬЗУЕМ ВСТРОЕННЫЙ МИНИФИКАТОР
    // ============================================================

    this._codec = BuiltinMinifier;
    this._codecReady = true;
    this._codecLoading = false;
    this._codecError = null;
    this._codecPromise = null;

    // ============================================================
    // 6.5 ★★★ БАЗОВЫЙ ГЕНЕРАТОР (ВСТРОЕННЫЙ) ★★★
    // ============================================================

    this._baseGenerator = null;
    this._baseGeneratorReady = false;

    // Создаем встроенный базовый генератор
    this[PRIVATE.CREATE_BASE_GENERATOR]();

    // ============================================================
    // 6.6 ИНИЦИАЛИЗАЦИЯ
    // ============================================================

    this._initialized = true;

    // ============================================================
    // 6.7 ЭКСПОРТ СИМВОЛОВ
    // ============================================================

    this._exportSymbols();

    // ============================================================
    // 6.8 ЛОГИРОВАНИЕ
    // ============================================================

    logger.header('СОЗДАНИЕ ЯДРА ГЕНЕРАТОРА ШАБЛОНОВ (100% СИМВОЛЫ)');
    logger.info(`📦 Версия: ${this._version}`);
    logger.info(`📅 Сборка: ${this._build}`);
    logger.info(`📌 BasePath: ${this._config.basePath}`);
    logger.info(`📌 Сжатие: ${this._config.compression.enabled ? '✅' : '❌'}`);
    logger.info(`📌 Кодек: встроенный минификатор (без внешних зависимостей)`);
    logger.info(`📌 Базовый генератор: ${this._baseGenerator ? '✅' : '❌'}`);
    logger.info(`📌 Callback: ${this._config.callback.enabled ? '✅' : '❌'}`);

    logger.separator();
    logger.info(`🔑 ПРИВАТНЫХ СИМВОЛОВ: ${Object.keys(PRIVATE).length}`);
    logger.info(`🔑 ПУБЛИЧНЫХ СИМВОЛОВ: ${Object.keys(PUBLIC).length}`);
    logger.separator();

    logger.success('✅ Ядро генератора шаблонов создано');
    logger.header('ГОТОВ');
  }

  // ============================================================
  // 7. ЭКСПОРТ СИМВОЛОВ
  // ============================================================

  _exportSymbols() {
    if (typeof window !== 'undefined') {
      window.__templateGeneratorCore = this;
      window[PUBLIC.API] = this;
      window[PUBLIC.STATE] = this.getStats.bind(this);
      window[PUBLIC.CONFIG] = this._config;
      window[PUBLIC.LOGGER] = this._logger;
      window[PUBLIC.GENERATOR] = this;
      window[PUBLIC.TEMPLATES] = this.getAllTemplates.bind(this);
      window[PUBLIC.STATS] = this.getStats.bind(this);
      window[PUBLIC.INSTANCE] = this;

      window.__templateGeneratorCoreSymbols = {
        PRIVATE: { ...PRIVATE },
        PUBLIC: { ...PUBLIC },
        version: this._version,
        build: this._build,
      };
    }
  }

  // ============================================================
  // 8. ★★★ СОЗДАНИЕ ВСТРОЕННОГО БАЗОВОГО ГЕНЕРАТОРА ★★★
  // ============================================================

  [PRIVATE.CREATE_BASE_GENERATOR]() {
    const logger = this._logger;
    logger.info('🔧 Создание встроенного базового генератора...');

    try {
      this._baseGenerator = this._createBuiltinGenerator();
      this._baseGeneratorReady = true;
      logger.success('✅ Базовый генератор создан (встроенный, с callback)');
    } catch (error) {
      logger.error('❌ Ошибка создания базового генератора:', error.message);
      this._baseGenerator = this._createFallbackGenerator();
      this._baseGeneratorReady = true;
      logger.success('✅ Базовый генератор создан (fallback)');
    }
  }

  /**
   * Создает встроенный базовый генератор с callback
   */
  _createBuiltinGenerator() {
    const logger = this._logger;
    const self = this;

    return {
      // ============================================================
      // ГЕНЕРАЦИЯ КОДА БУКМАРКЛЕТА С CALLBACK
      // ============================================================

      /**
       * Генерирует код букмарклета с callback
       */
      [PRIVATE.GENERATE_BOOKMARKLET_CODE](title, type, id, version, callback) {
        const safeTitle = title.replace(/'/g, "\\'");
        const cb = callback || self._config.callback.default || '(r)=>console.log("✅",r)';

        return `javascript:import('./Bookmarklet/bookmarklet.js').then(m=>m.default({name:'${safeTitle}',type:'${type}',id:'${id}',version:'${version}',callback:${cb}}))`;
      },

      /**
       * Генерирует шаблон букмарклета
       */
      generateTemplate: (bookmarkData, options = {}) => {
        const title = bookmarkData?.title || options.title || 'Bookmarklet';
        const type = options.type || self._config.templates.defaultType;
        const id = options.componentId || 'bm-' + Date.now() + '-' + Math.random().toString(36).substr(2, 4);
        const version = options.version || self._version;
        const callback = options.callback || self._config.callback.default;

        logger.info(`📝 Генерация шаблона: "${title}" (${type})`);

        // ★★★ ГЕНЕРАЦИЯ КОДА С CALLBACK ★★★
        const code = self[PRIVATE.GENERATE_BOOKMARKLET_CODE](title, type, id, version, callback);

        const template = {
          id,
          componentId: id,
          title,
          type,
          code,
          version,
          callback,
          generated: Date.now(),
          generatedISO: new Date().toISOString(),
        };

        self._templates.set(id, template);
        self._stats.totalGenerated++;

        logger.success(`✅ Шаблон "${title}" сгенерирован (${code.length} байт)`);
        return template;
      },

      /**
       * Генерирует код букмарклета (алиас)
       */
      generateCode: (bookmarkData, options = {}) => {
        return this.generateTemplate(bookmarkData, options);
      },

      /**
       * Генерирует универсальный букмарклет
       */
      generateUniversalBookmarklet: (bookmarkData, options = {}) => {
        return this.generateTemplate(bookmarkData, options);
      },

      // ============================================================
      // МИНИФИКАЦИЯ И СЖАТИЕ
      // ============================================================

      minify: (code) => {
        return self._codec.minify(code);
      },

      compress: (code) => {
        return self._codec.compress(code);
      },

      // ============================================================
      // УПРАВЛЕНИЕ ШАБЛОНАМИ
      // ============================================================

      getTemplate: (id) => {
        return self._templates.get(id) || null;
      },

      getAllTemplates: () => {
        return Array.from(self._templates.values());
      },

      deleteTemplate: (id) => {
        return self._templates.delete(id);
      },

      clearAll: () => {
        const count = self._templates.size;
        self._templates.clear();
        self._stats.totalGenerated = 0;
        logger.info(`🗑️ Очищено ${count} шаблонов`);
        return { cleared: count };
      },

      // ============================================================
      // СТАТИСТИКА
      // ============================================================

      getStats: () => {
        const templates = Array.from(self._templates.values());
        const avgSize = templates.length > 0
            ? (templates.reduce((sum, t) => sum + t.code.length, 0) / templates.length)
            : 0;
        return {
          totalGenerated: self._stats.totalGenerated,
          templatesCount: templates.length,
          averageSize: avgSize.toFixed(0),
          types: templates.reduce((acc, t) => {
            acc[t.type] = (acc[t.type] || 0) + 1;
            return acc;
          }, {}),
          callbackEnabled: self._config.callback.enabled,
        };
      },

      // ============================================================
      // ЭКСПОРТ/ИМПОРТ
      // ============================================================

      exportToJSON: () => {
        const templates = Array.from(self._templates.values());
        return JSON.stringify({
          version: self._version,
          timestamp: new Date().toISOString(),
          templates: templates.map(t => ({
            id: t.id,
            title: t.title,
            type: t.type,
            code: t.code,
            callback: t.callback || null,
            generated: t.generatedISO,
            version: t.version,
          })),
        }, null, 2);
      },

      importFromJSON: (json) => {
        try {
          const data = typeof json === 'string' ? JSON.parse(json) : json;
          if (!data.templates || !Array.isArray(data.templates)) {
            throw new Error('Неверный формат');
          }

          let imported = 0;
          for (const t of data.templates) {
            if (t.id && t.code) {
              const template = {
                id: t.id,
                componentId: t.id,
                title: t.title || 'Bookmarklet',
                type: t.type || 'main',
                code: t.code,
                callback: t.callback || self._config.callback.default,
                version: t.version || self._version,
                generated: t.generated ? new Date(t.generated).getTime() : Date.now(),
                generatedISO: t.generated || new Date().toISOString(),
              };
              self._templates.set(t.id, template);
              imported++;
            }
          }
          self._stats.totalGenerated += imported;
          logger.success(`✅ Импортировано ${imported} шаблонов`);
          return { imported, total: data.templates.length };
        } catch (error) {
          logger.error('❌ Ошибка импорта:', error.message);
          throw error;
        }
      },

      // ============================================================
      // УПРАВЛЕНИЕ ЖИЗНЕННЫМ ЦИКЛОМ
      // ============================================================

      reset: () => {
        self._templates.clear();
        self._stats.totalGenerated = 0;
        logger.info('🔄 Базовый генератор сброшен');
      },

      destroy: () => {
        self._templates.clear();
        self._cache.clear();
        logger.info('🗑️ Базовый генератор уничтожен');
      },

      getState: () => {
        return {
          initialized: true,
          version: self._version,
          type: 'builtin-with-callback',
          templatesCount: self._templates.size,
          callbackEnabled: self._config.callback.enabled,
        };
      },
    };
  }

  /**
   * Создает fallback генератор
   */
  _createFallbackGenerator() {
    const logger = this._logger;
    const self = this;

    return {
      generateTemplate: (bookmarkData, options = {}) => {
        const title = bookmarkData?.title || options.title || 'Bookmarklet';
        const type = options.type || self._config.templates.defaultType;
        const id = options.componentId || 'bm-' + Date.now() + '-' + Math.random().toString(36).substr(2, 4);
        const version = options.version || self._version;
        const callback = options.callback || self._config.callback.default;

        const code = `javascript:import('./Bookmarklet/bookmarklet.js').then(m=>m.default({name:'${title.replace(/'/g, "\\'")}',type:'${type}',id:'${id}',version:'${version}',callback:${callback}}))`;

        const template = {
          id,
          componentId: id,
          title,
          type,
          code,
          version,
          callback,
          generated: Date.now(),
          generatedISO: new Date().toISOString(),
        };

        self._templates.set(id, template);
        self._stats.totalGenerated++;
        return template;
      },

      generateCode: (bookmarkData, options) => {
        return this.generateTemplate(bookmarkData, options);
      },

      generateUniversalBookmarklet: (bookmarkData, options) => {
        return this.generateTemplate(bookmarkData, options);
      },

      minify: (code) => code,
      compress: (code) => code,

      getTemplate: (id) => self._templates.get(id) || null,
      getAllTemplates: () => Array.from(self._templates.values()),
      deleteTemplate: (id) => self._templates.delete(id),
      clearAll: () => {
        const count = self._templates.size;
        self._templates.clear();
        return { cleared: count };
      },
      getStats: () => ({
        totalGenerated: self._stats.totalGenerated,
        templatesCount: self._templates.size,
        callbackEnabled: self._config.callback.enabled,
      }),
      exportToJSON: () => {
        const templates = Array.from(self._templates.values());
        return JSON.stringify({
          version: self._version,
          timestamp: new Date().toISOString(),
          templates: templates.map(t => ({
            id: t.id,
            title: t.title,
            type: t.type,
            code: t.code,
            callback: t.callback || null,
            generated: t.generatedISO,
          })),
        }, null, 2);
      },
      importFromJSON: (json) => {
        try {
          const data = typeof json === 'string' ? JSON.parse(json) : json;
          if (!data.templates || !Array.isArray(data.templates)) {
            throw new Error('Неверный формат');
          }
          let imported = 0;
          for (const t of data.templates) {
            if (t.id && t.code) {
              self._templates.set(t.id, {
                id: t.id,
                componentId: t.id,
                title: t.title || 'Bookmarklet',
                type: t.type || 'main',
                code: t.code,
                callback: t.callback || self._config.callback.default,
                version: t.version || self._version,
                generated: t.generated ? new Date(t.generated).getTime() : Date.now(),
                generatedISO: t.generated || new Date().toISOString(),
              });
              imported++;
            }
          }
          return { imported, total: data.templates.length };
        } catch (error) {
          throw error;
        }
      },
      reset: () => { self._templates.clear(); },
      destroy: () => { self._templates.clear(); },
      getState: () => ({
        initialized: true,
        version: self._version,
        type: 'fallback',
        templatesCount: self._templates.size,
      }),
    };
  }

  // ============================================================
  // 9. ГЕНЕРАЦИЯ ШАБЛОНА
  // ============================================================

  [PRIVATE.GENERATE_TEMPLATE](bookmarkData, options = {}) {
    return this._generateTemplate(bookmarkData, options);
  }

  _generateTemplate(bookmarkData, options = {}) {
    const logger = this._logger;
    const title = bookmarkData?.title || options.title || 'Bookmarklet';
    const type = options.type || this._config.templates.defaultType;
    const componentId = options.componentId || 'bm-' + Date.now() + '-' + Math.random().toString(36).substr(2, 4);
    const version = options.version || this._version;
    const callback = options.callback || this._config.callback.default;

    logger.info(`📝 Генерация шаблона: "${title}" (${type})`);

    // Используем базовый генератор
    const template = this._baseGenerator.generateTemplate(
        { title, id: componentId },
        { type, title, componentId, version, callback }
    );

    // Добавляем в кеш
    this._templates.set(componentId, template);

    logger.success(`✅ Шаблон "${title}" сгенерирован (${template.code.length} байт)`);

    return template;
  }

  // ============================================================
  // 10. ГЕНЕРАЦИЯ ВСЕХ ШАБЛОНОВ
  // ============================================================

  [PRIVATE.GENERATE_ALL](options = {}) {
    return this._generateAll(options);
  }

  _generateAll(options = {}) {
    const logger = this._logger;
    logger.header('ГЕНЕРАЦИЯ ВСЕХ ШАБЛОНОВ');

    const types = [
      { name: 'ENV Control', type: 'env' },
      { name: 'Logs Control', type: 'logs' },
      { name: 'Debug Control', type: 'debug' },
      { name: 'Manager', type: 'manager' },
      { name: 'Toggle ENV', type: 'env' },
      { name: 'Toggle Logs', type: 'logs' },
      { name: 'Toggle Debug', type: 'debug' },
      { name: 'Register SW', type: 'sw' },
      { name: 'Reset All', type: 'reset' },
      { name: 'Widget', type: 'widget' },
    ];

    const results = [];

    for (const t of types) {
      const template = this._generateTemplate(
          { title: t.name },
          { type: t.type, title: t.name, ...options }
      );
      if (template) {
        results.push(template);
      }
    }

    logger.success(`✅ Сгенерировано ${results.length} шаблонов`);
    logger.info(`📊 Средний размер: ${(results.reduce((sum, r) => sum + r.code.length, 0) / results.length / 1024).toFixed(2)} KB`);

    return results;
  }

  // ============================================================
  // 11. ГЕНЕРАЦИЯ СЖАТОГО ШАБЛОНА
  // ============================================================

  generateCompressedTemplate(bookmarkData, options = {}) {
    const logger = this._logger;
    const template = this._generateTemplate(bookmarkData, options);

    if (!template) {
      logger.error('❌ Не удалось сгенерировать шаблон');
      return null;
    }

    logger.info(`🗜️ Сжатие шаблона: "${template.title}"`);

    const compressed = this._compressCode(template.code);

    const result = {
      ...template,
      compressed,
      compression: {
        originalSize: template.code.length,
        compressedSize: compressed.length,
        saved: template.code.length - compressed.length,
        ratio: ((1 - compressed.length / template.code.length) * 100).toFixed(1),
      },
    };

    logger.success(`✅ Шаблон "${template.title}" сжат`);
    logger.info(`📊 Сжатие: ${result.compression.saved} байт (${result.compression.ratio}%)`);

    return result;
  }

  // ============================================================
  // 12. ПОЛУЧЕНИЕ ШАБЛОНОВ
  // ============================================================

  [PRIVATE.GET_TEMPLATE](id) {
    return this._getTemplate(id);
  }

  _getTemplate(id) {
    return this._templates.get(id) || null;
  }

  [PRIVATE.GET_TEMPLATE_BY_NAME](name) {
    return this._getTemplateByName(name);
  }

  _getTemplateByName(name) {
    for (const [id, template] of this._templates) {
      if (template.title === name) {
        return template;
      }
    }
    return null;
  }

  [PRIVATE.GET_ALL_TEMPLATES]() {
    return this._getAllTemplates();
  }

  _getAllTemplates() {
    return Array.from(this._templates.values());
  }

  // ============================================================
  // 13. УДАЛЕНИЕ ШАБЛОНОВ
  // ============================================================

  [PRIVATE.DELETE_TEMPLATE](id) {
    return this._deleteTemplate(id);
  }

  _deleteTemplate(id) {
    const result = this._templates.delete(id);
    if (result) {
      this._logger.info(`🗑️ Шаблон удален: ${id}`);
    }
    return result;
  }

  [PRIVATE.CLEAR_ALL]() {
    return this._clearAll();
  }

  _clearAll() {
    const count = this._templates.size;
    this._templates.clear();
    this._stats.totalGenerated = 0;
    this._logger.info(`🗑️ Очищено ${count} шаблонов`);
    return { cleared: count };
  }

  // ============================================================
  // 14. СТАТИСТИКА
  // ============================================================

  [PRIVATE.GET_STATS]() {
    return this._getStats();
  }

  _getStats() {
    const templates = this._getAllTemplates();
    const types = templates.reduce((acc, t) => {
      acc[t.type] = (acc[t.type] || 0) + 1;
      return acc;
    }, {});

    const avgSize = templates.length > 0
        ? (templates.reduce((sum, t) => sum + t.code.length, 0) / templates.length / 1024).toFixed(2)
        : 0;

    return {
      totalGenerated: this._stats.totalGenerated,
      templatesCount: templates.length,
      averageSize: avgSize,
      types,
      version: this._version,
      build: this._build,
      initialized: this._initialized,
      baseGeneratorAvailable: !!this._baseGenerator,
      baseGeneratorType: this._baseGenerator ? 'builtin-with-callback' : 'none',
      callbackEnabled: this._config.callback.enabled,
      callbackDefault: this._config.callback.default,
    };
  }

  // ============================================================
  // 15. СТАТУС КОДЕКА
  // ============================================================

  [PRIVATE.GET_CODEC_STATUS]() {
    return this._getCodecStatus();
  }

  _getCodecStatus() {
    return {
      ready: true,
      loading: false,
      hasError: false,
      error: null,
      codecAvailable: true,
      type: 'builtin',
    };
  }

  // ============================================================
  // 16. ЭКСПОРТ/ИМПОРТ
  // ============================================================

  [PRIVATE.EXPORT_JSON]() {
    return this._exportJSON();
  }

  _exportJSON() {
    const data = {
      version: this._version,
      build: this._build,
      timestamp: new Date().toISOString(),
      config: this._config,
      stats: this._getStats(),
      templates: this._getAllTemplates().map(t => ({
        id: t.componentId || t.id,
        title: t.title,
        type: t.type,
        code: t.code,
        callback: t.callback || null,
        generated: t.generatedISO || new Date(t.generated).toISOString(),
        version: t.version || this._version,
      })),
    };
    return JSON.stringify(data, null, 2);
  }

  [PRIVATE.IMPORT_JSON](json) {
    return this._importJSON(json);
  }

  _importJSON(json) {
    const logger = this._logger;
    try {
      const data = typeof json === 'string' ? JSON.parse(json) : json;

      if (!data.templates || !Array.isArray(data.templates)) {
        throw new Error('Неверный формат: ожидается массив templates');
      }

      let imported = 0;
      for (const t of data.templates) {
        if (t.id && t.code) {
          const template = {
            id: t.id,
            componentId: t.id,
            title: t.title || 'Bookmarklet',
            type: t.type || 'main',
            code: t.code,
            callback: t.callback || this._config.callback.default,
            generated: t.generated ? new Date(t.generated).getTime() : Date.now(),
            generatedISO: t.generated || new Date().toISOString(),
            version: t.version || data.version || this._version,
          };
          this._templates.set(t.id, template);
          imported++;
        }
      }

      logger.success(`✅ Импортировано ${imported} шаблонов`);
      return { imported, total: data.templates.length };
    } catch (error) {
      logger.error('❌ Ошибка импорта:', error.message);
      throw error;
    }
  }

  // ============================================================
  // 17. ОЧИСТКА КЕША
  // ============================================================

  [PRIVATE.CLEAR_CACHE]() {
    return this._clearCache();
  }

  _clearCache() {
    this._cache.clear();
    this._compressedCache.clear();
    this._logger.info('🗑️ Кеш очищен');
    return this;
  }

  // ============================================================
  // 18. УНИЧТОЖЕНИЕ
  // ============================================================

  [PRIVATE.DESTROY]() {
    return this._destroy();
  }

  _destroy() {
    this._cache.clear();
    this._compressedCache.clear();
    this._templates.clear();

    if (this._baseGenerator && typeof this._baseGenerator.destroy === 'function') {
      this._baseGenerator.destroy();
    }
    this._baseGenerator = null;
    this._baseGeneratorReady = false;

    this._codec = null;
    this._initialized = false;

    if (typeof window !== 'undefined') {
      delete window.__templateGeneratorCore;
      delete window[PUBLIC.API];
      delete window[PUBLIC.STATE];
      delete window[PUBLIC.CONFIG];
      delete window[PUBLIC.LOGGER];
      delete window[PUBLIC.GENERATOR];
      delete window[PUBLIC.TEMPLATES];
      delete window[PUBLIC.STATS];
      delete window[PUBLIC.INSTANCE];
      delete window.__templateGeneratorCoreSymbols;
    }

    this._logger.info('🗑️ Ядро генератора шаблонов уничтожено');
  }

  // ============================================================
  // 19. ДОПОЛНИТЕЛЬНЫЙ МЕТОД
  // ============================================================

  ensureCodecLoaded() {
    return Promise.resolve(true);
  }

  // ============================================================
  // 20. ПУБЛИЧНЫЕ МЕТОДЫ (ОБЕРТКИ)
  // ============================================================

  minify(code) {
    return this._minifyCode(code);
  }

  compress(code) {
    return this._compressCode(code);
  }

  generateTemplate(bookmarkData, options = {}) {
    return this._generateTemplate(bookmarkData, options);
  }

  generateCompressedTemplate(bookmarkData, options = {}) {
    return this.generateCompressedTemplate(bookmarkData, options);
  }

  generateAllTemplates(options = {}) {
    return this._generateAll(options);
  }

  getTemplate(id) {
    return this._getTemplate(id);
  }

  getTemplateByName(name) {
    return this._getTemplateByName(name);
  }

  getAllTemplates() {
    return this._getAllTemplates();
  }

  deleteTemplate(id) {
    return this._deleteTemplate(id);
  }

  clearAll() {
    return this._clearAll();
  }

  getStats() {
    return this._getStats();
  }

  getCodecStatus() {
    return this._getCodecStatus();
  }

  exportToJSON() {
    return this._exportJSON();
  }

  importFromJSON(json) {
    return this._importJSON(json);
  }

  clearCache() {
    return this._clearCache();
  }

  destroy() {
    return this._destroy();
  }

  /**
   * Получить статус базового генератора
   */
  getBaseGeneratorStatus() {
    return {
      available: !!this._baseGenerator,
      ready: this._baseGeneratorReady,
      type: this._baseGenerator ? 'builtin-with-callback' : 'none',
      callbackEnabled: this._config.callback.enabled,
    };
  }

  /**
   * Установить callback по умолчанию
   */
  setDefaultCallback(callback) {
    this._config.callback.default = callback;
    this._logger.info('📌 Callback по умолчанию обновлен');
    return this;
  }

  /**
   * Получить callback по умолчанию
   */
  getDefaultCallback() {
    return this._config.callback.default;
  }

  // ============================================================
  // 21. ГЕТТЕРЫ ДЛЯ ПРИВАТНЫХ ДАННЫХ
  // ============================================================

  get [PRIVATE.CONFIG]() {
    return this._config;
  }

  get [PRIVATE.LOGGER]() {
    return this._logger;
  }

  get [PRIVATE.STATS]() {
    return this._stats;
  }

  get [PRIVATE.TEMPLATES]() {
    return this._templates;
  }

  get [PRIVATE.COMPRESSED_CACHE]() {
    return this._compressedCache;
  }

  get [PRIVATE.CODEC]() {
    return this._codec;
  }

  get [PRIVATE.BASE_GENERATOR]() {
    return this._baseGenerator;
  }

  get [PRIVATE.VERSION]() {
    return this._version;
  }

  get [PRIVATE.BUILD]() {
    return this._build;
  }

  get [PRIVATE.INITIALIZED]() {
    return this._initialized;
  }

  get [PRIVATE.BASE_GENERATOR_READY]() {
    return this._baseGeneratorReady;
  }
}

// ============================================================
// 22. СОЗДАНИЕ ЭКЗЕМПЛЯРА
// ============================================================

let templateGeneratorCoreInstance = null;

function getTemplateGeneratorCoreInstance(options = {}) {
  if (!templateGeneratorCoreInstance) {
    templateGeneratorCoreInstance = new TemplateGeneratorCore(options);
    if (typeof window !== 'undefined') {
      window.__templateGeneratorCoreInstance = templateGeneratorCoreInstance;
    }
    if (typeof self !== 'undefined') {
      self.__templateGeneratorCore = templateGeneratorCoreInstance;
    }
  }
  return templateGeneratorCoreInstance;
}

// ============================================================
// 23. ЭКСПОРТ
// ============================================================

export default TemplateGeneratorCore;
export { TemplateGeneratorCore, getTemplateGeneratorCoreInstance, PRIVATE, PUBLIC, DEFAULT_CONFIG };

// ============================================================
// 24. ИНИЦИАЛИЗАЦИЯ ПРИ ЗАГРУЗКЕ
// ============================================================

if (typeof window !== 'undefined') {
  const core = getTemplateGeneratorCoreInstance({
    debug: true,
    version: '2.0.7',
    build: '2026-07-19',
  });

  console.log('╔═══════════════════════════════════════════════════════════════════════════════╗');
  console.log('║              📦 TEMPLATE GENERATOR CORE (100% СИМВОЛЫ)                      ║');
  console.log('╠═══════════════════════════════════════════════════════════════════════════════╣');
  console.log('║  📋 Все логи выводятся в консоль с цветовой разметкой                       ║');
  console.log('║  🔑 Полная изоляция через приватные символы                                 ║');
  console.log('║  📦 Генерация сжатых букмарклетов                                           ║');
  console.log('║  🚀 Встроенный минификатор (без внешних зависимостей)                       ║');
  console.log('║  ✅ Базовый генератор: встроенный с CALLBACK                                ║');
  console.log('║  📋 Шаблон букмарклета с callback по умолчанию                              ║');
  console.log('║  📊 Полная статистика работы                                                ║');
  console.log('╚═══════════════════════════════════════════════════════════════════════════════╝');

  console.log('📋 ДОСТУПНЫЕ КОМАНДЫ:');
  console.log('  __templateGeneratorCore.minify(code)              - минифицировать код');
  console.log('  __templateGeneratorCore.compress(code)            - сжать код для URL');
  console.log('  __templateGeneratorCore.generateTemplate()        - генерировать шаблон');
  console.log('  __templateGeneratorCore.generateCompressedTemplate() - сжатый шаблон');
  console.log('  __templateGeneratorCore.generateAllTemplates()    - все шаблоны');
  console.log('  __templateGeneratorCore.getTemplate(id)           - получить шаблон');
  console.log('  __templateGeneratorCore.getAllTemplates()         - все шаблоны');
  console.log('  __templateGeneratorCore.deleteTemplate(id)        - удалить шаблон');
  console.log('  __templateGeneratorCore.clearAll()                - очистить всё');
  console.log('  __templateGeneratorCore.getStats()                - статистика');
  console.log('  __templateGeneratorCore.getCodecStatus()          - статус кодека');
  console.log('  __templateGeneratorCore.getBaseGeneratorStatus()  - статус базового генератора');
  console.log('  __templateGeneratorCore.setDefaultCallback(cb)    - установить callback');
  console.log('  __templateGeneratorCore.getDefaultCallback()      - получить callback');
  console.log('  __templateGeneratorCore.exportToJSON()            - экспорт');
  console.log('  __templateGeneratorCore.importFromJSON(json)      - импорт');
  console.log('  __templateGeneratorCore.clearCache()              - очистить кеш');
  console.log('  __templateGeneratorCore.destroy()                 - уничтожить');
  console.log('  window.PRIVATE_SYMBOLS                           - приватные символы');
  console.log('  window.PUBLIC_SYMBOLS                            - публичные символы');
  console.log('');
  console.log('📋 ПРИВАТНЫХ СИМВОЛОВ:', Object.keys(PRIVATE).length);
  console.log('📋 ПУБЛИЧНЫХ СИМВОЛОВ:', Object.keys(PUBLIC).length);
}

// ============================================================
// 25. КОМАНДЫ ДЛЯ ОТЛАДКИ
// ============================================================

if (typeof window !== 'undefined') {
  window.__tgc = {
    instance: window.__templateGeneratorCoreInstance || window.__templateGeneratorCore,
    getStats: () => window.__templateGeneratorCoreInstance?.getStats?.(),
    getCodecStatus: () => window.__templateGeneratorCoreInstance?.getCodecStatus?.(),
    getBaseGeneratorStatus: () => window.__templateGeneratorCoreInstance?.getBaseGeneratorStatus?.(),
    minify: code => window.__templateGeneratorCoreInstance?.minify?.(code),
    compress: code => window.__templateGeneratorCoreInstance?.compress?.(code),
    generateAll: opts => window.__templateGeneratorCoreInstance?.generateAllTemplates?.(opts),
    clearAll: () => window.__templateGeneratorCoreInstance?.clearAll?.(),
    destroy: () => window.__templateGeneratorCoreInstance?.destroy?.(),
    setDefaultCallback: cb => window.__templateGeneratorCoreInstance?.setDefaultCallback?.(cb),
    getDefaultCallback: () => window.__templateGeneratorCoreInstance?.getDefaultCallback?.(),
    getSymbols: () => ({
      PRIVATE: { ...PRIVATE },
      PUBLIC: { ...PUBLIC },
    }),
  };

  console.log('📋 КОМАНДЫ ОТЛАДКИ (__tgc):');
  console.log('  __tgc.getStats()              - статистика');
  console.log('  __tgc.getCodecStatus()        - статус кодека');
  console.log('  __tgc.getBaseGeneratorStatus() - статус базового генератора');
  console.log('  __tgc.minify()                - минифицировать код');
  console.log('  __tgc.compress()              - сжать код');
  console.log('  __tgc.generateAll()           - все шаблоны');
  console.log('  __tgc.clearAll()              - очистить всё');
  console.log('  __tgc.destroy()               - уничтожить');
  console.log('  __tgc.setDefaultCallback()    - установить callback');
  console.log('  __tgc.getDefaultCallback()    - получить callback');
  console.log('  __tgc.getSymbols()            - получить символы');
}
