// web/Bookmarklet/extension/background.js - ИСПРАВЛЕННАЯ ВЕРСИЯ (100% СИМВОЛЫ)
// Версия: 2.0.11
// ИСПРАВЛЕНО: Ошибка "Cannot set property Symbol(updater.config) of #<BookmarkletUpdater> which has only a getter"
// ИСПРАВЛЕНО: Ошибка "this[Symbol(...)] is not a function"
// ИСПРАВЛЕНО: Дублирование таймеров при перезагрузке Service Worker
// ИСПРАВЛЕНО: Дублирование логов при загрузке закладок
// ИСПРАВЛЕНО: Добавлены await для асинхронной загрузки букмарклетов из Chrome

// ============================================================
// 1. ИМПОРТЫ
// ============================================================

import TemplateGeneratorCore from './template-generator-core.js';
import BookmarkletGenerator from './bookmarklet-generator.mjs';
import BookmarkletTemplateGenerator from './bookmarklet-template-generator.js';
import BookmarkletUpdater, { getBookmarkletUpdater } from './bookmarklet-updater.js';

// ============================================================
// 2. ПРОВЕРКА ОКРУЖЕНИЯ (Service Worker vs Browser)
// ============================================================

const isServiceWorker = typeof self !== 'undefined' && typeof importScripts !== 'undefined';
const isBrowser = typeof window !== 'undefined' && typeof document !== 'undefined';

// Безопасное получение localStorage
function getStorage() {
  if (isBrowser) {
    try {
      return window.localStorage;
    } catch (e) {
      return null;
    }
  }
  return null;
}

// Безопасное получение chrome.storage
function getChromeStorage() {
  try {
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      return chrome.storage.local;
    }
  } catch (e) {}
  return null;
}

// ============================================================
// 3. ПРИВАТНЫЕ СИМВОЛЫ (100% изоляция)
// ============================================================

const PRIVATE = {
  // Основные символы
  CONFIG: Symbol('bg.config'),
  LOGGER: Symbol('bg.logger'),
  STATE: Symbol('bg.state'),
  CACHE: Symbol('bg.cache'),
  VERSION: Symbol('bg.version'),
  BUILD: Symbol('bg.build'),
  INITIALIZED: Symbol('bg.initialized'),
  IS_RUNNING: Symbol('bg.isRunning'),
  IS_DESTROYED: Symbol('bg.isDestroyed'),
  EXPORTED: Symbol('bg.exported'),

  // Генераторы
  GENERATOR: Symbol('bg.generator'),
  GENERATOR_LOADED: Symbol('bg.generatorLoaded'),
  TEMPLATE_GENERATOR: Symbol('bg.templateGenerator'),
  TEMPLATE_GENERATOR_LOADED: Symbol('bg.templateGeneratorLoaded'),
  TEMPLATE_GENERATOR_LOADING: Symbol('bg.templateGeneratorLoading'),
  TEMPLATE_GENERATOR_ERROR: Symbol('bg.templateGeneratorError'),

  // Управление окном
  WINDOW_ID: Symbol('bg.windowId'),
  WINDOW_CREATED: Symbol('bg.windowCreated'),
  WINDOW_OPENING: Symbol('bg.windowOpening'),
  WINDOW_CONFIG: Symbol('bg.windowConfig'),

  // Данные
  BOOKMARKS: Symbol('bg.bookmarks'),
  BOOKMARKLETS: Symbol('bg.bookmarklets'),
  BOOKMARKLETS_LIST: Symbol('bg.bookmarkletsList'),
  FOLDERS: Symbol('bg.folders'),
  RESULTS: Symbol('bg.results'),
  LAST_UPDATE: Symbol('bg.lastUpdate'),
  IS_UPDATING: Symbol('bg.isUpdating'),

  // Состояние
  GLOBAL_STATE: Symbol('bg.globalState'),
  CHANNEL_MANAGER: Symbol('bg.channelManager'),
  DYNAMIC_CONFIG: Symbol('bg.dynamicConfig'),
  EXTENSION_STATE: Symbol('bg.extensionState'),
  LAST_SYNC: Symbol('bg.lastSync'),

  // Управление
  TIMERS: Symbol('bg.timers'),
  LISTENERS: Symbol('bg.listeners'),

  // Табы и UI
  TABS: Symbol('bg.tabs'),
  TAB_PANELS: Symbol('bg.tabPanels'),
  ACTIVE_TAB: Symbol('bg.activeTab'),
  TAB_HANDLERS: Symbol('bg.tabHandlers'),

  // Логирование URL
  BOOKMARK_URL_CACHE: Symbol('bg.bookmarkUrlCache'),
  URL_LOGGER: Symbol('bg.urlLogger'),
  DEBUG_BOOKMARKS: Symbol('bg.debugBookmarks'),

  // Обновлятор букмарклетов
  UPDATER: Symbol('bg.updater'),
  UPDATER_CONFIG: Symbol('bg.updaterConfig'),
  UPDATER_INITIALIZED: Symbol('bg.updaterInitialized'),
  AUTO_UPDATE_TIMER: Symbol('bg.autoUpdateTimer'),
  UPDATE_DATA: Symbol('bg.updateData'),
  UPDATE_CONFIG: Symbol('bg.updateConfig'),

  // Методы
  SETUP_TABS: Symbol('bg.setupTabs'),
  LOG_BOOKMARKLET_URLS: Symbol('bg.logBookmarkletUrls'),
  DEBUG_BOOKMARKLETS: Symbol('bg.debugBookmarklets'),
  UPDATE_TAB: Symbol('bg.updateTab'),
  GET_BOOKMARKLETS_WITH_URLS: Symbol('bg.getBookmarkletsWithUrls'),

  // Методы обновлятора
  LOAD_UPDATE_DATA: Symbol('bg.loadUpdateData'),
  LOAD_UPDATE_CONFIG: Symbol('bg.loadUpdateConfig'),
  SAVE_UPDATE_CONFIG: Symbol('bg.saveUpdateConfig'),
  CREATE_DEFAULT_UPDATE_DATA: Symbol('bg.createDefaultUpdateData'),
  CREATE_DEFAULT_UPDATE_CONFIG: Symbol('bg.createDefaultUpdateConfig'),
  SAVE_UPDATE_DATA: Symbol('bg.saveUpdateData'),
  RUN_UPDATE: Symbol('bg.runUpdate'),
  SAVE_UPDATE_RESULTS: Symbol('bg.saveUpdateResults'),
  START_AUTO_UPDATE: Symbol('bg.startAutoUpdate'),
  STOP_AUTO_UPDATE: Symbol('bg.stopAutoUpdate'),
  INIT_UPDATER: Symbol('bg.initUpdater'),
  SET_UPDATE_CONFIG: Symbol('bg.setUpdateConfig'),
  GET_UPDATE_CONFIG: Symbol('bg.getUpdateConfig'),
  UPDATE_FROM_CONFIG: Symbol('bg.updateFromConfig'),
  PARSE_CONFIG_TO_UPDATE_DATA: Symbol('bg.parseConfigToUpdateData'),
  SAFE_CALL_METHOD: Symbol('bg.safeCallMethod'),

  // ★★★ НОВЫЕ СИМВОЛЫ ДЛЯ АСИНХРОННОЙ ЗАГРУЗКИ ★★★
  LOAD_BOOKMARKLETS_FROM_CHROME: Symbol('bg.loadBookmarkletsFromChrome'),
  LOAD_BOOKMARKLETS_ASYNC: Symbol('bg.loadBookmarkletsAsync'),
};

// ============================================================
// 4. ПУБЛИЧНЫЕ СИМВОЛЫ (доступны через Symbol.for)
// ============================================================

const PUBLIC = {
  API: Symbol.for('background.api'),
  STATE: Symbol.for('background.state'),
  INSTANCE: Symbol.for('background.instance'),
  WINDOW: Symbol.for('background.window'),
  EVENTS: Symbol.for('background.events'),
  CONFIG: Symbol.for('background.config'),
  LOGGER: Symbol.for('background.logger'),
  GENERATOR: Symbol.for('background.generator'),
  TEMPLATE_GENERATOR: Symbol.for('background.templateGenerator'),
  BOOKMARKS: Symbol.for('background.bookmarks'),
  TABS: Symbol.for('background.tabs'),
  BOOKMARKLETS_DEBUG: Symbol.for('background.bookmarklets.debug'),
  UPDATER: Symbol.for('background.updater'),
  UPDATE_CONFIG: Symbol.for('background.updateConfig'),
};

// ============================================================
// 5. КОНФИГУРАЦИЯ
// ============================================================

const DEFAULT_DYNAMIC_CONFIG = {
  version: '2.0.11',
  build: '2026-07-22',
  debug: true,
  bookmarklet: {
    basePath: './Bookmarklet/',
    useUniversalLoader: true,
    updateBookmarkUrl: true,
    autoShow: true,
    fallbackEnabled: true,
    timeout: 5000,
    maxRetries: 3,
    retryDelay: 1000,
  },
  compression: {
    enabled: true,
    minify: true,
    removeComments: true,
    shortenVariables: true,
    compressBooleans: true,
    aggressiveCompression: true,
    maxUrlLength: 2000,
  },
  window: {
    width: 540,
    height: 660,
    type: 'popup',
    focused: true,
  },
  channel: {
    name: 'bookmarklet-channel',
    debug: true,
    timeout: 5000,
  },
  panel: {
    defaultWidth: 420,
    defaultHeight: 520,
    defaultPosition: { x: 20, y: 20 },
    minWidth: 320,
    minHeight: 300,
    zIndex: 99996,
  },
  tabs: {
    defaultTab: 'logs',
    tabNames: ['settings', 'bookmarks', 'logs', 'info', 'bookmarklets'],
  },
  updater: {
    enabled: true,
    autoUpdate: true,
    updateInterval: 60000,
    generateNewCode: true,
    updateOnlyChanged: true,
    batchSize: 10,
    delayBetween: 500,
  },
};

// ============================================================
// 6. ДЕФОЛТНЫЙ КОНФИГ ОБНОВЛЕНИЙ
// ============================================================

const DEFAULT_UPDATE_CONFIG = {
  bookmarklets: {},
  defaults: {
    type: 'main',
  },
};

// ============================================================
// 7. ЛОГГЕР С ПРИВЯЗКОЙ КОНТЕКСТА (100% СИМВОЛЫ)
// ============================================================

const LOGGER_SYMBOLS = {
  HISTORY: Symbol('logger.history'),
  MAX_HISTORY: Symbol('logger.maxHistory'),
  DEBUG: Symbol('logger.debug'),
  INSTANCE_ID: Symbol('logger.instanceId'),
};

function createLogger(debug = true, instanceId = 'Background') {
  const state = {
    [LOGGER_SYMBOLS.HISTORY]: [],
    [LOGGER_SYMBOLS.MAX_HISTORY]: 200,
    [LOGGER_SYMBOLS.DEBUG]: debug,
    [LOGGER_SYMBOLS.INSTANCE_ID]: instanceId,
  };

  const logMethod = function (level, message, data = null) {
    if (!this[LOGGER_SYMBOLS.DEBUG] && level !== 'error') {
      return;
    }

    const timestamp = new Date().toISOString().slice(11, 23);
    const prefix = `[${timestamp}] [${this[LOGGER_SYMBOLS.INSTANCE_ID]}]`;

    this[LOGGER_SYMBOLS.HISTORY].push({ timestamp, level, message, data });
    if (this[LOGGER_SYMBOLS.HISTORY].length > this[LOGGER_SYMBOLS.MAX_HISTORY]) {
      this[LOGGER_SYMBOLS.HISTORY].shift();
    }

    if (data !== null && data !== undefined) {
      console.log(`${prefix} ${message}`, data);
    } else {
      console.log(`${prefix} ${message}`);
    }
  };

  const boundLog = logMethod.bind(state);

  const methods = {
    error: function (msg, d) {
      boundLog('error', `❌ ${msg}`, d);
    },
    warn: function (msg, d) {
      boundLog('warn', `⚠️ ${msg}`, d);
    },
    info: function (msg, d) {
      boundLog('info', `ℹ️ ${msg}`, d);
    },
    debug: function (msg, d) {
      boundLog('debug', `🔍 ${msg}`, d);
    },
    success: function (msg, d) {
      boundLog('info', `✅ ${msg}`, d);
    },

    header: function (title) {
      console.log('%c' + '═'.repeat(70), 'color: #636e72;');
      console.log(
        '%c  🚀 ' + title,
        'background: #1a1a2e; color: #fff; padding: 4px 12px; border-radius: 4px; font-weight: bold;'
      );
      console.log('%c' + '═'.repeat(70), 'color: #636e72;');
    },

    separator: function () {
      console.log('%c' + '─'.repeat(70), 'color: #636e72;');
    },

    symbol: function (name, symbol) {
      console.log(`  🔑 ${name}: ${String(symbol)}`);
    },

    private: function (name, symbol) {
      console.log(`  🔒 ${name}: ${String(symbol)}`);
    },

    getHistory: function () {
      return [...this[LOGGER_SYMBOLS.HISTORY]];
    },

    clearHistory: function () {
      this[LOGGER_SYMBOLS.HISTORY] = [];
      return this;
    },

    setDebug: function (enabled) {
      this[LOGGER_SYMBOLS.DEBUG] = enabled;
      return this;
    },
  };

  const logger = {};
  for (const [key, fn] of Object.entries(methods)) {
    logger[key] = fn.bind(state);
  }

  logger[LOGGER_SYMBOLS.HISTORY] = state[LOGGER_SYMBOLS.HISTORY];
  logger[LOGGER_SYMBOLS.MAX_HISTORY] = state[LOGGER_SYMBOLS.MAX_HISTORY];
  logger[LOGGER_SYMBOLS.DEBUG] = state[LOGGER_SYMBOLS.DEBUG];
  logger[LOGGER_SYMBOLS.INSTANCE_ID] = state[LOGGER_SYMBOLS.INSTANCE_ID];

  return logger;
}

// ============================================================
// 8. УТИЛИТЫ ДЛЯ РАБОТЫ С ХРАНИЛИЩЕМ (ИСПРАВЛЕНО)
// ============================================================

// Безопасное сохранение в storage
function safeStorageSet(key, value) {
  try {
    // Пробуем chrome.storage
    const chromeStorage = getChromeStorage();
    if (chromeStorage) {
      chromeStorage.set({ [key]: value }, () => {
        if (chrome.runtime.lastError) {
          // Игнорируем ошибки chrome.storage
        }
      });
      return true;
    }

    // Пробуем localStorage
    const storage = getStorage();
    if (storage) {
      storage.setItem(key, typeof value === 'string' ? value : JSON.stringify(value));
      return true;
    }
  } catch (e) {
    // Игнорируем ошибки
  }
  return false;
}

// Безопасное получение из storage
function safeStorageGet(key) {
  try {
    // Пробуем chrome.storage (синхронно через localStorage как fallback)
    const storage = getStorage();
    if (storage) {
      const value = storage.getItem(key);
      if (value) {
        try {
          return JSON.parse(value);
        } catch {
          return value;
        }
      }
    }
  } catch (e) {
    // Игнорируем ошибки
  }
  return null;
}

// ============================================================
// 9. ОСНОВНОЙ КЛАСС BACKGROUND SERVICE (100% СИМВОЛЫ)
// ============================================================

class BackgroundService {
  constructor(options = {}) {
    // ============================================================
    // 9.1 ИНИЦИАЛИЗАЦИЯ
    // ============================================================

    const debug = options.debug !== false;

    const logger = createLogger(debug, 'Background');
    this[PRIVATE.LOGGER] = logger;

    logger.header('СОЗДАНИЕ BACKGROUND SERVICE (100% СИМВОЛЫ)');
    logger.info(
      `📌 Окружение: ${isServiceWorker ? 'Service Worker' : isBrowser ? 'Browser' : 'Unknown'}`
    );

    this[PRIVATE.VERSION] = options.version || DEFAULT_DYNAMIC_CONFIG.version;
    this[PRIVATE.BUILD] = options.build || DEFAULT_DYNAMIC_CONFIG.build;
    this[PRIVATE.DYNAMIC_CONFIG] = { ...DEFAULT_DYNAMIC_CONFIG, ...options.dynamicConfig };
    this[PRIVATE.WINDOW_CONFIG] = this[PRIVATE.DYNAMIC_CONFIG].window || {
      width: 540,
      height: 660,
    };

    this[PRIVATE.INITIALIZED] = false;
    this[PRIVATE.IS_RUNNING] = false;
    this[PRIVATE.IS_DESTROYED] = false;
    this[PRIVATE.EXPORTED] = false;

    this[PRIVATE.CACHE] = new Map();
    this[PRIVATE.BOOKMARKS] = [];
    this[PRIVATE.BOOKMARKLETS] = [];
    this[PRIVATE.BOOKMARKLETS_LIST] = [];
    this[PRIVATE.FOLDERS] = [];
    this[PRIVATE.RESULTS] = null;
    this[PRIVATE.LAST_UPDATE] = null;
    this[PRIVATE.IS_UPDATING] = false;
    this[PRIVATE.TIMERS] = new Map();
    this[PRIVATE.LISTENERS] = new Map();
    this[PRIVATE.BOOKMARK_URL_CACHE] = new Map();

    this[PRIVATE.TABS] = new Map();
    this[PRIVATE.TAB_PANELS] = new Map();
    this[PRIVATE.ACTIVE_TAB] = this[PRIVATE.DYNAMIC_CONFIG].tabs.defaultTab || 'logs';
    this[PRIVATE.TAB_HANDLERS] = new Map();

    // Обновлятор
    this[PRIVATE.UPDATER] = null;
    this[PRIVATE.UPDATER_CONFIG] = {
      enabled: this[PRIVATE.DYNAMIC_CONFIG].updater.enabled,
      autoUpdate: this[PRIVATE.DYNAMIC_CONFIG].updater.autoUpdate,
      updateInterval: this[PRIVATE.DYNAMIC_CONFIG].updater.updateInterval || 60000,
      lastUpdate: null,
      lastResults: null,
    };
    this[PRIVATE.UPDATER_INITIALIZED] = false;
    this[PRIVATE.AUTO_UPDATE_TIMER] = null;
    this[PRIVATE.UPDATE_DATA] = {};
    this[PRIVATE.UPDATE_CONFIG] = { ...DEFAULT_UPDATE_CONFIG };

    this[PRIVATE.WINDOW_ID] = null;
    this[PRIVATE.WINDOW_CREATED] = false;
    this[PRIVATE.WINDOW_OPENING] = false;

    // ============================================================
    // 9.2 ОПРЕДЕЛЯЕМ ВСЕ МЕТОДЫ
    // ============================================================

    // --- ОСНОВНОЙ _init ---
    this._init = () => {
      logger.info('🔧 Инициализация...');

      this._setupActionHandler();
      this._loadBookmarks();

      // ★★★ ИНИЦИАЛИЗАЦИЯ ОБНОВЛЯТОРА (ИСПРАВЛЕНО) ★★★
      this[PRIVATE.INIT_UPDATER]();

      this._setupTimers();

      this[PRIVATE.GLOBAL_STATE] = {
        version: this[PRIVATE.VERSION],
        getState: () => ({
          version: this[PRIVATE.VERSION],
          position: { x: 20, y: 20 },
          size: { width: 420, height: 520 },
          zIndex: 99996,
        }),
      };

      this[PRIVATE.CHANNEL_MANAGER] = {
        name: this[PRIVATE.DYNAMIC_CONFIG].channel.name,
        send: data => data,
        on: () => () => {},
      };

      this[PRIVATE.EXTENSION_STATE] = {
        isActive: true,
        lastPing: Date.now(),
        connectedClients: 0,
        errors: [],
        lastError: null,
      };

      this[PRIVATE.SETUP_TABS]();

      this[PRIVATE.INITIALIZED] = true;
      logger.success('✅ Инициализация завершена');
    };

    // --- ИНИЦИАЛИЗАЦИЯ ОБНОВЛЯТОРА (ИСПРАВЛЕНО) ---
    this[PRIVATE.INIT_UPDATER] = () => {
      logger.info('📦 Инициализация обновлятора букмарклетов...');

      try {
        // Загружаем конфиг обновлений (безопасно)
        const config = this[PRIVATE.LOAD_UPDATE_CONFIG]();
        const updateData = this[PRIVATE.PARSE_CONFIG_TO_UPDATE_DATA](config);

        // Сохраняем данные
        this[PRIVATE.UPDATE_DATA] = updateData;
        this[PRIVATE.UPDATE_CONFIG] = config;

        // ★★★ ИСПРАВЛЕНИЕ: Создаем экземпляр напрямую ★★★
        const updater = new BookmarkletUpdater({
          debug: this[PRIVATE.DYNAMIC_CONFIG].debug,
          version: this[PRIVATE.VERSION],
          autoUpdate: this[PRIVATE.UPDATER_CONFIG].autoUpdate,
          updateInterval: this[PRIVATE.UPDATER_CONFIG].updateInterval,
          generateNewCode: true,
          updateOnlyChanged: true,
          batchSize: this[PRIVATE.DYNAMIC_CONFIG].updater.batchSize || 10,
          delayBetween: this[PRIVATE.DYNAMIC_CONFIG].updater.delayBetween || 500,
          initialData: updateData,
        });

        // Сохраняем экземпляр
        this[PRIVATE.UPDATER] = updater;

        // ★★★ ИСПРАВЛЕНИЕ: безопасный вызов методов ★★★
        this[PRIVATE.SAFE_CALL_METHOD](updater, 'initialize', this[PRIVATE.GENERATOR], this);
        this[PRIVATE.SAFE_CALL_METHOD](updater, 'setUpdateConfig', config);

        this[PRIVATE.UPDATER_INITIALIZED] = true;

        logger.success('✅ Обновлятор инициализирован');
        logger.info(`📦 Данных для обновления: ${Object.keys(updateData).length} записей`);
      } catch (error) {
        logger.error('❌ Ошибка инициализации обновлятора:', error.message);
        logger.debug('  Stack:', error.stack);
        this[PRIVATE.UPDATER_INITIALIZED] = false;
      }
    };

    // --- БЕЗОПАСНЫЙ ВЫЗОВ МЕТОДА (НОВЫЙ СИМВОЛ) ---
    this[PRIVATE.SAFE_CALL_METHOD] = (obj, methodName, ...args) => {
      if (obj && typeof obj === 'object' && typeof obj[methodName] === 'function') {
        try {
          return obj[methodName](...args);
        } catch (error) {
          logger.warn(`⚠️ Ошибка вызова ${methodName}:`, error.message);
          return null;
        }
      }
      return null;
    };

    // --- ПАРСИНГ КОНФИГА В ДАННЫЕ ---
    this[PRIVATE.PARSE_CONFIG_TO_UPDATE_DATA] = config => {
      const logger = this[PRIVATE.LOGGER];
      const updateData = {};

      if (!config || typeof config !== 'object') {
        logger.warn('⚠️ Конфиг пуст или не является объектом');
        return updateData;
      }

      const defaults = config.defaults || { type: 'main' };
      const bookmarklets = config.bookmarklets || config;

      for (const [id, data] of Object.entries(bookmarklets)) {
        if (id === 'defaults') continue;

        updateData[id] = {
          title: data.title || data.name || 'Bookmarklet',
          url: data.url || data.code || null,
          type: data.type || defaults.type || 'main',
          description: data.description || '',
          preserveTitle: data.preserveTitle || false,
        };
      }

      logger.info(`📦 Распарсено ${Object.keys(updateData).length} записей из конфига`);
      return updateData;
    };

    // --- ЗАГРУЗКА КОНФИГА ОБНОВЛЕНИЙ (ИСПРАВЛЕНО) ---
    this[PRIVATE.LOAD_UPDATE_CONFIG] = () => {
      const logger = this[PRIVATE.LOGGER];

      try {
        // Пробуем загрузить из localStorage (через безопасную функцию)
        const saved = safeStorageGet('bookmarklet-update-config');
        if (saved) {
          const config = typeof saved === 'string' ? JSON.parse(saved) : saved;
          this[PRIVATE.UPDATE_CONFIG] = config;
          const count = Object.keys(config.bookmarklets || config).length;
          logger.info(`📦 Загружен конфиг обновлений (${count} записей)`);
          return config;
        }

        // Пробуем загрузить из chrome.storage
        const chromeStorage = getChromeStorage();
        if (chromeStorage) {
          // В Service Worker используем синхронный доступ через localStorage
          // В браузере можно использовать async, но для простоты используем localStorage
          const savedFromStorage = safeStorageGet('bookmarklet-update-config');
          if (savedFromStorage) {
            const config =
              typeof savedFromStorage === 'string'
                ? JSON.parse(savedFromStorage)
                : savedFromStorage;
            this[PRIVATE.UPDATE_CONFIG] = config;
            const count = Object.keys(config.bookmarklets || config).length;
            logger.info(`📦 Загружен конфиг обновлений из chrome.storage (${count} записей)`);
            return config;
          }
        }

        // Создаем дефолтный конфиг
        const config = this[PRIVATE.CREATE_DEFAULT_UPDATE_CONFIG]();
        logger.info('📦 Создан дефолтный конфиг обновлений');
        return config;
      } catch (error) {
        logger.error('❌ Ошибка загрузки конфига:', error.message);
        return this[PRIVATE.CREATE_DEFAULT_UPDATE_CONFIG]();
      }
    };

    // --- СОЗДАНИЕ ДЕФОЛТНОГО КОНФИГА ---
    this[PRIVATE.CREATE_DEFAULT_UPDATE_CONFIG] = () => {
      const config = JSON.parse(JSON.stringify(DEFAULT_UPDATE_CONFIG));
      this[PRIVATE.UPDATE_CONFIG] = config;
      this[PRIVATE.SAVE_UPDATE_CONFIG](config);
      return config;
    };

    // --- СОХРАНЕНИЕ КОНФИГА ОБНОВЛЕНИЙ (ИСПРАВЛЕНО) ---
    this[PRIVATE.SAVE_UPDATE_CONFIG] = config => {
      try {
        // Сохраняем в localStorage
        safeStorageSet('bookmarklet-update-config', config);
        this[PRIVATE.UPDATE_CONFIG] = config;
      } catch (error) {
        // Игнорируем ошибки
      }
    };

    // --- УСТАНОВКА КОНФИГА ОБНОВЛЕНИЙ ---
    this[PRIVATE.SET_UPDATE_CONFIG] = config => {
      const logger = this[PRIVATE.LOGGER];

      if (!config || typeof config !== 'object') {
        logger.error('❌ Неверный формат конфига');
        return false;
      }

      // Сохраняем конфиг
      this[PRIVATE.SAVE_UPDATE_CONFIG](config);

      // Парсим и обновляем данные
      const updateData = this[PRIVATE.PARSE_CONFIG_TO_UPDATE_DATA](config);
      this[PRIVATE.UPDATE_DATA] = updateData;
      this[PRIVATE.SAVE_UPDATE_DATA]();

      const updater = this[PRIVATE.UPDATER];
      if (updater) {
        this[PRIVATE.SAFE_CALL_METHOD](updater, 'setUpdateConfig', config);
        this[PRIVATE.SAFE_CALL_METHOD](updater, 'setData', updateData);
      }

      // Запускаем обновление
      setTimeout(() => {
        this[PRIVATE.RUN_UPDATE]();
      }, 500);

      logger.info(`✅ Конфиг обновлений установлен (${Object.keys(updateData).length} записей)`);
      return true;
    };

    // --- ПОЛУЧЕНИЕ КОНФИГА ОБНОВЛЕНИЙ ---
    this[PRIVATE.GET_UPDATE_CONFIG] = () => {
      return this[PRIVATE.UPDATE_CONFIG] || null;
    };

    // --- ОБНОВЛЕНИЕ С КОНФИГОМ ---
    this[PRIVATE.UPDATE_FROM_CONFIG] = async config => {
      if (config) {
        this[PRIVATE.SET_UPDATE_CONFIG](config);
      }
      return this[PRIVATE.RUN_UPDATE]();
    };

    // --- ЗАГРУЗКА ДАННЫХ ОБНОВЛЕНИЙ ---
    this[PRIVATE.LOAD_UPDATE_DATA] = () => {
      const logger = this[PRIVATE.LOGGER];

      try {
        const saved = safeStorageGet('bookmarklet-update-data');
        if (saved) {
          const data = typeof saved === 'string' ? JSON.parse(saved) : saved;
          this[PRIVATE.UPDATE_DATA] = data;
          logger.info(`📦 Загружены данные обновлений (${Object.keys(data).length} записей)`);
          return;
        }

        this[PRIVATE.CREATE_DEFAULT_UPDATE_DATA]();
      } catch (error) {
        logger.error('❌ Ошибка загрузки данных:', error.message);
        this[PRIVATE.CREATE_DEFAULT_UPDATE_DATA]();
      }
    };

    // --- СОЗДАНИЕ ДЕФОЛТНЫХ ДАННЫХ ---
    this[PRIVATE.CREATE_DEFAULT_UPDATE_DATA] = () => {
      const logger = this[PRIVATE.LOGGER];
      this[PRIVATE.UPDATE_DATA] = {};
      this[PRIVATE.SAVE_UPDATE_DATA]();
      logger.info('📦 Созданы дефолтные данные обновлений');
    };

    // --- СОХРАНЕНИЕ ДАННЫХ ОБНОВЛЕНИЙ ---
    this[PRIVATE.SAVE_UPDATE_DATA] = () => {
      try {
        safeStorageSet('bookmarklet-update-data', this[PRIVATE.UPDATE_DATA]);
      } catch (error) {}
    };

    // --- ★★★ ЗАГРУЗКА БУКМАРКЛЕТОВ ИЗ CHROME (С АСИНХРОННЫМ ОЖИДАНИЕМ) ★★★ ---
    this[PRIVATE.LOAD_BOOKMARKLETS_FROM_CHROME] = () => {
      const logger = this[PRIVATE.LOGGER];
      logger.info('📑 Загрузка букмарклетов из Chrome...');

      return new Promise(resolve => {
        if (typeof chrome === 'undefined' || !chrome.bookmarks) {
          logger.warn('⚠️ Chrome bookmarks API не доступен');
          this[PRIVATE.BOOKMARKLETS] = [];
          resolve([]);
          return;
        }

        try {
          chrome.bookmarks.getTree(tree => {
            if (chrome.runtime.lastError) {
              logger.error('❌ Ошибка получения закладок:', chrome.runtime.lastError.message);
              this[PRIVATE.BOOKMARKLETS] = [];
              resolve([]);
              return;
            }

            const bookmarklets = [];

            function traverse(node, path = '') {
              if (node.url && node.url.startsWith('javascript:')) {
                bookmarklets.push({
                  id: node.id,
                  title: node.title || 'Без названия',
                  url: node.url,
                  path: path || 'Корень',
                  parentId: node.parentId,
                  isBookmarklet: true,
                  type: 'bookmarklet',
                  size: node.url ? node.url.length : 0,
                });
              }

              if (node.children) {
                const currentPath = path
                  ? `${path} > ${node.title || 'Корень'}`
                  : node.title || 'Корень';
                for (const child of node.children) {
                  traverse(child, currentPath);
                }
              }
            }

            for (const root of tree) {
              traverse(root, '');
            }

            this[PRIVATE.BOOKMARKLETS] = bookmarklets;
            this[PRIVATE.BOOKMARKLETS_LIST] = bookmarklets;

            logger.info(`📦 Загружено ${bookmarklets.length} букмарклетов из Chrome`);

            if (bookmarklets.length > 0) {
              logger.debug('📋 Найденные букмарклеты:');
              bookmarklets.forEach((bm, index) => {
                logger.debug(`   ${index + 1}. ${bm.title} (${bm.id})`);
              });
            }

            resolve(bookmarklets);
          });
        } catch (error) {
          logger.error('❌ Ошибка загрузки букмарклетов:', error.message);
          this[PRIVATE.BOOKMARKLETS] = [];
          resolve([]);
        }
      });
    };

    // --- ЗАПУСК ОБНОВЛЕНИЯ (С АСИНХРОННЫМ ОЖИДАНИЕМ) ---
    this[PRIVATE.RUN_UPDATE] = async () => {
      const logger = this[PRIVATE.LOGGER];
      const updater = this[PRIVATE.UPDATER];

      if (!updater) {
        logger.warn('⚠️ Обновлятор не инициализирован');
        return;
      }

      // ★★★ ИСПРАВЛЕНО: АСИНХРОННАЯ ЗАГРУЗКА БУКМАРКЛЕТОВ ★★★
      await this[PRIVATE.LOAD_BOOKMARKLETS_FROM_CHROME]();

      const updateData = this[PRIVATE.UPDATE_DATA] || {};

      if (!updateData || Object.keys(updateData).length === 0) {
        logger.info('ℹ️ Нет данных для обновления букмарклетов');
        return;
      }

      try {
        logger.header('🔄 ЗАПУСК ОБНОВЛЕНИЯ БУКМАРКЛЕТОВ');

        const generator = this[PRIVATE.GENERATOR];
        if (!generator) {
          logger.error('❌ Генератор не инициализирован');
          return;
        }

        const updateItems = Object.entries(updateData).map(([id, data]) => ({
          id: id,
          title: data.title || 'Bookmarklet',
          newTitle: data.title || 'Bookmarklet',
          newCode: data.url || null,
          type: data.type || 'main',
        }));

        logger.info(`📦 Найдено ${updateItems.length} букмарклетов для обновления`);

        // ★★★ ИСПРАВЛЕНИЕ: безопасный вызов updater.update ★★★
        let results;
        if (typeof updater.update === 'function') {
          results = await updater.update(updateItems);
        } else if (typeof updater.run === 'function') {
          results = await updater.run(updateItems);
        } else {
          throw new Error('Метод update не найден в обновляторе');
        }

        this[PRIVATE.UPDATER_CONFIG].lastUpdate = Date.now();
        this[PRIVATE.UPDATER_CONFIG].lastResults = results;

        this[PRIVATE.SAVE_UPDATE_RESULTS](results);

        logger.success(
          `✅ Обновление завершено: ${results.stats.updated} обновлено, ${results.stats.skipped} пропущено, ${results.stats.failed} ошибок`
        );
        logger.header('ГОТОВ');
      } catch (error) {
        logger.error('❌ Ошибка обновления:', error.message);
      }
    };

    // --- СОХРАНЕНИЕ РЕЗУЛЬТАТОВ ---
    this[PRIVATE.SAVE_UPDATE_RESULTS] = results => {
      try {
        const data = {
          timestamp: new Date().toISOString(),
          results: results,
          config: this[PRIVATE.UPDATER_CONFIG],
        };
        safeStorageSet('bookmarklet-update-results', data);
      } catch (error) {}
    };

    // --- ЗАПУСК АВТО-ОБНОВЛЕНИЯ (ИСПРАВЛЕНО) ---
    this[PRIVATE.START_AUTO_UPDATE] = () => {
      const logger = this[PRIVATE.LOGGER];

      // ★★★ ОЧИЩАЕМ СТАРЫЙ ТАЙМЕР ★★★
      if (this[PRIVATE.AUTO_UPDATE_TIMER]) {
        clearInterval(this[PRIVATE.AUTO_UPDATE_TIMER]);
        this[PRIVATE.AUTO_UPDATE_TIMER] = null;
      }

      const interval = this[PRIVATE.UPDATER_CONFIG].updateInterval || 60000;

      this[PRIVATE.AUTO_UPDATE_TIMER] = setInterval(async () => {
        if (this[PRIVATE.INITIALIZED] && !this[PRIVATE.IS_RUNNING]) {
          // ★★★ ИСПРАВЛЕНО: загружаем актуальные букмарклеты перед обновлением ★★★
          await this[PRIVATE.LOAD_BOOKMARKLETS_FROM_CHROME]();
          this[PRIVATE.RUN_UPDATE]();
        }
      }, interval);

      logger.info(`✅ Авто-обновление запущено (интервал: ${interval}ms)`);
    };

    // --- ОСТАНОВКА АВТО-ОБНОВЛЕНИЯ ---
    this[PRIVATE.STOP_AUTO_UPDATE] = () => {
      if (this[PRIVATE.AUTO_UPDATE_TIMER]) {
        clearInterval(this[PRIVATE.AUTO_UPDATE_TIMER]);
        this[PRIVATE.AUTO_UPDATE_TIMER] = null;
        const logger = this[PRIVATE.LOGGER];
        logger.info('⏹️ Авто-обновление остановлено');
      }
    };

    // --- НАСТРОЙКА ТАБОВ ---
    this[PRIVATE.SETUP_TABS] = () => {
      logger.info('🔧 Настройка табов...');

      const tabNames = this[PRIVATE.DYNAMIC_CONFIG].tabs.tabNames || [
        'settings',
        'bookmarks',
        'logs',
        'info',
        'bookmarklets',
      ];

      tabNames.forEach(name => {
        this[PRIVATE.TABS].set(name, {
          id: name,
          label: this._getTabLabel(name),
          active: name === this[PRIVATE.ACTIVE_TAB],
          panelId: `tab-${name}`,
        });
      });

      logger.success(`✅ Настроено ${this[PRIVATE.TABS].size} табов`);
    };

    // --- ПОЛУЧЕНИЕ ЛЕЙБЛА ТАБА ---
    this._getTabLabel = tabName => {
      const labels = {
        settings: '⚙️ Настройки',
        bookmarks: '📑 Закладки',
        logs: '📋 Логи',
        info: 'ℹ️ Инфо',
        bookmarklets: '📌 Букмарклеты',
      };
      return labels[tabName] || tabName;
    };

    // --- ОБРАБОТЧИК ДЕЙСТВИЙ ---
    this._setupActionHandler = () => {
      logger.info('🔧 Настройка обработчика действий...');

      try {
        if (typeof chrome !== 'undefined' && chrome.action) {
          chrome.action.onClicked.addListener(async tab => {
            logger.info('🖱️ Клик по иконке расширения');

            if (this[PRIVATE.WINDOW_CREATED] && this[PRIVATE.WINDOW_ID]) {
              try {
                await chrome.windows.update(this[PRIVATE.WINDOW_ID], { focused: true });
                logger.info('✅ Окно уже открыто');
                return;
              } catch (error) {
                logger.warn('⚠️ Окно закрыто');
                this[PRIVATE.WINDOW_CREATED] = false;
                this[PRIVATE.WINDOW_ID] = null;
              }
            }

            await this._openExtensionWindow();
          });
          logger.success('✅ Обработчик клика по иконке настроен');
        } else {
          logger.warn('⚠️ Chrome action API не доступен');
        }
      } catch (error) {
        logger.error('❌ Ошибка настройки обработчика:', error.message);
      }
    };

    // --- ОТКРЫТИЕ ОКНА ---
    this._openExtensionWindow = async () => {
      if (this[PRIVATE.WINDOW_OPENING]) return;
      this[PRIVATE.WINDOW_OPENING] = true;

      try {
        const config = this[PRIVATE.WINDOW_CONFIG];
        const popupUrl = chrome.runtime.getURL('popup.html');

        const window = await chrome.windows.create({
          url: popupUrl,
          type: config.type || 'popup',
          width: config.width || 540,
          height: config.height || 660,
          focused: config.focused !== false,
        });

        this[PRIVATE.WINDOW_ID] = window.id;
        this[PRIVATE.WINDOW_CREATED] = true;

        logger.success(`✅ Окно создано (ID: ${window.id})`);

        chrome.windows.onRemoved.addListener(windowId => {
          if (windowId === this[PRIVATE.WINDOW_ID]) {
            this[PRIVATE.WINDOW_CREATED] = false;
            this[PRIVATE.WINDOW_ID] = null;
          }
        });

        return window;
      } catch (error) {
        logger.error('❌ Ошибка создания окна:', error.message);
        try {
          const tab = await chrome.tabs.create({
            url: chrome.runtime.getURL('popup.html'),
            active: true,
          });
          logger.success(`✅ Вкладка создана (ID: ${tab.id})`);
          return { tab };
        } catch (fallbackError) {
          logger.error('❌ Fallback не сработал:', fallbackError.message);
          return null;
        }
      } finally {
        this[PRIVATE.WINDOW_OPENING] = false;
      }
    };

    // --- ЗАГРУЗКА ЗАКЛАДОК (ИСПРАВЛЕНО) ---
    this._loadBookmarks = () => {
      logger.info('📑 Загрузка закладок...');

      if (typeof chrome !== 'undefined' && chrome.bookmarks) {
        try {
          chrome.bookmarks.getTree(tree => {
            if (!chrome.runtime.lastError) {
              const bookmarks = [];
              const traverse = (node, path = '') => {
                if (node.url) {
                  const isBookmarklet = node.url && node.url.startsWith('javascript:');
                  bookmarks.push({
                    id: node.id,
                    title: node.title || 'Без названия',
                    url: node.url,
                    path: path || 'Корень',
                    parentId: node.parentId,
                    isBookmarklet: isBookmarklet,
                    type: isBookmarklet ? 'bookmarklet' : 'url',
                    size: node.url ? node.url.length : 0,
                  });

                  if (isBookmarklet) {
                    this[PRIVATE.LOG_BOOKMARKLET_URLS](node);
                  }
                }
                if (node.children) {
                  const currentPath = path ? `${path} > ${node.title}` : node.title || 'Корень';
                  for (const child of node.children) {
                    traverse(child, currentPath);
                  }
                }
              };
              for (const root of tree) {
                traverse(root, '');
              }
              this[PRIVATE.BOOKMARKS] = bookmarks;
              this[PRIVATE.BOOKMARKLETS] = bookmarks.filter(
                b => b.url && b.url.startsWith('javascript:')
              );
              this[PRIVATE.BOOKMARKLETS_LIST] = this[PRIVATE.BOOKMARKLETS];
              this[PRIVATE.FOLDERS] = bookmarks.filter(b => !b.url);

              logger.info(
                `📦 Загружено ${bookmarks.length} закладок, ${this[PRIVATE.BOOKMARKLETS].length} букмарклетов`
              );
            } else {
              logger.warn('⚠️ Ошибка загрузки закладок:', chrome.runtime.lastError);
            }
          });
        } catch (error) {
          logger.error('❌ Ошибка загрузки закладок:', error.message);
        }
      } else {
        logger.warn('⚠️ Chrome bookmarks API не доступен');
      }
    };

    // --- ЛОГИРОВАНИЕ URL БУКМАРКЛЕТОВ ---
    this[PRIVATE.LOG_BOOKMARKLET_URLS] = bookmark => {
      const logger = this[PRIVATE.LOGGER];
      if (!bookmark || !bookmark.url || !bookmark.url.startsWith('javascript:')) {
        return;
      }

      const code = bookmark.url.replace('javascript:', '');
      logger.debug(`📌 Букмарклет: ${bookmark.title}`);
      logger.debug(`   ID: ${bookmark.id}`);
      logger.debug(`   📏 Длина URL: ${bookmark.url.length}`);
      logger.debug(`   📄 Код (первые 200 символов):`);
      logger.debug(`   ${code.substring(0, 200)}${code.length > 200 ? '...' : ''}`);

      if (code.includes('./Bookmarklet/')) {
        logger.debug(`   ✅ Использует относительные пути: ./Bookmarklet/`);
      } else if (code.includes('http://localhost')) {
        logger.debug(`   🔗 Использует абсолютные пути (localhost)`);
      } else if (code.includes('https://')) {
        logger.debug(`   🔗 Использует абсолютные пути (https)`);
      }

      this[PRIVATE.BOOKMARK_URL_CACHE].set(bookmark.id, {
        title: bookmark.title,
        url: bookmark.url,
        code: code,
        length: bookmark.url.length,
        timestamp: Date.now(),
      });
    };

    // --- ДЕБАГ БУКМАРКЛЕТОВ ---
    this[PRIVATE.DEBUG_BOOKMARKLETS] = () => {
      const logger = this[PRIVATE.LOGGER];
      const bookmarklets = this[PRIVATE.BOOKMARKLETS];

      logger.separator();
      logger.header('🔍 ДЕБАГ БУКМАРКЛЕТОВ');

      if (bookmarklets.length === 0) {
        logger.warn('⚠️ Букмарклеты не найдены');
        logger.separator();
        return;
      }

      logger.info(`📦 Найдено букмарклетов: ${bookmarklets.length}`);
      logger.separator();

      bookmarklets.forEach((bm, index) => {
        const code = bm.url.replace('javascript:', '');
        logger.info(`📌 [${index + 1}] ${bm.title}`);
        logger.info(`   ID: ${bm.id}`);
        logger.info(`   Путь: ${bm.path || 'корень'}`);
        logger.info(`   📏 Длина URL: ${bm.url.length}`);
        logger.info(`   📄 Код (первые 150 символов):`);
        logger.info(`   ${code.substring(0, 150)}${code.length > 150 ? '...' : ''}`);

        if (code.includes('./Bookmarklet/')) {
          logger.info(`   ✅ Относительные пути: ./Bookmarklet/`);
        } else if (code.includes('http://localhost')) {
          logger.info(`   🔗 Абсолютные пути (localhost)`);
        } else if (code.includes('https://')) {
          logger.info(`   🔗 Абсолютные пути (https)`);
        } else {
          logger.info(`   📁 Другие пути`);
        }
        logger.separator();
      });

      logger.success('✅ Дебаг букмарклетов завершен');
      logger.separator();
    };

    // --- ПОЛУЧЕНИЕ БУКМАРКЛЕТОВ С URL ---
    this[PRIVATE.GET_BOOKMARKLETS_WITH_URLS] = () => {
      return this[PRIVATE.BOOKMARKLETS].map(bm => ({
        ...bm,
        code: bm.url ? bm.url.replace('javascript:', '') : null,
        isBookmarklet: true,
      }));
    };

    // --- ОБНОВЛЕНИЕ ТАБА ---
    this[PRIVATE.UPDATE_TAB] = tabName => {
      const logger = this[PRIVATE.LOGGER];
      logger.info(`🔘 Переключение на таб: ${tabName}`);

      if (!this[PRIVATE.TABS].has(tabName)) {
        logger.warn(`⚠️ Таб ${tabName} не найден`);
        return false;
      }

      this[PRIVATE.ACTIVE_TAB] = tabName;

      for (const [name, tab] of this[PRIVATE.TABS]) {
        tab.active = name === tabName;
        this[PRIVATE.TABS].set(name, tab);
      }

      this._sendMessageToPopup({
        type: 'TAB_CHANGED',
        tab: tabName,
        timestamp: Date.now(),
      });

      logger.success(`✅ Таб переключен на: ${tabName}`);
      return true;
    };

    // --- ОТПРАВКА СООБЩЕНИЯ В POPUP ---
    this._sendMessageToPopup = message => {
      try {
        if (typeof chrome !== 'undefined' && chrome.runtime) {
          chrome.runtime.sendMessage(message).catch(() => {});
        }
      } catch (error) {}
    };

    // --- ТАЙМЕРЫ (ИСПРАВЛЕНО) ---
    this._setupTimers = () => {
      logger.info('⏱️ Настройка таймеров...');

      // ★★★ ОЧИЩАЕМ СТАРЫЕ ТАЙМЕРЫ ★★★
      for (const [key, timer] of this[PRIVATE.TIMERS]) {
        clearInterval(timer);
        clearTimeout(timer);
      }
      this[PRIVATE.TIMERS].clear();

      try {
        const statusTimer = setInterval(() => {
          this[PRIVATE.EXTENSION_STATE].lastPing = Date.now();
        }, 30000);
        this[PRIVATE.TIMERS].set('status', statusTimer);

        const bookmarksTimer = setInterval(() => {
          if (this[PRIVATE.INITIALIZED]) {
            this._loadBookmarks();
          }
        }, 60000);
        this[PRIVATE.TIMERS].set('bookmarks', bookmarksTimer);

        logger.success('✅ Таймеры настроены');
      } catch (error) {
        logger.error('❌ Ошибка настройки таймеров:', error.message);
      }
    };

    // --- ЭКСПОРТ СИМВОЛОВ ---
    this._exportSymbols = () => {
      if (typeof self !== 'undefined') {
        self[PUBLIC.API] = this;
        self[PUBLIC.STATE] = this._getState.bind(this);
        self[PUBLIC.INSTANCE] = this;
        self[PUBLIC.WINDOW] = {
          open: this.openPopup.bind(this),
          isOpen: () => this[PRIVATE.WINDOW_CREATED],
          getId: () => this[PRIVATE.WINDOW_ID],
        };
        self[PUBLIC.EVENTS] = {
          on: this.on.bind(this),
          off: this.off.bind(this),
          emit: this.emit.bind(this),
        };
        self[PUBLIC.CONFIG] = this[PRIVATE.DYNAMIC_CONFIG];
        self[PUBLIC.LOGGER] = this[PRIVATE.LOGGER];
        self[PUBLIC.GENERATOR] = this[PRIVATE.GENERATOR];
        self[PUBLIC.TEMPLATE_GENERATOR] = this[PRIVATE.TEMPLATE_GENERATOR];
        self[PUBLIC.BOOKMARKS] = this[PRIVATE.BOOKMARKS];
        self[PUBLIC.TABS] = {
          get: () => Array.from(this[PRIVATE.TABS].values()),
          getActive: () => this[PRIVATE.ACTIVE_TAB],
          switch: tab => this[PRIVATE.UPDATE_TAB](tab),
          getPanel: tab => this[PRIVATE.TAB_PANELS].get(tab),
        };
        self[PUBLIC.BOOKMARKLETS_DEBUG] = {
          getAll: () => this[PRIVATE.GET_BOOKMARKLETS_WITH_URLS](),
          log: () => this[PRIVATE.DEBUG_BOOKMARKLETS](),
          getCache: () => Array.from(this[PRIVATE.BOOKMARK_URL_CACHE].entries()),
        };
        self[PUBLIC.UPDATER] = {
          getInstance: () => this[PRIVATE.UPDATER],
          getStatus: () => this.getUpdaterStatus(),
          setData: data => this.setUpdateData(data),
          getData: () => this.getUpdateData(),
          run: updates => this.manualUpdate(updates),
          getResults: () => this[PRIVATE.UPDATER_CONFIG].lastResults,
        };
        self[PUBLIC.UPDATE_CONFIG] = {
          get: () => this[PRIVATE.GET_UPDATE_CONFIG](),
          set: config => this[PRIVATE.SET_UPDATE_CONFIG](config),
          update: config => this[PRIVATE.UPDATE_FROM_CONFIG](config),
          default: DEFAULT_UPDATE_CONFIG,
        };
        self.__backgroundInstance = this;
        this[PRIVATE.EXPORTED] = true;
        logger.success('✅ Символы экспортированы');
      }
    };

    // --- ПОЛУЧЕНИЕ СОСТОЯНИЯ ---
    this._getState = () => {
      return {
        version: this[PRIVATE.VERSION],
        build: this[PRIVATE.BUILD],
        initialized: this[PRIVATE.INITIALIZED],
        isRunning: this[PRIVATE.IS_RUNNING],
        isDestroyed: this[PRIVATE.IS_DESTROYED],
        exported: this[PRIVATE.EXPORTED],
        generatorLoaded: this[PRIVATE.GENERATOR_LOADED],
        templateGeneratorLoaded: this[PRIVATE.TEMPLATE_GENERATOR_LOADED],
        bookmarksCount: this[PRIVATE.BOOKMARKS].length,
        bookmarkletsCount: this[PRIVATE.BOOKMARKLETS].length,
        bookmarkletsListCount: this[PRIVATE.BOOKMARKLETS_LIST].length,
        foldersCount: this[PRIVATE.FOLDERS].length,
        isUpdating: this[PRIVATE.IS_UPDATING],
        lastUpdate: this[PRIVATE.LAST_UPDATE],
        window: {
          id: this[PRIVATE.WINDOW_ID],
          created: this[PRIVATE.WINDOW_CREATED],
          config: this[PRIVATE.WINDOW_CONFIG],
        },
        extensionState: this[PRIVATE.EXTENSION_STATE],
        dynamicConfig: this[PRIVATE.DYNAMIC_CONFIG],
        generatorState: this[PRIVATE.GENERATOR]?.getState?.(),
        templateGeneratorStats: this[PRIVATE.TEMPLATE_GENERATOR]?.getStats?.(),
        listenersCount: this[PRIVATE.LISTENERS].size,
        timersCount: this[PRIVATE.TIMERS].size,
        cacheSize: this[PRIVATE.CACHE].size,
        urlCacheSize: this[PRIVATE.BOOKMARK_URL_CACHE].size,
        tabs: {
          count: this[PRIVATE.TABS].size,
          active: this[PRIVATE.ACTIVE_TAB],
          list: Array.from(this[PRIVATE.TABS].keys()),
        },
        updater: {
          enabled: this[PRIVATE.UPDATER_CONFIG].enabled,
          autoUpdate: this[PRIVATE.UPDATER_CONFIG].autoUpdate,
          initialized: this[PRIVATE.UPDATER_INITIALIZED],
          lastUpdate: this[PRIVATE.UPDATER_CONFIG].lastUpdate
            ? new Date(this[PRIVATE.UPDATER_CONFIG].lastUpdate).toISOString()
            : null,
          dataCount: Object.keys(this[PRIVATE.UPDATE_DATA] || {}).length,
          isRunning: this[PRIVATE.UPDATER]?.isRunning || false,
        },
        updateConfig: this[PRIVATE.GET_UPDATE_CONFIG](),
      };
    };

    // --- УНИЧТОЖЕНИЕ ---
    this._destroy = () => {
      if (this[PRIVATE.IS_DESTROYED]) {
        logger.warn('⚠️ Background Service уже уничтожен');
        return;
      }

      logger.warn('🗑️ Уничтожение Background Service...');

      for (const [key, timer] of this[PRIVATE.TIMERS]) {
        clearInterval(timer);
        clearTimeout(timer);
      }
      this[PRIVATE.TIMERS].clear();

      this[PRIVATE.LISTENERS].clear();
      this[PRIVATE.CACHE].clear();
      this[PRIVATE.BOOKMARK_URL_CACHE].clear();

      this[PRIVATE.TABS].clear();
      this[PRIVATE.TAB_PANELS].clear();
      this[PRIVATE.TAB_HANDLERS].clear();

      this[PRIVATE.STOP_AUTO_UPDATE]();

      if (this[PRIVATE.UPDATER]) {
        this[PRIVATE.SAFE_CALL_METHOD](this[PRIVATE.UPDATER], 'destroy');
        this[PRIVATE.UPDATER] = null;
      }

      if (this[PRIVATE.GENERATOR]?.reset) {
        this[PRIVATE.GENERATOR].reset();
      }
      if (this[PRIVATE.TEMPLATE_GENERATOR]?.destroy) {
        this[PRIVATE.TEMPLATE_GENERATOR].destroy();
      }

      if (this[PRIVATE.WINDOW_CREATED] && this[PRIVATE.WINDOW_ID]) {
        try {
          chrome.windows.remove(this[PRIVATE.WINDOW_ID]);
        } catch (error) {}
        this[PRIVATE.WINDOW_CREATED] = false;
        this[PRIVATE.WINDOW_ID] = null;
      }

      if (typeof self !== 'undefined') {
        delete self[PUBLIC.API];
        delete self[PUBLIC.STATE];
        delete self[PUBLIC.INSTANCE];
        delete self[PUBLIC.WINDOW];
        delete self[PUBLIC.EVENTS];
        delete self[PUBLIC.CONFIG];
        delete self[PUBLIC.LOGGER];
        delete self[PUBLIC.GENERATOR];
        delete self[PUBLIC.TEMPLATE_GENERATOR];
        delete self[PUBLIC.BOOKMARKS];
        delete self[PUBLIC.TABS];
        delete self[PUBLIC.BOOKMARKLETS_DEBUG];
        delete self[PUBLIC.UPDATER];
        delete self[PUBLIC.UPDATE_CONFIG];
        delete self.__backgroundInstance;
        delete self.__backgroundSymbols;
      }

      this[PRIVATE.IS_DESTROYED] = true;
      this[PRIVATE.INITIALIZED] = false;
      this[PRIVATE.EXPORTED] = false;

      logger.success('🗑️ Background Service уничтожен');
    };

    // ============================================================
    // 9.3 СОЗДАНИЕ ГЕНЕРАТОРОВ
    // ============================================================

    logger.info('📦 Создание генератора букмарклетов...');

    this[PRIVATE.GENERATOR] = new BookmarkletGenerator({
      debug: debug,
      version: this[PRIVATE.VERSION],
      dynamicConfig: this[PRIVATE.DYNAMIC_CONFIG],
    });
    this[PRIVATE.GENERATOR_LOADED] = true;
    logger.success('✅ Генератор букмарклетов создан');

    logger.info('📦 Создание генератора шаблонов...');

    this[PRIVATE.TEMPLATE_GENERATOR] = new BookmarkletTemplateGenerator({
      debug: debug,
      version: this[PRIVATE.VERSION],
      basePath: this[PRIVATE.DYNAMIC_CONFIG].bookmarklet.basePath,
      compression: this[PRIVATE.DYNAMIC_CONFIG].compression,
    });
    this[PRIVATE.TEMPLATE_GENERATOR_LOADED] = true;
    logger.success('✅ Генератор шаблонов создан');

    // ============================================================
    // 9.4 ВЫЗОВ ИНИЦИАЛИЗАЦИИ
    // ============================================================

    this._init();

    // ============================================================
    // 9.5 ЭКСПОРТ СИМВОЛОВ
    // ============================================================

    this._exportSymbols();

    // ============================================================
    // 9.6 ЛОГИРОВАНИЕ СТАТУСА
    // ============================================================

    logger.separator();
    logger.info(`📌 Версия: ${this[PRIVATE.VERSION]}`);
    logger.info(`📌 Сборка: ${this[PRIVATE.BUILD]}`);
    logger.info(`📌 Генератор букмарклетов: ${this[PRIVATE.GENERATOR_LOADED] ? '✅' : '❌'}`);
    logger.info(`📌 Генератор шаблонов: ${this[PRIVATE.TEMPLATE_GENERATOR_LOADED] ? '✅' : '❌'}`);
    logger.info(
      `📌 Окно: ${this[PRIVATE.WINDOW_CONFIG].width}x${this[PRIVATE.WINDOW_CONFIG].height}`
    );
    logger.info(`📌 Режим отладки: ${debug ? '✅' : '❌'}`);
    logger.info(`📌 Табов: ${this[PRIVATE.TABS].size}`);
    logger.info(`📌 Активный таб: ${this[PRIVATE.ACTIVE_TAB]}`);
    logger.info(`📌 Букмарклетов: ${this[PRIVATE.BOOKMARKLETS].length}`);
    logger.info(`📌 URL кеш: ${this[PRIVATE.BOOKMARK_URL_CACHE].size}`);
    logger.info(`📌 Обновлятор: ${this[PRIVATE.UPDATER_INITIALIZED] ? '✅' : '❌'}`);
    logger.info(`📌 Авто-обновление: ${this[PRIVATE.UPDATER_CONFIG].autoUpdate ? '✅' : '❌'}`);
    logger.info(`📌 Данных для обновления: ${Object.keys(this[PRIVATE.UPDATE_DATA] || {}).length}`);
    logger.info(`📌 Конфиг обновлений: ${this[PRIVATE.UPDATE_CONFIG] ? '✅' : '❌'}`);
    logger.separator();

    logger.success('✅ Background Service инициализирован (100% символы)');
    logger.header('ГОТОВ');
  }

  // ============================================================
  // 10. ПУБЛИЧНЫЕ МЕТОДЫ
  // ============================================================

  async openPopup() {
    const logger = this[PRIVATE.LOGGER];
    logger.info('📂 Открытие окна...');

    if (this[PRIVATE.WINDOW_CREATED] && this[PRIVATE.WINDOW_ID]) {
      try {
        await chrome.windows.update(this[PRIVATE.WINDOW_ID], { focused: true });
        return;
      } catch (error) {
        this[PRIVATE.WINDOW_CREATED] = false;
        this[PRIVATE.WINDOW_ID] = null;
      }
    }

    await this._openExtensionWindow();
  }

  getState() {
    return this._getState();
  }

  getGenerator() {
    return this[PRIVATE.GENERATOR];
  }

  getTemplateGenerator() {
    return this[PRIVATE.TEMPLATE_GENERATOR];
  }

  isTemplateGeneratorLoaded() {
    return this[PRIVATE.TEMPLATE_GENERATOR_LOADED];
  }

  async ensureTemplateGeneratorLoaded() {
    if (this[PRIVATE.TEMPLATE_GENERATOR_LOADED]) {
      return true;
    }
    return this[PRIVATE.TEMPLATE_GENERATOR_LOADED];
  }

  getTemplateGeneratorStatus() {
    return {
      loaded: this[PRIVATE.TEMPLATE_GENERATOR_LOADED],
      generatorAvailable: this[PRIVATE.TEMPLATE_GENERATOR] !== null,
      loading: this[PRIVATE.TEMPLATE_GENERATOR_LOADING] || false,
      error: this[PRIVATE.TEMPLATE_GENERATOR_ERROR] || null,
    };
  }

  refresh() {
    return this[PRIVATE.GENERATOR]?.refresh() || Promise.resolve({ updated: 0 });
  }

  updateAll() {
    return this[PRIVATE.GENERATOR]?.refresh() || Promise.resolve({ updated: 0 });
  }

  updateBookmarkUrl(bookmarkId, newCode) {
    return (
      this[PRIVATE.GENERATOR]?.updateBookmark(bookmarkId, newCode) ||
      Promise.reject('Generator not ready')
    );
  }

  generateUniversalBookmarklet(bookmarkData, options) {
    return this[PRIVATE.GENERATOR]?.generateUniversalBookmarklet(bookmarkData, options) || '';
  }

  compressCode(code) {
    return this[PRIVATE.GENERATOR]?.compressBookmarklet(code) || code;
  }

  minifyCode(code) {
    return this[PRIVATE.GENERATOR]?.minifyBookmarklet(code) || code;
  }

  generateAllTemplates(options = {}) {
    return this[PRIVATE.TEMPLATE_GENERATOR]?.generateAllTemplates(options) || [];
  }

  exportTemplates() {
    return this[PRIVATE.TEMPLATE_GENERATOR]?.exportToJSON() || null;
  }

  importTemplates(json) {
    return this[PRIVATE.TEMPLATE_GENERATOR]?.importFromJSON(json) || null;
  }

  getConfig() {
    return { ...this[PRIVATE.DYNAMIC_CONFIG] };
  }

  updateConfig(config) {
    this[PRIVATE.DYNAMIC_CONFIG] = { ...this[PRIVATE.DYNAMIC_CONFIG], ...config };
    this[PRIVATE.LOGGER].info('📌 Конфигурация обновлена');
    return this[PRIVATE.DYNAMIC_CONFIG];
  }

  getBookmarks() {
    return [...this[PRIVATE.BOOKMARKS]];
  }

  getBookmarklets() {
    return [...this[PRIVATE.BOOKMARKLETS]];
  }

  getBookmarkletsWithUrls() {
    return this[PRIVATE.GET_BOOKMARKLETS_WITH_URLS]();
  }

  getFolders() {
    return [...this[PRIVATE.FOLDERS]];
  }

  getBookmarkUrlCache() {
    return new Map(this[PRIVATE.BOOKMARK_URL_CACHE]);
  }

  clearCache() {
    this[PRIVATE.CACHE].clear();
    this[PRIVATE.BOOKMARK_URL_CACHE].clear();
    this[PRIVATE.LOGGER].info('🗑️ Кеш очищен');
    return this;
  }

  // ============================================================
  // 11. УПРАВЛЕНИЕ ТАБАМИ
  // ============================================================

  getTabs() {
    return Array.from(this[PRIVATE.TABS].values());
  }

  getActiveTab() {
    return this[PRIVATE.ACTIVE_TAB];
  }

  switchTab(tabName) {
    return this[PRIVATE.UPDATE_TAB](tabName);
  }

  debugBookmarklets() {
    this[PRIVATE.DEBUG_BOOKMARKLETS]();
  }

  logBookmarkletUrls(bookmark) {
    this[PRIVATE.LOG_BOOKMARKLET_URLS](bookmark);
  }

  // ============================================================
  // 12. УПРАВЛЕНИЕ ОБНОВЛЯТОРОМ
  // ============================================================

  setUpdateData(data) {
    const logger = this[PRIVATE.LOGGER];

    if (!data || typeof data !== 'object') {
      logger.error('❌ Неверный формат данных');
      return false;
    }

    this[PRIVATE.UPDATE_DATA] = data;
    this[PRIVATE.SAVE_UPDATE_DATA]();

    logger.info(`📦 Данные обновлений обновлены (${Object.keys(data).length} записей)`);

    const updater = this[PRIVATE.UPDATER];
    if (updater) {
      this[PRIVATE.SAFE_CALL_METHOD](updater, 'setData', data);
    }

    this[PRIVATE.RUN_UPDATE]();

    return true;
  }

  getUpdateData() {
    return this[PRIVATE.UPDATE_DATA] || {};
  }

  async manualUpdate(updates = null) {
    if (updates) {
      this.setUpdateData(updates);
      return this[PRIVATE.RUN_UPDATE]();
    } else {
      return this[PRIVATE.RUN_UPDATE]();
    }
  }

  getUpdaterStatus() {
    return {
      enabled: this[PRIVATE.UPDATER_CONFIG].enabled,
      autoUpdate: this[PRIVATE.UPDATER_CONFIG].autoUpdate,
      updateInterval: this[PRIVATE.UPDATER_CONFIG].updateInterval,
      initialized: this[PRIVATE.UPDATER_INITIALIZED],
      lastUpdate: this[PRIVATE.UPDATER_CONFIG].lastUpdate
        ? new Date(this[PRIVATE.UPDATER_CONFIG].lastUpdate).toISOString()
        : null,
      isRunning: this[PRIVATE.UPDATER]?.isRunning || false,
      dataCount: Object.keys(this[PRIVATE.UPDATE_DATA] || {}).length,
      results: this[PRIVATE.UPDATER_CONFIG].lastResults || null,
      updaterInstance: !!this[PRIVATE.UPDATER],
    };
  }

  async runBookmarkletUpdate() {
    return this[PRIVATE.RUN_UPDATE]();
  }

  getUpdater() {
    return this[PRIVATE.UPDATER];
  }

  setAutoUpdate(enabled) {
    const logger = this[PRIVATE.LOGGER];
    this[PRIVATE.UPDATER_CONFIG].autoUpdate = enabled;

    if (enabled) {
      this[PRIVATE.START_AUTO_UPDATE]();
      logger.info('✅ Авто-обновление включено');
    } else {
      this[PRIVATE.STOP_AUTO_UPDATE]();
      logger.info('⏹️ Авто-обновление выключено');
    }

    this._saveUpdaterConfig();
  }

  setUpdateInterval(interval) {
    const logger = this[PRIVATE.LOGGER];
    if (interval < 10000) {
      logger.warn('⚠️ Минимальный интервал 10 секунд');
      interval = 10000;
    }

    this[PRIVATE.UPDATER_CONFIG].updateInterval = interval;

    if (this[PRIVATE.UPDATER_CONFIG].autoUpdate) {
      this[PRIVATE.START_AUTO_UPDATE]();
    }

    logger.info(`📌 Интервал авто-обновления установлен: ${interval}ms`);
    this._saveUpdaterConfig();
  }

  _saveUpdaterConfig() {
    try {
      safeStorageSet('bookmarklet-updater-config', this[PRIVATE.UPDATER_CONFIG]);
    } catch (error) {}
  }

  // ============================================================
  // 13. УПРАВЛЕНИЕ КОНФИГОМ ОБНОВЛЕНИЙ
  // ============================================================

  setUpdateConfig(config) {
    return this[PRIVATE.SET_UPDATE_CONFIG](config);
  }

  getUpdateConfig() {
    return this[PRIVATE.GET_UPDATE_CONFIG]();
  }

  async updateFromConfig(config) {
    return this[PRIVATE.UPDATE_FROM_CONFIG](config);
  }

  // ============================================================
  // 14. СОБЫТИЯ
  // ============================================================

  on(event, callback) {
    if (!this[PRIVATE.LISTENERS].has(event)) {
      this[PRIVATE.LISTENERS].set(event, []);
    }
    this[PRIVATE.LISTENERS].get(event).push(callback);
    return () => this.off(event, callback);
  }

  off(event, callback) {
    if (this[PRIVATE.LISTENERS].has(event)) {
      const listeners = this[PRIVATE.LISTENERS].get(event);
      const index = listeners.indexOf(callback);
      if (index !== -1) {
        listeners.splice(index, 1);
      }
      if (listeners.length === 0) {
        this[PRIVATE.LISTENERS].delete(event);
      }
    }
  }

  emit(event, data) {
    if (this[PRIVATE.LISTENERS].has(event)) {
      const listeners = this[PRIVATE.LISTENERS].get(event);
      for (const callback of listeners) {
        try {
          callback(data);
        } catch (error) {}
      }
    }
  }

  destroy() {
    this._destroy();
  }
}

// ============================================================
// 15. СОЗДАНИЕ ЭКЗЕМПЛЯРА
// ============================================================

let backgroundInstance = null;

function getBackgroundInstance(options = {}) {
  if (!backgroundInstance) {
    backgroundInstance = new BackgroundService(options);
    if (typeof self !== 'undefined') {
      self.__backgroundInstance = backgroundInstance;
    }
  }
  return backgroundInstance;
}

// ============================================================
// 16. ЗАПУСК ДЛЯ SERVICE WORKER
// ============================================================

if (isServiceWorker) {
  try {
    const instance = getBackgroundInstance({
      debug: true,
      version: '2.0.11',
      build: '2026-07-22',
    });

    console.log(
      '╔═══════════════════════════════════════════════════════════════════════════════╗'
    );
    console.log('║              📦 BACKGROUND SERVICE (100% СИМВОЛЫ)                   ║');
    console.log(
      '╠═══════════════════════════════════════════════════════════════════════════════╣'
    );
    console.log('║  📋 Все логи выводятся в консоль с цветовой разметкой               ║');
    console.log('║  🔑 Полная изоляция через приватные символы                         ║');
    console.log('║  🔓 Публичные символы через Symbol.for                              ║');
    console.log('║  📦 Интеграция с генераторами букмарклетов                          ║');
    console.log('║  🪟 Управление окном и вкладками                                    ║');
    console.log('║  📊 Полная статистика работы                                        ║');
    console.log('║  🔍 Дебаг букмарклетов с логированием URL                           ║');
    console.log('║  🔄 Автоматическое обновление букмарклетов                          ║');
    console.log('║  📋 Управление конфигом обновлений                                 ║');
    console.log('║  ✅ ИСПРАВЛЕНЫ ошибки: localStorage и геттер updater               ║');
    console.log('║  ✅ ИСПРАВЛЕНА ошибка: Cannot set property Symbol(updater.config)  ║');
    console.log('║  ✅ ИСПРАВЛЕНА ошибка: this[Symbol(...)] is not a function        ║');
    console.log('║  ✅ ИСПРАВЛЕНО: дублирование таймеров при перезагрузке SW          ║');
    console.log('║  ✅ ИСПРАВЛЕНО: дублирование логов при загрузке закладок           ║');
    console.log('║  ✅ ИСПРАВЛЕНО: добавлены await для асинхронной загрузки            ║');
    console.log('║  ✅ ИСПРАВЛЕНО: загрузка букмарклетов перед обновлением             ║');
    console.log('║  ✅ Поддержка Service Worker окружения                              ║');
    console.log(
      '╚═══════════════════════════════════════════════════════════════════════════════╝'
    );

    console.log('📋 ДОСТУПНЫЕ КОМАНДЫ:');
    console.log('  __backgroundInstance.getState()                    - состояние');
    console.log('  __backgroundInstance.openPopup()                   - открыть окно');
    console.log('  __backgroundInstance.getGenerator()                - получить генератор');
    console.log(
      '  __backgroundInstance.getTemplateGenerator()        - получить генератор шаблонов'
    );
    console.log('  __backgroundInstance.ensureTemplateGeneratorLoaded() - загрузить генератор');
    console.log('  __backgroundInstance.refresh()                     - обновить');
    console.log('  __backgroundInstance.updateAll()                   - обновить все');
    console.log('  __backgroundInstance.compressCode()                - сжать код');
    console.log('  __backgroundInstance.minifyCode()                  - минифицировать код');
    console.log('  __backgroundInstance.generateAllTemplates()        - сгенерировать все шаблоны');
    console.log('  __backgroundInstance.exportTemplates()             - экспорт шаблонов');
    console.log('  __backgroundInstance.importTemplates(json)         - импорт шаблонов');
    console.log('  __backgroundInstance.on(event, cb)                 - подписка');
    console.log('  __backgroundInstance.emit(event)                   - событие');
    console.log('  __backgroundInstance.destroy()                     - уничтожить');
    console.log('  __backgroundInstance.getBookmarks()                - получить закладки');
    console.log('  __backgroundInstance.getBookmarklets()             - получить букмарклеты');
    console.log('  __backgroundInstance.clearCache()                  - очистить кеш');
    console.log('─'.repeat(70));
    console.log('📋 УПРАВЛЕНИЕ КОНФИГОМ ОБНОВЛЕНИЙ:');
    console.log('  __backgroundInstance.setUpdateConfig(config)       - установить конфиг');
    console.log('  __backgroundInstance.getUpdateConfig()             - получить конфиг');
    console.log('  __backgroundInstance.updateFromConfig(config)      - обновить с конфигом');
    console.log('  window[Symbol.for("background.updateConfig")]      - через символ');
    console.log('─'.repeat(70));
    console.log('🪟 УПРАВЛЕНИЕ ОКНОМ:');
    console.log('  __backgroundInstance.openPopup()                   - открыть окно');
    console.log('  window[Symbol.for("background.window")].open()     - через символ');
    console.log('─'.repeat(70));
    console.log('🔑 УПРАВЛЕНИЕ ТАБАМИ:');
    console.log('  __backgroundInstance.getTabs()                     - список табов');
    console.log('  __backgroundInstance.getActiveTab()                - активный таб');
    console.log('  __backgroundInstance.switchTab("logs")             - переключить таб');
    console.log('  window[Symbol.for("background.tabs")].switch()     - через символ');
    console.log('─'.repeat(70));
    console.log('🔍 ДЕБАГ БУКМАРКЛЕТОВ:');
    console.log('  __backgroundInstance.debugBookmarklets()           - дебаг всех букмарклетов');
    console.log('  __backgroundInstance.getBookmarkletsWithUrls()     - получить с URL');
    console.log('  __backgroundInstance.getBookmarkUrlCache()         - кеш URL');
    console.log('  window[Symbol.for("background.bookmarklets.debug")].log() - через символ');
    console.log('─'.repeat(70));
    console.log('🔄 УПРАВЛЕНИЕ ОБНОВЛЯТОРОМ:');
    console.log('  __backgroundInstance.setUpdateData(data)           - установить данные');
    console.log('  __backgroundInstance.getUpdateData()               - получить данные');
    console.log('  __backgroundInstance.manualUpdate(updates)         - ручное обновление');
    console.log('  __backgroundInstance.runBookmarkletUpdate()        - запустить обновление');
    console.log('  __backgroundInstance.getUpdaterStatus()            - статус обновлятора');
    console.log('  __backgroundInstance.setAutoUpdate(true/false)     - включить/выключить авто');
    console.log('  __backgroundInstance.setUpdateInterval(ms)         - установить интервал');
    console.log('  __backgroundInstance.getUpdater()                  - получить экземпляр');
    console.log('  window[Symbol.for("background.updater")]           - через символ');
    console.log('─'.repeat(70));
    console.log('🔑 ИСПОЛЬЗУЕМЫЕ МОДУЛИ:');
    console.log('  ✅ TemplateGeneratorCore          - ядро генератора шаблонов');
    console.log('  ✅ BookmarkletGenerator           - генератор букмарклетов');
    console.log('  ✅ BookmarkletTemplateGenerator   - обертка генератора шаблонов');
    console.log('  ✅ BookmarkletUpdater             - обновлятор букмарклетов');
    console.log('─'.repeat(70));
    console.log('📊 ПРИВАТНЫХ СИМВОЛОВ:', Object.keys(PRIVATE).length);
    console.log('📊 ПУБЛИЧНЫХ СИМВОЛОВ:', Object.keys(PUBLIC).length);
    console.log('─'.repeat(70));
    console.log('✅ Готов к работе!');

    self.__backgroundInstance = instance;
  } catch (error) {
    console.error('❌ Ошибка запуска:', error);
  }
}

// ============================================================
// 17. ЭКСПОРТ
// ============================================================

export {
  PRIVATE,
  PUBLIC,
  DEFAULT_DYNAMIC_CONFIG,
  DEFAULT_UPDATE_CONFIG,
  BackgroundService,
  getBackgroundInstance,
  createLogger,
};

// ============================================================
// 18. КОМАНДЫ ДЛЯ ОТЛАДКИ
// ============================================================

if (isBrowser) {
  window.__bg = {
    instance: window.__backgroundInstance || window.__background,
    getState: () => window.__backgroundInstance?.getState?.(),
    openPopup: () => window.__backgroundInstance?.openPopup?.(),
    refresh: () => window.__backgroundInstance?.refresh?.(),
    getGenerator: () => window.__backgroundInstance?.getGenerator?.(),
    getTemplateGenerator: () => window.__backgroundInstance?.getTemplateGenerator?.(),
    destroy: () => window.__backgroundInstance?.destroy?.(),
    getSymbols: () => ({
      PRIVATE: { ...PRIVATE },
      PUBLIC: { ...PUBLIC },
    }),
    tabs: {
      get: () => window.__backgroundInstance?.getTabs?.(),
      getActive: () => window.__backgroundInstance?.getActiveTab?.(),
      switch: tab => window.__backgroundInstance?.switchTab?.(tab),
    },
    debug: {
      bookmarklets: () => window.__backgroundInstance?.debugBookmarklets?.(),
      getUrls: () => window.__backgroundInstance?.getBookmarkletsWithUrls?.(),
      getCache: () => window.__backgroundInstance?.getBookmarkUrlCache?.(),
    },
    updater: {
      setData: data => window.__backgroundInstance?.setUpdateData?.(data),
      getData: () => window.__backgroundInstance?.getUpdateData?.(),
      run: updates => window.__backgroundInstance?.manualUpdate?.(updates),
      getStatus: () => window.__backgroundInstance?.getUpdaterStatus?.(),
      getInstance: () => window.__backgroundInstance?.getUpdater?.(),
      setAuto: enabled => window.__backgroundInstance?.setAutoUpdate?.(enabled),
      setInterval: ms => window.__backgroundInstance?.setUpdateInterval?.(ms),
    },
    updateConfig: {
      set: config => window.__backgroundInstance?.setUpdateConfig?.(config),
      get: () => window.__backgroundInstance?.getUpdateConfig?.(),
      update: config => window.__backgroundInstance?.updateFromConfig?.(config),
    },
  };

  console.log('📋 КОМАНДЫ ОТЛАДКИ (__bg):');
  console.log('  __bg.getState()            - состояние');
  console.log('  __bg.openPopup()           - открыть окно');
  console.log('  __bg.refresh()             - обновить');
  console.log('  __bg.getGenerator()        - получить генератор');
  console.log('  __bg.getTemplateGenerator() - получить генератор шаблонов');
  console.log('  __bg.destroy()             - уничтожить');
  console.log('  __bg.getSymbols()          - получить символы');
  console.log('');
  console.log('  __bg.tabs.get()            - список табов');
  console.log('  __bg.tabs.getActive()      - активный таб');
  console.log('  __bg.tabs.switch("logs")   - переключить таб');
  console.log('');
  console.log('  __bg.debug.bookmarklets()  - дебаг букмарклетов');
  console.log('  __bg.debug.getUrls()       - получить URL букмарклетов');
  console.log('  __bg.debug.getCache()      - кеш URL');
  console.log('');
  console.log('  __bg.updater.setData(data) - установить данные для обновления');
  console.log('  __bg.updater.getData()     - получить данные');
  console.log('  __bg.updater.run(updates)  - запустить обновление');
  console.log('  __bg.updater.getStatus()   - статус обновлятора');
  console.log('  __bg.updater.getInstance() - получить экземпляр');
  console.log('  __bg.updater.setAuto(true) - включить авто-обновление');
  console.log('  __bg.updater.setInterval(60000) - установить интервал');
  console.log('');
  console.log('  __bg.updateConfig.set(config) - установить конфиг обновлений');
  console.log('  __bg.updateConfig.get()       - получить конфиг');
  console.log('  __bg.updateConfig.update()    - обновить с конфигом');
}
