// popup.js - ИСПРАВЛЕННАЯ ВЕРСИЯ (100% СИМВОЛЫ)
// Версия: 2.0.6
// ИСПРАВЛЕНО: Добавлен await в loadBookmarksFromExtension()
// ИСПРАВЛЕНО: Асинхронная загрузка букмарклетов из Chrome

// ============================================================
// 1. ПРИВАТНЫЕ СИМВОЛЫ (100% изоляция)
// ============================================================

const PRIVATE = {
  // Основные символы
  CONFIG: Symbol('popup.config'),
  LOGGER: Symbol('popup.logger'),
  STATE: Symbol('popup.state'),
  CACHE: Symbol('popup.cache'),
  VERSION: Symbol('popup.version'),
  BUILD: Symbol('popup.build'),
  INITIALIZED: Symbol('popup.initialized'),
  IS_OPEN: Symbol('popup.isOpen'),
  IS_DESTROYED: Symbol('popup.isDestroyed'),

  // Данные
  SETTINGS: Symbol('popup.settings'),
  STATS: Symbol('popup.stats'),
  LOGS: Symbol('popup.logs'),
  BOOKMARKS: Symbol('popup.bookmarks'),
  ALL_BOOKMARKS: Symbol('popup.allBookmarks'),
  BOOKMARKLETS: Symbol('popup.bookmarklets'),
  FOLDERS: Symbol('popup.folders'),
  FILTERED_BOOKMARKS: Symbol('popup.filteredBookmarks'),

  // Состояние
  BACKGROUND_READY: Symbol('popup.backgroundReady'),
  BACKGROUND_ATTEMPTS: Symbol('popup.backgroundAttempts'),
  MAX_ATTEMPTS: Symbol('popup.maxAttempts'),
  CONNECTION_RETRY: Symbol('popup.connectionRetry'),
  DEVTOOLS_TAB_ID: Symbol('popup.devtoolsTabId'),
  INSTANCE_SYMBOLS: Symbol('popup.instanceSymbols'),
  INSTANCE_ID: Symbol('popup.instanceId'),

  // Управление
  TIMERS: Symbol('popup.timers'),
  LISTENERS: Symbol('popup.listeners'),
  HANDLERS: Symbol('popup.handlers'),
  TOAST_TIMER: Symbol('popup.toastTimer'),
  SAVE_TIMEOUT: Symbol('popup.saveTimeout'),

  // Методы
  INIT: Symbol('popup.init'),
  SETUP_UI: Symbol('popup.setupUI'),
  SETUP_TABS: Symbol('popup.setupTabs'),
  SETUP_EVENTS: Symbol('popup.setupEvents'),
  SETUP_TIMERS: Symbol('popup.setupTimers'),
  LOAD_STATE: Symbol('popup.loadState'),
  SAVE_STATE: Symbol('popup.saveState'),
  UPDATE_STATS: Symbol('popup.updateStats'),
  UPDATE_TIME: Symbol('popup.updateTime'),
  RENDER_LOGS: Symbol('popup.renderLogs'),
  RENDER_BOOKMARKS: Symbol('popup.renderBookmarks'),
  RENDER_BOOKMARKLETS: Symbol('popup.renderBookmarklets'),
  UPDATE_BOOKMARK_STATS: Symbol('popup.updateBookmarkStats'),
  LOG_BOOKMARKLET_URLS: Symbol('popup.logBookmarkletUrls'),
  DEBUG_BOOKMARKLET_URLS: Symbol('popup.debugBookmarkletUrls'),

  // Логи
  ADD_LOG: Symbol('popup.addLog'),
  LOG_INCOMING: Symbol('popup.logIncoming'),
  LOG_OUTGOING: Symbol('popup.logOutgoing'),
  CLEAR_LOGS: Symbol('popup.clearLogs'),

  // Загрузка данных
  LOAD_BOOKMARKS: Symbol('popup.loadBookmarks'),
  LOAD_BOOKMARKS_FROM_STORAGE: Symbol('popup.loadBookmarksFromStorage'),
  SAVE_BOOKMARKS_TO_STORAGE: Symbol('popup.saveBookmarksToStorage'),
  CREATE_TEST_BOOKMARKS: Symbol('popup.createTestBookmarks'),

  // Связь с background
  CHECK_BACKGROUND: Symbol('popup.checkBackground'),
  SAFE_SEND_MESSAGE: Symbol('popup.safeSendMessage'),
  UPDATE_CONNECTION_STATUS: Symbol('popup.updateConnectionStatus'),

  // Утилиты
  GET_FAVICON_URL: Symbol('popup.getFaviconUrl'),
  GET_FALLBACK_COLOR: Symbol('popup.getFallbackColor'),
  ESCAPE_HTML: Symbol('popup.escapeHtml'),
  SHOW_TOAST: Symbol('popup.showToast'),

  // Tabs
  TAB_PANELS: Symbol('popup.tabPanels'),
  ACTIVE_TAB: Symbol('popup.activeTab'),

  // ★★★ НОВЫЙ СИМВОЛ ДЛЯ ЗАГРУЗКИ ★★★
  LOAD_BOOKMARKS_FROM_EXTENSION: Symbol('popup.loadBookmarksFromExtension'),
};

// ============================================================
// 2. ПУБЛИЧНЫЕ СИМВОЛЫ (доступны через Symbol.for)
// ============================================================

const PUBLIC = {
  API: Symbol.for('popup.api'),
  STATE: Symbol.for('popup.state'),
  CONFIG: Symbol.for('popup.config'),
  LOGGER: Symbol.for('popup.logger'),
  INSTANCE: Symbol.for('popup.instance'),
  EVENTS: Symbol.for('popup.events'),
  BOOKMARKS: Symbol.for('popup.bookmarks'),
  CHANNEL: Symbol.for('popup.channel'),
};

// ============================================================
// 3. КОНФИГУРАЦИЯ
// ============================================================

const DEFAULT_CONFIG = {
  version: '2.0.6',
  build: '2026-07-22',
  debug: true,
  maxLogs: 200,
  maxBookmarks: 1000,
  backgroundCheckInterval: 30000,
  connectionTimeout: 5000,
  maxBackgroundAttempts: 10,
  storageKey: 'bookmarklet-bridge-state',
  bookmarksCacheKey: 'bookmarklet-bookmarks-cache',
};

const DEFAULT_SETTINGS = {
  bridgeEnabled: true,
  autoRespond: true,
  timeout: 5000,
  cacheTTL: 30,
  debugMode: false,
  logLevel: 'info',
  maxLogs: 100,
};

const DEFAULT_STATS = {
  requests: 0,
  success: 0,
  errors: 0,
  cacheSize: 0,
};

// ============================================================
// 4. ЛОГГЕР (с приватными символами)
// ============================================================

const LOGGER_SYMBOLS = {
  HISTORY: Symbol('logger.history'),
  MAX_HISTORY: Symbol('logger.maxHistory'),
  DEBUG: Symbol('logger.debug'),
  INSTANCE_ID: Symbol('logger.instanceId'),
};

function createLogger(debug = true, instanceId = 'Popup') {
  const logger = {};

  logger[LOGGER_SYMBOLS.HISTORY] = [];
  logger[LOGGER_SYMBOLS.MAX_HISTORY] = 200;
  logger[LOGGER_SYMBOLS.DEBUG] = debug;
  logger[LOGGER_SYMBOLS.INSTANCE_ID] = instanceId;

  logger[Symbol('logger.log')] = function (level, message, data = null) {
    if (!this[LOGGER_SYMBOLS.DEBUG] && level !== 'error') {
      return;
    }

    const timestamp = new Date().toISOString().slice(11, 23);
    const prefix = `[${timestamp}] [${this[LOGGER_SYMBOLS.INSTANCE_ID]}]`;

    this[LOGGER_SYMBOLS.HISTORY].push({ timestamp, level, message, data });
    if (this[LOGGER_SYMBOLS.HISTORY].length > this[LOGGER_SYMBOLS.MAX_HISTORY]) {
      this[LOGGER_SYMBOLS.HISTORY].shift();
    }

    if (data !== null && data !== undefined) {
      console.log(`${prefix} ${message}`, data);
    } else {
      console.log(`${prefix} ${message}`);
    }
  };

  logger.error = function (msg, d) {
    this[Symbol('logger.log')]('error', `❌ ${msg}`, d);
  };
  logger.warn = function (msg, d) {
    this[Symbol('logger.log')]('warn', `⚠️ ${msg}`, d);
  };
  logger.info = function (msg, d) {
    this[Symbol('logger.log')]('info', `ℹ️ ${msg}`, d);
  };
  logger.debug = function (msg, d) {
    this[Symbol('logger.log')]('debug', `🔍 ${msg}`, d);
  };
  logger.success = function (msg, d) {
    this[Symbol('logger.log')]('info', `✅ ${msg}`, d);
  };

  logger.header = function (title) {
    console.log('%c' + '═'.repeat(70), 'color: #636e72;');
    console.log(
        '%c  📦 ' + title,
        'background: #1a1a2e; color: #fff; padding: 4px 12px; border-radius: 4px; font-weight: bold;'
    );
    console.log('%c' + '═'.repeat(70), 'color: #636e72;');
  };

  logger.separator = function () {
    console.log('%c' + '─'.repeat(70), 'color: #636e72;');
  };

  logger.symbol = function (name, symbol) {
    console.log(`  🔑 ${name}: ${String(symbol)}`);
  };

  logger.private = function (name, symbol) {
    console.log(`  🔒 ${name}: ${String(symbol)}`);
  };

  logger.getHistory = function () {
    return [...this[LOGGER_SYMBOLS.HISTORY]];
  };

  logger.clearHistory = function () {
    this[LOGGER_SYMBOLS.HISTORY] = [];
    return this;
  };

  return logger;
}

// ============================================================
// 5. ОСНОВНОЙ КЛАСС POPUP (100% СИМВОЛЫ)
// ============================================================

class Popup {
  constructor(options = {}) {
    // ============================================================
    // 5.1 ИНИЦИАЛИЗАЦИЯ
    // ============================================================

    this[PRIVATE.CONFIG] = { ...DEFAULT_CONFIG, ...options };
    this[PRIVATE.VERSION] = options.version || DEFAULT_CONFIG.version;
    this[PRIVATE.BUILD] = options.build || DEFAULT_CONFIG.build;
    this[PRIVATE.LOGGER] = createLogger(this[PRIVATE.CONFIG].debug !== false, 'Popup');
    const logger = this[PRIVATE.LOGGER];

    // ============================================================
    // 5.2 СОСТОЯНИЕ
    // ============================================================

    this[PRIVATE.STATE] = {
      settings: { ...DEFAULT_SETTINGS },
      stats: { ...DEFAULT_STATS },
      logs: [],
      bookmarks: [],
      allBookmarks: [],
      bookmarklets: [],
      folders: [],
      filteredBookmarks: [],
      isOpen: true,
      initialized: false,
      instanceSymbols: null,
      instanceId: null,
      devtoolsTabId: null,
      backgroundReady: false,
      backgroundAttempts: 0,
      maxAttempts: this[PRIVATE.CONFIG].maxBackgroundAttempts,
      connectionRetryTimer: null,
    };

    this[PRIVATE.CACHE] = new Map();
    this[PRIVATE.TIMERS] = new Map();
    this[PRIVATE.LISTENERS] = new Map();
    this[PRIVATE.HANDLERS] = new Map();
    this[PRIVATE.TAB_PANELS] = new Map();
    this[PRIVATE.ACTIVE_TAB] = null;
    this[PRIVATE.TOAST_TIMER] = null;
    this[PRIVATE.SAVE_TIMEOUT] = null;
    this[PRIVATE.INITIALIZED] = false;
    this[PRIVATE.IS_DESTROYED] = false;

    // ============================================================
    // 5.3 ЗАГРУЗКА СОСТОЯНИЯ
    // ============================================================

    this[PRIVATE.LOAD_STATE]();

    // ============================================================
    // 5.4 ИНИЦИАЛИЗАЦИЯ
    // ============================================================

    logger.header('СОЗДАНИЕ POPUP (100% СИМВОЛЫ)');
    logger.info(`📦 Версия: ${this[PRIVATE.VERSION]}`);
    logger.info(`📅 Сборка: ${this[PRIVATE.BUILD]}`);
    logger.info(`📌 Режим отладки: ${this[PRIVATE.CONFIG].debug ? '✅' : '❌'}`);
    logger.separator();

    // Экспорт символов
    this[PRIVATE.EXPORT_SYMBOLS]();

    // Инициализация
    this[PRIVATE.INIT]();

    this[PRIVATE.INITIALIZED] = true;
    logger.success('✅ Popup инициализирован (100% символы)');
    logger.header('ГОТОВ');

    // Логируем URL букмарклетов
    setTimeout(() => {
      this[PRIVATE.DEBUG_BOOKMARKLET_URLS]();
    }, 1500);
  }

  // ============================================================
  // 6. ЭКСПОРТ СИМВОЛОВ
  // ============================================================

  [PRIVATE.EXPORT_SYMBOLS]() {
    if (typeof window === 'undefined') return;

    window.__popup = this;
    window[PUBLIC.API] = this;
    window[PUBLIC.STATE] = this.getState.bind(this);
    window[PUBLIC.CONFIG] = this[PRIVATE.CONFIG];
    window[PUBLIC.LOGGER] = this[PRIVATE.LOGGER];
    window[PUBLIC.INSTANCE] = this;
    window[PUBLIC.EVENTS] = {
      on: this.on.bind(this),
      off: this.off.bind(this),
      emit: this.emit.bind(this),
    };
    window[PUBLIC.BOOKMARKS] = this.getBookmarks.bind(this);
    window[PUBLIC.CHANNEL] = this.getChannel.bind(this);

    window.__popupSymbols = {
      PRIVATE: { ...PRIVATE },
      PUBLIC: { ...PUBLIC },
      version: this[PRIVATE.VERSION],
      build: this[PRIVATE.BUILD],
    };

    this[PRIVATE.LOGGER].success('✅ Символы экспортированы');
  }

  // ============================================================
  // 7. ИНИЦИАЛИЗАЦИЯ
  // ============================================================

  [PRIVATE.INIT]() {
    const logger = this[PRIVATE.LOGGER];
    logger.info('🔧 Инициализация...');

    this[PRIVATE.SETUP_UI]();
    this[PRIVATE.SETUP_TABS]();
    this[PRIVATE.SETUP_EVENTS]();
    this[PRIVATE.SETUP_TIMERS]();

    // Проверяем готовность background
    this[PRIVATE.CHECK_BACKGROUND](true);

    // Загружаем закладки
    this[PRIVATE.LOAD_BOOKMARKS]();

    this[PRIVATE.STATE].isOpen = true;
    this[PRIVATE.SAVE_STATE]();

    logger.success('✅ Инициализация завершена');
  }

  // ============================================================
  // 8. НАСТРОЙКА UI
  // ============================================================

  [PRIVATE.SETUP_UI]() {
    const logger = this[PRIVATE.LOGGER];
    logger.info('🎨 Настройка UI...');

    // Загружаем настройки в UI
    const bridgeEnabled = document.getElementById('bridge-enabled');
    const autoRespond = document.getElementById('auto-respond');
    const timeout = document.getElementById('timeout');
    const cacheTTL = document.getElementById('cache-ttl');
    const debugMode = document.getElementById('debug-mode');
    const logLevel = document.getElementById('log-level');
    const maxLogs = document.getElementById('max-logs');

    const settings = this[PRIVATE.STATE].settings;

    if (bridgeEnabled) bridgeEnabled.checked = settings.bridgeEnabled;
    if (autoRespond) autoRespond.checked = settings.autoRespond;
    if (timeout) timeout.value = settings.timeout;
    if (cacheTTL) cacheTTL.value = settings.cacheTTL;
    if (debugMode) debugMode.checked = settings.debugMode;
    if (logLevel) logLevel.value = settings.logLevel;
    if (maxLogs) maxLogs.value = settings.maxLogs;

    // ID расширения
    const extensionId = document.getElementById('extension-id');
    if (extensionId) {
      extensionId.textContent = chrome.runtime.id?.substring(0, 8) || 'unknown';
    }

    // Обновляем статус
    this[PRIVATE.UPDATE_CONNECTION_STATUS](this[PRIVATE.STATE].backgroundReady);

    // Рендерим логи и закладки
    this[PRIVATE.RENDER_LOGS]();
    this[PRIVATE.RENDER_BOOKMARKS]();

    logger.success('✅ UI настроен');
  }

  // ============================================================
  // 9. НАСТРОЙКА ТАБОВ (ИСПРАВЛЕННАЯ ВЕРСИЯ)
  // ============================================================

  [PRIVATE.SETUP_TABS]() {
    const logger = this[PRIVATE.LOGGER];
    logger.info('📑 Настройка табов...');

    // Получаем все панели
    const tabPanels = {
      settings: document.getElementById('tab-settings'),
      bookmarks: document.getElementById('tab-bookmarks'),
      logs: document.getElementById('tab-logs'),
      info: document.getElementById('tab-info'),
      bookmarklets: document.getElementById('tab-bookmarklets'),
    };

    // Сохраняем панели
    this[PRIVATE.TAB_PANELS] = new Map(Object.entries(tabPanels));

    // Проверяем наличие панелей
    logger.info('📋 Проверка панелей:');
    for (const [key, panel] of Object.entries(tabPanels)) {
      logger.info(`   ${key}: ${panel ? '✅ найдена' : '❌ НЕ НАЙДЕНА'}`);
    }

    // Настраиваем обработчики кнопок
    const tabBtns = document.querySelectorAll('.tab-btn');
    logger.info(`📌 Найдено кнопок: ${tabBtns.length}`);

    tabBtns.forEach((btn, index) => {
      btn.addEventListener('click', (e) => {
        e.preventDefault();
        const tab = btn.dataset.tab;
        logger.info(`🔘 Переключение на вкладку: ${tab}`);

        // Скрываем все панели
        for (const [key, panel] of this[PRIVATE.TAB_PANELS]) {
          if (panel) panel.classList.remove('active');
        }

        // Показываем нужную панель
        const targetPanel = this[PRIVATE.TAB_PANELS].get(tab);
        if (targetPanel) {
          targetPanel.classList.add('active');
          logger.success(`✅ Панель ${tab} показана`);
        } else {
          logger.error(`❌ Панель ${tab} не найдена!`);
        }

        // Обновляем кнопки
        tabBtns.forEach((b) => b.classList.remove('active'));
        btn.classList.add('active');

        // Сохраняем активный таб
        this[PRIVATE.ACTIVE_TAB] = tab;

        // Перерисовываем содержимое при необходимости
        if (tab === 'bookmarks') {
          this[PRIVATE.RENDER_BOOKMARKS]();
        }
        if (tab === 'bookmarklets') {
          this[PRIVATE.RENDER_BOOKMARKLETS]();
        }
        if (tab === 'logs') {
          this[PRIVATE.RENDER_LOGS]();
        }

        // Обновляем статистику
        this[PRIVATE.UPDATE_STATS]();

        // Логируем букмарклеты при переключении на соответствующий таб
        if (tab === 'bookmarklets' || tab === 'bookmarks') {
          this[PRIVATE.LOG_BOOKMARKLET_URLS](this[PRIVATE.STATE].bookmarks);
        }
      });

      // Добавляем лог для отладки
      logger.debug(`   Кнопка ${index + 1}: data-tab="${btn.dataset.tab}"`);
    });

    // Активируем первую вкладку по умолчанию
    const activeTab = document.querySelector('.tab-btn.active');
    if (activeTab) {
      const tab = activeTab.dataset.tab;
      const panel = this[PRIVATE.TAB_PANELS].get(tab);
      if (panel) {
        panel.classList.add('active');
        this[PRIVATE.ACTIVE_TAB] = tab;
        logger.info(`📌 Активная вкладка: ${tab}`);
      }
    } else if (tabBtns.length > 0) {
      // Если нет активной, активируем первую
      tabBtns[0].click();
    }

    logger.success('✅ Табы настроены');
  }

  // ============================================================
  // 10. НАСТРОЙКА СОБЫТИЙ
  // ============================================================

  [PRIVATE.SETUP_EVENTS]() {
    const logger = this[PRIVATE.LOGGER];
    logger.info('👂 Настройка событий...');

    // Сохранение настроек
    const saveBtn = document.getElementById('btn-save-settings');
    if (saveBtn) {
      saveBtn.addEventListener('click', () => {
        this[PRIVATE.SAVE_SETTINGS]();
      });
      logger.debug('✅ Кнопка сохранения настроена');
    }

    // Сброс настроек
    const resetBtn = document.getElementById('btn-reset-settings');
    if (resetBtn) {
      resetBtn.addEventListener('click', () => {
        this[PRIVATE.RESET_SETTINGS]();
      });
      logger.debug('✅ Кнопка сброса настроена');
    }

    // Очистка кеша
    const clearCacheBtn = document.getElementById('btn-clear-cache');
    if (clearCacheBtn) {
      clearCacheBtn.addEventListener('click', () => {
        this[PRIVATE.CLEAR_CACHE]();
      });
      logger.debug('✅ Кнопка очистки кеша настроена');
    }

    // Фильтр закладок
    const filterInput = document.getElementById('bookmark-filter');
    if (filterInput) {
      filterInput.addEventListener('input', () => {
        this[PRIVATE.RENDER_BOOKMARKS]();
      });
      logger.debug('✅ Фильтр закладок настроен');
    }

    // Обновление закладок
    const refreshBtn = document.getElementById('btn-refresh-bookmarks');
    if (refreshBtn) {
      refreshBtn.addEventListener('click', () => {
        this[PRIVATE.LOAD_BOOKMARKS]();
        this[PRIVATE.SHOW_TOAST]('🔄 Закладки обновлены', 'success');
      });
      logger.debug('✅ Кнопка обновления закладок настроена');
    }

    // Экспорт закладок
    const exportBtn = document.getElementById('btn-export-bookmarks');
    if (exportBtn) {
      exportBtn.addEventListener('click', () => {
        this[PRIVATE.EXPORT_BOOKMARKS]();
      });
      logger.debug('✅ Кнопка экспорта закладок настроена');
    }

    // Очистка логов
    const clearLogsBtn = document.getElementById('btn-clear-logs');
    if (clearLogsBtn) {
      clearLogsBtn.addEventListener('click', () => {
        this[PRIVATE.CLEAR_LOGS]();
      });
      logger.debug('✅ Кнопка очистки логов настроена');
    }

    // Экспорт логов
    const exportLogsBtn = document.getElementById('btn-export-logs');
    if (exportLogsBtn) {
      exportLogsBtn.addEventListener('click', () => {
        this[PRIVATE.EXPORT_LOGS]();
      });
      logger.debug('✅ Кнопка экспорта логов настроена');
    }

    // Фильтр логов
    const logFilter = document.getElementById('log-filter');
    if (logFilter) {
      logFilter.addEventListener('change', () => {
        this[PRIVATE.RENDER_LOGS]();
      });
      logger.debug('✅ Фильтр логов настроен');
    }

    // Обновление информации о вкладке
    const refreshTabBtn = document.getElementById('btn-refresh-tab');
    if (refreshTabBtn) {
      refreshTabBtn.addEventListener('click', () => {
        this[PRIVATE.UPDATE_TAB_INFO]();
      });
      logger.debug('✅ Кнопка обновления вкладки настроена');
    }

    // Открытие PiP
    const openPipBtn = document.getElementById('btn-open-pip');
    if (openPipBtn) {
      openPipBtn.addEventListener('click', () => {
        this[PRIVATE.OPEN_PIP]();
      });
      logger.debug('✅ Кнопка PiP настроена');
    }

    // Ссылки
    const linkManager = document.getElementById('link-manager');
    if (linkManager) {
      linkManager.addEventListener('click', (e) => {
        e.preventDefault();
        this[PRIVATE.OPEN_MANAGER]();
      });
      logger.debug('✅ Ссылка на менеджер настроена');
    }

    const linkInstall = document.getElementById('link-install');
    if (linkInstall) {
      linkInstall.addEventListener('click', (e) => {
        e.preventDefault();
        this[PRIVATE.OPEN_INSTALL]();
      });
      logger.debug('✅ Ссылка на установку настроена');
    }

    const linkDebug = document.getElementById('link-debug');
    if (linkDebug) {
      linkDebug.addEventListener('click', (e) => {
        e.preventDefault();
        this[PRIVATE.OPEN_DEBUG]();
      });
      logger.debug('✅ Ссылка на debug настроена');
    }

    const linkDevtools = document.getElementById('link-devtools');
    if (linkDevtools) {
      linkDevtools.addEventListener('click', (e) => {
        e.preventDefault();
        this[PRIVATE.OPEN_DEVTOOLS]();
      });
      logger.debug('✅ Ссылка на DevTools настроена');
    }

    // Кнопки управления букмарклетами
    const genAllBtn = document.getElementById('btn-generate-all');
    if (genAllBtn) {
      genAllBtn.addEventListener('click', () => {
        this[PRIVATE.GENERATE_ALL_BOOKMARKLETS]();
      });
      logger.debug('✅ Кнопка генерации всех букмарклетов настроена');
    }

    const updateHashBtn = document.getElementById('btn-update-with-hash');
    if (updateHashBtn) {
      updateHashBtn.addEventListener('click', () => {
        this[PRIVATE.UPDATE_BOOKMARKLETS_WITH_HASH]();
      });
      logger.debug('✅ Кнопка обновления с хешем настроена');
    }

    const clearBmCacheBtn = document.getElementById('btn-clear-bookmarklet-cache');
    if (clearBmCacheBtn) {
      clearBmCacheBtn.addEventListener('click', () => {
        this[PRIVATE.CLEAR_BOOKMARKLET_CACHE]();
      });
      logger.debug('✅ Кнопка очистки кеша букмарклетов настроена');
    }

    const deleteAllBmBtn = document.getElementById('btn-delete-all-bookmarklets');
    if (deleteAllBmBtn) {
      deleteAllBmBtn.addEventListener('click', () => {
        this[PRIVATE.DELETE_ALL_BOOKMARKLETS]();
      });
      logger.debug('✅ Кнопка удаления всех букмарклетов настроена');
    }

    const copyCodeBtn = document.getElementById('btn-copy-bookmarklet');
    if (copyCodeBtn) {
      copyCodeBtn.addEventListener('click', () => {
        this[PRIVATE.COPY_BOOKMARKLET_CODE]();
      });
      logger.debug('✅ Кнопка копирования кода настроена');
    }

    // Выбор букмарклета
    const bmSelect = document.getElementById('bookmarklet-select');
    if (bmSelect) {
      bmSelect.addEventListener('change', () => {
        this[PRIVATE.UPDATE_BOOKMARKLET_CODE_DISPLAY]();
      });
      logger.debug('✅ Выбор букмарклета настроен');
    }

    logger.success('✅ Все события настроены');
  }

  // ============================================================
  // 11. НАСТРОЙКА ТАЙМЕРОВ
  // ============================================================

  [PRIVATE.SETUP_TIMERS]() {
    const logger = this[PRIVATE.LOGGER];
    logger.info('⏱️ Настройка таймеров...');

    // Таймер обновления времени
    const timeTimer = setInterval(() => {
      this[PRIVATE.UPDATE_TIME]();
    }, 10000);
    this[PRIVATE.TIMERS].set('time', timeTimer);

    // Таймер проверки соединения
    const statusTimer = setInterval(() => {
      if (!this[PRIVATE.STATE].backgroundReady) {
        this[PRIVATE.CHECK_BACKGROUND](true);
      }
    }, this[PRIVATE.CONFIG].backgroundCheckInterval);
    this[PRIVATE.TIMERS].set('status', statusTimer);

    logger.success('✅ Таймеры настроены');
  }

  // ============================================================
  // 12. ЗАГРУЗКА/СОХРАНЕНИЕ СОСТОЯНИЯ
  // ============================================================

  [PRIVATE.LOAD_STATE]() {
    const logger = this[PRIVATE.LOGGER];
    logger.debug('📥 Загрузка состояния...');

    try {
      const saved = localStorage.getItem(this[PRIVATE.CONFIG].storageKey);
      if (saved) {
        const data = JSON.parse(saved);
        if (data.settings) {
          Object.assign(this[PRIVATE.STATE].settings, data.settings);
        }
        if (data.stats) {
          Object.assign(this[PRIVATE.STATE].stats, data.stats);
        }
        if (data.logs) {
          this[PRIVATE.STATE].logs = data.logs;
        }
        if (data.devtoolsTabId) {
          this[PRIVATE.STATE].devtoolsTabId = data.devtoolsTabId;
        }
        if (data.allBookmarks) {
          this[PRIVATE.STATE].allBookmarks = data.allBookmarks;
          this[PRIVATE.STATE].bookmarks = data.allBookmarks;
        }
        if (data.bookmarklets) {
          this[PRIVATE.STATE].bookmarklets = data.bookmarklets;
        }
        if (data.folders) {
          this[PRIVATE.STATE].folders = data.folders;
        }
        logger.debug(`✅ Состояние загружено (${Object.keys(data).length} полей)`);
      }
    } catch (e) {
      logger.warn('⚠️ Ошибка загрузки состояния:', e.message);
    }
  }

  [PRIVATE.SAVE_STATE]() {
    try {
      const data = {
        settings: this[PRIVATE.STATE].settings,
        stats: this[PRIVATE.STATE].stats,
        logs: this[PRIVATE.STATE].logs.slice(0, 100),
        devtoolsTabId: this[PRIVATE.STATE].devtoolsTabId,
        allBookmarks: this[PRIVATE.STATE].allBookmarks,
        bookmarklets: this[PRIVATE.STATE].bookmarklets,
        folders: this[PRIVATE.STATE].folders,
        timestamp: Date.now(),
      };
      localStorage.setItem(this[PRIVATE.CONFIG].storageKey, JSON.stringify(data));
      return true;
    } catch (e) {
      this[PRIVATE.LOGGER].warn('⚠️ Ошибка сохранения состояния:', e.message);
      return false;
    }
  }

  // ============================================================
  // 13. ЛОГИРОВАНИЕ
  // ============================================================

  [PRIVATE.ADD_LOG](level, message, data = null) {
    const settings = this[PRIVATE.STATE].settings;

    // Проверяем уровень логирования
    const levels = ['error', 'warn', 'info', 'debug', 'trace'];
    const levelIndex = levels.indexOf(level);
    const currentIndex = levels.indexOf(settings.logLevel);

    if (levelIndex > currentIndex) {
      return;
    }

    let dataStr = '';
    if (data !== null && data !== undefined) {
      try {
        if (typeof data === 'object') {
          dataStr = JSON.stringify(data, null, 2);
        } else {
          dataStr = String(data);
        }
      } catch (e) {
        dataStr = '[Object]';
      }
    }

    const entry = {
      timestamp: new Date().toISOString(),
      level,
      message,
      data: dataStr || null,
      rawData: data,
    };

    this[PRIVATE.STATE].logs.unshift(entry);
    if (this[PRIVATE.STATE].logs.length > settings.maxLogs) {
      this[PRIVATE.STATE].logs.pop();
    }

    // Выводим в консоль
    const consoleMsg = `[${level.toUpperCase()}] ${message}`;
    try {
      if (data !== null && data !== undefined) {
        if (level === 'error') {
          console.error(consoleMsg, data);
        } else if (level === 'warn') {
          console.warn(consoleMsg, data);
        } else if (level === 'debug') {
          console.debug(consoleMsg, data);
        } else {
          console.log(consoleMsg, data);
        }
      } else {
        if (level === 'error') {
          console.error(consoleMsg);
        } else if (level === 'warn') {
          console.warn(consoleMsg);
        } else if (level === 'debug') {
          console.debug(consoleMsg);
        } else {
          console.log(consoleMsg);
        }
      }
    } catch (e) {
      // Игнорируем
    }

    this[PRIVATE.RENDER_LOGS]();
    this[PRIVATE.SAVE_STATE]();

    // Отправляем в background
    if (chrome?.runtime?.id && this[PRIVATE.STATE].backgroundReady) {
      try {
        chrome.runtime.sendMessage({
          action: 'log_update',
          level,
          message,
          data: dataStr,
        }).catch(() => {});
      } catch (e) {
        // Игнорируем
      }
    }
  }

  [PRIVATE.LOG_INCOMING](source, type, data) {
    this[PRIVATE.ADD_LOG]('debug', `📥 ВХОДЯЩЕЕ: ${source}:${type}`, data);
  }

  [PRIVATE.LOG_OUTGOING](target, type, data) {
    this[PRIVATE.ADD_LOG]('debug', `📤 ИСХОДЯЩЕЕ: ${target}:${type}`, data);
  }

  [PRIVATE.CLEAR_LOGS]() {
    this[PRIVATE.STATE].logs = [];
    this[PRIVATE.RENDER_LOGS]();
    this[PRIVATE.SAVE_STATE]();
    this[PRIVATE.ADD_LOG]('info', '🗑️ Логи очищены');
    this[PRIVATE.SHOW_TOAST]('🗑️ Логи очищены', 'info');
  }

  [PRIVATE.EXPORT_LOGS]() {
    const data = JSON.stringify(this[PRIVATE.STATE].logs, null, 2);
    const blob = new Blob([data], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `logs-${new Date().toISOString().slice(0, 19).replace(/[:.]/g, '-')}.json`;
    a.click();
    URL.revokeObjectURL(url);
    this[PRIVATE.ADD_LOG]('info', `📥 Экспортировано ${this[PRIVATE.STATE].logs.length} записей`);
  }

  // ============================================================
  // 14. РЕНДЕРИНГ ЛОГОВ
  // ============================================================

  [PRIVATE.RENDER_LOGS]() {
    const container = document.getElementById('logs-container');
    if (!container) return;

    const filter = document.getElementById('log-filter');
    const filterValue = filter ? filter.value : 'all';

    let filtered = this[PRIVATE.STATE].logs;
    if (filterValue !== 'all') {
      filtered = filtered.filter((log) => log.level === filterValue);
    }

    if (filtered.length === 0) {
      container.innerHTML = `<div class=\"log-empty\">📭 Логов нет</div>`;
      return;
    }

    let html = '';
    for (const log of filtered) {
      const time = new Date(log.timestamp).toLocaleTimeString();
      const levelClass = log.level;

      let messageHtml = this[PRIVATE.ESCAPE_HTML](log.message);
      if (log.data) {
        const dataPreview =
            typeof log.data === 'string' && log.data.length > 100
                ? log.data.substring(0, 100) + '...'
                : log.data;
        messageHtml += `\n📦 ${this[PRIVATE.ESCAPE_HTML](JSON.stringify(dataPreview, null, 2))}`;
      }

      html += `
                <div class="log-entry">
                    <span class="log-time">${time}</span>
                    <span class="log-level ${levelClass}">${log.level.toUpperCase()}</span>
                    <span class="log-message">${messageHtml}</span>
                </div>
            `;
    }

    container.innerHTML = html;
    // Прокручиваем вверх (новые логи сверху)
    container.scrollTop = 0;
  }

  // ============================================================
  // 15. ★★★ РАБОТА С ЗАКЛАДКАМИ (ИСПРАВЛЕННАЯ ВЕРСИЯ) ★★★
  // ============================================================

  [PRIVATE.LOAD_BOOKMARKS]() {
    const logger = this[PRIVATE.LOGGER];
    logger.info('📑 Загрузка закладок...');

    // Пробуем загрузить через extension
    this[PRIVATE.LOAD_BOOKMARKS_FROM_EXTENSION]().catch(() => {
      // Fallback - из localStorage
      logger.warn('⚠️ Используем кеш закладок');
      this[PRIVATE.LOAD_BOOKMARKS_FROM_STORAGE]();
    });
  }

  // ★★★ ИСПРАВЛЕННЫЙ МЕТОД С await ★★★
  async [PRIVATE.LOAD_BOOKMARKS_FROM_EXTENSION]() {
    const logger = this[PRIVATE.LOGGER];
    logger.debug('📡 Загрузка через background...');

    // Если есть кеш - сначала показываем его
    if (this[PRIVATE.STATE].allBookmarks && this[PRIVATE.STATE].allBookmarks.length > 0) {
      logger.debug('📦 Используем кеш закладок');
      this[PRIVATE.UPDATE_BOOKMARK_STATS]();
      this[PRIVATE.RENDER_BOOKMARKS]();
      return this[PRIVATE.STATE].allBookmarks;
    }

    try {
      logger.debug('📤 Запрос к background...');
      this[PRIVATE.LOG_OUTGOING]('background', 'get_all_bookmarks', { action: 'get_all_bookmarks' });

      // ★★★ ИСПОЛЬЗУЕМ await ДЛЯ ОЖИДАНИЯ ОТВЕТА ★★★
      const response = await this[PRIVATE.SAFE_SEND_MESSAGE](
          {
            action: 'get_all_bookmarks',
          },
          5000
      );

      this[PRIVATE.LOG_INCOMING]('background', 'get_all_bookmarks_response', response);

      if (response && response.success) {
        const data = response.data;
        this[PRIVATE.STATE].allBookmarks = data.all || [];
        this[PRIVATE.STATE].bookmarklets = data.bookmarklets || [];
        this[PRIVATE.STATE].folders = data.folders || [];
        this[PRIVATE.STATE].bookmarks = data.all || [];

        // Сохраняем в кеш
        this[PRIVATE.SAVE_BOOKMARKS_TO_STORAGE](this[PRIVATE.STATE].allBookmarks);

        this[PRIVATE.UPDATE_BOOKMARK_STATS]();
        this[PRIVATE.RENDER_BOOKMARKS]();
        this[PRIVATE.LOG_BOOKMARKLET_URLS](this[PRIVATE.STATE].bookmarks);

        logger.info(`✅ Загружено ${this[PRIVATE.STATE].bookmarks.length} закладок`);
        return data;
      }

      throw new Error('Не удалось загрузить закладки');
    } catch (error) {
      logger.error(`❌ Ошибка: ${error.message}`);
      return this[PRIVATE.LOAD_BOOKMARKS_FROM_STORAGE]();
    }
  }

  [PRIVATE.LOAD_BOOKMARKS_FROM_STORAGE]() {
    const logger = this[PRIVATE.LOGGER];
    logger.debug('📦 Загрузка из localStorage...');

    try {
      const saved = localStorage.getItem(this[PRIVATE.CONFIG].bookmarksCacheKey);
      if (saved) {
        const data = JSON.parse(saved);
        this[PRIVATE.STATE].allBookmarks = data.all || [];
        this[PRIVATE.STATE].bookmarklets = data.bookmarklets || [];
        this[PRIVATE.STATE].folders = data.folders || [];
        this[PRIVATE.STATE].bookmarks = data.all || [];

        this[PRIVATE.UPDATE_BOOKMARK_STATS]();
        this[PRIVATE.RENDER_BOOKMARKS]();
        this[PRIVATE.LOG_BOOKMARKLET_URLS](this[PRIVATE.STATE].bookmarks);

        logger.info(`📦 Загружено ${this[PRIVATE.STATE].bookmarks.length} закладок из кеша`);
        return data;
      }

      // Если кеша нет - создаем тестовые
      logger.info('📦 Создаем тестовые закладки');
      return this[PRIVATE.CREATE_TEST_BOOKMARKS]();
    } catch (e) {
      logger.error(`❌ Ошибка: ${e.message}`);
      return this[PRIVATE.CREATE_TEST_BOOKMARKS]();
    }
  }

  [PRIVATE.SAVE_BOOKMARKS_TO_STORAGE](bookmarks) {
    try {
      const data = {
        all: bookmarks,
        bookmarklets: bookmarks.filter((b) => b.isBookmarklet || b.type === 'bookmarklet'),
        folders: bookmarks.filter((b) => b.type === 'folder'),
        timestamp: Date.now(),
      };
      localStorage.setItem(this[PRIVATE.CONFIG].bookmarksCacheKey, JSON.stringify(data));
      return true;
    } catch (e) {
      this[PRIVATE.LOGGER].warn('⚠️ Ошибка сохранения кеша:', e.message);
      return false;
    }
  }

  [PRIVATE.CREATE_TEST_BOOKMARKS]() {
    const logger = this[PRIVATE.LOGGER];
    logger.info('📦 Создание тестовых букмарклетов...');

    const all = [
      {
        id: '1',
        title: '📌 ENV Control',
        url: 'javascript:(function(){const s=document.createElement("script");s.type="module";s.src="./Bookmarklet/bookmarklet.js";document.head.appendChild(s);})();',
        isBookmarklet: true,
        type: 'bookmarklet',
        path: 'Панель закладок',
      },
      {
        id: '2',
        title: '📋 Logs Control',
        url: 'javascript:(function(){const s=document.createElement("script");s.type="module";s.src="./Bookmarklet/logs-panel.js";document.head.appendChild(s);})();',
        isBookmarklet: true,
        type: 'bookmarklet',
        path: 'Панель закладок',
      },
      {
        id: '3',
        title: '🐛 Debug Control',
        url: 'javascript:(function(){const s=document.createElement("script");s.type="module";s.src="./Bookmarklet/debug-panel.js";document.head.appendChild(s);})();',
        isBookmarklet: true,
        type: 'bookmarklet',
        path: 'Панель закладок',
      },
      {
        id: '4',
        title: '📦 Manager',
        url: 'javascript:window.open("./Bookmarklet/manager.html","_blank","width=900,height=800");',
        isBookmarklet: true,
        type: 'bookmarklet',
        path: 'Панель закладок',
      },
    ];

    this[PRIVATE.STATE].allBookmarks = all;
    this[PRIVATE.STATE].bookmarklets = all;
    this[PRIVATE.STATE].folders = [];
    this[PRIVATE.STATE].bookmarks = all;

    this[PRIVATE.SAVE_BOOKMARKS_TO_STORAGE](all);
    this[PRIVATE.UPDATE_BOOKMARK_STATS]();
    this[PRIVATE.RENDER_BOOKMARKS]();
    this[PRIVATE.LOG_BOOKMARKLET_URLS](all);

    logger.info(`✅ Создано ${all.length} тестовых букмарклетов`);
    return all;
  }

  // ============================================================
  // 16. ЛОГИРОВАНИЕ URL БУКМАРКЛЕТОВ
  // ============================================================

  [PRIVATE.LOG_BOOKMARKLET_URLS](bookmarks) {
    const logger = this[PRIVATE.LOGGER];
    logger.separator();
    logger.header('📋 БУКМАРКЛЕТЫ И ИХ URL');

    if (!bookmarks || bookmarks.length === 0) {
      logger.info('📭 Букмарклеты не найдены');
      logger.separator();
      return;
    }

    const bookmarklets = bookmarks.filter((b) => b.url && b.url.startsWith('javascript:'));

    if (bookmarklets.length === 0) {
      logger.info('📭 Букмарклеты не найдены');
      logger.separator();
      return;
    }

    logger.info(`📦 Всего найдено: ${bookmarklets.length}`);

    bookmarklets.forEach((bm, index) => {
      const code = bm.url.replace('javascript:', '');
      logger.info(`\n📌 [${index + 1}] ${bm.title}`);
      logger.info(`   ID: ${bm.id}`);
      logger.info(`   📍 Путь: ${bm.path || 'корень'}`);
      logger.info(`   📏 Длина URL: ${bm.url.length} символов`);
      logger.info(`   📄 Код (первые 200 символов):`);
      logger.info(`   ${code.substring(0, 200)}${code.length > 200 ? '...' : ''}`);

      // Анализ путей
      if (code.includes('./Bookmarklet/')) {
        logger.info(`   ✅ Использует относительные пути: ./Bookmarklet/`);
      } else if (code.includes('http://localhost')) {
        logger.info(`   🔗 Использует абсолютные пути (localhost)`);
      } else if (code.includes('https://')) {
        logger.info(`   🔗 Использует абсолютные пути (https)`);
      } else {
        logger.info(`   📁 Использует другие пути`);
      }

      // Проверяем наличие проблемных паттернов
      if (code.includes('http://localhost:8081')) {
        logger.warn(`   ⚠️ Содержит localhost:8081 — возможно, требует замены`);
      }
      if (code.includes('http://localhost')) {
        logger.warn(`   ⚠️ Содержит localhost — возможно, требует замены`);
      }
    });

    logger.separator();
  }

  [PRIVATE.DEBUG_BOOKMARKLET_URLS]() {
    const logger = this[PRIVATE.LOGGER];
    logger.header('🐛 ОТЛАДКА: ПОЛУЧЕНИЕ ВСЕХ БУКМАРКЛЕТОВ ИЗ CHROME');

    if (typeof chrome === 'undefined' || !chrome.bookmarks) {
      logger.error('❌ Chrome bookmarks API не доступен');
      return;
    }

    chrome.bookmarks.getTree((tree) => {
      if (chrome.runtime.lastError) {
        logger.error(`❌ Ошибка: ${chrome.runtime.lastError.message}`);
        return;
      }

      const bookmarklets = [];

      function traverse(node, path = '') {
        if (node.url && node.url.startsWith('javascript:')) {
          bookmarklets.push({
            id: node.id,
            title: node.title || 'Без названия',
            url: node.url,
            path: path || 'корень',
            parentId: node.parentId,
          });
        }
        if (node.children) {
          const currentPath = path ? `${path} > ${node.title || 'корень'}` : node.title || 'корень';
          for (const child of node.children) {
            traverse(child, currentPath);
          }
        }
      }

      for (const root of tree) {
        traverse(root, '');
      }

      logger.info(`📦 НАЙДЕНО БУКМАРКЛЕТОВ: ${bookmarklets.length}`);

      if (bookmarklets.length === 0) {
        logger.info('📭 Нет букмарклетов в Chrome');
        return;
      }

      bookmarklets.forEach((bm, i) => {
        logger.info(`\n📌 [${i + 1}] ${bm.title}`);
        logger.info(`   ID: ${bm.id}`);
        logger.info(`   Путь: ${bm.path}`);
        logger.info(`   URL длина: ${bm.url.length}`);
        const code = bm.url.replace('javascript:', '');
        logger.info(`   Код: ${code.substring(0, 150)}${code.length > 150 ? '...' : ''}`);
      });

      // Сохраняем в состояние
      if (bookmarklets.length > 0) {
        this[PRIVATE.STATE].bookmarks = bookmarklets;
        this[PRIVATE.STATE].allBookmarks = bookmarklets;
        this[PRIVATE.SAVE_STATE]();
        this[PRIVATE.RENDER_BOOKMARKS]();
      }
    });
  }

  // ============================================================
  // 17. РЕНДЕРИНГ ЗАКЛАДОК
  // ============================================================

  [PRIVATE.RENDER_BOOKMARKS]() {
    const container = document.getElementById('bookmarks-list');
    if (!container) return;

    const filter = document.getElementById('bookmark-filter');
    const filterValue = filter ? filter.value.toLowerCase() : '';

    const bookmarks = this[PRIVATE.STATE].bookmarks || this[PRIVATE.STATE].allBookmarks || [];

    let filtered = bookmarks;
    if (filterValue) {
      filtered = filtered.filter(
          (b) =>
              b.title.toLowerCase().includes(filterValue) ||
              (b.url && b.url.toLowerCase().includes(filterValue))
      );
    }

    this[PRIVATE.STATE].filteredBookmarks = filtered;

    if (filtered.length === 0) {
      container.innerHTML = `<div class="log-empty">📭 Закладок не найдено</div>`;
      return;
    }

    let html = '';
    for (const bookmark of filtered) {
      const type = bookmark.type || (bookmark.isBookmarklet ? 'bookmarklet' : 'url');
      const isFolder = type === 'folder';
      const isBookmarklet = type === 'bookmarklet' || bookmark.isBookmarklet;
      const isUrl = type === 'url' && !isBookmarklet;

      let iconHtml = '';
      if (isFolder) {
        iconHtml = `<span class="bookmark-icon-fallback">📁</span>`;
      } else if (isBookmarklet) {
        iconHtml = `<span class="bookmark-icon-fallback">📌</span>`;
      } else if (isUrl && bookmark.url) {
        const faviconUrl = this[PRIVATE.GET_FAVICON_URL](bookmark.url);
        iconHtml = `
                    <div class="bookmark-icon-wrapper">
                        <img src="${faviconUrl}" 
                             class="bookmark-favicon" 
                             alt="favicon"
                             onerror="this.style.display='none'; this.parentElement.innerHTML='<span class=\\'bookmark-icon-fallback\\' style=\\'color:${this[PRIVATE.GET_FALLBACK_COLOR](bookmark.url)}\\'>🔗</span>'"
                             loading="lazy">
                    </div>
                `;
      } else {
        iconHtml = `<span class="bookmark-icon-fallback">🔗</span>`;
      }

      const typeClass = isBookmarklet ? 'bookmarklet' : isFolder ? 'folder' : 'url';
      const typeLabel = isBookmarklet ? '📌 букмарклет' : isFolder ? '📁 папка' : '🔗 url';
      const path = bookmark.path || '—';

      html += `
                <div class="bookmark-item" data-id="${bookmark.id}" title="Путь: ${path}">
                    <div class="bookmark-info">
                        ${iconHtml}
                        <div style="display:flex;flex-direction:column;min-width:0;flex:1;">
                            <span class="bookmark-title">${this[PRIVATE.ESCAPE_HTML](bookmark.title)}</span>
                            <span style="font-size:9px;color:#636e72;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${this[PRIVATE.ESCAPE_HTML](path)}</span>
                        </div>
                        <span class="bookmark-url">${bookmark.url ? this[PRIVATE.ESCAPE_HTML](bookmark.url.substring(0, 30)) : ''}</span>
                    </div>
                    <span class="bookmark-type ${typeClass}">${typeLabel}</span>
                </div>
            `;
    }

    container.innerHTML = html;
    this[PRIVATE.UPDATE_BOOKMARK_STATS]();
  }

  [PRIVATE.UPDATE_BOOKMARK_STATS]() {
    const bookmarks = this[PRIVATE.STATE].bookmarks || this[PRIVATE.STATE].allBookmarks || [];
    const total = bookmarks.length;
    const bookmarklets = bookmarks.filter((b) => b.isBookmarklet || b.type === 'bookmarklet').length;
    const folders = bookmarks.filter((b) => b.type === 'folder').length;

    const totalEl = document.getElementById('bookmarks-total');
    const bmEl = document.getElementById('bookmarks-bookmarklets');
    const foldersEl = document.getElementById('bookmarks-folders');

    if (totalEl) totalEl.textContent = total;
    if (bmEl) bmEl.textContent = bookmarklets;
    if (foldersEl) foldersEl.textContent = folders;
  }

  // ============================================================
  // 18. РЕНДЕРИНГ БУКМАРКЛЕТОВ (ВКЛАДКА)
  // ============================================================

  [PRIVATE.RENDER_BOOKMARKLETS]() {
    const container = document.getElementById('bookmarklets-list');
    const select = document.getElementById('bookmarklet-select');
    if (!container || !select) return;

    const bookmarks = this[PRIVATE.STATE].bookmarks || this[PRIVATE.STATE].allBookmarks || [];
    const bookmarklets = bookmarks.filter((b) => b.url && b.url.startsWith('javascript:'));

    if (bookmarklets.length === 0) {
      container.innerHTML = '<div class="log-empty">📭 Нет букмарклетов</div>';
      select.innerHTML = '<option value="">Нет букмарклетов</option>';
      return;
    }

    // Обновляем список
    let html = '';
    select.innerHTML = '<option value="">Выберите букмарклет</option>';

    bookmarklets.forEach((bm, index) => {
      const code = bm.url.replace('javascript:', '');
      html += `
                <div class="bookmark-item" data-id="${bm.id}">
                    <div class="bookmark-info">
                        <span class="bookmark-icon-fallback">📌</span>
                        <div style="display:flex;flex-direction:column;min-width:0;flex:1;">
                            <span class="bookmark-title">${this[PRIVATE.ESCAPE_HTML](bm.title)}</span>
                            <span style="font-size:9px;color:#636e72;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${this[PRIVATE.ESCAPE_HTML](bm.path || 'корень')}</span>
                        </div>
                        <span style="font-size:10px;color:#636e72;">${code.length} симв.</span>
                    </div>
                    <span class="bookmark-type bookmarklet">📌 букмарклет</span>
                </div>
            `;

      const opt = document.createElement('option');
      opt.value = bm.id;
      opt.textContent = `${bm.title} (${code.substring(0, 30)}...)`;
      select.appendChild(opt);
    });

    container.innerHTML = html;

    // Обновляем отображение кода
    this[PRIVATE.UPDATE_BOOKMARKLET_CODE_DISPLAY]();

    // Обновляем статистику кеша
    this[PRIVATE.UPDATE_BOOKMARKLET_CACHE_STATS]();
  }

  [PRIVATE.UPDATE_BOOKMARKLET_CODE_DISPLAY]() {
    const select = document.getElementById('bookmarklet-select');
    const display = document.getElementById('bookmarklet-code-display');
    if (!select || !display) return;

    const id = select.value;
    if (!id) {
      display.textContent = 'Выберите букмарклет из списка';
      return;
    }

    const bookmarks = this[PRIVATE.STATE].bookmarks || [];
    const bm = bookmarks.find((b) => b.id === id);

    if (!bm || !bm.url) {
      display.textContent = 'Букмарклет не найден';
      return;
    }

    const code = bm.url.replace('javascript:', '');
    display.textContent = code;
  }

  // ============================================================
  // 19. СТАТИСТИКА
  // ============================================================

  [PRIVATE.UPDATE_STATS]() {
    const stats = this[PRIVATE.STATE].stats;
    const requests = document.getElementById('stat-requests');
    const success = document.getElementById('stat-success');
    const errors = document.getElementById('stat-errors');
    const cache = document.getElementById('stat-cache');

    if (requests) requests.textContent = stats.requests;
    if (success) success.textContent = stats.success;
    if (errors) errors.textContent = stats.errors;
    if (cache) cache.textContent = stats.cacheSize;

    // Кеш букмарклетов
    const cacheTotal = document.getElementById('cache-total');
    const cacheHitRate = document.getElementById('cache-hit-rate');
    const cacheOrphaned = document.getElementById('cache-orphaned');
    const cacheVersion = document.getElementById('cache-version');

    if (cacheTotal) {
      try {
        const cached = localStorage.getItem('bookmarklet-bookmarks-cache');
        const data = cached ? JSON.parse(cached) : null;
        cacheTotal.textContent = data?.all?.length || 0;
      } catch {
        cacheTotal.textContent = 0;
      }
    }

    if (cacheHitRate) {
      const total = this[PRIVATE.STATE].bookmarks?.length || 0;
      const bookmarklets = this[PRIVATE.STATE].bookmarklets?.length || 0;
      cacheHitRate.textContent = total > 0 ? `${((bookmarklets / total) * 100).toFixed(1)}%` : '0%';
    }

    if (cacheOrphaned) {
      cacheOrphaned.textContent = '0';
    }

    if (cacheVersion) {
      cacheVersion.textContent = '2.0.6';
    }
  }

  [PRIVATE.UPDATE_TIME]() {
    const now = new Date();
    const timeEl = document.getElementById('footer-time');
    const updateEl = document.getElementById('last-update');

    if (timeEl) {
      timeEl.textContent = now.toLocaleTimeString();
    }
    if (updateEl) {
      updateEl.textContent = now.toLocaleString();
    }
  }

  // ============================================================
  // 20. СВЯЗЬ С BACKGROUND
  // ============================================================

  async [PRIVATE.CHECK_BACKGROUND](force = false) {
    const logger = this[PRIVATE.LOGGER];

    if (this[PRIVATE.STATE].backgroundReady && !force) {
      return true;
    }

    try {
      if (!chrome?.runtime?.id) {
        logger.debug('❌ Chrome runtime не доступен');
        this[PRIVATE.STATE].backgroundReady = false;
        this[PRIVATE.UPDATE_CONNECTION_STATUS](false);
        return false;
      }

      logger.debug(`🔄 Проверка background (попытка ${this[PRIVATE.STATE].backgroundAttempts + 1})...`);

      const response = await Promise.race([
        chrome.runtime.sendMessage({ action: 'ping' }),
        new Promise((_, reject) => setTimeout(() => reject(new Error('Таймаут')), 3000)),
      ]);

      if (response && response.status === 'ok') {
        this[PRIVATE.STATE].backgroundReady = true;
        this[PRIVATE.STATE].backgroundAttempts = 0;
        logger.success('✅ Background готов к работе');
        this[PRIVATE.UPDATE_CONNECTION_STATUS](true);
        return true;
      }

      this[PRIVATE.STATE].backgroundReady = false;
      return false;
    } catch (error) {
      this[PRIVATE.STATE].backgroundAttempts++;

      if (this[PRIVATE.STATE].backgroundAttempts < this[PRIVATE.STATE].maxAttempts) {
        logger.debug(`⏳ Ожидание background (попытка ${this[PRIVATE.STATE].backgroundAttempts})...`);
        await new Promise((resolve) => setTimeout(resolve, 1000));
        return this[PRIVATE.CHECK_BACKGROUND](force);
      }

      logger.warn('⚠️ Background не отвечает, используем fallback режим');
      this[PRIVATE.STATE].backgroundReady = false;
      this[PRIVATE.UPDATE_CONNECTION_STATUS](false);
      return false;
    }
  }

  async [PRIVATE.SAFE_SEND_MESSAGE](message, timeout = 5000) {
    if (!chrome?.runtime?.id) {
      throw new Error('Chrome runtime не доступен');
    }

    if (!this[PRIVATE.STATE].backgroundReady) {
      const ready = await this[PRIVATE.CHECK_BACKGROUND](true);
      if (!ready) {
        throw new Error('Background не готов');
      }
    }

    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        reject(new Error('Таймаут ответа от background'));
      }, timeout);

      chrome.runtime.sendMessage(message, (response) => {
        clearTimeout(timer);
        if (chrome.runtime.lastError) {
          this[PRIVATE.STATE].backgroundReady = false;
          reject(new Error(chrome.runtime.lastError.message));
        } else {
          resolve(response);
        }
      });
    });
  }

  [PRIVATE.UPDATE_CONNECTION_STATUS](isConnected) {
    const statusEl = document.getElementById('connection-status');
    const footerStatus = document.getElementById('footer-status');

    if (statusEl) {
      statusEl.textContent = isConnected ? '🟢 Подключено' : '🔴 Офлайн';
      statusEl.className = 'info-value';
    }

    if (footerStatus) {
      footerStatus.textContent = isConnected ? '🟢 Активно' : '🔴 Офлайн';
      footerStatus.className = isConnected ? 'online' : 'offline';
    }
  }

  // ============================================================
  // 21. УТИЛИТЫ
  // ============================================================

  [PRIVATE.GET_FAVICON_URL](url) {
    if (!url) return null;
    try {
      const urlObj = new URL(url);
      return `${urlObj.origin}/favicon.ico`;
    } catch {
      return null;
    }
  }

  [PRIVATE.GET_FALLBACK_COLOR](url) {
    if (!url) return '#667eea';
    let hash = 0;
    for (let i = 0; i < url.length; i++) {
      hash = url.charCodeAt(i) + ((hash << 5) - hash);
    }
    const colors = [
      '#667eea',
      '#764ba2',
      '#00b894',
      '#fdcb6e',
      '#ff6b6b',
      '#74b9ff',
      '#fd79a8',
      '#00cec9',
      '#6c5ce7',
      '#f39c12',
      '#e17055',
      '#0984e3',
    ];
    return colors[Math.abs(hash) % colors.length];
  }

  [PRIVATE.ESCAPE_HTML](text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }

  [PRIVATE.SHOW_TOAST](message, type = 'info') {
    let toast = document.getElementById('toast');
    if (!toast) {
      toast = document.createElement('div');
      toast.id = 'toast';
      toast.style.cssText = `
                position: fixed;
                bottom: 20px;
                left: 50%;
                transform: translateX(-50%);
                background: rgba(0, 0, 0, 0.9);
                backdrop-filter: blur(8px);
                padding: 10px 24px;
                border-radius: 8px;
                border: 1px solid rgba(255, 255, 255, 0.1);
                color: #fff;
                font-size: 13px;
                z-index: 99999;
                opacity: 0;
                transition: opacity 0.3s ease;
                pointer-events: none;
                max-width: 90vw;
                text-align: center;
                font-family: 'Segoe UI', system-ui, sans-serif;
            `;
      document.body.appendChild(toast);
    }

    const colors = {
      success: '#00b894',
      error: '#ff6b6b',
      warn: '#fdcb6e',
      info: '#667eea',
    };

    toast.style.borderColor = colors[type] || colors.info;
    toast.textContent = message;
    toast.style.opacity = '1';

    if (this[PRIVATE.TOAST_TIMER]) {
      clearTimeout(this[PRIVATE.TOAST_TIMER]);
    }
    this[PRIVATE.TOAST_TIMER] = setTimeout(() => {
      toast.style.opacity = '0';
      this[PRIVATE.TOAST_TIMER] = null;
    }, 3000);
  }

  // ============================================================
  // 22. УПРАВЛЕНИЕ НАСТРОЙКАМИ
  // ============================================================

  [PRIVATE.SAVE_SETTINGS]() {
    const bridgeEnabled = document.getElementById('bridge-enabled');
    const autoRespond = document.getElementById('auto-respond');
    const timeout = document.getElementById('timeout');
    const cacheTTL = document.getElementById('cache-ttl');
    const debugMode = document.getElementById('debug-mode');
    const logLevel = document.getElementById('log-level');
    const maxLogs = document.getElementById('max-logs');

    const settings = this[PRIVATE.STATE].settings;

    settings.bridgeEnabled = bridgeEnabled ? bridgeEnabled.checked : true;
    settings.autoRespond = autoRespond ? autoRespond.checked : true;
    settings.timeout = timeout ? parseInt(timeout.value) || 5000 : 5000;
    settings.cacheTTL = cacheTTL ? parseInt(cacheTTL.value) || 30 : 30;
    settings.debugMode = debugMode ? debugMode.checked : false;
    settings.logLevel = logLevel ? logLevel.value : 'info';
    settings.maxLogs = maxLogs ? parseInt(maxLogs.value) || 100 : 100;

    this[PRIVATE.SAVE_STATE]();
    this[PRIVATE.ADD_LOG]('info', '💾 Настройки сохранены');
    this[PRIVATE.SHOW_TOAST]('✅ Настройки сохранены', 'success');
  }

  [PRIVATE.RESET_SETTINGS]() {
    if (!confirm('Сбросить все настройки?')) return;

    this[PRIVATE.STATE].settings = { ...DEFAULT_SETTINGS };
    this[PRIVATE.STATE].stats = { ...DEFAULT_STATS };
    this[PRIVATE.STATE].logs = [];

    this[PRIVATE.SETUP_UI]();
    this[PRIVATE.SAVE_STATE]();
    this[PRIVATE.UPDATE_STATS]();
    this[PRIVATE.RENDER_LOGS]();
    this[PRIVATE.ADD_LOG]('info', '↺ Настройки сброшены');
    this[PRIVATE.SHOW_TOAST]('↺ Настройки сброшены', 'info');
  }

  // ============================================================
  // 23. УПРАВЛЕНИЕ КЕШЕМ
  // ============================================================

  [PRIVATE.CLEAR_CACHE]() {
    if (!confirm('Очистить кеш закладок?')) return;

    localStorage.removeItem(this[PRIVATE.CONFIG].bookmarksCacheKey);
    this[PRIVATE.STATE].allBookmarks = [];
    this[PRIVATE.STATE].bookmarks = [];
    this[PRIVATE.STATE].stats.cacheSize = 0;

    this[PRIVATE.UPDATE_STATS]();
    this[PRIVATE.RENDER_BOOKMARKS]();
    this[PRIVATE.ADD_LOG]('info', '🗑️ Кеш очищен');
    this[PRIVATE.SHOW_TOAST]('🗑️ Кеш очищен', 'success');
  }

  // ============================================================
  // 24. УПРАВЛЕНИЕ БУКМАРКЛЕТАМИ
  // ============================================================

  [PRIVATE.GENERATE_ALL_BOOKMARKLETS]() {
    this[PRIVATE.ADD_LOG]('info', '📦 Генерация всех стандартных букмарклетов...');
    this[PRIVATE.SHOW_TOAST]('📦 Генерация букмарклетов...', 'info');

    // Используем генератор из background
    if (window.__backgroundInstance?.getGenerator) {
      const generator = window.__backgroundInstance.getGenerator();
      if (generator && generator.generateAllTemplates) {
        const result = generator.generateAllTemplates();
        this[PRIVATE.ADD_LOG]('success', `✅ Сгенерировано ${result?.length || 0} букмарклетов`);
        this[PRIVATE.SHOW_TOAST](`✅ Сгенерировано ${result?.length || 0} букмарклетов`, 'success');
        this[PRIVATE.RENDER_BOOKMARKLETS]();
        return;
      }
    }

    // Fallback - создаем тестовые
    this[PRIVATE.CREATE_TEST_BOOKMARKS]();
    this[PRIVATE.ADD_LOG]('success', '✅ Тестовые букмарклеты созданы');
    this[PRIVATE.SHOW_TOAST]('✅ Тестовые букмарклеты созданы', 'success');
  }

  [PRIVATE.UPDATE_BOOKMARKLETS_WITH_HASH]() {
    this[PRIVATE.ADD_LOG]('info', '🔄 Обновление букмарклетов с проверкой хеша...');
    this[PRIVATE.SHOW_TOAST]('🔄 Обновление букмарклетов...', 'info');

    if (window.__bookmarkController) {
      const controller = window.__bookmarkController;
      if (controller.updateAllBookmarkletsWithHashCheck) {
        controller.updateAllBookmarkletsWithHashCheck().then((result) => {
          this[PRIVATE.ADD_LOG](
              'success',
              `✅ Обновлено: ${result.updated}, без изменений: ${result.unchanged}`
          );
          this[PRIVATE.SHOW_TOAST](
              `✅ Обновлено: ${result.updated}, без изменений: ${result.unchanged}`,
              'success'
          );
          this[PRIVATE.RENDER_BOOKMARKLETS]();
        });
        return;
      }
    }

    this[PRIVATE.ADD_LOG]('warn', '⚠️ Контроллер букмарклетов не доступен');
    this[PRIVATE.SHOW_TOAST]('⚠️ Контроллер букмарклетов не доступен', 'warn');
  }

  [PRIVATE.CLEAR_BOOKMARKLET_CACHE]() {
    if (!confirm('Очистить кеш букмарклетов?')) return;

    if (window.__bookmarkController) {
      const controller = window.__bookmarkController;
      if (controller.clearCache) {
        const result = controller.clearCache();
        this[PRIVATE.ADD_LOG]('info', `🗑️ Кеш очищен (${result.cleared} записей)`);
        this[PRIVATE.SHOW_TOAST](`🗑️ Кеш очищен (${result.cleared} записей)`, 'success');
        this[PRIVATE.RENDER_BOOKMARKLETS]();
        return;
      }
    }

    try {
      localStorage.removeItem('bookmarklet-generator-data');
      localStorage.removeItem('bookmarklet-bookmarks-cache');
      this[PRIVATE.ADD_LOG]('info', '🗑️ Кеш очищен');
      this[PRIVATE.SHOW_TOAST]('🗑️ Кеш очищен', 'success');
      this[PRIVATE.RENDER_BOOKMARKLETS]();
    } catch (e) {
      this[PRIVATE.ADD_LOG]('error', `❌ Ошибка: ${e.message}`);
      this[PRIVATE.SHOW_TOAST]('❌ Ошибка очистки кеша', 'error');
    }
  }

  [PRIVATE.DELETE_ALL_BOOKMARKLETS]() {
    if (!confirm('⚠️ Удалить все букмарклеты?')) return;

    if (window.__bookmarkController) {
      const controller = window.__bookmarkController;
      if (controller.deleteAllBookmarklets) {
        controller.deleteAllBookmarklets().then((result) => {
          this[PRIVATE.ADD_LOG]('info', `🗑️ Удалено ${result.deleted} букмарклетов`);
          this[PRIVATE.SHOW_TOAST](`🗑️ Удалено ${result.deleted} букмарклетов`, 'success');
          this[PRIVATE.RENDER_BOOKMARKLETS]();
        });
        return;
      }
    }

    this[PRIVATE.ADD_LOG]('warn', '⚠️ Контроллер букмарклетов не доступен');
    this[PRIVATE.SHOW_TOAST]('⚠️ Контроллер букмарклетов не доступен', 'warn');
  }

  [PRIVATE.COPY_BOOKMARKLET_CODE]() {
    const display = document.getElementById('bookmarklet-code-display');
    if (!display || !display.textContent || display.textContent === 'Выберите букмарклет из списка') {
      this[PRIVATE.SHOW_TOAST]('⚠️ Сначала выберите букмарклет', 'warn');
      return;
    }

    const code = display.textContent;
    navigator.clipboard
        .writeText('javascript:' + code)
        .then(() => {
          this[PRIVATE.ADD_LOG]('success', '📋 Код букмарклета скопирован');
          this[PRIVATE.SHOW_TOAST]('📋 Код букмарклета скопирован', 'success');
        })
        .catch(() => {
          this[PRIVATE.ADD_LOG]('error', '❌ Не удалось скопировать код');
          this[PRIVATE.SHOW_TOAST]('❌ Не удалось скопировать код', 'error');
        });
  }

  [PRIVATE.UPDATE_BOOKMARKLET_CACHE_STATS]() {
    try {
      const cached = localStorage.getItem('bookmarklet-bookmarks-cache');
      const data = cached ? JSON.parse(cached) : null;

      const total = document.getElementById('cache-total');
      const hitRate = document.getElementById('cache-hit-rate');
      const orphaned = document.getElementById('cache-orphaned');
      const version = document.getElementById('cache-version');

      if (total) total.textContent = data?.all?.length || 0;
      if (hitRate) {
        const bookmarks = this[PRIVATE.STATE].bookmarks?.length || 0;
        const bookmarklets = this[PRIVATE.STATE].bookmarklets?.length || 0;
        hitRate.textContent = bookmarks > 0 ? `${((bookmarklets / bookmarks) * 100).toFixed(1)}%` : '0%';
      }
      if (orphaned) orphaned.textContent = '0';
      if (version) version.textContent = '2.0.6';
    } catch (e) {
      // Игнорируем
    }
  }

  // ============================================================
  // 25. ЭКСПОРТ ЗАКЛАДОК
  // ============================================================

  [PRIVATE.EXPORT_BOOKMARKS]() {
    const data = {
      timestamp: new Date().toISOString(),
      total: this[PRIVATE.STATE].bookmarks.length,
      bookmarklets: this[PRIVATE.STATE].bookmarklets,
      folders: this[PRIVATE.STATE].folders,
      bookmarks: this[PRIVATE.STATE].bookmarks,
      version: this[PRIVATE.VERSION],
    };

    const json = JSON.stringify(data, null, 2);
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `bookmarks-${new Date().toISOString().slice(0, 19).replace(/[:.]/g, '-')}.json`;
    a.click();
    URL.revokeObjectURL(url);

    this[PRIVATE.ADD_LOG]('info', `📤 Экспортировано ${this[PRIVATE.STATE].bookmarks.length} закладок`);
    this[PRIVATE.SHOW_TOAST]('📤 Экспорт выполнен', 'success');
  }

  // ============================================================
  // 26. ИНФОРМАЦИЯ О ВКЛАДКЕ
  // ============================================================

  [PRIVATE.UPDATE_TAB_INFO]() {
    if (typeof chrome === 'undefined' || !chrome.tabs) {
      this[PRIVATE.ADD_LOG]('warn', '⚠️ Chrome tabs API не доступен');
      return;
    }

    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs.length === 0) return;
      const tab = tabs[0];

      const titleEl = document.getElementById('current-tab-title');
      const urlEl = document.getElementById('current-tab-url');

      if (titleEl) titleEl.textContent = tab.title || '—';
      if (urlEl) urlEl.textContent = tab.url || '—';

      // Проверяем, есть ли закладка
      if (tab.url) {
        chrome.bookmarks.search({ url: tab.url }, (results) => {
          const bookmarkEl = document.getElementById('current-bookmark-title');
          const typeEl = document.getElementById('current-bookmark-type');

          if (results && results.length > 0) {
            const bm = results[0];
            if (bookmarkEl) bookmarkEl.textContent = bm.title || '—';
            if (typeEl) {
              const isBookmarklet = bm.url && bm.url.startsWith('javascript:');
              typeEl.textContent = isBookmarklet ? '📌 букмарклет' : '🔗 закладка';
              typeEl.style.color = isBookmarklet ? '#667eea' : '#00b894';
            }
          } else {
            if (bookmarkEl) bookmarkEl.textContent = '❌ Нет закладки';
            if (typeEl) {
              typeEl.textContent = '—';
              typeEl.style.color = '#636e72';
            }
          }
        });
      }

      this[PRIVATE.ADD_LOG]('info', `📋 Обновлена информация о вкладке: ${tab.title}`);
    });
  }

  // ============================================================
  // 27. ОТКРЫТИЕ ОКОН
  // ============================================================

  [PRIVATE.OPEN_PIP]() {
    if (typeof chrome === 'undefined' || !chrome.windows) {
      this[PRIVATE.ADD_LOG]('warn', '⚠️ Chrome windows API не доступен');
      return;
    }

    chrome.windows.create({
      url: 'popup.html',
      type: 'popup',
      width: 420,
      height: 600,
      focused: true,
    });

    this[PRIVATE.ADD_LOG]('info', '📌 Открыто закрепленное окно');
    this[PRIVATE.SHOW_TOAST]('📌 Окно открыто', 'success');
  }

  [PRIVATE.OPEN_MANAGER]() {
    const url = chrome.runtime.getURL('Bookmarklet/manager.html');
    chrome.tabs.create({ url, active: true });
    this[PRIVATE.ADD_LOG]('info', '📦 Открыт менеджер букмарклетов');
  }

  [PRIVATE.OPEN_INSTALL]() {
    const url = chrome.runtime.getURL('install.html');
    chrome.tabs.create({ url, active: true });
    this[PRIVATE.ADD_LOG]('info', '📥 Открыта страница установки');
  }

  [PRIVATE.OPEN_DEBUG]() {
    const url = chrome.runtime.getURL('Bookmarklet/debug-panel.html');
    chrome.tabs.create({ url, active: true });
    this[PRIVATE.ADD_LOG]('info', '🐛 Открыта debug панель');
  }

  [PRIVATE.OPEN_DEVTOOLS]() {
    const tabId = this[PRIVATE.STATE].devtoolsTabId;

    if (tabId) {
      chrome.tabs.update(tabId, { active: true });
      return;
    }

    chrome.windows.create({
      url: `chrome-extension://${chrome.runtime.id}/popup.html`,
      type: 'popup',
      width: 800,
      height: 600,
      focused: true,
    });

    this[PRIVATE.ADD_LOG]('info', '🔧 Открыты DevTools');
  }

  // ============================================================
  // 28. ПОЛУЧЕНИЕ КАНАЛА
  // ============================================================

  getChannel() {
    return window.__channel || window.__channelManager || null;
  }

  // ============================================================
  // 29. УПРАВЛЕНИЕ СОБЫТИЯМИ
  // ============================================================

  on(event, callback) {
    if (!this[PRIVATE.HANDLERS].has(event)) {
      this[PRIVATE.HANDLERS].set(event, []);
    }
    this[PRIVATE.HANDLERS].get(event).push(callback);
    return () => this.off(event, callback);
  }

  off(event, callback) {
    if (this[PRIVATE.HANDLERS].has(event)) {
      const handlers = this[PRIVATE.HANDLERS].get(event);
      const index = handlers.indexOf(callback);
      if (index !== -1) {
        handlers.splice(index, 1);
      }
      if (handlers.length === 0) {
        this[PRIVATE.HANDLERS].delete(event);
      }
    }
  }

  emit(event, data) {
    if (this[PRIVATE.HANDLERS].has(event)) {
      const handlers = this[PRIVATE.HANDLERS].get(event);
      for (const callback of handlers) {
        try {
          callback(data);
        } catch (error) {
          this[PRIVATE.ADD_LOG]('error', `❌ Ошибка в обработчике ${event}: ${error.message}`);
        }
      }
    }
  }

  // ============================================================
  // 30. ПОЛУЧЕНИЕ СОСТОЯНИЯ
  // ============================================================

  getState() {
    return {
      id: this[PRIVATE.STATE].instanceId || 'popup',
      version: this[PRIVATE.VERSION],
      build: this[PRIVATE.BUILD],
      initialized: this[PRIVATE.INITIALIZED],
      isOpen: this[PRIVATE.STATE].isOpen,
      isDestroyed: this[PRIVATE.IS_DESTROYED],
      backgroundReady: this[PRIVATE.STATE].backgroundReady,
      settings: { ...this[PRIVATE.STATE].settings },
      stats: { ...this[PRIVATE.STATE].stats },
      logsCount: this[PRIVATE.STATE].logs.length,
      bookmarksCount: this[PRIVATE.STATE].bookmarks.length,
      bookmarkletsCount: this[PRIVATE.STATE].bookmarklets.length,
      foldersCount: this[PRIVATE.STATE].folders.length,
      activeTab: this[PRIVATE.ACTIVE_TAB],
      timersCount: this[PRIVATE.TIMERS].size,
      handlersCount: this[PRIVATE.HANDLERS].size,
      cacheSize: this[PRIVATE.CACHE].size,
    };
  }

  getBookmarks() {
    return [...this[PRIVATE.STATE].bookmarks];
  }

  getBookmarklets() {
    return [...this[PRIVATE.STATE].bookmarklets];
  }

  getFolders() {
    return [...this[PRIVATE.STATE].folders];
  }

  getLogger() {
    return this[PRIVATE.LOGGER];
  }

  getConfig() {
    return { ...this[PRIVATE.CONFIG] };
  }

  getSettings() {
    return { ...this[PRIVATE.STATE].settings };
  }

  getStats() {
    return { ...this[PRIVATE.STATE].stats };
  }

  // ============================================================
  // 31. УНИЧТОЖЕНИЕ
  // ============================================================

  destroy() {
    if (this[PRIVATE.IS_DESTROYED]) return;

    const logger = this[PRIVATE.LOGGER];
    logger.warn('🗑️ Уничтожение Popup...');

    // Очищаем таймеры
    for (const [key, timer] of this[PRIVATE.TIMERS]) {
      clearInterval(timer);
      clearTimeout(timer);
    }
    this[PRIVATE.TIMERS].clear();

    // Очищаем слушатели
    this[PRIVATE.HANDLERS].clear();
    this[PRIVATE.LISTENERS].clear();

    // Очищаем кеш
    this[PRIVATE.CACHE].clear();

    // Удаляем глобальные ссылки
    if (typeof window !== 'undefined') {
      delete window.__popup;
      delete window[PUBLIC.API];
      delete window[PUBLIC.STATE];
      delete window[PUBLIC.CONFIG];
      delete window[PUBLIC.LOGGER];
      delete window[PUBLIC.INSTANCE];
      delete window[PUBLIC.EVENTS];
      delete window[PUBLIC.BOOKMARKS];
      delete window[PUBLIC.CHANNEL];
      delete window.__popupSymbols;
    }

    this[PRIVATE.IS_DESTROYED] = true;
    this[PRIVATE.INITIALIZED] = false;

    logger.success('✅ Popup уничтожен');
  }
}

// ============================================================
// 32. СОЗДАНИЕ ЭКЗЕМПЛЯРА
// ============================================================

let popupInstance = null;

function getPopupInstance(options = {}) {
  if (!popupInstance) {
    popupInstance = new Popup(options);
    if (typeof window !== 'undefined') {
      window.__popupInstance = popupInstance;
    }
  }
  return popupInstance;
}

// ============================================================
// 33. ИНИЦИАЛИЗАЦИЯ
// ============================================================

if (typeof window !== 'undefined') {
  const popup = getPopupInstance({
    debug: true,
    version: '2.0.6',
    build: '2026-07-22',
  });

  console.log('╔═══════════════════════════════════════════════════════════════════════════════╗');
  console.log('║              📦 POPUP (100% СИМВОЛЫ) v2.0.6                                 ║');
  console.log('╠═══════════════════════════════════════════════════════════════════════════════╣');
  console.log('║  📋 Все логи выводятся в консоль с цветовой разметкой                       ║');
  console.log('║  🔑 Полная изоляция через приватные символы                                 ║');
  console.log('║  🔓 Публичные символы через Symbol.for                                      ║');
  console.log('║  📑 Исправленное переключение табов                                         ║');
  console.log('║  📊 Логирование URL букмарклетов                                            ║');
  console.log('║  📦 Автономный режим с кешированием                                         ║');
  console.log('║  ✅ ИСПРАВЛЕНА: асинхронная загрузка букмарклетов из Chrome                 ║');
  console.log('║  ✅ ДОБАВЛЕН: await в loadBookmarksFromExtension()                          ║');
  console.log('╚═══════════════════════════════════════════════════════════════════════════════╝');

  console.log('📋 ДОСТУПНЫЕ КОМАНДЫ:');
  console.log('  __popup.getState()          - состояние');
  console.log('  __popup.getBookmarks()      - получить закладки');
  console.log('  __popup.getBookmarklets()   - получить букмарклеты');
  console.log('  __popup.getChannel()        - получить канал');
  console.log('  __popup.on(event, cb)       - подписка');
  console.log('  __popup.emit(event, data)   - событие');
  console.log('  __popup.destroy()           - уничтожить');
  console.log('');
  console.log('📋 ПРИВАТНЫХ СИМВОЛОВ:', Object.keys(PRIVATE).length);
  console.log('📋 ПУБЛИЧНЫХ СИМВОЛОВ:', Object.keys(PUBLIC).length);
  console.log('');

  // Автоматически логируем букмарклеты через 2 секунды
  setTimeout(() => {
    if (popup[PRIVATE.DEBUG_BOOKMARKLET_URLS]) {
      popup[PRIVATE.DEBUG_BOOKMARKLET_URLS]();
    }
  }, 2000);

  // Добавляем глобальную команду для быстрого доступа
  window.__debugBookmarklets = () => {
    if (popup[PRIVATE.DEBUG_BOOKMARKLET_URLS]) {
      popup[PRIVATE.DEBUG_BOOKMARKLET_URLS]();
    }
  };

  // Добавляем команду для логирования URL
  window.__logBookmarkletUrls = () => {
    if (popup[PRIVATE.LOG_BOOKMARKLET_URLS]) {
      popup[PRIVATE.LOG_BOOKMARKLET_URLS](popup[PRIVATE.STATE].bookmarks);
    }
  };

  console.log('📋 КОМАНДЫ ОТЛАДКИ БУКМАРКЛЕТОВ:');
  console.log('  window.__debugBookmarklets()  - получить все букмарклеты из Chrome');
  console.log('  window.__logBookmarkletUrls()  - логировать URL букмарклетов');
  console.log('');
  console.log('📌 Кнопки табов теперь работают!');
  console.log('   Переключение табов логируется в консоль.');
}

// ============================================================
// 34. ЭКСПОРТ
// ============================================================

export default Popup;
export { Popup, getPopupInstance, PRIVATE, PUBLIC };
