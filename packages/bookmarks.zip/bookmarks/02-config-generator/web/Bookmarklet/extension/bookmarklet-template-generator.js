// bookmarklet-template-generator.js - ИСПРАВЛЕННАЯ ВЕРСИЯ
// Версия: 2.0.3
// ИСПРАВЛЕНО: Ошибка "Cannot set property Symbol(wrapper.version) of #<BookmarkletTemplateGenerator> which has only a getter"
// Проблема: В классе BookmarkletTemplateGenerator используются геттеры для приватных свойств,
// но при создании экземпляра происходит попытка установить значения через эти геттеры.

// ============================================================
// 1. ИМПОРТЫ
// ============================================================

import TemplateGeneratorCore from './template-generator-core.js';

// ============================================================
// 2. ПРИВАТНЫЕ СИМВОЛЫ (100% изоляция)
// ============================================================

const PRIVATE = {
  // Основные символы
  CORE: Symbol('wrapper.core'),
  LOGGER: Symbol('wrapper.logger'),
  CONFIG: Symbol('wrapper.config'),
  CACHE: Symbol('wrapper.cache'),
  VERSION: Symbol('wrapper.version'),
  BUILD: Symbol('wrapper.build'),
  INITIALIZED: Symbol('wrapper.initialized'),
  IS_DESTROYED: Symbol('wrapper.isDestroyed'),

  // Данные
  NAME: Symbol('wrapper.name'),
  TYPE: Symbol('wrapper.type'),
  ID: Symbol('wrapper.id'),
  TIMESTAMP: Symbol('wrapper.timestamp'),

  // Шаблоны
  TEMPLATES: Symbol('wrapper.templates'),
  TEMPLATES_CACHE: Symbol('wrapper.templatesCache'),
  GENERATED_TEMPLATES: Symbol('wrapper.generatedTemplates'),

  // Статистика
  STATS: Symbol('wrapper.stats'),
  TOTAL_GENERATED: Symbol('wrapper.totalGenerated'),
  TOTAL_COMPRESSED: Symbol('wrapper.totalCompressed'),
  TOTAL_SAVED: Symbol('wrapper.totalSaved'),
  AVERAGE_RATIO: Symbol('wrapper.averageRatio'),
  CACHE_HITS: Symbol('wrapper.cacheHits'),
  CACHE_MISSES: Symbol('wrapper.cacheMisses'),

  // Метаданные
  METADATA: Symbol('wrapper.metadata'),
  CONTEXT: Symbol('wrapper.context'),
  LOG_HISTORY: Symbol('wrapper.logHistory'),

  // Слушатели
  LISTENERS: Symbol('wrapper.listeners'),
  EVENT_HANDLERS: Symbol('wrapper.eventHandlers'),

  // Безопасность
  SECURE: Symbol('wrapper.secure'),
  VALIDATOR: Symbol('wrapper.validator'),

  // Методы (приватные)
  CREATE_LOGGER: Symbol('wrapper.createLogger'),
  GENERATE_TEMPLATE: Symbol('wrapper.generateTemplate'),
  GENERATE_COMPRESSED: Symbol('wrapper.generateCompressed'),
  GENERATE_ALL: Symbol('wrapper.generateAll'),
  GET_TEMPLATE: Symbol('wrapper.getTemplate'),
  GET_TEMPLATE_BY_NAME: Symbol('wrapper.getTemplateByName'),
  GET_ALL_TEMPLATES: Symbol('wrapper.getAllTemplates'),
  DELETE_TEMPLATE: Symbol('wrapper.deleteTemplate'),
  CLEAR_ALL: Symbol('wrapper.clearAll'),
  GET_STATS: Symbol('wrapper.getStats'),
  EXPORT_JSON: Symbol('wrapper.exportJSON'),
  IMPORT_JSON: Symbol('wrapper.importJSON'),
  MINIFY: Symbol('wrapper.minify'),
  COMPRESS: Symbol('wrapper.compress'),
  GET_CODEC_STATUS: Symbol('wrapper.getCodecStatus'),
  ENSURE_CODEC_LOADED: Symbol('wrapper.ensureCodecLoaded'),
  RESET: Symbol('wrapper.reset'),
  DESTROY: Symbol('wrapper.destroy'),
  ON: Symbol('wrapper.on'),
  OFF: Symbol('wrapper.off'),
  EMIT: Symbol('wrapper.emit'),
  GET_STATE: Symbol('wrapper.getState'),
  // ★★★ НОВЫЙ СИМВОЛ ДЛЯ ИНИЦИАЛИЗАЦИИ ★★★
  INIT: Symbol('wrapper.init'),
};

// ============================================================
// 3. ПУБЛИЧНЫЕ СИМВОЛЫ (доступны через Symbol.for)
// ============================================================

const PUBLIC = {
  API: Symbol.for('template-wrapper.api'),
  STATE: Symbol.for('template-wrapper.state'),
  CONFIG: Symbol.for('template-wrapper.config'),
  LOGGER: Symbol.for('template-wrapper.logger'),
  GENERATOR: Symbol.for('template-wrapper.generator'),
  TEMPLATES: Symbol.for('template-wrapper.templates'),
  STATS: Symbol.for('template-wrapper.stats'),
  INSTANCE: Symbol.for('template-wrapper.instance'),
  EVENTS: Symbol.for('template-wrapper.events'),
};

// ============================================================
// 4. КОНФИГУРАЦИЯ
// ============================================================

const DEFAULT_CONFIG = {
  version: '2.0.3',
  build: '2026-07-19',
  debug: true,
  basePath: './Bookmarklet/',
  compression: {
    enabled: true,
    minify: true,
    removeComments: true,
    shortenVariables: true,
    compressBooleans: true,
    aggressiveCompression: true,
    maxUrlLength: 2000,
  },
  templates: {
    maxCacheSize: 100,
    autoCompress: true,
    defaultType: 'main',
  },
  types: ['env', 'logs', 'debug', 'manager', 'widget', 'sw', 'reset'],
};

// ============================================================
// 5. ЛОГГЕР С ПРИВЯЗКОЙ КОНТЕКСТА (100% СИМВОЛЫ)
// ============================================================

const LOGGER_SYMBOLS = {
  HISTORY: Symbol('logger.history'),
  MAX_HISTORY: Symbol('logger.maxHistory'),
  DEBUG: Symbol('logger.debug'),
  INSTANCE_ID: Symbol('logger.instanceId'),
};

function createLogger(debug = true, instanceId = 'TemplateWrapper') {
  const state = {
    [LOGGER_SYMBOLS.HISTORY]: [],
    [LOGGER_SYMBOLS.MAX_HISTORY]: 200,
    [LOGGER_SYMBOLS.DEBUG]: debug,
    [LOGGER_SYMBOLS.INSTANCE_ID]: instanceId,
  };

  const logMethod = function (level, message, data = null) {
    if (!this[LOGGER_SYMBOLS.DEBUG] && level !== 'error') {
      return;
    }

    const timestamp = new Date().toISOString().slice(11, 23);
    const prefix = `[${timestamp}] [${this[LOGGER_SYMBOLS.INSTANCE_ID]}]`;

    this[LOGGER_SYMBOLS.HISTORY].push({ timestamp, level, message, data });
    if (this[LOGGER_SYMBOLS.HISTORY].length > this[LOGGER_SYMBOLS.MAX_HISTORY]) {
      this[LOGGER_SYMBOLS.HISTORY].shift();
    }

    if (data !== null && data !== undefined) {
      console.log(`${prefix} ${message}`, data);
    } else {
      console.log(`${prefix} ${message}`);
    }
  };

  const boundLog = logMethod.bind(state);

  const methods = {
    error (msg, d) {
      boundLog('error', `❌ ${msg}`, d);
    },
    warn (msg, d) {
      boundLog('warn', `⚠️ ${msg}`, d);
    },
    info (msg, d) {
      boundLog('info', `ℹ️ ${msg}`, d);
    },
    debug (msg, d) {
      boundLog('debug', `🔍 ${msg}`, d);
    },
    success (msg, d) {
      boundLog('info', `✅ ${msg}`, d);
    },

    header (title) {
      console.log('%c' + '═'.repeat(70), 'color: #636e72;');
      console.log(
        '%c  📦 ' + title,
        'background: #1a1a2e; color: #fff; padding: 4px 12px; border-radius: 4px; font-weight: bold;',
      );
      console.log('%c' + '═'.repeat(70), 'color: #636e72;');
    },

    separator () {
      console.log('%c' + '─'.repeat(70), 'color: #636e72;');
    },

    symbol (name, symbol) {
      console.log(`  🔑 ${name}: ${String(symbol)}`);
    },

    private (name, symbol) {
      console.log(`  🔒 ${name}: ${String(symbol)}`);
    },

    getHistory () {
      return [...this[LOGGER_SYMBOLS.HISTORY]];
    },

    clearHistory () {
      this[LOGGER_SYMBOLS.HISTORY] = [];
      return this;
    },

    setDebug (enabled) {
      this[LOGGER_SYMBOLS.DEBUG] = enabled;
      return this;
    },
  };

  const logger = {};
  for (const [key, fn] of Object.entries(methods)) {
    logger[key] = fn.bind(state);
  }

  logger[LOGGER_SYMBOLS.HISTORY] = state[LOGGER_SYMBOLS.HISTORY];
  logger[LOGGER_SYMBOLS.MAX_HISTORY] = state[LOGGER_SYMBOLS.MAX_HISTORY];
  logger[LOGGER_SYMBOLS.DEBUG] = state[LOGGER_SYMBOLS.DEBUG];
  logger[LOGGER_SYMBOLS.INSTANCE_ID] = state[LOGGER_SYMBOLS.INSTANCE_ID];

  return logger;
}

// ============================================================
// 6. ВАЛИДАТОР (с приватными символами)
// ============================================================

const VALIDATOR = {
  [PRIVATE.VALIDATOR]: {
    isValidId: id => id && typeof id === 'string' && id.length > 0,
    isValidType: type =>
      ['main', 'env', 'logs', 'debug', 'manager', 'widget', 'sw', 'reset'].includes(type),
    isValidName: name => name && typeof name === 'string' && name.length > 0,
    isValidConfig: config => config && typeof config === 'object',
    isValidCode: code => code && typeof code === 'string' && code.length > 0,
    isValidCallback: fn => typeof fn === 'function',
  },
  [PRIVATE.SECURE]: {
    sanitize: value => {
      if (value === null || value === undefined) {
        return null;
      }
      if (typeof value === 'string') {
        return value.replace(/[<>]/g, '');
      }
      if (typeof value === 'object') {
        try {
          return JSON.parse(JSON.stringify(value));
        } catch {
          return null;
        }
      }
      return value;
    },
    validate: (value, schema) => {
      if (!schema) {
        return true;
      }
      if (schema.type && typeof value !== schema.type) {
        return false;
      }
      if (schema.min !== undefined && value < schema.min) {
        return false;
      }
      if (schema.max !== undefined && value > schema.max) {
        return false;
      }
      if (schema.pattern && !schema.pattern.test(value)) {
        return false;
      }
      return true;
    },
  },
};

// ============================================================
// 7. ОСНОВНОЙ КЛАСС ОБЕРТКИ (100% СИМВОЛЫ) - ИСПРАВЛЕНО
// ============================================================

class BookmarkletTemplateGenerator {
  constructor(options = {}) {
    // ============================================================
    // 7.1 ★★★ ИНИЦИАЛИЗАЦИЯ - ИСПОЛЬЗУЕМ МЕТОД init ★★★
    // ============================================================

    this[PRIVATE.INIT](options);
  }

  // ============================================================
  // 7.2 ★★★ МЕТОД ИНИЦИАЛИЗАЦИИ (ВЫНЕСЕН В ОТДЕЛЬНЫЙ МЕТОД) ★★★
  // ============================================================

  [PRIVATE.INIT](options) {
    // ============================================================
    // 7.2.1 ВЕРСИЯ И СБОРКА
    // ============================================================

    // ★★★ ИСПРАВЛЕНИЕ: Используем _ для внутренних свойств ★★★
    // Вместо геттеров используем обычные свойства
    this._version = options.version || DEFAULT_CONFIG.version;
    this._build = options.build || DEFAULT_CONFIG.build;

    // ============================================================
    // 7.2.2 КОНФИГУРАЦИЯ
    // ============================================================

    this._config = {
      ...DEFAULT_CONFIG,
      ...options,
      compression: { ...DEFAULT_CONFIG.compression, ...options.compression },
      templates: { ...DEFAULT_CONFIG.templates, ...options.templates },
    };

    // ============================================================
    // 7.2.3 ЛОГГЕР
    // ============================================================

    this._logger = createLogger(this._config.debug !== false, 'TemplateWrapper');
    const logger = this._logger;

    // ============================================================
    // 7.2.4 ОСНОВНЫЕ ДАННЫЕ
    // ============================================================

    this._name = options.name || 'BookmarkletTemplateGenerator';
    this._type = options.type || 'main';
    this._id = options.id || 'bmt-' + Date.now() + '-' + Math.random().toString(36).substr(2, 4);
    this._timestamp = Date.now();

    // ============================================================
    // 7.2.5 СОЗДАНИЕ ЯДРА
    // ============================================================

    logger.info('📦 Создание ядра TemplateGeneratorCore...');

    this._core = new TemplateGeneratorCore({
      debug: this._config.debug,
      basePath: this._config.basePath,
      version: this._version,
      compression: this._config.compression,
    });

    logger.success('✅ Ядро создано');

    // ============================================================
    // 7.2.6 ХРАНИЛИЩА
    // ============================================================

    this._cache = new Map();
    this._templates = new Map();
    this._templatesCache = new Map();
    this._generatedTemplates = [];
    this._listeners = [];
    this._eventHandlers = new Map();
    this._logHistory = [];

    // ============================================================
    // 7.2.7 СТАТИСТИКА
    // ============================================================

    this._stats = {
      totalGenerated: 0,
      totalCompressed: 0,
      totalSaved: 0,
      averageRatio: 0,
      cacheHits: 0,
      cacheMisses: 0,
    };
    this._totalGenerated = 0;
    this._totalCompressed = 0;
    this._totalSaved = 0;
    this._averageRatio = 0;
    this._cacheHits = 0;
    this._cacheMisses = 0;

    // ============================================================
    // 7.2.8 МЕТАДАННЫЕ
    // ============================================================

    this._metadata = {
      created: Date.now(),
      lastAccess: Date.now(),
      lastUpdate: Date.now(),
      generateCount: 0,
      errorCount: 0,
    };

    this._context = {
      url: typeof window !== 'undefined' ? window.location.href : '',
      title: typeof window !== 'undefined' ? document.title : '',
      userAgent: typeof navigator !== 'undefined' ? navigator.userAgent : '',
      origin: typeof window !== 'undefined' ? window.location.origin : '',
    };

    // ============================================================
    // 7.2.9 ФЛАГИ
    // ============================================================

    this._initialized = true;
    this._isDestroyed = false;

    // ============================================================
    // 7.2.10 ЭКСПОРТ СИМВОЛОВ
    // ============================================================

    this._exportSymbols();

    // ============================================================
    // 7.2.11 ЛОГИРОВАНИЕ
    // ============================================================

    logger.header('СОЗДАНИЕ ОБЕРТКИ ГЕНЕРАТОРА ШАБЛОНОВ (100% СИМВОЛЫ)');
    logger.info(`📦 Версия: ${this._version}`);
    logger.info(`📅 Сборка: ${this._build}`);
    logger.info(`📌 Имя: ${this._name}`);
    logger.info(`📌 Тип: ${this._type}`);
    logger.info(`📌 ID: ${this._id}`);
    logger.info(`📌 Путь: ${this._config.basePath}`);

    const codecStatus = this._core.getCodecStatus();
    logger.info(`📌 Кодек: ${codecStatus.ready ? '✅ готов' : '⏳ загружается'}`);

    logger.separator();
    logger.info(`🔑 ПРИВАТНЫХ СИМВОЛОВ: ${Object.keys(PRIVATE).length}`);
    logger.info(`🔑 ПУБЛИЧНЫХ СИМВОЛОВ: ${Object.keys(PUBLIC).length}`);
    logger.separator();

    logger.success('✅ Обертка генератора шаблонов создана (100% символы)');
    logger.header('ГОТОВ');
  }

  // ============================================================
  // 8. ЭКСПОРТ СИМВОЛОВ
  // ============================================================

  _exportSymbols() {
    if (typeof window !== 'undefined') {
      window.__templateWrapper = this;
      window[PUBLIC.API] = this;
      window[PUBLIC.STATE] = this.getState.bind(this);
      window[PUBLIC.CONFIG] = this._config;
      window[PUBLIC.LOGGER] = this._logger;
      window[PUBLIC.GENERATOR] = this;
      window[PUBLIC.TEMPLATES] = this.getAllTemplates.bind(this);
      window[PUBLIC.STATS] = this.getStats.bind(this);
      window[PUBLIC.INSTANCE] = this;
      window[PUBLIC.EVENTS] = {
        on: this.on.bind(this),
        off: this.off.bind(this),
        emit: this.emit.bind(this),
      };

      window.__templateWrapperSymbols = {
        PRIVATE: { ...PRIVATE },
        PUBLIC: { ...PUBLIC },
        version: this._version,
        build: this._build,
      };
    }
  }

  // ============================================================
  // 9. ДЕЛЕГИРОВАНИЕ МЕТОДОВ ЯДРУ
  // ============================================================

  minify(code) {
    return this._minify(code);
  }

  _minify(code) {
    const logger = this._logger;
    logger.debug('🔧 Минификация кода...');

    try {
      const result = this._core.minify(code);
      return result;
    } catch (error) {
      logger.error('❌ Ошибка минификации:', error.message);
      return code;
    }
  }

  compress(code) {
    return this._compress(code);
  }

  _compress(code) {
    const logger = this._logger;
    logger.debug('🗜️ Сжатие кода для URL...');

    try {
      const result = this._core.compress(code);
      return result;
    } catch (error) {
      logger.error('❌ Ошибка сжатия:', error.message);
      return 'javascript:' + encodeURIComponent(code.replace(/^javascript:/i, ''));
    }
  }

  getCodecStatus() {
    return this._core.getCodecStatus();
  }

  async ensureCodecLoaded() {
    return this._core.ensureCodecLoaded();
  }

  // ============================================================
  // 10. ГЕНЕРАЦИЯ ШАБЛОНОВ
  // ============================================================

  generateTemplate(bookmarkData, options = {}) {
    return this._generateTemplate(bookmarkData, options);
  }

  _generateTemplate(bookmarkData, options = {}) {
    const logger = this._logger;
    const title = bookmarkData?.title || options.title || 'Bookmarklet';
    const type = options.type || this._config.templates.defaultType || 'main';
    const componentId = options.componentId || 'bm-' + Date.now() + '-' + Math.random().toString(36).substr(2, 4);
    const version = options.version || this._version;
    const debug = options.debug !== false;

    logger.info(`📝 Генерация шаблона: "${title}" (${type})`);

    try {
      // Генерируем код через ядро
      const code = this._generateCode(title, type, componentId, version, debug);

      const template = {
        id: componentId,
        componentId,
        title,
        type,
        code,
        version,
        generated: Date.now(),
        generatedISO: new Date().toISOString(),
        debug,
        size: code.length,
      };

      // Сохраняем в кеш
      this._templates.set(componentId, template);
      this._generatedTemplates.push(template);

      // Обновляем статистику
      this._totalGenerated++;
      this._metadata.generateCount++;
      this._stats.totalGenerated++;

      logger.success(`✅ Шаблон "${title}" сгенерирован`);
      logger.info(`📊 Размер: ${code.length} байт`);

      return template;
    } catch (error) {
      logger.error(`❌ Ошибка генерации "${title}":`, error.message);
      this._metadata.errorCount++;
      return null;
    }
  }

  _generateCode(title, type, componentId, version, debug) {
    const basePath = this._config.basePath;
    const config = this._config;

    // ★★★ ШАБЛОН С CALLBACK ★★★
    return `javascript:import('./Bookmarklet/bookmarklet.js').then(m=>m.default({name:'${title.replace(/'/g, "\\'")}',type:'${type}',id:'${componentId}',version:'${version}',callback:(r)=>console.log('✅',r)}))`;
  }

  // ============================================================
  // 11. ГЕНЕРАЦИЯ СЖАТОГО ШАБЛОНА
  // ============================================================

  generateCompressedTemplate(bookmarkData, options = {}) {
    return this._generateCompressed(bookmarkData, options);
  }

  _generateCompressed(bookmarkData, options = {}) {
    const logger = this._logger;
    const template = this._generateTemplate(bookmarkData, options);

    if (!template) {
      logger.error('❌ Не удалось сгенерировать шаблон');
      return null;
    }

    logger.info(`🗜️ Сжатие шаблона: "${template.title}"`);

    const compressed = this._compress(template.code);

    const result = {
      ...template,
      compressed,
      compression: {
        originalSize: template.code.length,
        compressedSize: compressed.length,
        saved: template.code.length - compressed.length,
        ratio: ((1 - compressed.length / template.code.length) * 100).toFixed(1),
      },
    };

    // Сохраняем в кеш сжатых шаблонов
    this._templatesCache.set(template.id, result);
    this._totalCompressed++;
    this._stats.totalCompressed++;

    logger.success(`✅ Шаблон "${template.title}" сжат`);
    logger.info(`📊 Сжатие: ${result.compression.saved} байт (${result.compression.ratio}%)`);

    return result;
  }

  // ============================================================
  // 12. ГЕНЕРАЦИЯ ВСЕХ ШАБЛОНОВ
  // ============================================================

  generateAllTemplates(options = {}) {
    return this._generateAll(options);
  }

  _generateAll(options = {}) {
    const logger = this._logger;
    logger.header('ГЕНЕРАЦИЯ ВСЕХ ШАБЛОНОВ');

    const types = this._config.types || [
      { name: 'ENV Control', type: 'env' },
      { name: 'Logs Control', type: 'logs' },
      { name: 'Debug Control', type: 'debug' },
      { name: 'Manager', type: 'manager' },
      { name: 'Widget', type: 'widget' },
    ];

    const results = [];
    const compress = options.compress !== false;

    for (const t of types) {
      const template = compress
        ? this._generateCompressed(
          { title: t.name },
          { type: t.type, title: t.name, ...options },
        )
        : this._generateTemplate(
          { title: t.name },
          { type: t.type, title: t.name, ...options },
        );
      if (template) {
        results.push(template);
      }
    }

    logger.success(`✅ Сгенерировано ${results.length} шаблонов`);

    const avgSize =
        results.length > 0
          ? (results.reduce((sum, r) => sum + r.code.length, 0) / results.length / 1024).toFixed(2)
          : 0;
    logger.info(`📊 Средний размер: ${avgSize} KB`);

    return results;
  }

  // ============================================================
  // 13. ПОЛУЧЕНИЕ ШАБЛОНОВ
  // ============================================================

  getTemplate(id) {
    return this._getTemplate(id);
  }

  _getTemplate(id) {
    if (this._templates.has(id)) {
      return this._templates.get(id);
    }
    if (this._templatesCache.has(id)) {
      return this._templatesCache.get(id);
    }
    return null;
  }

  getTemplateByName(name) {
    return this._getTemplateByName(name);
  }

  _getTemplateByName(name) {
    for (const [id, template] of this._templates) {
      if (template.title === name) {
        return template;
      }
    }
    for (const [id, template] of this._templatesCache) {
      if (template.title === name) {
        return template;
      }
    }
    return null;
  }

  getAllTemplates() {
    return this._getAllTemplates();
  }

  _getAllTemplates() {
    const all = [];
    for (const [id, template] of this._templates) {
      all.push(template);
    }
    for (const [id, template] of this._templatesCache) {
      if (!all.find(t => t.id === id)) {
        all.push(template);
      }
    }
    return all;
  }

  // ============================================================
  // 14. УДАЛЕНИЕ ШАБЛОНОВ
  // ============================================================

  deleteTemplate(id) {
    return this._deleteTemplate(id);
  }

  _deleteTemplate(id) {
    const result1 = this._templates.delete(id);
    const result2 = this._templatesCache.delete(id);
    const result = result1 || result2;
    if (result) {
      this._logger.info(`🗑️ Шаблон удален: ${id}`);
      this._generatedTemplates = this._generatedTemplates.filter(t => t.id !== id);
    }
    return result;
  }

  clearAll() {
    return this._clearAll();
  }

  _clearAll() {
    const count = this._templates.size + this._templatesCache.size;
    this._templates.clear();
    this._templatesCache.clear();
    this._generatedTemplates = [];
    this._stats = {
      totalGenerated: 0,
      totalCompressed: 0,
      totalSaved: 0,
      averageRatio: 0,
      cacheHits: 0,
      cacheMisses: 0,
    };
    this._logger.info(`🗑️ Очищено ${count} шаблонов`);
    return { cleared: count };
  }

  // ============================================================
  // 15. СТАТИСТИКА
  // ============================================================

  getStats() {
    return this._getStats();
  }

  _getStats() {
    const templates = this._getAllTemplates();
    const types = templates.reduce((acc, t) => {
      acc[t.type] = (acc[t.type] || 0) + 1;
      return acc;
    }, {});

    const codecStatus = this._core.getCodecStatus();

    return {
      ...this._stats,
      templatesCount: templates.length,
      types,
      version: this._version,
      build: this._build,
      initialized: this._initialized,
      codecReady: codecStatus.ready,
      codecLoading: codecStatus.loading,
      codecError: codecStatus.error || null,
      metadata: { ...this._metadata },
      averageSize:
          templates.length > 0
            ? (
              templates.reduce((sum, t) => sum + t.code.length, 0) /
                  templates.length /
                  1024
            ).toFixed(2)
            : 0,
      cacheSize: this._cache.size,
      templatesCacheSize: this._templatesCache.size,
      generatedTemplatesCount: this._generatedTemplates.length,
    };
  }

  // ============================================================
  // 16. ЭКСПОРТ/ИМПОРТ
  // ============================================================

  exportToJSON() {
    return this._exportJSON();
  }

  _exportJSON() {
    const data = {
      version: this._version,
      build: this._build,
      timestamp: new Date().toISOString(),
      config: this._config,
      stats: this._getStats(),
      templates: this._getAllTemplates().map(t => ({
        id: t.componentId || t.id,
        title: t.title,
        type: t.type,
        code: t.code,
        compressed: t.compressed || null,
        generated: t.generatedISO || new Date(t.generated).toISOString(),
        version: t.version || this._version,
        size: t.code.length,
        compression: t.compression || null,
      })),
    };
    return JSON.stringify(data, null, 2);
  }

  importFromJSON(json) {
    return this._importJSON(json);
  }

  _importJSON(json) {
    const logger = this._logger;
    try {
      const data = typeof json === 'string' ? JSON.parse(json) : json;

      if (!data.templates || !Array.isArray(data.templates)) {
        throw new Error('Неверный формат: ожидается массив templates');
      }

      let imported = 0;
      for (const t of data.templates) {
        if (t.id && t.code) {
          const template = {
            id: t.id,
            componentId: t.id,
            title: t.title || 'Bookmarklet',
            type: t.type || 'main',
            code: t.code,
            compressed: t.compressed || null,
            generated: t.generated ? new Date(t.generated).getTime() : Date.now(),
            generatedISO: t.generated || new Date().toISOString(),
            version: t.version || data.version || this._version,
            debug: t.debug !== false,
            size: t.code.length,
            compression: t.compression || null,
          };

          this._templates.set(t.id, template);
          if (t.compressed) {
            this._templatesCache.set(t.id, {
              ...template,
              compressed: t.compressed,
            });
          }
          imported++;
        }
      }

      logger.success(`✅ Импортировано ${imported} шаблонов`);
      return { imported, total: data.templates.length };
    } catch (error) {
      logger.error('❌ Ошибка импорта:', error.message);
      throw error;
    }
  }

  // ============================================================
  // 17. УПРАВЛЕНИЕ ЖИЗНЕННЫМ ЦИКЛОМ
  // ============================================================

  reset() {
    return this._reset();
  }

  _reset() {
    const logger = this._logger;
    logger.warn('🔄 Сброс состояния...');

    this._cache.clear();
    this._templates.clear();
    this._templatesCache.clear();
    this._generatedTemplates = [];

    this._stats = {
      totalGenerated: 0,
      totalCompressed: 0,
      totalSaved: 0,
      averageRatio: 0,
      cacheHits: 0,
      cacheMisses: 0,
    };

    this._metadata = {
      created: Date.now(),
      lastAccess: Date.now(),
      lastUpdate: Date.now(),
      generateCount: 0,
      errorCount: 0,
    };

    this._core.reset();

    logger.success('✅ Состояние сброшено');
    return this;
  }

  destroy() {
    return this._destroy();
  }

  _destroy() {
    const logger = this._logger;

    if (this._isDestroyed) {
      logger.warn('⚠️ Уже уничтожен');
      return;
    }

    logger.warn('🗑️ Уничтожение обертки...');

    this._cache.clear();
    this._templates.clear();
    this._templatesCache.clear();
    this._generatedTemplates = [];
    this._listeners = [];
    this._eventHandlers.clear();

    if (this._core) {
      this._core.destroy();
    }

    if (typeof window !== 'undefined') {
      delete window.__templateWrapper;
      delete window[PUBLIC.API];
      delete window[PUBLIC.STATE];
      delete window[PUBLIC.CONFIG];
      delete window[PUBLIC.LOGGER];
      delete window[PUBLIC.GENERATOR];
      delete window[PUBLIC.TEMPLATES];
      delete window[PUBLIC.STATS];
      delete window[PUBLIC.INSTANCE];
      delete window[PUBLIC.EVENTS];
      delete window.__templateWrapperSymbols;
    }

    this._isDestroyed = true;
    this._initialized = false;

    logger.success('✅ Обертка уничтожена');
  }

  // ============================================================
  // 18. СОБЫТИЯ
  // ============================================================

  on(event, callback) {
    return this._on(event, callback);
  }

  _on(event, callback) {
    if (!VALIDATOR[PRIVATE.VALIDATOR].isValidCallback(callback)) {
      this._logger.warn(`⚠️ Некорректный callback для события ${event}`);
      return () => {};
    }

    if (!this._eventHandlers.has(event)) {
      this._eventHandlers.set(event, []);
    }
    this._eventHandlers.get(event).push(callback);

    return () => this._off(event, callback);
  }

  off(event, callback) {
    return this._off(event, callback);
  }

  _off(event, callback) {
    if (this._eventHandlers.has(event)) {
      const handlers = this._eventHandlers.get(event);
      const index = handlers.indexOf(callback);
      if (index !== -1) {
        handlers.splice(index, 1);
      }
      if (handlers.length === 0) {
        this._eventHandlers.delete(event);
      }
    }
  }

  emit(event, data) {
    return this._emit(event, data);
  }

  _emit(event, data) {
    if (this._eventHandlers.has(event)) {
      const handlers = this._eventHandlers.get(event);
      for (const callback of handlers) {
        try {
          callback(data);
        } catch (error) {
          this._logger.error(`❌ Ошибка в обработчике ${event}:`, error);
        }
      }
    }
  }

  // ============================================================
  // 19. ПОЛУЧЕНИЕ СОСТОЯНИЯ
  // ============================================================

  getState() {
    return this._getState();
  }

  _getState() {
    return {
      id: this._id,
      name: this._name,
      type: this._type,
      version: this._version,
      build: this._build,
      initialized: this._initialized,
      destroyed: this._isDestroyed,
      config: { ...this._config },
      metadata: { ...this._metadata },
      context: { ...this._context },
      stats: this._getStats(),
      templatesCount: this._templates.size,
      templatesCacheCount: this._templatesCache.size,
      generatedCount: this._generatedTemplates.length,
      coreStatus: this._core?.getCodecStatus?.() || { ready: false },
    };
  }

  // ============================================================
  // 20. ГЕТТЕРЫ (ТОЛЬКО ДЛЯ ЧТЕНИЯ) - ИСПРАВЛЕНО
  // ============================================================

  // ★★★ ИСПРАВЛЕНИЕ: Используем обычные свойства, а не геттеры ★★★
  // Это предотвращает ошибку "Cannot set property"

  get [PRIVATE.CONFIG]() {
    return this._config;
  }

  get [PRIVATE.LOGGER]() {
    return this._logger;
  }

  get [PRIVATE.STATS]() {
    return this._stats;
  }

  get [PRIVATE.VERSION]() {
    return this._version;
  }

  get [PRIVATE.BUILD]() {
    return this._build;
  }

  get [PRIVATE.INITIALIZED]() {
    return this._initialized;
  }

  get [PRIVATE.IS_DESTROYED]() {
    return this._isDestroyed;
  }

  get [PRIVATE.CORE]() {
    return this._core;
  }

  get [PRIVATE.TEMPLATES]() {
    return this._templates;
  }

  get [PRIVATE.TEMPLATES_CACHE]() {
    return this._templatesCache;
  }

  get [PRIVATE.GENERATED_TEMPLATES]() {
    return this._generatedTemplates;
  }

  get [PRIVATE.CACHE]() {
    return this._cache;
  }

  get [PRIVATE.METADATA]() {
    return this._metadata;
  }

  get [PRIVATE.CONTEXT]() {
    return this._context;
  }

  get [PRIVATE.LISTENERS]() {
    return this._listeners;
  }

  get [PRIVATE.EVENT_HANDLERS]() {
    return this._eventHandlers;
  }

  get [PRIVATE.LOG_HISTORY]() {
    return this._logHistory;
  }
}

// ============================================================
// 21. СОЗДАНИЕ ЭКЗЕМПЛЯРА
// ============================================================

let wrapperInstance = null;

function getTemplateWrapper(options = {}) {
  if (!wrapperInstance) {
    wrapperInstance = new BookmarkletTemplateGenerator(options);
    if (typeof window !== 'undefined') {
      window.__templateWrapperInstance = wrapperInstance;
    }
    if (typeof self !== 'undefined') {
      self.__templateWrapper = wrapperInstance;
    }
  }
  return wrapperInstance;
}

// ============================================================
// 22. ЭКСПОРТ
// ============================================================

export default BookmarkletTemplateGenerator;
export { BookmarkletTemplateGenerator, getTemplateWrapper, PRIVATE, PUBLIC, DEFAULT_CONFIG };

// ============================================================
// 23. ИНИЦИАЛИЗАЦИЯ ПРИ ЗАГРУЗКЕ
// ============================================================

if (typeof window !== 'undefined') {
  const wrapper = getTemplateWrapper({
    debug: true,
    version: '2.0.3',
    build: '2026-07-19',
  });

  console.log('╔═══════════════════════════════════════════════════════════════════════════════╗');
  console.log('║          📦 BOOKMARKLET TEMPLATE WRAPPER (100% СИМВОЛЫ)                    ║');
  console.log('╠═══════════════════════════════════════════════════════════════════════════════╣');
  console.log('║  📋 Все логи выводятся в консоль с цветовой разметкой                       ║');
  console.log('║  🔑 Полная изоляция через приватные символы                                 ║');
  console.log('║  🔓 Публичные символы через Symbol.for                                      ║');
  console.log('║  📦 Обертка над TemplateGeneratorCore                                       ║');
  console.log('║  🚀 Генерация и сжатие шаблонов букмарклетов                                ║');
  console.log('║  ✅ ИСПРАВЛЕНА ОШИБКА: геттеры заменены на обычные свойства                ║');
  console.log('║  📊 Полная статистика и кеширование                                         ║');
  console.log('╚═══════════════════════════════════════════════════════════════════════════════╝');

  console.log('📋 ДОСТУПНЫЕ КОМАНДЫ:');
  console.log('  __templateWrapper.generateTemplate()          - генерировать шаблон');
  console.log('  __templateWrapper.generateCompressedTemplate() - сжатый шаблон');
  console.log('  __templateWrapper.generateAllTemplates()      - все шаблоны');
  console.log('  __templateWrapper.getTemplate(id)             - получить шаблон');
  console.log('  __templateWrapper.getAllTemplates()           - все шаблоны');
  console.log('  __templateWrapper.deleteTemplate(id)          - удалить шаблон');
  console.log('  __templateWrapper.clearAll()                  - очистить всё');
  console.log('  __templateWrapper.getStats()                  - статистика');
  console.log('  __templateWrapper.exportToJSON()              - экспорт');
  console.log('  __templateWrapper.importFromJSON(json)        - импорт');
  console.log('  __templateWrapper.minify(code)                - минифицировать');
  console.log('  __templateWrapper.compress(code)              - сжать');
  console.log('  __templateWrapper.getCodecStatus()            - статус кодека');
  console.log('  __templateWrapper.ensureCodecLoaded()         - загрузить кодек');
  console.log('  __templateWrapper.on(event, cb)               - подписка');
  console.log('  __templateWrapper.off(event, cb)              - отписка');
  console.log('  __templateWrapper.emit(event, data)           - событие');
  console.log('  __templateWrapper.getState()                  - состояние');
  console.log('  __templateWrapper.reset()                     - сбросить');
  console.log('  __templateWrapper.destroy()                   - уничтожить');
  console.log('  window.PRIVATE_SYMBOLS                        - приватные символы');
  console.log('  window.PUBLIC_SYMBOLS                         - публичные символы');
}
