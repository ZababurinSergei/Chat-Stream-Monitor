// web/Bookmarklet/bookmarklet.js - Единая точка входа (100% СИМВОЛЫ)
// Версия: 3.5.3
// ИСПРАВЛЕНО: Ошибка при повторном нажатии на букмарклет

// ============================================================
// 1. ИМПОРТЫ СИМВОЛОВ ИЗ МОДУЛЕЙ
// ============================================================

import { PRIVATE, PUBLIC } from './core/symbols.js';
import { createLogger, Logger } from './core/logger.js';
import { VALIDATOR } from './core/validator.js';
import { DEFAULT_CONFIG, SCRIPT_MAP } from './core/config.js';
import {
  isBookmarkletInstance,
  getScriptPath,
  detectScript,
  safeMerge,
  generateId,
} from './core/utils.js';
import { executeScript } from './core/script-executor.js';
import { recursiveStep, recursiveLoop as recursiveLoopFn, checkState } from './core/recursion.js';
import { togglePanel, showError } from './core/panel-manager.js';
import {
  registerGlobals,
  handleAutoStart,
  printBanner,
} from './core/global-registry.js';

// ============================================================
// 2. ГЛОБАЛЬНЫЙ ЭКЗЕМПЛЯР ДЛЯ ПРОВЕРКИ
// ============================================================

let globalBookmarkletInstance = null;
let globalBookmarkletLogger = null;

// ============================================================
// 3. КЛАСС BOOKMARKLET (100% СИМВОЛЫ)
// ============================================================

class Bookmarklet {
  // ★★★ СТАТИЧЕСКИЕ СИМВОЛЫ ★★★
  static [PRIVATE.INSTANCE] = null;
  static [PRIVATE.IS_SINGLETON] = true;

  // ============================================================
  // 3.1 ★★★ КОНСТРУКТОР ★★★
  // ============================================================

  constructor(props = {}) {
    // ★★★ ПРОВЕРКА SINGLETON ★★★
    if (Bookmarklet[PRIVATE.INSTANCE]) {
      const logger = this._getLogger(props);
      logger.warn('⚠️ Букмарклет уже существует, обновляем параметры');
      this.update(props);
      return Bookmarklet[PRIVATE.INSTANCE];
    }

    this[PRIVATE.INIT](props);
    Bookmarklet[PRIVATE.INSTANCE] = this;
    globalBookmarkletInstance = this;
  }

  // ============================================================
  // 3.2 ★★★ ПОЛУЧЕНИЕ ЛОГГЕРА (С ЗАЩИТОЙ) ★★★
  // ============================================================

  _getLogger(props) {
    // Если есть сохраненный логгер - используем его
    if (globalBookmarkletLogger) {
      return globalBookmarkletLogger;
    }

    // Если есть логгер в экземпляре
    if (this && this._logger) {
      globalBookmarkletLogger = this._logger;
      return this._logger;
    }

    // Создаем новый логгер
    const logger = createLogger(props.debug !== false, 'Bookmarklet');
    globalBookmarkletLogger = logger;
    return logger;
  }

  // ============================================================
  // 3.3 ★★★ ИНИЦИАЛИЗАЦИЯ ★★★
  // ============================================================

  [PRIVATE.INIT](props) {
    // ★★★ СОЗДАНИЕ ЛОГГЕРА ★★★
    this._logger = this._getLogger(props);
    const logger = this._logger;

    // Основные символы
    this._version = props.version || DEFAULT_CONFIG.version;
    this._build = props.build || DEFAULT_CONFIG.build;
    this._timestamp = Date.now();
    this._config = { ...DEFAULT_CONFIG, ...props };
    this._props = props;

    // Символы данных
    this._name = props.name || DEFAULT_CONFIG.name;
    this._type = props.type || DEFAULT_CONFIG.type;
    this._id = props.id || generateId('bm');
    this._callback = props.callback || null;
    this._data = props.data || null;
    this._previousResult = null;
    this._isRecursive = props.recursive || false;

    // Символы рекурсии
    this._targetState = props.targetState || null;
    this._maxRecursion = props.maxRecursion || this._config.maxRecursion || 100;
    this._recursionDelay = props.recursionDelay || this._config.recursionDelay || 500;
    this._isComplete = false;
    this._recursionIteration = 0;

    // Символ скрипта
    this._script = this[PRIVATE.DETECT_SCRIPT](props);
    this._scriptPath = null;

    // Логирование через символы логгера
    logger.debug(`🔍 Инициализация: script = ${this._script}`);
    logger.debug(`🔍 Callback: ${typeof this._callback === 'function' ? '✅' : '❌'}`);
    logger.debug(`🔍 Recursive: ${this._isRecursive ? '✅' : '❌'}`);
    logger.debug(`🔍 MaxRecursion: ${this._maxRecursion}`);

    // Символ состояния
    this._state = {
      initialized: false,
      running: false,
      destroyed: false,
      scriptExecuted: false,
      result: null,
      error: null,
      timestamp: Date.now(),
    };

    // Символ активного компонента
    this._activeComponent = {
      name: this._name,
      type: this._type,
      id: this._id,
      script: this._script,
      scriptPath: null,
      data: this._data,
      hasCallback: typeof this._callback === 'function',
      isRecursive: this._isRecursive,
      targetState: this._targetState,
      maxRecursion: this._maxRecursion,
      recursionDelay: this._recursionDelay,
      isComplete: this._isComplete,
      recursionIteration: this._recursionIteration,
      timestamp: Date.now(),
      status: 'initialized',
      isSingleton: Bookmarklet[PRIVATE.IS_SINGLETON],
    };

    // Символ результата
    this._result = null;

    // Символ кеша
    this._cache = new Map();

    // Символы слушателей
    this._listeners = [];
    this._eventHandlers = new Map();

    // Символ истории логов
    this._logHistory = [];

    // Символы метаданных
    this._metadata = {
      created: Date.now(),
      lastAccess: Date.now(),
      lastUpdate: Date.now(),
      runCount: 0,
      errorCount: 0,
      recursiveCount: 0,
    };

    // Символ контекста
    this._context = {
      url: typeof window !== 'undefined' ? window.location.href : '',
      title: typeof window !== 'undefined' ? document.title : '',
      userAgent: typeof navigator !== 'undefined' ? navigator.userAgent : '',
      origin: typeof window !== 'undefined' ? window.location.origin : '',
    };

    // Символы флагов
    this._initialized = true;
    this._isRunning = false;
    this._isDestroyed = false;
    this._scriptExecuted = false;

    // ★★★ ВЫЗОВ СИМВОЛОВ МЕТОДОВ ★★★
    this[PRIVATE.EXPORT_SYMBOLS]();
    this[PRIVATE.LOG_ACTIVE_COMPONENT]();

    // Логирование через символы логгера
    logger.header('СОЗДАНИЕ БУКМАРКЛЕТА (100% СИМВОЛЫ + SINGLETON)');
    logger.info(`📦 Версия: ${this._version}`);
    logger.info(`📌 Имя: ${this._name}`);
    logger.info(`📌 Тип: ${this._type}`);
    logger.info(`📌 ID: ${this._id}`);
    logger.success('✅ Букмарклет создан');
    logger.header('ГОТОВ');
  }

  // ============================================================
  // 3.4 ★★★ ПУБЛИЧНЫЕ МЕТОДЫ (ОБЕРТКИ СИМВОЛОВ) ★★★
  // ============================================================

  update(props) {
    return this[PRIVATE.UPDATE](props);
  }

  recursive(props) {
    return this[PRIVATE.RECURSIVE](props);
  }

  recursiveLoop(props) {
    return this[PRIVATE.RECURSIVE_LOOP](props);
  }

  getState() {
    return this[PRIVATE.GET_STATE]();
  }

  getStats() {
    return this[PRIVATE.GET_STATS]();
  }

  reset() {
    return this[PRIVATE.RESET]();
  }

  destroy() {
    return this[PRIVATE.DESTROY]();
  }

  // ============================================================
  // 3.5 ★★★ МЕТОДЫ СОБЫТИЙ ★★★
  // ============================================================

  on(event, callback) {
    if (!VALIDATOR[PRIVATE.VALIDATOR].isValidCallback(callback)) {
      this._logger.warn(`⚠️ Некорректный callback для события ${event}`);
      return () => {};
    }
    if (!this._eventHandlers.has(event)) {
      this._eventHandlers.set(event, []);
    }
    this._eventHandlers.get(event).push(callback);
    return () => this.off(event, callback);
  }

  off(event, callback) {
    if (this._eventHandlers.has(event)) {
      const handlers = this._eventHandlers.get(event);
      const index = handlers.indexOf(callback);
      if (index !== -1) {
        handlers.splice(index, 1);
      }
      if (handlers.length === 0) {
        this._eventHandlers.delete(event);
      }
    }
  }

  emit(event, data) {
    if (this._eventHandlers.has(event)) {
      const handlers = this._eventHandlers.get(event);
      for (const callback of handlers) {
        try {
          callback(data);
        } catch (error) {
          this._logger.error(`❌ Ошибка в обработчике ${event}:`, error);
        }
      }
    }
  }

  // ============================================================
  // 3.6 ★★★ ПРИВАТНЫЙ МЕТОД ОБНОВЛЕНИЯ ★★★
  // ============================================================

  [PRIVATE.UPDATE](props) {
    const logger = this._getLogger(props);
    logger.info('🔄 Обновление параметров Singleton...');
    let updated = false;

    // Обновление через символы
    if (props.callback && typeof props.callback === 'function') {
      this._callback = props.callback;
      this._activeComponent.hasCallback = true;
      updated = true;
    }

    if (props.data) {
      this._data = props.data;
      updated = true;
    }

    if (props.recursive !== undefined) {
      this._isRecursive = props.recursive;
      this._activeComponent.isRecursive = props.recursive;
      updated = true;
    }

    if (props.targetState !== undefined) {
      this._targetState = props.targetState;
      this._activeComponent.targetState = props.targetState;
      updated = true;
    }

    if (props.maxRecursion !== undefined) {
      this._maxRecursion = props.maxRecursion;
      this._activeComponent.maxRecursion = props.maxRecursion;
      updated = true;
    }

    if (props.recursionDelay !== undefined) {
      this._recursionDelay = props.recursionDelay;
      this._activeComponent.recursionDelay = props.recursionDelay;
      updated = true;
    }

    if (props.name) {
      this._name = props.name;
      updated = true;
    }

    if (props.type) {
      this._type = props.type;
      updated = true;
    }

    if (props.script) {
      this._script = props.script;
      this._scriptPath = getScriptPath(props.script, this._config.basePath);
      this._activeComponent.script = props.script;
      this._activeComponent.scriptPath = this._scriptPath;
      updated = true;
    }

    if (props) {
      this._props = safeMerge(this._props, props);
      updated = true;
    }

    if (updated) {
      logger.success('✅ Параметры обновлены');
    } else {
      logger.info('ℹ️ Нет новых параметров');
    }

    // ★★★ ВОЗВРАЩАЕМ ЭКЗЕМПЛЯР ДЛЯ ЦЕПОЧКИ ★★★
    return this;
  }

  // ============================================================
  // 3.7 ★★★ ПРИВАТНЫЙ МЕТОД РЕКУРСИИ ★★★
  // ============================================================

  [PRIVATE.RECURSIVE](props = {}) {
    return recursiveStep(this, props);
  }

  // ============================================================
  // 3.8 ★★★ ПРИВАТНЫЙ МЕТОД БЕСКОНЕЧНОЙ РЕКУРСИИ ★★★
  // ============================================================

  [PRIVATE.RECURSIVE_LOOP](props = {}) {
    return recursiveLoopFn(this, props);
  }

  // ============================================================
  // 3.9 ★★★ ПРИВАТНЫЙ МЕТОД ОПРЕДЕЛЕНИЯ СКРИПТА ★★★
  // ============================================================

  [PRIVATE.DETECT_SCRIPT](props) {
    return detectScript(props, SCRIPT_MAP);
  }

  // ============================================================
  // 3.10 ★★★ ПРИВАТНЫЙ МЕТОД ЛОГИРОВАНИЯ КОМПОНЕНТА ★★★
  // ============================================================

  [PRIVATE.LOG_ACTIVE_COMPONENT]() {
    const logger = this._getLogger();
    const scriptPath = this._script
      ? getScriptPath(this._script, this._config.basePath)
      : null;
    this._scriptPath = scriptPath;
    this._activeComponent.scriptPath = scriptPath;
    this._activeComponent.status = 'active';

    // ★★★ ИСПРАВЛЕНО: Проверка наличия метода separator ★★★
    if (typeof logger.separator === 'function') {
      logger.separator();
    } else {
      console.log('─'.repeat(70));
    }

    console.log('%c  🎯 АКТИВНЫЙ КОМПОНЕНТ (SINGLETON)', 'font-size: 16px; font-weight: bold; color: #667eea;');
    console.log(`  📌 ${logger._instanceId || 'Bookmarklet'} → ${this._name}`);
    console.log('');
    console.log(`  📋 Имя: ${this._name}`);
    console.log(`  📋 Тип: ${this._type}`);
    console.log(`  📋 ID: ${this._id}`);
    console.log(`  📋 Версия: ${this._version}`);
    console.log(`  📋 Скрипт: ${this._script || '❌ не указан'}`);
    console.log(`  📋 Путь: ${scriptPath || '❌ не указан'}`);
    console.log(`  📋 Recursive: ${this._isRecursive ? '✅' : '❌'}`);
    console.log(`  📋 MaxRecursion: ${this._maxRecursion}`);
    console.log(`  📋 Singleton: ${Bookmarklet[PRIVATE.IS_SINGLETON] ? '✅' : '❌'}`);

    if (typeof logger.separator === 'function') {
      logger.separator();
    } else {
      console.log('─'.repeat(70));
    }

    if (typeof window !== 'undefined') {
      window.__activeComponent = {
        name: this._name,
        type: this._type,
        id: this._id,
        script: this._script,
        scriptPath,
        data: this._data,
        hasCallback: typeof this._callback === 'function',
        isRecursive: this._isRecursive,
        targetState: this._targetState,
        maxRecursion: this._maxRecursion,
        recursionDelay: this._recursionDelay,
        isComplete: this._isComplete,
        recursionIteration: this._recursionIteration,
        isSingleton: Bookmarklet[PRIVATE.IS_SINGLETON],
        timestamp: this._timestamp,
        status: 'active',
        url: this._context.url,
        version: this._version,
      };
    }
  }

  // ============================================================
  // 3.11 ★★★ ПРИВАТНЫЙ МЕТОД ЭКСПОРТА СИМВОЛОВ ★★★
  // ============================================================

  [PRIVATE.EXPORT_SYMBOLS]() {
    if (typeof window === 'undefined') {return;}

    // Экспорт через публичные символы
    window.__bookmarklet = this;
    window.__bookmarkletInstance = this;
    window[PUBLIC.API] = this;
    window[PUBLIC.STATE] = this.getState.bind(this);
    window[PUBLIC.CONFIG] = this._config;
    window[PUBLIC.LOGGER] = this._logger;
    window[PUBLIC.INSTANCE] = this;
    window[PUBLIC.MAIN] = this[PRIVATE.RUN].bind(this);
    window[PUBLIC.RECURSIVE] = this[PRIVATE.RECURSIVE].bind(this);
    window[PUBLIC.RECURSIVE_LOOP] = this[PRIVATE.RECURSIVE_LOOP].bind(this);
    window[PUBLIC.ACTIVE] = this._activeComponent;
    window[PUBLIC.SINGLETON] = Bookmarklet[PRIVATE.INSTANCE];
    window[PUBLIC.EVENTS] = {
      on: this.on.bind(this),
      off: this.off.bind(this),
      emit: this.emit.bind(this),
    };

    // Экспорт приватных символов (для отладки)
    window.__bookmarkletSymbols = {
      PRIVATE: { ...PRIVATE },
      PUBLIC: { ...PUBLIC },
      version: this._version,
      build: this._build,
      active: this._activeComponent,
      isSingleton: Bookmarklet[PRIVATE.IS_SINGLETON],
      isRecursive: this._isRecursive,
      targetState: this._targetState,
      maxRecursion: this._maxRecursion,
    };

    window.R = this;
  }

  // ============================================================
  // 3.12 ★★★ ПРИВАТНЫЙ МЕТОД ЗАПУСКА ★★★
  // ============================================================

  [PRIVATE.RUN]() {
    return this._run();
  }

  async _run() {
    // ★★★ ПОЛУЧАЕМ ЛОГГЕР С ЗАЩИТОЙ ★★★
    const logger = this._getLogger();

    // ★★★ ПРОВЕРКА НАЛИЧИЯ ЛОГГЕРА ★★★
    if (!logger) {
      console.error('❌ Логгер не доступен, создаем временный');
      // Создаем временный логгер
      const tempLogger = createLogger(true, 'Bookmarklet');
      this._logger = tempLogger;
      globalBookmarkletLogger = tempLogger;
      return this._run(); // Повторяем с новым логгером
    }

    const callback = this._callback;
    const data = this._data;
    const isRecursive = this._isRecursive;

    // Проверка состояния через символы
    if (this._isRunning && !isRecursive) {
      const result = togglePanel(this);
      this[PRIVATE.HANDLE_CALLBACK](result);
      return result;
    }

    if (this._isDestroyed) {
      const error = 'Bookmarklet destroyed';
      logger.error(`❌ ${error}`);
      const result = { success: false, error };
      this[PRIVATE.HANDLE_CALLBACK](result);
      return result;
    }

    this._isRunning = true;
    this._metadata.runCount++;
    this._metadata.lastAccess = Date.now();
    this._activeComponent.timestamp = Date.now();
    this._activeComponent.runCount = this._metadata.runCount;
    this._activeComponent.status = 'running';

    logger.header(isRecursive ? 'ЗАПУСК БУКМАРКЛЕТА (РЕКУРСИВНЫЙ)' : 'ЗАПУСК БУКМАРКЛЕТА (SINGLETON)');
    logger.info(`📌 Имя: ${this._name}`);
    logger.info(`📌 Тип: ${this._type}`);
    logger.info(`📌 ID: ${this._id}`);

    const scriptToExecute = this._script;
    logger.info(`📌 Скрипт: ${scriptToExecute || 'не указан'}`);

    try {
      let result = null;

      if (scriptToExecute) {
        logger.log('📜 Выполнение скрипта...');
        const scriptProps = {
          ...this._props,
          data,
          callback,
          bookmarkletId: this._id,
          bookmarkletName: this._name,
          bookmarkletType: this._type,
          isSingleton: Bookmarklet[PRIVATE.IS_SINGLETON],
          isRecursive,
          previousResult: this._previousResult,
          recursiveCount: this._metadata.recursiveCount,
          targetState: this._targetState,
          maxRecursion: this._maxRecursion,
          recursionDelay: this._recursionDelay,
          isComplete: this._isComplete,
          recursionIteration: this._recursionIteration,
        };

        result = await executeScript(scriptToExecute, scriptProps, this);
        this._scriptExecuted = true;
        this._activeComponent.executed = true;
        this._activeComponent.lastResult = result;
        this._activeComponent.status = 'completed';
      } else {
        logger.warn('⚠️ Скрипт не указан');
        result = {
          success: true,
          message: 'Скрипт не указан',
          props: this._props,
          data,
        };
        this._activeComponent.status = 'idle';
      }

      if (isRecursive) {
        this._previousResult = this._result;
        this._metadata.recursiveCount++;
        this._recursionIteration++;
      }

      this._result = result;
      this._state.result = result;
      this._state.scriptExecuted = this._scriptExecuted;

      this[PRIVATE.HANDLE_CALLBACK](result);

      logger.success('✅ Букмарклет выполнен успешно');
      this._isRunning = false;
      return result;

    } catch (error) {
      logger.error('❌ Ошибка выполнения:', error.message);
      this._metadata.errorCount++;

      const result = {
        success: false,
        error: error.message,
        stack: error.stack,
        type: this._type,
        name: this._name,
        id: this._id,
        script: this._scriptPath || scriptToExecute,
        data,
        isSingleton: Bookmarklet[PRIVATE.IS_SINGLETON],
        isRecursive,
        previousResult: this._previousResult,
        targetState: this._targetState,
        recursionIteration: this._recursionIteration,
      };

      this._result = result;
      this._state.result = result;
      this._state.error = error.message;
      this._activeComponent.lastError = error.message;
      this._activeComponent.executed = false;
      this._activeComponent.status = 'error';

      this[PRIVATE.HANDLE_CALLBACK](result);
      this._isRunning = false;
      return result;
    }
  }

  // ============================================================
  // 3.13 ★★★ ПРИВАТНЫЙ МЕТОД ОБРАБОТКИ CALLBACK ★★★
  // ============================================================

  [PRIVATE.HANDLE_CALLBACK](result) {
    const logger = this._getLogger();
    const callback = this._callback;

    if (typeof callback === 'function') {
      try {
        logger.debug('📞 Вызов callback');
        callback(result);
        logger.success('✅ Callback выполнен');
      } catch (error) {
        logger.error(`❌ Ошибка в callback: ${error.message}`);
        console.error('[Bookmarklet] Callback error:', error);
      }
    } else {
      if (result && result.success !== false) {
        console.log('✅ Букмарклет выполнен:', result);
      } else if (result && result.error) {
        console.error('❌ Ошибка букмарклета:', result.error);
        if (result.stack) {
          console.error('📚 Stack:', result.stack);
        }
      }
    }
  }

  // ============================================================
  // 3.14 ★★★ ПРИВАТНЫЙ МЕТОД ПОЛУЧЕНИЯ СОСТОЯНИЯ ★★★
  // ============================================================

  [PRIVATE.GET_STATE]() {
    return {
      id: this._id,
      name: this._name,
      type: this._type,
      version: this._version,
      build: this._build,
      initialized: this._initialized,
      running: this._isRunning,
      destroyed: this._isDestroyed,
      scriptExecuted: this._scriptExecuted,
      result: this._result,
      error: this._state.error,
      metadata: { ...this._metadata },
      context: { ...this._context },
      config: { ...this._config },
      cacheSize: this._cache.size,
      listenersCount: this._listeners.length,
      hasScript: !!this._script,
      hasCallback: typeof this._callback === 'function',
      hasData: !!this._data,
      isRecursive: this._isRecursive,
      isSingleton: Bookmarklet[PRIVATE.IS_SINGLETON],
      previousResult: this._previousResult,
      recursiveCount: this._metadata.recursiveCount || 0,
      targetState: this._targetState,
      maxRecursion: this._maxRecursion,
      recursionDelay: this._recursionDelay,
      isComplete: this._isComplete,
      recursionIteration: this._recursionIteration,
      activeComponent: { ...this._activeComponent },
      scriptPath: this._scriptPath,
    };
  }

  // ============================================================
  // 3.15 ★★★ ПРИВАТНЫЙ МЕТОД ПОЛУЧЕНИЯ СТАТИСТИКИ ★★★
  // ============================================================

  [PRIVATE.GET_STATS]() {
    return {
      id: this._id,
      name: this._name,
      type: this._type,
      version: this._version,
      runCount: this._metadata.runCount,
      errorCount: this._metadata.errorCount,
      recursiveCount: this._metadata.recursiveCount || 0,
      scriptExecuted: this._scriptExecuted,
      cacheSize: this._cache.size,
      listenersCount: this._listeners.length,
      hasCallback: typeof this._callback === 'function',
      hasData: !!this._data,
      isRecursive: this._isRecursive,
      isSingleton: Bookmarklet[PRIVATE.IS_SINGLETON],
      hasTargetState: !!this._targetState,
      maxRecursion: this._maxRecursion,
      recursionDelay: this._recursionDelay,
      isComplete: this._isComplete,
      recursionIteration: this._recursionIteration,
      activeComponent: { ...this._activeComponent },
    };
  }

  // ============================================================
  // 3.16 ★★★ ПРИВАТНЫЙ МЕТОД СБРОСА ★★★
  // ============================================================

  [PRIVATE.RESET]() {
    const logger = this._getLogger();
    logger.warn('🔄 Сброс состояния...');

    this._state = {
      initialized: true,
      running: false,
      destroyed: false,
      scriptExecuted: false,
      result: null,
      error: null,
      timestamp: Date.now(),
    };

    this._result = null;
    this._previousResult = null;
    this._cache.clear();
    this._logHistory = [];

    this._metadata = {
      created: Date.now(),
      lastAccess: Date.now(),
      lastUpdate: Date.now(),
      runCount: 0,
      errorCount: 0,
      recursiveCount: 0,
    };

    this._isComplete = false;
    this._recursionIteration = 0;
    this._activeComponent.isComplete = false;
    this._activeComponent.recursionIteration = 0;
    this._scriptExecuted = false;
    this._activeComponent.executed = false;
    this._activeComponent.lastResult = null;
    this._activeComponent.lastError = null;
    this._activeComponent.status = 'reset';

    logger.success('✅ Состояние сброшено');
    return this;
  }

  // ============================================================
  // 3.17 ★★★ ПРИВАТНЫЙ МЕТОД УНИЧТОЖЕНИЯ ★★★
  // ============================================================

  [PRIVATE.DESTROY]() {
    const logger = this._getLogger();
    if (this._isDestroyed) {
      logger.warn('⚠️ Букмарклет уже уничтожен');
      return;
    }

    logger.warn('🗑️ Уничтожение букмарклета...');

    // Очистка слушателей
    for (const listener of this._listeners) {
      if (listener.element && listener.event && listener.handler) {
        listener.element.removeEventListener(listener.event, listener.handler);
      }
    }
    this._listeners = [];
    this._eventHandlers.clear();
    this._cache.clear();

    // Удаление глобальных ссылок
    if (typeof window !== 'undefined') {
      if (window.__bookmarklet === this) {delete window.__bookmarklet;}
      if (window.__bookmarkletInstance === this) {delete window.__bookmarkletInstance;}
      if (window.R === this) {delete window.R;}
      delete window[PUBLIC.API];
      delete window[PUBLIC.STATE];
      delete window[PUBLIC.CONFIG];
      delete window[PUBLIC.LOGGER];
      delete window[PUBLIC.INSTANCE];
      delete window[PUBLIC.MAIN];
      delete window[PUBLIC.RECURSIVE];
      delete window[PUBLIC.RECURSIVE_LOOP];
      delete window[PUBLIC.EVENTS];
      delete window[PUBLIC.ACTIVE];
      delete window[PUBLIC.SINGLETON];
      delete window.__bookmarkletSymbols;
      delete window.__activeComponent;
    }

    if (Bookmarklet[PRIVATE.INSTANCE] === this) {
      Bookmarklet[PRIVATE.INSTANCE] = null;
    }

    // ★★★ ОЧИЩАЕМ ГЛОБАЛЬНЫЙ ЛОГГЕР ★★★
    if (globalBookmarkletInstance === this) {
      globalBookmarkletInstance = null;
    }
    if (globalBookmarkletLogger) {
      globalBookmarkletLogger = null;
    }

    this._activeComponent.status = 'destroyed';
    this._isDestroyed = true;
    this._initialized = false;
    this._isRunning = false;

    logger.success('✅ Букмарклет уничтожен');
  }

  // ============================================================
  // 3.18 ★★★ СТАТИЧЕСКИЕ МЕТОДЫ ★★★
  // ============================================================

  static getInstance() {
    return Bookmarklet[PRIVATE.INSTANCE];
  }

  static createInstance(props) {
    if (Bookmarklet[PRIVATE.INSTANCE]) {
      return Bookmarklet[PRIVATE.INSTANCE];
    }
    return new Bookmarklet(props);
  }

  static isSingleton() {
    return Bookmarklet[PRIVATE.IS_SINGLETON];
  }

  static destroyInstance() {
    if (Bookmarklet[PRIVATE.INSTANCE]) {
      Bookmarklet[PRIVATE.INSTANCE].destroy();
      Bookmarklet[PRIVATE.INSTANCE] = null;
      return true;
    }
    return false;
  }
}

// ============================================================
// 4. ★★★ ЭКСПОРТЫ ★★★
// ============================================================

// ✅ ОСНОВНОЙ ЭКСПОРТ
export default async function bookmarkletMain(props = {}) {
  // ★★★ ПРОВЕРКА СУЩЕСТВУЮЩЕГО ЭКЗЕМПЛЯРА ★★★
  let instance = Bookmarklet.getInstance();

  // ★★★ ПРОВЕРКА ГЛОБАЛЬНОГО ЛОГГЕРА ★★★
  if (!globalBookmarkletLogger) {
    globalBookmarkletLogger = createLogger(true, 'Bookmarklet');
  }

  if (instance) {
    // ★★★ ВОССТАНАВЛИВАЕМ ЛОГГЕР ★★★
    if (!instance._logger) {
      instance._logger = globalBookmarkletLogger;
    }
    instance.update(props);
    const logger = instance._getLogger();
    logger.info('📌 Используем существующий Singleton');
    logger.info(`📌 ID: ${instance._id}`);
  } else {
    instance = new Bookmarklet(props);
    globalBookmarkletInstance = instance;
  }

  // ★★★ ПРОВЕРКА НАЛИЧИЯ МЕТОДА RUN ★★★
  if (!instance[PRIVATE.RUN]) {
    console.error('❌ Метод RUN не найден, создаем новый экземпляр');
    instance = new Bookmarklet(props);
    globalBookmarkletInstance = instance;
  }

  return instance[PRIVATE.RUN]();
}

// ✅ ДОПОЛНИТЕЛЬНЫЕ ЭКСПОРТЫ
export async function runRecursive(props = {}) {
  let instance = Bookmarklet.getInstance();
  if (!instance) {
    instance = new Bookmarklet({ ...props, recursive: true });
    globalBookmarkletInstance = instance;
  }
  // ★★★ ВОССТАНАВЛИВАЕМ ЛОГГЕР ★★★
  if (!instance._logger) {
    instance._logger = globalBookmarkletLogger || createLogger(true, 'Bookmarklet');
  }
  return instance[PRIVATE.RECURSIVE](props);
}

export async function runRecursiveLoop(props = {}) {
  let instance = Bookmarklet.getInstance();
  if (!instance) {
    instance = new Bookmarklet({
      ...props,
      recursive: true,
      targetState: props.targetState,
      maxRecursion: props.maxRecursion || 100,
      recursionDelay: props.recursionDelay || 500,
    });
    globalBookmarkletInstance = instance;
  }
  // ★★★ ВОССТАНАВЛИВАЕМ ЛОГГЕР ★★★
  if (!instance._logger) {
    instance._logger = globalBookmarkletLogger || createLogger(true, 'Bookmarklet');
  }
  return instance[PRIVATE.RECURSIVE_LOOP](props);
}

// ✅ АЛИАСЫ
export const recursive = runRecursive;
export const recursiveLoop = runRecursiveLoop;

// ✅ ЭКСПОРТ КЛАССА И СИМВОЛОВ
export {
  Bookmarklet,
  PRIVATE,
  PUBLIC,
  DEFAULT_CONFIG,
  createLogger,
  VALIDATOR,
};

// ============================================================
// 5. ★★★ ГЛОБАЛЬНАЯ РЕГИСТРАЦИЯ ★★★
// ============================================================

if (typeof window !== 'undefined') {
  // ★★★ СОЗДАЕМ ГЛОБАЛЬНЫЙ ЛОГГЕР ★★★
  if (!globalBookmarkletLogger) {
    globalBookmarkletLogger = createLogger(true, 'Bookmarklet');
  }

  const instance = Bookmarklet.getInstance();

  // Регистрируем глобальные API
  registerGlobals(instance || bookmarkletMain, Bookmarklet);

  // ✅ ДОБАВЛЯЕМ ГЛОБАЛЬНЫЕ ФУНКЦИИ
  window.__bookmarkletMain = bookmarkletMain;
  window.__bookmarkletRecursive = runRecursive;
  window.__bookmarkletRecursiveLoop = runRecursiveLoop;

  // ✅ АЛИАСЫ
  window.bookmarkletMain = bookmarkletMain;
  window.recursive = runRecursive;
  window.recursiveLoop = runRecursiveLoop;

  // Печатаем баннер
  printBanner(PRIVATE, PUBLIC);

  // Автозапуск
  handleAutoStart(bookmarkletMain);
}

// ============================================================
// 6. ★★★ КОМАНДЫ ДЛЯ ОТЛАДКИ ★★★
// ============================================================

if (typeof window !== 'undefined') {
  window.__bm = {
    instance: Bookmarklet.getInstance(),
    config: DEFAULT_CONFIG,
    getState: window.__bookmarkletGetState,
    reset: window.__bookmarkletReset,
    destroy: window.__bookmarkletDestroy,
    run: bookmarkletMain,
    recursive: runRecursive,
    recursiveLoop: runRecursiveLoop,
    getInstance: Bookmarklet.getInstance.bind(Bookmarklet),
    createInstance: Bookmarklet.createInstance.bind(Bookmarklet),
    destroyInstance: Bookmarklet.destroyInstance.bind(Bookmarklet),
    isSingleton: Bookmarklet.isSingleton.bind(Bookmarklet),
    getSymbols: () => ({
      PRIVATE: { ...PRIVATE },
      PUBLIC: { ...PUBLIC },
    }),
    // ★★★ НОВАЯ КОМАНДА ДЛЯ ВОССТАНОВЛЕНИЯ ЛОГГЕРА ★★★
    fixLogger: () => {
      const instance = Bookmarklet.getInstance();
      if (instance) {
        instance._logger = globalBookmarkletLogger || createLogger(true, 'Bookmarklet');
        console.log('✅ Логгер восстановлен');
        return instance._logger;
      }
      console.error('❌ Экземпляр не найден');
      return null;
    },
  };

  console.log('📋 КОМАНДЫ ОТЛАДКИ (__bm):');
  console.log('  __bm.run({ name: "My Panel", type: "env" }) - запустить');
  console.log('  __bm.recursive({ data: { step: 2 } }) - один шаг рекурсии');
  console.log('  __bm.recursiveLoop({ targetState: { status: "complete" } }) - бесконечная рекурсия');
  console.log('  __bm.getInstance()      - получить Singleton');
  console.log('  __bm.destroyInstance()  - уничтожить Singleton');
  console.log('  __bm.isSingleton()      - проверить режим');
  console.log('  __bm.getState()         - состояние');
  console.log('  __bm.reset()            - сбросить');
  console.log('  __bm.destroy()          - уничтожить');
  console.log('  __bm.getSymbols()       - получить символы');
  console.log('  __bm.fixLogger()        - восстановить логгер');
}
