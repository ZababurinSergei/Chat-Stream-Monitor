// web/Bookmarklet/src/template/logs-template.mjs
// 100% СИМВОЛЫ — полная изоляция и безопасность
// Шаблон Logs панели
// Версия: 2.1.9

// ============================================================
// 1. ПРИВАТНЫЕ СИМВОЛЫ (100% изоляция)
// ============================================================

const PRIVATE = {
  // Основные символы шаблона
  TEMPLATE: Symbol('logs-template.template'),
  CONFIG: Symbol('logs-template.config'),
  CACHE: Symbol('logs-template.cache'),
  VERSION: Symbol('logs-template.version'),
  BUILD: Symbol('logs-template.build'),
  TIMESTAMP: Symbol('logs-template.timestamp'),

  // Символы секций
  CONTROLS: Symbol('logs-template.controls'),
  CONSOLE: Symbol('logs-template.console'),
  STATS: Symbol('logs-template.stats'),
  EMPTY_STATE: Symbol('logs-template.emptyState'),
  FILTERS: Symbol('logs-template.filters'),
  ACTIONS: Symbol('logs-template.actions'),

  // Символы стилей
  STYLES: Symbol('logs-template.styles'),
  THEME: Symbol('logs-template.theme'),
  COLORS: Symbol('logs-template.colors'),
  ANIMATIONS: Symbol('logs-template.animations'),

  // Символы утилит
  ESCAPE_HTML: Symbol('logs-template.escapeHtml'),
  FORMAT_TIME: Symbol('logs-template.formatTime'),
  GET_LEVEL_COLOR: Symbol('logs-template.getLevelColor'),
  GET_LEVEL_LABEL: Symbol('logs-template.getLevelLabel'),
  GET_LEVEL_ICON: Symbol('logs-template.getLevelIcon'),
  TRUNCATE: Symbol('logs-template.truncate'),
  BUILD_ENTRY: Symbol('logs-template.buildEntry'),

  // Символы конфигурации
  DEFAULT_FILTER: Symbol('logs-template.defaultFilter'),
  DEFAULT_LEVEL: Symbol('logs-template.defaultLevel'),
  MAX_ENTRIES: Symbol('logs-template.maxEntries'),
  TRUNCATE_LENGTH: Symbol('logs-template.truncateLength'),
  ANIMATION_DURATION: Symbol('logs-template.animationDuration'),

  // Символы хранения
  LOG_ENTRIES: Symbol('logs-template.logEntries'),
  FILTERED_ENTRIES: Symbol('logs-template.filteredEntries'),
  CURRENT_FILTER: Symbol('logs-template.currentFilter'),
  CURRENT_LEVEL: Symbol('logs-template.currentLevel'),
  IS_PAUSED: Symbol('logs-template.isPaused'),
  IS_FOLLOWING: Symbol('logs-template.isFollowing'),
};

// ============================================================
// 2. ПУБЛИЧНЫЕ СИМВОЛЫ (доступны через Symbol.for)
// ============================================================

const PUBLIC = {
  API: Symbol.for('logs-template.api'),
  STATE: Symbol.for('logs-template.state'),
  CONFIG: Symbol.for('logs-template.config'),
  RENDERER: Symbol.for('logs-template.renderer'),
  INSTANCE: Symbol.for('logs-template.instance'),
  EVENTS: Symbol.for('logs-template.events'),
};

// ============================================================
// 3. КОНФИГУРАЦИЯ (100% СИМВОЛЫ)
// ============================================================

const CONFIG_SYMBOLS = {
  MAX_ENTRIES: Symbol('config.maxEntries'),
  TRUNCATE_LENGTH: Symbol('config.truncateLength'),
  ANIMATION_DURATION: Symbol('config.animationDuration'),
  DEFAULT_FILTER: Symbol('config.defaultFilter'),
  DEFAULT_LEVEL: Symbol('config.defaultLevel'),
  COLORS: Symbol('config.colors'),
  LEVELS: Symbol('config.levels'),
  ICONS: Symbol('config.icons'),
  LABELS: Symbol('config.labels'),
  THEME: Symbol('config.theme'),
};

const CONFIG = {
  [CONFIG_SYMBOLS.MAX_ENTRIES]: 1000,
  [CONFIG_SYMBOLS.TRUNCATE_LENGTH]: 500,
  [CONFIG_SYMBOLS.ANIMATION_DURATION]: 200,
  [CONFIG_SYMBOLS.DEFAULT_FILTER]: '',
  [CONFIG_SYMBOLS.DEFAULT_LEVEL]: 'all',

  [CONFIG_SYMBOLS.LEVELS]: {
    DEBUG: 'debug',
    INFO: 'info',
    WARN: 'warn',
    ERROR: 'error',
    SUCCESS: 'success',
    TRACE: 'trace',
    VERBOSE: 'verbose',
  },

  [CONFIG_SYMBOLS.ICONS]: {
    debug: '🔍',
    info: 'ℹ️',
    warn: '⚠️',
    error: '❌',
    success: '✅',
    trace: '🔎',
    verbose: '📝',
  },

  [CONFIG_SYMBOLS.LABELS]: {
    debug: 'DEBUG',
    info: 'INFO',
    warn: 'WARN',
    error: 'ERROR',
    success: 'SUCCESS',
    trace: 'TRACE',
    verbose: 'VERBOSE',
  },

  [CONFIG_SYMBOLS.COLORS]: {
    debug: '#667eea',
    info: '#74b9ff',
    warn: '#fdcb6e',
    error: '#ff6b6b',
    success: '#00b894',
    trace: '#a29bfe',
    verbose: '#636e72',
  },

  [CONFIG_SYMBOLS.THEME]: {
    dark: {
      bg: 'rgba(0,0,0,0.4)',
      border: 'rgba(255,255,255,0.05)',
      text: '#dfe6e9',
      muted: '#8899bb',
      empty: '#4a4a4a',
      hover: 'rgba(255,255,255,0.03)',
      scrollbar: 'rgba(102,126,234,0.3)',
    },
    light: {
      bg: 'rgba(0,0,0,0.08)',
      border: 'rgba(0,0,0,0.08)',
      text: '#2d3436',
      muted: '#636e72',
      empty: '#b2bec3',
      hover: 'rgba(0,0,0,0.03)',
      scrollbar: 'rgba(102,126,234,0.3)',
    },
  },
};

// ============================================================
// 4. ЛОГГЕР (100% СИМВОЛЫ)
// ============================================================

const LOGGER_SYMBOLS = {
  HISTORY: Symbol('logger.history'),
  MAX_HISTORY: Symbol('logger.maxHistory'),
  DEBUG: Symbol('logger.debug'),
  INSTANCE_ID: Symbol('logger.instanceId'),
  LEVEL: Symbol('logger.level'),
  TIMESTAMP: Symbol('logger.timestamp'),
  COLORS: Symbol('logger.colors'),
  OUTPUT: Symbol('logger.output'),
};

function createTemplateLogger(debug = true, instanceId = 'LogsTemplate') {
  const loggerState = {
    [LOGGER_SYMBOLS.HISTORY]: [],
    [LOGGER_SYMBOLS.MAX_HISTORY]: 100,
    [LOGGER_SYMBOLS.DEBUG]: debug,
    [LOGGER_SYMBOLS.INSTANCE_ID]: instanceId,
    [LOGGER_SYMBOLS.LEVEL]: 'info',
    [LOGGER_SYMBOLS.TIMESTAMP]: true,
    [LOGGER_SYMBOLS.COLORS]: true,
    [LOGGER_SYMBOLS.OUTPUT]: console,
  };

  const logMethod = function (level, message, data = null) {
    if (!this[LOGGER_SYMBOLS.DEBUG] && level !== 'error') return;

    const timestamp = this[LOGGER_SYMBOLS.TIMESTAMP]
      ? `[${new Date().toISOString().slice(11, 23)}]`
      : '';
    const prefix = `${timestamp} [${this[LOGGER_SYMBOLS.INSTANCE_ID]}]`;
    const output = this[LOGGER_SYMBOLS.OUTPUT];

    this[LOGGER_SYMBOLS.HISTORY].push({ timestamp, level, message, data });
    if (this[LOGGER_SYMBOLS.HISTORY].length > this[LOGGER_SYMBOLS.MAX_HISTORY]) {
      this[LOGGER_SYMBOLS.HISTORY].shift();
    }

    const styles = this[LOGGER_SYMBOLS.COLORS]
      ? {
          error: 'color: #ff6b6b; font-weight: bold;',
          warn: 'color: #fdcb6e; font-weight: bold;',
          info: 'color: #74b9ff; font-weight: bold;',
          debug: 'color: #a29bfe;',
          success: 'color: #00b894; font-weight: bold;',
        }
      : {};

    const style = styles[level] || styles.info;

    if (data !== null && data !== undefined) {
      if (typeof data === 'object') {
        output.log(`%c${prefix} ${message}`, style, data);
      } else {
        output.log(`%c${prefix} ${message}`, style, data);
      }
    } else {
      output.log(`%c${prefix} ${message}`, style);
    }
  };

  const boundLog = logMethod.bind(loggerState);

  const logger = {
    error: (msg, d) => boundLog('error', `❌ ${msg}`, d),
    warn: (msg, d) => boundLog('warn', `⚠️ ${msg}`, d),
    info: (msg, d) => boundLog('info', `ℹ️ ${msg}`, d),
    debug: (msg, d) => boundLog('debug', `🔍 ${msg}`, d),
    success: (msg, d) => boundLog('info', `✅ ${msg}`, d),

    getHistory: () => [...loggerState[LOGGER_SYMBOLS.HISTORY]],
    clearHistory: () => {
      loggerState[LOGGER_SYMBOLS.HISTORY] = [];
      return logger;
    },
    setDebug: enabled => {
      loggerState[LOGGER_SYMBOLS.DEBUG] = enabled;
      return logger;
    },
    getLevel: () => loggerState[LOGGER_SYMBOLS.LEVEL],
  };

  return logger;
}

const logger = createTemplateLogger(true, 'LogsTemplate');

// ============================================================
// 5. ВАЛИДАТОР (100% СИМВОЛЫ)
// ============================================================

const VALIDATOR_SYMBOLS = {
  IS_VALID_LEVEL: Symbol('validator.isValidLevel'),
  IS_VALID_ENTRY: Symbol('validator.isValidEntry'),
  IS_VALID_FILTER: Symbol('validator.isValidFilter'),
  IS_VALID_STRING: Symbol('validator.isValidString'),
  IS_VALID_NUMBER: Symbol('validator.isValidNumber'),
  IS_VALID_OBJECT: Symbol('validator.isValidObject'),
  SANITIZE: Symbol('validator.sanitize'),
  ESCAPE: Symbol('validator.escape'),
  TRUNCATE: Symbol('validator.truncate'),
};

const VALIDATOR = {
  [VALIDATOR_SYMBOLS.IS_VALID_LEVEL]: level => {
    const levels = Object.values(CONFIG[CONFIG_SYMBOLS.LEVELS]);
    return level && typeof level === 'string' && levels.includes(level.toLowerCase());
  },

  [VALIDATOR_SYMBOLS.IS_VALID_ENTRY]: entry => {
    return (
      entry &&
      typeof entry === 'object' &&
      typeof entry.id === 'number' &&
      entry.timestamp instanceof Date &&
      typeof entry.message === 'string' &&
      VALIDATOR[VALIDATOR_SYMBOLS.IS_VALID_LEVEL](entry.level)
    );
  },

  [VALIDATOR_SYMBOLS.IS_VALID_FILTER]: filter => {
    return filter === null || filter === undefined || typeof filter === 'string';
  },

  [VALIDATOR_SYMBOLS.IS_VALID_STRING]: str => {
    return typeof str === 'string';
  },

  [VALIDATOR_SYMBOLS.IS_VALID_NUMBER]: num => {
    return typeof num === 'number' && !isNaN(num) && isFinite(num);
  },

  [VALIDATOR_SYMBOLS.IS_VALID_OBJECT]: obj => {
    return obj && typeof obj === 'object' && !Array.isArray(obj);
  },

  [VALIDATOR_SYMBOLS.SANITIZE]: value => {
    if (value === null || value === undefined) return null;
    if (typeof value === 'string') {
      return value.replace(/[<>]/g, '').trim();
    }
    if (typeof value === 'object') {
      try {
        return JSON.parse(JSON.stringify(value));
      } catch {
        return null;
      }
    }
    return value;
  },

  [VALIDATOR_SYMBOLS.ESCAPE]: text => {
    if (!text || typeof text !== 'string') return '';
    return text
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  },

  [VALIDATOR_SYMBOLS.TRUNCATE]: (text, maxLength) => {
    if (!text || typeof text !== 'string') return '';
    const max = maxLength || CONFIG[CONFIG_SYMBOLS.TRUNCATE_LENGTH];
    if (text.length <= max) return text;
    return text.substring(0, max) + '...';
  },
};

// ============================================================
// 6. ОСНОВНОЙ ОБЪЕКТ ШАБЛОНА (100% СИМВОЛЫ)
// ============================================================

const LogsTemplate = {};

// ============================================================
// 6.1 ★★★ СОСТОЯНИЕ ШАБЛОНА ★★★
// ============================================================

const templateState = {
  [PRIVATE.LOG_ENTRIES]: [],
  [PRIVATE.FILTERED_ENTRIES]: [],
  [PRIVATE.CURRENT_FILTER]: CONFIG[CONFIG_SYMBOLS.DEFAULT_FILTER],
  [PRIVATE.CURRENT_LEVEL]: CONFIG[CONFIG_SYMBOLS.DEFAULT_LEVEL],
  [PRIVATE.IS_PAUSED]: false,
  [PRIVATE.IS_FOLLOWING]: true,
  [PRIVATE.CACHE]: new Map(),
  [PRIVATE.TIMESTAMP]: Date.now(),
};

// ============================================================
// 6.2 ★★★ ВСПОМОГАТЕЛЬНЫЕ МЕТОДЫ ★★★
// ============================================================

LogsTemplate[PRIVATE.ESCAPE_HTML] = function (text) {
  return VALIDATOR[VALIDATOR_SYMBOLS.ESCAPE](text);
};

LogsTemplate[PRIVATE.FORMAT_TIME] = function (date) {
  if (!(date instanceof Date)) return '';
  return date.toLocaleTimeString('ru-RU', {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
  });
};

LogsTemplate[PRIVATE.GET_LEVEL_COLOR] = function (level) {
  const colors = CONFIG[CONFIG_SYMBOLS.COLORS];
  return colors[level] || colors.info;
};

LogsTemplate[PRIVATE.GET_LEVEL_LABEL] = function (level) {
  const labels = CONFIG[CONFIG_SYMBOLS.LABELS];
  return labels[level] || level.toUpperCase();
};

LogsTemplate[PRIVATE.GET_LEVEL_ICON] = function (level) {
  const icons = CONFIG[CONFIG_SYMBOLS.ICONS];
  return icons[level] || '📌';
};

LogsTemplate[PRIVATE.TRUNCATE] = function (text, maxLength) {
  return VALIDATOR[VALIDATOR_SYMBOLS.TRUNCATE](text, maxLength);
};

LogsTemplate[PRIVATE.BUILD_ENTRY] = function (entry) {
  if (!VALIDATOR[VALIDATOR_SYMBOLS.IS_VALID_ENTRY](entry)) {
    logger.warn('⚠️ Некорректная запись лога:', entry);
    return null;
  }

  const time = LogsTemplate[PRIVATE.FORMAT_TIME](entry.timestamp);
  const level = entry.level || 'info';
  const color = LogsTemplate[PRIVATE.GET_LEVEL_COLOR](level);
  const label = LogsTemplate[PRIVATE.GET_LEVEL_LABEL](level);
  const icon = LogsTemplate[PRIVATE.GET_LEVEL_ICON](level);
  const message = LogsTemplate[PRIVATE.ESCAPE_HTML](entry.message);
  const truncated = LogsTemplate[PRIVATE.TRUNCATE](message);

  return {
    time,
    level,
    color,
    label,
    icon,
    message,
    truncated,
    raw: entry,
  };
};

// ============================================================
// 6.3 ★★★ СТИЛИ ★★★
// ============================================================

LogsTemplate[PRIVATE.STYLES] = function (theme = 'dark') {
  const themeConfig = CONFIG[CONFIG_SYMBOLS.THEME][theme] || CONFIG[CONFIG_SYMBOLS.THEME].dark;

  return {
    container: `
      flex: 1;
      background: ${themeConfig.bg};
      border-radius: 6px;
      padding: 8px;
      overflow-y: auto;
      font-family: 'Courier New', monospace;
      font-size: 11px;
      line-height: 1.5;
      min-height: 100px;
      border: 1px solid ${themeConfig.border};
      color: ${themeConfig.text};
      scrollbar-width: thin;
      scrollbar-color: ${themeConfig.scrollbar} transparent;
    `,

    entry: `
      padding: 2px 0;
      border-bottom: 1px solid rgba(255,255,255,0.03);
      display: flex;
      gap: 6px;
      align-items: flex-start;
      transition: background 0.15s ease;
    `,

    time: `
      color: ${themeConfig.muted};
      font-size: 9px;
      min-width: 60px;
      flex-shrink: 0;
      font-weight: 400;
    `,

    level: `
      font-size: 9px;
      padding: 0 5px;
      border-radius: 3px;
      font-weight: 600;
      flex-shrink: 0;
    `,

    message: `
      color: ${themeConfig.text};
      word-break: break-all;
      flex: 1;
      font-weight: 400;
    `,

    empty: `
      color: ${themeConfig.empty};
      text-align: center;
      padding: 20px;
      font-style: italic;
      font-size: 12px;
    `,

    hover: `
      background: ${themeConfig.hover};
    `,

    scrollbar: `
      &::-webkit-scrollbar {
        width: 4px;
      }
      &::-webkit-scrollbar-track {
        background: transparent;
        border-radius: 2px;
      }
      &::-webkit-scrollbar-thumb {
        background: ${themeConfig.scrollbar};
        border-radius: 2px;
      }
      &::-webkit-scrollbar-thumb:hover {
        background: rgba(102,126,234,0.5);
      }
    `,
  };
};

// ============================================================
// 6.4 ★★★ КОНТРОЛЫ ★★★
// ============================================================

LogsTemplate[PRIVATE.CONTROLS] = function () {
  return `
    <div id="logs-controls" style="
      display: flex;
      flex-direction: column;
      gap: 6px;
      flex-shrink: 0;
      padding-bottom: 6px;
      border-bottom: 1px solid var(--border-color, rgba(255,255,255,0.05));
    ">
      <div style="display:flex;gap:6px;flex-wrap:wrap;">
        <input id="logs-filter" type="text" placeholder="🔍 Фильтр..." style="
          flex: 1;
          min-width: 100px;
          padding: 4px 10px;
          border: 1px solid var(--border-color, rgba(255,255,255,0.1));
          border-radius: 6px;
          background: var(--bg-input, rgba(0,0,0,0.3));
          color: var(--text-primary, #fff);
          font-size: 12px;
          outline: none;
          transition: border-color 0.2s ease, box-shadow 0.2s ease;
          font-family: inherit;
        ">
        <select id="logs-level" style="
          padding: 4px 8px;
          border: 1px solid var(--border-color, rgba(255,255,255,0.1));
          border-radius: 6px;
          background: var(--bg-input, rgba(0,0,0,0.3));
          color: var(--text-primary, #fff);
          font-size: 12px;
          outline: none;
          cursor: pointer;
          font-family: inherit;
          transition: border-color 0.2s ease;
        ">
          <option value="all">📊 Все</option>
          <option value="debug">🔍 Debug</option>
          <option value="info">ℹ️ Info</option>
          <option value="warn">⚠️ Warn</option>
          <option value="error">❌ Error</option>
          <option value="success">✅ Success</option>
          <option value="trace">🔎 Trace</option>
          <option value="verbose">📝 Verbose</option>
        </select>
      </div>
      <div style="display:flex;gap:4px;flex-wrap:wrap;">
        <button id="logs-pause-btn" class="logs-control-btn" style="
          padding: 3px 12px;
          border: 1px solid var(--border-color, rgba(255,255,255,0.1));
          border-radius: 4px;
          background: var(--bg-btn, rgba(255,255,255,0.05));
          color: var(--text-muted, #8899bb);
          font-size: 11px;
          cursor: pointer;
          transition: all 0.2s ease;
          font-family: inherit;
        ">⏸️ Пауза</button>
        <button id="logs-clear-btn" class="logs-control-btn" style="
          padding: 3px 12px;
          border: 1px solid var(--border-color, rgba(255,255,255,0.1));
          border-radius: 4px;
          background: var(--bg-btn, rgba(255,255,255,0.05));
          color: var(--text-muted, #8899bb);
          font-size: 11px;
          cursor: pointer;
          transition: all 0.2s ease;
          font-family: inherit;
        ">🗑️ Очистить</button>
        <button id="logs-export-btn" class="logs-control-btn" style="
          padding: 3px 12px;
          border: 1px solid var(--border-color, rgba(255,255,255,0.1));
          border-radius: 4px;
          background: var(--bg-btn, rgba(255,255,255,0.05));
          color: var(--text-muted, #8899bb);
          font-size: 11px;
          cursor: pointer;
          transition: all 0.2s ease;
          font-family: inherit;
        ">📥 Экспорт</button>
        <button id="logs-follow-btn" class="logs-control-btn active" style="
          padding: 3px 12px;
          border: 1px solid var(--active-border, rgba(0,184,148,0.3));
          border-radius: 4px;
          background: var(--active-bg, rgba(0,184,148,0.1));
          color: var(--active-color, #00b894);
          font-size: 11px;
          cursor: pointer;
          transition: all 0.2s ease;
          font-family: inherit;
        ">▶️ Следить</button>
      </div>
    </div>
  `;
};

// ============================================================
// 6.5 ★★★ КОНСОЛЬ ★★★
// ============================================================

LogsTemplate[PRIVATE.CONSOLE] = function () {
  const styles = LogsTemplate[PRIVATE.STYLES]();

  return `
    <div id="logs-console" style="${styles.container} ${styles.scrollbar}">
      <div class="logs-empty" style="${styles.empty}">
        📭 Логи будут отображаться здесь...
      </div>
    </div>
  `;
};

// ============================================================
// 6.6 ★★★ СТАТИСТИКА ★★★
// ============================================================

LogsTemplate[PRIVATE.STATS] = function () {
  return `
    <div id="logs-stats" style="
      display: flex;
      gap: 12px;
      font-size: 11px;
      color: var(--text-muted, #8899bb);
      padding-top: 6px;
      border-top: 1px solid var(--border-color, rgba(255,255,255,0.05));
      flex-wrap: wrap;
      flex-shrink: 0;
      margin-top: 6px;
    ">
      <span>📊 Всего: <b id="logs-total" style="color: var(--text-primary, #dfe6e9);">0</b></span>
      <span style="color: #ff6b6b;">❌ <b id="logs-errors" style="color: #ff6b6b;">0</b></span>
      <span style="color: #fdcb6e;">⚠️ <b id="logs-warnings" style="color: #fdcb6e;">0</b></span>
      <span style="color: #00b894;">✅ <b id="logs-success" style="color: #00b894;">0</b></span>
      <span style="color: #74b9ff;">ℹ️ <b id="logs-info" style="color: #74b9ff;">0</b></span>
      <span style="color: #a29bfe;">🔍 <b id="logs-debug" style="color: #a29bfe;">0</b></span>
      <span id="logs-status" style="color: #00b894;">▶️ Активен</span>
    </div>
  `;
};

// ============================================================
// 6.7 ★★★ ПУСТОЕ СОСТОЯНИЕ ★★★
// ============================================================

LogsTemplate[PRIVATE.EMPTY_STATE] = function (filter = '', level = 'all') {
  const styles = LogsTemplate[PRIVATE.STYLES]();

  let message = '📭 Нет логов';
  if (filter) {
    message += ` по фильтру "${filter}"`;
  }
  if (level !== 'all') {
    message += ` (уровень: ${level})`;
  }

  return `<div class="logs-empty" style="${styles.empty}">${message}</div>`;
};

// ============================================================
// 6.8 ★★★ ФИЛЬТРЫ ★★★
// ============================================================

LogsTemplate[PRIVATE.FILTERS] = function (entries = [], filter = '', level = 'all') {
  if (!Array.isArray(entries)) return [];

  let filtered = entries;

  // Фильтр по тексту
  if (filter && typeof filter === 'string') {
    const lowerFilter = filter.toLowerCase();
    filtered = filtered.filter(entry => {
      const message = entry.message || '';
      return message.toLowerCase().includes(lowerFilter);
    });
  }

  // Фильтр по уровню
  if (level && level !== 'all') {
    filtered = filtered.filter(entry => {
      const entryLevel = entry.level || 'info';
      return entryLevel === level;
    });
  }

  return filtered;
};

// ============================================================
// 6.9 ★★★ АКЦИИ ★★★
// ============================================================

LogsTemplate[PRIVATE.ACTIONS] = function () {
  return {
    pause: isPaused => {
      const btn = document.getElementById('logs-pause-btn');
      if (btn) {
        btn.textContent = isPaused ? '▶️ Возобновить' : '⏸️ Пауза';
      }
      const status = document.getElementById('logs-status');
      if (status) {
        status.textContent = isPaused ? '⏸️ Пауза' : '▶️ Активен';
        status.style.color = isPaused ? '#fdcb6e' : '#00b894';
      }
    },

    follow: isFollowing => {
      const btn = document.getElementById('logs-follow-btn');
      if (btn) {
        btn.textContent = isFollowing ? '▶️ Следить' : '⏹️ Не следить';
        btn.style.borderColor = isFollowing
          ? 'rgba(0,184,148,0.3)'
          : 'var(--border-color, rgba(255,255,255,0.1))';
        btn.style.background = isFollowing
          ? 'rgba(0,184,148,0.1)'
          : 'var(--bg-btn, rgba(255,255,255,0.05))';
        btn.style.color = isFollowing ? '#00b894' : 'var(--text-muted, #8899bb)';
      }
    },

    updateStats: entries => {
      const total = entries.length;
      const errors = entries.filter(e => e.level === 'error').length;
      const warnings = entries.filter(e => e.level === 'warn').length;
      const success = entries.filter(e => e.level === 'success').length;
      const info = entries.filter(e => e.level === 'info').length;
      const debug = entries.filter(e => e.level === 'debug').length;

      const totalEl = document.getElementById('logs-total');
      const errorsEl = document.getElementById('logs-errors');
      const warningsEl = document.getElementById('logs-warnings');
      const successEl = document.getElementById('logs-success');
      const infoEl = document.getElementById('logs-info');
      const debugEl = document.getElementById('logs-debug');

      if (totalEl) totalEl.textContent = total;
      if (errorsEl) errorsEl.textContent = errors;
      if (warningsEl) warningsEl.textContent = warnings;
      if (successEl) successEl.textContent = success;
      if (infoEl) infoEl.textContent = info;
      if (debugEl) debugEl.textContent = debug;
    },

    renderEntry: entry => {
      const built = LogsTemplate[PRIVATE.BUILD_ENTRY](entry);
      if (!built) return '';

      const styles = LogsTemplate[PRIVATE.STYLES]();

      return `
        <div class="logs-entry" style="${styles.entry}" data-level="${built.level}" data-id="${entry.id}">
          <span class="logs-time" style="${styles.time}">${built.time}</span>
          <span class="logs-level ${built.level}" style="${styles.level} color: ${built.color};">${built.label}</span>
          <span class="logs-message" style="${styles.message}">${built.message}</span>
        </div>
      `;
    },

    renderEntries: (entries, isFollowing = true) => {
      const styles = LogsTemplate[PRIVATE.STYLES]();
      const consoleEl = document.getElementById('logs-console');

      if (!consoleEl) return;

      if (!entries || entries.length === 0) {
        consoleEl.innerHTML = LogsTemplate[PRIVATE.EMPTY_STATE](
          templateState[PRIVATE.CURRENT_FILTER],
          templateState[PRIVATE.CURRENT_LEVEL]
        );
        return;
      }

      const displayEntries = isFollowing ? entries : entries.slice(-100);
      let html = '';

      for (const entry of displayEntries) {
        html += LogsTemplate[PRIVATE.ACTIONS]().renderEntry(entry);
      }

      consoleEl.innerHTML = html;

      // Прокрутка вниз если следим
      if (isFollowing) {
        consoleEl.scrollTop = consoleEl.scrollHeight;
      }
    },
  };
};

// ============================================================
// 6.10 ★★★ ПОСТРОЕНИЕ ПОЛНОГО ШАБЛОНА ★★★
// ============================================================

LogsTemplate[PRIVATE.TEMPLATE] = function (options = {}) {
  const {
    panelId = 'logs-control-panel',
    panelType = 'logs',
    instanceId = 'unknown',
    icon = '📋',
    title = 'Logs Control',
    status = 'off',
    theme = 'dark',
  } = options;

  const styles = LogsTemplate[PRIVATE.STYLES](theme);

  return `
    <div id="${panelId}" 
         data-panel-type="${panelType}" 
         data-instance-id="${instanceId}"
         class="panel-container logs-panel"
         style="
           position: fixed;
           display: flex;
           flex-direction: column;
           overflow: hidden;
           background: rgba(26, 26, 46, 0.96);
           backdrop-filter: blur(20px);
           border: 1px solid rgba(255,255,255,0.08);
           border-radius: 12px;
           color: #fff;
           font-family: 'Segoe UI', system-ui, sans-serif;
           font-size: 13px;
           box-shadow: 0 20px 60px rgba(0,0,0,0.8);
           min-width: 320px;
           min-height: 300px;
           max-width: 90vw;
           max-height: 90vh;
           user-select: none;
         ">

      <!-- Шапка -->
      <div id="panel-header" style="
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 8px 14px;
        border-bottom: 1px solid rgba(255,255,255,0.06);
        cursor: grab;
        flex-shrink: 0;
        min-height: 44px;
        background: rgba(26, 26, 46, 0.98);
      ">
        <span style="
          font-weight: bold;
          font-size: 14px;
          display: flex;
          align-items: center;
          gap: 8px;
        ">
          <span>${icon}</span>
          <span>${title}</span>
          <span id="panel-status-badge" style="
            font-size: 9px;
            padding: 1px 8px;
            border-radius: 10px;
            background: ${status === 'off' ? 'rgba(255,255,255,0.05)' : 'rgba(0,184,148,0.15)'};
            color: ${status === 'off' ? '#636e72' : '#00b894'};
            border: 1px solid ${status === 'off' ? 'rgba(255,255,255,0.05)' : 'rgba(0,184,148,0.2)'};
            margin-left: 8px;
          ">${status}</span>
        </span>
        <div class="panel-controls" style="display:flex;gap:2px;flex-shrink:0;">
          <button id="panel-minimize-btn" style="
            background:none;border:none;color:#8899bb;cursor:pointer;font-size:16px;
            padding:0 4px;width:28px;height:28px;display:flex;align-items:center;
            justify-content:center;border-radius:4px;transition:all 0.2s;
          " title="Свернуть">─</button>
          <button id="panel-maximize-btn" style="
            background:none;border:none;color:#8899bb;cursor:pointer;font-size:14px;
            padding:0 4px;width:28px;height:28px;display:flex;align-items:center;
            justify-content:center;border-radius:4px;transition:all 0.2s;
          " title="Развернуть">□</button>
          <button id="panel-close-btn" style="
            background:none;border:none;color:#8899bb;cursor:pointer;font-size:16px;
            padding:0 4px;width:28px;height:28px;display:flex;align-items:center;
            justify-content:center;border-radius:4px;transition:all 0.2s;
          " title="Закрыть">✕</button>
        </div>
      </div>

      <!-- Тело -->
      <div id="panel-body" style="
        flex: 1;
        overflow-y: auto;
        padding: 10px 14px 14px 14px;
        scrollbar-width: thin;
        scrollbar-color: rgba(102,126,234,0.3) transparent;
      ">
        ${LogsTemplate[PRIVATE.CONTROLS]()}
        ${LogsTemplate[PRIVATE.CONSOLE]()}
        ${LogsTemplate[PRIVATE.STATS]()}
      </div>

      <!-- Ресайз -->
      <div id="panel-resize" style="
        position: absolute;
        bottom: 0;
        right: 0;
        width: 16px;
        height: 16px;
        cursor: nwse-resize;
        z-index: 10;
        background: linear-gradient(135deg, transparent 50%, rgba(102,126,234,0.2) 50%);
        border-radius: 0 0 12px 0;
      "></div>
    </div>
  `;
};

// ============================================================
// 6.11 ★★★ ПУБЛИЧНЫЕ МЕТОДЫ ШАБЛОНА ★★★
// ============================================================

export function renderLogsTemplate(options = {}) {
  return LogsTemplate[PRIVATE.TEMPLATE](options);
}

export function renderLogsControls() {
  return LogsTemplate[PRIVATE.CONTROLS]();
}

export function renderLogsConsole() {
  return LogsTemplate[PRIVATE.CONSOLE]();
}

export function renderLogsStats() {
  return LogsTemplate[PRIVATE.STATS]();
}

export function renderLogsEmpty(filter = '', level = 'all') {
  return LogsTemplate[PRIVATE.EMPTY_STATE](filter, level);
}

export function renderLogEntry(entry) {
  return LogsTemplate[PRIVATE.ACTIONS]().renderEntry(entry);
}

export function renderLogEntries(entries, isFollowing = true) {
  return LogsTemplate[PRIVATE.ACTIONS]().renderEntries(entries, isFollowing);
}

export function filterLogs(entries, filter = '', level = 'all') {
  return LogsTemplate[PRIVATE.FILTERS](entries, filter, level);
}

// ============================================================
// 6.12 ★★★ УПРАВЛЕНИЕ СОСТОЯНИЕМ ★★★
// ============================================================

export function getLogsTemplateState() {
  return {
    entries: templateState[PRIVATE.LOG_ENTRIES].length,
    filtered: templateState[PRIVATE.FILTERED_ENTRIES].length,
    filter: templateState[PRIVATE.CURRENT_FILTER],
    level: templateState[PRIVATE.CURRENT_LEVEL],
    isPaused: templateState[PRIVATE.IS_PAUSED],
    isFollowing: templateState[PRIVATE.IS_FOLLOWING],
    cacheSize: templateState[PRIVATE.CACHE].size,
    timestamp: templateState[PRIVATE.TIMESTAMP],
  };
}

export function updateLogsTemplateState(newState) {
  if (newState.filter !== undefined) {
    templateState[PRIVATE.CURRENT_FILTER] = newState.filter;
  }
  if (newState.level !== undefined) {
    templateState[PRIVATE.CURRENT_LEVEL] = newState.level;
  }
  if (newState.isPaused !== undefined) {
    templateState[PRIVATE.IS_PAUSED] = newState.isPaused;
    LogsTemplate[PRIVATE.ACTIONS]().pause(newState.isPaused);
  }
  if (newState.isFollowing !== undefined) {
    templateState[PRIVATE.IS_FOLLOWING] = newState.isFollowing;
    LogsTemplate[PRIVATE.ACTIONS]().follow(newState.isFollowing);
  }
  return getLogsTemplateState();
}

export function resetLogsTemplateState() {
  templateState[PRIVATE.LOG_ENTRIES] = [];
  templateState[PRIVATE.FILTERED_ENTRIES] = [];
  templateState[PRIVATE.CURRENT_FILTER] = CONFIG[CONFIG_SYMBOLS.DEFAULT_FILTER];
  templateState[PRIVATE.CURRENT_LEVEL] = CONFIG[CONFIG_SYMBOLS.DEFAULT_LEVEL];
  templateState[PRIVATE.IS_PAUSED] = false;
  templateState[PRIVATE.IS_FOLLOWING] = true;
  templateState[PRIVATE.CACHE].clear();
  templateState[PRIVATE.TIMESTAMP] = Date.now();

  LogsTemplate[PRIVATE.ACTIONS]().pause(false);
  LogsTemplate[PRIVATE.ACTIONS]().follow(true);
  LogsTemplate[PRIVATE.ACTIONS]().updateStats([]);

  return getLogsTemplateState();
}

// ============================================================
// 6.13 ★★★ УТИЛИТЫ ★★★
// ============================================================

export function escapeHtml(text) {
  return LogsTemplate[PRIVATE.ESCAPE_HTML](text);
}

export function formatTime(date) {
  return LogsTemplate[PRIVATE.FORMAT_TIME](date);
}

export function getLevelColor(level) {
  return LogsTemplate[PRIVATE.GET_LEVEL_COLOR](level);
}

export function getLevelLabel(level) {
  return LogsTemplate[PRIVATE.GET_LEVEL_LABEL](level);
}

export function getLevelIcon(level) {
  return LogsTemplate[PRIVATE.GET_LEVEL_ICON](level);
}

export function truncateText(text, maxLength) {
  return LogsTemplate[PRIVATE.TRUNCATE](text, maxLength);
}

export function buildLogEntry(entry) {
  return LogsTemplate[PRIVATE.BUILD_ENTRY](entry);
}

// ============================================================
// 6.14 ★★★ СТАТИСТИКА ШАБЛОНА ★★★
// ============================================================

export function getLogsTemplateStats() {
  const entries = templateState[PRIVATE.LOG_ENTRIES];
  const levels = {};

  for (const entry of entries) {
    const level = entry.level || 'info';
    levels[level] = (levels[level] || 0) + 1;
  }

  return {
    total: entries.length,
    filtered: templateState[PRIVATE.FILTERED_ENTRIES].length,
    levels,
    isPaused: templateState[PRIVATE.IS_PAUSED],
    isFollowing: templateState[PRIVATE.IS_FOLLOWING],
    filter: templateState[PRIVATE.CURRENT_FILTER],
    level: templateState[PRIVATE.CURRENT_LEVEL],
    cacheSize: templateState[PRIVATE.CACHE].size,
    timestamp: templateState[PRIVATE.TIMESTAMP],
    version: '2.1.9',
  };
}

// ============================================================
// 6.15 ★★★ УНИЧТОЖЕНИЕ ★★★
// ============================================================

export function destroyLogsTemplate() {
  templateState[PRIVATE.LOG_ENTRIES] = [];
  templateState[PRIVATE.FILTERED_ENTRIES] = [];
  templateState[PRIVATE.CACHE].clear();

  if (typeof window !== 'undefined') {
    delete window[PUBLIC.API];
    delete window[PUBLIC.STATE];
    delete window[PUBLIC.CONFIG];
    delete window[PUBLIC.RENDERER];
    delete window[PUBLIC.INSTANCE];
    delete window[PUBLIC.EVENTS];
  }

  logger.success('🗑️ LogsTemplate уничтожен');
  return true;
}

// ============================================================
// 7. ★★★ ГЛОБАЛЬНАЯ РЕГИСТРАЦИЯ ★★★
// ============================================================

if (typeof window !== 'undefined') {
  // Экспорт через публичные символы
  window[PUBLIC.API] = {
    render: renderLogsTemplate,
    controls: renderLogsControls,
    console: renderLogsConsole,
    stats: renderLogsStats,
    empty: renderLogsEmpty,
    entry: renderLogEntry,
    entries: renderLogEntries,
    filter: filterLogs,
  };

  window[PUBLIC.STATE] = getLogsTemplateState;
  window[PUBLIC.CONFIG] = CONFIG;
  window[PUBLIC.RENDERER] = {
    renderLogsTemplate,
    renderLogsControls,
    renderLogsConsole,
    renderLogsStats,
    renderLogsEmpty,
    renderLogEntry,
    renderLogEntries,
    filterLogs,
  };
  window[PUBLIC.INSTANCE] = LogsTemplate;
  window[PUBLIC.EVENTS] = {
    on: (event, callback) => {
      if (typeof callback === 'function') {
        const handlers = templateState[PRIVATE.CACHE];
        if (!handlers.has(event)) {
          handlers.set(event, []);
        }
        handlers.get(event).push(callback);
        return () => {
          const list = handlers.get(event);
          if (list) {
            const index = list.indexOf(callback);
            if (index !== -1) list.splice(index, 1);
          }
        };
      }
      return () => {};
    },
    emit: (event, data) => {
      const handlers = templateState[PRIVATE.CACHE];
      if (handlers.has(event)) {
        for (const callback of handlers.get(event)) {
          try {
            callback(data);
          } catch (e) {
            logger.error(`❌ Ошибка в обработчике ${event}:`, e.message);
          }
        }
      }
    },
  };

  // Глобальные команды
  window.__logsTemplate = {
    render: renderLogsTemplate,
    controls: renderLogsControls,
    console: renderLogsConsole,
    stats: renderLogsStats,
    empty: renderLogsEmpty,
    entry: renderLogEntry,
    entries: renderLogEntries,
    filter: filterLogs,
    getState: getLogsTemplateState,
    updateState: updateLogsTemplateState,
    resetState: resetLogsTemplateState,
    getStats: getLogsTemplateStats,
    escape: escapeHtml,
    formatTime,
    getLevelColor,
    getLevelLabel,
    getLevelIcon,
    truncate: truncateText,
    buildEntry: buildLogEntry,
    destroy: destroyLogsTemplate,
    getSymbols: () => ({
      PRIVATE: { ...PRIVATE },
      PUBLIC: { ...PUBLIC },
      CONFIG_SYMBOLS: { ...CONFIG_SYMBOLS },
      LOGGER_SYMBOLS: { ...LOGGER_SYMBOLS },
      VALIDATOR_SYMBOLS: { ...VALIDATOR_SYMBOLS },
    }),
  };

  // Баннер
  console.log('╔═══════════════════════════════════════════════════════════════════════════════╗');
  console.log('║              📦 LOGS TEMPLATE (100% СИМВОЛЫ) v2.1.9                         ║');
  console.log('╠═══════════════════════════════════════════════════════════════════════════════╣');
  console.log('║  📋 Полный шаблон для панели логов                                          ║');
  console.log('║  🔑 Полная изоляция через приватные символы                                 ║');
  console.log('║  🔓 Публичные символы через Symbol.for                                      ║');
  console.log('║  📊 4 секции: controls, console, stats, empty                              ║');
  console.log('║  🎨 2 темы: dark (по умолчанию) и light                                   ║');
  console.log('║  🔍 7 уровней логирования: debug, info, warn, error, success, trace, verbose ║');
  console.log('║  📝 Экранирование HTML и усечение текста                                  ║');
  console.log('║  💾 Встроенное кеширование и состояние                                    ║');
  console.log('║  📡 Система событий (on/emit)                                             ║');
  console.log('║  🧹 Очистка и уничтожение                                                ║');
  console.log('╚═══════════════════════════════════════════════════════════════════════════════╝');

  console.log('📋 КОМАНДЫ ОТЛАДКИ (__logsTemplate):');
  console.log('  __logsTemplate.render(options)          - полный шаблон');
  console.log('  __logsTemplate.controls()               - контролы');
  console.log('  __logsTemplate.console()               - консоль');
  console.log('  __logsTemplate.stats()                 - статистика');
  console.log('  __logsTemplate.empty(filter, level)    - пустое состояние');
  console.log('  __logsTemplate.entry(entry)            - одна запись');
  console.log('  __logsTemplate.entries(entries, follow) - множество записей');
  console.log('  __logsTemplate.filter(entries, filter) - фильтрация');
  console.log('  __logsTemplate.getState()              - состояние');
  console.log('  __logsTemplate.updateState({})         - обновить состояние');
  console.log('  __logsTemplate.resetState()            - сбросить состояние');
  console.log('  __logsTemplate.getStats()              - статистика');
  console.log('  __logsTemplate.escape(text)            - экранирование');
  console.log('  __logsTemplate.formatTime(date)        - формат времени');
  console.log('  __logsTemplate.getLevelColor(level)    - цвет уровня');
  console.log('  __logsTemplate.getLevelLabel(level)    - метка уровня');
  console.log('  __logsTemplate.getLevelIcon(level)     - иконка уровня');
  console.log('  __logsTemplate.truncate(text, max)     - усечение');
  console.log('  __logsTemplate.buildEntry(entry)       - построить запись');
  console.log('  __logsTemplate.destroy()               - уничтожить');
  console.log('  __logsTemplate.getSymbols()            - получить все символы');
  console.log('');

  console.log('📋 УРОВНИ ЛОГИРОВАНИЯ:');
  console.log('  🔍 debug    - #667eea  - отладка');
  console.log('  ℹ️ info     - #74b9ff  - информация');
  console.log('  ⚠️ warn     - #fdcb6e  - предупреждения');
  console.log('  ❌ error    - #ff6b6b  - ошибки');
  console.log('  ✅ success  - #00b894  - успех');
  console.log('  🔎 trace    - #a29bfe  - трассировка');
  console.log('  📝 verbose  - #636e72  - подробно');
  console.log('');

  console.log('📋 ПРИВАТНЫХ СИМВОЛОВ:', Object.keys(PRIVATE).length);
  console.log('📋 ПУБЛИЧНЫХ СИМВОЛОВ:', Object.keys(PUBLIC).length);
  console.log('📋 КОНФИГ СИМВОЛОВ:', Object.keys(CONFIG_SYMBOLS).length);
  console.log('📋 ЛОГГЕР СИМВОЛОВ:', Object.keys(LOGGER_SYMBOLS).length);
  console.log('📋 ВАЛИДАТОР СИМВОЛОВ:', Object.keys(VALIDATOR_SYMBOLS).length);
  console.log('═══════════════════════════════════════════════════════════════════════════════');
}

// ============================================================
// 8. ★★★ ЭКСПОРТЫ ★★★
// ============================================================

export {
  PRIVATE,
  PUBLIC,
  CONFIG_SYMBOLS,
  CONFIG,
  LOGGER_SYMBOLS,
  VALIDATOR_SYMBOLS,
  LogsTemplate,
  logger as LogsTemplateLogger,
  // Основные функции
  renderLogsTemplate,
  renderLogsControls,
  renderLogsConsole,
  renderLogsStats,
  renderLogsEmpty,
  renderLogEntry,
  renderLogEntries,
  filterLogs,
  // Состояние
  getLogsTemplateState,
  updateLogsTemplateState,
  resetLogsTemplateState,
  // Утилиты
  escapeHtml,
  formatTime,
  getLevelColor,
  getLevelLabel,
  getLevelIcon,
  truncateText,
  buildLogEntry,
  // Статистика
  getLogsTemplateStats,
  // Уничтожение
  destroyLogsTemplate,
};

// ============================================================
// 9. ★★★ ДЕФОЛТНЫЙ ЭКСПОРТ ★★★
// ============================================================

export default {
  render: renderLogsTemplate,
  controls: renderLogsControls,
  console: renderLogsConsole,
  stats: renderLogsStats,
  empty: renderLogsEmpty,
  entry: renderLogEntry,
  entries: renderLogEntries,
  filter: filterLogs,
  getState: getLogsTemplateState,
  updateState: updateLogsTemplateState,
  resetState: resetLogsTemplateState,
  getStats: getLogsTemplateStats,
  escape: escapeHtml,
  formatTime,
  getLevelColor,
  getLevelLabel,
  getLevelIcon,
  truncate: truncateText,
  buildEntry: buildLogEntry,
  destroy: destroyLogsTemplate,
  on: (event, callback) => {
    const handlers = templateState[PRIVATE.CACHE];
    if (!handlers.has(event)) {
      handlers.set(event, []);
    }
    handlers.get(event).push(callback);
    return () => {
      const list = handlers.get(event);
      if (list) {
        const index = list.indexOf(callback);
        if (index !== -1) list.splice(index, 1);
      }
    };
  },
  emit: (event, data) => {
    const handlers = templateState[PRIVATE.CACHE];
    if (handlers.has(event)) {
      for (const callback of handlers.get(event)) {
        try {
          callback(data);
        } catch (e) {
          logger.error(`❌ Ошибка в обработчике ${event}:`, e.message);
        }
      }
    }
  },
  getSymbols: () => ({
    PRIVATE: { ...PRIVATE },
    PUBLIC: { ...PUBLIC },
    CONFIG_SYMBOLS: { ...CONFIG_SYMBOLS },
    LOGGER_SYMBOLS: { ...LOGGER_SYMBOLS },
    VALIDATOR_SYMBOLS: { ...VALIDATOR_SYMBOLS },
  }),
};
