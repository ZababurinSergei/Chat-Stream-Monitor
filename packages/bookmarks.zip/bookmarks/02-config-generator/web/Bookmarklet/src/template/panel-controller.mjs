// web/Bookmarklet/src/controller/panel-controller.mjs
// 100% СИМВОЛЫ — полная изоляция и безопасность
// Базовый контроллер для панелей
// Версия: 2.2.0

// ============================================================
// 1. ПРИВАТНЫЕ СИМВОЛЫ (100% изоляция)
// ============================================================

const PRIVATE = {
  // Основные символы контроллера
  PANEL: Symbol('panel-controller.panel'),
  MIN_BTN: Symbol('panel-controller.minBtn'),
  MAX_BTN: Symbol('panel-controller.maxBtn'),
  CLOSE_BTN: Symbol('panel-controller.closeBtn'),
  HEADER: Symbol('panel-controller.header'),
  BODY: Symbol('panel-controller.body'),
  RESIZE: Symbol('panel-controller.resize'),

  // Символы состояния
  STATE: Symbol('panel-controller.state'),
  CONFIG: Symbol('panel-controller.config'),
  CACHE: Symbol('panel-controller.cache'),
  METADATA: Symbol('panel-controller.metadata'),
  CONTEXT: Symbol('panel-controller.context'),

  // Символы действий
  ACTIONS: Symbol('panel-controller.actions'),
  ACTION_QUEUE: Symbol('panel-controller.actionQueue'),
  IS_PROCESSING: Symbol('panel-controller.isProcessing'),

  // Символы жизненного цикла
  INITIALIZED: Symbol('panel-controller.initialized'),
  DESTROYED: Symbol('panel-controller.destroyed'),
  IS_RUNNING: Symbol('panel-controller.isRunning'),

  // Символы слушателей
  LISTENERS: Symbol('panel-controller.listeners'),
  EVENT_HANDLERS: Symbol('panel-controller.eventHandlers'),
  DOM_LISTENERS: Symbol('panel-controller.domListeners'),

  // Символы таймеров
  TIMERS: Symbol('panel-controller.timers'),
  RAF_ID: Symbol('panel-controller.rafId'),
  DEBOUNCE_TIMERS: Symbol('panel-controller.debounceTimers'),

  // Символы логгера
  LOGGER: Symbol('panel-controller.logger'),
  LOG_HISTORY: Symbol('panel-controller.logHistory'),
  DEBUG: Symbol('panel-controller.debug'),

  // Символы утилит
  BIND_METHODS: Symbol('panel-controller.bindMethods'),
  VALIDATE_PANEL: Symbol('panel-controller.validatePanel'),
  VALIDATE_STATE: Symbol('panel-controller.validateState'),
  SANITIZE_CONFIG: Symbol('panel-controller.sanitizeConfig'),
  DEEP_CLONE: Symbol('panel-controller.deepClone'),
  MERGE_STATE: Symbol('panel-controller.mergeState'),

  // Символы методов (приватные)
  SETUP_DOM: Symbol('panel-controller.setupDom'),
  SETUP_HANDLERS: Symbol('panel-controller.setupHandlers'),
  SETUP_TIMERS: Symbol('panel-controller.setupTimers'),
  CLEANUP: Symbol('panel-controller.cleanup'),
  EMIT: Symbol('panel-controller.emit'),
  NOTIFY: Symbol('panel-controller.notify'),
  LOG: Symbol('panel-controller.log'),
  ERROR: Symbol('panel-controller.error'),
  WARN: Symbol('panel-controller.warn'),
  INFO: Symbol('panel-controller.info'),
  DEBUG_LOG: Symbol('panel-controller.debugLog'),
  SUCCESS: Symbol('panel-controller.success'),

  // Символы действий
  DO_SHOW: Symbol('panel-controller.doShow'),
  DO_HIDE: Symbol('panel-controller.doHide'),
  DO_TOGGLE: Symbol('panel-controller.doToggle'),
  DO_MINIMIZE: Symbol('panel-controller.doMinimize'),
  DO_FULLSCREEN: Symbol('panel-controller.doFullscreen'),
  DO_CLOSE: Symbol('panel-controller.doClose'),
  DO_FOCUS: Symbol('panel-controller.doFocus'),
  DO_RESIZE: Symbol('panel-controller.doResize'),
  DO_MOVE: Symbol('panel-controller.doMove'),

  // Символы состояния панели
  IS_VISIBLE: Symbol('panel-controller.isVisible'),
  IS_MINIMIZED: Symbol('panel-controller.isMinimized'),
  IS_FULLSCREEN: Symbol('panel-controller.isFullscreen'),
  IS_FOCUSED: Symbol('panel-controller.isFocused'),
  Z_INDEX: Symbol('panel-controller.zIndex'),
  POSITION: Symbol('panel-controller.position'),
  SIZE: Symbol('panel-controller.size'),

  // Символы цепочки вызовов
  CHAIN: Symbol('panel-controller.chain'),
  THEN: Symbol('panel-controller.then'),
  CATCH: Symbol('panel-controller.catch'),
  FINALLY: Symbol('panel-controller.finally'),
};

// ============================================================
// 2. ПУБЛИЧНЫЕ СИМВОЛЫ (доступны через Symbol.for)
// ============================================================

const PUBLIC = {
  API: Symbol.for('panel-controller.api'),
  STATE: Symbol.for('panel-controller.state'),
  CONFIG: Symbol.for('panel-controller.config'),
  LOGGER: Symbol.for('panel-controller.logger'),
  EVENTS: Symbol.for('panel-controller.events'),
  INSTANCE: Symbol.for('panel-controller.instance'),
  ACTIONS: Symbol.for('panel-controller.actions'),
  CHAIN: Symbol.for('panel-controller.chain'),
};

// ============================================================
// 3. ЛОГГЕР (100% СИМВОЛЫ)
// ============================================================

const LOGGER_SYMBOLS = {
  HISTORY: Symbol('logger.history'),
  MAX_HISTORY: Symbol('logger.maxHistory'),
  DEBUG: Symbol('logger.debug'),
  INSTANCE_ID: Symbol('logger.instanceId'),
  LEVEL: Symbol('logger.level'),
  TIMESTAMP: Symbol('logger.timestamp'),
  COLORS: Symbol('logger.colors'),
  OUTPUT: Symbol('logger.output'),
  CONTEXT: Symbol('logger.context'),
  METADATA: Symbol('logger.metadata'),
  FILTERS: Symbol('logger.filters'),
  FORMATTERS: Symbol('logger.formatters'),
  SILENT: Symbol('logger.silent'),
  PRETTY: Symbol('logger.pretty'),
  GROUP_LEVEL: Symbol('logger.groupLevel'),
  INDENT: Symbol('logger.indent'),
};

function createControllerLogger(debug = true, instanceId = 'PanelController') {
  const loggerState = {
    [LOGGER_SYMBOLS.HISTORY]: [],
    [LOGGER_SYMBOLS.MAX_HISTORY]: 200,
    [LOGGER_SYMBOLS.DEBUG]: debug,
    [LOGGER_SYMBOLS.INSTANCE_ID]: instanceId,
    [LOGGER_SYMBOLS.LEVEL]: 'info',
    [LOGGER_SYMBOLS.TIMESTAMP]: true,
    [LOGGER_SYMBOLS.COLORS]: true,
    [LOGGER_SYMBOLS.OUTPUT]: console,
    [LOGGER_SYMBOLS.CONTEXT]: new Map(),
    [LOGGER_SYMBOLS.METADATA]: new Map(),
    [LOGGER_SYMBOLS.FILTERS]: new Map(),
    [LOGGER_SYMBOLS.FORMATTERS]: new Map(),
    [LOGGER_SYMBOLS.SILENT]: false,
    [LOGGER_SYMBOLS.PRETTY]: false,
    [LOGGER_SYMBOLS.GROUP_LEVEL]: 0,
    [LOGGER_SYMBOLS.INDENT]: 0,
  };

  const logMethod = function (level, message, data = null) {
    if (this[LOGGER_SYMBOLS.SILENT]) return;
    if (!this[LOGGER_SYMBOLS.DEBUG] && level !== 'error') return;

    const timestamp = this[LOGGER_SYMBOLS.TIMESTAMP]
      ? `[${new Date().toISOString().slice(11, 23)}]`
      : '';
    const indent = '  '.repeat(this[LOGGER_SYMBOLS.INDENT] || 0);
    const prefix = `${timestamp} [${this[LOGGER_SYMBOLS.INSTANCE_ID]}]${indent}`;
    const output = this[LOGGER_SYMBOLS.OUTPUT];

    // Проверяем фильтры
    let shouldLog = true;
    for (const [name, filter] of this[LOGGER_SYMBOLS.FILTERS]) {
      try {
        if (!filter(level, message, data)) {
          shouldLog = false;
          break;
        }
      } catch (e) {
        // Игнорируем ошибки фильтров
      }
    }
    if (!shouldLog) return;

    this[LOGGER_SYMBOLS.HISTORY].push({ timestamp, level, message, data });
    if (this[LOGGER_SYMBOLS.HISTORY].length > this[LOGGER_SYMBOLS.MAX_HISTORY]) {
      this[LOGGER_SYMBOLS.HISTORY].shift();
    }

    // Форматирование
    let formattedMessage = message;
    for (const [name, formatter] of this[LOGGER_SYMBOLS.FORMATTERS]) {
      try {
        formattedMessage = formatter(formattedMessage, data);
      } catch (e) {
        // Игнорируем ошибки форматтеров
      }
    }

    const styles = this[LOGGER_SYMBOLS.COLORS]
      ? {
        error: 'color: #ff6b6b; font-weight: bold;',
        warn: 'color: #fdcb6e; font-weight: bold;',
        info: 'color: #74b9ff; font-weight: bold;',
        debug: 'color: #a29bfe;',
        success: 'color: #00b894; font-weight: bold;',
        trace: 'color: #dfe6e9; font-style: italic;',
        verbose: 'color: #636e72; font-size: 11px;',
        fatal: 'color: #ff0000; font-weight: bold; font-size: 14px;',
      }
      : {};

    const style = styles[level] || styles.info;

    // Контекст
    let contextStr = '';
    if (this[LOGGER_SYMBOLS.CONTEXT].size > 0) {
      const ctx = {};
      for (const [key, value] of this[LOGGER_SYMBOLS.CONTEXT]) {
        ctx[key] = value;
      }
      contextStr = ` [${JSON.stringify(ctx)}]`;
    }

    if (data !== null && data !== undefined) {
      if (typeof data === 'object' && this[LOGGER_SYMBOLS.PRETTY]) {
        output.log(`%c${prefix}${formattedMessage}${contextStr}`, style);
        output.log('%c  📦 ' + JSON.stringify(data, null, 2), 'color: #fdcb6e;');
      } else if (typeof data === 'object') {
        output.log(`%c${prefix}${formattedMessage}${contextStr}`, style, data);
      } else {
        output.log(`%c${prefix}${formattedMessage}${contextStr}`, style, data);
      }
    } else {
      output.log(`%c${prefix}${formattedMessage}${contextStr}`, style);
    }
  };

  const boundLog = logMethod.bind(loggerState);

  const logger = {
      // Основные методы логирования
      error: (msg, d) => boundLog('error', `❌ ${msg}`, d),
      warn: (msg, d) => boundLog('warn', `⚠️ ${msg}`, d),
      info: (msg, d) => boundLog('info', `ℹ️ ${msg}`, d),
      debug: (msg, d) => boundLog('debug', `🔍 ${msg}`, d),
      success: (msg, d) => boundLog('info', `✅ ${msg}`, d),
      trace: (msg, d) => boundLog('trace', `🔎 ${msg}`, d),
      verbose: (msg, d) => boundLog('verbose', `📝 ${msg}`, d),
      fatal: (msg, d) => boundLog('fatal', `💀 ${msg}`, d),

      // Заголовок и разделители
      header: (title) => {
        const output = loggerState[LOGGER_SYMBOLS.OUTPUT];
        output.log('%c' + '═'.repeat(70), 'color: #636e72;');
        output.log(
          '%c  📦 ' + title,
          'background: #1a1a2e; color: #fff; padding: 4px 12px; border-radius: 4px; font-weight: bold;'
        );
        output.log('%c' + '═'.repeat(70), 'color: #636e72;');
      },

      separator: () => {
        const output = loggerState[LOGGER_SYMBOLS.OUTPUT];
        output.log('%c' + '─'.repeat(70), 'color: #636e72;');
      },

      subheader: (title) => {
        const output = loggerState[LOGGER_SYMBOLS.OUTPUT];
        output.log('%c' + '┌' + '─'.repeat(68) + '┐', 'color: #636e72;');
        output.log(`%c│  📌 ${title.padEnd(65)}│`, 'color: #74b9ff;');
        output.log('%c' + '└' + '─'.repeat(68) + '┘', 'color: #636e72;');
      },

      // Управление отступами
      indent: () => {
        loggerState[LOGGER_SYMBOLS.INDENT] = (loggerState[LOGGER_SYMBOLS.INDENT] || 0) + 1;
        return logger;
      },

      outdent: () => {
        loggerState[LOGGER_SYMBOLS.INDENT] = Math.max(0, (loggerState[LOGGER_SYMBOLS.INDENT] || 0) - 1);
        return logger;
      },

      // Группировка
      group: (title, collapsed = true) => {
        const output = loggerState[LOGGER_SYMBOLS.OUTPUT];
        const level = loggerState[LOGGER_SYMBOLS.GROUP_LEVEL] || 0;
        const indent = '  '.repeat(level);

        if (collapsed) {
          output.groupCollapsed(`${indent}📂 ${title}`);
        } else {
          output.group(`${indent}📂 ${title}`);
        }
        loggerState[LOGGER_SYMBOLS.GROUP_LEVEL] = (loggerState[LOGGER_SYMBOLS.GROUP_LEVEL] || 0) + 1;
        return logger;
      },

      groupEnd: () => {
        const output = loggerState[LOGGER_SYMBOLS.OUTPUT};
      output.groupEnd();
      loggerState[LOGGER_SYMBOLS.GROUP_LEVEL] = Math.max(0, (loggerState[LOGGER_SYMBOLS.GROUP_LEVEL] || 1) - 1);
      return logger;
    },

    // Управление контекстом
    setContext: (key, value) => {
      loggerState[LOGGER_SYMBOLS.CONTEXT].set(key, value);
      return logger;
    },

    getContext: (key) => {
      return loggerState[LOGGER_SYMBOLS.CONTEXT].get(key) || null;
    },

    clearContext: () => {
      loggerState[LOGGER_SYMBOLS.CONTEXT].clear();
      return logger;
    },

    // Управление метаданными
    setMetadata: (key, value) => {
      loggerState[LOGGER_SYMBOLS.METADATA].set(key, value);
      return logger;
    },

    getMetadata: (key) => {
      return loggerState[LOGGER_SYMBOLS.METADATA].get(key) || null;
    },

    clearMetadata: () => {
      loggerState[LOGGER_SYMBOLS.METADATA].clear();
      return logger;
    },

    // Управление фильтрами
    addFilter: (name, filter) => {
      if (typeof filter === 'function') {
    loggerState[LOGGER_SYMBOLS.FILTERS].set(name, filter);
  }
  return logger;
},

  removeFilter: (name) => {
    loggerState[LOGGER_SYMBOLS.FILTERS].delete(name);
    return logger;
  },

    // Управление форматтерами
    addFormatter: (name, formatter) => {
    if (typeof formatter === 'function') {
      loggerState[LOGGER_SYMBOLS.FORMATTERS].set(name, formatter);
    }
    return logger;
  },

    removeFormatter: (name) => {
    loggerState[LOGGER_SYMBOLS.FORMATTERS].delete(name);
    return logger;
  },

    // История
    getHistory: (filter = null) => {
    const history = loggerState[LOGGER_SYMBOLS.HISTORY];
    if (filter) {
      return history.filter(entry => entry.level === filter || entry.message.includes(filter));
    }
    return [...history];
  },

    clearHistory: () => {
    loggerState[LOGGER_SYMBOLS.HISTORY] = [];
    return logger;
  },

    // Настройки
    setDebug: (enabled) => {
    loggerState[LOGGER_SYMBOLS.DEBUG] = enabled;
    return logger;
  },

    setLevel: (level) => {
    loggerState[LOGGER_SYMBOLS.LEVEL] = level;
    return logger;
  },

    getLevel: () => loggerState[LOGGER_SYMBOLS.LEVEL],

    setOutput: (output) => {
    loggerState[LOGGER_SYMBOLS.OUTPUT] = output;
    return logger;
  },

    setSilent: (silent) => {
    loggerState[LOGGER_SYMBOLS.SILENT] = silent;
    return logger;
  },

    setPretty: (pretty) => {
    loggerState[LOGGER_SYMBOLS.PRETTY] = pretty;
    return logger;
  },

    setTimestamp: (enabled) => {
    loggerState[LOGGER_SYMBOLS.TIMESTAMP] = enabled;
    return logger;
  },

    setColors: (enabled) => {
    loggerState[LOGGER_SYMBOLS.COLORS] = enabled;
    return logger;
  },

    // Статистика
    getStats: () => {
    const history = loggerState[LOGGER_SYMBOLS.HISTORY];
    const stats = {
      total: history.length,
      byLevel: {},
      oldest: null,
      newest: null,
      contextSize: loggerState[LOGGER_SYMBOLS.CONTEXT].size,
      metadataSize: loggerState[LOGGER_SYMBOLS.METADATA].size,
      filtersCount: loggerState[LOGGER_SYMBOLS.FILTERS].size,
      formattersCount: loggerState[LOGGER_SYMBOLS.FORMATTERS].size,
    };

    for (const entry of history) {
      stats.byLevel[entry.level] = (stats.byLevel[entry.level] || 0) + 1;
    }

    if (history.length > 0) {
      stats.oldest = history[0].timestamp;
      stats.newest = history[history.length - 1].timestamp;
    }

    return stats;
  },

    // Экспорт/Импорт
    exportHistory: () => {
    return JSON.stringify(loggerState[LOGGER_SYMBOLS.HISTORY], null, 2);
  },

    importHistory: (json) => {
    try {
      const data = JSON.parse(json);
      if (Array.isArray(data)) {
        loggerState[LOGGER_SYMBOLS.HISTORY] = data;
        return true;
      }
      return false;
    } catch {
      return false;
    }
  },

    // Дочерние логгеры
    child: (name) => {
    const childId = `${loggerState[LOGGER_SYMBOLS.INSTANCE_ID]}:${name}`;
    return createControllerLogger(loggerState[LOGGER_SYMBOLS.DEBUG], childId);
  },

    // Таймеры
    time: (label) => {
    const start = performance.now();
    const key = `_time_${label}`;
    loggerState[LOGGER_SYMBOLS.METADATA].set(key, start);
    return {
      end: (message = '') => {
        const startTime = loggerState[LOGGER_SYMBOLS.METADATA].get(key);
        if (startTime) {
          const elapsed = (performance.now() - startTime).toFixed(2);
          logger.info(`⏱️ ${label}${message ? ' ' + message : ''}: ${elapsed}ms`);
          loggerState[LOGGER_SYMBOLS.METADATA].delete(key);
          return elapsed;
        }
        return null;
      },
      lap: (name) => {
        const startTime = loggerState[LOGGER_SYMBOLS.METADATA].get(key);
        if (startTime) {
          const elapsed = (performance.now() - startTime).toFixed(2);
          logger.debug(`⏱️ ${label} [${name}]: ${elapsed}ms`);
          return elapsed;
        }
        return null;
      },
    };
  },
};

return logger;
}

// ============================================================
// 4. ВАЛИДАТОР (100% СИМВОЛЫ)
// ============================================================

const VALIDATOR_SYMBOLS = {
  IS_PANEL: Symbol('validator.isPanel'),
  IS_BUTTON: Symbol('validator.isButton'),
  IS_ELEMENT: Symbol('validator.isElement'),
  IS_STATE: Symbol('validator.isState'),
  IS_CONFIG: Symbol('validator.isConfig'),
  IS_ACTION: Symbol('validator.isAction'),
  IS_CALLBACK: Symbol('validator.isCallback'),
  IS_STRING: Symbol('validator.isString'),
  IS_NUMBER: Symbol('validator.isNumber'),
  IS_BOOLEAN: Symbol('validator.isBoolean'),
  IS_OBJECT: Symbol('validator.isObject'),
  IS_FUNCTION: Symbol('validator.isFunction'),
  IS_ARRAY: Symbol('validator.isArray'),
  SANITIZE: Symbol('validator.sanitize'),
  CHECK_DOM: Symbol('validator.checkDom'),
  CHECK_ID: Symbol('validator.checkId'),
  CHECK_POSITION: Symbol('validator.checkPosition'),
  CHECK_SIZE: Symbol('validator.checkSize'),
};

const VALIDATOR = {
  [VALIDATOR_SYMBOLS.IS_PANEL]: (panel) => {
    return panel &&
      typeof panel === 'object' &&
      panel instanceof HTMLElement &&
      panel.tagName === 'DIV' &&
      panel.id &&
      document.body.contains(panel);
  },

  [VALIDATOR_SYMBOLS.IS_BUTTON]: (btn) => {
    return btn &&
      typeof btn === 'object' &&
      btn instanceof HTMLElement &&
      btn.tagName === 'BUTTON' &&
      typeof btn.click === 'function';
  },

  [VALIDATOR_SYMBOLS.IS_ELEMENT]: (el) => {
    return el && typeof el === 'object' && el instanceof HTMLElement;
  },

  [VALIDATOR_SYMBOLS.IS_STATE]: (state) => {
    if (!state || typeof state !== 'object') return false;
    const required = ['visible', 'minimized', 'fullscreen', 'zIndex'];
    for (const key of required) {
      if (!(key in state)) return false;
    }
    if (typeof state.visible !== 'boolean') return false;
    if (typeof state.minimized !== 'boolean') return false;
    if (typeof state.fullscreen !== 'boolean') return false;
    if (typeof state.zIndex !== 'number' || state.zIndex < 0) return false;
    return true;
  },

  [VALIDATOR_SYMBOLS.IS_CONFIG]: (config) => {
    if (!config || typeof config !== 'object') return false;
    return true;
  },

  [VALIDATOR_SYMBOLS.IS_ACTION]: (action) => {
    return typeof action === 'function';
  },

  [VALIDATOR_SYMBOLS.IS_CALLBACK]: (callback) => {
    return typeof callback === 'function';
  },

  [VALIDATOR_SYMBOLS.IS_STRING]: (value) => {
    return typeof value === 'string';
  },

  [VALIDATOR_SYMBOLS.IS_NUMBER]: (value) => {
    return typeof value === 'number' && !isNaN(value) && isFinite(value);
  },

  [VALIDATOR_SYMBOLS.IS_BOOLEAN]: (value) => {
    return typeof value === 'boolean';
  },

  [VALIDATOR_SYMBOLS.IS_OBJECT]: (value) => {
    return value && typeof value === 'object' && !Array.isArray(value);
  },

  [VALIDATOR_SYMBOLS.IS_FUNCTION]: (value) => {
    return typeof value === 'function';
  },

  [VALIDATOR_SYMBOLS.IS_ARRAY]: (value) => {
    return Array.isArray(value);
  },

  [VALIDATOR_SYMBOLS.SANITIZE]: (value) => {
    if (value === null || value === undefined) return null;
    if (typeof value === 'string') {
      return value.replace(/[<>]/g, '').trim();
    }
    if (typeof value === 'object') {
      try {
        return JSON.parse(JSON.stringify(value));
      } catch {
        return null;
      }
    }
    return value;
  },

  [VALIDATOR_SYMBOLS.CHECK_DOM]: (panel) => {
    if (!panel) return false;
    return document.body.contains(panel);
  },

  [VALIDATOR_SYMBOLS.CHECK_ID]: (id) => {
    return id && typeof id === 'string' && id.length > 0;
  },

  [VALIDATOR_SYMBOLS.CHECK_POSITION]: (pos) => {
    if (!pos || typeof pos !== 'object') return false;
    const { x, y } = pos;
    return typeof x === 'number' && x >= 0 &&
      typeof y === 'number' && y >= 0;
  },

  [VALIDATOR_SYMBOLS.CHECK_SIZE]: (size) => {
    if (!size || typeof size !== 'object') return false;
    const { width, height } = size;
    return typeof width === 'number' && width > 0 &&
      typeof height === 'number' && height > 0;
  },
};

// ============================================================
// 5. КОНФИГУРАЦИЯ (100% СИМВОЛЫ)
// ============================================================

const CONFIG_SYMBOLS = {
  ANIMATION_DURATION: Symbol('config.animationDuration'),
  MIN_WIDTH: Symbol('config.minWidth'),
  MIN_HEIGHT: Symbol('config.minHeight'),
  Z_INDEX_BASE: Symbol('config.zIndexBase'),
  Z_INDEX_MAX: Symbol('config.zIndexMax'),
  CACHE_TTL: Symbol('config.cacheTtl'),
  STATE_KEY: Symbol('config.stateKey'),
  DEBOUNCE_DELAY: Symbol('config.debounceDelay'),
  MAX_ACTION_QUEUE: Symbol('config.maxActionQueue'),
  DEFAULT_POSITION: Symbol('config.defaultPosition'),
  DEFAULT_SIZE: Symbol('config.defaultSize'),
  DEFAULT_STATE: Symbol('config.defaultState'),
  SAVE_INTERVAL: Symbol('config.saveInterval'),
};

const CONFIG = {
  [CONFIG_SYMBOLS.ANIMATION_DURATION]: 300,
  [CONFIG_SYMBOLS.MIN_WIDTH]: 320,
  [CONFIG_SYMBOLS.MIN_HEIGHT]: 300,
  [CONFIG_SYMBOLS.Z_INDEX_BASE]: 99996,
  [CONFIG_SYMBOLS.Z_INDEX_MAX]: 999999,
  [CONFIG_SYMBOLS.CACHE_TTL]: 3600000,
  [CONFIG_SYMBOLS.STATE_KEY]: 'panel-controller-state',
  [CONFIG_SYMBOLS.DEBOUNCE_DELAY]: 100,
  [CONFIG_SYMBOLS.MAX_ACTION_QUEUE]: 50,
  [CONFIG_SYMBOLS.DEFAULT_POSITION]: { x: 100, y: 100 },
  [CONFIG_SYMBOLS.DEFAULT_SIZE]: { width: 420, height: 520 },
  [CONFIG_SYMBOLS.DEFAULT_STATE]: {
    visible: true,
    minimized: false,
    fullscreen: false,
    focused: false,
    zIndex: 99996,
  },
  [CONFIG_SYMBOLS.SAVE_INTERVAL]: 5000,
};

// ============================================================
// 6. ОСНОВНОЙ КЛАСС КОНТРОЛЛЕРА (100% СИМВОЛЫ)
// ============================================================

export class PanelController {
  constructor(options = {}) {
    // ============================================================
    // 6.1 ИНИЦИАЛИЗАЦИЯ
    // ============================================================

    // Создаём логгер
    this[PRIVATE.LOGGER] = createControllerLogger(
      options.debug !== false,
      options.instanceId || 'PanelController'
    );
    const logger = this[PRIVATE.LOGGER];

    // Логируем создание
    logger.header('СОЗДАНИЕ КОНТРОЛЛЕРА (100% СИМВОЛЫ)');

    // ============================================================
    // 6.2 КОНФИГУРАЦИЯ
    // ============================================================

    this[PRIVATE.CONFIG] = {
      ...CONFIG,
      ...options.config,
    };

    // ============================================================
    // 6.3 СОСТОЯНИЕ
    // ============================================================

    this[PRIVATE.STATE] = {
      ...CONFIG[CONFIG_SYMBOLS.DEFAULT_STATE],
      ...options.state,
    };

    // ============================================================
    // 6.4 КЕШ
    // ============================================================

    this[PRIVATE.CACHE] = new Map();

    // ============================================================
    // 6.5 МЕТАДАННЫЕ
    // ============================================================

    this[PRIVATE.METADATA] = {
      created: Date.now(),
      lastAccess: Date.now(),
      lastUpdate: Date.now(),
      actionCount: 0,
      errorCount: 0,
      successCount: 0,
    };

    // ============================================================
    // 6.6 КОНТЕКСТ
    // ============================================================

    this[PRIVATE.CONTEXT] = {
      url: typeof window !== 'undefined' ? window.location.href : '',
      title: typeof window !== 'undefined' ? document.title : '',
      userAgent: typeof navigator !== 'undefined' ? navigator.userAgent : '',
      platform: typeof navigator !== 'undefined' ? navigator.platform : '',
    };

    // ============================================================
    // 6.7 DOM ЭЛЕМЕНТЫ
    // ============================================================

    this[PRIVATE.PANEL] = options.panel || null;
    this[PRIVATE.MIN_BTN] = options.minBtn || null;
    this[PRIVATE.MAX_BTN] = options.maxBtn || null;
    this[PRIVATE.CLOSE_BTN] = options.closeBtn || null;
    this[PRIVATE.HEADER] = options.header || null;
    this[PRIVATE.BODY] = options.body || null;
    this[PRIVATE.RESIZE] = options.resize || null;

    // ============================================================
    // 6.8 ДЕЙСТВИЯ
    // ============================================================

    this[PRIVATE.ACTIONS] = options.actions || {};
    this[PRIVATE.ACTION_QUEUE] = [];
    this[PRIVATE.IS_PROCESSING] = false;

    // ============================================================
    // 6.9 СЛУШАТЕЛИ И СОБЫТИЯ
    // ============================================================

    this[PRIVATE.LISTENERS] = [];
    this[PRIVATE.EVENT_HANDLERS] = new Map();
    this[PRIVATE.DOM_LISTENERS] = [];

    // ============================================================
    // 6.10 ТАЙМЕРЫ
    // ============================================================

    this[PRIVATE.TIMERS] = new Map();
    this[PRIVATE.RAF_ID] = null;
    this[PRIVATE.DEBOUNCE_TIMERS] = new Map();

    // ============================================================
    // 6.11 СОСТОЯНИЕ ЖИЗНЕННОГО ЦИКЛА
    // ============================================================

    this[PRIVATE.INITIALIZED] = false;
    this[PRIVATE.DESTROYED] = false;
    this[PRIVATE.IS_RUNNING] = false;

    // ============================================================
    // 6.12 ДЕБАГ
    // ============================================================

    this[PRIVATE.DEBUG] = options.debug !== false;
    this[PRIVATE.LOG_HISTORY] = [];

    // ============================================================
    // 6.13 ПРИВЯЗКА МЕТОДОВ
    // ============================================================

    this[PRIVATE.BIND_METHODS]();

    // ============================================================
    // 6.14 НАСТРОЙКА
    // ============================================================

    this[PRIVATE.SETUP_DOM]();
    this[PRIVATE.SETUP_HANDLERS]();
    this[PRIVATE.SETUP_TIMERS]();

    // ============================================================
    // 6.15 ЗАГРУЗКА СОСТОЯНИЯ
    // ============================================================

    this._loadState();

    // ============================================================
    // 6.16 ЭКСПОРТ СИМВОЛОВ
    // ============================================================

    this._exportSymbols();

    // ============================================================
    // 6.17 ФИНАЛЬНАЯ ИНИЦИАЛИЗАЦИЯ
    // ============================================================

    this[PRIVATE.INITIALIZED] = true;
    this[PRIVATE.IS_RUNNING] = true;

    // Логируем успешное создание
    logger.success(`✅ Контроллер инициализирован`);
    logger.info(`📌 Panel ID: ${this[PRIVATE.PANEL]?.id || 'не задан'}`);
    logger.info(`📌 Состояние:`, this[PRIVATE.STATE]);
    logger.header('ГОТОВ');

    // Событие инициализации
    this[PRIVATE.EMIT]('init', {
      controller: this,
      state: this[PRIVATE.STATE],
      timestamp: Date.now(),
    });
  }

  // ============================================================
  // 7. ★★★ ПРИВЯЗКА МЕТОДОВ ★★★
  // ============================================================

  [PRIVATE.BIND_METHODS]() {
    const methods = [
      'show', 'hide', 'toggle',
      'minimize', 'fullscreen', 'close', 'focus',
      'resize', 'move',
      'getState', 'updateState', 'resetState',
      'saveState', 'loadState',
      'on', 'off', 'emit',
      'destroy', 'reset',
    ];

    for (const method of methods) {
      if (typeof this[method] === 'function') {
        this[method] = this[method].bind(this);
      }
    }
  }

  // ============================================================
  // 8. ★★★ НАСТРОЙКА DOM ★★★
  // ============================================================

  [PRIVATE.SETUP_DOM]() {
    const logger = this[PRIVATE.LOGGER];
    const panel = this[PRIVATE.PANEL];

    if (!panel) {
      logger.warn('⚠️ Панель не передана, создаём новую');
      this[PRIVATE.PANEL] = this._createPanel();
    }

    // Находим элементы если не переданы
    if (!this[PRIVATE.HEADER]) {
      this[PRIVATE.HEADER] = this[PRIVATE.PANEL]?.querySelector('#panel-header') || null;
    }

    if (!this[PRIVATE.BODY]) {
      this[PRIVATE.BODY] = this[PRIVATE.PANEL]?.querySelector('#panel-body') || null;
    }

    if (!this[PRIVATE.RESIZE]) {
      this[PRIVATE.RESIZE] = this[PRIVATE.PANEL]?.querySelector('#panel-resize') || null;
    }

    if (!this[PRIVATE.MIN_BTN]) {
      this[PRIVATE.MIN_BTN] = this[PRIVATE.PANEL]?.querySelector('#panel-minimize-btn') || null;
    }

    if (!this[PRIVATE.MAX_BTN]) {
      this[PRIVATE.MAX_BTN] = this[PRIVATE.PANEL]?.querySelector('#panel-maximize-btn') || null;
    }

    if (!this[PRIVATE.CLOSE_BTN]) {
      this[PRIVATE.CLOSE_BTN] = this[PRIVATE.PANEL]?.querySelector('#panel-close-btn') || null;
    }

    // Применяем состояние к DOM
    this._applyStateToDom();

    logger.debug('✅ DOM настроен');
  }

  _createPanel() {
    const panel = document.createElement('div');
    panel.id = 'panel-controller-panel-' + Date.now();
    panel.className = 'panel-container';
    panel.style.cssText = `
      position: fixed;
      display: flex;
      flex-direction: column;
      background: rgba(26, 26, 46, 0.96);
      backdrop-filter: blur(20px);
      border: 1px solid rgba(255,255,255,0.08);
      border-radius: 12px;
      color: #fff;
      font-family: 'Segoe UI', system-ui, sans-serif;
      font-size: 13px;
      box-shadow: 0 20px 60px rgba(0,0,0,0.8);
      min-width: 320px;
      min-height: 300px;
      max-width: 90vw;
      max-height: 90vh;
      user-select: none;
      overflow: hidden;
    `;
    document.body.appendChild(panel);

    // Добавляем базовую структуру
    panel.innerHTML = `
      <div id="panel-header" style="
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 8px 14px;
        border-bottom: 1px solid rgba(255,255,255,0.06);
        cursor: grab;
        flex-shrink: 0;
        min-height: 44px;
        background: rgba(26, 26, 46, 0.98);
      ">
        <span style="
          font-weight: bold;
          font-size: 14px;
          display: flex;
          align-items: center;
          gap: 8px;
        ">
          <span>📦</span>
          <span>Панель</span>
          <span id="panel-status-badge" style="
            font-size: 9px;
            padding: 1px 8px;
            border-radius: 10px;
            background: rgba(255,255,255,0.05);
            color: #636e72;
            border: 1px solid rgba(255,255,255,0.05);
            margin-left: 8px;
          ">off</span>
        </span>
        <div class="panel-controls" style="display:flex;gap:2px;flex-shrink:0;">
          <button id="panel-minimize-btn" style="
            background:none;border:none;color:#8899bb;cursor:pointer;font-size:16px;
            padding:0 4px;width:28px;height:28px;display:flex;align-items:center;
            justify-content:center;border-radius:4px;transition:all 0.2s;
          " title="Свернуть">─</button>
          <button id="panel-maximize-btn" style="
            background:none;border:none;color:#8899bb;cursor:pointer;font-size:14px;
            padding:0 4px;width:28px;height:28px;display:flex;align-items:center;
            justify-content:center;border-radius:4px;transition:all 0.2s;
          " title="Развернуть">□</button>
          <button id="panel-close-btn" style="
            background:none;border:none;color:#8899bb;cursor:pointer;font-size:16px;
            padding:0 4px;width:28px;height:28px;display:flex;align-items:center;
            justify-content:center;border-radius:4px;transition:all 0.2s;
          " title="Закрыть">✕</button>
        </div>
      </div>
      <div id="panel-body" style="
        flex: 1;
        overflow-y: auto;
        padding: 10px 14px 14px 14px;
        scrollbar-width: thin;
        scrollbar-color: rgba(102,126,234,0.3) transparent;
      ">
        <div style="
          color: #8899bb;
          font-size: 12px;
          padding: 8px 12px;
          background: rgba(255,255,255,0.03);
          border-radius: 6px;
          border: 1px solid rgba(255,255,255,0.05);
        ">⚡ Панель создана контроллером</div>
      </div>
      <div id="panel-resize" style="
        position: absolute;
        bottom: 0;
        right: 0;
        width: 16px;
        height: 16px;
        cursor: nwse-resize;
        z-index: 10;
        background: linear-gradient(135deg, transparent 50%, rgba(102,126,234,0.2) 50%);
        border-radius: 0 0 12px 0;
      "></div>
    `;

    // Обновляем ссылки
    this[PRIVATE.HEADER] = panel.querySelector('#panel-header');
    this[PRIVATE.BODY] = panel.querySelector('#panel-body');
    this[PRIVATE.RESIZE] = panel.querySelector('#panel-resize');
    this[PRIVATE.MIN_BTN] = panel.querySelector('#panel-minimize-btn');
    this[PRIVATE.MAX_BTN] = panel.querySelector('#panel-maximize-btn');
    this[PRIVATE.CLOSE_BTN] = panel.querySelector('#panel-close-btn');

    return panel;
  }

  // ============================================================
  // 9. ★★★ НАСТРОЙКА ОБРАБОТЧИКОВ ★★★
  // ============================================================

  [PRIVATE.SETUP_HANDLERS]() {
    const logger = this[PRIVATE.LOGGER];
    const panel = this[PRIVATE.PANEL];

    if (!panel) {
      logger.warn('⚠️ Нет панели для настройки обработчиков');
      return;
    }

    // Функция для безопасного добавления слушателя
    const addListener = (element, event, handler) => {
      if (!element) return;
      element.addEventListener(event, handler);
      this[PRIVATE.DOM_LISTENERS].push({ element, event, handler });
    };

    // Клик по панели — фокус
    addListener(panel, 'mousedown', (e) => {
      if (e.target.closest('.panel-controls')) return;
      if (e.target.closest('button')) return;
      if (e.target.closest('input')) return;
      if (e.target.closest('select')) return;
      if (e.target.closest('textarea')) return;
      this[PRIVATE.DO_FOCUS]();
    });

    // Минимизация
    addListener(this[PRIVATE.MIN_BTN], 'click', (e) => {
      e.stopPropagation();
      e.preventDefault();
      this[PRIVATE.DO_MINIMIZE]();
    });

    // Полноэкранный режим
    addListener(this[PRIVATE.MAX_BTN], 'click', (e) => {
      e.stopPropagation();
      e.preventDefault();
      this[PRIVATE.DO_FULLSCREEN]();
    });

    // Закрытие
    addListener(this[PRIVATE.CLOSE_BTN], 'click', (e) => {
      e.stopPropagation();
      e.preventDefault();
      this[PRIVATE.DO_CLOSE]();
    });

    // Двойной клик по шапке
    addListener(this[PRIVATE.HEADER], 'dblclick', (e) => {
      if (e.target.closest('.panel-controls')) return;
      this[PRIVATE.DO_FULLSCREEN]();
    });

    // Перетаскивание
    this._setupDrag();

    // Ресайз
    this._setupResize();

    logger.debug('✅ Обработчики настроены');
  }

  // ============================================================
  // 10. ★★★ ПЕРЕТАСКИВАНИЕ ★★★
  // ============================================================

  _setupDrag() {
    const panel = this[PRIVATE.PANEL];
    const header = this[PRIVATE.HEADER];
    if (!panel || !header) return;

    let isDragging = false;
    let offsetX = 0, offsetY = 0;
    let startX = 0, startY = 0;
    let rafId = null;

    const onMouseDown = (e) => {
      if (e.target.closest('.panel-controls')) return;
      if (this[PRIVATE.STATE].fullscreen) return;
      if (e.button !== 0) return;

      e.preventDefault();
      isDragging = true;

      const rect = panel.getBoundingClientRect();
      offsetX = e.clientX - rect.left;
      offsetY = e.clientY - rect.top;
      startX = rect.left;
      startY = rect.top;

      panel.style.transition = 'none';
      panel.style.cursor = 'grabbing';
      document.body.style.cursor = 'grabbing';
      document.body.style.userSelect = 'none';

      document.addEventListener('mousemove', onMouseMove, { passive: true });
      document.addEventListener('mouseup', onMouseUp, { passive: true });

      this[PRIVATE.EMIT]('dragStart', { x: startX, y: startY });
    };

    const onMouseMove = (e) => {
      if (!isDragging) return;
      if (rafId) cancelAnimationFrame(rafId);

      rafId = requestAnimationFrame(() => {
        let x = e.clientX - offsetX;
        let y = e.clientY - offsetY;

        const maxX = window.innerWidth - panel.offsetWidth;
        const maxY = window.innerHeight - panel.offsetHeight;
        x = Math.max(0, Math.min(maxX, x));
        y = Math.max(0, Math.min(maxY, y));

        panel.style.transform = `translate(${x - startX}px, ${y - startY}px)`;
        panel.dataset.x = x;
        panel.dataset.y = y;

        this[PRIVATE.STATE].position = { x, y };
        this[PRIVATE.EMIT]('drag', { x, y });

        rafId = null;
      });
    };

    const onMouseUp = () => {
      if (!isDragging) return;
      isDragging = false;

      document.removeEventListener('mousemove', onMouseMove);
      document.removeEventListener('mouseup', onMouseUp);

      const x = parseInt(panel.dataset.x) || parseInt(panel.style.left) || 100;
      const y = parseInt(panel.dataset.y) || parseInt(panel.style.top) || 100;

      panel.style.transform = 'none';
      panel.style.left = x + 'px';
      panel.style.top = y + 'px';
      panel.style.cursor = '';
      document.body.style.cursor = '';
      document.body.style.userSelect = '';

      this[PRIVATE.STATE].position = { x, y };

      if (rafId) {
        cancelAnimationFrame(rafId);
        rafId = null;
      }

      this[PRIVATE.EMIT]('dragEnd', { x, y });
      this._saveState();
    };

    header.addEventListener('mousedown', onMouseDown);
    this[PRIVATE.DOM_LISTENERS].push({ element: header, event: 'mousedown', handler: onMouseDown });
  }

  // ============================================================
  // 11. ★★★ РЕСАЙЗ ★★★
  // ============================================================

  _setupResize() {
    const panel = this[PRIVATE.PANEL];
    const resize = this[PRIVATE.RESIZE];
    if (!panel || !resize) return;

    let isResizing = false;
    let startX = 0, startY = 0;
    let startW = 0, startH = 0;
    let rafId = null;

    const onMouseDown = (e) => {
      if (this[PRIVATE.STATE].fullscreen) return;
      e.stopPropagation();
      e.preventDefault();

      isResizing = true;

      startX = e.clientX;
      startY = e.clientY;
      startW = panel.offsetWidth;
      startH = panel.offsetHeight;

      panel.style.transition = 'none';
      document.body.style.cursor = 'nwse-resize';
      document.body.style.userSelect = 'none';

      document.addEventListener('mousemove', onMouseMove, { passive: true });
      document.addEventListener('mouseup', onMouseUp, { passive: true });

      this[PRIVATE.EMIT]('resizeStart', { width: startW, height: startH });
    };

    const onMouseMove = (e) => {
      if (!isResizing) return;
      if (rafId) cancelAnimationFrame(rafId);

      rafId = requestAnimationFrame(() => {
        const config = this[PRIVATE.CONFIG];
        const minW = config[CONFIG_SYMBOLS.MIN_WIDTH] || 320;
        const minH = config[CONFIG_SYMBOLS.MIN_HEIGHT] || 300;
        const maxW = window.innerWidth * 0.9;
        const maxH = window.innerHeight * 0.9;

        const w = Math.max(minW, Math.min(maxW, startW + (e.clientX - startX)));
        const h = Math.max(minH, Math.min(maxH, startH + (e.clientY - startY)));

        panel.style.width = w + 'px';
        panel.style.height = h + 'px';

        this[PRIVATE.STATE].size = { width: w, height: h };
        this[PRIVATE.EMIT]('resize', { width: w, height: h });

        rafId = null;
      });
    };

    const onMouseUp = () => {
      if (!isResizing) return;
      isResizing = false;

      document.removeEventListener('mousemove', onMouseMove);
      document.removeEventListener('mouseup', onMouseUp);

      panel.style.transition = '';
      document.body.style.cursor = '';
      document.body.style.userSelect = '';

      if (rafId) {
        cancelAnimationFrame(rafId);
        rafId = null;
      }

      this[PRIVATE.EMIT]('resizeEnd', this[PRIVATE.STATE].size);
      this._saveState();
    };

    resize.addEventListener('mousedown', onMouseDown);
    this[PRIVATE.DOM_LISTENERS].push({ element: resize, event: 'mousedown', handler: onMouseDown });
  }

  // ============================================================
  // 12. ★★★ НАСТРОЙКА ТАЙМЕРОВ ★★★
  // ============================================================

  [PRIVATE.SETUP_TIMERS]() {
    const logger = this[PRIVATE.LOGGER];
    const config = this[PRIVATE.CONFIG];
    const saveInterval = config[CONFIG_SYMBOLS.SAVE_INTERVAL] || 5000;

    // Автосохранение
    const saveTimer = setInterval(() => {
      if (!this[PRIVATE.DESTROYED]) {
        this._saveState();
      }
    }, saveInterval);

    this[PRIVATE.TIMERS].set('save', saveTimer);

    // Проверка состояния
    const stateTimer = setInterval(() => {
      if (!this[PRIVATE.DESTROYED]) {
        this._checkState();
      }
    }, 30000);

    this[PRIVATE.TIMERS].set('state', stateTimer);

    logger.debug('✅ Таймеры настроены');
  }

  // ============================================================
  // 13. ★★★ ПРИМЕНЕНИЕ СОСТОЯНИЯ К DOM ★★★
  // ============================================================

  _applyStateToDom() {
    const panel = this[PRIVATE.PANEL];
    const state = this[PRIVATE.STATE];
    const config = this[PRIVATE.CONFIG];

    if (!panel) return;

    // Позиция
    const pos = state.position || config[CONFIG_SYMBOLS.DEFAULT_POSITION];
    panel.style.left = pos.x + 'px';
    panel.style.top = pos.y + 'px';

    // Размер
    const size = state.size || config[CONFIG_SYMBOLS.DEFAULT_SIZE];
    panel.style.width = size.width + 'px';
    panel.style.height = size.height + 'px';

    // Видимость
    if (state.visible) {
      panel.style.display = 'flex';
    } else {
      panel.style.display = 'none';
    }

    // Минимизация
    if (state.minimized) {
      panel.classList.add('minimized');
      panel.style.height = '44px';
      panel.style.minHeight = '44px';
      panel.style.maxHeight = '44px';
      if (this[PRIVATE.MIN_BTN]) this[PRIVATE.MIN_BTN].textContent = '□';
    } else {
      panel.classList.remove('minimized');
      panel.style.height = '';
      panel.style.minHeight = '';
      panel.style.maxHeight = '';
      if (this[PRIVATE.MIN_BTN]) this[PRIVATE.MIN_BTN].textContent = '─';
    }

    // Полноэкранный режим
    if (state.fullscreen) {
      panel.classList.add('fullscreen');
      panel.style.width = '100vw';
      panel.style.height = '100vh';
      panel.style.top = '0';
      panel.style.left = '0';
      panel.style.borderRadius = '0';
      panel.style.border = 'none';
      panel.style.maxWidth = '100vw';
      panel.style.maxHeight = '100vh';
      panel.style.minWidth = '100vw';
      panel.style.minHeight = '100vh';
      if (this[PRIVATE.MAX_BTN]) this[PRIVATE.MAX_BTN].textContent = '⧉';
    } else {
      panel.classList.remove('fullscreen');
      panel.style.borderRadius = '12px';
      panel.style.border = '1px solid rgba(255,255,255,0.08)';
      panel.style.maxWidth = '';
      panel.style.maxHeight = '';
      panel.style.minWidth = '320px';
      panel.style.minHeight = '300px';
      if (this[PRIVATE.MAX_BTN]) this[PRIVATE.MAX_BTN].textContent = '□';
    }

    // z-index
    panel.style.zIndex = state.zIndex || config[CONFIG_SYMBOLS.Z_INDEX_BASE];

    // Обновляем бейдж
    this._updateBadge();
  }

  _updateBadge() {
    const badge = this[PRIVATE.PANEL]?.querySelector('#panel-status-badge');
    if (!badge) return;

    const state = this[PRIVATE.STATE];
    const status = state.visible ? 'on' : 'off';
    const isOn = state.visible;

    badge.textContent = status;
    badge.style.background = isOn ? 'rgba(0,184,148,0.15)' : 'rgba(255,255,255,0.05)';
    badge.style.color = isOn ? '#00b894' : '#636e72';
    badge.style.borderColor = isOn ? 'rgba(0,184,148,0.2)' : 'rgba(255,255,255,0.05)';
  }

  // ============================================================
  // 14. ★★★ ОСНОВНЫЕ ДЕЙСТВИЯ ★★★
  // ============================================================

  async [PRIVATE.DO_SHOW](options = {}) {
    const logger = this[PRIVATE.LOGGER];
    const panel = this[PRIVATE.PANEL];

    if (!panel) {
      logger.error('❌ Панель не существует');
      return false;
    }

    if (this[PRIVATE.STATE].visible) {
      logger.debug('ℹ️ Панель уже видна');
      return true;
    }

    logger.debug('👁️ Показ панели...');

    // Событие beforeShow
    this[PRIVATE.EMIT]('beforeShow', { panel, options });

    // Анимация
    if (options.animate !== false) {
      panel.style.transition = `transform ${options.duration || 300}ms ease, opacity ${options.duration || 300}ms ease`;
      panel.style.transform = 'scale(0.95)';
      panel.style.opacity = '0';
      panel.style.display = 'flex';

      await new Promise(resolve => {
        requestAnimationFrame(() => {
          requestAnimationFrame(() => {
            panel.style.transform = 'scale(1)';
            panel.style.opacity = '1';
            setTimeout(resolve, (options.duration || 300) + 50);
          });
        });
      });

      panel.style.transition = '';
    } else {
      panel.style.display = 'flex';
      panel.style.opacity = '1';
      panel.style.transform = 'scale(1)';
    }

    // Обновляем состояние
    this[PRIVATE.STATE].visible = true;
    this[PRIVATE.METADATA].lastUpdate = Date.now();
    this[PRIVATE.METADATA].successCount++;
    this[PRIVATE.METADATA].actionCount++;

    this._updateBadge();

    // Событие afterShow
    this[PRIVATE.EMIT]('afterShow', { panel, state: this[PRIVATE.STATE] });

    logger.success(`✅ Панель показана`);
    this._saveState();

    return true;
  }

  async [PRIVATE.DO_HIDE](options = {}) {
    const logger = this[PRIVATE.LOGGER];
    const panel = this[PRIVATE.PANEL];

    if (!panel) {
      logger.error('❌ Панель не существует');
      return false;
    }

    if (!this[PRIVATE.STATE].visible) {
      logger.debug('ℹ️ Панель уже скрыта');
      return true;
    }

    logger.debug('🙈 Скрытие панели...');

    // Событие beforeHide
    this[PRIVATE.EMIT]('beforeHide', { panel, options });

    // Анимация
    if (options.animate !== false) {
      panel.style.transition = `transform ${options.duration || 300}ms ease, opacity ${options.duration || 300}ms ease`;
      panel.style.transform = 'scale(0.95)';
      panel.style.opacity = '0';

      await new Promise(resolve => {
        setTimeout(() => {
          panel.style.display = 'none';
          panel.style.transform = '';
          panel.style.opacity = '';
          panel.style.transition = '';
          resolve();
        }, (options.duration || 300) + 50);
      });
    } else {
      panel.style.display = 'none';
    }

    // Обновляем состояние
    this[PRIVATE.STATE].visible = false;
    this[PRIVATE.METADATA].lastUpdate = Date.now();
    this[PRIVATE.METADATA].successCount++;
    this[PRIVATE.METADATA].actionCount++;

    this._updateBadge();

    // Событие afterHide
    this[PRIVATE.EMIT]('afterHide', { panel, state: this[PRIVATE.STATE] });

    logger.success(`✅ Панель скрыта`);
    this._saveState();

    return true;
  }

  async [PRIVATE.DO_TOGGLE](options = {}) {
    const logger = this[PRIVATE.LOGGER];
    const isVisible = this[PRIVATE.STATE].visible;

    logger.debug(`🔄 Переключение панели (${isVisible ? 'скрыть' : 'показать'})...`);

    // Событие beforeToggle
    this[PRIVATE.EMIT]('beforeToggle', {
      panel: this[PRIVATE.PANEL],
      visible: !isVisible,
      options,
    });

    let result;
    if (isVisible) {
      result = await this[PRIVATE.DO_HIDE](options);
    } else {
      result = await this[PRIVATE.DO_SHOW](options);
    }

    // Событие afterToggle
    this[PRIVATE.EMIT]('afterToggle', {
      panel: this[PRIVATE.PANEL],
      visible: !isVisible,
      result,
    });

    logger.success(`✅ Панель переключена: ${!isVisible ? 'показана' : 'скрыта'}`);
    return result;
  }

  async [PRIVATE.DO_MINIMIZE](options = {}) {
    const logger = this[PRIVATE.LOGGER];
    const panel = this[PRIVATE.PANEL];

    if (!panel) {
      logger.error('❌ Панель не существует');
      return false;
    }

    // Если в полноэкранном режиме — выходим из него
    if (this[PRIVATE.STATE].fullscreen) {
      await this[PRIVATE.DO_FULLSCREEN]({ ...options, animate: false });
      await new Promise(resolve => setTimeout(resolve, 50));
    }

    const isMinimized = this[PRIVATE.STATE].minimized;
    logger.debug(`📐 ${isMinimized ? 'Разворачивание' : 'Сворачивание'} панели...`);

    // Событие beforeMinimize
    this[PRIVATE.EMIT]('beforeMinimize', {
      panel,
      minimized: !isMinimized,
      options,
    });

    // Сохраняем высоту
    if (!isMinimized) {
      panel.dataset.prevHeight = panel.offsetHeight;
    }

    // Анимация
    const dur = options.duration || 300;
    if (options.animate !== false) {
      panel.style.transition = `height ${dur}ms ease, min-height ${dur}ms ease`;

      if (!isMinimized) {
        panel.style.height = '44px';
        panel.style.minHeight = '44px';
        panel.style.maxHeight = '44px';
      } else {
        const prevHeight = parseInt(panel.dataset.prevHeight) || 520;
        panel.style.height = prevHeight + 'px';
        panel.style.minHeight = '300px';
        panel.style.maxHeight = '';
      }

      await new Promise(resolve => {
        setTimeout(() => {
          panel.style.transition = '';
          resolve();
        }, dur + 50);
      });
    } else {
      if (!isMinimized) {
        panel.style.height = '44px';
        panel.style.minHeight = '44px';
        panel.style.maxHeight = '44px';
      } else {
        const prevHeight = parseInt(panel.dataset.prevHeight) || 520;
        panel.style.height = prevHeight + 'px';
        panel.style.minHeight = '300px';
        panel.style.maxHeight = '';
      }
    }

    // Переключаем класс
    panel.classList.toggle('minimized', !isMinimized);

    // Скрываем/показываем элементы
    const body = this[PRIVATE.BODY];
    const resize = this[PRIVATE.RESIZE];
    const minBtn = this[PRIVATE.MIN_BTN];

    if (!isMinimized) {
      if (body) body.style.display = 'none';
      if (resize) resize.style.display = 'none';
      if (minBtn) minBtn.textContent = '□';
    } else {
      if (body) body.style.display = '';
      if (resize) resize.style.display = '';
      if (minBtn) minBtn.textContent = '─';
    }

    // Обновляем состояние
    this[PRIVATE.STATE].minimized = !isMinimized;
    this[PRIVATE.METADATA].lastUpdate = Date.now();
    this[PRIVATE.METADATA].successCount++;
    this[PRIVATE.METADATA].actionCount++;

    // Событие afterMinimize
    this[PRIVATE.EMIT]('afterMinimize', {
      panel,
      minimized: this[PRIVATE.STATE].minimized,
    });

    logger.success(`✅ Панель ${this[PRIVATE.STATE].minimized ? 'свёрнута' : 'развёрнута'}`);
    this._saveState();

    return this[PRIVATE.STATE].minimized;
  }

  async [PRIVATE.DO_FULLSCREEN](options = {}) {
    const logger = this[PRIVATE.LOGGER];
    const panel = this[PRIVATE.PANEL];

    if (!panel) {
      logger.error('❌ Панель не существует');
      return false;
    }

    const isFullscreen = this[PRIVATE.STATE].fullscreen;
    logger.debug(`🖥️ ${isFullscreen ? 'Выход из' : 'Вход в'} полноэкранный режим...`);

    // Событие beforeFullscreen
    this[PRIVATE.EMIT]('beforeFullscreen', {
      panel,
      fullscreen: !isFullscreen,
      options,
    });

    const dur = options.duration || 300;

    if (!isFullscreen) {
      // Вход в полноэкранный режим
      panel.dataset.prevWidth = panel.offsetWidth;
      panel.dataset.prevHeight = panel.offsetHeight;
      panel.dataset.prevLeft = panel.style.left || panel.offsetLeft + 'px';
      panel.dataset.prevTop = panel.style.top || panel.offsetTop + 'px';

      if (options.animate !== false) {
        panel.style.transition = `
          width ${dur}ms ease,
          height ${dur}ms ease,
          top ${dur}ms ease,
          left ${dur}ms ease,
          border-radius ${dur}ms ease
        `;
      }

      panel.style.width = '100vw';
      panel.style.height = '100vh';
      panel.style.top = '0';
      panel.style.left = '0';
      panel.style.borderRadius = '0';
      panel.style.border = 'none';
      panel.style.maxWidth = '100vw';
      panel.style.maxHeight = '100vh';
      panel.style.minWidth = '100vw';
      panel.style.minHeight = '100vh';
      panel.style.zIndex = CONFIG[CONFIG_SYMBOLS.Z_INDEX_MAX];
      document.body.style.overflow = 'hidden';

      // Если была свёрнута — разворачиваем
      if (this[PRIVATE.STATE].minimized) {
        const body = this[PRIVATE.BODY];
        const resize = this[PRIVATE.RESIZE];
        const minBtn = this[PRIVATE.MIN_BTN];
        panel.classList.remove('minimized');
        if (body) body.style.display = '';
        if (resize) resize.style.display = '';
        if (minBtn) minBtn.textContent = '─';
        this[PRIVATE.STATE].minimized = false;
      }

      const resize = this[PRIVATE.RESIZE];
      if (resize) resize.style.display = 'none';
      if (this[PRIVATE.MAX_BTN]) this[PRIVATE.MAX_BTN].textContent = '⧉';

      panel.classList.add('fullscreen');
      this[PRIVATE.STATE].fullscreen = true;

    } else {
      // Выход из полноэкранного режима
      const prevWidth = parseInt(panel.dataset.prevWidth) || 420;
      const prevHeight = parseInt(panel.dataset.prevHeight) || 520;
      const prevLeft = panel.dataset.prevLeft || '100px';
      const prevTop = panel.dataset.prevTop || '100px';

      if (options.animate !== false) {
        panel.style.transition = `
          width ${dur}ms ease,
          height ${dur}ms ease,
          top ${dur}ms ease,
          left ${dur}ms ease,
          border-radius ${dur}ms ease
        `;
      }

      panel.style.width = prevWidth + 'px';
      panel.style.height = prevHeight + 'px';
      panel.style.top = prevTop;
      panel.style.left = prevLeft;
      panel.style.borderRadius = '12px';
      panel.style.border = '1px solid rgba(255,255,255,0.08)';
      panel.style.maxWidth = '';
      panel.style.maxHeight = '';
      panel.style.minWidth = '320px';
      panel.style.minHeight = '300px';
      panel.style.zIndex = '';
      document.body.style.overflow = '';

      const resize = this[PRIVATE.RESIZE];
      if (resize) resize.style.display = '';
      if (this[PRIVATE.MAX_BTN]) this[PRIVATE.MAX_BTN].textContent = '□';

      panel.classList.remove('fullscreen');
      this[PRIVATE.STATE].fullscreen = false;
    }

    if (options.animate !== false) {
      await new Promise(resolve => {
        setTimeout(() => {
          panel.style.transition = '';
          resolve();
        }, dur + 50);
      });
    }

    this[PRIVATE.METADATA].lastUpdate = Date.now();
    this[PRIVATE.METADATA].successCount++;
    this[PRIVATE.METADATA].actionCount++;

    // Событие afterFullscreen
    this[PRIVATE.EMIT]('afterFullscreen', {
      panel,
      fullscreen: this[PRIVATE.STATE].fullscreen,
    });

    logger.success(`✅ Панель ${this[PRIVATE.STATE].fullscreen ? 'в полноэкранном режиме' : 'восстановлена'}`);
    this._saveState();

    return this[PRIVATE.STATE].fullscreen;
  }

  async [PRIVATE.DO_CLOSE](options = {}) {
    const logger = this[PRIVATE.LOGGER];
    const panel = this[PRIVATE.PANEL];

    if (!panel) {
      logger.error('❌ Панель не существует');
      return false;
    }

    logger.debug('🚪 Закрытие панели...');

    // Событие beforeClose
    this[PRIVATE.EMIT]('beforeClose', { panel, options });

    // Если в полноэкранном режиме — выходим из него
    if (this[PRIVATE.STATE].fullscreen) {
      await this[PRIVATE.DO_FULLSCREEN]({ ...options, animate: false });
    }

    // Анимация
    if (options.animate !== false) {
      const dur = options.duration || 300;
      panel.style.transition = `transform ${dur}ms ease, opacity ${dur}ms ease`;
      panel.style.transform = 'scale(0.95)';
      panel.style.opacity = '0';

      await new Promise(resolve => {
        setTimeout(() => {
          panel.style.display = 'none';
          panel.style.transform = '';
          panel.style.opacity = '';
          panel.style.transition = '';
          resolve();
        }, dur + 50);
      });
    } else {
      panel.style.display = 'none';
    }

    // Обновляем состояние
    this[PRIVATE.STATE].visible = false;
    this[PRIVATE.METADATA].lastUpdate = Date.now();
    this[PRIVATE.METADATA].successCount++;
    this[PRIVATE.METADATA].actionCount++;

    this._updateBadge();

    // Событие afterClose
    this[PRIVATE.EMIT]('afterClose', { panel, state: this[PRIVATE.STATE] });

    logger.success(`✅ Панель закрыта`);
    this._saveState();

    return true;
  }

  async [PRIVATE.DO_FOCUS](options = {}) {
    const logger = this[PRIVATE.LOGGER};
  const panel = this[PRIVATE.PANEL];

  if (!panel) {
  logger.error('❌ Панель не существует');
  return false;
}

logger.debug('🎯 Фокус на панели...');

// Событие onFocus
this[PRIVATE.EMIT]('onFocus', { panel, options });

// Находим все панели
const allWindows = document.querySelectorAll(
  '.panel-container, #widget-app, #env-control-panel, #logs-control-panel, #debug-control-panel'
);

// Находим максимальный z-index
let maxZ = CONFIG[CONFIG_SYMBOLS.Z_INDEX_BASE];
allWindows.forEach(win => {
  if (win !== panel && win.style.display !== 'none') {
    const z = parseInt(win.style.zIndex) || 0;
    if (z > maxZ) maxZ = z;
  }
});

// Устанавливаем новый z-index
const newZ = maxZ + 1;
const dur = options.duration || 150;

if (options.animate !== false) {
  panel.style.transition = `z-index ${dur}ms ease`;
  panel.style.zIndex = newZ;

  await new Promise(resolve => {
    setTimeout(() => {
      panel.style.transition = '';
      resolve();
    }, dur + 50);
  });
} else {
  panel.style.zIndex = newZ;
}

// Обновляем состояние
this[PRIVATE.STATE].zIndex = newZ;
this[PRIVATE.STATE].focused = true;
this[PRIVATE.METADATA].lastUpdate = Date.now();
this[PRIVATE.METADATA].successCount++;
this[PRIVATE.METADATA].actionCount++;

// Убираем активные классы у других панелей
allWindows.forEach(win => {
  win.classList.remove('active-window');
});
panel.classList.add('active-window');

logger.success(`✅ Панель на переднем плане (z-index: ${newZ})`);
this._saveState();

return newZ;
}

async [PRIVATE.DO_RESIZE](width, height, options = {}) {
  const logger = this[PRIVATE.LOGGER];
  const panel = this[PRIVATE.PANEL];

  if (!panel) {
    logger.error('❌ Панель не существует');
    return false;
  }

  const config = this[PRIVATE.CONFIG];
  const minW = config[CONFIG_SYMBOLS.MIN_WIDTH] || 320;
  const minH = config[CONFIG_SYMBOLS.MIN_HEIGHT] || 300;
  const maxW = window.innerWidth * 0.9;
  const maxH = window.innerHeight * 0.9;

  const w = Math.max(minW, Math.min(maxW, width));
  const h = Math.max(minH, Math.min(maxH, height));

  logger.debug(`📐 Ресайз панели: ${w}x${h}`);

  // Событие beforeResize
  this[PRIVATE.EMIT]('beforeResize', { panel, width: w, height: h, options });

  if (options.animate !== false) {
    const dur = options.duration || 300;
    panel.style.transition = `width ${dur}ms ease, height ${dur}ms ease`;

    panel.style.width = w + 'px';
    panel.style.height = h + 'px';

    await new Promise(resolve => {
      setTimeout(() => {
        panel.style.transition = '';
        resolve();
      }, dur + 50);
    });
  } else {
    panel.style.width = w + 'px';
    panel.style.height = h + 'px';
  }

  // Обновляем состояние
  this[PRIVATE.STATE].size = { width: w, height: h };
  this[PRIVATE.METADATA].lastUpdate = Date.now();
  this[PRIVATE.METADATA].successCount++;
  this[PRIVATE.METADATA].actionCount++;

  // Событие afterResize
  this[PRIVATE.EMIT]('afterResize', { panel, width: w, height: h });

  logger.success(`✅ Панель изменена: ${w}x${h}`);
  this._saveState();

  return { width: w, height: h };
}

async [PRIVATE.DO_MOVE](x, y, options = {}) {
  const logger = this[PRIVATE.LOGGER];
  const panel = this[PRIVATE.PANEL];

  if (!panel) {
    logger.error('❌ Панель не существует');
    return false;
  }

  const maxX = window.innerWidth - panel.offsetWidth;
  const maxY = window.innerHeight - panel.offsetHeight;

  const posX = Math.max(0, Math.min(maxX, x));
  const posY = Math.max(0, Math.min(maxY, y));

  logger.debug(`📍 Перемещение панели: ${posX}, ${posY}`);

  // Событие beforeMove
  this[PRIVATE.EMIT]('beforeMove', { panel, x: posX, y: posY, options });

  if (options.animate !== false) {
    const dur = options.duration || 300;
    panel.style.transition = `left ${dur}ms ease, top ${dur}ms ease`;

    panel.style.left = posX + 'px';
    panel.style.top = posY + 'px';

    await new Promise(resolve => {
      setTimeout(() => {
        panel.style.transition = '';
        resolve();
      }, dur + 50);
    });
  } else {
    panel.style.left = posX + 'px';
    panel.style.top = posY + 'px';
  }

  // Обновляем состояние
  this[PRIVATE.STATE].position = { x: posX, y: posY };
  this[PRIVATE.METADATA].lastUpdate = Date.now();
  this[PRIVATE.METADATA].successCount++;
  this[PRIVATE.METADATA].actionCount++;

  // Событие afterMove
  this[PRIVATE.EMIT]('afterMove', { panel, x: posX, y: posY });

  logger.success(`✅ Панель перемещена: ${posX}, ${posY}`);
  this._saveState();

  return { x: posX, y: posY };
}

// ============================================================
// 15. ★★★ УПРАВЛЕНИЕ СОСТОЯНИЕМ ★★★
// ============================================================

getState() {
  return { ...this[PRIVATE.STATE] };
}

updateState(newState) {
  const oldState = { ...this[PRIVATE.STATE] };
  Object.assign(this[PRIVATE.STATE], newState);
  this._applyStateToDom();
  this[PRIVATE.METADATA].lastUpdate = Date.now();

  this[PRIVATE.EMIT]('stateChange', {
    oldState,
    newState: this[PRIVATE.STATE],
    changes: newState,
  });

  this._saveState();
  return this[PRIVATE.STATE];
}

resetState() {
  const config = this[PRIVATE.CONFIG};
const defaultState = config[CONFIG_SYMBOLS.DEFAULT_STATE];
const oldState = { ...this[PRIVATE.STATE] };

this[PRIVATE.STATE] = {
  ...defaultState,
  position: config[CONFIG_SYMBOLS.DEFAULT_POSITION],
  size: config[CONFIG_SYMBOLS.DEFAULT_SIZE],
};

this._applyStateToDom();
this[PRIVATE.METADATA].lastUpdate = Date.now();

this[PRIVATE.EMIT]('stateReset', {
  oldState,
  newState: this[PRIVATE.STATE],
});

this._saveState();
return this[PRIVATE.STATE];
}

// ============================================================
// 16. ★★★ СОХРАНЕНИЕ И ЗАГРУЗКА СОСТОЯНИЯ ★★★
// ============================================================

_saveState() {
  try {
    const data = {
      state: this[PRIVATE.STATE],
      metadata: {
        actionCount: this[PRIVATE.METADATA].actionCount,
        successCount: this[PRIVATE.METADATA].successCount,
        errorCount: this[PRIVATE.METADATA].errorCount,
      },
      timestamp: Date.now(),
      version: '2.2.0',
    };
    const key = this[PRIVATE.CONFIG][CONFIG_SYMBOLS.STATE_KEY] || 'panel-controller-state';
    localStorage.setItem(key, JSON.stringify(data));
  } catch (e) {
    this[PRIVATE.LOGGER].debug('⚠️ Не удалось сохранить состояние:', e.message);
  }
}

_loadState() {
  try {
    const key = this[PRIVATE.CONFIG][CONFIG_SYMBOLS.STATE_KEY] || 'panel-controller-state';
    const saved = localStorage.getItem(key);
    if (saved) {
      const data = JSON.parse(saved);
      if (data.state && typeof data.state === 'object') {
        Object.assign(this[PRIVATE.STATE], data.state);
        if (data.metadata) {
          Object.assign(this[PRIVATE.METADATA], data.metadata);
        }
        this._applyStateToDom();
        this[PRIVATE.LOGGER].debug('✅ Состояние загружено');
      }
    }
  } catch (e) {
    this[PRIVATE.LOGGER].debug('⚠️ Не удалось загрузить состояние:', e.message);
  }
}

saveState() {
  return this._saveState();
}

loadState() {
  return this._loadState();
}

// ============================================================
// 17. ★★★ ПРОВЕРКА СОСТОЯНИЯ ★★★
// ============================================================

_checkState() {
  const panel = this[PRIVATE.PANEL];
  if (!panel) return;

  // Проверяем, что панель всё ещё в DOM
  if (!document.body.contains(panel)) {
    this[PRIVATE.LOGGER].warn('⚠️ Панель удалена из DOM, восстанавливаем...');
    document.body.appendChild(panel);
  }

  // Проверяем позицию
  const pos = this[PRIVATE.STATE].position;
  if (pos) {
    const maxX = window.innerWidth - panel.offsetWidth;
    const maxY = window.innerHeight - panel.offsetHeight;
    if (pos.x > maxX || pos.y > maxY) {
      this[PRIVATE.LOGGER].debug('📌 Корректировка позиции панели');
      this[PRIVATE.DO_MOVE](
        Math.min(pos.x, maxX),
        Math.min(pos.y, maxY),
        { animate: false }
      );
    }
  }
}

// ============================================================
// 18. ★★★ СОБЫТИЯ ★★★
// ============================================================

on(event, callback) {
  if (!VALIDATOR[VALIDATOR_SYMBOLS.IS_CALLBACK](callback)) {
    this[PRIVATE.LOGGER].warn(`⚠️ Некорректный callback для события ${event}`);
    return () => {};
  }

  const handlers = this[PRIVATE.EVENT_HANDLERS];
  if (!handlers.has(event)) {
    handlers.set(event, []);
  }
  handlers.get(event).push(callback);

  return () => this.off(event, callback);
}

off(event, callback) {
  const handlers = this[PRIVATE.EVENT_HANDLERS];
  if (handlers.has(event)) {
    const list = handlers.get(event);
    const index = list.indexOf(callback);
    if (index !== -1) {
      list.splice(index, 1);
    }
    if (list.length === 0) {
      handlers.delete(event);
    }
  }
}

[PRIVATE.EMIT](event, data) {
  const handlers = this[PRIVATE.EVENT_HANDLERS];
  if (handlers.has(event)) {
    const list = handlers.get(event);
    for (const callback of list) {
      try {
        callback(data);
      } catch (e) {
        this[PRIVATE.LOGGER].error(`❌ Ошибка в обработчике ${event}:`, e.message);
      }
    }
  }

  // Также отправляем глобальное событие
  if (typeof window !== 'undefined') {
    try {
      const customEvent = new CustomEvent(`panel:${event}`, {
        detail: { ...data, controller: this, timestamp: Date.now() },
      });
      window.dispatchEvent(customEvent);
    } catch (e) {
      // Игнорируем ошибки
    }
  }
}

emit(event, data) {
  this[PRIVATE.EMIT](event, data);
}

// ============================================================
// 19. ★★★ ПУБЛИЧНЫЕ МЕТОДЫ ★★★
// ============================================================

async show(options = {}) {
  return this[PRIVATE.DO_SHOW](options);
}

async hide(options = {}) {
  return this[PRIVATE.DO_HIDE](options);
}

async toggle(options = {}) {
  return this[PRIVATE.DO_TOGGLE](options);
}

async minimize(options = {}) {
  return this[PRIVATE.DO_MINIMIZE](options);
}

async fullscreen(options = {}) {
  return this[PRIVATE.DO_FULLSCREEN](options);
}

async close(options = {}) {
  return this[PRIVATE.DO_CLOSE](options);
}

async focus(options = {}) {
  return this[PRIVATE.DO_FOCUS](options);
}

async resize(width, height, options = {}) {
  return this[PRIVATE.DO_RESIZE](width, height, options);
}

async move(x, y, options = {}) {
  return this[PRIVATE.DO_MOVE](x, y, options);
}

// ============================================================
// 20. ★★★ ЦЕПОЧКА ВЫЗОВОВ ★★★
// ============================================================

[PRIVATE.CHAIN](action, ...args) {
  return new Promise((resolve, reject) => {
    const handler = () => {
      try {
        const result = this[action](...args);
        resolve(result);
      } catch (e) {
        reject(e);
      }
    };

    if (this[PRIVATE.ACTION_QUEUE].length < CONFIG[CONFIG_SYMBOLS.MAX_ACTION_QUEUE]) {
      this[PRIVATE.ACTION_QUEUE].push(handler);
      this._processQueue();
    } else {
      reject(new Error('Очередь действий переполнена'));
    }
  });
}

async _processQueue() {
  if (this[PRIVATE.IS_PROCESSING] || this[PRIVATE.ACTION_QUEUE].length === 0) return;

  this[PRIVATE.IS_PROCESSING] = true;

  while (this[PRIVATE.ACTION_QUEUE].length > 0) {
    const handler = this[PRIVATE.ACTION_QUEUE].shift();
    try {
      await handler();
    } catch (e) {
      this[PRIVATE.LOGGER].error('❌ Ошибка в цепочке вызовов:', e.message);
    }
  }

  this[PRIVATE.IS_PROCESSING] = false;
}

then(callback) {
  return this[PRIVATE.CHAIN]('then', callback);
}

catch(callback) {
  return this[PRIVATE.CHAIN]('catch', callback);
}

finally(callback) {
  return this[PRIVATE.CHAIN]('finally', callback);
}

// ============================================================
// 21. ★★★ СТАТИСТИКА ★★★
// ============================================================

getStats() {
  return {
    state: { ...this[PRIVATE.STATE] },
    metadata: { ...this[PRIVATE.METADATA] },
    context: { ...this[PRIVATE.CONTEXT] },
    config: { ...this[PRIVATE.CONFIG] },
    cacheSize: this[PRIVATE.CACHE].size,
    listenersCount: this[PRIVATE.LISTENERS].length,
    eventHandlersCount: this[PRIVATE.EVENT_HANDLERS].size,
    domListenersCount: this[PRIVATE.DOM_LISTENERS].length,
    timersCount: this[PRIVATE.TIMERS].size,
    actionQueueSize: this[PRIVATE.ACTION_QUEUE].length,
    isProcessing: this[PRIVATE.IS_PROCESSING],
    initialized: this[PRIVATE.INITIALIZED],
    destroyed: this[PRIVATE.DESTROYED],
    isRunning: this[PRIVATE.IS_RUNNING],
    logHistorySize: this[PRIVATE.LOG_HISTORY].length,
  };
}

// ============================================================
// 22. ★★★ СБРОС И УНИЧТОЖЕНИЕ ★★★
// ============================================================

reset() {
  const logger = this[PRIVATE.LOGGER];
  logger.warn('🔄 Сброс контроллера...');

  this.resetState();
  this[PRIVATE.CACHE].clear();
  this[PRIVATE.METADATA] = {
    created: Date.now(),
    lastAccess: Date.now(),
    lastUpdate: Date.now(),
    actionCount: 0,
    errorCount: 0,
    successCount: 0,
  };
  this[PRIVATE.ACTION_QUEUE] = [];
  this[PRIVATE.IS_PROCESSING] = false;

  this[PRIVATE.EMIT]('reset', { controller: this });

  logger.success('✅ Контроллер сброшен');
  return this;
}

destroy() {
  if (this[PRIVATE.DESTROYED]) {
    this[PRIVATE.LOGGER].warn('⚠️ Контроллер уже уничтожен');
    return;
  }

  const logger = this[PRIVATE.LOGGER];
  logger.warn('🗑️ Уничтожение контроллера...');

  // Очищаем таймеры
  for (const [key, timer] of this[PRIVATE.TIMERS]) {
    clearInterval(timer);
    clearTimeout(timer);
  }
  this[PRIVATE.TIMERS].clear();

  if (this[PRIVATE.RAF_ID]) {
    cancelAnimationFrame(this[PRIVATE.RAF_ID]);
    this[PRIVATE.RAF_ID] = null;
  }

  for (const [key, timer] of this[PRIVATE.DEBOUNCE_TIMERS]) {
    clearTimeout(timer);
  }
  this[PRIVATE.DEBOUNCE_TIMERS].clear();

  // Удаляем DOM слушатели
  for (const { element, event, handler } of this[PRIVATE.DOM_LISTENERS]) {
    try {
      element.removeEventListener(event, handler);
    } catch (e) {
      // Игнорируем ошибки
    }
  }
  this[PRIVATE.DOM_LISTENERS] = [];

  // Очищаем данные
  this[PRIVATE.CACHE].clear();
  this[PRIVATE.EVENT_HANDLERS].clear();
  this[PRIVATE.LISTENERS] = [];
  this[PRIVATE.ACTION_QUEUE] = [];
  this[PRIVATE.LOG_HISTORY] = [];

  // Удаляем панель из DOM
  if (this[PRIVATE.PANEL] && this[PRIVATE.PANEL].parentNode) {
    this[PRIVATE.PANEL].parentNode.removeChild(this[PRIVATE.PANEL]);
  }

  // Удаляем глобальные ссылки
  if (typeof window !== 'undefined') {
    delete window[PUBLIC.API];
    delete window[PUBLIC.STATE];
    delete window[PUBLIC.CONFIG];
    delete window[PUBLIC.LOGGER];
    delete window[PUBLIC.EVENTS];
    delete window[PUBLIC.INSTANCE];
    delete window[PUBLIC.ACTIONS];
    delete window[PUBLIC.CHAIN];
    if (window.__panelController === this) {
      delete window.__panelController;
    }
  }

  this[PRIVATE.DESTROYED] = true;
  this[PRIVATE.INITIALIZED] = false;
  this[PRIVATE.IS_RUNNING] = false;

  this[PRIVATE.EMIT]('destroy', { controller: this });

  logger.success('✅ Контроллер уничтожен');
}

// ============================================================
// 23. ★★★ ЭКСПОРТ СИМВОЛОВ ★★★
// ============================================================

_exportSymbols() {
  if (typeof window === 'undefined') return;

  window[PUBLIC.API] = this;
  window[PUBLIC.STATE] = this.getState.bind(this);
  window[PUBLIC.CONFIG] = this[PRIVATE.CONFIG];
  window[PUBLIC.LOGGER] = this[PRIVATE.LOGGER];
  window[PUBLIC.EVENTS] = {
    on: this.on.bind(this),
    off: this.off.bind(this),
    emit: this.emit.bind(this),
  };
  window[PUBLIC.INSTANCE] = this;
  window[PUBLIC.ACTIONS] = {
    show: this.show.bind(this),
    hide: this.hide.bind(this),
    toggle: this.toggle.bind(this),
    minimize: this.minimize.bind(this),
    fullscreen: this.fullscreen.bind(this),
    close: this.close.bind(this),
    focus: this.focus.bind(this),
    resize: this.resize.bind(this),
    move: this.move.bind(this),
  };
  window[PUBLIC.CHAIN] = {
    then: this.then.bind(this),
    catch: this.catch.bind(this),
    finally: this.finally.bind(this),
  };

  window.__panelController = this;
  window.__panelControllerSymbols = {
    PRIVATE: { ...PRIVATE },
    PUBLIC: { ...PUBLIC },
    LOGGER_SYMBOLS: { ...LOGGER_SYMBOLS },
    VALIDATOR_SYMBOLS: { ...VALIDATOR_SYMBOLS },
    CONFIG_SYMBOLS: { ...CONFIG_SYMBOLS },
    version: '2.2.0',
  };
}

// ============================================================
// 24. ★★★ ПОЛУЧЕНИЕ СИМВОЛОВ ★★★
// ============================================================

getSymbols() {
  return {
    PRIVATE: { ...PRIVATE },
    PUBLIC: { ...PUBLIC },
    LOGGER_SYMBOLS: { ...LOGGER_SYMBOLS },
    VALIDATOR_SYMBOLS: { ...VALIDATOR_SYMBOLS },
    CONFIG_SYMBOLS: { ...CONFIG_SYMBOLS },
  };
}

// ============================================================
// 25. ★★★ ПОЛУЧЕНИЕ ЛОГГЕРА ★★★
// ============================================================

getLogger() {
  return this[PRIVATE.LOGGER];
}

// ============================================================
// 26. ★★★ ПОЛУЧЕНИЕ КОНФИГА ★★★
// ============================================================

getConfig() {
  return { ...this[PRIVATE.CONFIG] };
}

// ============================================================
// 27. ★★★ ПОЛУЧЕНИЕ ПАНЕЛИ ★★★
// ============================================================

getPanel() {
  return this[PRIVATE.PANEL];
}
}

// ============================================================
// 28. ★★★ ГЛОБАЛЬНАЯ РЕГИСТРАЦИЯ ★★★
// ============================================================

if (typeof window !== 'undefined') {
  window.PanelController = PanelController;

  console.log('╔═══════════════════════════════════════════════════════════════════════════════╗');
  console.log('║              📦 PANEL CONTROLLER (100% СИМВОЛЫ) v2.2.0                      ║');
  console.log('╠═══════════════════════════════════════════════════════════════════════════════╣');
  console.log('║  📋 Все логи выводятся в консоль с цветовой разметкой                       ║');
  console.log('║  🔑 Полная изоляция через приватные символы                                 ║');
  console.log('║  🔓 Публичные символы через Symbol.for                                      ║');
  console.log('║  🎯 9 действий: show, hide, toggle, minimize, fullscreen, close, focus, resize, move ║');
  console.log('║  📊 Полное управление состоянием                                            ║');
  console.log('║  🎬 Анимации с настраиваемой длительностью                                  ║');
  console.log('║  📡 Система событий (on/off/emit)                                          ║');
  console.log('║  💾 Кеширование и сохранение состояния                                     ║');
  console.log('║  🔗 Цепочка вызовов (then/catch/finally)                                   ║');
  console.log('║  🧹 Очистка таймеров и ресурсов                                            ║');
  console.log('╚═══════════════════════════════════════════════════════════════════════════════╝');

  console.log('📋 ПРИВАТНЫХ СИМВОЛОВ:', Object.keys(PRIVATE).length);
  console.log('📋 ПУБЛИЧНЫХ СИМВОЛОВ:', Object.keys(PUBLIC).length);
  console.log('📋 ЛОГГЕР СИМВОЛОВ:', Object.keys(LOGGER_SYMBOLS).length);
  console.log('📋 ВАЛИДАТОР СИМВОЛОВ:', Object.keys(VALIDATOR_SYMBOLS).length);
  console.log('📋 КОНФИГ СИМВОЛОВ:', Object.keys(CONFIG_SYMBOLS).length);
  console.log('═══════════════════════════════════════════════════════════════════════════════');

  console.log('📋 КОМАНДЫ ОТЛАДКИ (__panelController):');
  console.log('  __panelController.show()         - показать панель');
  console.log('  __panelController.hide()         - скрыть панель');
  console.log('  __panelController.toggle()       - переключить');
  console.log('  __panelController.minimize()     - свернуть/развернуть');
  console.log('  __panelController.fullscreen()   - полноэкранный режим');
  console.log('  __panelController.close()        - закрыть');
  console.log('  __panelController.focus()        - вывести на передний план');
  console.log('  __panelController.resize(w,h)    - изменить размер');
  console.log('  __panelController.move(x,y)      - переместить');
  console.log('  __panelController.getState()     - получить состояние');
  console.log('  __panelController.updateState()  - обновить состояние');
  console.log('  __panelController.resetState()   - сбросить состояние');
  console.log('  __panelController.saveState()    - сохранить состояние');
  console.log('  __panelController.loadState()    - загрузить состояние');
  console.log('  __panelController.getStats()     - статистика');
  console.log('  __panelController.on(event, cb)  - подписка на события');
  console.log('  __panelController.off(event, cb) - отписка');
  console.log('  __panelController.emit(event)    - отправка события');
  console.log('  __panelController.then(cb)       - цепочка вызовов');
  console.log('  __panelController.catch(cb)      - обработка ошибок');
  console.log('  __panelController.finally(cb)    - завершение цепочки');
  console.log('  __panelController.reset()        - сброс контроллера');
  console.log('  __panelController.destroy()      - уничтожить');
  console.log('  __panelController.getSymbols()   - получить все символы');
  console.log('');

  console.log('📋 СОБЫТИЯ:');
  console.log('  init, reset, destroy');
  console.log('  beforeShow, afterShow, beforeHide, afterHide');
  console.log('  beforeToggle, afterToggle, beforeMinimize, afterMinimize');
  console.log('  beforeFullscreen, afterFullscreen, beforeClose, afterClose');
  console.log('  onFocus, beforeResize, afterResize, beforeMove, afterMove');
  console.log('  dragStart, drag, dragEnd, resizeStart, resize, resizeEnd');
  console.log('  stateChange, stateReset');
  console.log('');
}

// ============================================================
// 29. ★★★ ЭКСПОРТЫ ★★★
// ============================================================

export {
  PRIVATE,
  PUBLIC,
  LOGGER_SYMBOLS,
  VALIDATOR_SYMBOLS,
  CONFIG_SYMBOLS,
  CONFIG,
  PanelController,
};

export default PanelController;
