// web/Bookmarklet/src/template/env-template.mjs
// 100% СИМВОЛЫ — полная изоляция и безопасность
// Шаблон ENV панели
// Версия: 2.1.9

// ============================================================
// 1. ПРИВАТНЫЕ СИМВОЛЫ (100% изоляция)
// ============================================================

const PRIVATE = {
  // Основные символы шаблона
  TEMPLATE_ID: Symbol('env-template.id'),
  TEMPLATE_VERSION: Symbol('env-template.version'),
  TEMPLATE_TYPE: Symbol('env-template.type'),

  // Символы секций
  CONTAINER: Symbol('env-template.container'),
  HEADER: Symbol('env-template.header'),
  BODY: Symbol('env-template.body'),
  GROUPS: Symbol('env-template.groups'),
  ACTIONS: Symbol('env-template.actions'),
  COMMANDS: Symbol('env-template.commands'),
  RESIZE: Symbol('env-template.resize'),
  FULL_TEMPLATE: Symbol('env-template.full'),

  // Символы элементов
  GROUPS_CONTAINER: Symbol('env-template.groupsContainer'),
  ACTIONS_CONTAINER: Symbol('env-template.actionsContainer'),
  COMMANDS_CONTAINER: Symbol('env-template.commandsContainer'),
  STATUS_BADGE: Symbol('env-template.statusBadge'),

  // Символы пресетов
  PRESET_FLOW: Symbol('env-template.presetFlow'),
  PRESET_MEMORY: Symbol('env-template.presetMemory'),
  PRESET_GENERATE: Symbol('env-template.presetGenerate'),
  PRESET_API: Symbol('env-template.presetApi'),
  PRESET_ERRORS: Symbol('env-template.presetErrors'),
  PRESET_ALL: Symbol('env-template.presetAll'),
  PRESET_CUSTOM: Symbol('env-template.presetCustom'),
  PRESET_BOOKMARKLET: Symbol('env-template.presetBookmarklet'),

  // Символы действий
  ACTION_ENABLE_ALL: Symbol('env-template.actionEnableAll'),
  ACTION_DISABLE_ALL: Symbol('env-template.actionDisableAll'),
  ACTION_SHOW_CONFIG: Symbol('env-template.actionShowConfig'),
  ACTION_ENABLE_FLOW: Symbol('env-template.actionEnableFlow'),
  ACTION_ENABLE_MEMORY: Symbol('env-template.actionEnableMemory'),
  ACTION_ENABLE_GENERATE: Symbol('env-template.actionEnableGenerate'),
  ACTION_ENABLE_API: Symbol('env-template.actionEnableApi'),
  ACTION_ENABLE_ERRORS: Symbol('env-template.actionEnableErrors'),
  ACTION_ENABLE_ALL_EXCEPT_MEMORY: Symbol('env-template.actionEnableAllExceptMemory'),
  ACTION_ENABLE_BOOKMARKLET: Symbol('env-template.actionEnableBookmarklet'),
  ACTION_DISABLE_BOOKMARKLET: Symbol('env-template.actionDisableBookmarklet'),
  ACTION_SYNC: Symbol('env-template.actionSync'),
  ACTION_EXPORT: Symbol('env-template.actionExport'),
  ACTION_RESET: Symbol('env-template.actionReset'),
  ACTION_HISTORY: Symbol('env-template.actionHistory'),
  ACTION_SHARED_MEMORY: Symbol('env-template.actionSharedMemory'),

  // Символы стилей
  STYLES: Symbol('env-template.styles'),
  STYLE_CONTAINER: Symbol('env-template.styleContainer'),
  STYLE_HEADER: Symbol('env-template.styleHeader'),
  STYLE_BODY: Symbol('env-template.styleBody'),
  STYLE_GROUPS: Symbol('env-template.styleGroups'),
  STYLE_GROUP: Symbol('env-template.styleGroup'),
  STYLE_GROUP_TITLE: Symbol('env-template.styleGroupTitle'),
  STYLE_PRESET_BTN: Symbol('env-template.stylePresetBtn'),
  STYLE_PRESET_BTN_ACTIVE: Symbol('env-template.stylePresetBtnActive'),
  STYLE_ACTION_BTN: Symbol('env-template.styleActionBtn'),
  STYLE_COMMANDS: Symbol('env-template.styleCommands'),
  STYLE_STATUS_BADGE: Symbol('env-template.styleStatusBadge'),
  STYLE_RESIZE: Symbol('env-template.styleResize'),

  // Символы утилит
  ESCAPE_HTML: Symbol('env-template.escapeHtml'),
  CREATE_ELEMENT: Symbol('env-template.createElement'),
  CREATE_BUTTON: Symbol('env-template.createButton'),
  CREATE_GROUP: Symbol('env-template.createGroup'),
  CREATE_PRESET: Symbol('env-template.createPreset'),
  CREATE_ACTION: Symbol('env-template.createAction'),
  RENDER_TEMPLATE: Symbol('env-template.renderTemplate'),
  GET_CURRENT_NAMESPACE: Symbol('env-template.getCurrentNamespace'),
  IS_ACTIVE_PRESET: Symbol('env-template.isActivePreset'),

  // Символы кеша
  CACHE: Symbol('env-template.cache'),
  CACHE_KEY: Symbol('env-template.cacheKey'),
  CACHE_TTL: Symbol('env-template.cacheTtl'),

  // Символы метаданных
  METADATA: Symbol('env-template.metadata'),
  GENERATED_AT: Symbol('env-template.generatedAt'),
  TEMPLATE_HASH: Symbol('env-template.templateHash'),

  // Символы отладки
  DEBUG: Symbol('env-template.debug'),
  LOG_HISTORY: Symbol('env-template.logHistory'),
  RENDER_COUNT: Symbol('env-template.renderCount'),
};

// ============================================================
// 2. ПУБЛИЧНЫЕ СИМВОЛЫ (доступны через Symbol.for)
// ============================================================

const PUBLIC = {
  API: Symbol.for('env-template.api'),
  CONFIG: Symbol.for('env-template.config'),
  RENDER: Symbol.for('env-template.render'),
  TEMPLATE: Symbol.for('env-template.template'),
  UTILS: Symbol.for('env-template.utils'),
  INSTANCE: Symbol.for('env-template.instance'),
};

// ============================================================
// 3. КОНФИГУРАЦИЯ (100% СИМВОЛЫ)
// ============================================================

const CONFIG_SYMBOLS = {
  VERSION: Symbol('config.version'),
  BUILD: Symbol('config.build'),
  DEBUG: Symbol('config.debug'),
  CACHE_TTL: Symbol('config.cacheTtl'),
  MAX_HISTORY: Symbol('config.maxHistory'),
  ANIMATION_DURATION: Symbol('config.animationDuration'),
  DEFAULT_NAMESPACE: Symbol('config.defaultNamespace'),
};

const CONFIG = {
  [CONFIG_SYMBOLS.VERSION]: '2.1.9',
  [CONFIG_SYMBOLS.BUILD]: '2026-07-21',
  [CONFIG_SYMBOLS.DEBUG]: true,
  [CONFIG_SYMBOLS.CACHE_TTL]: 300000,
  [CONFIG_SYMBOLS.MAX_HISTORY]: 100,
  [CONFIG_SYMBOLS.ANIMATION_DURATION]: 200,
  [CONFIG_SYMBOLS.DEFAULT_NAMESPACE]: '',
};

// ============================================================
// 4. ЛОГГЕР (100% СИМВОЛЫ)
// ============================================================

const LOGGER_SYMBOLS = {
  HISTORY: Symbol('logger.history'),
  MAX_HISTORY: Symbol('logger.maxHistory'),
  DEBUG: Symbol('logger.debug'),
  INSTANCE_ID: Symbol('logger.instanceId'),
  LEVEL: Symbol('logger.level'),
  COLORS: Symbol('logger.colors'),
  TIMESTAMP: Symbol('logger.timestamp'),
  OUTPUT: Symbol('logger.output'),
};

function createTemplateLogger(debug = true, instanceId = 'EnvTemplate') {
  const loggerState = {
    [LOGGER_SYMBOLS.HISTORY]: [],
    [LOGGER_SYMBOLS.MAX_HISTORY]: 200,
    [LOGGER_SYMBOLS.DEBUG]: debug,
    [LOGGER_SYMBOLS.INSTANCE_ID]: instanceId,
    [LOGGER_SYMBOLS.LEVEL]: 'info',
    [LOGGER_SYMBOLS.COLORS]: true,
    [LOGGER_SYMBOLS.TIMESTAMP]: true,
    [LOGGER_SYMBOLS.OUTPUT]: console,
  };

  const logMethod = function (level, message, data = null) {
    if (!this[LOGGER_SYMBOLS.DEBUG] && level !== 'error') {
      return;
    }

    const timestamp = this[LOGGER_SYMBOLS.TIMESTAMP]
      ? `[${new Date().toISOString().slice(11, 23)}]`
      : '';
    const prefix = `${timestamp} [${this[LOGGER_SYMBOLS.INSTANCE_ID]}]`;
    const output = this[LOGGER_SYMBOLS.OUTPUT];

    this[LOGGER_SYMBOLS.HISTORY].push({ timestamp, level, message, data });
    if (this[LOGGER_SYMBOLS.HISTORY].length > this[LOGGER_SYMBOLS.MAX_HISTORY]) {
      this[LOGGER_SYMBOLS.HISTORY].shift();
    }

    const styles = this[LOGGER_SYMBOLS.COLORS]
      ? {
          error: 'color: #ff6b6b; font-weight: bold;',
          warn: 'color: #fdcb6e; font-weight: bold;',
          info: 'color: #74b9ff; font-weight: bold;',
          debug: 'color: #a29bfe;',
          success: 'color: #00b894; font-weight: bold;',
          template: 'color: #e17055; font-weight: bold;',
        }
      : {};

    const style = styles[level] || styles.info;

    if (data !== null && data !== undefined) {
      if (typeof data === 'object') {
        output.log(`%c${prefix} ${message}`, style, data);
      } else {
        output.log(`%c${prefix} ${message}`, style, data);
      }
    } else {
      output.log(`%c${prefix} ${message}`, style);
    }
  };

  const boundLog = logMethod.bind(loggerState);

  const logger = {
    error: (msg, d) => boundLog('error', `❌ ${msg}`, d),
    warn: (msg, d) => boundLog('warn', `⚠️ ${msg}`, d),
    info: (msg, d) => boundLog('info', `ℹ️ ${msg}`, d),
    debug: (msg, d) => boundLog('debug', `🔍 ${msg}`, d),
    success: (msg, d) => boundLog('info', `✅ ${msg}`, d),
    template: (msg, d) => boundLog('info', `📄 ${msg}`, d),

    header: title => {
      const output = loggerState[LOGGER_SYMBOLS.OUTPUT];
      output.log('%c' + '═'.repeat(70), 'color: #636e72;');
      output.log(
        '%c  📦 ' + title,
        'background: #1a1a2e; color: #fff; padding: 4px 12px; border-radius: 4px; font-weight: bold;'
      );
      output.log('%c' + '═'.repeat(70), 'color: #636e72;');
    },

    separator: () => {
      const output = loggerState[LOGGER_SYMBOLS.OUTPUT];
      output.log('%c' + '─'.repeat(70), 'color: #636e72;');
    },

    getHistory: () => [...loggerState[LOGGER_SYMBOLS.HISTORY]],
    clearHistory: () => {
      loggerState[LOGGER_SYMBOLS.HISTORY] = [];
      return logger;
    },
    setDebug: enabled => {
      loggerState[LOGGER_SYMBOLS.DEBUG] = enabled;
      return logger;
    },
    setLevel: level => {
      loggerState[LOGGER_SYMBOLS.LEVEL] = level;
      return logger;
    },
    getLevel: () => loggerState[LOGGER_SYMBOLS.LEVEL],
  };

  return logger;
}

const logger = createTemplateLogger(true, 'EnvTemplate');

// ============================================================
// 5. ВАЛИДАТОР (100% СИМВОЛЫ)
// ============================================================

const VALIDATOR_SYMBOLS = {
  IS_VALID_STRING: Symbol('validator.isValidString'),
  IS_VALID_NAMESPACE: Symbol('validator.isValidNamespace'),
  IS_VALID_PRESET: Symbol('validator.isValidPreset'),
  IS_VALID_ACTION: Symbol('validator.isValidAction'),
  SANITIZE_HTML: Symbol('validator.sanitizeHtml'),
  SANITIZE_NAMESPACE: Symbol('validator.sanitizeNamespace'),
  ESCAPE_HTML: Symbol('validator.escapeHtml'),
  IS_EMPTY: Symbol('validator.isEmpty'),
  IS_ACTIVE: Symbol('validator.isActive'),
};

const VALIDATOR = {
  [VALIDATOR_SYMBOLS.IS_VALID_STRING]: str => {
    return str !== null && str !== undefined && typeof str === 'string';
  },

  [VALIDATOR_SYMBOLS.IS_VALID_NAMESPACE]: ns => {
    if (!VALIDATOR[VALIDATOR_SYMBOLS.IS_VALID_STRING](ns)) return false;
    return ns.length === 0 || /^[a-zA-Z0-9:*,-]+$/.test(ns);
  },

  [VALIDATOR_SYMBOLS.IS_VALID_PRESET]: preset => {
    return preset !== null && preset !== undefined && typeof preset === 'object';
  },

  [VALIDATOR_SYMBOLS.IS_VALID_ACTION]: action => {
    return typeof action === 'function';
  },

  [VALIDATOR_SYMBOLS.SANITIZE_HTML]: html => {
    if (!VALIDATOR[VALIDATOR_SYMBOLS.IS_VALID_STRING](html)) return '';
    return html
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  },

  [VALIDATOR_SYMBOLS.SANITIZE_NAMESPACE]: ns => {
    if (!VALIDATOR[VALIDATOR_SYMBOLS.IS_VALID_STRING](ns)) return '';
    return ns.replace(/[^a-zA-Z0-9:*,-]/g, '');
  },

  [VALIDATOR_SYMBOLS.ESCAPE_HTML]: text => {
    if (!VALIDATOR[VALIDATOR_SYMBOLS.IS_VALID_STRING](text)) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  },

  [VALIDATOR_SYMBOLS.IS_EMPTY]: value => {
    return value === null || value === undefined || value === '';
  },

  [VALIDATOR_SYMBOLS.IS_ACTIVE]: (preset, current) => {
    return preset === current;
  },
};

// ============================================================
// 6. СТИЛИ (100% СИМВОЛЫ)
// ============================================================

const STYLES = {
  [PRIVATE.STYLE_CONTAINER]: `
    position: fixed;
    display: flex;
    flex-direction: column;
    overflow: hidden;
    background: rgba(26, 26, 46, 0.96);
    backdrop-filter: blur(20px);
    border: 1px solid rgba(255,255,255,0.08);
    border-radius: 12px;
    color: #fff;
    font-family: 'Segoe UI', system-ui, sans-serif;
    font-size: 13px;
    box-shadow: 0 20px 60px rgba(0,0,0,0.8);
    min-width: 320px;
    min-height: 300px;
    max-width: 90vw;
    max-height: 90vh;
    user-select: none;
  `,

  [PRIVATE.STYLE_HEADER]: `
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 8px 14px;
    border-bottom: 1px solid rgba(255,255,255,0.06);
    cursor: grab;
    flex-shrink: 0;
    min-height: 44px;
    background: rgba(26, 26, 46, 0.98);
  `,

  [PRIVATE.STYLE_BODY]: `
    flex: 1;
    overflow-y: auto;
    padding: 10px 14px 14px 14px;
    scrollbar-width: thin;
    scrollbar-color: rgba(102,126,234,0.3) transparent;
  `,

  [PRIVATE.STYLE_GROUPS]: `
    display: flex;
    flex-direction: column;
    gap: 8px;
  `,

  [PRIVATE.STYLE_GROUP]: `
    border: 1px solid rgba(255,255,255,0.05);
    border-radius: 8px;
    padding: 8px 10px;
    background: rgba(255,255,255,0.02);
  `,

  [PRIVATE.STYLE_GROUP_TITLE]: `
    font-size: 10px;
    font-weight: bold;
    color: #8899bb;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    margin-bottom: 4px;
  `,

  [PRIVATE.STYLE_PRESET_BTN]: isActive => `
    padding: 3px 8px;
    border: 1px solid ${isActive ? '#667eea' : 'rgba(255,255,255,0.05)'};
    border-radius: 4px;
    background: ${isActive ? 'rgba(102,126,234,0.3)' : 'rgba(255,255,255,0.03)'};
    color: ${isActive ? '#fff' : '#8899bb'};
    font-size: 10px;
    cursor: pointer;
    font-family: inherit;
    white-space: nowrap;
    transition: all 0.2s;
  `,

  [PRIVATE.STYLE_PRESET_BTN_ACTIVE]: `
    background: rgba(102,126,234,0.3);
    color: #fff;
    border-color: #667eea;
  `,

  [PRIVATE.STYLE_ACTION_BTN]: `
    padding: 4px 10px;
    border: 1px solid rgba(255,255,255,0.05);
    border-radius: 4px;
    background: rgba(255,255,255,0.03);
    color: #8899bb;
    font-size: 10px;
    cursor: pointer;
    font-family: inherit;
    transition: all 0.2s;
  `,

  [PRIVATE.STYLE_COMMANDS]: `
    margin-top: 8px;
    padding: 6px 10px;
    background: rgba(0,0,0,0.3);
    border-radius: 4px;
    font-size: 9px;
    color: #636e72;
    font-family: monospace;
    border: 1px solid rgba(255,255,255,0.03);
  `,

  [PRIVATE.STYLE_STATUS_BADGE]: isActive => `
    font-size: 9px;
    padding: 1px 8px;
    border-radius: 10px;
    background: ${isActive ? 'rgba(0,184,148,0.15)' : 'rgba(255,255,255,0.05)'};
    color: ${isActive ? '#00b894' : '#636e72'};
    border: 1px solid ${isActive ? 'rgba(0,184,148,0.2)' : 'rgba(255,255,255,0.05)'};
    margin-left: 8px;
  `,

  [PRIVATE.STYLE_RESIZE]: `
    position: absolute;
    bottom: 0;
    right: 0;
    width: 16px;
    height: 16px;
    cursor: nwse-resize;
    z-index: 10;
    background: linear-gradient(135deg, transparent 50%, rgba(102,126,234,0.2) 50%);
    border-radius: 0 0 12px 0;
  `,
};

// ============================================================
// 7. ГРУППЫ ПРЕСЕТОВ (100% СИМВОЛЫ)
// ============================================================

const PRESET_GROUPS = {
  [PRIVATE.PRESET_FLOW]: {
    name: '🌊 Flow',
    presets: [
      { name: 'Все flow', value: 'wasm:flow:*' },
      { name: 'Flow шаги', value: 'wasm:flow:step:*' },
      { name: 'Flow чекпоинты', value: 'wasm:flow:checkpoint:*' },
      { name: 'Flow ветки', value: 'wasm:flow:branch:*' },
    ],
  },

  [PRIVATE.PRESET_MEMORY]: {
    name: '🧠 Memory',
    presets: [
      { name: 'Все память', value: 'wasm:memory:*' },
      { name: 'Чтение памяти', value: 'wasm:memory:read:*' },
      { name: 'Запись памяти', value: 'wasm:memory:write:*' },
    ],
  },

  [PRIVATE.PRESET_GENERATE]: {
    name: '⚡ Generate',
    presets: [
      { name: 'Все генерация', value: 'wasm:generate:*' },
      { name: 'JSON генерация', value: 'wasm:generate:json:*' },
      { name: 'C генерация', value: 'wasm:generate:c:*' },
      { name: 'ENV генерация', value: 'wasm:generate:env:*' },
    ],
  },

  [PRIVATE.PRESET_API]: {
    name: '🔧 API',
    presets: [
      { name: 'Все API', value: 'wasm:api:*' },
      { name: 'API вызовы', value: 'wasm:api:call:*' },
      { name: 'API ошибки', value: 'wasm:api:error:*' },
    ],
  },

  [PRIVATE.PRESET_ERRORS]: {
    name: '🚨 Errors',
    presets: [
      { name: 'Все ошибки', value: 'wasm:error:*' },
      { name: 'Критические', value: 'wasm:error:critical:*' },
    ],
  },

  [PRIVATE.PRESET_ALL]: {
    name: '📊 All',
    presets: [
      { name: 'ВСЕ ЛОГИ', value: 'wasm:*' },
      { name: 'Все кроме памяти', value: '*, -wasm:memory:*' },
      { name: 'Flow+Generate+Memory', value: 'wasm:flow:*, wasm:generate:*, wasm:memory:*' },
      { name: 'Только ошибки', value: 'wasm:error:*' },
    ],
  },

  [PRIVATE.PRESET_CUSTOM]: {
    name: '🎯 Custom',
    presets: [
      { name: 'Отключить всё', value: '' },
      { name: 'Только flow и generate', value: 'wasm:flow:*, wasm:generate:*' },
      { name: 'Только memory и errors', value: 'wasm:memory:*, wasm:error:*' },
      { name: 'Flow + API', value: 'wasm:flow:*, wasm:api:*' },
    ],
  },

  [PRIVATE.PRESET_BOOKMARKLET]: {
    name: '📦 Bookmarklet',
    presets: [
      { name: 'Все bookmarklet', value: 'bookmarklet:*' },
      { name: 'Только main', value: 'bookmarklet:main' },
      { name: 'Только loader', value: 'bookmarklet:loader' },
      { name: 'Только SW', value: 'bookmarklet:sw' },
      { name: 'Только панели', value: 'bookmarklet:panels' },
      { name: 'Все кроме SW', value: 'bookmarklet:*, -bookmarklet:sw' },
    ],
  },
};

// ============================================================
// 8. ДЕЙСТВИЯ (100% СИМВОЛЫ)
// ============================================================

const ACTIONS = {
  [PRIVATE.ACTION_ENABLE_ALL]: {
    name: '🔊 Всё',
    value: 'wasm:*',
    description: 'Включить все логи',
  },

  [PRIVATE.ACTION_DISABLE_ALL]: {
    name: '🔇 Выкл',
    value: '',
    description: 'Отключить все логи',
  },

  [PRIVATE.ACTION_ENABLE_FLOW]: {
    name: '🌊 Flow',
    value: 'wasm:flow:*',
    description: 'Включить flow логи',
  },

  [PRIVATE.ACTION_ENABLE_MEMORY]: {
    name: '🧠 Memory',
    value: 'wasm:memory:*',
    description: 'Включить логи памяти',
  },

  [PRIVATE.ACTION_ENABLE_GENERATE]: {
    name: '⚡ Generate',
    value: 'wasm:generate:*',
    description: 'Включить логи генерации',
  },

  [PRIVATE.ACTION_ENABLE_API]: {
    name: '🔧 API',
    value: 'wasm:api:*',
    description: 'Включить логи API',
  },

  [PRIVATE.ACTION_ENABLE_ERRORS]: {
    name: '🚨 Errors',
    value: 'wasm:error:*',
    description: 'Включить логи ошибок',
  },

  [PRIVATE.ACTION_ENABLE_ALL_EXCEPT_MEMORY]: {
    name: '📊 Все кроме памяти',
    value: '*, -wasm:memory:*',
    description: 'Включить все логи кроме памяти',
  },

  [PRIVATE.ACTION_ENABLE_BOOKMARKLET]: {
    name: '📦 Bookmarklet',
    value: 'bookmarklet:*',
    description: 'Включить логи букмарклета',
  },

  [PRIVATE.ACTION_DISABLE_BOOKMARKLET]: {
    name: '📦 Выкл',
    value: '',
    description: 'Отключить логи букмарклета',
  },

  [PRIVATE.ACTION_SYNC]: {
    name: '🔄 Синхр',
    value: null,
    description: 'Синхронизировать с localStorage',
  },

  [PRIVATE.ACTION_EXPORT]: {
    name: '📤 Экспорт',
    value: null,
    description: 'Экспортировать состояние',
  },

  [PRIVATE.ACTION_RESET]: {
    name: '🔄 Сброс',
    value: null,
    description: 'Сбросить состояние',
  },

  [PRIVATE.ACTION_HISTORY]: {
    name: '📜 История',
    value: null,
    description: 'Показать историю изменений',
  },

  [PRIVATE.ACTION_SHARED_MEMORY]: {
    name: '🧠 SharedMem',
    value: null,
    description: 'Проверить SharedMemory',
  },
};

// ============================================================
// 9. КОМАНДЫ (100% СИМВОЛЫ)
// ============================================================

const COMMANDS = [
  {
    code: 'ENV.debug.enable("wasm:*")',
    description: 'Включить все логи',
    color: '#667eea',
  },
  {
    code: 'ENV.debug.disable()',
    description: 'Отключить логи',
    color: '#ff6b6b',
  },
  {
    code: 'window.__envPanel.toggle()',
    description: 'Переключить панель',
    color: '#74b9ff',
  },
  {
    code: 'ENV.debug.setOptions({ depth: 4 })',
    description: 'Настроить глубину',
    color: '#fdcb6e',
  },
  {
    code: 'ENV.debug.getConfig()',
    description: 'Показать конфиг',
    color: '#a29bfe',
  },
  {
    code: 'ENV.debug.getHistory()',
    description: 'История изменений',
    color: '#fd79a8',
  },
  {
    code: 'ENV.debug.logStatus()',
    description: 'Статус DEBUG',
    color: '#00b894',
  },
  {
    code: 'ENV.debug.help()',
    description: 'Помощь по DEBUG',
    color: '#e17055',
  },
];

// ============================================================
// 10. ★★★ ОСНОВНОЙ ОБЪЕКТ ШАБЛОНА ★★★
// ============================================================

const EnvTemplate = {};

// ============================================================
// 10.1 ★★★ УТИЛИТЫ ★★★
// ============================================================

EnvTemplate[PRIVATE.ESCAPE_HTML] = function (text) {
  return VALIDATOR[VALIDATOR_SYMBOLS.ESCAPE_HTML](text);
};

EnvTemplate[PRIVATE.GET_CURRENT_NAMESPACE] = function () {
  try {
    if (typeof window.ENV?.debug?.namespace !== 'undefined') {
      return window.ENV.debug.namespace || CONFIG[CONFIG_SYMBOLS.DEFAULT_NAMESPACE];
    }
    if (typeof ENV?.debug?.namespace !== 'undefined') {
      return ENV.debug.namespace || CONFIG[CONFIG_SYMBOLS.DEFAULT_NAMESPACE];
    }
    return localStorage.getItem('debug') || CONFIG[CONFIG_SYMBOLS.DEFAULT_NAMESPACE];
  } catch {
    return CONFIG[CONFIG_SYMBOLS.DEFAULT_NAMESPACE];
  }
};

EnvTemplate[PRIVATE.IS_ACTIVE_PRESET] = function (presetValue, currentNamespace) {
  if (!presetValue && !currentNamespace) return true;
  if (!presetValue) return false;
  if (presetValue === currentNamespace) return true;
  // Проверка для составных паттернов с запятыми
  if (currentNamespace && currentNamespace.includes(',')) {
    const parts = currentNamespace.split(',').map(p => p.trim());
    return parts.some(p => p === presetValue);
  }
  return false;
};

// ============================================================
// 10.2 ★★★ СОЗДАНИЕ ЭЛЕМЕНТОВ ★★★
// ============================================================

EnvTemplate[PRIVATE.CREATE_ELEMENT] = function (tag, attrs = {}, children = []) {
  const el = document.createElement(tag);
  Object.entries(attrs).forEach(([key, value]) => {
    if (key === 'style' && typeof value === 'object') {
      Object.assign(el.style, value);
    } else if (key === 'dataset' && typeof value === 'object') {
      Object.entries(value).forEach(([k, v]) => {
        el.dataset[k] = v;
      });
    } else if (key === 'textContent') {
      el.textContent = value;
    } else if (key === 'innerHTML') {
      el.innerHTML = value;
    } else if (key === 'className') {
      el.className = value;
    } else {
      el.setAttribute(key, value);
    }
  });
  children.forEach(child => {
    if (typeof child === 'string') {
      el.appendChild(document.createTextNode(child));
    } else if (child instanceof Node) {
      el.appendChild(child);
    }
  });
  return el;
};

EnvTemplate[PRIVATE.CREATE_BUTTON] = function (text, attrs = {}, onClick = null) {
  const btn = EnvTemplate[PRIVATE.CREATE_ELEMENT]('button', {
    ...attrs,
    textContent: text,
    type: 'button',
  });
  if (onClick && typeof onClick === 'function') {
    btn.addEventListener('click', onClick);
  }
  return btn;
};

EnvTemplate[PRIVATE.CREATE_GROUP] = function (title, buttons, attrs = {}) {
  const group = EnvTemplate[PRIVATE.CREATE_ELEMENT]('div', {
    style: {
      border: '1px solid rgba(255,255,255,0.05)',
      borderRadius: '8px',
      padding: '8px 10px',
      background: 'rgba(255,255,255,0.02)',
      ...attrs.style,
    },
    ...attrs,
  });

  const titleEl = EnvTemplate[PRIVATE.CREATE_ELEMENT]('div', {
    style: {
      fontSize: '10px',
      fontWeight: 'bold',
      color: '#8899bb',
      textTransform: 'uppercase',
      letterSpacing: '0.5px',
      marginBottom: '4px',
    },
    textContent: title,
  });
  group.appendChild(titleEl);

  const btnsContainer = EnvTemplate[PRIVATE.CREATE_ELEMENT]('div', {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      gap: '3px',
    },
  });

  buttons.forEach(btn => {
    if (btn instanceof HTMLElement) {
      btnsContainer.appendChild(btn);
    }
  });

  group.appendChild(btnsContainer);
  return group;
};

EnvTemplate[PRIVATE.CREATE_PRESET] = function (name, value, currentNamespace, onClick) {
  const isActive = EnvTemplate[PRIVATE.IS_ACTIVE_PRESET](value, currentNamespace);
  const style = STYLES[PRIVATE.STYLE_PRESET_BTN](isActive);

  const btn = EnvTemplate[PRIVATE.CREATE_ELEMENT]('button', {
    'data-preset': value || '',
    'data-active': isActive ? 'true' : 'false',
    style: style,
    textContent: name,
    type: 'button',
  });

  if (onClick && typeof onClick === 'function') {
    btn.addEventListener('click', () => onClick(value));
  }

  // Hover эффекты
  btn.addEventListener('mouseenter', () => {
    const active = btn.dataset.active === 'true';
    btn.style.background = active ? 'rgba(102,126,234,0.4)' : 'rgba(255,255,255,0.08)';
    btn.style.transform = 'translateY(-1px)';
  });

  btn.addEventListener('mouseleave', () => {
    const active = btn.dataset.active === 'true';
    btn.style.background = active ? 'rgba(102,126,234,0.3)' : 'rgba(255,255,255,0.03)';
    btn.style.transform = 'translateY(0)';
  });

  return btn;
};

// ============================================================
// 10.3 ★★★ ОСНОВНЫЕ МЕТОДЫ ШАБЛОНА ★★★
// ============================================================

EnvTemplate[PRIVATE.GROUPS] = function (currentNamespace, onPresetClick) {
  const container = EnvTemplate[PRIVATE.CREATE_ELEMENT]('div', {
    id: 'env-groups',
    style: STYLES[PRIVATE.STYLE_GROUPS],
  });

  const groups = Object.values(PRESET_GROUPS);

  groups.forEach(groupData => {
    const buttons = groupData.presets.map(preset => {
      return EnvTemplate[PRIVATE.CREATE_PRESET](
        preset.name,
        preset.value,
        currentNamespace,
        onPresetClick
      );
    });

    const group = EnvTemplate[PRIVATE.CREATE_GROUP](groupData.name, buttons);
    container.appendChild(group);
  });

  return container;
};

EnvTemplate[PRIVATE.ACTIONS] = function (onActionClick) {
  const container = EnvTemplate[PRIVATE.CREATE_ELEMENT]('div', {
    id: 'env-actions',
    style: {
      marginTop: '10px',
      paddingTop: '10px',
      borderTop: '1px solid rgba(255,255,255,0.05)',
      display: 'flex',
      gap: '4px',
      flexWrap: 'wrap',
    },
  });

  const actionEntries = [
    ACTIONS[PRIVATE.ACTION_ENABLE_ALL],
    ACTIONS[PRIVATE.ACTION_DISABLE_ALL],
    ACTIONS[PRIVATE.ACTION_ENABLE_FLOW],
    ACTIONS[PRIVATE.ACTION_ENABLE_MEMORY],
    ACTIONS[PRIVATE.ACTION_ENABLE_GENERATE],
    ACTIONS[PRIVATE.ACTION_ENABLE_API],
    ACTIONS[PRIVATE.ACTION_ENABLE_ERRORS],
    ACTIONS[PRIVATE.ACTION_ENABLE_ALL_EXCEPT_MEMORY],
    ACTIONS[PRIVATE.ACTION_ENABLE_BOOKMARKLET],
    ACTIONS[PRIVATE.ACTION_DISABLE_BOOKMARKLET],
    ACTIONS[PRIVATE.ACTION_SYNC],
    ACTIONS[PRIVATE.ACTION_EXPORT],
    ACTIONS[PRIVATE.ACTION_RESET],
    ACTIONS[PRIVATE.ACTION_HISTORY],
    ACTIONS[PRIVATE.ACTION_SHARED_MEMORY],
  ];

  actionEntries.forEach(action => {
    const btn = EnvTemplate[PRIVATE.CREATE_ELEMENT]('button', {
      'data-action': action.name.replace(/[^a-zA-Z]/g, '').toLowerCase(),
      style: STYLES[PRIVATE.STYLE_ACTION_BTN],
      textContent: action.name,
      title: action.description || '',
      type: 'button',
    });

    btn.addEventListener('click', () => {
      if (onActionClick && typeof onActionClick === 'function') {
        onActionClick(action);
      }
    });

    // Hover эффекты
    btn.addEventListener('mouseenter', () => {
      btn.style.background = 'rgba(255,255,255,0.08)';
      btn.style.transform = 'translateY(-1px)';
    });

    btn.addEventListener('mouseleave', () => {
      btn.style.background = 'rgba(255,255,255,0.03)';
      btn.style.transform = 'translateY(0)';
    });

    container.appendChild(btn);
  });

  return container;
};

EnvTemplate[PRIVATE.COMMANDS] = function () {
  const container = EnvTemplate[PRIVATE.CREATE_ELEMENT]('div', {
    id: 'env-commands',
    style: STYLES[PRIVATE.STYLE_COMMANDS],
  });

  const title = EnvTemplate[PRIVATE.CREATE_ELEMENT]('div', {
    style: {
      color: '#8899bb',
      fontWeight: 'bold',
      fontSize: '9px',
      marginBottom: '2px',
    },
    textContent: '📋 Команды:',
  });
  container.appendChild(title);

  const list = EnvTemplate[PRIVATE.CREATE_ELEMENT]('div', {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      gap: '2px 8px',
    },
  });

  COMMANDS.forEach(cmd => {
    const code = EnvTemplate[PRIVATE.CREATE_ELEMENT]('code', {
      style: `color: ${cmd.color};`,
      textContent: cmd.code,
    });

    const sep = EnvTemplate[PRIVATE.CREATE_ELEMENT]('span', {
      style: { color: '#445' },
      textContent: ' ',
    });

    const desc = EnvTemplate[PRIVATE.CREATE_ELEMENT]('span', {
      style: { color: '#445', fontSize: '8px' },
      textContent: cmd.description,
    });

    const wrapper = EnvTemplate[PRIVATE.CREATE_ELEMENT]('span', {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: '4px',
        fontSize: '9px',
      },
    });

    wrapper.appendChild(code);
    wrapper.appendChild(desc);
    list.appendChild(wrapper);
  });

  container.appendChild(list);
  return container;
};

EnvTemplate[PRIVATE.BODY] = function (currentNamespace, onPresetClick, onActionClick) {
  const body = EnvTemplate[PRIVATE.CREATE_ELEMENT]('div', {
    id: 'panel-body',
    style: STYLES[PRIVATE.STYLE_BODY],
  });

  // Группы пресетов
  const groups = EnvTemplate[PRIVATE.GROUPS](currentNamespace, onPresetClick);
  body.appendChild(groups);

  // Действия
  const actions = EnvTemplate[PRIVATE.ACTIONS](onActionClick);
  body.appendChild(actions);

  // Команды
  const commands = EnvTemplate[PRIVATE.COMMANDS]();
  body.appendChild(commands);

  return body;
};

EnvTemplate[PRIVATE.HEADER] = function (icon, title, currentNamespace) {
  const isActive = currentNamespace && currentNamespace !== 'off';
  const statusText = currentNamespace || 'off';
  const badgeStyle = STYLES[PRIVATE.STYLE_STATUS_BADGE](isActive);

  const header = EnvTemplate[PRIVATE.CREATE_ELEMENT]('div', {
    id: 'panel-header',
    style: STYLES[PRIVATE.STYLE_HEADER],
  });

  // Заголовок
  const titleSpan = EnvTemplate[PRIVATE.CREATE_ELEMENT]('span', {
    style: {
      fontWeight: 'bold',
      fontSize: '14px',
      display: 'flex',
      alignItems: 'center',
      gap: '8px',
    },
  });

  const iconSpan = EnvTemplate[PRIVATE.CREATE_ELEMENT]('span', {
    textContent: icon || '🔍',
  });
  titleSpan.appendChild(iconSpan);

  const nameSpan = EnvTemplate[PRIVATE.CREATE_ELEMENT]('span', {
    textContent: title || 'ENV Control',
  });
  titleSpan.appendChild(nameSpan);

  const badge = EnvTemplate[PRIVATE.CREATE_ELEMENT]('span', {
    id: 'panel-status-badge',
    style: badgeStyle,
    textContent: statusText,
  });
  titleSpan.appendChild(badge);

  header.appendChild(titleSpan);

  // Контролы
  const controls = EnvTemplate[PRIVATE.CREATE_ELEMENT]('div', {
    className: 'panel-controls',
    style: {
      display: 'flex',
      gap: '2px',
      flexShrink: 0,
    },
  });

  const buttons = [
    { id: 'panel-minimize-btn', text: '─', title: 'Свернуть' },
    { id: 'panel-maximize-btn', text: '□', title: 'Развернуть' },
    { id: 'panel-close-btn', text: '✕', title: 'Закрыть' },
  ];

  buttons.forEach(btnData => {
    const btn = EnvTemplate[PRIVATE.CREATE_ELEMENT]('button', {
      id: btnData.id,
      style: {
        background: 'none',
        border: 'none',
        color: '#8899bb',
        cursor: 'pointer',
        fontSize: btnData.text === '□' ? '14px' : '16px',
        padding: '0 4px',
        width: '28px',
        height: '28px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        borderRadius: '4px',
        transition: 'all 0.2s',
      },
      textContent: btnData.text,
      title: btnData.title,
      type: 'button',
    });

    controls.appendChild(btn);
  });

  header.appendChild(controls);

  return header;
};

EnvTemplate[PRIVATE.CONTAINER] = function (panelId, panelType, instanceId) {
  return EnvTemplate[PRIVATE.CREATE_ELEMENT]('div', {
    id: panelId,
    'data-panel-type': panelType,
    'data-instance-id': instanceId,
    className: 'panel-container',
    style: STYLES[PRIVATE.STYLE_CONTAINER],
  });
};

EnvTemplate[PRIVATE.RESIZE] = function () {
  return EnvTemplate[PRIVATE.CREATE_ELEMENT]('div', {
    id: 'panel-resize',
    style: STYLES[PRIVATE.STYLE_RESIZE],
  });
};

// ============================================================
// 10.4 ★★★ ПОЛНЫЙ ШАБЛОН ★★★
// ============================================================

EnvTemplate[PRIVATE.FULL_TEMPLATE] = function (
  panelId,
  panelType,
  instanceId,
  icon,
  title,
  currentNamespace,
  onPresetClick,
  onActionClick
) {
  // Контейнер
  const container = EnvTemplate[PRIVATE.CONTAINER](panelId, panelType, instanceId);

  // Шапка
  const header = EnvTemplate[PRIVATE.HEADER](icon, title, currentNamespace);
  container.appendChild(header);

  // Тело
  const body = EnvTemplate[PRIVATE.BODY](currentNamespace, onPresetClick, onActionClick);
  container.appendChild(body);

  // Ресайз
  const resize = EnvTemplate[PRIVATE.RESIZE]();
  container.appendChild(resize);

  return container;
};

// ============================================================
// 10.5 ★★★ ПУБЛИЧНЫЙ МЕТОД РЕНДЕРИНГА ★★★
// ============================================================

EnvTemplate[PRIVATE.RENDER_TEMPLATE] = function (
  panelId = 'env-control-panel',
  panelType = 'env',
  instanceId = null,
  options = {}
) {
  const loggerInstance = logger;

  loggerInstance.template(`📄 Рендеринг шаблона ENV: ${panelId}`);

  const currentNamespace = options.namespace || EnvTemplate[PRIVATE.GET_CURRENT_NAMESPACE]();
  const icon = options.icon || '🔍';
  const title = options.title || 'ENV Control';
  const onPresetClick = options.onPresetClick || null;
  const onActionClick = options.onActionClick || null;

  // Создаём шаблон
  const template = EnvTemplate[PRIVATE.FULL_TEMPLATE](
    panelId,
    panelType,
    instanceId || 'env-' + Date.now(),
    icon,
    title,
    currentNamespace,
    onPresetClick,
    onActionClick
  );

  // Кешируем
  const cacheKey = `${panelId}:${currentNamespace}`;
  EnvTemplate[PRIVATE.CACHE] = EnvTemplate[PRIVATE.CACHE] || new Map();
  EnvTemplate[PRIVATE.CACHE].set(cacheKey, {
    template,
    timestamp: Date.now(),
    namespace: currentNamespace,
  });

  // Обновляем метаданные
  EnvTemplate[PRIVATE.METADATA] = EnvTemplate[PRIVATE.METADATA] || {};
  EnvTemplate[PRIVATE.METADATA][PRIVATE.GENERATED_AT] = Date.now();
  EnvTemplate[PRIVATE.METADATA][PRIVATE.RENDER_COUNT] =
    (EnvTemplate[PRIVATE.METADATA][PRIVATE.RENDER_COUNT] || 0) + 1;

  loggerInstance.success(`✅ Шаблон ENV отрендерен (${cacheKey})`);

  return template;
};

// ============================================================
// 10.6 ★★★ ОБНОВЛЕНИЕ СТАТУСА ★★★
// ============================================================

EnvTemplate[PRIVATE.UPDATE_STATUS] = function (panel, currentNamespace) {
  if (!panel) return;

  const badge = panel.querySelector('#panel-status-badge');
  if (badge) {
    const isActive = currentNamespace && currentNamespace !== 'off';
    badge.textContent = currentNamespace || 'off';
    badge.style.background = isActive ? 'rgba(0,184,148,0.15)' : 'rgba(255,255,255,0.05)';
    badge.style.color = isActive ? '#00b894' : '#636e72';
    badge.style.borderColor = isActive ? 'rgba(0,184,148,0.2)' : 'rgba(255,255,255,0.05)';
  }

  // Обновляем активные пресеты
  const presetBtns = panel.querySelectorAll('[data-preset]');
  presetBtns.forEach(btn => {
    const preset = btn.dataset.preset;
    const isActive = EnvTemplate[PRIVATE.IS_ACTIVE_PRESET](preset, currentNamespace);
    btn.dataset.active = isActive ? 'true' : 'false';
    btn.style.background = isActive ? 'rgba(102,126,234,0.3)' : 'rgba(255,255,255,0.03)';
    btn.style.color = isActive ? '#fff' : '#8899bb';
    btn.style.borderColor = isActive ? '#667eea' : 'rgba(255,255,255,0.05)';
  });
};

// ============================================================
// 10.7 ★★★ ОЧИСТКА ★★★
// ============================================================

EnvTemplate[PRIVATE.CLEAR_CACHE] = function () {
  if (EnvTemplate[PRIVATE.CACHE]) {
    const size = EnvTemplate[PRIVATE.CACHE].size;
    EnvTemplate[PRIVATE.CACHE].clear();
    logger.debug(`🗑️ Кеш шаблонов очищен (${size} записей)`);
    return size;
  }
  return 0;
};

EnvTemplate[PRIVATE.CLEAR_HISTORY] = function () {
  logger.clearHistory();
  EnvTemplate[PRIVATE.METADATA] = {};
  logger.debug('🗑️ История очищена');
};

// ============================================================
// 11. ★★★ ПУБЛИЧНЫЙ API ★★★
// ============================================================

export function renderEnvTemplate(
  panelId = 'env-control-panel',
  panelType = 'env',
  instanceId = null,
  options = {}
) {
  return EnvTemplate[PRIVATE.RENDER_TEMPLATE](panelId, panelType, instanceId, options);
}

export function updateEnvStatus(panel, currentNamespace) {
  return EnvTemplate[PRIVATE.UPDATE_STATUS](panel, currentNamespace);
}

export function getEnvTemplateCache() {
  return EnvTemplate[PRIVATE.CACHE] || new Map();
}

export function clearEnvTemplateCache() {
  return EnvTemplate[PRIVATE.CLEAR_CACHE]();
}

export function clearEnvTemplateHistory() {
  return EnvTemplate[PRIVATE.CLEAR_HISTORY]();
}

export function getEnvTemplateMetadata() {
  return { ...EnvTemplate[PRIVATE.METADATA] };
}

export function getCurrentNamespace() {
  return EnvTemplate[PRIVATE.GET_CURRENT_NAMESPACE]();
}

export function isPresetActive(presetValue, currentNamespace) {
  return EnvTemplate[PRIVATE.IS_ACTIVE_PRESET](presetValue, currentNamespace);
}

// ============================================================
// 12. ★★★ ГЛОБАЛЬНАЯ РЕГИСТРАЦИЯ ★★★
// ============================================================

if (typeof window !== 'undefined') {
  window[PUBLIC.API] = {
    render: renderEnvTemplate,
    updateStatus: updateEnvStatus,
    getCache: getEnvTemplateCache,
    clearCache: clearEnvTemplateCache,
    clearHistory: clearEnvTemplateHistory,
    getMetadata: getEnvTemplateMetadata,
    getCurrentNamespace: getCurrentNamespace,
    isPresetActive: isPresetActive,
  };

  window[PUBLIC.CONFIG] = CONFIG;
  window[PUBLIC.RENDER] = renderEnvTemplate;
  window[PUBLIC.TEMPLATE] = EnvTemplate;
  window[PUBLIC.UTILS] = {
    escapeHtml: EnvTemplate[PRIVATE.ESCAPE_HTML],
    getCurrentNamespace: getCurrentNamespace,
    isPresetActive: isPresetActive,
  };
  window[PUBLIC.INSTANCE] = EnvTemplate;

  window.__envTemplate = {
    render: renderEnvTemplate,
    updateStatus: updateEnvStatus,
    getCache: getEnvTemplateCache,
    clearCache: clearEnvTemplateCache,
    clearHistory: clearEnvTemplateHistory,
    getMetadata: getEnvTemplateMetadata,
    getCurrentNamespace: getCurrentNamespace,
    isPresetActive: isPresetActive,
    getSymbols: () => ({
      PRIVATE: { ...PRIVATE },
      PUBLIC: { ...PUBLIC },
      CONFIG_SYMBOLS: { ...CONFIG_SYMBOLS },
      LOGGER_SYMBOLS: { ...LOGGER_SYMBOLS },
      VALIDATOR_SYMBOLS: { ...VALIDATOR_SYMBOLS },
    }),
    getPresetGroups: () => ({ ...PRESET_GROUPS }),
    getActions: () => ({ ...ACTIONS }),
    getCommands: () => [...COMMANDS],
  };

  // Баннер
  console.log('╔═══════════════════════════════════════════════════════════════════════════════╗');
  console.log('║              📦 ENV TEMPLATE (100% СИМВОЛЫ) v2.1.9                           ║');
  console.log('╠═══════════════════════════════════════════════════════════════════════════════╣');
  console.log('║  📋 Все логи выводятся в консоль с цветовой разметкой                       ║');
  console.log('║  🔑 Полная изоляция через приватные символы                                 ║');
  console.log('║  🔓 Публичные символы через Symbol.for                                      ║');
  console.log('║  📄 7 групп пресетов (Flow, Memory, Generate, API, Errors, All, Custom)    ║');
  console.log('║  🎯 15 быстрых действий для управления DEBUG                                ║');
  console.log('║  📋 8 команд для работы с ENV                                               ║');
  console.log('║  💾 Кеширование шаблонов                                                    ║');
  console.log('║  📊 Метаданные и статистика рендеринга                                     ║');
  console.log('╚═══════════════════════════════════════════════════════════════════════════════╝');

  console.log('📋 КОМАНДЫ ОТЛАДКИ (__envTemplate):');
  console.log('  __envTemplate.render(id, type, instanceId, options) - рендеринг шаблона');
  console.log('  __envTemplate.updateStatus(panel, ns)              - обновить статус');
  console.log('  __envTemplate.getCache()                           - получить кеш');
  console.log('  __envTemplate.clearCache()                         - очистить кеш');
  console.log('  __envTemplate.clearHistory()                       - очистить историю');
  console.log('  __envTemplate.getMetadata()                        - получить метаданные');
  console.log('  __envTemplate.getCurrentNamespace()                - получить текущий namespace');
  console.log(
    '  __envTemplate.isPresetActive(value, current)       - проверить активность пресета'
  );
  console.log('  __envTemplate.getPresetGroups()                    - получить группы пресетов');
  console.log('  __envTemplate.getActions()                         - получить действия');
  console.log('  __envTemplate.getCommands()                        - получить команды');
  console.log('  __envTemplate.getSymbols()                         - получить все символы');
  console.log('');

  console.log('📋 ПРИВАТНЫХ СИМВОЛОВ:', Object.keys(PRIVATE).length);
  console.log('📋 ПУБЛИЧНЫХ СИМВОЛОВ:', Object.keys(PUBLIC).length);
  console.log('📋 КОНФИГ СИМВОЛОВ:', Object.keys(CONFIG_SYMBOLS).length);
  console.log('📋 ЛОГГЕР СИМВОЛОВ:', Object.keys(LOGGER_SYMBOLS).length);
  console.log('📋 ВАЛИДАТОР СИМВОЛОВ:', Object.keys(VALIDATOR_SYMBOLS).length);
  console.log('═══════════════════════════════════════════════════════════════════════════════');
}

// ============================================================
// 13. ★★★ ЭКСПОРТЫ ★★★
// ============================================================

export {
  PRIVATE,
  PUBLIC,
  CONFIG_SYMBOLS,
  CONFIG,
  LOGGER_SYMBOLS,
  VALIDATOR_SYMBOLS,
  PRESET_GROUPS,
  ACTIONS,
  COMMANDS,
  EnvTemplate,
  renderEnvTemplate,
  updateEnvStatus,
  getEnvTemplateCache,
  clearEnvTemplateCache,
  clearEnvTemplateHistory,
  getEnvTemplateMetadata,
  getCurrentNamespace,
  isPresetActive,
  logger as EnvTemplateLogger,
};

// ============================================================
// 14. ★★★ ДЕФОЛТНЫЙ ЭКСПОРТ ★★★
// ============================================================

export default {
  render: renderEnvTemplate,
  updateStatus: updateEnvStatus,
  getCache: getEnvTemplateCache,
  clearCache: clearEnvTemplateCache,
  clearHistory: clearEnvTemplateHistory,
  getMetadata: getEnvTemplateMetadata,
  getCurrentNamespace: getCurrentNamespace,
  isPresetActive: isPresetActive,
  getPresetGroups: () => ({ ...PRESET_GROUPS }),
  getActions: () => ({ ...ACTIONS }),
  getCommands: () => [...COMMANDS],
  getSymbols: () => ({
    PRIVATE: { ...PRIVATE },
    PUBLIC: { ...PUBLIC },
    CONFIG_SYMBOLS: { ...CONFIG_SYMBOLS },
    LOGGER_SYMBOLS: { ...LOGGER_SYMBOLS },
    VALIDATOR_SYMBOLS: { ...VALIDATOR_SYMBOLS },
  }),
};
