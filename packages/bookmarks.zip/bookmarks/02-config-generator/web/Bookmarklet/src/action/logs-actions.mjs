// web/Bookmarklet/src/action/logs-actions.mjs
// 100% СИМВОЛЫ — полная изоляция и безопасность
// Действия для Logs панели
// Версия: 2.1.9

// ============================================================
// 1. ПРИВАТНЫЕ СИМВОЛЫ (100% изоляция)
// ============================================================

const PRIVATE = {
  // Основные символы действий
  ADD_LOG: Symbol('logs-actions.addLog'),
  GET_LOGS: Symbol('logs-actions.getLogs'),
  RENDER_LOGS: Symbol('logs-actions.renderLogs'),
  UPDATE_STATS: Symbol('logs-actions.updateStats'),
  CLEAR_LOGS: Symbol('logs-actions.clearLogs'),
  EXPORT_LOGS: Symbol('logs-actions.exportLogs'),
  TOGGLE_PAUSE: Symbol('logs-actions.togglePause'),
  TOGGLE_FOLLOW: Symbol('logs-actions.toggleFollow'),
  HOOK_CONSOLE: Symbol('logs-actions.hookConsole'),
  SETUP_HANDLERS: Symbol('logs-actions.setupHandlers'),
  GET_LEVEL_COLOR: Symbol('logs-actions.getLevelColor'),
  ESCAPE_HTML: Symbol('logs-actions.escapeHtml'),
  FORMAT_MESSAGE: Symbol('logs-actions.formatMessage'),

  // Символы состояния логов
  LOG_ENTRIES: Symbol('logs-actions.logEntries'),
  LOG_ID: Symbol('logs-actions.logId'),
  IS_PAUSED: Symbol('logs-actions.isPaused'),
  IS_FOLLOWING: Symbol('logs-actions.isFollowing'),
  IS_CONSOLE_HOOKED: Symbol('logs-actions.isConsoleHooked'),
  MAX_LOGS: Symbol('logs-actions.maxLogs'),
  LOG_LEVELS: Symbol('logs-actions.logLevels'),

  // Символы DOM
  CONSOLE_EL: Symbol('logs-actions.consoleEl'),
  FILTER_INPUT: Symbol('logs-actions.filterInput'),
  LEVEL_SELECT: Symbol('logs-actions.levelSelect'),
  PAUSE_BTN: Symbol('logs-actions.pauseBtn'),
  CLEAR_BTN: Symbol('logs-actions.clearBtn'),
  EXPORT_BTN: Symbol('logs-actions.exportBtn'),
  FOLLOW_BTN: Symbol('logs-actions.followBtn'),
  TOTAL_EL: Symbol('logs-actions.totalEl'),
  ERRORS_EL: Symbol('logs-actions.errorsEl'),
  WARNINGS_EL: Symbol('logs-actions.warningsEl'),
  STATUS_EL: Symbol('logs-actions.statusEl'),

  // Символы оригинальных методов console
  ORIGINAL_LOG: Symbol('logs-actions.originalLog'),
  ORIGINAL_DEBUG: Symbol('logs-actions.originalDebug'),
  ORIGINAL_INFO: Symbol('logs-actions.originalInfo'),
  ORIGINAL_WARN: Symbol('logs-actions.originalWarn'),
  ORIGINAL_ERROR: Symbol('logs-actions.originalError'),

  // Символы утилит
  LOGGER: Symbol('logs-actions.logger'),
  CACHE: Symbol('logs-actions.cache'),
  TIMERS: Symbol('logs-actions.timers'),
  RAF_ID: Symbol('logs-actions.rafId'),
  EVENT_HANDLERS: Symbol('logs-actions.eventHandlers'),

  // Символы событий
  ON_LOG_ADDED: Symbol('logs-actions.onLogAdded'),
  ON_LOGS_CLEARED: Symbol('logs-actions.onLogsCleared'),
  ON_PAUSE_TOGGLED: Symbol('logs-actions.onPauseToggled'),
  ON_FOLLOW_TOGGLED: Symbol('logs-actions.onFollowToggled'),
  ON_CONSOLE_HOOKED: Symbol('logs-actions.onConsoleHooked'),

  // Символы фильтрации
  FILTER_PATTERN: Symbol('logs-actions.filterPattern'),
  LEVEL_FILTER: Symbol('logs-actions.levelFilter'),
  FILTERED_LOGS: Symbol('logs-actions.filteredLogs'),
  CURRENT_FILTER: Symbol('logs-actions.currentFilter'),
  CURRENT_LEVEL: Symbol('logs-actions.currentLevel'),

  // Символы экспорта
  EXPORT_FORMAT: Symbol('logs-actions.exportFormat'),
  EXPORT_FILENAME: Symbol('logs-actions.exportFilename'),
  EXPORT_LIMIT: Symbol('logs-actions.exportLimit'),

  // Символы статистики
  STATS: Symbol('logs-actions.stats'),
  STATS_TOTAL: Symbol('logs-actions.statsTotal'),
  STATS_ERRORS: Symbol('logs-actions.statsErrors'),
  STATS_WARNINGS: Symbol('logs-actions.statsWarnings'),
  STATS_TIMESTAMP: Symbol('logs-actions.statsTimestamp'),

  // Символы сохранения
  SAVE_INTERVAL: Symbol('logs-actions.saveInterval'),
  SAVE_KEY: Symbol('logs-actions.saveKey'),
  LAST_SAVE: Symbol('logs-actions.lastSave'),
};

// ============================================================
// 2. ПУБЛИЧНЫЕ СИМВОЛЫ (доступны через Symbol.for)
// ============================================================

const PUBLIC = {
  API: Symbol.for('logs-actions.api'),
  STATE: Symbol.for('logs-actions.state'),
  CONFIG: Symbol.for('logs-actions.config'),
  LOGGER: Symbol.for('logs-actions.logger'),
  EVENTS: Symbol.for('logs-actions.events'),
  INSTANCE: Symbol.for('logs-actions.instance'),
  STATS: Symbol.for('logs-actions.stats'),
};

// ============================================================
// 3. ЛОГГЕР (100% СИМВОЛЫ)
// ============================================================

const LOGGER_SYMBOLS = {
  HISTORY: Symbol('logger.history'),
  MAX_HISTORY: Symbol('logger.maxHistory'),
  DEBUG: Symbol('logger.debug'),
  INSTANCE_ID: Symbol('logger.instanceId'),
  LEVEL: Symbol('logger.level'),
  TIMESTAMP: Symbol('logger.timestamp'),
  COLORS: Symbol('logger.colors'),
  OUTPUT: Symbol('logger.output'),
};

function createLogsLogger(debug = true, instanceId = 'LogsActions') {
  const loggerState = {
    [LOGGER_SYMBOLS.HISTORY]: [],
    [LOGGER_SYMBOLS.MAX_HISTORY]: 200,
    [LOGGER_SYMBOLS.DEBUG]: debug,
    [LOGGER_SYMBOLS.INSTANCE_ID]: instanceId,
    [LOGGER_SYMBOLS.LEVEL]: 'info',
    [LOGGER_SYMBOLS.TIMESTAMP]: true,
    [LOGGER_SYMBOLS.COLORS]: true,
    [LOGGER_SYMBOLS.OUTPUT]: console,
  };

  const logMethod = function (level, message, data = null) {
    if (!this[LOGGER_SYMBOLS.DEBUG] && level !== 'error') {
      return;
    }

    const timestamp = this[LOGGER_SYMBOLS.TIMESTAMP]
      ? `[${new Date().toISOString().slice(11, 23)}]`
      : '';
    const prefix = `${timestamp} [${this[LOGGER_SYMBOLS.INSTANCE_ID]}]`;
    const output = this[LOGGER_SYMBOLS.OUTPUT];

    this[LOGGER_SYMBOLS.HISTORY].push({ timestamp, level, message, data });
    if (this[LOGGER_SYMBOLS.HISTORY].length > this[LOGGER_SYMBOLS.MAX_HISTORY]) {
      this[LOGGER_SYMBOLS.HISTORY].shift();
    }

    const styles = this[LOGGER_SYMBOLS.COLORS]
      ? {
          error: 'color: #ff6b6b; font-weight: bold;',
          warn: 'color: #fdcb6e; font-weight: bold;',
          info: 'color: #74b9ff; font-weight: bold;',
          debug: 'color: #a29bfe;',
          success: 'color: #00b894; font-weight: bold;',
        }
      : {};

    const style = styles[level] || styles.info;

    if (data !== null && data !== undefined) {
      if (typeof data === 'object') {
        output.log(`%c${prefix} ${message}`, style, data);
      } else {
        output.log(`%c${prefix} ${message}`, style, data);
      }
    } else {
      output.log(`%c${prefix} ${message}`, style);
    }
  };

  const boundLog = logMethod.bind(loggerState);

  const logger = {
    error: (msg, d) => boundLog('error', `❌ ${msg}`, d),
    warn: (msg, d) => boundLog('warn', `⚠️ ${msg}`, d),
    info: (msg, d) => boundLog('info', `ℹ️ ${msg}`, d),
    debug: (msg, d) => boundLog('debug', `🔍 ${msg}`, d),
    success: (msg, d) => boundLog('info', `✅ ${msg}`, d),

    header: title => {
      const output = loggerState[LOGGER_SYMBOLS.OUTPUT];
      output.log('%c' + '═'.repeat(70), 'color: #636e72;');
      output.log(
        '%c  📦 ' + title,
        'background: #1a1a2e; color: #fff; padding: 4px 12px; border-radius: 4px; font-weight: bold;'
      );
      output.log('%c' + '═'.repeat(70), 'color: #636e72;');
    },

    separator: () => {
      const output = loggerState[LOGGER_SYMBOLS.OUTPUT];
      output.log('%c' + '─'.repeat(70), 'color: #636e72;');
    },

    getHistory: () => [...loggerState[LOGGER_SYMBOLS.HISTORY]],
    clearHistory: () => {
      loggerState[LOGGER_SYMBOLS.HISTORY] = [];
      return logger;
    },
    setDebug: enabled => {
      loggerState[LOGGER_SYMBOLS.DEBUG] = enabled;
      return logger;
    },
    setLevel: level => {
      loggerState[LOGGER_SYMBOLS.LEVEL] = level;
      return logger;
    },
    getLevel: () => loggerState[LOGGER_SYMBOLS.LEVEL],
    setOutput: output => {
      loggerState[LOGGER_SYMBOLS.OUTPUT] = output;
      return logger;
    },
  };

  return logger;
}

// ============================================================
// 4. ВАЛИДАТОР (100% СИМВОЛЫ)
// ============================================================

const VALIDATOR_SYMBOLS = {
  IS_VALID_LOG: Symbol('validator.isValidLog'),
  IS_VALID_LEVEL: Symbol('validator.isValidLevel'),
  IS_VALID_MESSAGE: Symbol('validator.isValidMessage'),
  IS_VALID_ELEMENT: Symbol('validator.isValidElement'),
  IS_VALID_FILTER: Symbol('validator.isValidFilter'),
  SANITIZE: Symbol('validator.sanitize'),
  CHECK_DOM: Symbol('validator.checkDom'),
};

const VALIDATOR = {
  [VALIDATOR_SYMBOLS.IS_VALID_LOG]: entry => {
    return (
      entry &&
      typeof entry === 'object' &&
      typeof entry.level === 'string' &&
      typeof entry.message === 'string' &&
      entry.timestamp instanceof Date
    );
  },

  [VALIDATOR_SYMBOLS.IS_VALID_LEVEL]: level => {
    const levels = ['debug', 'info', 'warn', 'error', 'success'];
    return typeof level === 'string' && levels.includes(level);
  },

  [VALIDATOR_SYMBOLS.IS_VALID_MESSAGE]: message => {
    return typeof message === 'string' && message.length > 0;
  },

  [VALIDATOR_SYMBOLS.IS_VALID_ELEMENT]: el => {
    return el && typeof el === 'object' && el instanceof HTMLElement;
  },

  [VALIDATOR_SYMBOLS.IS_VALID_FILTER]: filter => {
    return filter === null || filter === undefined || typeof filter === 'string';
  },

  [VALIDATOR_SYMBOLS.SANITIZE]: value => {
    if (value === null || value === undefined) return null;
    if (typeof value === 'string') {
      return value.replace(/[<>]/g, '').trim();
    }
    if (typeof value === 'object') {
      try {
        return JSON.parse(JSON.stringify(value));
      } catch {
        return null;
      }
    }
    return value;
  },

  [VALIDATOR_SYMBOLS.CHECK_DOM]: el => {
    if (!el) return false;
    return document.body.contains(el);
  },
};

// ============================================================
// 5. КОНФИГУРАЦИЯ (100% СИМВОЛЫ)
// ============================================================

const CONFIG_SYMBOLS = {
  MAX_LOGS: Symbol('config.maxLogs'),
  MAX_HISTORY: Symbol('config.maxHistory'),
  SAVE_INTERVAL: Symbol('config.saveInterval'),
  SAVE_KEY: Symbol('config.saveKey'),
  EXPORT_LIMIT: Symbol('config.exportLimit'),
  EXPORT_FORMAT: Symbol('config.exportFormat'),
  LEVELS: Symbol('config.levels'),
  LEVEL_COLORS: Symbol('config.levelColors'),
  LEVEL_LABELS: Symbol('config.levelLabels'),
};

const CONFIG = {
  [CONFIG_SYMBOLS.MAX_LOGS]: 1000,
  [CONFIG_SYMBOLS.MAX_HISTORY]: 500,
  [CONFIG_SYMBOLS.SAVE_INTERVAL]: 30000,
  [CONFIG_SYMBOLS.SAVE_KEY]: 'logs-actions-data',
  [CONFIG_SYMBOLS.EXPORT_LIMIT]: 10000,
  [CONFIG_SYMBOLS.EXPORT_FORMAT]: 'json',
  [CONFIG_SYMBOLS.LEVELS]: ['debug', 'info', 'warn', 'error', 'success'],
  [CONFIG_SYMBOLS.LEVEL_COLORS]: {
    debug: '#667eea',
    info: '#74b9ff',
    warn: '#fdcb6e',
    error: '#ff6b6b',
    success: '#00b894',
  },
  [CONFIG_SYMBOLS.LEVEL_LABELS]: {
    debug: 'DEBUG',
    info: 'INFO',
    warn: 'WARN',
    error: 'ERROR',
    success: 'SUCCESS',
  },
};

// ============================================================
// 6. ОСНОВНОЙ ОБЪЕКТ ДЕЙСТВИЙ (100% СИМВОЛЫ)
// ============================================================

const LogsActions = {};

// ============================================================
// 6.1 ★★★ ПРИВАТНОЕ СОСТОЯНИЕ ★★★
// ============================================================

const logsState = {
  [PRIVATE.LOG_ENTRIES]: [],
  [PRIVATE.LOG_ID]: 0,
  [PRIVATE.IS_PAUSED]: false,
  [PRIVATE.IS_FOLLOWING]: true,
  [PRIVATE.IS_CONSOLE_HOOKED]: false,
  [PRIVATE.MAX_LOGS]: CONFIG[CONFIG_SYMBOLS.MAX_LOGS],
  [PRIVATE.LOG_LEVELS]: CONFIG[CONFIG_SYMBOLS.LEVELS],
  [PRIVATE.LOGGER]: createLogsLogger(true, 'LogsActions'),
  [PRIVATE.CACHE]: new Map(),
  [PRIVATE.TIMERS]: new Map(),
  [PRIVATE.RAF_ID]: null,
  [PRIVATE.EVENT_HANDLERS]: new Map(),
  [PRIVATE.STATS]: {
    [PRIVATE.STATS_TOTAL]: 0,
    [PRIVATE.STATS_ERRORS]: 0,
    [PRIVATE.STATS_WARNINGS]: 0,
    [PRIVATE.STATS_TIMESTAMP]: Date.now(),
  },
  [PRIVATE.FILTER_PATTERN]: '',
  [PRIVATE.LEVEL_FILTER]: 'all',
  [PRIVATE.CURRENT_FILTER]: '',
  [PRIVATE.CURRENT_LEVEL]: 'all',
  [PRIVATE.EXPORT_FORMAT]: CONFIG[CONFIG_SYMBOLS.EXPORT_FORMAT],
  [PRIVATE.EXPORT_FILENAME]: `logs-${new Date().toISOString().slice(0, 10)}`,
  [PRIVATE.EXPORT_LIMIT]: CONFIG[CONFIG_SYMBOLS.EXPORT_LIMIT],
  [PRIVATE.SAVE_KEY]: CONFIG[CONFIG_SYMBOLS.SAVE_KEY],
  [PRIVATE.LAST_SAVE]: Date.now(),
  [PRIVATE.SAVE_INTERVAL]: CONFIG[CONFIG_SYMBOLS.SAVE_INTERVAL],
};

const logger = logsState[PRIVATE.LOGGER];

// ============================================================
// 6.2 ★★★ ОСНОВНЫЕ ДЕЙСТВИЯ ★★★
// ============================================================

/**
 * Добавление записи лога
 */
LogsActions[PRIVATE.ADD_LOG] = function (level, ...args) {
  const isPaused = logsState[PRIVATE.IS_PAUSED];
  const loggerInstance = logger;

  if (isPaused) {
    loggerInstance.debug('⏸️ Логи на паузе, запись пропущена');
    return null;
  }

  // Валидация уровня
  if (!VALIDATOR[VALIDATOR_SYMBOLS.IS_VALID_LEVEL](level)) {
    level = 'info';
    loggerInstance.debug(`⚠️ Некорректный уровень, заменён на "${level}"`);
  }

  // Форматирование сообщения
  let message = LogsActions[PRIVATE.FORMAT_MESSAGE](args);

  // Валидация сообщения
  if (!VALIDATOR[VALIDATOR_SYMBOLS.IS_VALID_MESSAGE](message)) {
    message = '(empty)';
  }

  // Создание записи
  const entry = {
    id: logsState[PRIVATE.LOG_ID]++,
    timestamp: new Date(),
    level: level,
    message: message,
    formatted: LogsActions[PRIVATE.ESCAPE_HTML](message),
    color: LogsActions[PRIVATE.GET_LEVEL_COLOR](level),
  };

  // Добавление в хранилище
  const entries = logsState[PRIVATE.LOG_ENTRIES];
  entries.push(entry);

  // Ограничение количества
  const maxLogs = logsState[PRIVATE.MAX_LOGS];
  if (entries.length > maxLogs) {
    const removed = entries.splice(0, entries.length - maxLogs);
    loggerInstance.debug(`🧹 Удалено ${removed.length} старых записей (лимит ${maxLogs})`);
  }

  // Обновление статистики
  LogsActions[PRIVATE.UPDATE_STATS]();

  // Рендеринг
  LogsActions[PRIVATE.RENDER_LOGS]();

  // Авто-слежение
  if (logsState[PRIVATE.IS_FOLLOWING]) {
    const consoleEl = logsState[PRIVATE.CONSOLE_EL];
    if (consoleEl && VALIDATOR[VALIDATOR_SYMBOLS.IS_VALID_ELEMENT](consoleEl)) {
      consoleEl.scrollTop = consoleEl.scrollHeight;
    }
  }

  // Сохранение
  LogsActions[PRIVATE.SAVE_STATE]();

  // Событие
  const handlers = logsState[PRIVATE.EVENT_HANDLERS];
  if (handlers.has(PRIVATE.ON_LOG_ADDED)) {
    const list = handlers.get(PRIVATE.ON_LOG_ADDED);
    for (const callback of list) {
      try {
        callback(entry);
      } catch (e) {
        loggerInstance.error('❌ Ошибка в обработчике ON_LOG_ADDED:', e.message);
      }
    }
  }

  return entry;
};

/**
 * Форматирование сообщения из аргументов
 */
LogsActions[PRIVATE.FORMAT_MESSAGE] = function (args) {
  if (!args || args.length === 0) return '';

  let message = '';
  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    if (arg === null) {
      message += 'null';
    } else if (arg === undefined) {
      message += 'undefined';
    } else if (typeof arg === 'object') {
      try {
        message += JSON.stringify(arg);
      } catch {
        message += '[Object]';
      }
    } else if (typeof arg === 'function') {
      message += `[Function: ${arg.name || 'anonymous'}]`;
    } else {
      message += String(arg);
    }
    if (i < args.length - 1) {
      message += ' ';
    }
  }

  return message;
};

/**
 * Получение логов с фильтрацией
 */
LogsActions[PRIVATE.GET_LOGS] = function (filter = null, levelFilter = null) {
  const entries = logsState[PRIVATE.LOG_ENTRIES];
  let filtered = [...entries];

  // Фильтр по тексту
  if (filter && typeof filter === 'string' && filter.trim()) {
    const pattern = filter.toLowerCase().trim();
    filtered = filtered.filter(entry => {
      return entry.message.toLowerCase().includes(pattern);
    });
    logsState[PRIVATE.CURRENT_FILTER] = pattern;
  } else {
    logsState[PRIVATE.CURRENT_FILTER] = '';
  }

  // Фильтр по уровню
  if (levelFilter && levelFilter !== 'all') {
    filtered = filtered.filter(entry => entry.level === levelFilter);
    logsState[PRIVATE.CURRENT_LEVEL] = levelFilter;
  } else {
    logsState[PRIVATE.CURRENT_LEVEL] = 'all';
  }

  return filtered;
};

/**
 * Рендеринг логов в консоль
 */
LogsActions[PRIVATE.RENDER_LOGS] = function () {
  const consoleEl = logsState[PRIVATE.CONSOLE_EL];
  const loggerInstance = logger;

  if (!consoleEl || !VALIDATOR[VALIDATOR_SYMBOLS.IS_VALID_ELEMENT](consoleEl)) {
    loggerInstance.debug('⚠️ Консоль логов не найдена');
    return;
  }

  const filter = logsState[PRIVATE.CURRENT_FILTER] || '';
  const levelFilter = logsState[PRIVATE.CURRENT_LEVEL] || 'all';

  const filtered = LogsActions[PRIVATE.GET_LOGS](filter, levelFilter);

  if (filtered.length === 0) {
    consoleEl.innerHTML = `
      <div class="logs-empty" style="
        color: #8899bb;
        text-align: center;
        padding: 20px;
        font-style: italic;
      ">
        📭 Нет логов${filter ? ' по вашему фильтру' : ''}
      </div>
    `;
    return;
  }

  const isFollowing = logsState[PRIVATE.IS_FOLLOWING];
  const entries = isFollowing ? filtered : filtered.slice(-100);

  let html = '';
  for (const entry of entries) {
    const time = entry.timestamp.toLocaleTimeString();
    const levelLabel =
      CONFIG[CONFIG_SYMBOLS.LEVEL_LABELS][entry.level] || entry.level.toUpperCase();
    const color = entry.color || LogsActions[PRIVATE.GET_LEVEL_COLOR](entry.level);

    html += `
      <div class="logs-entry" style="
        padding: 2px 0;
        border-bottom: 1px solid rgba(255,255,255,0.03);
        display: flex;
        gap: 6px;
        align-items: flex-start;
      ">
        <span class="logs-time" style="
          color: #8899bb;
          font-size: 9px;
          min-width: 60px;
          flex-shrink: 0;
        ">${time}</span>
        <span class="logs-level ${entry.level}" style="
          font-size: 9px;
          padding: 0 5px;
          border-radius: 3px;
          font-weight: 600;
          flex-shrink: 0;
          color: ${color};
        ">${levelLabel}</span>
        <span class="logs-message" style="
          color: #dfe6e9;
          word-break: break-all;
          flex: 1;
        ">${entry.formatted || LogsActions[PRIVATE.ESCAPE_HTML](entry.message)}</span>
      </div>
    `;
  }

  consoleEl.innerHTML = html;

  // Прокрутка вниз если следим
  if (isFollowing) {
    consoleEl.scrollTop = consoleEl.scrollHeight;
  }
};

/**
 * Обновление статистики
 */
LogsActions[PRIVATE.UPDATE_STATS] = function () {
  const entries = logsState[PRIVATE.LOG_ENTRIES];
  const total = entries.length;
  const errors = entries.filter(e => e.level === 'error').length;
  const warnings = entries.filter(e => e.level === 'warn').length;

  const stats = logsState[PRIVATE.STATS];
  stats[PRIVATE.STATS_TOTAL] = total;
  stats[PRIVATE.STATS_ERRORS] = errors;
  stats[PRIVATE.STATS_WARNINGS] = warnings;
  stats[PRIVATE.STATS_TIMESTAMP] = Date.now();

  // Обновляем DOM
  const totalEl = logsState[PRIVATE.TOTAL_EL];
  const errorsEl = logsState[PRIVATE.ERRORS_EL];
  const warningsEl = logsState[PRIVATE.WARNINGS_EL];
  const statusEl = logsState[PRIVATE.STATUS_EL];

  if (totalEl) totalEl.textContent = total;
  if (errorsEl) errorsEl.textContent = errors;
  if (warningsEl) warningsEl.textContent = warnings;

  if (statusEl) {
    const isPaused = logsState[PRIVATE.IS_PAUSED];
    statusEl.textContent = isPaused ? '⏸️ Пауза' : '▶️ Активен';
    statusEl.style.color = isPaused ? '#fdcb6e' : '#00b894';
  }

  // Событие
  const handlers = logsState[PRIVATE.EVENT_HANDLERS];
  if (handlers.has('onStatsUpdated')) {
    const list = handlers.get('onStatsUpdated');
    for (const callback of list) {
      try {
        callback({ total, errors, warnings });
      } catch (e) {
        logger.error('❌ Ошибка в обработчике onStatsUpdated:', e.message);
      }
    }
  }
};

/**
 * Очистка логов
 */
LogsActions[PRIVATE.CLEAR_LOGS] = function () {
  const loggerInstance = logger;
  const count = logsState[PRIVATE.LOG_ENTRIES].length;

  logsState[PRIVATE.LOG_ENTRIES] = [];
  logsState[PRIVATE.LOG_ID] = 0;

  LogsActions[PRIVATE.RENDER_LOGS]();
  LogsActions[PRIVATE.UPDATE_STATS]();

  // Очищаем кеш
  logsState[PRIVATE.CACHE].clear();

  // Сохраняем состояние
  LogsActions[PRIVATE.SAVE_STATE]();

  // Событие
  const handlers = logsState[PRIVATE.EVENT_HANDLERS];
  if (handlers.has(PRIVATE.ON_LOGS_CLEARED)) {
    const list = handlers.get(PRIVATE.ON_LOGS_CLEARED);
    for (const callback of list) {
      try {
        callback({ count });
      } catch (e) {
        loggerInstance.error('❌ Ошибка в обработчике ON_LOGS_CLEARED:', e.message);
      }
    }
  }

  loggerInstance.success(`🧹 Очищено ${count} записей логов`);
  return count;
};

/**
 * Экспорт логов
 */
LogsActions[PRIVATE.EXPORT_LOGS] = function (format = null, filename = null) {
  const loggerInstance = logger;
  const entries = logsState[PRIVATE.LOG_ENTRIES];
  const limit = logsState[PRIVATE.EXPORT_LIMIT];

  if (entries.length === 0) {
    loggerInstance.warn('⚠️ Нет логов для экспорта');
    return false;
  }

  const exportData = entries.slice(-limit);
  const exportFormat = format || logsState[PRIVATE.EXPORT_FORMAT];
  const exportFilename = filename || logsState[PRIVATE.EXPORT_FILENAME];

  let data, mimeType, extension;

  switch (exportFormat) {
    case 'json':
      data = JSON.stringify(exportData, null, 2);
      mimeType = 'application/json';
      extension = 'json';
      break;

    case 'csv':
      const headers = ['timestamp', 'level', 'message'];
      const rows = exportData.map(e => [
        e.timestamp.toISOString(),
        e.level,
        `"${e.message.replace(/"/g, '""')}"`,
      ]);
      data = [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
      mimeType = 'text/csv';
      extension = 'csv';
      break;

    case 'txt':
      data = exportData
        .map(e => `[${e.timestamp.toISOString()}] [${e.level.toUpperCase()}] ${e.message}`)
        .join('\n');
      mimeType = 'text/plain';
      extension = 'txt';
      break;

    default:
      data = JSON.stringify(exportData, null, 2);
      mimeType = 'application/json';
      extension = 'json';
  }

  const blob = new Blob([data], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `${exportFilename}.${extension}`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);

  loggerInstance.success(
    `📤 Экспортировано ${exportData.length} записей в ${exportFilename}.${extension}`
  );
  return true;
};

/**
 * Переключение паузы
 */
LogsActions[PRIVATE.TOGGLE_PAUSE] = function () {
  const oldState = logsState[PRIVATE.IS_PAUSED];
  logsState[PRIVATE.IS_PAUSED] = !oldState;

  const btn = logsState[PRIVATE.PAUSE_BTN];
  if (btn && VALIDATOR[VALIDATOR_SYMBOLS.IS_VALID_ELEMENT](btn)) {
    btn.textContent = logsState[PRIVATE.IS_PAUSED] ? '▶️ Возобновить' : '⏸️ Пауза';
  }

  LogsActions[PRIVATE.UPDATE_STATS]();

  // Событие
  const handlers = logsState[PRIVATE.EVENT_HANDLERS];
  if (handlers.has(PRIVATE.ON_PAUSE_TOGGLED)) {
    const list = handlers.get(PRIVATE.ON_PAUSE_TOGGLED);
    for (const callback of list) {
      try {
        callback({ paused: logsState[PRIVATE.IS_PAUSED], oldState });
      } catch (e) {
        logger.error('❌ Ошибка в обработчике ON_PAUSE_TOGGLED:', e.message);
      }
    }
  }

  logger.debug(`⏸️ Пауза: ${logsState[PRIVATE.IS_PAUSED] ? 'включена' : 'выключена'}`);
  return logsState[PRIVATE.IS_PAUSED];
};

/**
 * Переключение слежения
 */
LogsActions[PRIVATE.TOGGLE_FOLLOW] = function () {
  const oldState = logsState[PRIVATE.IS_FOLLOWING];
  logsState[PRIVATE.IS_FOLLOWING] = !oldState;

  const btn = logsState[PRIVATE.FOLLOW_BTN];
  if (btn && VALIDATOR[VALIDATOR_SYMBOLS.IS_VALID_ELEMENT](btn)) {
    btn.textContent = logsState[PRIVATE.IS_FOLLOWING] ? '▶️ Следить' : '⏹️ Не следить';
    btn.style.borderColor = logsState[PRIVATE.IS_FOLLOWING]
      ? 'rgba(0,184,148,0.3)'
      : 'rgba(255,255,255,0.1)';
    btn.style.background = logsState[PRIVATE.IS_FOLLOWING]
      ? 'rgba(0,184,148,0.1)'
      : 'rgba(255,255,255,0.05)';
    btn.style.color = logsState[PRIVATE.IS_FOLLOWING] ? '#00b894' : '#8899bb';
  }

  // Прокрутка вниз если включено
  if (logsState[PRIVATE.IS_FOLLOWING]) {
    const consoleEl = logsState[PRIVATE.CONSOLE_EL];
    if (consoleEl && VALIDATOR[VALIDATOR_SYMBOLS.IS_VALID_ELEMENT](consoleEl)) {
      consoleEl.scrollTop = consoleEl.scrollHeight;
    }
  }

  // Событие
  const handlers = logsState[PRIVATE.EVENT_HANDLERS];
  if (handlers.has(PRIVATE.ON_FOLLOW_TOGGLED)) {
    const list = handlers.get(PRIVATE.ON_FOLLOW_TOGGLED);
    for (const callback of list) {
      try {
        callback({ following: logsState[PRIVATE.IS_FOLLOWING], oldState });
      } catch (e) {
        logger.error('❌ Ошибка в обработчике ON_FOLLOW_TOGGLED:', e.message);
      }
    }
  }

  logger.debug(`📌 Слежение: ${logsState[PRIVATE.IS_FOLLOWING] ? 'включено' : 'выключено'}`);
  return logsState[PRIVATE.IS_FOLLOWING];
};

// ============================================================
// 6.3 ★★★ ВСПОМОГАТЕЛЬНЫЕ МЕТОДЫ ★★★
// ============================================================

/**
 * Получение цвета для уровня
 */
LogsActions[PRIVATE.GET_LEVEL_COLOR] = function (level) {
  const colors = CONFIG[CONFIG_SYMBOLS.LEVEL_COLORS];
  return colors[level] || '#8899bb';
};

/**
 * Экранирование HTML
 */
LogsActions[PRIVATE.ESCAPE_HTML] = function (text) {
  if (!text) return '';
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
};

/**
 * Перехват console
 */
LogsActions[PRIVATE.HOOK_CONSOLE] = function () {
  const loggerInstance = logger;

  if (logsState[PRIVATE.IS_CONSOLE_HOOKED]) {
    loggerInstance.debug('ℹ️ Перехват console уже установлен');
    return;
  }

  // Сохраняем оригинальные методы
  const originalLog = console.log;
  const originalDebug = console.debug;
  const originalInfo = console.info;
  const originalWarn = console.warn;
  const originalError = console.error;

  logsState[PRIVATE.ORIGINAL_LOG] = originalLog;
  logsState[PRIVATE.ORIGINAL_DEBUG] = originalDebug;
  logsState[PRIVATE.ORIGINAL_INFO] = originalInfo;
  logsState[PRIVATE.ORIGINAL_WARN] = originalWarn;
  logsState[PRIVATE.ORIGINAL_ERROR] = originalError;

  // Переопределяем методы
  console.log = function (...args) {
    originalLog.apply(console, args);
    LogsActions[PRIVATE.ADD_LOG]('info', ...args);
  };

  console.debug = function (...args) {
    originalDebug.apply(console, args);
    LogsActions[PRIVATE.ADD_LOG]('debug', ...args);
  };

  console.info = function (...args) {
    originalInfo.apply(console, args);
    LogsActions[PRIVATE.ADD_LOG]('info', ...args);
  };

  console.warn = function (...args) {
    originalWarn.apply(console, args);
    LogsActions[PRIVATE.ADD_LOG]('warn', ...args);
  };

  console.error = function (...args) {
    originalError.apply(console, args);
    LogsActions[PRIVATE.ADD_LOG]('error', ...args);
  };

  logsState[PRIVATE.IS_CONSOLE_HOOKED] = true;

  // Событие
  const handlers = logsState[PRIVATE.EVENT_HANDLERS];
  if (handlers.has(PRIVATE.ON_CONSOLE_HOOKED)) {
    const list = handlers.get(PRIVATE.ON_CONSOLE_HOOKED);
    for (const callback of list) {
      try {
        callback({ hooked: true });
      } catch (e) {
        loggerInstance.error('❌ Ошибка в обработчике ON_CONSOLE_HOOKED:', e.message);
      }
    }
  }

  loggerInstance.success('✅ Перехват console установлен');
};

/**
 * Восстановление оригинальных методов console
 */
LogsActions[PRIVATE.RESTORE_CONSOLE] = function () {
  if (!logsState[PRIVATE.IS_CONSOLE_HOOKED]) {
    return;
  }

  if (logsState[PRIVATE.ORIGINAL_LOG]) {
    console.log = logsState[PRIVATE.ORIGINAL_LOG];
  }
  if (logsState[PRIVATE.ORIGINAL_DEBUG]) {
    console.debug = logsState[PRIVATE.ORIGINAL_DEBUG];
  }
  if (logsState[PRIVATE.ORIGINAL_INFO]) {
    console.info = logsState[PRIVATE.ORIGINAL_INFO];
  }
  if (logsState[PRIVATE.ORIGINAL_WARN]) {
    console.warn = logsState[PRIVATE.ORIGINAL_WARN];
  }
  if (logsState[PRIVATE.ORIGINAL_ERROR]) {
    console.error = logsState[PRIVATE.ORIGINAL_ERROR];
  }

  logsState[PRIVATE.IS_CONSOLE_HOOKED] = false;
  logger.info('🔌 Перехват console восстановлен');
};

// ============================================================
// 6.4 ★★★ НАСТРОЙКА ОБРАБОТЧИКОВ ★★★
// ============================================================

LogsActions[PRIVATE.SETUP_HANDLERS] = function () {
  const loggerInstance = logger;

  // Фильтр
  const filterInput = logsState[PRIVATE.FILTER_INPUT];
  if (filterInput && VALIDATOR[VALIDATOR_SYMBOLS.IS_VALID_ELEMENT](filterInput)) {
    filterInput.addEventListener('input', () => {
      const value = filterInput.value || '';
      logsState[PRIVATE.CURRENT_FILTER] = value;
      LogsActions[PRIVATE.RENDER_LOGS]();
    });
    loggerInstance.debug('✅ Фильтр настроен');
  }

  // Уровень
  const levelSelect = logsState[PRIVATE.LEVEL_SELECT];
  if (levelSelect && VALIDATOR[VALIDATOR_SYMBOLS.IS_VALID_ELEMENT](levelSelect)) {
    levelSelect.addEventListener('change', () => {
      const value = levelSelect.value || 'all';
      logsState[PRIVATE.CURRENT_LEVEL] = value;
      LogsActions[PRIVATE.RENDER_LOGS]();
    });
    loggerInstance.debug('✅ Фильтр по уровню настроен');
  }

  // Пауза
  const pauseBtn = logsState[PRIVATE.PAUSE_BTN];
  if (pauseBtn && VALIDATOR[VALIDATOR_SYMBOLS.IS_VALID_ELEMENT](pauseBtn)) {
    pauseBtn.addEventListener('click', LogsActions[PRIVATE.TOGGLE_PAUSE]);
    loggerInstance.debug('✅ Кнопка паузы настроена');
  }

  // Очистка
  const clearBtn = logsState[PRIVATE.CLEAR_BTN];
  if (clearBtn && VALIDATOR[VALIDATOR_SYMBOLS.IS_VALID_ELEMENT](clearBtn)) {
    clearBtn.addEventListener('click', LogsActions[PRIVATE.CLEAR_LOGS]);
    loggerInstance.debug('✅ Кнопка очистки настроена');
  }

  // Экспорт
  const exportBtn = logsState[PRIVATE.EXPORT_BTN];
  if (exportBtn && VALIDATOR[VALIDATOR_SYMBOLS.IS_VALID_ELEMENT](exportBtn)) {
    exportBtn.addEventListener('click', () => LogsActions[PRIVATE.EXPORT_LOGS]());
    loggerInstance.debug('✅ Кнопка экспорта настроена');
  }

  // Слежение
  const followBtn = logsState[PRIVATE.FOLLOW_BTN];
  if (followBtn && VALIDATOR[VALIDATOR_SYMBOLS.IS_VALID_ELEMENT](followBtn)) {
    followBtn.addEventListener('click', LogsActions[PRIVATE.TOGGLE_FOLLOW]);
    loggerInstance.debug('✅ Кнопка слежения настроена');
  }

  loggerInstance.success('✅ Все обработчики настроены');
};

// ============================================================
// 6.5 ★★★ УПРАВЛЕНИЕ СОСТОЯНИЕМ ★★★
// ============================================================

LogsActions[PRIVATE.SAVE_STATE] = function () {
  try {
    const data = {
      entries: logsState[PRIVATE.LOG_ENTRIES].slice(-500),
      id: logsState[PRIVATE.LOG_ID],
      isPaused: logsState[PRIVATE.IS_PAUSED],
      isFollowing: logsState[PRIVATE.IS_FOLLOWING],
      stats: logsState[PRIVATE.STATS],
      timestamp: Date.now(),
      version: '2.1.9',
    };
    localStorage.setItem(logsState[PRIVATE.SAVE_KEY], JSON.stringify(data));
    logsState[PRIVATE.LAST_SAVE] = Date.now();
  } catch (e) {
    logger.debug('⚠️ Не удалось сохранить состояние логов:', e.message);
  }
};

LogsActions[PRIVATE.LOAD_STATE] = function () {
  try {
    const saved = localStorage.getItem(logsState[PRIVATE.SAVE_KEY]);
    if (saved) {
      const data = JSON.parse(saved);
      if (data.entries && Array.isArray(data.entries)) {
        // Восстанавливаем объекты Date
        const entries = data.entries.map(e => ({
          ...e,
          timestamp: new Date(e.timestamp),
        }));
        logsState[PRIVATE.LOG_ENTRIES] = entries;
        logsState[PRIVATE.LOG_ID] = data.id || entries.length;
        logsState[PRIVATE.IS_PAUSED] = data.isPaused || false;
        logsState[PRIVATE.IS_FOLLOWING] = data.isFollowing !== undefined ? data.isFollowing : true;
        if (data.stats) {
          logsState[PRIVATE.STATS] = data.stats;
        }
        logger.debug(`✅ Загружено ${entries.length} записей логов`);
        return true;
      }
    }
  } catch (e) {
    logger.debug('⚠️ Не удалось загрузить состояние логов:', e.message);
  }
  return false;
};

// ============================================================
// 6.6 ★★★ ПУБЛИЧНЫЕ МЕТОДЫ (ОБЕРТКИ СИМВОЛОВ) ★★★
// ============================================================

export function addLog(level, ...args) {
  return LogsActions[PRIVATE.ADD_LOG](level, ...args);
}

export function getLogs(filter = null, levelFilter = null) {
  return LogsActions[PRIVATE.GET_LOGS](filter, levelFilter);
}

export function renderLogs() {
  return LogsActions[PRIVATE.RENDER_LOGS]();
}

export function updateStats() {
  return LogsActions[PRIVATE.UPDATE_STATS]();
}

export function clearLogs() {
  return LogsActions[PRIVATE.CLEAR_LOGS]();
}

export function exportLogs(format = null, filename = null) {
  return LogsActions[PRIVATE.EXPORT_LOGS](format, filename);
}

export function togglePause() {
  return LogsActions[PRIVATE.TOGGLE_PAUSE]();
}

export function toggleFollow() {
  return LogsActions[PRIVATE.TOGGLE_FOLLOW]();
}

export function hookConsole() {
  return LogsActions[PRIVATE.HOOK_CONSOLE]();
}

export function restoreConsole() {
  return LogsActions[PRIVATE.RESTORE_CONSOLE]();
}

export function setupHandlers() {
  return LogsActions[PRIVATE.SETUP_HANDLERS]();
}

export function getLevelColor(level) {
  return LogsActions[PRIVATE.GET_LEVEL_COLOR](level);
}

export function escapeHtml(text) {
  return LogsActions[PRIVATE.ESCAPE_HTML](text);
}

export function formatMessage(...args) {
  return LogsActions[PRIVATE.FORMAT_MESSAGE](args);
}

// ============================================================
// 6.7 ★★★ МЕТОДЫ УПРАВЛЕНИЯ СОСТОЯНИЕМ ★★★
// ============================================================

export function getLogsState() {
  return {
    entries: [...logsState[PRIVATE.LOG_ENTRIES]],
    id: logsState[PRIVATE.LOG_ID],
    isPaused: logsState[PRIVATE.IS_PAUSED],
    isFollowing: logsState[PRIVATE.IS_FOLLOWING],
    isHooked: logsState[PRIVATE.IS_CONSOLE_HOOKED],
    maxLogs: logsState[PRIVATE.MAX_LOGS],
    currentFilter: logsState[PRIVATE.CURRENT_FILTER],
    currentLevel: logsState[PRIVATE.CURRENT_LEVEL],
    stats: { ...logsState[PRIVATE.STATS] },
  };
}

export function resetLogsState() {
  logsState[PRIVATE.LOG_ENTRIES] = [];
  logsState[PRIVATE.LOG_ID] = 0;
  logsState[PRIVATE.IS_PAUSED] = false;
  logsState[PRIVATE.IS_FOLLOWING] = true;
  logsState[PRIVATE.STATS] = {
    [PRIVATE.STATS_TOTAL]: 0,
    [PRIVATE.STATS_ERRORS]: 0,
    [PRIVATE.STATS_WARNINGS]: 0,
    [PRIVATE.STATS_TIMESTAMP]: Date.now(),
  };
  LogsActions[PRIVATE.RENDER_LOGS]();
  LogsActions[PRIVATE.UPDATE_STATS]();
  LogsActions[PRIVATE.SAVE_STATE]();
  logger.success('🔄 Состояние логов сброшено');
}

export function saveLogsState() {
  return LogsActions[PRIVATE.SAVE_STATE]();
}

export function loadLogsState() {
  return LogsActions[PRIVATE.LOAD_STATE]();
}

// ============================================================
// 6.8 ★★★ УПРАВЛЕНИЕ DOM ЭЛЕМЕНТАМИ ★★★
// ============================================================

export function setConsoleElement(el) {
  if (VALIDATOR[VALIDATOR_SYMBOLS.IS_VALID_ELEMENT](el)) {
    logsState[PRIVATE.CONSOLE_EL] = el;
  }
}

export function setFilterInput(el) {
  if (VALIDATOR[VALIDATOR_SYMBOLS.IS_VALID_ELEMENT](el)) {
    logsState[PRIVATE.FILTER_INPUT] = el;
  }
}

export function setLevelSelect(el) {
  if (VALIDATOR[VALIDATOR_SYMBOLS.IS_VALID_ELEMENT](el)) {
    logsState[PRIVATE.LEVEL_SELECT] = el;
  }
}

export function setPauseBtn(el) {
  if (VALIDATOR[VALIDATOR_SYMBOLS.IS_VALID_ELEMENT](el)) {
    logsState[PRIVATE.PAUSE_BTN] = el;
  }
}

export function setClearBtn(el) {
  if (VALIDATOR[VALIDATOR_SYMBOLS.IS_VALID_ELEMENT](el)) {
    logsState[PRIVATE.CLEAR_BTN] = el;
  }
}

export function setExportBtn(el) {
  if (VALIDATOR[VALIDATOR_SYMBOLS.IS_VALID_ELEMENT](el)) {
    logsState[PRIVATE.EXPORT_BTN] = el;
  }
}

export function setFollowBtn(el) {
  if (VALIDATOR[VALIDATOR_SYMBOLS.IS_VALID_ELEMENT](el)) {
    logsState[PRIVATE.FOLLOW_BTN] = el;
  }
}

export function setStatsElements(totalEl, errorsEl, warningsEl, statusEl) {
  if (VALIDATOR[VALIDATOR_SYMBOLS.IS_VALID_ELEMENT](totalEl)) {
    logsState[PRIVATE.TOTAL_EL] = totalEl;
  }
  if (VALIDATOR[VALIDATOR_SYMBOLS.IS_VALID_ELEMENT](errorsEl)) {
    logsState[PRIVATE.ERRORS_EL] = errorsEl;
  }
  if (VALIDATOR[VALIDATOR_SYMBOLS.IS_VALID_ELEMENT](warningsEl)) {
    logsState[PRIVATE.WARNINGS_EL] = warningsEl;
  }
  if (VALIDATOR[VALIDATOR_SYMBOLS.IS_VALID_ELEMENT](statusEl)) {
    logsState[PRIVATE.STATUS_EL] = statusEl;
  }
}

// ============================================================
// 6.9 ★★★ УПРАВЛЕНИЕ СОБЫТИЯМИ ★★★
// ============================================================

export function onLogsAction(event, callback) {
  if (typeof callback !== 'function') {
    logger.warn(`⚠️ Некорректный callback для события ${String(event)}`);
    return () => {};
  }

  const handlers = logsState[PRIVATE.EVENT_HANDLERS];
  if (!handlers.has(event)) {
    handlers.set(event, []);
  }
  handlers.get(event).push(callback);

  return () => offLogsAction(event, callback);
}

export function offLogsAction(event, callback) {
  const handlers = logsState[PRIVATE.EVENT_HANDLERS];
  if (handlers.has(event)) {
    const list = handlers.get(event);
    const index = list.indexOf(callback);
    if (index !== -1) {
      list.splice(index, 1);
    }
    if (list.length === 0) {
      handlers.delete(event);
    }
  }
}

export function emitLogsAction(event, data) {
  const handlers = logsState[PRIVATE.EVENT_HANDLERS];
  if (handlers.has(event)) {
    const list = handlers.get(event);
    for (const callback of list) {
      try {
        callback(data);
      } catch (e) {
        logger.error(`❌ Ошибка в обработчике ${String(event)}:`, e.message);
      }
    }
  }
}

// ============================================================
// 6.10 ★★★ СТАТИСТИКА И ОЧИСТКА ★★★
// ============================================================

export function getLogsStats() {
  const stats = logsState[PRIVATE.STATS];
  const entries = logsState[PRIVATE.LOG_ENTRIES];

  const levelCounts = {};
  for (const level of CONFIG[CONFIG_SYMBOLS.LEVELS]) {
    levelCounts[level] = entries.filter(e => e.level === level).length;
  }

  return {
    total: stats[PRIVATE.STATS_TOTAL],
    errors: stats[PRIVATE.STATS_ERRORS],
    warnings: stats[PRIVATE.STATS_WARNINGS],
    byLevel: levelCounts,
    timestamp: stats[PRIVATE.STATS_TIMESTAMP],
    isPaused: logsState[PRIVATE.IS_PAUSED],
    isFollowing: logsState[PRIVATE.IS_FOLLOWING],
    isHooked: logsState[PRIVATE.IS_CONSOLE_HOOKED],
    maxLogs: logsState[PRIVATE.MAX_LOGS],
    currentFilter: logsState[PRIVATE.CURRENT_FILTER] || 'none',
    currentLevel: logsState[PRIVATE.CURRENT_LEVEL] || 'all',
    cacheSize: logsState[PRIVATE.CACHE].size,
    timersCount: logsState[PRIVATE.TIMERS].size,
    hasRaf: !!logsState[PRIVATE.RAF_ID],
    version: '2.1.9',
  };
}

export function clearLogsTimers() {
  const timers = logsState[PRIVATE.TIMERS];
  for (const [key, timer] of timers) {
    clearTimeout(timer);
    clearInterval(timer);
  }
  timers.clear();

  if (logsState[PRIVATE.RAF_ID]) {
    cancelAnimationFrame(logsState[PRIVATE.RAF_ID]);
    logsState[PRIVATE.RAF_ID] = null;
  }

  logger.debug('🧹 Таймеры логов очищены');
}

export function clearLogsCache() {
  logsState[PRIVATE.CACHE].clear();
  logger.debug('🧹 Кеш логов очищен');
}

export function destroyLogsActions() {
  clearLogsTimers();
  clearLogsCache();
  LogsActions[PRIVATE.RESTORE_CONSOLE]();
  logsState[PRIVATE.EVENT_HANDLERS].clear();
  logsState[PRIVATE.LOG_ENTRIES] = [];
  logsState[PRIVATE.LOG_ID] = 0;

  if (typeof window !== 'undefined') {
    delete window[PUBLIC.API];
    delete window[PUBLIC.STATE];
    delete window[PUBLIC.CONFIG];
    delete window[PUBLIC.LOGGER];
    delete window[PUBLIC.EVENTS];
    delete window[PUBLIC.INSTANCE];
    delete window[PUBLIC.STATS];
  }

  logger.success('🗑️ LogsActions уничтожены');
}

// ============================================================
// 7. ★★★ ЗАГРУЗКА СОСТОЯНИЯ ПРИ СТАРТЕ ★★★
// ============================================================

LogsActions[PRIVATE.LOAD_STATE]();

// ============================================================
// 8. ★★★ ГЛОБАЛЬНАЯ РЕГИСТРАЦИЯ ★★★
// ============================================================

if (typeof window !== 'undefined') {
  // Экспорт через публичные символы
  window[PUBLIC.API] = {
    addLog,
    getLogs,
    renderLogs,
    updateStats,
    clearLogs,
    exportLogs,
    togglePause,
    toggleFollow,
    hookConsole,
    restoreConsole,
    setupHandlers,
  };

  window[PUBLIC.STATE] = getLogsState;
  window[PUBLIC.CONFIG] = CONFIG;
  window[PUBLIC.LOGGER] = logger;
  window[PUBLIC.EVENTS] = {
    on: onLogsAction,
    off: offLogsAction,
    emit: emitLogsAction,
  };
  window[PUBLIC.INSTANCE] = LogsActions;
  window[PUBLIC.STATS] = getLogsStats;

  // Глобальные команды
  window.__logsActions = {
    addLog,
    getLogs,
    renderLogs,
    updateStats,
    clearLogs,
    exportLogs,
    togglePause,
    toggleFollow,
    hookConsole,
    restoreConsole,
    setupHandlers,
    getState: getLogsState,
    resetState: resetLogsState,
    saveState: saveLogsState,
    loadState: loadLogsState,
    getStats: getLogsStats,
    clearTimers: clearLogsTimers,
    clearCache: clearLogsCache,
    destroy: destroyLogsActions,
    on: onLogsAction,
    off: offLogsAction,
    emit: emitLogsAction,
    setConsoleElement,
    setFilterInput,
    setLevelSelect,
    setPauseBtn,
    setClearBtn,
    setExportBtn,
    setFollowBtn,
    setStatsElements,
    getSymbols: () => ({
      PRIVATE: { ...PRIVATE },
      PUBLIC: { ...PUBLIC },
      LOGGER_SYMBOLS: { ...LOGGER_SYMBOLS },
      VALIDATOR_SYMBOLS: { ...VALIDATOR_SYMBOLS },
      CONFIG_SYMBOLS: { ...CONFIG_SYMBOLS },
    }),
  };

  // Баннер
  console.log('╔═══════════════════════════════════════════════════════════════════════════════╗');
  console.log('║              📦 LOGS ACTIONS (100% СИМВОЛЫ) v2.1.9                          ║');
  console.log('╠═══════════════════════════════════════════════════════════════════════════════╣');
  console.log('║  📋 Все логи выводятся в консоль с цветовой разметкой                       ║');
  console.log('║  🔑 Полная изоляция через приватные символы                                 ║');
  console.log('║  🔓 Публичные символы через Symbol.for                                      ║');
  console.log('║  📊 Полное управление логами: добавление, фильтрация, экспорт              ║');
  console.log('║  🎛️ Перехват console.log/error/warn/info/debug                              ║');
  console.log('║  ⏸️ Пауза и слежение за логами                                              ║');
  console.log('║  💾 Сохранение состояния в localStorage                                      ║');
  console.log('║  📤 Экспорт в JSON, CSV, TXT                                                ║');
  console.log('║  📡 Система событий (on/off/emit)                                          ║');
  console.log('║  🧹 Очистка таймеров и ресурсов                                            ║');
  console.log('╚═══════════════════════════════════════════════════════════════════════════════╝');

  console.log('📋 КОМАНДЫ ОТЛАДКИ (__logsActions):');
  console.log('  __logsActions.addLog(level, ...args)  - добавить лог');
  console.log('  __logsActions.getLogs(filter, level)  - получить логи');
  console.log('  __logsActions.renderLogs()            - рендеринг');
  console.log('  __logsActions.updateStats()           - обновить статистику');
  console.log('  __logsActions.clearLogs()             - очистить логи');
  console.log('  __logsActions.exportLogs(format)      - экспорт (json/csv/txt)');
  console.log('  __logsActions.togglePause()           - пауза');
  console.log('  __logsActions.toggleFollow()          - слежение');
  console.log('  __logsActions.hookConsole()           - перехват console');
  console.log('  __logsActions.restoreConsole()        - восстановить console');
  console.log('  __logsActions.getState()              - состояние');
  console.log('  __logsActions.getStats()              - статистика');
  console.log('  __logsActions.on(event, cb)           - подписка');
  console.log('  __logsActions.off(event, cb)          - отписка');
  console.log('  __logsActions.emit(event, data)       - событие');
  console.log('  __logsActions.destroy()               - уничтожить');
  console.log('  __logsActions.getSymbols()            - получить все символы');
  console.log('');

  console.log('📋 СОБЫТИЯ:');
  console.log('  onLogAdded, onLogsCleared, onPauseToggled');
  console.log('  onFollowToggled, onConsoleHooked, onStatsUpdated');
  console.log('');

  console.log('📋 ПРИВАТНЫХ СИМВОЛОВ:', Object.keys(PRIVATE).length);
  console.log('📋 ПУБЛИЧНЫХ СИМВОЛОВ:', Object.keys(PUBLIC).length);
  console.log('📋 ЛОГГЕР СИМВОЛОВ:', Object.keys(LOGGER_SYMBOLS).length);
  console.log('📋 ВАЛИДАТОР СИМВОЛОВ:', Object.keys(VALIDATOR_SYMBOLS).length);
  console.log('📋 КОНФИГ СИМВОЛОВ:', Object.keys(CONFIG_SYMBOLS).length);
  console.log('═══════════════════════════════════════════════════════════════════════════════');
}

// ============================================================
// 9. ★★★ ЭКСПОРТЫ ★★★
// ============================================================

export {
  PRIVATE,
  PUBLIC,
  LOGGER_SYMBOLS,
  VALIDATOR_SYMBOLS,
  CONFIG_SYMBOLS,
  CONFIG,
  logger as LogsActionsLogger,
  LogsActions,
  // Основные действия
  addLog,
  getLogs,
  renderLogs,
  updateStats,
  clearLogs,
  exportLogs,
  togglePause,
  toggleFollow,
  hookConsole,
  restoreConsole,
  setupHandlers,
  // Вспомогательные
  getLevelColor,
  escapeHtml,
  formatMessage,
  // Состояние
  getLogsState,
  resetLogsState,
  saveLogsState,
  loadLogsState,
  // DOM элементы
  setConsoleElement,
  setFilterInput,
  setLevelSelect,
  setPauseBtn,
  setClearBtn,
  setExportBtn,
  setFollowBtn,
  setStatsElements,
  // События
  onLogsAction,
  offLogsAction,
  emitLogsAction,
  // Статистика и очистка
  getLogsStats,
  clearLogsTimers,
  clearLogsCache,
  destroyLogsActions,
};

// ============================================================
// 10. ★★★ ДЕФОЛТНЫЙ ЭКСПОРТ ★★★
// ============================================================

export default {
  addLog,
  getLogs,
  renderLogs,
  updateStats,
  clearLogs,
  exportLogs,
  togglePause,
  toggleFollow,
  hookConsole,
  restoreConsole,
  setupHandlers,
  getLevelColor,
  escapeHtml,
  formatMessage,
  getState: getLogsState,
  resetState: resetLogsState,
  saveState: saveLogsState,
  loadState: loadLogsState,
  getStats: getLogsStats,
  clearTimers: clearLogsTimers,
  clearCache: clearLogsCache,
  destroy: destroyLogsActions,
  on: onLogsAction,
  off: offLogsAction,
  emit: emitLogsAction,
  setConsoleElement,
  setFilterInput,
  setLevelSelect,
  setPauseBtn,
  setClearBtn,
  setExportBtn,
  setFollowBtn,
  setStatsElements,
  getSymbols: () => ({
    PRIVATE: { ...PRIVATE },
    PUBLIC: { ...PUBLIC },
    LOGGER_SYMBOLS: { ...LOGGER_SYMBOLS },
    VALIDATOR_SYMBOLS: { ...VALIDATOR_SYMBOLS },
    CONFIG_SYMBOLS: { ...CONFIG_SYMBOLS },
  }),
};
