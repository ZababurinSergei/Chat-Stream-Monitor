// web/Bookmarklet/src/action/panel-actions.mjs
// 100% СИМВОЛЫ — полная изоляция и безопасность
// Базовые действия для панелей
// Версия: 2.1.9

// ============================================================
// 1. ПРИВАТНЫЕ СИМВОЛЫ (100% изоляция)
// ============================================================

const PRIVATE = {
  // Основные символы действий
  SHOW: Symbol('panel-actions.show'),
  HIDE: Symbol('panel-actions.hide'),
  TOGGLE: Symbol('panel-actions.toggle'),
  MINIMIZE: Symbol('panel-actions.minimize'),
  FULLSCREEN: Symbol('panel-actions.fullscreen'),
  CLOSE: Symbol('panel-actions.close'),
  FOCUS: Symbol('panel-actions.focus'),

  // Символы состояния
  STATE: Symbol('panel-actions.state'),
  CONFIG: Symbol('panel-actions.config'),
  CACHE: Symbol('panel-actions.cache'),

  // Символы DOM
  PANEL: Symbol('panel-actions.panel'),
  MIN_BTN: Symbol('panel-actions.minBtn'),
  MAX_BTN: Symbol('panel-actions.maxBtn'),
  CLOSE_BTN: Symbol('panel-actions.closeBtn'),
  HEADER: Symbol('panel-actions.header'),
  BODY: Symbol('panel-actions.body'),
  RESIZE: Symbol('panel-actions.resize'),

  // Символы утилит
  GET_PANEL: Symbol('panel-actions.getPanel'),
  GET_HEADER: Symbol('panel-actions.getHeader'),
  GET_BODY: Symbol('panel-actions.getBody'),
  GET_RESIZE: Symbol('panel-actions.getResize'),
  GET_MIN_BTN: Symbol('panel-actions.getMinBtn'),
  GET_MAX_BTN: Symbol('panel-actions.getMaxBtn'),
  GET_CLOSE_BTN: Symbol('panel-actions.getCloseBtn'),
  FIND_ELEMENT: Symbol('panel-actions.findElement'),
  UPDATE_STATE: Symbol('panel-actions.updateState'),
  GET_STATE: Symbol('panel-actions.getState'),
  RESET_STATE: Symbol('panel-actions.resetState'),
  SAVE_STATE: Symbol('panel-actions.saveState'),
  LOAD_STATE: Symbol('panel-actions.loadState'),

  // Символы анимации
  ANIMATE_SHOW: Symbol('panel-actions.animateShow'),
  ANIMATE_HIDE: Symbol('panel-actions.animateHide'),
  ANIMATE_MINIMIZE: Symbol('panel-actions.animateMinimize'),
  ANIMATE_FULLSCREEN: Symbol('panel-actions.animateFullscreen'),
  ANIMATE_FOCUS: Symbol('panel-actions.animateFocus'),

  // Символы логирования
  LOGGER: Symbol('panel-actions.logger'),
  LOG_HISTORY: Symbol('panel-actions.logHistory'),
  DEBUG: Symbol('panel-actions.debug'),

  // Символы событий
  EVENT_HANDLERS: Symbol('panel-actions.eventHandlers'),
  BEFORE_SHOW: Symbol('panel-actions.beforeShow'),
  AFTER_SHOW: Symbol('panel-actions.afterShow'),
  BEFORE_HIDE: Symbol('panel-actions.beforeHide'),
  AFTER_HIDE: Symbol('panel-actions.afterHide'),
  BEFORE_MINIMIZE: Symbol('panel-actions.beforeMinimize'),
  AFTER_MINIMIZE: Symbol('panel-actions.afterMinimize'),
  BEFORE_FULLSCREEN: Symbol('panel-actions.beforeFullscreen'),
  AFTER_FULLSCREEN: Symbol('panel-actions.afterFullscreen'),
  BEFORE_CLOSE: Symbol('panel-actions.beforeClose'),
  AFTER_CLOSE: Symbol('panel-actions.afterClose'),
  ON_FOCUS: Symbol('panel-actions.onFocus'),

  // Символы таймеров
  TIMERS: Symbol('panel-actions.timers'),
  RAF_ID: Symbol('panel-actions.rafId'),
  ANIMATION_ID: Symbol('panel-actions.animationId'),
};

// ============================================================
// 2. ПУБЛИЧНЫЕ СИМВОЛЫ (доступны через Symbol.for)
// ============================================================

const PUBLIC = {
  API: Symbol.for('panel-actions.api'),
  STATE: Symbol.for('panel-actions.state'),
  CONFIG: Symbol.for('panel-actions.config'),
  LOGGER: Symbol.for('panel-actions.logger'),
  EVENTS: Symbol.for('panel-actions.events'),
  INSTANCE: Symbol.for('panel-actions.instance'),
};

// ============================================================
// 3. ЛОГГЕР (100% СИМВОЛЫ)
// ============================================================

const LOGGER_SYMBOLS = {
  HISTORY: Symbol('logger.history'),
  MAX_HISTORY: Symbol('logger.maxHistory'),
  DEBUG: Symbol('logger.debug'),
  INSTANCE_ID: Symbol('logger.instanceId'),
  LEVEL: Symbol('logger.level'),
  TIMESTAMP: Symbol('logger.timestamp'),
  COLORS: Symbol('logger.colors'),
  OUTPUT: Symbol('logger.output'),
};

function createPanelLogger(debug = true, instanceId = 'PanelActions') {
  const loggerState = {
    [LOGGER_SYMBOLS.HISTORY]: [],
    [LOGGER_SYMBOLS.MAX_HISTORY]: 200,
    [LOGGER_SYMBOLS.DEBUG]: debug,
    [LOGGER_SYMBOLS.INSTANCE_ID]: instanceId,
    [LOGGER_SYMBOLS.LEVEL]: 'info',
    [LOGGER_SYMBOLS.TIMESTAMP]: true,
    [LOGGER_SYMBOLS.COLORS]: true,
    [LOGGER_SYMBOLS.OUTPUT]: console,
  };

  const logMethod = function (level, message, data = null) {
    if (!this[LOGGER_SYMBOLS.DEBUG] && level !== 'error') {
      return;
    }

    const timestamp = this[LOGGER_SYMBOLS.TIMESTAMP]
      ? `[${new Date().toISOString().slice(11, 23)}]`
      : '';
    const prefix = `${timestamp} [${this[LOGGER_SYMBOLS.INSTANCE_ID]}]`;
    const output = this[LOGGER_SYMBOLS.OUTPUT];

    this[LOGGER_SYMBOLS.HISTORY].push({ timestamp, level, message, data });
    if (this[LOGGER_SYMBOLS.HISTORY].length > this[LOGGER_SYMBOLS.MAX_HISTORY]) {
      this[LOGGER_SYMBOLS.HISTORY].shift();
    }

    const styles = this[LOGGER_SYMBOLS.COLORS]
      ? {
          error: 'color: #ff6b6b; font-weight: bold;',
          warn: 'color: #fdcb6e; font-weight: bold;',
          info: 'color: #74b9ff; font-weight: bold;',
          debug: 'color: #a29bfe;',
          success: 'color: #00b894; font-weight: bold;',
        }
      : {};

    const style = styles[level] || styles.info;

    if (data !== null && data !== undefined) {
      if (typeof data === 'object') {
        output.log(`%c${prefix} ${message}`, style, data);
      } else {
        output.log(`%c${prefix} ${message}`, style, data);
      }
    } else {
      output.log(`%c${prefix} ${message}`, style);
    }
  };

  const boundLog = logMethod.bind(loggerState);

  const logger = {
    error: (msg, d) => boundLog('error', `❌ ${msg}`, d),
    warn: (msg, d) => boundLog('warn', `⚠️ ${msg}`, d),
    info: (msg, d) => boundLog('info', `ℹ️ ${msg}`, d),
    debug: (msg, d) => boundLog('debug', `🔍 ${msg}`, d),
    success: (msg, d) => boundLog('info', `✅ ${msg}`, d),

    header: title => {
      const output = loggerState[LOGGER_SYMBOLS.OUTPUT];
      output.log('%c' + '═'.repeat(70), 'color: #636e72;');
      output.log(
        '%c  📦 ' + title,
        'background: #1a1a2e; color: #fff; padding: 4px 12px; border-radius: 4px; font-weight: bold;'
      );
      output.log('%c' + '═'.repeat(70), 'color: #636e72;');
    },

    separator: () => {
      const output = loggerState[LOGGER_SYMBOLS.OUTPUT];
      output.log('%c' + '─'.repeat(70), 'color: #636e72;');
    },

    getHistory: () => [...loggerState[LOGGER_SYMBOLS.HISTORY]],
    clearHistory: () => {
      loggerState[LOGGER_SYMBOLS.HISTORY] = [];
      return logger;
    },
    setDebug: enabled => {
      loggerState[LOGGER_SYMBOLS.DEBUG] = enabled;
      return logger;
    },
    setLevel: level => {
      loggerState[LOGGER_SYMBOLS.LEVEL] = level;
      return logger;
    },
    getLevel: () => loggerState[LOGGER_SYMBOLS.LEVEL],
    setOutput: output => {
      loggerState[LOGGER_SYMBOLS.OUTPUT] = output;
      return logger;
    },
  };

  return logger;
}

// ============================================================
// 4. ВАЛИДАТОР (100% СИМВОЛЫ)
// ============================================================

const VALIDATOR_SYMBOLS = {
  IS_VALID_PANEL: Symbol('validator.isValidPanel'),
  IS_VALID_BUTTON: Symbol('validator.isValidButton'),
  IS_VALID_ELEMENT: Symbol('validator.isValidElement'),
  IS_VALID_STATE: Symbol('validator.isValidState'),
  IS_VALID_ACTION: Symbol('validator.isValidAction'),
  SANITIZE: Symbol('validator.sanitize'),
  CHECK_DOM: Symbol('validator.checkDom'),
};

const VALIDATOR = {
  [VALIDATOR_SYMBOLS.IS_VALID_PANEL]: panel => {
    return (
      panel &&
      typeof panel === 'object' &&
      panel instanceof HTMLElement &&
      panel.tagName === 'DIV' &&
      panel.id
    );
  },

  [VALIDATOR_SYMBOLS.IS_VALID_BUTTON]: btn => {
    return (
      btn &&
      typeof btn === 'object' &&
      btn instanceof HTMLElement &&
      btn.tagName === 'BUTTON' &&
      typeof btn.click === 'function'
    );
  },

  [VALIDATOR_SYMBOLS.IS_VALID_ELEMENT]: el => {
    return el && typeof el === 'object' && el instanceof HTMLElement;
  },

  [VALIDATOR_SYMBOLS.IS_VALID_STATE]: state => {
    return state && typeof state === 'object' && typeof state.visible === 'boolean';
  },

  [VALIDATOR_SYMBOLS.IS_VALID_ACTION]: action => {
    return typeof action === 'function';
  },

  [VALIDATOR_SYMBOLS.SANITIZE]: value => {
    if (value === null || value === undefined) return null;
    if (typeof value === 'string') {
      return value.replace(/[<>]/g, '').trim();
    }
    if (typeof value === 'object') {
      try {
        return JSON.parse(JSON.stringify(value));
      } catch {
        return null;
      }
    }
    return value;
  },

  [VALIDATOR_SYMBOLS.CHECK_DOM]: panel => {
    if (!panel) return false;
    return document.body.contains(panel);
  },
};

// ============================================================
// 5. КОНФИГУРАЦИЯ (100% СИМВОЛЫ)
// ============================================================

const CONFIG_SYMBOLS = {
  ANIMATION_DURATION: Symbol('config.animationDuration'),
  MIN_WIDTH: Symbol('config.minWidth'),
  MIN_HEIGHT: Symbol('config.minHeight'),
  Z_INDEX_BASE: Symbol('config.zIndexBase'),
  Z_INDEX_MAX: Symbol('config.zIndexMax'),
  CACHE_TTL: Symbol('config.cacheTtl'),
  STATE_KEY: Symbol('config.stateKey'),
  DEFAULT_STATE: Symbol('config.defaultState'),
};

const CONFIG = {
  [CONFIG_SYMBOLS.ANIMATION_DURATION]: 300,
  [CONFIG_SYMBOLS.MIN_WIDTH]: 320,
  [CONFIG_SYMBOLS.MIN_HEIGHT]: 300,
  [CONFIG_SYMBOLS.Z_INDEX_BASE]: 99996,
  [CONFIG_SYMBOLS.Z_INDEX_MAX]: 999999,
  [CONFIG_SYMBOLS.CACHE_TTL]: 3600000,
  [CONFIG_SYMBOLS.STATE_KEY]: 'panel-actions-state',
  [CONFIG_SYMBOLS.DEFAULT_STATE]: {
    visible: true,
    minimized: false,
    fullscreen: false,
    zIndex: 99996,
  },
};

// ============================================================
// 6. ОСНОВНОЙ ОБЪЕКТ ДЕЙСТВИЙ (100% СИМВОЛЫ)
// ============================================================

const PanelActions = {};

// ============================================================
// 6.1 ★★★ ПРИВАТНОЕ СОСТОЯНИЕ ★★★
// ============================================================

const actionsState = {
  [PRIVATE.STATE]: { ...CONFIG[CONFIG_SYMBOLS.DEFAULT_STATE] },
  [PRIVATE.CACHE]: new Map(),
  [PRIVATE.TIMERS]: new Map(),
  [PRIVATE.RAF_ID]: null,
  [PRIVATE.ANIMATION_ID]: null,
  [PRIVATE.EVENT_HANDLERS]: new Map(),
  [PRIVATE.LOG_HISTORY]: [],
};

const logger = createPanelLogger(true, 'PanelActions');

// ============================================================
// 6.2 ★★★ ПОЛУЧЕНИЕ СОСТОЯНИЯ ★★★
// ============================================================

PanelActions[PRIVATE.GET_STATE] = function () {
  return { ...actionsState[PRIVATE.STATE] };
};

PanelActions[PRIVATE.UPDATE_STATE] = function (newState) {
  const oldState = { ...actionsState[PRIVATE.STATE] };
  Object.assign(actionsState[PRIVATE.STATE], newState);
  PanelActions[PRIVATE.SAVE_STATE]();
  return actionsState[PRIVATE.STATE];
};

PanelActions[PRIVATE.RESET_STATE] = function () {
  actionsState[PRIVATE.STATE] = { ...CONFIG[CONFIG_SYMBOLS.DEFAULT_STATE] };
  PanelActions[PRIVATE.SAVE_STATE]();
  return actionsState[PRIVATE.STATE];
};

PanelActions[PRIVATE.SAVE_STATE] = function () {
  try {
    const data = {
      state: actionsState[PRIVATE.STATE],
      timestamp: Date.now(),
      version: '2.1.9',
    };
    localStorage.setItem(CONFIG[CONFIG_SYMBOLS.STATE_KEY], JSON.stringify(data));
  } catch (e) {
    logger.debug('⚠️ Не удалось сохранить состояние:', e.message);
  }
};

PanelActions[PRIVATE.LOAD_STATE] = function () {
  try {
    const saved = localStorage.getItem(CONFIG[CONFIG_SYMBOLS.STATE_KEY]);
    if (saved) {
      const data = JSON.parse(saved);
      if (data.state && typeof data.state === 'object') {
        Object.assign(actionsState[PRIVATE.STATE], data.state);
        logger.debug('✅ Состояние загружено');
      }
    }
  } catch (e) {
    logger.debug('⚠️ Не удалось загрузить состояние:', e.message);
  }
  return actionsState[PRIVATE.STATE];
};

// ============================================================
// 6.3 ★★★ ПОИСК ЭЛЕМЕНТОВ ★★★
// ============================================================

PanelActions[PRIVATE.FIND_ELEMENT] = function (panel, selector) {
  if (!VALIDATOR[VALIDATOR_SYMBOLS.IS_VALID_PANEL](panel)) return null;
  try {
    return panel.querySelector(selector);
  } catch {
    return null;
  }
};

PanelActions[PRIVATE.GET_HEADER] = function (panel) {
  return PanelActions[PRIVATE.FIND_ELEMENT](panel, '#panel-header');
};

PanelActions[PRIVATE.GET_BODY] = function (panel) {
  return PanelActions[PRIVATE.FIND_ELEMENT](panel, '#panel-body');
};

PanelActions[PRIVATE.GET_RESIZE] = function (panel) {
  return PanelActions[PRIVATE.FIND_ELEMENT](panel, '#panel-resize');
};

PanelActions[PRIVATE.GET_MIN_BTN] = function (panel) {
  return PanelActions[PRIVATE.FIND_ELEMENT](panel, '#panel-minimize-btn');
};

PanelActions[PRIVATE.GET_MAX_BTN] = function (panel) {
  return PanelActions[PRIVATE.FIND_ELEMENT](panel, '#panel-maximize-btn');
};

PanelActions[PRIVATE.GET_CLOSE_BTN] = function (panel) {
  return PanelActions[PRIVATE.FIND_ELEMENT](panel, '#panel-close-btn');
};

// ============================================================
// 6.4 ★★★ АНИМАЦИИ ★★★
// ============================================================

PanelActions[PRIVATE.ANIMATE_SHOW] = function (panel, duration) {
  return new Promise(resolve => {
    if (!panel) return resolve(false);

    const dur = duration || CONFIG[CONFIG_SYMBOLS.ANIMATION_DURATION];

    panel.style.transition = `transform ${dur}ms ease, opacity ${dur}ms ease`;
    panel.style.transform = 'scale(0.95)';
    panel.style.opacity = '0';
    panel.style.display = 'flex';

    requestAnimationFrame(() => {
      requestAnimationFrame(() => {
        panel.style.transform = 'scale(1)';
        panel.style.opacity = '1';
      });
    });

    const timer = setTimeout(() => {
      panel.style.transition = '';
      resolve(true);
    }, dur + 50);

    actionsState[PRIVATE.TIMERS].set('show', timer);
  });
};

PanelActions[PRIVATE.ANIMATE_HIDE] = function (panel, duration) {
  return new Promise(resolve => {
    if (!panel) return resolve(false);

    const dur = duration || CONFIG[CONFIG_SYMBOLS.ANIMATION_DURATION];

    panel.style.transition = `transform ${dur}ms ease, opacity ${dur}ms ease`;
    panel.style.transform = 'scale(0.95)';
    panel.style.opacity = '0';

    const timer = setTimeout(() => {
      panel.style.display = 'none';
      panel.style.transform = '';
      panel.style.opacity = '';
      panel.style.transition = '';
      resolve(true);
    }, dur + 50);

    actionsState[PRIVATE.TIMERS].set('hide', timer);
  });
};

PanelActions[PRIVATE.ANIMATE_MINIMIZE] = function (panel, duration) {
  return new Promise(resolve => {
    if (!panel) return resolve(false);

    const dur = duration || CONFIG[CONFIG_SYMBOLS.ANIMATION_DURATION];
    const isMinimized = panel.classList.contains('minimized');

    panel.style.transition = `height ${dur}ms ease, min-height ${dur}ms ease`;

    if (!isMinimized) {
      panel.style.height = '44px';
      panel.style.minHeight = '44px';
      panel.style.maxHeight = '44px';
    } else {
      const prevHeight = parseInt(panel.dataset.prevHeight) || 520;
      panel.style.height = prevHeight + 'px';
      panel.style.minHeight = '300px';
      panel.style.maxHeight = '';
    }

    const timer = setTimeout(() => {
      panel.style.transition = '';
      resolve(true);
    }, dur + 50);

    actionsState[PRIVATE.TIMERS].set('minimize', timer);
  });
};

PanelActions[PRIVATE.ANIMATE_FULLSCREEN] = function (panel, duration) {
  return new Promise(resolve => {
    if (!panel) return resolve(false);

    const dur = duration || CONFIG[CONFIG_SYMBOLS.ANIMATION_DURATION];
    const isFullscreen = panel.classList.contains('fullscreen');

    panel.style.transition = `
      width ${dur}ms ease,
      height ${dur}ms ease,
      top ${dur}ms ease,
      left ${dur}ms ease,
      border-radius ${dur}ms ease
    `;

    const timer = setTimeout(() => {
      panel.style.transition = '';
      resolve(true);
    }, dur + 50);

    actionsState[PRIVATE.TIMERS].set('fullscreen', timer);
  });
};

PanelActions[PRIVATE.ANIMATE_FOCUS] = function (panel, duration) {
  return new Promise(resolve => {
    if (!panel) return resolve(false);

    const dur = duration || 150;
    const currentZ = parseInt(panel.style.zIndex) || CONFIG[CONFIG_SYMBOLS.Z_INDEX_BASE];

    panel.style.transition = `z-index ${dur}ms ease`;
    panel.style.zIndex = currentZ + 1;

    const timer = setTimeout(() => {
      panel.style.transition = '';
      resolve(true);
    }, dur + 50);

    actionsState[PRIVATE.TIMERS].set('focus', timer);
  });
};

// ============================================================
// 6.5 ★★★ ОСНОВНЫЕ ДЕЙСТВИЯ ★★★
// ============================================================

PanelActions[PRIVATE.SHOW] = async function (panel, options = {}) {
  const state = actionsState[PRIVATE.STATE];
  const loggerInstance = logger;

  loggerInstance.debug(`👁️ Показ панели: ${panel?.id || 'unknown'}`);

  if (!VALIDATOR[VALIDATOR_SYMBOLS.IS_VALID_PANEL](panel)) {
    loggerInstance.error('❌ Некорректный элемент панели');
    return false;
  }

  // Проверяем, не видна ли уже
  if (panel.style.display !== 'none' && state.visible) {
    loggerInstance.debug('ℹ️ Панель уже видна');
    return true;
  }

  // Событие beforeShow
  const beforeShow = options.beforeShow || null;
  if (typeof beforeShow === 'function') {
    try {
      beforeShow(panel);
    } catch (e) {
      loggerInstance.error('❌ Ошибка в beforeShow:', e.message);
    }
  }

  // Анимация
  if (options.animate !== false) {
    await PanelActions[PRIVATE.ANIMATE_SHOW](panel, options.duration);
  } else {
    panel.style.display = 'flex';
    panel.style.opacity = '1';
    panel.style.transform = 'scale(1)';
  }

  // Обновляем состояние
  state.visible = true;
  PanelActions[PRIVATE.UPDATE_STATE]({ visible: true });

  // Событие afterShow
  const afterShow = options.afterShow || null;
  if (typeof afterShow === 'function') {
    try {
      afterShow(panel);
    } catch (e) {
      loggerInstance.error('❌ Ошибка в afterShow:', e.message);
    }
  }

  loggerInstance.success(`✅ Панель ${panel.id} показана`);
  return true;
};

PanelActions[PRIVATE.HIDE] = async function (panel, options = {}) {
  const state = actionsState[PRIVATE.STATE];
  const loggerInstance = logger;

  loggerInstance.debug(`🙈 Скрытие панели: ${panel?.id || 'unknown'}`);

  if (!VALIDATOR[VALIDATOR_SYMBOLS.IS_VALID_PANEL](panel)) {
    loggerInstance.error('❌ Некорректный элемент панели');
    return false;
  }

  // Проверяем, не скрыта ли уже
  if (panel.style.display === 'none' && !state.visible) {
    loggerInstance.debug('ℹ️ Панель уже скрыта');
    return true;
  }

  // Событие beforeHide
  const beforeHide = options.beforeHide || null;
  if (typeof beforeHide === 'function') {
    try {
      beforeHide(panel);
    } catch (e) {
      loggerInstance.error('❌ Ошибка в beforeHide:', e.message);
    }
  }

  // Анимация
  if (options.animate !== false) {
    await PanelActions[PRIVATE.ANIMATE_HIDE](panel, options.duration);
  } else {
    panel.style.display = 'none';
  }

  // Обновляем состояние
  state.visible = false;
  PanelActions[PRIVATE.UPDATE_STATE]({ visible: false });

  // Событие afterHide
  const afterHide = options.afterHide || null;
  if (typeof afterHide === 'function') {
    try {
      afterHide(panel);
    } catch (e) {
      loggerInstance.error('❌ Ошибка в afterHide:', e.message);
    }
  }

  loggerInstance.success(`✅ Панель ${panel.id} скрыта`);
  return true;
};

PanelActions[PRIVATE.TOGGLE] = async function (panel, options = {}) {
  const state = actionsState[PRIVATE.STATE];
  const loggerInstance = logger;

  loggerInstance.debug(`🔄 Переключение панели: ${panel?.id || 'unknown'}`);

  if (!VALIDATOR[VALIDATOR_SYMBOLS.IS_VALID_PANEL](panel)) {
    loggerInstance.error('❌ Некорректный элемент панели');
    return false;
  }

  const isVisible = panel.style.display !== 'none' && state.visible;

  // Событие beforeToggle
  const beforeToggle = options.beforeToggle || null;
  if (typeof beforeToggle === 'function') {
    try {
      beforeToggle(panel, !isVisible);
    } catch (e) {
      loggerInstance.error('❌ Ошибка в beforeToggle:', e.message);
    }
  }

  let result;
  if (isVisible) {
    result = await PanelActions[PRIVATE.HIDE](panel, options);
  } else {
    result = await PanelActions[PRIVATE.SHOW](panel, options);
  }

  // Событие afterToggle
  const afterToggle = options.afterToggle || null;
  if (typeof afterToggle === 'function') {
    try {
      afterToggle(panel, !isVisible);
    } catch (e) {
      loggerInstance.error('❌ Ошибка в afterToggle:', e.message);
    }
  }

  loggerInstance.success(
    `✅ Панель ${panel.id} переключена: ${!isVisible ? 'показана' : 'скрыта'}`
  );
  return result;
};

PanelActions[PRIVATE.MINIMIZE] = async function (panel, options = {}) {
  const state = actionsState[PRIVATE.STATE];
  const loggerInstance = logger;
  const minBtn = PanelActions[PRIVATE.GET_MIN_BTN](panel);

  loggerInstance.debug(`📐 Минимизация панели: ${panel?.id || 'unknown'}`);

  if (!VALIDATOR[VALIDATOR_SYMBOLS.IS_VALID_PANEL](panel)) {
    loggerInstance.error('❌ Некорректный элемент панели');
    return false;
  }

  const isFullscreen = panel.classList.contains('fullscreen');
  if (isFullscreen) {
    loggerInstance.debug('⚠️ Панель в полноэкранном режиме, сначала выходим из него');
    await PanelActions[PRIVATE.FULLSCREEN](panel, { ...options, animate: false });
    await new Promise(resolve => setTimeout(resolve, 50));
  }

  const isMinimized = panel.classList.contains('minimized');

  // Событие beforeMinimize
  const beforeMinimize = options.beforeMinimize || null;
  if (typeof beforeMinimize === 'function') {
    try {
      beforeMinimize(panel, !isMinimized);
    } catch (e) {
      loggerInstance.error('❌ Ошибка в beforeMinimize:', e.message);
    }
  }

  // Сохраняем высоту перед минимизацией
  if (!isMinimized) {
    panel.dataset.prevHeight = panel.offsetHeight;
  }

  // Анимация
  if (options.animate !== false) {
    await PanelActions[PRIVATE.ANIMATE_MINIMIZE](panel, options.duration);
  } else {
    if (!isMinimized) {
      panel.style.height = '44px';
      panel.style.minHeight = '44px';
      panel.style.maxHeight = '44px';
    } else {
      const prevHeight = parseInt(panel.dataset.prevHeight) || 520;
      panel.style.height = prevHeight + 'px';
      panel.style.minHeight = '300px';
      panel.style.maxHeight = '';
    }
  }

  // Переключаем класс
  panel.classList.toggle('minimized', !isMinimized);

  // Скрываем/показываем элементы
  const body = PanelActions[PRIVATE.GET_BODY](panel);
  const resize = PanelActions[PRIVATE.GET_RESIZE](panel);

  if (!isMinimized) {
    if (body) body.style.display = 'none';
    if (resize) resize.style.display = 'none';
    if (minBtn) minBtn.textContent = '□';
  } else {
    if (body) body.style.display = '';
    if (resize) resize.style.display = '';
    if (minBtn) minBtn.textContent = '─';
  }

  // Обновляем состояние
  state.minimized = !isMinimized;
  PanelActions[PRIVATE.UPDATE_STATE]({ minimized: state.minimized });

  // Событие afterMinimize
  const afterMinimize = options.afterMinimize || null;
  if (typeof afterMinimize === 'function') {
    try {
      afterMinimize(panel, !isMinimized);
    } catch (e) {
      loggerInstance.error('❌ Ошибка в afterMinimize:', e.message);
    }
  }

  loggerInstance.success(`✅ Панель ${panel.id} ${state.minimized ? 'свёрнута' : 'развёрнута'}`);
  return state.minimized;
};

PanelActions[PRIVATE.FULLSCREEN] = async function (panel, options = {}) {
  const state = actionsState[PRIVATE.STATE];
  const loggerInstance = logger;
  const maxBtn = PanelActions[PRIVATE.GET_MAX_BTN](panel);

  loggerInstance.debug(`🖥️ Полноэкранный режим: ${panel?.id || 'unknown'}`);

  if (!VALIDATOR[VALIDATOR_SYMBOLS.IS_VALID_PANEL](panel)) {
    loggerInstance.error('❌ Некорректный элемент панели');
    return false;
  }

  const isFullscreen = panel.classList.contains('fullscreen');

  // Событие beforeFullscreen
  const beforeFullscreen = options.beforeFullscreen || null;
  if (typeof beforeFullscreen === 'function') {
    try {
      beforeFullscreen(panel, !isFullscreen);
    } catch (e) {
      loggerInstance.error('❌ Ошибка в beforeFullscreen:', e.message);
    }
  }

  if (!isFullscreen) {
    // Вход в полноэкранный режим
    panel.dataset.prevWidth = panel.offsetWidth;
    panel.dataset.prevHeight = panel.offsetHeight;
    panel.dataset.prevLeft = panel.style.left || panel.offsetLeft + 'px';
    panel.dataset.prevTop = panel.style.top || panel.offsetTop + 'px';

    panel.style.width = '100vw';
    panel.style.height = '100vh';
    panel.style.top = '0';
    panel.style.left = '0';
    panel.style.borderRadius = '0';
    panel.style.border = 'none';
    panel.style.maxWidth = '100vw';
    panel.style.maxHeight = '100vh';
    panel.style.minWidth = '100vw';
    panel.style.minHeight = '100vh';
    panel.style.zIndex = CONFIG[CONFIG_SYMBOLS.Z_INDEX_MAX];
    document.body.style.overflow = 'hidden';

    // Если была свёрнута — разворачиваем
    if (panel.classList.contains('minimized')) {
      const minBtn = PanelActions[PRIVATE.GET_MIN_BTN](panel);
      panel.classList.remove('minimized');
      const body = PanelActions[PRIVATE.GET_BODY](panel);
      const resize = PanelActions[PRIVATE.GET_RESIZE](panel);
      if (body) body.style.display = '';
      if (resize) resize.style.display = '';
      if (minBtn) minBtn.textContent = '─';
      state.minimized = false;
    }

    const resize = PanelActions[PRIVATE.GET_RESIZE](panel);
    if (resize) resize.style.display = 'none';
    if (maxBtn) maxBtn.textContent = '⧉';

    // Анимация
    if (options.animate !== false) {
      await PanelActions[PRIVATE.ANIMATE_FULLSCREEN](panel, options.duration);
    }

    panel.classList.add('fullscreen');
    state.fullscreen = true;
  } else {
    // Выход из полноэкранного режима
    const prevWidth = parseInt(panel.dataset.prevWidth) || 420;
    const prevHeight = parseInt(panel.dataset.prevHeight) || 520;
    const prevLeft = panel.dataset.prevLeft || '100px';
    const prevTop = panel.dataset.prevTop || '100px';

    panel.style.width = prevWidth + 'px';
    panel.style.height = prevHeight + 'px';
    panel.style.top = prevTop;
    panel.style.left = prevLeft;
    panel.style.borderRadius = '12px';
    panel.style.border = '1px solid rgba(255,255,255,0.08)';
    panel.style.maxWidth = '';
    panel.style.maxHeight = '';
    panel.style.minWidth = '320px';
    panel.style.minHeight = '300px';
    panel.style.zIndex = '';
    document.body.style.overflow = '';

    const resize = PanelActions[PRIVATE.GET_RESIZE](panel);
    if (resize) resize.style.display = '';
    if (maxBtn) maxBtn.textContent = '□';

    // Анимация
    if (options.animate !== false) {
      await PanelActions[PRIVATE.ANIMATE_FULLSCREEN](panel, options.duration);
    }

    panel.classList.remove('fullscreen');
    state.fullscreen = false;
  }

  PanelActions[PRIVATE.UPDATE_STATE]({ fullscreen: state.fullscreen });

  // Событие afterFullscreen
  const afterFullscreen = options.afterFullscreen || null;
  if (typeof afterFullscreen === 'function') {
    try {
      afterFullscreen(panel, !isFullscreen);
    } catch (e) {
      loggerInstance.error('❌ Ошибка в afterFullscreen:', e.message);
    }
  }

  loggerInstance.success(
    `✅ Панель ${panel.id} ${state.fullscreen ? 'в полноэкранном режиме' : 'восстановлена'}`
  );
  return state.fullscreen;
};

PanelActions[PRIVATE.CLOSE] = async function (panel, options = {}) {
  const state = actionsState[PRIVATE.STATE];
  const loggerInstance = logger;

  loggerInstance.debug(`🚪 Закрытие панели: ${panel?.id || 'unknown'}`);

  if (!VALIDATOR[VALIDATOR_SYMBOLS.IS_VALID_PANEL](panel)) {
    loggerInstance.error('❌ Некорректный элемент панели');
    return false;
  }

  // Событие beforeClose
  const beforeClose = options.beforeClose || null;
  if (typeof beforeClose === 'function') {
    try {
      beforeClose(panel);
    } catch (e) {
      loggerInstance.error('❌ Ошибка в beforeClose:', e.message);
    }
  }

  // Анимация
  if (options.animate !== false) {
    await PanelActions[PRIVATE.ANIMATE_HIDE](panel, options.duration);
  } else {
    panel.style.display = 'none';
  }

  // Обновляем состояние
  state.visible = false;
  PanelActions[PRIVATE.UPDATE_STATE]({ visible: false });

  // Событие afterClose
  const afterClose = options.afterClose || null;
  if (typeof afterClose === 'function') {
    try {
      afterClose(panel);
    } catch (e) {
      loggerInstance.error('❌ Ошибка в afterClose:', e.message);
    }
  }

  loggerInstance.success(`✅ Панель ${panel.id} закрыта`);
  return true;
};

PanelActions[PRIVATE.FOCUS] = async function (panel, options = {}) {
  const loggerInstance = logger;
  const state = actionsState[PRIVATE.STATE];

  loggerInstance.debug(`🎯 Фокус на панели: ${panel?.id || 'unknown'}`);

  if (!VALIDATOR[VALIDATOR_SYMBOLS.IS_VALID_PANEL](panel)) {
    loggerInstance.error('❌ Некорректный элемент панели');
    return false;
  }

  // Событие onFocus
  const onFocus = options.onFocus || null;
  if (typeof onFocus === 'function') {
    try {
      onFocus(panel);
    } catch (e) {
      loggerInstance.error('❌ Ошибка в onFocus:', e.message);
    }
  }

  // Находим все панели
  const allWindows = document.querySelectorAll(
    '.panel-container, #widget-app, #env-control-panel, #logs-control-panel, #debug-control-panel'
  );

  // Находим максимальный z-index
  let maxZ = CONFIG[CONFIG_SYMBOLS.Z_INDEX_BASE];
  allWindows.forEach(win => {
    if (win !== panel && win.style.display !== 'none') {
      const z = parseInt(win.style.zIndex) || 0;
      if (z > maxZ) maxZ = z;
    }
  });

  // Устанавливаем новый z-index
  const newZ = maxZ + 1;
  panel.style.zIndex = newZ;

  // Анимация
  if (options.animate !== false) {
    await PanelActions[PRIVATE.ANIMATE_FOCUS](panel, options.duration);
  }

  // Обновляем состояние
  state.zIndex = newZ;
  PanelActions[PRIVATE.UPDATE_STATE]({ zIndex: newZ });

  // Убираем активные классы у других панелей
  allWindows.forEach(win => {
    win.classList.remove('active-window');
  });
  panel.classList.add('active-window');

  loggerInstance.success(`✅ Панель ${panel.id} на переднем плане (z-index: ${newZ})`);
  return newZ;
};

// ============================================================
// 6.6 ★★★ ПУБЛИЧНЫЕ МЕТОДЫ (ОБЕРТКИ СИМВОЛОВ) ★★★
// ============================================================

export function showPanel(panel, options = {}) {
  return PanelActions[PRIVATE.SHOW](panel, options);
}

export function hidePanel(panel, options = {}) {
  return PanelActions[PRIVATE.HIDE](panel, options);
}

export function togglePanel(panel, options = {}) {
  return PanelActions[PRIVATE.TOGGLE](panel, options);
}

export function minimizePanel(panel, options = {}) {
  return PanelActions[PRIVATE.MINIMIZE](panel, options);
}

export function fullscreenPanel(panel, options = {}) {
  return PanelActions[PRIVATE.FULLSCREEN](panel, options);
}

export function closePanel(panel, options = {}) {
  return PanelActions[PRIVATE.CLOSE](panel, options);
}

export function focusPanel(panel, options = {}) {
  return PanelActions[PRIVATE.FOCUS](panel, options);
}

// ============================================================
// 6.7 ★★★ МЕТОДЫ УПРАВЛЕНИЯ СОСТОЯНИЕМ ★★★
// ============================================================

export function getPanelState() {
  return PanelActions[PRIVATE.GET_STATE]();
}

export function updatePanelState(newState) {
  return PanelActions[PRIVATE.UPDATE_STATE](newState);
}

export function resetPanelState() {
  return PanelActions[PRIVATE.RESET_STATE]();
}

export function loadPanelState() {
  return PanelActions[PRIVATE.LOAD_STATE]();
}

// ============================================================
// 6.8 ★★★ МЕТОДЫ ПОИСКА ЭЛЕМЕНТОВ ★★★
// ============================================================

export function getPanelHeader(panel) {
  return PanelActions[PRIVATE.GET_HEADER](panel);
}

export function getPanelBody(panel) {
  return PanelActions[PRIVATE.GET_BODY](panel);
}

export function getPanelResize(panel) {
  return PanelActions[PRIVATE.GET_RESIZE](panel);
}

export function getPanelMinBtn(panel) {
  return PanelActions[PRIVATE.GET_MIN_BTN](panel);
}

export function getPanelMaxBtn(panel) {
  return PanelActions[PRIVATE.GET_MAX_BTN](panel);
}

export function getPanelCloseBtn(panel) {
  return PanelActions[PRIVATE.GET_CLOSE_BTN](panel);
}

// ============================================================
// 6.9 ★★★ ВСПОМОГАТЕЛЬНЫЕ МЕТОДЫ ★★★
// ============================================================

export function isPanelVisible(panel) {
  if (!VALIDATOR[VALIDATOR_SYMBOLS.IS_VALID_PANEL](panel)) return false;
  const state = getPanelState();
  return panel.style.display !== 'none' && state.visible;
}

export function isPanelMinimized(panel) {
  if (!VALIDATOR[VALIDATOR_SYMBOLS.IS_VALID_PANEL](panel)) return false;
  return panel.classList.contains('minimized');
}

export function isPanelFullscreen(panel) {
  if (!VALIDATOR[VALIDATOR_SYMBOLS.IS_VALID_PANEL](panel)) return false;
  return panel.classList.contains('fullscreen');
}

export function getPanelZIndex(panel) {
  if (!VALIDATOR[VALIDATOR_SYMBOLS.IS_VALID_PANEL](panel)) return 0;
  return parseInt(panel.style.zIndex) || CONFIG[CONFIG_SYMBOLS.Z_INDEX_BASE];
}

// ============================================================
// 6.10 ★★★ УПРАВЛЕНИЕ СОБЫТИЯМИ ★★★
// ============================================================

export function onPanelAction(event, callback) {
  if (typeof callback !== 'function') {
    logger.warn(`⚠️ Некорректный callback для события ${event}`);
    return () => {};
  }

  const handlers = actionsState[PRIVATE.EVENT_HANDLERS];
  if (!handlers.has(event)) {
    handlers.set(event, []);
  }
  handlers.get(event).push(callback);

  return () => offPanelAction(event, callback);
}

export function offPanelAction(event, callback) {
  const handlers = actionsState[PRIVATE.EVENT_HANDLERS];
  if (handlers.has(event)) {
    const list = handlers.get(event);
    const index = list.indexOf(callback);
    if (index !== -1) {
      list.splice(index, 1);
    }
    if (list.length === 0) {
      handlers.delete(event);
    }
  }
}

export function emitPanelAction(event, data) {
  const handlers = actionsState[PRIVATE.EVENT_HANDLERS];
  if (handlers.has(event)) {
    const list = handlers.get(event);
    for (const callback of list) {
      try {
        callback(data);
      } catch (e) {
        logger.error(`❌ Ошибка в обработчике ${event}:`, e.message);
      }
    }
  }
}

// ============================================================
// 6.11 ★★★ ОЧИСТКА И УНИЧТОЖЕНИЕ ★★★
// ============================================================

export function clearPanelTimers() {
  const timers = actionsState[PRIVATE.TIMERS];
  for (const [key, timer] of timers) {
    clearTimeout(timer);
    clearInterval(timer);
  }
  timers.clear();

  if (actionsState[PRIVATE.RAF_ID]) {
    cancelAnimationFrame(actionsState[PRIVATE.RAF_ID]);
    actionsState[PRIVATE.RAF_ID] = null;
  }

  if (actionsState[PRIVATE.ANIMATION_ID]) {
    cancelAnimationFrame(actionsState[PRIVATE.ANIMATION_ID]);
    actionsState[PRIVATE.ANIMATION_ID] = null;
  }
}

export function clearPanelCache() {
  actionsState[PRIVATE.CACHE].clear();
}

export function destroyPanelActions() {
  clearPanelTimers();
  clearPanelCache();
  actionsState[PRIVATE.EVENT_HANDLERS].clear();
  actionsState[PRIVATE.LOG_HISTORY] = [];
  resetPanelState();

  if (typeof window !== 'undefined') {
    delete window[PUBLIC.API];
    delete window[PUBLIC.STATE];
    delete window[PUBLIC.CONFIG];
    delete window[PUBLIC.LOGGER];
    delete window[PUBLIC.EVENTS];
    delete window[PUBLIC.INSTANCE];
  }

  logger.success('🗑️ PanelActions уничтожены');
}

// ============================================================
// 6.12 ★★★ ПОЛУЧЕНИЕ СТАТИСТИКИ ★★★
// ============================================================

export function getPanelActionsStats() {
  const state = getPanelState();
  const cache = actionsState[PRIVATE.CACHE];
  const handlers = actionsState[PRIVATE.EVENT_HANDLERS];
  const history = logger.getHistory();

  return {
    state: { ...state },
    cacheSize: cache.size,
    cacheKeys: Array.from(cache.keys()),
    handlersCount: handlers.size,
    handlersEvents: Array.from(handlers.keys()),
    historyCount: history.length,
    timersCount: actionsState[PRIVATE.TIMERS].size,
    hasRaf: !!actionsState[PRIVATE.RAF_ID],
    hasAnimation: !!actionsState[PRIVATE.ANIMATION_ID],
    version: '2.1.9',
  };
}

// ============================================================
// 7. ★★★ ЗАГРУЗКА СОСТОЯНИЯ ПРИ СТАРТЕ ★★★
// ============================================================

PanelActions[PRIVATE.LOAD_STATE]();

// ============================================================
// 8. ★★★ ГЛОБАЛЬНАЯ РЕГИСТРАЦИЯ ★★★
// ============================================================

if (typeof window !== 'undefined') {
  // Экспорт через публичные символы
  window[PUBLIC.API] = {
    show: showPanel,
    hide: hidePanel,
    toggle: togglePanel,
    minimize: minimizePanel,
    fullscreen: fullscreenPanel,
    close: closePanel,
    focus: focusPanel,
  };

  window[PUBLIC.STATE] = getPanelState;
  window[PUBLIC.CONFIG] = CONFIG;
  window[PUBLIC.LOGGER] = logger;
  window[PUBLIC.EVENTS] = {
    on: onPanelAction,
    off: offPanelAction,
    emit: emitPanelAction,
  };
  window[PUBLIC.INSTANCE] = PanelActions;

  // Глобальные команды
  window.__panelActions = {
    show: showPanel,
    hide: hidePanel,
    toggle: togglePanel,
    minimize: minimizePanel,
    fullscreen: fullscreenPanel,
    close: closePanel,
    focus: focusPanel,
    getState: getPanelState,
    updateState: updatePanelState,
    resetState: resetPanelState,
    loadState: loadPanelState,
    getStats: getPanelActionsStats,
    clearTimers: clearPanelTimers,
    clearCache: clearPanelCache,
    destroy: destroyPanelActions,
    on: onPanelAction,
    off: offPanelAction,
    emit: emitPanelAction,
    getSymbols: () => ({
      PRIVATE: { ...PRIVATE },
      PUBLIC: { ...PUBLIC },
      LOGGER_SYMBOLS: { ...LOGGER_SYMBOLS },
      VALIDATOR_SYMBOLS: { ...VALIDATOR_SYMBOLS },
      CONFIG_SYMBOLS: { ...CONFIG_SYMBOLS },
    }),
  };

  // Баннер
  console.log('╔═══════════════════════════════════════════════════════════════════════════════╗');
  console.log('║              📦 PANEL ACTIONS (100% СИМВОЛЫ) v2.1.9                         ║');
  console.log('╠═══════════════════════════════════════════════════════════════════════════════╣');
  console.log('║  📋 Все логи выводятся в консоль с цветовой разметкой                       ║');
  console.log('║  🔑 Полная изоляция через приватные символы                                 ║');
  console.log('║  🔓 Публичные символы через Symbol.for                                      ║');
  console.log(
    '║  🎯 7 основных действий: show, hide, toggle, minimize, fullscreen, close, focus ║'
  );
  console.log('║  📊 Полное управление состоянием                                            ║');
  console.log('║  🎬 Анимации с настраиваемой длительностью                                  ║');
  console.log('║  📡 Система событий (on/off/emit)                                          ║');
  console.log('║  💾 Кеширование и сохранение состояния                                     ║');
  console.log('║  🧹 Очистка таймеров и ресурсов                                            ║');
  console.log('╚═══════════════════════════════════════════════════════════════════════════════╝');

  console.log('📋 КОМАНДЫ ОТЛАДКИ (__panelActions):');
  console.log('  __panelActions.show(panel)         - показать панель');
  console.log('  __panelActions.hide(panel)         - скрыть панель');
  console.log('  __panelActions.toggle(panel)       - переключить');
  console.log('  __panelActions.minimize(panel)     - свернуть/развернуть');
  console.log('  __panelActions.fullscreen(panel)   - полноэкранный режим');
  console.log('  __panelActions.close(panel)        - закрыть');
  console.log('  __panelActions.focus(panel)        - вывести на передний план');
  console.log('  __panelActions.getState()          - получить состояние');
  console.log('  __panelActions.updateState({})     - обновить состояние');
  console.log('  __panelActions.resetState()        - сбросить состояние');
  console.log('  __panelActions.getStats()          - статистика');
  console.log('  __panelActions.on(event, cb)       - подписка на события');
  console.log('  __panelActions.off(event, cb)      - отписка');
  console.log('  __panelActions.emit(event, data)   - отправка события');
  console.log('  __panelActions.clearTimers()       - очистить таймеры');
  console.log('  __panelActions.clearCache()        - очистить кеш');
  console.log('  __panelActions.destroy()           - уничтожить');
  console.log('  __panelActions.getSymbols()        - получить все символы');
  console.log('');

  console.log('📋 СОБЫТИЯ:');
  console.log('  beforeShow, afterShow, beforeHide, afterHide');
  console.log('  beforeToggle, afterToggle, beforeMinimize, afterMinimize');
  console.log('  beforeFullscreen, afterFullscreen, beforeClose, afterClose');
  console.log('  onFocus');
  console.log('');

  console.log('📋 ПРИВАТНЫХ СИМВОЛОВ:', Object.keys(PRIVATE).length);
  console.log('📋 ПУБЛИЧНЫХ СИМВОЛОВ:', Object.keys(PUBLIC).length);
  console.log('📋 ЛОГГЕР СИМВОЛОВ:', Object.keys(LOGGER_SYMBOLS).length);
  console.log('📋 ВАЛИДАТОР СИМВОЛОВ:', Object.keys(VALIDATOR_SYMBOLS).length);
  console.log('📋 КОНФИГ СИМВОЛОВ:', Object.keys(CONFIG_SYMBOLS).length);
  console.log('═══════════════════════════════════════════════════════════════════════════════');
}

// ============================================================
// 9. ★★★ ЭКСПОРТЫ ★★★
// ============================================================

export {
  PRIVATE,
  PUBLIC,
  LOGGER_SYMBOLS,
  VALIDATOR_SYMBOLS,
  CONFIG_SYMBOLS,
  CONFIG,
  logger as PanelActionsLogger,
  PanelActions,
  // Основные действия
  showPanel,
  hidePanel,
  togglePanel,
  minimizePanel,
  fullscreenPanel,
  closePanel,
  focusPanel,
  // Состояние
  getPanelState,
  updatePanelState,
  resetPanelState,
  loadPanelState,
  // Поиск элементов
  getPanelHeader,
  getPanelBody,
  getPanelResize,
  getPanelMinBtn,
  getPanelMaxBtn,
  getPanelCloseBtn,
  // Вспомогательные
  isPanelVisible,
  isPanelMinimized,
  isPanelFullscreen,
  getPanelZIndex,
  // События
  onPanelAction,
  offPanelAction,
  emitPanelAction,
  // Очистка
  clearPanelTimers,
  clearPanelCache,
  destroyPanelActions,
  // Статистика
  getPanelActionsStats,
};

// ============================================================
// 10. ★★★ ДЕФОЛТНЫЙ ЭКСПОРТ ★★★
// ============================================================

export default {
  show: showPanel,
  hide: hidePanel,
  toggle: togglePanel,
  minimize: minimizePanel,
  fullscreen: fullscreenPanel,
  close: closePanel,
  focus: focusPanel,
  getState: getPanelState,
  updateState: updatePanelState,
  resetState: resetPanelState,
  loadState: loadPanelState,
  getStats: getPanelActionsStats,
  clearTimers: clearPanelTimers,
  clearCache: clearPanelCache,
  destroy: destroyPanelActions,
  on: onPanelAction,
  off: offPanelAction,
  emit: emitPanelAction,
  getPanelHeader,
  getPanelBody,
  getPanelResize,
  getPanelMinBtn,
  getPanelMaxBtn,
  getPanelCloseBtn,
  isVisible: isPanelVisible,
  isMinimized: isPanelMinimized,
  isFullscreen: isPanelFullscreen,
  getZIndex: getPanelZIndex,
  getSymbols: () => ({
    PRIVATE: { ...PRIVATE },
    PUBLIC: { ...PUBLIC },
    LOGGER_SYMBOLS: { ...LOGGER_SYMBOLS },
    VALIDATOR_SYMBOLS: { ...VALIDATOR_SYMBOLS },
    CONFIG_SYMBOLS: { ...CONFIG_SYMBOLS },
  }),
};
