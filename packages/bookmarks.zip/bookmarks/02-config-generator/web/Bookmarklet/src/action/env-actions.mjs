// web/Bookmarklet/src/action/env-actions.mjs
// 100% СИМВОЛЫ — полная изоляция и безопасность
// Действия для ENV панели
// Версия: 2.1.9

import {
  showPanel as baseShow,
  hidePanel as baseHide,
  togglePanel as baseToggle,
  minimizePanel as baseMinimize,
  fullscreenPanel as baseFullscreen,
  closePanel as baseClose,
  focusPanel as baseFocus,
  getPanelState as baseGetState,
  updatePanelState as baseUpdateState,
  resetPanelState as baseResetState,
  getPanelActionsStats as baseGetStats,
  onPanelAction as baseOn,
  offPanelAction as baseOff,
  emitPanelAction as baseEmit,
  clearPanelTimers as baseClearTimers,
  clearPanelCache as baseClearCache,
  destroyPanelActions as baseDestroy,
  PRIVATE as BASE_PRIVATE,
  PUBLIC as BASE_PUBLIC,
  CONFIG as BASE_CONFIG,
} from './panel-actions.mjs';

// ============================================================
// 1. ПРИВАТНЫЕ СИМВОЛЫ (100% изоляция)
// ============================================================

const PRIVATE = {
  // Основные символы ENV
  ENABLE_DEBUG: Symbol('env-actions.enableDebug'),
  DISABLE_DEBUG: Symbol('env-actions.disableDebug'),
  GET_DEBUG_NAMESPACE: Symbol('env-actions.getDebugNamespace'),
  SET_DEBUG_NAMESPACE: Symbol('env-actions.setDebugNamespace'),
  SHOW_CONFIG: Symbol('env-actions.showConfig'),
  UPDATE_UI: Symbol('env-actions.updateUI'),
  UPDATE_BADGE: Symbol('env-actions.updateBadge'),
  UPDATE_PRESETS: Symbol('env-actions.updatePresets'),
  UPDATE_ACTIONS: Symbol('env-actions.updateActions'),
  UPDATE_COMMANDS: Symbol('env-actions.updateCommands'),

  // Символы пресетов
  PRESETS: Symbol('env-actions.presets'),
  PRESETS_GROUPS: Symbol('env-actions.presetsGroups'),
  PRESETS_ACTIVE: Symbol('env-actions.presetsActive'),
  PRESETS_CUSTOM: Symbol('env-actions.presetsCustom'),

  // Символы состояния ENV
  ENV_STATE: Symbol('env-actions.envState'),
  ENV_CONFIG: Symbol('env-actions.envConfig'),
  ENV_CACHE: Symbol('env-actions.envCache'),
  ENV_HISTORY: Symbol('env-actions.envHistory'),

  // Символы UI
  UI_CONTAINER: Symbol('env-actions.uiContainer'),
  UI_BADGE: Symbol('env-actions.uiBadge'),
  UI_PRESET_BUTTONS: Symbol('env-actions.uiPresetButtons'),
  UI_ACTION_BUTTONS: Symbol('env-actions.uiActionButtons'),

  // Символы обработчиков
  HANDLERS: Symbol('env-actions.handlers'),
  HANDLER_PRESET: Symbol('env-actions.handlerPreset'),
  HANDLER_ACTION: Symbol('env-actions.handlerAction'),
  HANDLER_CUSTOM: Symbol('env-actions.handlerCustom'),

  // Символы событий ENV
  ON_ENV_CHANGE: Symbol('env-actions.onEnvChange'),
  ON_PRESET_APPLY: Symbol('env-actions.onPresetApply'),
  ON_CONFIG_CHANGE: Symbol('env-actions.onConfigChange'),
  ON_UI_UPDATE: Symbol('env-actions.onUiUpdate'),

  // Символы утилит
  GET_ENV: Symbol('env-actions.getEnv'),
  GET_DEBUG: Symbol('env-actions.getDebug'),
  IS_DEBUG_ENABLED: Symbol('env-actions.isDebugEnabled'),
  PARSE_NAMESPACE: Symbol('env-actions.parseNamespace'),
  VALIDATE_NAMESPACE: Symbol('env-actions.validateNamespace'),
  NORMALIZE_NAMESPACE: Symbol('env-actions.normalizeNamespace'),
  ESCAPE_HTML: Symbol('env-actions.escapeHtml'),
  GET_TIMESTAMP: Symbol('env-actions.getTimestamp'),

  // Символы хранения
  STORAGE_KEY: Symbol('env-actions.storageKey'),
  SAVE_TO_STORAGE: Symbol('env-actions.saveToStorage'),
  LOAD_FROM_STORAGE: Symbol('env-actions.loadFromStorage'),
  CLEAR_STORAGE: Symbol('env-actions.clearStorage'),

  // Символы логгера
  LOGGER: Symbol('env-actions.logger'),
  LOG_HISTORY: Symbol('env-actions.logHistory'),
  DEBUG_MODE: Symbol('env-actions.debugMode'),

  // Символы таймеров
  TIMERS: Symbol('env-actions.timers'),
  UPDATE_TIMER: Symbol('env-actions.updateTimer'),
  DEBOUNCE_TIMER: Symbol('env-actions.debounceTimer'),
};

// ============================================================
// 2. ПУБЛИЧНЫЕ СИМВОЛЫ (доступны через Symbol.for)
// ============================================================

const PUBLIC = {
  API: Symbol.for('env-actions.api'),
  STATE: Symbol.for('env-actions.state'),
  CONFIG: Symbol.for('env-actions.config'),
  LOGGER: Symbol.for('env-actions.logger'),
  EVENTS: Symbol.for('env-actions.events'),
  INSTANCE: Symbol.for('env-actions.instance'),
  PRESETS: Symbol.for('env-actions.presets'),
};

// ============================================================
// 3. ЛОГГЕР (100% СИМВОЛЫ)
// ============================================================

const LOGGER_SYMBOLS = {
  HISTORY: Symbol('logger.history'),
  MAX_HISTORY: Symbol('logger.maxHistory'),
  DEBUG: Symbol('logger.debug'),
  INSTANCE_ID: Symbol('logger.instanceId'),
  LEVEL: Symbol('logger.level'),
  TIMESTAMP: Symbol('logger.timestamp'),
  COLORS: Symbol('logger.colors'),
  OUTPUT: Symbol('logger.output'),
};

function createEnvLogger(debug = true, instanceId = 'EnvActions') {
  const loggerState = {
    [LOGGER_SYMBOLS.HISTORY]: [],
    [LOGGER_SYMBOLS.MAX_HISTORY]: 200,
    [LOGGER_SYMBOLS.DEBUG]: debug,
    [LOGGER_SYMBOLS.INSTANCE_ID]: instanceId,
    [LOGGER_SYMBOLS.LEVEL]: 'info',
    [LOGGER_SYMBOLS.TIMESTAMP]: true,
    [LOGGER_SYMBOLS.COLORS]: true,
    [LOGGER_SYMBOLS.OUTPUT]: console,
  };

  const logMethod = function (level, message, data = null) {
    if (!this[LOGGER_SYMBOLS.DEBUG] && level !== 'error') {
      return;
    }

    const timestamp = this[LOGGER_SYMBOLS.TIMESTAMP]
      ? `[${new Date().toISOString().slice(11, 23)}]`
      : '';
    const prefix = `${timestamp} [${this[LOGGER_SYMBOLS.INSTANCE_ID]}]`;
    const output = this[LOGGER_SYMBOLS.OUTPUT];

    this[LOGGER_SYMBOLS.HISTORY].push({ timestamp, level, message, data });
    if (this[LOGGER_SYMBOLS.HISTORY].length > this[LOGGER_SYMBOLS.MAX_HISTORY]) {
      this[LOGGER_SYMBOLS.HISTORY].shift();
    }

    const styles = this[LOGGER_SYMBOLS.COLORS]
      ? {
        error: 'color: #ff6b6b; font-weight: bold;',
        warn: 'color: #fdcb6e; font-weight: bold;',
        info: 'color: #74b9ff; font-weight: bold;',
        debug: 'color: #a29bfe;',
        success: 'color: #00b894; font-weight: bold;',
      }
      : {};

    const style = styles[level] || styles.info;

    if (data !== null && data !== undefined) {
      if (typeof data === 'object') {
        output.log(`%c${prefix} ${message}`, style, data);
      } else {
        output.log(`%c${prefix} ${message}`, style, data);
      }
    } else {
      output.log(`%c${prefix} ${message}`, style);
    }
  };

  const boundLog = logMethod.bind(loggerState);

  const logger = {
    error: (msg, d) => boundLog('error', `❌ ${msg}`, d),
    warn: (msg, d) => boundLog('warn', `⚠️ ${msg}`, d),
    info: (msg, d) => boundLog('info', `ℹ️ ${msg}`, d),
    debug: (msg, d) => boundLog('debug', `🔍 ${msg}`, d),
    success: (msg, d) => boundLog('info', `✅ ${msg}`, d),

    header: (title) => {
      const output = loggerState[LOGGER_SYMBOLS.OUTPUT];
      output.log('%c' + '═'.repeat(70), 'color: #636e72;');
      output.log(
        '%c  📦 ' + title,
        'background: #1a1a2e; color: #fff; padding: 4px 12px; border-radius: 4px; font-weight: bold;'
      );
      output.log('%c' + '═'.repeat(70), 'color: #636e72;');
    },

    separator: () => {
      const output = loggerState[LOGGER_SYMBOLS.OUTPUT];
      output.log('%c' + '─'.repeat(70), 'color: #636e72;');
    },

    env: (msg, d) => boundLog('debug', `🌍 ${msg}`, d),
    preset: (msg, d) => boundLog('debug', `📌 ${msg}`, d),

    getHistory: () => [...loggerState[LOGGER_SYMBOLS.HISTORY]],
    clearHistory: () => {
      loggerState[LOGGER_SYMBOLS.HISTORY] = [];
      return logger;
    },
    setDebug: (enabled) => {
      loggerState[LOGGER_SYMBOLS.DEBUG] = enabled;
      return logger;
    },
    setLevel: (level) => {
      loggerState[LOGGER_SYMBOLS.LEVEL] = level;
      return logger;
    },
    getLevel: () => loggerState[LOGGER_SYMBOLS.LEVEL],
    setOutput: (output) => {
      loggerState[LOGGER_SYMBOLS.OUTPUT] = output;
      return logger;
    },
  };

  return logger;
}

// ============================================================
// 4. ВАЛИДАТОР (100% СИМВОЛЫ)
// ============================================================

const VALIDATOR_SYMBOLS = {
  IS_VALID_NAMESPACE: Symbol('validator.isValidNamespace'),
  IS_VALID_PRESET: Symbol('validator.isValidPreset'),
  IS_VALID_CONFIG: Symbol('validator.isValidConfig'),
  IS_VALID_UI_ELEMENT: Symbol('validator.isValidUiElement'),
  IS_VALID_CALLBACK: Symbol('validator.isValidCallback'),
  IS_VALID_ENV_OBJECT: Symbol('validator.isValidEnvObject'),
  IS_VALID_DEBUG_OBJECT: Symbol('validator.isValidDebugObject'),
  SANITIZE_NAMESPACE: Symbol('validator.sanitizeNamespace'),
  NORMALIZE_PRESET: Symbol('validator.normalizePreset'),
};

const VALIDATOR = {
  [VALIDATOR_SYMBOLS.IS_VALID_NAMESPACE]: (ns) => {
    if (!ns || typeof ns !== 'string') return false;
    // Разрешены: буквы, цифры, *, -, _, :
    return /^[a-zA-Z0-9*\-_:,]*$/.test(ns);
  },

  [VALIDATOR_SYMBOLS.IS_VALID_PRESET]: (preset) => {
    return preset &&
      typeof preset === 'object' &&
      typeof preset.name === 'string' &&
      typeof preset.value === 'string' &&
      VALIDATOR[VALIDATOR_SYMBOLS.IS_VALID_NAMESPACE](preset.value);
  },

  [VALIDATOR_SYMBOLS.IS_VALID_CONFIG]: (config) => {
    return config && typeof config === 'object' && typeof config.namespace === 'string';
  },

  [VALIDATOR_SYMBOLS.IS_VALID_UI_ELEMENT]: (el) => {
    return el && typeof el === 'object' && el instanceof HTMLElement;
  },

  [VALIDATOR_SYMBOLS.IS_VALID_CALLBACK]: (cb) => {
    return typeof cb === 'function';
  },

  [VALIDATOR_SYMBOLS.IS_VALID_ENV_OBJECT]: (env) => {
    return env && typeof env === 'object' && typeof env.debug === 'object';
  },

  [VALIDATOR_SYMBOLS.IS_VALID_DEBUG_OBJECT]: (debug) => {
    return debug &&
      typeof debug === 'object' &&
      (typeof debug.enable === 'function' ||
        typeof debug.disable === 'function' ||
        typeof debug.namespace === 'string');
  },

  [VALIDATOR_SYMBOLS.SANITIZE_NAMESPACE]: (ns) => {
    if (!ns || typeof ns !== 'string') return '';
    return ns.replace(/[^a-zA-Z0-9*\-_:,]/g, '').trim();
  },

  [VALIDATOR_SYMBOLS.NORMALIZE_PRESET]: (preset) => {
    if (typeof preset === 'string') {
      return { name: preset, value: preset };
    }
    if (typeof preset === 'object' && preset !== null) {
      return {
        name: preset.name || preset.value || 'custom',
        value: preset.value || preset.name || '',
      };
    }
    return null;
  },
};

// ============================================================
// 5. КОНФИГУРАЦИЯ ENV (100% СИМВОЛЫ)
// ============================================================

const CONFIG_SYMBOLS = {
  DEFAULT_NAMESPACE: Symbol('config.defaultNamespace'),
  STORAGE_KEY: Symbol('config.storageKey'),
  PRESETS_STORAGE_KEY: Symbol('config.presetsStorageKey'),
  MAX_HISTORY: Symbol('config.maxHistory'),
  DEBOUNCE_DELAY: Symbol('config.debounceDelay'),
  UPDATE_INTERVAL: Symbol('config.updateInterval'),
  PRESETS_GROUPS: Symbol('config.presetsGroups'),
  CUSTOM_PRESETS: Symbol('config.customPresets'),
};

const CONFIG = {
  [CONFIG_SYMBOLS.DEFAULT_NAMESPACE]: '',
  [CONFIG_SYMBOLS.STORAGE_KEY]: 'env-actions-state',
  [CONFIG_SYMBOLS.PRESETS_STORAGE_KEY]: 'env-actions-presets',
  [CONFIG_SYMBOLS.MAX_HISTORY]: 100,
  [CONFIG_SYMBOLS.DEBOUNCE_DELAY]: 300,
  [CONFIG_SYMBOLS.UPDATE_INTERVAL]: 1000,
  [CONFIG_SYMBOLS.PRESETS_GROUPS]: [
    {
      name: '🌊 Flow',
      presets: [
        { name: 'Все flow', value: 'wasm:flow:*' },
        { name: 'Flow шаги', value: 'wasm:flow:step:*' },
        { name: 'Flow чекпоинты', value: 'wasm:flow:checkpoint:*' },
        { name: 'Flow ветки', value: 'wasm:flow:branch:*' },
      ],
    },
    {
      name: '🧠 Memory',
      presets: [
        { name: 'Все память', value: 'wasm:memory:*' },
        { name: 'Чтение памяти', value: 'wasm:memory:read:*' },
        { name: 'Запись памяти', value: 'wasm:memory:write:*' },
      ],
    },
    {
      name: '⚡ Generate',
      presets: [
        { name: 'Все генерация', value: 'wasm:generate:*' },
        { name: 'JSON генерация', value: 'wasm:generate:json:*' },
        { name: 'C генерация', value: 'wasm:generate:c:*' },
        { name: 'ENV генерация', value: 'wasm:generate:env:*' },
      ],
    },
    {
      name: '🔧 API',
      presets: [
        { name: 'Все API', value: 'wasm:api:*' },
        { name: 'API вызовы', value: 'wasm:api:call:*' },
        { name: 'API ошибки', value: 'wasm:api:error:*' },
      ],
    },
    {
      name: '🚨 Errors',
      presets: [
        { name: 'Все ошибки', value: 'wasm:error:*' },
        { name: 'Критические', value: 'wasm:error:critical:*' },
      ],
    },
    {
      name: '📊 All',
      presets: [
        { name: 'ВСЕ ЛОГИ', value: 'wasm:*' },
        { name: 'Все кроме памяти', value: '*,-wasm:memory:*' },
        { name: 'Flow+Generate+Memory', value: 'wasm:flow:*,wasm:generate:*,wasm:memory:*' },
        { name: 'Только ошибки', value: 'wasm:error:*' },
      ],
    },
    {
      name: '🎯 Custom',
      presets: [
        { name: 'Отключить всё', value: '' },
        { name: 'Только flow и generate', value: 'wasm:flow:*,wasm:generate:*' },
        { name: 'Только memory и errors', value: 'wasm:memory:*,wasm:error:*' },
        { name: 'Flow + API', value: 'wasm:flow:*,wasm:api:*' },
      ],
    },
    {
      name: '📦 Bookmarklet',
      presets: [
        { name: 'Все bookmarklet', value: 'bookmarklet:*' },
        { name: 'Только main', value: 'bookmarklet:main' },
        { name: 'Только loader', value: 'bookmarklet:loader' },
        { name: 'Только SW', value: 'bookmarklet:sw' },
        { name: 'Только панели', value: 'bookmarklet:panels' },
        { name: 'Все кроме SW', value: 'bookmarklet:*,-bookmarklet:sw' },
      ],
    },
  ],
  [CONFIG_SYMBOLS.CUSTOM_PRESETS]: [],
};

// ============================================================
// 6. ОСНОВНОЙ ОБЪЕКТ ENV ДЕЙСТВИЙ (100% СИМВОЛЫ)
// ============================================================

const EnvActions = {};

// ============================================================
// 6.1 ★★★ ПРИВАТНОЕ СОСТОЯНИЕ ENV ★★★
// ============================================================

const envState = {
  [PRIVATE.ENV_STATE]: {
    namespace: '',
    isEnabled: false,
    timestamp: null,
    lastAction: null,
    history: [],
  },
  [PRIVATE.ENV_CONFIG]: {
    ...CONFIG,
  },
  [PRIVATE.ENV_CACHE]: new Map(),
  [PRIVATE.ENV_HISTORY]: [],
  [PRIVATE.PRESETS]: [...CONFIG[CONFIG_SYMBOLS.PRESETS_GROUPS]],
  [PRIVATE.PRESETS_ACTIVE]: '',
  [PRIVATE.PRESETS_CUSTOM]: [],
  [PRIVATE.TIMERS]: new Map(),
  [PRIVATE.HANDLERS]: new Map(),
  [PRIVATE.LOG_HISTORY]: [],
};

const logger = createEnvLogger(true, 'EnvActions');

// ============================================================
// 6.2 ★★★ ПОЛУЧЕНИЕ ENV ★★★
// ============================================================

EnvActions[PRIVATE.GET_ENV] = function () {
  // Проверяем глобальный ENV
  if (typeof window !== 'undefined' && window.ENV && window.ENV.debug) {
    return window.ENV;
  }
  if (typeof globalThis !== 'undefined' && globalThis.ENV && globalThis.ENV.debug) {
    return globalThis.ENV;
  }
  if (typeof ENV !== 'undefined' && ENV.debug) {
    return ENV;
  }
  return null;
};

EnvActions[PRIVATE.GET_DEBUG] = function () {
  const env = EnvActions[PRIVATE.GET_ENV]();
  if (env && env.debug) {
    return env.debug;
  }

  // Fallback: создаём заглушку
  const debugStub = {
    namespace: '',
    enable: (ns) => {
      logger.debug(`🔍 DEBUG enabled (stub): ${ns}`);
      try {
        localStorage.setItem('debug', ns || '');
      } catch (e) {}
      envState[PRIVATE.ENV_STATE].namespace = ns || '';
      envState[PRIVATE.ENV_STATE].isEnabled = !!ns;
    },
    disable: () => {
      logger.debug('🔍 DEBUG disabled (stub)');
      try {
        localStorage.setItem('debug', '');
      } catch (e) {}
      envState[PRIVATE.ENV_STATE].namespace = '';
      envState[PRIVATE.ENV_STATE].isEnabled = false;
    },
    getConfig: () => ({
      namespace: envState[PRIVATE.ENV_STATE].namespace || '',
      hideDate: false,
      colors: true,
      depth: 2,
      showHidden: false,
    }),
    enabled: () => !!envState[PRIVATE.ENV_STATE].namespace,
    setOptions: (opts) => {
      logger.debug('⚙️ DEBUG options (stub):', opts);
    },
    getHistory: () => [],
    clearHistory: () => {},
    logStatus: () => {
      const ns = envState[PRIVATE.ENV_STATE].namespace || 'off';
      logger.info(`🔍 DEBUG status: ${ns}`);
    },
    help: () => {
      logger.info('📋 DEBUG help: use enable(namespace) or disable()');
    },
  };

  // Сохраняем заглушку в глобальный объект
  if (typeof window !== 'undefined' && !window.ENV) {
    window.ENV = { debug: debugStub };
  }

  return debugStub;
};

// ============================================================
// 6.3 ★★★ УПРАВЛЕНИЕ NAMESPACE ★★★
// ============================================================

EnvActions[PRIVATE.VALIDATE_NAMESPACE] = function (ns) {
  return VALIDATOR[VALIDATOR_SYMBOLS.IS_VALID_NAMESPACE](ns);
};

EnvActions[PRIVATE.NORMALIZE_NAMESPACE] = function (ns) {
  return VALIDATOR[VALIDATOR_SYMBOLS.SANITIZE_NAMESPACE](ns);
};

EnvActions[PRIVATE.PARSE_NAMESPACE] = function (ns) {
  if (!ns || typeof ns !== 'string') return { namespaces: [], isEnabled: false };

  const parts = ns.split(',').map(p => p.trim()).filter(Boolean);
  const enabled = parts.some(p => p !== '' && !p.startsWith('-'));

  return {
    namespaces: parts,
    isEnabled: enabled,
    count: parts.length,
  };
};

EnvActions[PRIVATE.IS_DEBUG_ENABLED] = function (ns) {
  const current = EnvActions[PRIVATE.GET_DEBUG_NAMESPACE]();
  if (!current) return false;
  if (current === '*') return true;

  const parts = current.split(',').map(p => p.trim());
  let enabled = false;

  for (const part of parts) {
    if (part === '*') {
      enabled = true;
    } else if (part.endsWith('*') && ns.startsWith(part.slice(0, -1))) {
      enabled = true;
    } else if (part === ns) {
      enabled = true;
    } else if (part.startsWith('-')) {
      const exclude = part.slice(1);
      if (exclude === '*') {
        enabled = false;
      } else if (exclude.endsWith('*') && ns.startsWith(exclude.slice(0, -1))) {
        enabled = false;
      } else if (exclude === ns) {
        enabled = false;
      }
    }
  }

  return enabled;
};

EnvActions[PRIVATE.GET_DEBUG_NAMESPACE] = function () {
  const debug = EnvActions[PRIVATE.GET_DEBUG]();
  if (debug && typeof debug.namespace !== 'undefined') {
    return debug.namespace || '';
  }
  return envState[PRIVATE.ENV_STATE].namespace || '';
};

EnvActions[PRIVATE.SET_DEBUG_NAMESPACE] = function (ns) {
  const normalized = EnvActions[PRIVATE.NORMALIZE_NAMESPACE](ns);
  const debug = EnvActions[PRIVATE.GET_DEBUG]();

  // Обновляем через debug
  if (debug && typeof debug.enable === 'function') {
    debug.enable(normalized);
  } else if (debug && typeof debug.namespace !== 'undefined') {
    debug.namespace = normalized;
  }

  // Обновляем состояние
  const oldValue = envState[PRIVATE.ENV_STATE].namespace;
  envState[PRIVATE.ENV_STATE].namespace = normalized;
  envState[PRIVATE.ENV_STATE].isEnabled = !!normalized;
  envState[PRIVATE.ENV_STATE].timestamp = Date.now();
  envState[PRIVATE.ENV_STATE].lastAction = 'setNamespace';

  // Сохраняем в localStorage
  try {
    localStorage.setItem('debug', normalized);
  } catch (e) {}

  // Добавляем в историю
  EnvActions[PRIVATE.ADD_TO_HISTORY]('namespace', oldValue, normalized);

  // Вызываем события
  EnvActions[PRIVATE.EMIT_ENV_EVENT]('change', {
    namespace: normalized,
    oldValue,
    timestamp: Date.now(),
  });

  EnvActions[PRIVATE.EMIT_ENV_EVENT]('namespaceChanged', {
    namespace: normalized,
    oldValue,
  });

  // Обновляем UI
  EnvActions[PRIVATE.UPDATE_UI]();

  logger.env(`🌍 DEBUG namespace: ${normalized || 'off'}`);
  return normalized;
};

EnvActions[PRIVATE.ENABLE_DEBUG] = function (ns) {
  const normalized = EnvActions[PRIVATE.NORMALIZE_NAMESPACE](ns || '');
  if (!normalized) {
    logger.warn('⚠️ Пустой namespace, отключаем debug');
    return EnvActions[PRIVATE.DISABLE_DEBUG]();
  }

  logger.debug(`🔍 Включение DEBUG: ${normalized}`);
  return EnvActions[PRIVATE.SET_DEBUG_NAMESPACE](normalized);
};

EnvActions[PRIVATE.DISABLE_DEBUG] = function () {
  logger.debug('🔍 Отключение DEBUG');
  return EnvActions[PRIVATE.SET_DEBUG_NAMESPACE']('');
};

// ============================================================
// 6.4 ★★★ УПРАВЛЕНИЕ ПРЕСЕТАМИ ★★★
// ============================================================

EnvActions[PRIVATE.PRESETS_GROUPS] = function () {
  return [...CONFIG[CONFIG_SYMBOLS.PRESETS_GROUPS]];
};

EnvActions[PRIVATE.PRESETS_CUSTOM] = function () {
  return [...envState[PRIVATE.PRESETS_CUSTOM]];
};

EnvActions[PRIVATE.PRESETS_ACTIVE] = function () {
  return envState[PRIVATE.PRESETS_ACTIVE] || '';
};

EnvActions[PRIVATE.ADD_CUSTOM_PRESET] = function (name, value) {
  if (!name || !value) return false;

  const preset = {
    name: name,
    value: value,
    timestamp: Date.now(),
    custom: true,
  };

  envState[PRIVATE.PRESETS_CUSTOM].push(preset);
  EnvActions[PRIVATE.SAVE_PRESETS_TO_STORAGE]();

  logger.preset(`📌 Добавлен кастомный пресет: ${name} (${value})`);
  EnvActions[PRIVATE.EMIT_ENV_EVENT]('presetAdded', preset);

  return preset;
};

EnvActions[PRIVATE.REMOVE_CUSTOM_PRESET] = function (index) {
  if (index < 0 || index >= envState[PRIVATE.PRESETS_CUSTOM].length) return false;

  const removed = envState[PRIVATE.PRESETS_CUSTOM].splice(index, 1)[0];
  EnvActions[PRIVATE.SAVE_PRESETS_TO_STORAGE]();

  logger.preset(`🗑️ Удалён кастомный пресет: ${removed.name}`);
  EnvActions[PRIVATE.EMIT_ENV_EVENT]('presetRemoved', removed);

  return removed;
};

EnvActions[PRIVATE.GET_ALL_PRESETS] = function () {
  const groups = EnvActions[PRIVATE.PRESETS_GROUPS]();
  const custom = EnvActions[PRIVATE.PRESETS_CUSTOM]();

  return {
    groups: [...groups],
    custom: [...custom],
    all: [
      ...groups.flatMap(g => g.presets.map(p => ({ ...p, group: g.name }))),
      ...custom.map(p => ({ ...p, group: 'Custom' })),
    ],
  };
};

EnvActions[PRIVATE.APPLY_PRESET] = function (preset) {
  const normalized = EnvActions[PRIVATE.NORMALIZE_PRESET](preset);
  if (!normalized) {
    logger.warn('⚠️ Некорректный пресет');
    return false;
  }

  const value = typeof normalized === 'string' ? normalized : normalized.value;
  const name = typeof normalized === 'string' ? normalized : normalized.name;

  envState[PRIVATE.PRESETS_ACTIVE] = value;

  EnvActions[PRIVATE.SET_DEBUG_NAMESPACE](value);

  logger.preset(`📌 Применён пресет: ${name} (${value || 'off'})`);
  EnvActions[PRIVATE.EMIT_ENV_EVENT]('presetApplied', { name, value });

  EnvActions[PRIVATE.UPDATE_UI]();

  return value;
};

EnvActions[PRIVATE.SAVE_PRESETS_TO_STORAGE] = function () {
  try {
    const data = {
      custom: envState[PRIVATE.PRESETS_CUSTOM],
      timestamp: Date.now(),
      version: '2.1.9',
    };
    localStorage.setItem(CONFIG[CONFIG_SYMBOLS.PRESETS_STORAGE_KEY], JSON.stringify(data));
  } catch (e) {
    logger.debug('⚠️ Не удалось сохранить пресеты:', e.message);
  }
};

EnvActions[PRIVATE.LOAD_PRESETS_FROM_STORAGE] = function () {
  try {
    const saved = localStorage.getItem(CONFIG[CONFIG_SYMBOLS.PRESETS_STORAGE_KEY]);
    if (saved) {
      const data = JSON.parse(saved);
      if (data.custom && Array.isArray(data.custom)) {
        envState[PRIVATE.PRESETS_CUSTOM] = data.custom;
        logger.debug(`✅ Загружено ${data.custom.length} кастомных пресетов`);
      }
    }
  } catch (e) {
    logger.debug('⚠️ Не удалось загрузить пресеты:', e.message);
  }
};

// ============================================================
// 6.5 ★★★ ИСТОРИЯ ★★★
// ============================================================

EnvActions[PRIVATE.ADD_TO_HISTORY] = function (type, oldValue, newValue) {
  const entry = {
    type,
    oldValue,
    newValue,
    timestamp: Date.now(),
    namespace: envState[PRIVATE.ENV_STATE].namespace,
  };

  envState[PRIVATE.ENV_HISTORY].push(entry);
  if (envState[PRIVATE.ENV_HISTORY].length > CONFIG[CONFIG_SYMBOLS.MAX_HISTORY]) {
    envState[PRIVATE.ENV_HISTORY].shift();
  }

  logger.debug(`📜 История: ${type} ${oldValue} → ${newValue}`);
};

EnvActions[PRIVATE.GET_HISTORY] = function () {
  return [...envState[PRIVATE.ENV_HISTORY]];
};

EnvActions[PRIVATE.CLEAR_HISTORY] = function () {
  envState[PRIVATE.ENV_HISTORY] = [];
  logger.debug('🗑️ История очищена');
  return true;
};

// ============================================================
// 6.6 ★★★ ПОКАЗ КОНФИГА ★★★
// ============================================================

EnvActions[PRIVATE.SHOW_CONFIG] = function () {
  const namespace = EnvActions[PRIVATE.GET_DEBUG_NAMESPACE]();
  const debug = EnvActions[PRIVATE.GET_DEBUG]();
  const config = debug && typeof debug.getConfig === 'function'
    ? debug.getConfig()
    : { namespace, hideDate: false, colors: true, depth: 2 };

  const history = EnvActions[PRIVATE.GET_HISTORY]();
  const presets = EnvActions[PRIVATE.GET_ALL_PRESETS]();

  const fullConfig = {
    timestamp: new Date().toISOString(),
    namespace,
    config,
    historyCount: history.length,
    presetsCount: presets.all.length,
    customPresetsCount: presets.custom.length,
    isEnabled: !!namespace,
    version: '2.1.9',
    environment: {
      hasWindow: typeof window !== 'undefined',
      hasGlobalENV: !!(typeof window !== 'undefined' && window.ENV),
      hasDebug: !!(EnvActions[PRIVATE.GET_DEBUG]()),
    },
  };

  logger.header('📊 ENV КОНФИГУРАЦИЯ');
  logger.env('🌍 Текущий namespace:', namespace || 'off');
  logger.env('📋 Конфиг:', config);
  logger.env('📜 История:', history.length, 'записей');
  logger.env('📌 Пресеты:', presets.all.length, 'всего');
  logger.env('📌 Кастомные пресеты:', presets.custom.length);

  // Также выводим в консоль таблицей
  console.table({
    'Namespace': namespace || 'off',
    'Enabled': !!namespace,
    'History Records': history.length,
    'Total Presets': presets.all.length,
    'Custom Presets': presets.custom.length,
    'Version': '2.1.9',
  });

  // Выводим историю
  if (history.length > 0) {
    console.log('📜 Последние 10 записей истории:');
    console.table(history.slice(-10));
  }

  EnvActions[PRIVATE.EMIT_ENV_EVENT]('configShown', fullConfig);

  return fullConfig;
};

// ============================================================
// 6.7 ★★★ ОБНОВЛЕНИЕ UI ★★★
// ============================================================

EnvActions[PRIVATE.UPDATE_UI] = function (container) {
  const targetContainer = container || envState[PRIVATE.UI_CONTAINER];
  if (!targetContainer) return;

  EnvActions[PRIVATE.UPDATE_BADGE]();
  EnvActions[PRIVATE.UPDATE_PRESETS](targetContainer);
  EnvActions[PRIVATE.UPDATE_ACTIONS](targetContainer);
  EnvActions[PRIVATE.UPDATE_COMMANDS](targetContainer);

  EnvActions[PRIVATE.EMIT_ENV_EVENT]('uiUpdated', { container: targetContainer });
};

EnvActions[PRIVATE.UPDATE_BADGE] = function () {
  const badge = envState[PRIVATE.UI_BADGE] || document.getElementById('panel-status-badge');
  if (!badge) return;

  const namespace = EnvActions[PRIVATE.GET_DEBUG_NAMESPACE]();
  const isEnabled = !!namespace && namespace !== 'off';

  badge.textContent = namespace || 'off';
  badge.style.background = isEnabled ? 'rgba(0,184,148,0.15)' : 'rgba(255,255,255,0.05)';
  badge.style.color = isEnabled ? '#00b894' : '#636e72';
  badge.style.borderColor = isEnabled ? 'rgba(0,184,148,0.2)' : 'rgba(255,255,255,0.05)';

  envState[PRIVATE.UI_BADGE] = badge;
};

EnvActions[PRIVATE.UPDATE_PRESETS] = function (container) {
  const buttons = container.querySelectorAll('.preset-btn');
  const current = EnvActions[PRIVATE.GET_DEBUG_NAMESPACE]();

  buttons.forEach(btn => {
    const preset = btn.dataset.preset;
    const isActive = preset === current;

    btn.style.background = isActive ? 'rgba(102,126,234,0.3)' : 'rgba(255,255,255,0.03)';
    btn.style.color = isActive ? '#fff' : '#8899bb';
    btn.style.borderColor = isActive ? '#667eea' : 'rgba(255,255,255,0.05)';
    btn.classList.toggle('active', isActive);
  });

  envState[PRIVATE.UI_PRESET_BUTTONS] = buttons;
};

EnvActions[PRIVATE.UPDATE_ACTIONS] = function (container) {
  const buttons = container.querySelectorAll('.action-btn');
  buttons.forEach(btn => {
    const action = btn.dataset.action;
    const isActive = btn.classList.contains('active');

    // Обновляем состояние кнопок действий
    if (action === 'enable-all') {
      const current = EnvActions[PRIVATE.GET_DEBUG_NAMESPACE]();
      btn.classList.toggle('active', !!current);
    }
  });

  envState[PRIVATE.UI_ACTION_BUTTONS] = buttons;
};

EnvActions[PRIVATE.UPDATE_COMMANDS] = function (container) {
  // Команды обновляются по необходимости
  // Можно добавить динамическое обновление команд
};

// ============================================================
// 6.8 ★★★ ХРАНЕНИЕ ★★★
// ============================================================

EnvActions[PRIVATE.SAVE_TO_STORAGE] = function () {
  try {
    const data = {
      state: envState[PRIVATE.ENV_STATE],
      presets: envState[PRIVATE.PRESETS_CUSTOM],
      timestamp: Date.now(),
      version: '2.1.9',
    };
    localStorage.setItem(CONFIG[CONFIG_SYMBOLS.STORAGE_KEY], JSON.stringify(data));
    return true;
  } catch (e) {
    logger.debug('⚠️ Не удалось сохранить состояние:', e.message);
    return false;
  }
};

EnvActions[PRIVATE.LOAD_FROM_STORAGE] = function () {
  try {
    const saved = localStorage.getItem(CONFIG[CONFIG_SYMBOLS.STORAGE_KEY]);
    if (saved) {
      const data = JSON.parse(saved);
      if (data.state) {
        Object.assign(envState[PRIVATE.ENV_STATE], data.state);
        logger.debug('✅ Состояние ENV загружено');
      }
      if (data.presets) {
        envState[PRIVATE.PRESETS_CUSTOM] = data.presets;
        logger.debug(`✅ Загружено ${data.presets.length} кастомных пресетов`);
      }
      return true;
    }
  } catch (e) {
    logger.debug('⚠️ Не удалось загрузить состояние:', e.message);
  }
  return false;
};

EnvActions[PRIVATE.CLEAR_STORAGE] = function () {
  try {
    localStorage.removeItem(CONFIG[CONFIG_SYMBOLS.STORAGE_KEY]);
    localStorage.removeItem(CONFIG[CONFIG_SYMBOLS.PRESETS_STORAGE_KEY]);
    localStorage.removeItem('debug');
    return true;
  } catch (e) {
    logger.debug('⚠️ Не удалось очистить хранилище:', e.message);
    return false;
  }
};

// ============================================================
// 6.9 ★★★ СОБЫТИЯ ENV ★★★
// ============================================================

EnvActions[PRIVATE.ON_ENV_CHANGE] = function (callback) {
  return EnvActions[PRIVATE.EMIT_ENV_EVENT]('change', callback);
};

EnvActions[PRIVATE.ON_PRESET_APPLY] = function (callback) {
  return EnvActions[PRIVATE.EMIT_ENV_EVENT]('presetApply', callback);
};

EnvActions[PRIVATE.ON_CONFIG_CHANGE] = function (callback) {
  return EnvActions[PRIVATE.EMIT_ENV_EVENT]('configChange', callback);
};

EnvActions[PRIVATE.ON_UI_UPDATE] = function (callback) {
  return EnvActions[PRIVATE.EMIT_ENV_EVENT]('uiUpdate', callback);
};

EnvActions[PRIVATE.EMIT_ENV_EVENT] = function (event, data) {
  const handlers = envState[PRIVATE.HANDLERS];
  if (handlers.has(event)) {
    const list = handlers.get(event);
    for (const callback of list) {
      try {
        callback(data);
      } catch (e) {
        logger.error(`❌ Ошибка в обработчике ${event}:`, e.message);
      }
    }
  }

  // Также отправляем через глобальные события
  if (typeof window !== 'undefined') {
    try {
      const customEvent = new CustomEvent(`env:${event}`, {
        detail: { data, timestamp: Date.now() },
      });
      window.dispatchEvent(customEvent);
    } catch (e) {}
  }
};

EnvActions[PRIVATE.ADD_HANDLER] = function (event, callback) {
  if (typeof callback !== 'function') {
    logger.warn(`⚠️ Некорректный callback для события ${event}`);
    return () => {};
  }

  const handlers = envState[PRIVATE.HANDLERS];
  if (!handlers.has(event)) {
    handlers.set(event, []);
  }
  handlers.get(event).push(callback);

  return () => EnvActions[PRIVATE.REMOVE_HANDLER](event, callback);
};

EnvActions[PRIVATE.REMOVE_HANDLER] = function (event, callback) {
  const handlers = envState[PRIVATE.HANDLERS];
  if (handlers.has(event)) {
    const list = handlers.get(event);
    const index = list.indexOf(callback);
    if (index !== -1) {
      list.splice(index, 1);
    }
    if (list.length === 0) {
      handlers.delete(event);
    }
  }
};

// ============================================================
// 6.10 ★★★ ВСПОМОГАТЕЛЬНЫЕ МЕТОДЫ ★★★
// ============================================================

EnvActions[PRIVATE.ESCAPE_HTML] = function (text) {
  if (!text) return '';
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
};

EnvActions[PRIVATE.GET_TIMESTAMP] = function () {
  return new Date().toISOString();
};

// ============================================================
// 7. ★★★ ПУБЛИЧНЫЕ МЕТОДЫ (ОБЕРТКИ СИМВОЛОВ) ★★★
// ============================================================

export function enableDebug(ns) {
  return EnvActions[PRIVATE.ENABLE_DEBUG](ns);
}

export function disableDebug() {
  return EnvActions[PRIVATE.DISABLE_DEBUG]();
}

export function getDebugNamespace() {
  return EnvActions[PRIVATE.GET_DEBUG_NAMESPACE]();
}

export function setDebugNamespace(ns) {
  return EnvActions[PRIVATE.SET_DEBUG_NAMESPACE](ns);
}

export function isDebugEnabled(ns) {
  return EnvActions[PRIVATE.IS_DEBUG_ENABLED](ns);
}

export function showEnvConfig() {
  return EnvActions[PRIVATE.SHOW_CONFIG]();
}

export function updateEnvUI(container) {
  return EnvActions[PRIVATE.UPDATE_UI](container);
}

// ============================================================
// 7.1 ★★★ УПРАВЛЕНИЕ ПРЕСЕТАМИ ★★★
// ============================================================

export function getPresets() {
  return EnvActions[PRIVATE.GET_ALL_PRESETS]();
}

export function applyPreset(preset) {
  return EnvActions[PRIVATE.APPLY_PRESET](preset);
}

export function addCustomPreset(name, value) {
  return EnvActions[PRIVATE.ADD_CUSTOM_PRESET](name, value);
}

export function removeCustomPreset(index) {
  return EnvActions[PRIVATE.REMOVE_CUSTOM_PRESET](index);
}

export function getActivePreset() {
  return EnvActions[PRIVATE.PRESETS_ACTIVE]();
}

// ============================================================
// 7.2 ★★★ УПРАВЛЕНИЕ ИСТОРИЕЙ ★★★
// ============================================================

export function getEnvHistory() {
  return EnvActions[PRIVATE.GET_HISTORY]();
}

export function clearEnvHistory() {
  return EnvActions[PRIVATE.CLEAR_HISTORY]();
}

// ============================================================
// 7.3 ★★★ УПРАВЛЕНИЕ ХРАНИЛИЩЕМ ★★★
// ============================================================

export function saveEnvState() {
  return EnvActions[PRIVATE.SAVE_TO_STORAGE]();
}

export function loadEnvState() {
  return EnvActions[PRIVATE.LOAD_FROM_STORAGE]();
}

export function clearEnvStorage() {
  return EnvActions[PRIVATE.CLEAR_STORAGE]();
}

// ============================================================
// 7.4 ★★★ СОБЫТИЯ ★★★
// ============================================================

export function onEnvEvent(event, callback) {
  return EnvActions[PRIVATE.ADD_HANDLER](event, callback);
}

export function offEnvEvent(event, callback) {
  return EnvActions[PRIVATE.REMOVE_HANDLER](event, callback);
}

export function emitEnvEvent(event, data) {
  return EnvActions[PRIVATE.EMIT_ENV_EVENT](event, data);
}

// ============================================================
// 7.5 ★★★ УПРАВЛЕНИЕ ТАЙМЕРАМИ ★★★
// ============================================================

export function clearEnvTimers() {
  const timers = envState[PRIVATE.TIMERS];
  for (const [key, timer] of timers) {
    clearTimeout(timer);
    clearInterval(timer);
  }
  timers.clear();
  return true;
}

// ============================================================
// 7.6 ★★★ СТАТИСТИКА ★★★
// ============================================================

export function getEnvStats() {
  const presets = EnvActions[PRIVATE.GET_ALL_PRESETS]();
  const history = EnvActions[PRIVATE.GET_HISTORY]();
  const state = envState[PRIVATE.ENV_STATE];

  return {
    namespace: state.namespace || 'off',
    isEnabled: state.isEnabled || false,
    lastAction: state.lastAction || null,
    timestamp: state.timestamp || null,
    historyCount: history.length,
    presetsCount: presets.all.length,
    customPresetsCount: presets.custom.length,
    groupsCount: presets.groups.length,
    handlersCount: envState[PRIVATE.HANDLERS].size,
    cacheSize: envState[PRIVATE.ENV_CACHE].size,
    version: '2.1.9',
  };
}

// ============================================================
// 7.7 ★★★ ОЧИСТКА И УНИЧТОЖЕНИЕ ★★★
// ============================================================

export function clearEnvCache() {
  envState[PRIVATE.ENV_CACHE].clear();
  return true;
}

export function resetEnvState() {
  envState[PRIVATE.ENV_STATE] = {
    namespace: '',
    isEnabled: false,
    timestamp: null,
    lastAction: null,
    history: [],
  };
  envState[PRIVATE.PRESETS_CUSTOM] = [];
  envState[PRIVATE.PRESETS_ACTIVE] = '';
  envState[PRIVATE.ENV_HISTORY] = [];

  EnvActions[PRIVATE.CLEAR_STORAGE]();
  EnvActions[PRIVATE.SAVE_TO_STORAGE]();

  logger.info('🔄 ENV состояние сброшено');
  EnvActions[PRIVATE.EMIT_ENV_EVENT]('reset', { timestamp: Date.now() });

  return true;
}

export function destroyEnvActions() {
  clearEnvTimers();
  clearEnvCache();
  envState[PRIVATE.HANDLERS].clear();
  envState[PRIVATE.ENV_HISTORY] = [];
  envState[PRIVATE.PRESETS_CUSTOM] = [];

  if (typeof window !== 'undefined') {
    delete window[PUBLIC.API];
    delete window[PUBLIC.STATE];
    delete window[PUBLIC.CONFIG];
    delete window[PUBLIC.LOGGER];
    delete window[PUBLIC.EVENTS];
    delete window[PUBLIC.INSTANCE];
    delete window[PUBLIC.PRESETS];
  }

  logger.success('🗑️ EnvActions уничтожены');
  return true;
}

// ============================================================
// 8. ★★★ ЗАГРУЗКА СОСТОЯНИЯ ПРИ СТАРТЕ ★★★
// ============================================================

EnvActions[PRIVATE.LOAD_FROM_STORAGE]();
EnvActions[PRIVATE.LOAD_PRESETS_FROM_STORAGE]();

// Загружаем текущий namespace из localStorage
try {
  const savedDebug = localStorage.getItem('debug');
  if (savedDebug !== null && savedDebug !== envState[PRIVATE.ENV_STATE].namespace) {
    envState[PRIVATE.ENV_STATE].namespace = savedDebug;
    envState[PRIVATE.ENV_STATE].isEnabled = !!savedDebug;
  }
} catch (e) {}

// ============================================================
// 9. ★★★ ГЛОБАЛЬНАЯ РЕГИСТРАЦИЯ ★★★
// ============================================================

if (typeof window !== 'undefined') {
  // Экспорт через публичные символы
  window[PUBLIC.API] = {
    enable: enableDebug,
    disable: disableDebug,
    setNamespace: setDebugNamespace,
    getNamespace: getDebugNamespace,
    isEnabled: isDebugEnabled,
    showConfig: showEnvConfig,
    updateUI: updateEnvUI,
    applyPreset: applyPreset,
    addPreset: addCustomPreset,
    removePreset: removeCustomPreset,
    getPresets: getPresets,
    getHistory: getEnvHistory,
    clearHistory: clearEnvHistory,
    save: saveEnvState,
    load: loadEnvState,
    clear: clearEnvStorage,
    reset: resetEnvState,
    destroy: destroyEnvActions,
    getStats: getEnvStats,
  };

  window[PUBLIC.STATE] = getEnvStats;
  window[PUBLIC.CONFIG] = CONFIG;
  window[PUBLIC.LOGGER] = logger;
  window[PUBLIC.EVENTS] = {
    on: onEnvEvent,
    off: offEnvEvent,
    emit: emitEnvEvent,
  };
  window[PUBLIC.INSTANCE] = EnvActions;
  window[PUBLIC.PRESETS] = getPresets;

  // Глобальные команды
  window.__envActions = {
    enable: enableDebug,
    disable: disableDebug,
    setNamespace: setDebugNamespace,
    getNamespace: getDebugNamespace,
    isEnabled: isDebugEnabled,
    showConfig: showEnvConfig,
    updateUI: updateEnvUI,
    applyPreset: applyPreset,
    addPreset: addCustomPreset,
    removePreset: removeCustomPreset,
    getPresets: getPresets,
    getHistory: getEnvHistory,
    clearHistory: clearEnvHistory,
    save: saveEnvState,
    load: loadEnvState,
    clear: clearEnvStorage,
    reset: resetEnvState,
    destroy: destroyEnvActions,
    getStats: getEnvStats,
    getSymbols: () => ({
      PRIVATE: { ...PRIVATE },
      PUBLIC: { ...PUBLIC },
      LOGGER_SYMBOLS: { ...LOGGER_SYMBOLS },
      VALIDATOR_SYMBOLS: { ...VALIDATOR_SYMBOLS },
      CONFIG_SYMBOLS: { ...CONFIG_SYMBOLS },
    }),
    on: onEnvEvent,
    off: offEnvEvent,
    emit: emitEnvEvent,
  };

  // Баннер
  console.log('╔═══════════════════════════════════════════════════════════════════════════════╗');
  console.log('║              📦 ENV ACTIONS (100% СИМВОЛЫ) v2.1.9                           ║');
  console.log('╠═══════════════════════════════════════════════════════════════════════════════╣');
  console.log('║  📋 Все логи выводятся в консоль с цветовой разметкой                       ║');
  console.log('║  🔑 Полная изоляция через приватные символы                                 ║');
  console.log('║  🔓 Публичные символы через Symbol.for                                      ║');
  console.log('║  🌍 Управление DEBUG namespace                                              ║');
  console.log('║  📌 Система пресетов (встроенные + кастомные)                               ║');
  console.log('║  📜 История изменений                                                       ║');
  console.log('║  💾 Сохранение и загрузка состояния                                         ║');
  console.log('║  📡 Система событий (on/off/emit)                                          ║');
  console.log('║  🎯 8+ действий для управления ENV                                         ║');
  console.log('╚═══════════════════════════════════════════════════════════════════════════════╝');

  console.log('📋 КОМАНДЫ ОТЛАДКИ (__envActions):');
  console.log('  __envActions.enable("wasm:*")      - включить DEBUG');
  console.log('  __envActions.disable()             - отключить DEBUG');
  console.log('  __envActions.getNamespace()        - получить текущий namespace');
  console.log('  __envActions.setNamespace(ns)      - установить namespace');
  console.log('  __envActions.isEnabled(ns)         - проверить включён ли namespace');
  console.log('  __envActions.showConfig()          - показать конфигурацию');
  console.log('  __envActions.updateUI(container)   - обновить UI');
  console.log('  __envActions.applyPreset(preset)   - применить пресет');
  console.log('  __envActions.addPreset(name, value)- добавить кастомный пресет');
  console.log('  __envActions.removePreset(index)   - удалить кастомный пресет');
  console.log('  __envActions.getPresets()          - получить все пресеты');
  console.log('  __envActions.getHistory()          - получить историю');
  console.log('  __envActions.clearHistory()        - очистить историю');
  console.log('  __envActions.save()                - сохранить состояние');
  console.log('  __envActions.load()                - загрузить состояние');
  console.log('  __envActions.clear()               - очистить хранилище');
  console.log('  __envActions.reset()               - сбросить состояние');
  console.log('  __envActions.destroy()             - уничтожить');
  console.log('  __envActions.getStats()            - статистика');
  console.log('  __envActions.on(event, cb)         - подписка на события');
  console.log('  __envActions.off(event, cb)        - отписка');
  console.log('  __envActions.emit(event, data)     - отправка события');
  console.log('  __envActions.getSymbols()          - получить все символы');
  console.log('');

  console.log('📋 СОБЫТИЯ ENV:');
  console.log('  change          - изменение namespace');
  console.log('  namespaceChanged - изменение namespace (детально)');
  console.log('  presetAdded     - добавлен пресет');
  console.log('  presetRemoved   - удалён пресет');
  console.log('  presetApplied   - применён пресет');
  console.log('  configShown     - показана конфигурация');
  console.log('  uiUpdated       - обновлён UI');
  console.log('  reset           - сброс состояния');
  console.log('');

  console.log('📋 ПРИВАТНЫХ СИМВОЛОВ:', Object.keys(PRIVATE).length);
  console.log('📋 ПУБЛИЧНЫХ СИМВОЛОВ:', Object.keys(PUBLIC).length);
  console.log('📋 ЛОГГЕР СИМВОЛОВ:', Object.keys(LOGGER_SYMBOLS).length);
  console.log('📋 ВАЛИДАТОР СИМВОЛОВ:', Object.keys(VALIDATOR_SYMBOLS).length);
  console.log('📋 КОНФИГ СИМВОЛОВ:', Object.keys(CONFIG_SYMBOLS).length);
  console.log('═══════════════════════════════════════════════════════════════════════════════');
}

// ============================================================
// 10. ★★★ ЭКСПОРТЫ ★★★
// ============================================================

export {
  PRIVATE,
  PUBLIC,
  LOGGER_SYMBOLS,
  VALIDATOR_SYMBOLS,
  CONFIG_SYMBOLS,
  CONFIG,
  logger as EnvActionsLogger,
  EnvActions,
  // Основные действия
  enableDebug,
  disableDebug,
  getDebugNamespace,
  setDebugNamespace,
  isDebugEnabled,
  showEnvConfig,
  updateEnvUI,
  // Пресеты
  getPresets,
  applyPreset,
  addCustomPreset,
  removeCustomPreset,
  getActivePreset,
  // История
  getEnvHistory,
  clearEnvHistory,
  // Хранилище
  saveEnvState,
  loadEnvState,
  clearEnvStorage,
  // События
  onEnvEvent,
  offEnvEvent,
  emitEnvEvent,
  // Управление
  clearEnvTimers,
  clearEnvCache,
  resetEnvState,
  destroyEnvActions,
  // Статистика
  getEnvStats,
};

// ============================================================
// 11. ★★★ ДЕФОЛТНЫЙ ЭКСПОРТ ★★★
// ============================================================

export default {
  enable: enableDebug,
  disable: disableDebug,
  getNamespace: getDebugNamespace,
  setNamespace: setDebugNamespace,
  isEnabled: isDebugEnabled,
  showConfig: showEnvConfig,
  updateUI: updateEnvUI,
  // Пресеты
  getPresets,
  applyPreset,
  addPreset: addCustomPreset,
  removePreset: removeCustomPreset,
  getActivePreset,
  // История
  getHistory: getEnvHistory,
  clearHistory: clearEnvHistory,
  // Хранилище
  save: saveEnvState,
  load: loadEnvState,
  clear: clearEnvStorage,
  // Управление
  clearTimers: clearEnvTimers,
  clearCache: clearEnvCache,
  reset: resetEnvState,
  destroy: destroyEnvActions,
  // События
  on: onEnvEvent,
  off: offEnvEvent,
  emit: emitEnvEvent,
  // Статистика
  getStats: getEnvStats,
  getSymbols: () => ({
    PRIVATE: { ...PRIVATE },
    PUBLIC: { ...PUBLIC },
    LOGGER_SYMBOLS: { ...LOGGER_SYMBOLS },
    VALIDATOR_SYMBOLS: { ...VALIDATOR_SYMBOLS },
    CONFIG_SYMBOLS: { ...CONFIG_SYMBOLS },
  }),
};
