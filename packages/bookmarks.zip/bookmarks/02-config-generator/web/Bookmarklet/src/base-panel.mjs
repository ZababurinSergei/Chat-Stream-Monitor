// web/Bookmarklet/src/base-panel.mjs
// Базовый класс для панелей (ENV, Logs, Debug)
// 100% СИМВОЛЫ — полная изоляция и безопасность
// Версия: 2.5.1

// ============================================================
// 1. ПРИВАТНЫЕ СИМВОЛЫ (100% изоляция)
// ============================================================

export const PRIVATE = {
  // ============================================================
  // ОСНОВНЫЕ СИМВОЛЫ (7)
  // ============================================================
  ID: Symbol('base-panel.id'),
  NAME: Symbol('base-panel.name'),
  TYPE: Symbol('base-panel.type'),
  VERSION: Symbol('base-panel.version'),
  PANEL_ID: Symbol('base-panel.panelId'),
  PANEL_TYPE: Symbol('base-panel.panelType'),
  PANEL_PREFIX: Symbol('base-panel.panelPrefix'),

  // ============================================================
  // СОСТОЯНИЕ (5)
  // ============================================================
  IS_VISIBLE: Symbol('base-panel.isVisible'),
  IS_MINIMIZED: Symbol('base-panel.isMinimized'),
  IS_FULLSCREEN: Symbol('base-panel.isFullscreen'),
  INITIALIZED: Symbol('base-panel.initialized'),
  DESTROYED: Symbol('base-panel.destroyed'),

  // ============================================================
  // РАЗМЕРЫ И ПОЗИЦИЯ (3)
  // ============================================================
  POSITION: Symbol('base-panel.position'),
  SIZE: Symbol('base-panel.size'),
  Z_INDEX: Symbol('base-panel.zIndex'),

  // ============================================================
  // DOM ЭЛЕМЕНТЫ (9)
  // ============================================================
  PANEL: Symbol('base-panel.panel'),
  HEADER: Symbol('base-panel.header'),
  BODY: Symbol('base-panel.body'),
  RESIZE_HANDLE: Symbol('base-panel.resizeHandle'),
  MIN_BTN: Symbol('base-panel.minBtn'),
  MAX_BTN: Symbol('base-panel.maxBtn'),
  CLOSE_BTN: Symbol('base-panel.closeBtn'),
  STATUS_BADGE: Symbol('base-panel.statusBadge'),
  CONTROLS: Symbol('base-panel.controls'),

  // ============================================================
  // ДАННЫЕ (10)
  // ============================================================
  DRAG_DATA: Symbol('base-panel.dragData'),
  RESIZE_DATA: Symbol('base-panel.resizeData'),
  RAF_ID: Symbol('base-panel.rafId'),
  LISTENERS: Symbol('base-panel.listeners'),
  EVENT_HANDLERS: Symbol('base-panel.eventHandlers'),
  CACHE: Symbol('base-panel.cache'),
  METADATA: Symbol('base-panel.metadata'),
  CONTEXT: Symbol('base-panel.context'),
  LOG_HISTORY: Symbol('base-panel.logHistory'),
  TIMERS: Symbol('base-panel.timers'),

  // ============================================================
  // ЛОГГЕР И КОЛБЭКИ (4)
  // ============================================================
  LOGGER: Symbol('base-panel.logger'),
  PROPS: Symbol('base-panel.props'),
  RESULT: Symbol('base-panel.result'),
  CALLBACK: Symbol('base-panel.callback'),

  // ============================================================
  // ХРАНИЛИЩЕ (1)
  // ============================================================
  STORE: Symbol('base-panel.store'),

  // ============================================================
  // МЕТОДЫ (23)
  // ============================================================
  BUILD_PANEL: Symbol('base-panel.buildPanel'),
  BUILD_HEADER: Symbol('base-panel.buildHeader'),
  BUILD_BODY: Symbol('base-panel.buildBody'),
  BUILD_RESIZE: Symbol('base-panel.buildResize'),
  SETUP_DRAG: Symbol('base-panel.setupDrag'),
  SETUP_RESIZE: Symbol('base-panel.setupResize'),
  SETUP_HANDLERS: Symbol('base-panel.setupHandlers'),
  SETUP_EVENTS: Symbol('base-panel.setupEvents'),
  FORCE_SHOW: Symbol('base-panel.forceShow'),
  GET_STATE: Symbol('base-panel.getState'),
  EXPORT_SYMBOLS: Symbol('base-panel.exportSymbols'),
  SHOW: Symbol('base-panel.show'),
  HIDE: Symbol('base-panel.hide'),
  TOGGLE: Symbol('base-panel.toggle'),
  GET_ICON: Symbol('base-panel.getIcon'),
  GET_TITLE: Symbol('base-panel.getTitle'),
  HANDLE_CALLBACK: Symbol('base-panel.handleCallback'),
  TOGGLE_MINIMIZE: Symbol('base-panel.toggleMinimize'),
  TOGGLE_FULLSCREEN: Symbol('base-panel.toggleFullscreen'),
  CLOSE_PANEL: Symbol('base-panel.closePanel'),
  CREATE_CONTROL_BTN: Symbol('base-panel.createControlBtn'),
  UPDATE_BADGE: Symbol('base-panel.updateBadge'),
  // ★★★ НОВЫЙ СИМВОЛ ДЛЯ FOCUS ★★★
  FOCUS: Symbol('base-panel.focus'),

  // ============================================================
  // АНИМАЦИИ (5)
  // ============================================================
  ANIMATE_SHOW: Symbol('base-panel.animateShow'),
  ANIMATE_HIDE: Symbol('base-panel.animateHide'),
  ANIMATE_MINIMIZE: Symbol('base-panel.animateMinimize'),
  ANIMATE_FULLSCREEN: Symbol('base-panel.animateFullscreen'),
  ANIMATE_FOCUS: Symbol('base-panel.animateFocus'),

  // ============================================================
  // СОБЫТИЯ (14)
  // ============================================================
  BEFORE_SHOW: Symbol('base-panel.beforeShow'),
  AFTER_SHOW: Symbol('base-panel.afterShow'),
  BEFORE_HIDE: Symbol('base-panel.beforeHide'),
  AFTER_HIDE: Symbol('base-panel.afterHide'),
  BEFORE_TOGGLE: Symbol('base-panel.beforeToggle'),
  AFTER_TOGGLE: Symbol('base-panel.afterToggle'),
  BEFORE_MINIMIZE: Symbol('base-panel.beforeMinimize'),
  AFTER_MINIMIZE: Symbol('base-panel.afterMinimize'),
  BEFORE_FULLSCREEN: Symbol('base-panel.beforeFullscreen'),
  AFTER_FULLSCREEN: Symbol('base-panel.afterFullscreen'),
  BEFORE_CLOSE: Symbol('base-panel.beforeClose'),
  AFTER_CLOSE: Symbol('base-panel.afterClose'),
  ON_FOCUS: Symbol('base-panel.onFocus'),
  ON_STATE_CHANGE: Symbol('base-panel.onStateChange'),

  // ============================================================
  // ВАЛИДАЦИЯ (4)
  // ============================================================
  VALIDATE_PANEL: Symbol('base-panel.validatePanel'),
  VALIDATE_STATE: Symbol('base-panel.validateState'),
  VALIDATE_POSITION: Symbol('base-panel.validatePosition'),
  VALIDATE_SIZE: Symbol('base-panel.validateSize'),

  // ============================================================
  // СОХРАНЕНИЕ (3)
  // ============================================================
  SAVE_STATE: Symbol('base-panel.saveState'),
  LOAD_STATE: Symbol('base-panel.loadState'),
  RESET_STATE: Symbol('base-panel.resetState'),
};

// ============================================================
// 2. ПУБЛИЧНЫЕ СИМВОЛЫ (доступны через Symbol.for)
// ============================================================

export const PUBLIC = {
  // ============================================================
  // ОСНОВНЫЕ API (6)
  // ============================================================
  API: Symbol.for('base-panel.api'),
  STATE: Symbol.for('base-panel.state'),
  CONFIG: Symbol.for('base-panel.config'),
  LOGGER: Symbol.for('base-panel.logger'),
  PANEL: Symbol.for('base-panel.panel'),
  INSTANCE: Symbol.for('base-panel.instance'),

  // ============================================================
  // ДЕЙСТВИЯ (8) - ДОБАВЛЕН FOCUS
  // ============================================================
  SHOW: Symbol.for('base-panel.show'),
  HIDE: Symbol.for('base-panel.hide'),
  TOGGLE: Symbol.for('base-panel.toggle'),
  MINIMIZE: Symbol.for('base-panel.minimize'),
  FULLSCREEN: Symbol.for('base-panel.fullscreen'),
  CLOSE: Symbol.for('base-panel.close'),
  FOCUS: Symbol.for('base-panel.focus'),

  // ============================================================
  // СОБЫТИЯ (1)
  // ============================================================
  EVENTS: Symbol.for('base-panel.events'),
};

// ============================================================
// 3. ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ
// ============================================================

export function generateInstanceId() {
  return 'panel-' + Date.now() + '-' + Math.random().toString(36).substr(2, 4);
}

export function generatePanelId(prefix = 'panel') {
  const name = (typeof document !== 'undefined' && document.title) || 'panel';
  const cleanName = name
      .toLowerCase()
      .replace(/[^a-z0-9]/g, '-')
      .replace(/-+/g, '-')
      .slice(0, 20);
  const timestamp = Date.now().toString(36).slice(-4);
  const random = Math.random().toString(36).slice(2, 5);
  return `${prefix}-${cleanName || 'panel'}-${timestamp}-${random}`;
}

export function createLogger(instanceId) {
  return {
    error: (msg, d) => console.error(`[Panel:${instanceId?.slice(-6) || 'unknown'}] ❌ ${msg}`, d || ''),
    warn: (msg, d) => console.warn(`[Panel:${instanceId?.slice(-6) || 'unknown'}] ⚠️ ${msg}`, d || ''),
    info: (msg, d) => console.log(`[Panel:${instanceId?.slice(-6) || 'unknown'}] ℹ️ ${msg}`, d || ''),
    success: (msg, d) => console.log(`[Panel:${instanceId?.slice(-6) || 'unknown'}] ✅ ${msg}`, d || ''),
    debug: (msg, d) => console.log(`[Panel:${instanceId?.slice(-6) || 'unknown'}] 🔍 ${msg}`, d || ''),
    trace: (msg, d) => console.log(`[Panel:${instanceId?.slice(-6) || 'unknown'}] 🔎 ${msg}`, d || ''),
  };
}

// ============================================================
// 4. ЛОГГЕР С ПРИВЯЗКОЙ КОНТЕКСТА
// ============================================================

const LOGGER_SYMBOLS = {
  HISTORY: Symbol('logger.history'),
  MAX_HISTORY: Symbol('logger.maxHistory'),
  DEBUG: Symbol('logger.debug'),
  INSTANCE_ID: Symbol('logger.instanceId'),
  LEVEL: Symbol('logger.level'),
  TIMESTAMP: Symbol('logger.timestamp'),
  COLORS: Symbol('logger.colors'),
  OUTPUT: Symbol('logger.output'),
};

function createPanelLogger(debug = true, instanceId = 'Panel') {
  const state = {
    [LOGGER_SYMBOLS.HISTORY]: [],
    [LOGGER_SYMBOLS.MAX_HISTORY]: 200,
    [LOGGER_SYMBOLS.DEBUG]: debug,
    [LOGGER_SYMBOLS.INSTANCE_ID]: instanceId,
    [LOGGER_SYMBOLS.LEVEL]: 'info',
    [LOGGER_SYMBOLS.TIMESTAMP]: true,
    [LOGGER_SYMBOLS.COLORS]: true,
    [LOGGER_SYMBOLS.OUTPUT]: console,
  };

  const logMethod = function (level, message, data = null) {
    if (!this[LOGGER_SYMBOLS.DEBUG] && level !== 'error' && level !== 'fatal') return;
    if (this[LOGGER_SYMBOLS.SILENT]) return;

    const levels = { error: 0, warn: 1, info: 2, debug: 3, trace: 4, verbose: 5 };
    const currentLevel = levels[this[LOGGER_SYMBOLS.LEVEL]] || 2;
    const messageLevel = levels[level] || 2;
    if (messageLevel > currentLevel) return;

    const timestamp = this[LOGGER_SYMBOLS.TIMESTAMP]
        ? `[${new Date().toISOString().slice(11, 23)}]`
        : '';
    const prefix = `${timestamp} [${this[LOGGER_SYMBOLS.INSTANCE_ID]}]`;
    const output = this[LOGGER_SYMBOLS.OUTPUT];

    this[LOGGER_SYMBOLS.HISTORY].push({ timestamp, level, message, data });
    if (this[LOGGER_SYMBOLS.HISTORY].length > this[LOGGER_SYMBOLS.MAX_HISTORY]) {
      this[LOGGER_SYMBOLS.HISTORY].shift();
    }

    const styles = this[LOGGER_SYMBOLS.COLORS]
        ? {
          error: 'color: #ff6b6b; font-weight: bold;',
          fatal: 'color: #ff0000; font-weight: bold; font-size: 14px;',
          warn: 'color: #fdcb6e; font-weight: bold;',
          info: 'color: #74b9ff; font-weight: bold;',
          debug: 'color: #a29bfe;',
          trace: 'color: #dfe6e9; font-style: italic;',
          verbose: 'color: #636e72; font-size: 11px;',
          success: 'color: #00b894; font-weight: bold;',
        }
        : {};

    const style = styles[level] || styles.info;

    if (data !== null && data !== undefined) {
      if (typeof data === 'object') {
        output.log(`%c${prefix} ${message}`, style, data);
      } else {
        output.log(`%c${prefix} ${message}`, style, data);
      }
    } else {
      output.log(`%c${prefix} ${message}`, style);
    }
  };

  const boundLog = logMethod.bind(state);

  const logger = {
    error: (msg, d) => boundLog('error', `❌ ${msg}`, d),
    fatal: (msg, d) => boundLog('fatal', `💀 ${msg}`, d),
    warn: (msg, d) => boundLog('warn', `⚠️ ${msg}`, d),
    info: (msg, d) => boundLog('info', `ℹ️ ${msg}`, d),
    debug: (msg, d) => boundLog('debug', `🔍 ${msg}`, d),
    trace: (msg, d) => boundLog('trace', `🔎 ${msg}`, d),
    verbose: (msg, d) => boundLog('verbose', `📝 ${msg}`, d),
    success: (msg, d) => boundLog('info', `✅ ${msg}`, d),

    header: (title) => {
      const output = state[LOGGER_SYMBOLS.OUTPUT];
      output.log('%c' + '═'.repeat(70), 'color: #636e72;');
      output.log(
          '%c  📦 ' + title,
          'background: #1a1a2e; color: #fff; padding: 4px 12px; border-radius: 4px; font-weight: bold;'
      );
      output.log('%c' + '═'.repeat(70), 'color: #636e72;');
    },

    separator: () => {
      const output = state[LOGGER_SYMBOLS.OUTPUT];
      output.log('%c' + '─'.repeat(70), 'color: #636e72;');
    },

    subheader: (title) => {
      const output = state[LOGGER_SYMBOLS.OUTPUT];
      output.log('%c' + '┌' + '─'.repeat(68) + '┐', 'color: #636e72;');
      output.log(`%c│  📌 ${title.padEnd(65)}│`, 'color: #74b9ff;');
      output.log('%c' + '└' + '─'.repeat(68) + '┘', 'color: #636e72;');
    },

    getHistory: () => [...state[LOGGER_SYMBOLS.HISTORY]],
    clearHistory: () => {
      state[LOGGER_SYMBOLS.HISTORY] = [];
      return logger;
    },

    setDebug: (enabled) => {
      state[LOGGER_SYMBOLS.DEBUG] = enabled;
      return logger;
    },

    setLevel: (level) => {
      state[LOGGER_SYMBOLS.LEVEL] = level;
      return logger;
    },

    getLevel: () => state[LOGGER_SYMBOLS.LEVEL],

    setOutput: (output) => {
      state[LOGGER_SYMBOLS.OUTPUT] = output;
      return logger;
    },

    setTimestamp: (enabled) => {
      state[LOGGER_SYMBOLS.TIMESTAMP] = enabled;
      return logger;
    },

    setColors: (enabled) => {
      state[LOGGER_SYMBOLS.COLORS] = enabled;
      return logger;
    },

    child: (name) => {
      return createPanelLogger(state[LOGGER_SYMBOLS.DEBUG], `${state[LOGGER_SYMBOLS.INSTANCE_ID]}:${name}`);
    },

    getStats: () => {
      const history = state[LOGGER_SYMBOLS.HISTORY];
      const stats = {
        total: history.length,
        byLevel: {},
        oldest: null,
        newest: null,
      };
      for (const entry of history) {
        stats.byLevel[entry.level] = (stats.byLevel[entry.level] || 0) + 1;
      }
      if (history.length > 0) {
        stats.oldest = history[0].timestamp;
        stats.newest = history[history.length - 1].timestamp;
      }
      return stats;
    },
  };

  return logger;
}

// ============================================================
// 5. БАЗОВЫЙ КЛАСС PANEL (100% СИМВОЛЫ)
// ============================================================

export class BasePanel {
  constructor(options = {}) {
    // ============================================================
    // 5.1 ИНИЦИАЛИЗАЦИЯ ХРАНИЛИЩА
    // ============================================================
    this[PRIVATE.STORE] = {};

    // ============================================================
    // 5.2 ОСНОВНЫЕ СВОЙСТВА
    // ============================================================
    this[PRIVATE.STORE][PRIVATE.ID] = options.id || generateInstanceId();
    this[PRIVATE.STORE][PRIVATE.PANEL_ID] = options.panelId || generatePanelId(options.panelPrefix || 'panel');
    this[PRIVATE.STORE][PRIVATE.PANEL_PREFIX] = options.panelPrefix || 'panel';
    this[PRIVATE.STORE][PRIVATE.NAME] = options.name || (typeof document !== 'undefined' && document.title) || 'Panel';
    this[PRIVATE.STORE][PRIVATE.TYPE] = options.type || options.panelType || 'base';
    this[PRIVATE.STORE][PRIVATE.PANEL_TYPE] = options.panelType || this[PRIVATE.STORE][PRIVATE.TYPE];
    this[PRIVATE.STORE][PRIVATE.VERSION] = options.version || '2.5.1';

    // ============================================================
    // 5.3 СОСТОЯНИЕ
    // ============================================================
    this[PRIVATE.STORE][PRIVATE.IS_VISIBLE] = false;
    this[PRIVATE.STORE][PRIVATE.IS_MINIMIZED] = false;
    this[PRIVATE.STORE][PRIVATE.IS_FULLSCREEN] = false;
    this[PRIVATE.STORE][PRIVATE.INITIALIZED] = false;
    this[PRIVATE.STORE][PRIVATE.DESTROYED] = false;

    // ============================================================
    // 5.4 РАЗМЕРЫ И ПОЗИЦИЯ
    // ============================================================
    this[PRIVATE.STORE][PRIVATE.POSITION] = options.position || { x: 100, y: 100 };
    this[PRIVATE.STORE][PRIVATE.SIZE] = options.size || { width: 420, height: 520 };
    this[PRIVATE.STORE][PRIVATE.Z_INDEX] = options.zIndex || 99996;

    // ============================================================
    // 5.5 DOM ЭЛЕМЕНТЫ
    // ============================================================
    this[PRIVATE.STORE][PRIVATE.PANEL] = null;
    this[PRIVATE.STORE][PRIVATE.HEADER] = null;
    this[PRIVATE.STORE][PRIVATE.BODY] = null;
    this[PRIVATE.STORE][PRIVATE.RESIZE_HANDLE] = null;
    this[PRIVATE.STORE][PRIVATE.MIN_BTN] = null;
    this[PRIVATE.STORE][PRIVATE.MAX_BTN] = null;
    this[PRIVATE.STORE][PRIVATE.CLOSE_BTN] = null;
    this[PRIVATE.STORE][PRIVATE.STATUS_BADGE] = null;
    this[PRIVATE.STORE][PRIVATE.CONTROLS] = null;

    // ============================================================
    // 5.6 ДАННЫЕ
    // ============================================================
    this[PRIVATE.STORE][PRIVATE.DRAG_DATA] = null;
    this[PRIVATE.STORE][PRIVATE.RESIZE_DATA] = null;
    this[PRIVATE.STORE][PRIVATE.RAF_ID] = null;
    this[PRIVATE.STORE][PRIVATE.LISTENERS] = [];
    this[PRIVATE.STORE][PRIVATE.EVENT_HANDLERS] = new Map();
    this[PRIVATE.STORE][PRIVATE.CACHE] = new Map();
    this[PRIVATE.STORE][PRIVATE.METADATA] = {
      created: Date.now(),
      lastAccess: Date.now(),
      lastUpdate: Date.now(),
      runCount: 0,
      errorCount: 0,
      toggleCount: 0,
      showCount: 0,
      hideCount: 0,
    };
    this[PRIVATE.STORE][PRIVATE.CONTEXT] = {
      url: typeof window !== 'undefined' ? window.location.href : '',
      title: typeof window !== 'undefined' ? document.title : '',
      userAgent: typeof navigator !== 'undefined' ? navigator.userAgent : '',
      platform: typeof navigator !== 'undefined' ? navigator.platform : '',
    };
    this[PRIVATE.STORE][PRIVATE.LOG_HISTORY] = [];
    this[PRIVATE.STORE][PRIVATE.TIMERS] = new Map();

    // ============================================================
    // 5.7 ЛОГГЕР И КОЛБЭКИ
    // ============================================================
    this[PRIVATE.STORE][PRIVATE.LOGGER] = options.logger || createPanelLogger(options.debug !== false, this[PRIVATE.STORE][PRIVATE.ID]);
    this[PRIVATE.STORE][PRIVATE.RESULT] = null;
    this[PRIVATE.STORE][PRIVATE.CALLBACK] = options.callback || null;

    const logger = this[PRIVATE.STORE][PRIVATE.LOGGER];
    logger.header('СОЗДАНИЕ ПАНЕЛИ (100% СИМВОЛЫ)');
    logger.info(`📌 Panel ID: ${this[PRIVATE.STORE][PRIVATE.PANEL_ID]}`);
    logger.info(`📌 Instance ID: ${this[PRIVATE.STORE][PRIVATE.ID]}`);
    logger.info(`📌 Тип: ${this[PRIVATE.STORE][PRIVATE.PANEL_TYPE]}`);
    logger.info(`📌 Callback: ${typeof this[PRIVATE.STORE][PRIVATE.CALLBACK] === 'function' ? '✅' : '❌'}`);

    // ============================================================
    // 5.8 ПОСТРОЕНИЕ
    // ============================================================
    this[PRIVATE.BUILD_PANEL]();
    this[PRIVATE.EXPORT_SYMBOLS]();
    this[PRIVATE.SETUP_EVENTS]();

    // ============================================================
    // 5.9 ПРИНУДИТЕЛЬНЫЙ ПОКАЗ
    // ============================================================
    setTimeout(() => {
      this[PRIVATE.FORCE_SHOW]();
    }, 50);

    // ============================================================
    // 5.10 ЗАГРУЗКА СОСТОЯНИЯ
    // ============================================================
    this[PRIVATE.LOAD_STATE]();

    logger.success(`✅ ${this[PRIVATE.STORE][PRIVATE.NAME]} создан`);
    logger.header('ГОТОВ');
  }

  // ============================================================
  // 6. ГЕТТЕРЫ (ТОЛЬКО ДЛЯ ЧТЕНИЯ)
  // ============================================================

  get [PRIVATE.ID]() { return this[PRIVATE.STORE][PRIVATE.ID]; }
  get [PRIVATE.NAME]() { return this[PRIVATE.STORE][PRIVATE.NAME]; }
  get [PRIVATE.TYPE]() { return this[PRIVATE.STORE][PRIVATE.TYPE]; }
  get [PRIVATE.VERSION]() { return this[PRIVATE.STORE][PRIVATE.VERSION]; }
  get [PRIVATE.PANEL_ID]() { return this[PRIVATE.STORE][PRIVATE.PANEL_ID]; }
  get [PRIVATE.PANEL_TYPE]() { return this[PRIVATE.STORE][PRIVATE.PANEL_TYPE]; }
  get [PRIVATE.PANEL_PREFIX]() { return this[PRIVATE.STORE][PRIVATE.PANEL_PREFIX]; }

  get [PRIVATE.IS_VISIBLE]() { return this[PRIVATE.STORE][PRIVATE.IS_VISIBLE]; }
  get [PRIVATE.IS_MINIMIZED]() { return this[PRIVATE.STORE][PRIVATE.IS_MINIMIZED]; }
  get [PRIVATE.IS_FULLSCREEN]() { return this[PRIVATE.STORE][PRIVATE.IS_FULLSCREEN]; }
  get [PRIVATE.INITIALIZED]() { return this[PRIVATE.STORE][PRIVATE.INITIALIZED]; }
  get [PRIVATE.DESTROYED]() { return this[PRIVATE.STORE][PRIVATE.DESTROYED]; }

  get [PRIVATE.POSITION]() { return this[PRIVATE.STORE][PRIVATE.POSITION]; }
  get [PRIVATE.SIZE]() { return this[PRIVATE.STORE][PRIVATE.SIZE]; }
  get [PRIVATE.Z_INDEX]() { return this[PRIVATE.STORE][PRIVATE.Z_INDEX]; }

  get [PRIVATE.PANEL]() { return this[PRIVATE.STORE][PRIVATE.PANEL]; }
  get [PRIVATE.HEADER]() { return this[PRIVATE.STORE][PRIVATE.HEADER]; }
  get [PRIVATE.BODY]() { return this[PRIVATE.STORE][PRIVATE.BODY]; }
  get [PRIVATE.RESIZE_HANDLE]() { return this[PRIVATE.STORE][PRIVATE.RESIZE_HANDLE]; }
  get [PRIVATE.MIN_BTN]() { return this[PRIVATE.STORE][PRIVATE.MIN_BTN]; }
  get [PRIVATE.MAX_BTN]() { return this[PRIVATE.STORE][PRIVATE.MAX_BTN]; }
  get [PRIVATE.CLOSE_BTN]() { return this[PRIVATE.STORE][PRIVATE.CLOSE_BTN]; }
  get [PRIVATE.STATUS_BADGE]() { return this[PRIVATE.STORE][PRIVATE.STATUS_BADGE]; }
  get [PRIVATE.CONTROLS]() { return this[PRIVATE.STORE][PRIVATE.CONTROLS]; }

  get [PRIVATE.DRAG_DATA]() { return this[PRIVATE.STORE][PRIVATE.DRAG_DATA]; }
  get [PRIVATE.RESIZE_DATA]() { return this[PRIVATE.STORE][PRIVATE.RESIZE_DATA]; }
  get [PRIVATE.RAF_ID]() { return this[PRIVATE.STORE][PRIVATE.RAF_ID]; }
  get [PRIVATE.LISTENERS]() { return this[PRIVATE.STORE][PRIVATE.LISTENERS]; }
  get [PRIVATE.EVENT_HANDLERS]() { return this[PRIVATE.STORE][PRIVATE.EVENT_HANDLERS]; }
  get [PRIVATE.CACHE]() { return this[PRIVATE.STORE][PRIVATE.CACHE]; }
  get [PRIVATE.METADATA]() { return this[PRIVATE.STORE][PRIVATE.METADATA]; }
  get [PRIVATE.CONTEXT]() { return this[PRIVATE.STORE][PRIVATE.CONTEXT]; }
  get [PRIVATE.LOG_HISTORY]() { return this[PRIVATE.STORE][PRIVATE.LOG_HISTORY]; }
  get [PRIVATE.TIMERS]() { return this[PRIVATE.STORE][PRIVATE.TIMERS]; }

  get [PRIVATE.LOGGER]() { return this[PRIVATE.STORE][PRIVATE.LOGGER]; }
  get [PRIVATE.PROPS]() { return this[PRIVATE.STORE][PRIVATE.PROPS]; }
  get [PRIVATE.RESULT]() { return this[PRIVATE.STORE][PRIVATE.RESULT]; }
  get [PRIVATE.CALLBACK]() { return this[PRIVATE.STORE][PRIVATE.CALLBACK]; }

  // ============================================================
  // 7. СЕТТЕРЫ (ДЛЯ ЗАПИСИ)
  // ============================================================

  set [PRIVATE.IS_VISIBLE](value) { this[PRIVATE.STORE][PRIVATE.IS_VISIBLE] = value; }
  set [PRIVATE.IS_MINIMIZED](value) { this[PRIVATE.STORE][PRIVATE.IS_MINIMIZED] = value; }
  set [PRIVATE.IS_FULLSCREEN](value) { this[PRIVATE.STORE][PRIVATE.IS_FULLSCREEN] = value; }
  set [PRIVATE.INITIALIZED](value) { this[PRIVATE.STORE][PRIVATE.INITIALIZED] = value; }
  set [PRIVATE.DESTROYED](value) { this[PRIVATE.STORE][PRIVATE.DESTROYED] = value; }

  set [PRIVATE.POSITION](value) { this[PRIVATE.STORE][PRIVATE.POSITION] = value; }
  set [PRIVATE.SIZE](value) { this[PRIVATE.STORE][PRIVATE.SIZE] = value; }
  set [PRIVATE.Z_INDEX](value) { this[PRIVATE.STORE][PRIVATE.Z_INDEX] = value; }

  set [PRIVATE.PANEL](value) { this[PRIVATE.STORE][PRIVATE.PANEL] = value; }
  set [PRIVATE.HEADER](value) { this[PRIVATE.STORE][PRIVATE.HEADER] = value; }
  set [PRIVATE.BODY](value) { this[PRIVATE.STORE][PRIVATE.BODY] = value; }
  set [PRIVATE.RESIZE_HANDLE](value) { this[PRIVATE.STORE][PRIVATE.RESIZE_HANDLE] = value; }
  set [PRIVATE.MIN_BTN](value) { this[PRIVATE.STORE][PRIVATE.MIN_BTN] = value; }
  set [PRIVATE.MAX_BTN](value) { this[PRIVATE.STORE][PRIVATE.MAX_BTN] = value; }
  set [PRIVATE.CLOSE_BTN](value) { this[PRIVATE.STORE][PRIVATE.CLOSE_BTN] = value; }
  set [PRIVATE.STATUS_BADGE](value) { this[PRIVATE.STORE][PRIVATE.STATUS_BADGE] = value; }
  set [PRIVATE.CONTROLS](value) { this[PRIVATE.STORE][PRIVATE.CONTROLS] = value; }

  set [PRIVATE.DRAG_DATA](value) { this[PRIVATE.STORE][PRIVATE.DRAG_DATA] = value; }
  set [PRIVATE.RESIZE_DATA](value) { this[PRIVATE.STORE][PRIVATE.RESIZE_DATA] = value; }
  set [PRIVATE.RAF_ID](value) { this[PRIVATE.STORE][PRIVATE.RAF_ID] = value; }
  set [PRIVATE.LISTENERS](value) { this[PRIVATE.STORE][PRIVATE.LISTENERS] = value; }
  set [PRIVATE.EVENT_HANDLERS](value) { this[PRIVATE.STORE][PRIVATE.EVENT_HANDLERS] = value; }
  set [PRIVATE.CACHE](value) { this[PRIVATE.STORE][PRIVATE.CACHE] = value; }
  set [PRIVATE.METADATA](value) { this[PRIVATE.STORE][PRIVATE.METADATA] = value; }
  set [PRIVATE.CONTEXT](value) { this[PRIVATE.STORE][PRIVATE.CONTEXT] = value; }
  set [PRIVATE.LOG_HISTORY](value) { this[PRIVATE.STORE][PRIVATE.LOG_HISTORY] = value; }
  set [PRIVATE.TIMERS](value) { this[PRIVATE.STORE][PRIVATE.TIMERS] = value; }

  set [PRIVATE.LOGGER](value) { this[PRIVATE.STORE][PRIVATE.LOGGER] = value; }
  set [PRIVATE.PROPS](value) { this[PRIVATE.STORE][PRIVATE.PROPS] = value; }
  set [PRIVATE.RESULT](value) { this[PRIVATE.STORE][PRIVATE.RESULT] = value; }
  set [PRIVATE.CALLBACK](value) { this[PRIVATE.STORE][PRIVATE.CALLBACK] = value; }

  // ============================================================
  // 8. СТАТИЧЕСКИЕ МЕТОДЫ
  // ============================================================

  static getPrivate() {
    return PRIVATE;
  }

  static getPublic() {
    return PUBLIC;
  }

  static getSymbols() {
    return { PRIVATE, PUBLIC };
  }

  // ============================================================
  // 9. ПОСТРОЕНИЕ ПАНЕЛИ
  // ============================================================

  [PRIVATE.BUILD_PANEL]() {
    const logger = this[PRIVATE.STORE][PRIVATE.LOGGER];
    logger.info('🏗️ Построение панели...');

    const panelId = this[PRIVATE.STORE][PRIVATE.PANEL_ID];
    const existingPanel = document.getElementById(panelId);

    if (existingPanel) {
      logger.success('✅ Панель уже существует', { id: panelId });
      this[PRIVATE.STORE][PRIVATE.PANEL] = existingPanel;
      this[PRIVATE.STORE][PRIVATE.IS_VISIBLE] = existingPanel.style.display !== 'none';
      this[PRIVATE.STORE][PRIVATE.INITIALIZED] = true;
      this[PRIVATE.HANDLE_CALLBACK]({ success: true, action: 'existing', panel: existingPanel });
      return;
    }

    const panel = document.createElement('div');
    panel.id = panelId;
    panel.dataset.panelType = this[PRIVATE.STORE][PRIVATE.PANEL_TYPE];
    panel.dataset.instanceId = this[PRIVATE.STORE][PRIVATE.ID];

    Object.assign(panel.style, {
      position: 'fixed',
      left: this[PRIVATE.STORE][PRIVATE.POSITION].x + 'px',
      top: this[PRIVATE.STORE][PRIVATE.POSITION].y + 'px',
      width: this[PRIVATE.STORE][PRIVATE.SIZE].width + 'px',
      height: this[PRIVATE.STORE][PRIVATE.SIZE].height + 'px',
      zIndex: this[PRIVATE.STORE][PRIVATE.Z_INDEX],
      background: 'rgba(26, 26, 46, 0.96)',
      backdropFilter: 'blur(20px)',
      border: '1px solid rgba(255,255,255,0.08)',
      borderRadius: '12px',
      color: '#fff',
      fontFamily: 'Segoe UI, system-ui, sans-serif',
      fontSize: '13px',
      boxShadow: '0 20px 60px rgba(0,0,0,0.8)',
      display: 'flex',
      flexDirection: 'column',
      overflow: 'hidden',
      minWidth: '320px',
      minHeight: '300px',
      maxWidth: '90vw',
      maxHeight: '90vh',
      userSelect: 'none',
    });

    // Шапка
    const header = this[PRIVATE.BUILD_HEADER]();
    panel.appendChild(header);
    this[PRIVATE.STORE][PRIVATE.HEADER] = header;

    // Тело
    const body = this[PRIVATE.BUILD_BODY]();
    panel.appendChild(body);
    this[PRIVATE.STORE][PRIVATE.BODY] = body;

    // Ресайз
    const resize = this[PRIVATE.BUILD_RESIZE]();
    panel.appendChild(resize);
    this[PRIVATE.STORE][PRIVATE.RESIZE_HANDLE] = resize;

    this[PRIVATE.STORE][PRIVATE.PANEL] = panel;
    this[PRIVATE.STORE][PRIVATE.IS_VISIBLE] = true;
    this[PRIVATE.STORE][PRIVATE.INITIALIZED] = true;

    document.body.appendChild(panel);

    this[PRIVATE.SETUP_DRAG](panel, header);
    this[PRIVATE.SETUP_RESIZE](panel, resize);
    this[PRIVATE.SETUP_HANDLERS](panel);

    logger.success('✅ Панель добавлена в DOM', { id: panel.id });
    this[PRIVATE.HANDLE_CALLBACK]({ success: true, action: 'build', panel: panel });
  }

  // ============================================================
  // 10. ПОСТРОЕНИЕ ШАПКИ
  // ============================================================

  [PRIVATE.BUILD_HEADER]() {
    const header = document.createElement('div');
    header.id = 'panel-header';
    Object.assign(header.style, {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      padding: '8px 14px',
      borderBottom: '1px solid rgba(255,255,255,0.06)',
      cursor: 'grab',
      flexShrink: 0,
      minHeight: '44px',
      background: 'rgba(26, 26, 46, 0.98)',
    });

    const title = document.createElement('span');
    Object.assign(title.style, {
      fontWeight: 'bold',
      fontSize: '14px',
      display: 'flex',
      alignItems: 'center',
      gap: '8px',
    });

    const icon = document.createElement('span');
    icon.textContent = this[PRIVATE.GET_ICON]();
    title.appendChild(icon);

    const nameSpan = document.createElement('span');
    nameSpan.textContent = this[PRIVATE.GET_TITLE]();
    title.appendChild(nameSpan);

    // Бейдж статуса
    const badge = document.createElement('span');
    badge.id = 'panel-status-badge';
    Object.assign(badge.style, {
      fontSize: '9px',
      padding: '1px 8px',
      borderRadius: '10px',
      background: 'rgba(0,184,148,0.15)',
      color: '#00b894',
      border: '1px solid rgba(0,184,148,0.2)',
      marginLeft: '8px',
    });
    badge.textContent = 'off';
    title.appendChild(badge);
    this[PRIVATE.STORE][PRIVATE.STATUS_BADGE] = badge;

    header.appendChild(title);

    // Кнопки управления
    const controls = document.createElement('div');
    controls.className = 'panel-controls';
    Object.assign(controls.style, {
      display: 'flex',
      gap: '2px',
      flexShrink: 0,
    });
    this[PRIVATE.STORE][PRIVATE.CONTROLS] = controls;

    const minBtn = this[PRIVATE.CREATE_CONTROL_BTN]('─', 'Свернуть', 'panel-minimize-btn');
    const maxBtn = this[PRIVATE.CREATE_CONTROL_BTN]('□', 'Развернуть', 'panel-maximize-btn');
    const closeBtn = this[PRIVATE.CREATE_CONTROL_BTN]('✕', 'Закрыть', 'panel-close-btn');

    this[PRIVATE.STORE][PRIVATE.MIN_BTN] = minBtn;
    this[PRIVATE.STORE][PRIVATE.MAX_BTN] = maxBtn;
    this[PRIVATE.STORE][PRIVATE.CLOSE_BTN] = closeBtn;

    controls.appendChild(minBtn);
    controls.appendChild(maxBtn);
    controls.appendChild(closeBtn);
    header.appendChild(controls);

    return header;
  }

  // ============================================================
  // 11. КНОПКА УПРАВЛЕНИЯ
  // ============================================================

  [PRIVATE.CREATE_CONTROL_BTN](text, title, id) {
    const btn = document.createElement('button');
    btn.id = id;
    Object.assign(btn.style, {
      background: 'none',
      border: 'none',
      color: '#8899bb',
      cursor: 'pointer',
      fontSize: '16px',
      padding: '0 4px',
      width: '28px',
      height: '28px',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      borderRadius: '4px',
      transition: 'all 0.2s',
    });
    btn.textContent = text;
    btn.title = title;
    return btn;
  }

  // ============================================================
  // 12. ПОСТРОЕНИЕ ТЕЛА (ПЕРЕОПРЕДЕЛЯЕТСЯ)
  // ============================================================

  [PRIVATE.BUILD_BODY]() {
    const body = document.createElement('div');
    body.id = 'panel-body';
    Object.assign(body.style, {
      flex: '1',
      overflowY: 'auto',
      padding: '10px 14px 14px 14px',
      scrollbarWidth: 'thin',
      scrollbarColor: 'rgba(102,126,234,0.3) transparent',
    });

    const info = document.createElement('div');
    Object.assign(info.style, {
      color: '#8899bb',
      fontSize: '12px',
      padding: '8px 12px',
      background: 'rgba(255,255,255,0.03)',
      borderRadius: '6px',
      border: '1px solid rgba(255,255,255,0.05)',
    });
    info.textContent = '⚡ ' + this[PRIVATE.STORE][PRIVATE.NAME];
    body.appendChild(info);

    return body;
  }

  // ============================================================
  // 13. ПОСТРОЕНИЕ РЕСАЙЗА
  // ============================================================

  [PRIVATE.BUILD_RESIZE]() {
    const resize = document.createElement('div');
    resize.id = 'panel-resize';
    Object.assign(resize.style, {
      position: 'absolute',
      bottom: '0',
      right: '0',
      width: '16px',
      height: '16px',
      cursor: 'nwse-resize',
      zIndex: '10',
      background: 'linear-gradient(135deg, transparent 50%, rgba(102,126,234,0.2) 50%)',
      borderRadius: '0 0 12px 0',
    });
    return resize;
  }

  // ============================================================
  // 14. МЕТОДЫ, ПЕРЕОПРЕДЕЛЯЕМЫЕ В НАСЛЕДНИКАХ
  // ============================================================

  [PRIVATE.GET_ICON]() {
    return '📦';
  }

  [PRIVATE.GET_TITLE]() {
    return this[PRIVATE.STORE][PRIVATE.NAME];
  }

  // ============================================================
  // 15. ПЕРЕТАСКИВАНИЕ
  // ============================================================

  [PRIVATE.SETUP_DRAG](panel, header) {
    if (!header || !panel) return;

    let isDragging = false;
    let offsetX = 0, offsetY = 0;
    let startX = 0, startY = 0;
    let rafId = null;

    const onMouseDown = (e) => {
      if (e.target.closest('.panel-controls')) return;
      if (this[PRIVATE.STORE][PRIVATE.IS_FULLSCREEN]) return;
      if (e.button !== 0) return;

      e.preventDefault();
      isDragging = true;

      const rect = panel.getBoundingClientRect();
      offsetX = e.clientX - rect.left;
      offsetY = e.clientY - rect.top;
      startX = rect.left;
      startY = rect.top;

      panel.style.transition = 'none';
      panel.style.cursor = 'grabbing';
      document.body.style.cursor = 'grabbing';
      document.body.style.userSelect = 'none';

      document.addEventListener('mousemove', onMouseMove, { passive: true });
      document.addEventListener('mouseup', onMouseUp, { passive: true });
    };

    const onMouseMove = (e) => {
      if (!isDragging) return;
      if (rafId) cancelAnimationFrame(rafId);

      rafId = requestAnimationFrame(() => {
        let x = e.clientX - offsetX;
        let y = e.clientY - offsetY;

        const maxX = window.innerWidth - panel.offsetWidth;
        const maxY = window.innerHeight - panel.offsetHeight;
        x = Math.max(0, Math.min(maxX, x));
        y = Math.max(0, Math.min(maxY, y));

        panel.style.transform = `translate(${x - startX}px, ${y - startY}px)`;
        panel.dataset.x = x;
        panel.dataset.y = y;

        this[PRIVATE.STORE][PRIVATE.POSITION] = { x, y };
        rafId = null;
      });
    };

    const onMouseUp = () => {
      if (!isDragging) return;
      isDragging = false;

      document.removeEventListener('mousemove', onMouseMove);
      document.removeEventListener('mouseup', onMouseUp);

      const x = parseInt(panel.dataset.x) || parseInt(panel.style.left) || 100;
      const y = parseInt(panel.dataset.y) || parseInt(panel.style.top) || 100;

      panel.style.transform = 'none';
      panel.style.left = x + 'px';
      panel.style.top = y + 'px';
      panel.style.cursor = '';
      document.body.style.cursor = '';
      document.body.style.userSelect = '';

      this[PRIVATE.STORE][PRIVATE.POSITION] = { x, y };

      if (rafId) {
        cancelAnimationFrame(rafId);
        rafId = null;
      }
    };

    header.addEventListener('mousedown', onMouseDown);
  }

  // ============================================================
  // 16. РЕСАЙЗ
  // ============================================================

  [PRIVATE.SETUP_RESIZE](panel, handle) {
    if (!handle || !panel) return;

    let isResizing = false;
    let startX = 0, startY = 0;
    let startW = 0, startH = 0;
    let rafId = null;

    const onMouseDown = (e) => {
      if (this[PRIVATE.STORE][PRIVATE.IS_FULLSCREEN]) return;
      e.stopPropagation();
      e.preventDefault();

      isResizing = true;

      startX = e.clientX;
      startY = e.clientY;
      startW = panel.offsetWidth;
      startH = panel.offsetHeight;

      panel.style.transition = 'none';
      document.body.style.cursor = 'nwse-resize';
      document.body.style.userSelect = 'none';

      document.addEventListener('mousemove', onMouseMove, { passive: true });
      document.addEventListener('mouseup', onMouseUp, { passive: true });
    };

    const onMouseMove = (e) => {
      if (!isResizing) return;
      if (rafId) cancelAnimationFrame(rafId);

      rafId = requestAnimationFrame(() => {
        const w = Math.max(320, Math.min(window.innerWidth * 0.9, startW + (e.clientX - startX)));
        const h = Math.max(300, Math.min(window.innerHeight * 0.9, startH + (e.clientY - startY)));

        panel.style.width = w + 'px';
        panel.style.height = h + 'px';

        this[PRIVATE.STORE][PRIVATE.SIZE] = { width: w, height: h };
        rafId = null;
      });
    };

    const onMouseUp = () => {
      if (!isResizing) return;
      isResizing = false;

      document.removeEventListener('mousemove', onMouseMove);
      document.removeEventListener('mouseup', onMouseUp);

      panel.style.transition = '';
      document.body.style.cursor = '';
      document.body.style.userSelect = '';

      if (rafId) {
        cancelAnimationFrame(rafId);
        rafId = null;
      }
    };

    handle.addEventListener('mousedown', onMouseDown);
  }

  // ============================================================
  // 17. ОБРАБОТЧИКИ КНОПОК
  // ============================================================

  [PRIVATE.SETUP_HANDLERS](panel) {
    const logger = this[PRIVATE.STORE][PRIVATE.LOGGER];

    if (this[PRIVATE.STORE][PRIVATE.MIN_BTN]) {
      this[PRIVATE.STORE][PRIVATE.MIN_BTN].addEventListener('click', (e) => {
        e.stopPropagation();
        e.preventDefault();
        this[PRIVATE.TOGGLE_MINIMIZE](panel);
      });
    }

    if (this[PRIVATE.STORE][PRIVATE.MAX_BTN]) {
      this[PRIVATE.STORE][PRIVATE.MAX_BTN].addEventListener('click', (e) => {
        e.stopPropagation();
        e.preventDefault();
        this[PRIVATE.TOGGLE_FULLSCREEN](panel);
      });
    }

    if (this[PRIVATE.STORE][PRIVATE.CLOSE_BTN]) {
      this[PRIVATE.STORE][PRIVATE.CLOSE_BTN].addEventListener('click', (e) => {
        e.stopPropagation();
        e.preventDefault();
        this[PRIVATE.CLOSE_PANEL](panel);
      });
    }

    const header = panel.querySelector('#panel-header');
    if (header) {
      header.addEventListener('dblclick', e => {
        if (e.target.closest('.panel-controls')) return;
        this[PRIVATE.STORE][PRIVATE.MAX_BTN]?.click();
      });
    }

    panel.addEventListener('mousedown', e => {
      if (e.target.closest('.panel-controls')) return;
      if (e.target.closest('button')) return;
      if (e.target.closest('input')) return;
      if (e.target.closest('select')) return;
      // ★★★ ИСПРАВЛЕНО: используем метод focus ★★★
      this.focus();
    });

    logger.success('✅ Обработчики настроены');
  }

  // ============================================================
  // 18. НАСТРОЙКА СОБЫТИЙ
  // ============================================================

  [PRIVATE.SETUP_EVENTS]() {
    const logger = this[PRIVATE.STORE][PRIVATE.LOGGER];
    logger.debug('👂 Настройка событий...');

    this[PRIVATE.STORE][PRIVATE.EVENT_HANDLERS] = new Map();

    logger.success('✅ События настроены');
  }

  // ============================================================
  // 19. УПРАВЛЕНИЕ СОСТОЯНИЕМ
  // ============================================================

  [PRIVATE.TOGGLE_MINIMIZE](panel) {
    this[PRIVATE.STORE][PRIVATE.IS_MINIMIZED] = !this[PRIVATE.STORE][PRIVATE.IS_MINIMIZED];
    if (this[PRIVATE.STORE][PRIVATE.IS_MINIMIZED]) {
      panel.classList.add('minimized');
      panel.style.height = '44px';
      panel.style.minHeight = '44px';
      panel.style.maxHeight = '44px';
      const body = panel.querySelector('#panel-body');
      if (body) body.style.display = 'none';
      const resize = panel.querySelector('#panel-resize');
      if (resize) resize.style.display = 'none';
      this[PRIVATE.STORE][PRIVATE.MIN_BTN].textContent = '□';
    } else {
      panel.classList.remove('minimized');
      panel.style.height = '';
      panel.style.minHeight = '';
      panel.style.maxHeight = '';
      const body = panel.querySelector('#panel-body');
      if (body) body.style.display = '';
      const resize = panel.querySelector('#panel-resize');
      if (resize) resize.style.display = '';
      this[PRIVATE.STORE][PRIVATE.MIN_BTN].textContent = '─';
    }
    this[PRIVATE.HANDLE_CALLBACK]({
      success: true,
      action: 'minimize',
      minimized: this[PRIVATE.STORE][PRIVATE.IS_MINIMIZED],
    });
    this[PRIVATE.UPDATE_BADGE]();
    this[PRIVATE.SAVE_STATE]();
  }

  [PRIVATE.TOGGLE_FULLSCREEN](panel) {
    this[PRIVATE.STORE][PRIVATE.IS_FULLSCREEN] = !this[PRIVATE.STORE][PRIVATE.IS_FULLSCREEN];
    if (this[PRIVATE.STORE][PRIVATE.IS_FULLSCREEN]) {
      panel.dataset.prevWidth = panel.offsetWidth;
      panel.dataset.prevHeight = panel.offsetHeight;
      panel.dataset.prevLeft = panel.style.left || panel.offsetLeft + 'px';
      panel.dataset.prevTop = panel.style.top || panel.offsetTop + 'px';

      panel.style.width = '100vw';
      panel.style.height = '100vh';
      panel.style.top = '0';
      panel.style.left = '0';
      panel.style.borderRadius = '0';
      panel.style.border = 'none';
      panel.style.maxWidth = '100vw';
      panel.style.maxHeight = '100vh';
      panel.style.minWidth = '100vw';
      panel.style.minHeight = '100vh';
      panel.style.zIndex = '999999';
      document.body.style.overflow = 'hidden';

      if (this[PRIVATE.STORE][PRIVATE.IS_MINIMIZED]) {
        this[PRIVATE.STORE][PRIVATE.IS_MINIMIZED] = false;
        panel.classList.remove('minimized');
        if (this[PRIVATE.STORE][PRIVATE.MIN_BTN]) this[PRIVATE.STORE][PRIVATE.MIN_BTN].textContent = '─';
      }

      const resize = panel.querySelector('#panel-resize');
      if (resize) resize.style.display = 'none';
      this[PRIVATE.STORE][PRIVATE.MAX_BTN].textContent = '⧉';
    } else {
      const prevWidth = parseInt(panel.dataset.prevWidth) || 420;
      const prevHeight = parseInt(panel.dataset.prevHeight) || 520;
      const prevLeft = panel.dataset.prevLeft || '100px';
      const prevTop = panel.dataset.prevTop || '100px';

      panel.style.width = prevWidth + 'px';
      panel.style.height = prevHeight + 'px';
      panel.style.top = prevTop;
      panel.style.left = prevLeft;
      panel.style.borderRadius = '12px';
      panel.style.border = '1px solid rgba(255,255,255,0.08)';
      panel.style.maxWidth = '';
      panel.style.maxHeight = '';
      panel.style.minWidth = '320px';
      panel.style.minHeight = '300px';
      panel.style.zIndex = '';
      document.body.style.overflow = '';

      const resize = panel.querySelector('#panel-resize');
      if (resize) resize.style.display = '';
      this[PRIVATE.STORE][PRIVATE.MAX_BTN].textContent = '□';
    }
    this[PRIVATE.HANDLE_CALLBACK]({
      success: true,
      action: 'fullscreen',
      fullscreen: this[PRIVATE.STORE][PRIVATE.IS_FULLSCREEN],
    });
    this[PRIVATE.UPDATE_BADGE]();
    this[PRIVATE.SAVE_STATE]();
  }

  [PRIVATE.CLOSE_PANEL](panel) {
    panel.style.display = 'none';
    this[PRIVATE.STORE][PRIVATE.IS_VISIBLE] = false;
    this[PRIVATE.STORE][PRIVATE.METADATA].lastUpdate = Date.now();
    this[PRIVATE.STORE][PRIVATE.METADATA].hideCount++;
    this[PRIVATE.HANDLE_CALLBACK]({
      success: true,
      action: 'close',
      visible: false,
    });
    this[PRIVATE.UPDATE_BADGE]();
    this[PRIVATE.SAVE_STATE]();
  }

  // ============================================================
  // 20. ОБНОВЛЕНИЕ БЕЙДЖА
  // ============================================================

  [PRIVATE.UPDATE_BADGE]() {
    const badge = this[PRIVATE.STORE][PRIVATE.STATUS_BADGE];
    if (!badge) return;

    const state = this[PRIVATE.STORE];
    const isOn = state[PRIVATE.IS_VISIBLE];
    const status = isOn ? 'on' : 'off';

    badge.textContent = status;
    badge.style.background = isOn ? 'rgba(0,184,148,0.15)' : 'rgba(255,255,255,0.05)';
    badge.style.color = isOn ? '#00b894' : '#636e72';
    badge.style.borderColor = isOn ? 'rgba(0,184,148,0.2)' : 'rgba(255,255,255,0.05)';
  }

  // ============================================================
  // 21. ПУБЛИЧНЫЕ МЕТОДЫ
  // ============================================================

  show() {
    this[PRIVATE.SHOW]();
    return this;
  }

  hide() {
    this[PRIVATE.HIDE]();
    return this;
  }

  toggle() {
    this[PRIVATE.TOGGLE]();
    return this;
  }

  // ★★★ НОВЫЙ ПУБЛИЧНЫЙ МЕТОД FOCUS ★★★
  focus() {
    this[PRIVATE.FOCUS]();
    return this;
  }

  [PRIVATE.SHOW]() {
    const panel = this[PRIVATE.STORE][PRIVATE.PANEL];
    if (!panel) return;
    panel.style.display = 'flex';
    panel.style.visibility = 'visible';
    panel.style.opacity = '1';
    panel.style.transform = 'scale(1)';
    this[PRIVATE.STORE][PRIVATE.IS_VISIBLE] = true;
    this[PRIVATE.STORE][PRIVATE.METADATA].lastUpdate = Date.now();
    this[PRIVATE.STORE][PRIVATE.METADATA].showCount++;
    this[PRIVATE.STORE][PRIVATE.METADATA].toggleCount++;
    this[PRIVATE.HANDLE_CALLBACK]({ success: true, action: 'show', visible: true });
    this[PRIVATE.UPDATE_BADGE]();
    this[PRIVATE.SAVE_STATE]();
  }

  [PRIVATE.HIDE]() {
    const panel = this[PRIVATE.STORE][PRIVATE.PANEL];
    if (!panel) return;
    panel.style.display = 'none';
    this[PRIVATE.STORE][PRIVATE.IS_VISIBLE] = false;
    this[PRIVATE.STORE][PRIVATE.METADATA].lastUpdate = Date.now();
    this[PRIVATE.STORE][PRIVATE.METADATA].hideCount++;
    this[PRIVATE.HANDLE_CALLBACK]({ success: true, action: 'hide', visible: false });
    this[PRIVATE.UPDATE_BADGE]();
    this[PRIVATE.SAVE_STATE]();
  }

  [PRIVATE.TOGGLE]() {
    if (this[PRIVATE.STORE][PRIVATE.IS_VISIBLE]) {
      this[PRIVATE.HIDE]();
    } else {
      this[PRIVATE.SHOW]();
    }
  }

  [PRIVATE.FORCE_SHOW]() {
    const panel = this[PRIVATE.STORE][PRIVATE.PANEL];
    if (!panel) return;
    panel.style.display = 'flex';
    panel.style.visibility = 'visible';
    panel.style.opacity = '1';
    panel.style.transform = 'scale(1)';
    this[PRIVATE.STORE][PRIVATE.IS_VISIBLE] = true;
    this[PRIVATE.STORE][PRIVATE.METADATA].lastUpdate = Date.now();
    this[PRIVATE.STORE][PRIVATE.METADATA].showCount++;
    this[PRIVATE.STORE][PRIVATE.METADATA].toggleCount++;
    this[PRIVATE.HANDLE_CALLBACK]({ success: true, action: 'forceShow', visible: true });
    this[PRIVATE.UPDATE_BADGE]();
    this[PRIVATE.SAVE_STATE]();
  }

  // ============================================================
  // 22. ПРИВАТНЫЙ МЕТОД FOCUS ★★★
  // ============================================================

// ============================================================
// 22. ПРИВАТНЫЙ МЕТОД FOCUS ★★★
// ============================================================

  [PRIVATE.FOCUS]() {
    const panel = this[PRIVATE.STORE][PRIVATE.PANEL];
    if (!panel) return;

    const logger = this[PRIVATE.STORE][PRIVATE.LOGGER];
    logger.debug('🎯 Фокус на панели...');

    // ★★★ НАХОДИМ ВСЕ ПАНЕЛИ ★★★
    const allWindows = document.querySelectorAll(
        '.panel-container, #widget-app, #env-control-panel, #logs-control-panel, #debug-control-panel, #debug-control-panel-v2'
    );

    // ★★★ НАХОДИМ МАКСИМАЛЬНЫЙ Z-INDEX ★★★
    let maxZ = 99996; // базовое значение

    // Сначала собираем все z-index существующих панелей
    const zIndices = [];
    allWindows.forEach(win => {
      if (win !== panel && win.style.display !== 'none') {
        const z = parseInt(win.style.zIndex) || 0;
        if (z > 0) {
          zIndices.push(z);
          if (z > maxZ) maxZ = z;
        }
      }
    });

    // ★★★ УСТАНАВЛИВАЕМ НОВЫЙ Z-INDEX ★★★
    const newZ = maxZ + 1;
    panel.style.zIndex = newZ;

    // ★★★ УБИРАЕМ АКТИВНЫЕ КЛАССЫ У ВСЕХ ПАНЕЛЕЙ ★★★
    allWindows.forEach(win => {
      win.classList.remove('active-window');
      // ★★★ НЕ СБРАСЫВАЕМ Z-INDEX У ДРУГИХ ПАНЕЛЕЙ ★★★
      // Оставляем их z-index как есть
    });

    // ★★★ ДОБАВЛЯЕМ АКТИВНЫЙ КЛАСС ТОЛЬКО ТЕКУЩЕЙ ПАНЕЛИ ★★★
    panel.classList.add('active-window');

    // ★★★ ОБНОВЛЯЕМ СОСТОЯНИЕ ★★★
    this[PRIVATE.STORE][PRIVATE.Z_INDEX] = newZ;

    // ★★★ ВЫЗЫВАЕМ СОБЫТИЕ ★★★
    this.emit('onFocus', {
      panel,
      zIndex: newZ,
      allZIndices: zIndices,
      timestamp: Date.now(),
    });

    // ★★★ СОХРАНЯЕМ СОСТОЯНИЕ ★★★
    this[PRIVATE.SAVE_STATE]();

    logger.success(`✅ Панель на переднем плане (z-index: ${newZ})`);

    // ★★★ ВОЗВРАЩАЕМ НОВЫЙ Z-INDEX ★★★
    return newZ;
  }

  // ============================================================
  // 23. ПОЛУЧЕНИЕ СОСТОЯНИЯ
  // ============================================================

  [PRIVATE.GET_STATE]() {
    return {
      id: this[PRIVATE.STORE][PRIVATE.ID],
      name: this[PRIVATE.STORE][PRIVATE.NAME],
      type: this[PRIVATE.STORE][PRIVATE.TYPE],
      version: this[PRIVATE.STORE][PRIVATE.VERSION],
      visible: this[PRIVATE.STORE][PRIVATE.IS_VISIBLE],
      minimized: this[PRIVATE.STORE][PRIVATE.IS_MINIMIZED],
      fullscreen: this[PRIVATE.STORE][PRIVATE.IS_FULLSCREEN],
      position: this[PRIVATE.STORE][PRIVATE.POSITION],
      size: this[PRIVATE.STORE][PRIVATE.SIZE],
      zIndex: this[PRIVATE.STORE][PRIVATE.Z_INDEX],
      metadata: { ...this[PRIVATE.STORE][PRIVATE.METADATA] },
      context: { ...this[PRIVATE.STORE][PRIVATE.CONTEXT] },
      panelId: this[PRIVATE.STORE][PRIVATE.PANEL_ID],
      initialized: this[PRIVATE.STORE][PRIVATE.INITIALIZED],
      destroyed: this[PRIVATE.STORE][PRIVATE.DESTROYED],
      hasCallback: typeof this[PRIVATE.STORE][PRIVATE.CALLBACK] === 'function',
      cacheSize: this[PRIVATE.STORE][PRIVATE.CACHE].size,
      listenersCount: this[PRIVATE.STORE][PRIVATE.LISTENERS].length,
      eventHandlersCount: this[PRIVATE.STORE][PRIVATE.EVENT_HANDLERS].size,
    };
  }

  getState() {
    return this[PRIVATE.GET_STATE]();
  }

  // ============================================================
  // 24. ЭКСПОРТ СИМВОЛОВ
  // ============================================================

  [PRIVATE.EXPORT_SYMBOLS]() {
    if (typeof window === 'undefined') return;
    const panel = this[PRIVATE.STORE][PRIVATE.PANEL];
    window.__panelInstance = this;
    window.__panelSymbols = {
      PRIVATE: { ...PRIVATE },
      PUBLIC: { ...PUBLIC },
      instanceId: this[PRIVATE.STORE][PRIVATE.ID],
      panelId: this[PRIVATE.STORE][PRIVATE.PANEL_ID],
    };
    window[PUBLIC.API] = this;
    window[PUBLIC.STATE] = this[PRIVATE.GET_STATE].bind(this);
    window[PUBLIC.CONFIG] = {
      id: this[PRIVATE.STORE][PRIVATE.ID],
      name: this[PRIVATE.STORE][PRIVATE.NAME],
      version: this[PRIVATE.STORE][PRIVATE.VERSION],
      panelId: this[PRIVATE.STORE][PRIVATE.PANEL_ID],
    };
    window[PUBLIC.LOGGER] = this[PRIVATE.STORE][PRIVATE.LOGGER];
    window[PUBLIC.PANEL] = panel;
    window[PUBLIC.INSTANCE] = this;
    window[PUBLIC.EVENTS] = {
      on: this.on.bind(this),
      off: this.off.bind(this),
      emit: this.emit.bind(this),
    };
  }

  // ============================================================
  // 25. ОБРАБОТКА CALLBACK
  // ============================================================

  [PRIVATE.HANDLE_CALLBACK](result) {
    const callback = this[PRIVATE.STORE][PRIVATE.CALLBACK];
    const logger = this[PRIVATE.STORE][PRIVATE.LOGGER];
    if (typeof callback === 'function') {
      try {
        callback(result);
      } catch (cbError) {
        logger.error(`❌ Ошибка в callback: ${cbError.message}`);
      }
    }
  }

  // ============================================================
  // 26. СОБЫТИЯ
  // ============================================================

  on(event, callback) {
    if (typeof callback !== 'function') {
      this[PRIVATE.STORE][PRIVATE.LOGGER].warn(`⚠️ Некорректный callback для события ${event}`);
      return () => {};
    }

    const handlers = this[PRIVATE.STORE][PRIVATE.EVENT_HANDLERS];
    if (!handlers.has(event)) {
      handlers.set(event, []);
    }
    handlers.get(event).push(callback);

    return () => this.off(event, callback);
  }

  off(event, callback) {
    const handlers = this[PRIVATE.STORE][PRIVATE.EVENT_HANDLERS];
    if (handlers.has(event)) {
      const list = handlers.get(event);
      const index = list.indexOf(callback);
      if (index !== -1) {
        list.splice(index, 1);
      }
      if (list.length === 0) {
        handlers.delete(event);
      }
    }
  }

  emit(event, data) {
    const handlers = this[PRIVATE.STORE][PRIVATE.EVENT_HANDLERS];
    if (handlers.has(event)) {
      const list = handlers.get(event);
      for (const callback of list) {
        try {
          callback(data);
        } catch (e) {
          this[PRIVATE.STORE][PRIVATE.LOGGER].error(`❌ Ошибка в обработчике ${event}:`, e.message);
        }
      }
    }
  }

  // ============================================================
  // 27. СОХРАНЕНИЕ И ЗАГРУЗКА СОСТОЯНИЯ
  // ============================================================

  [PRIVATE.SAVE_STATE]() {
    try {
      const key = `panel-state-${this[PRIVATE.STORE][PRIVATE.ID]}`;
      const data = {
        state: {
          visible: this[PRIVATE.STORE][PRIVATE.IS_VISIBLE],
          minimized: this[PRIVATE.STORE][PRIVATE.IS_MINIMIZED],
          fullscreen: this[PRIVATE.STORE][PRIVATE.IS_FULLSCREEN],
          position: this[PRIVATE.STORE][PRIVATE.POSITION],
          size: this[PRIVATE.STORE][PRIVATE.SIZE],
          zIndex: this[PRIVATE.STORE][PRIVATE.Z_INDEX],
        },
        metadata: {
          runCount: this[PRIVATE.STORE][PRIVATE.METADATA].runCount,
          showCount: this[PRIVATE.STORE][PRIVATE.METADATA].showCount,
          hideCount: this[PRIVATE.STORE][PRIVATE.METADATA].hideCount,
          toggleCount: this[PRIVATE.STORE][PRIVATE.METADATA].toggleCount,
        },
        timestamp: Date.now(),
        version: this[PRIVATE.STORE][PRIVATE.VERSION],
      };
      localStorage.setItem(key, JSON.stringify(data));
    } catch (e) {
      this[PRIVATE.STORE][PRIVATE.LOGGER].debug('⚠️ Не удалось сохранить состояние:', e.message);
    }
  }

  [PRIVATE.LOAD_STATE]() {
    try {
      const key = `panel-state-${this[PRIVATE.STORE][PRIVATE.ID]}`;
      const saved = localStorage.getItem(key);
      if (saved) {
        const data = JSON.parse(saved);
        if (data.state) {
          if (data.state.visible !== undefined) this[PRIVATE.STORE][PRIVATE.IS_VISIBLE] = data.state.visible;
          if (data.state.minimized !== undefined) this[PRIVATE.STORE][PRIVATE.IS_MINIMIZED] = data.state.minimized;
          if (data.state.fullscreen !== undefined) this[PRIVATE.STORE][PRIVATE.IS_FULLSCREEN] = data.state.fullscreen;
          if (data.state.position) this[PRIVATE.STORE][PRIVATE.POSITION] = data.state.position;
          if (data.state.size) this[PRIVATE.STORE][PRIVATE.SIZE] = data.state.size;
          if (data.state.zIndex) this[PRIVATE.STORE][PRIVATE.Z_INDEX] = data.state.zIndex;
          this._applyStateToDom();
        }
        if (data.metadata) {
          Object.assign(this[PRIVATE.STORE][PRIVATE.METADATA], data.metadata);
        }
        this[PRIVATE.STORE][PRIVATE.LOGGER].debug('✅ Состояние загружено');
      }
    } catch (e) {
      this[PRIVATE.STORE][PRIVATE.LOGGER].debug('⚠️ Не удалось загрузить состояние:', e.message);
    }
  }

  [PRIVATE.RESET_STATE]() {
    this[PRIVATE.STORE][PRIVATE.IS_VISIBLE] = true;
    this[PRIVATE.STORE][PRIVATE.IS_MINIMIZED] = false;
    this[PRIVATE.STORE][PRIVATE.IS_FULLSCREEN] = false;
    this[PRIVATE.STORE][PRIVATE.POSITION] = { x: 100, y: 100 };
    this[PRIVATE.STORE][PRIVATE.SIZE] = { width: 420, height: 520 };
    this[PRIVATE.STORE][PRIVATE.Z_INDEX] = 99996;
    this[PRIVATE.STORE][PRIVATE.METADATA] = {
      created: Date.now(),
      lastAccess: Date.now(),
      lastUpdate: Date.now(),
      runCount: 0,
      errorCount: 0,
      toggleCount: 0,
      showCount: 0,
      hideCount: 0,
    };
    this._applyStateToDom();
    this[PRIVATE.UPDATE_BADGE]();
    this[PRIVATE.SAVE_STATE]();
    this[PRIVATE.STORE][PRIVATE.LOGGER].info('🔄 Состояние сброшено');
  }

  _applyStateToDom() {
    const panel = this[PRIVATE.STORE][PRIVATE.PANEL];
    if (!panel) return;

    const state = this[PRIVATE.STORE];
    const pos = state[PRIVATE.POSITION];
    const size = state[PRIVATE.SIZE];

    panel.style.left = pos.x + 'px';
    panel.style.top = pos.y + 'px';
    panel.style.width = size.width + 'px';
    panel.style.height = size.height + 'px';
    panel.style.zIndex = state[PRIVATE.Z_INDEX];

    if (state[PRIVATE.IS_VISIBLE]) {
      panel.style.display = 'flex';
    } else {
      panel.style.display = 'none';
    }

    if (state[PRIVATE.IS_MINIMIZED]) {
      panel.classList.add('minimized');
      panel.style.height = '44px';
      panel.style.minHeight = '44px';
      panel.style.maxHeight = '44px';
      const body = panel.querySelector('#panel-body');
      if (body) body.style.display = 'none';
      const resize = panel.querySelector('#panel-resize');
      if (resize) resize.style.display = 'none';
      if (this[PRIVATE.STORE][PRIVATE.MIN_BTN]) this[PRIVATE.STORE][PRIVATE.MIN_BTN].textContent = '□';
    } else {
      panel.classList.remove('minimized');
      panel.style.height = '';
      panel.style.minHeight = '';
      panel.style.maxHeight = '';
      const body = panel.querySelector('#panel-body');
      if (body) body.style.display = '';
      const resize = panel.querySelector('#panel-resize');
      if (resize) resize.style.display = '';
      if (this[PRIVATE.STORE][PRIVATE.MIN_BTN]) this[PRIVATE.STORE][PRIVATE.MIN_BTN].textContent = '─';
    }

    if (state[PRIVATE.IS_FULLSCREEN]) {
      panel.classList.add('fullscreen');
      panel.style.width = '100vw';
      panel.style.height = '100vh';
      panel.style.top = '0';
      panel.style.left = '0';
      panel.style.borderRadius = '0';
      panel.style.border = 'none';
      panel.style.maxWidth = '100vw';
      panel.style.maxHeight = '100vh';
      panel.style.minWidth = '100vw';
      panel.style.minHeight = '100vh';
      if (this[PRIVATE.STORE][PRIVATE.MAX_BTN]) this[PRIVATE.STORE][PRIVATE.MAX_BTN].textContent = '⧉';
    } else {
      panel.classList.remove('fullscreen');
      panel.style.borderRadius = '12px';
      panel.style.border = '1px solid rgba(255,255,255,0.08)';
      panel.style.maxWidth = '';
      panel.style.maxHeight = '';
      panel.style.minWidth = '320px';
      panel.style.minHeight = '300px';
      if (this[PRIVATE.STORE][PRIVATE.MAX_BTN]) this[PRIVATE.STORE][PRIVATE.MAX_BTN].textContent = '□';
    }

    this[PRIVATE.UPDATE_BADGE]();
  }

  // ============================================================
  // 28. УНИЧТОЖЕНИЕ
  // ============================================================

  destroy() {
    if (this[PRIVATE.STORE][PRIVATE.DESTROYED]) return;

    const logger = this[PRIVATE.STORE][PRIVATE.LOGGER];
    logger.warn('🗑️ Уничтожение панели...');

    if (this[PRIVATE.STORE][PRIVATE.PANEL] && this[PRIVATE.STORE][PRIVATE.PANEL].parentNode) {
      this[PRIVATE.STORE][PRIVATE.PANEL].parentNode.removeChild(this[PRIVATE.STORE][PRIVATE.PANEL]);
    }

    for (const [key, timer] of this[PRIVATE.STORE][PRIVATE.TIMERS]) {
      clearInterval(timer);
      clearTimeout(timer);
    }
    this[PRIVATE.STORE][PRIVATE.TIMERS].clear();

    if (this[PRIVATE.STORE][PRIVATE.RAF_ID]) {
      cancelAnimationFrame(this[PRIVATE.STORE][PRIVATE.RAF_ID]);
      this[PRIVATE.STORE][PRIVATE.RAF_ID] = null;
    }

    this[PRIVATE.STORE][PRIVATE.CACHE].clear();
    this[PRIVATE.STORE][PRIVATE.LISTENERS] = [];
    this[PRIVATE.STORE][PRIVATE.EVENT_HANDLERS].clear();

    if (window.__panelInstance === this) delete window.__panelInstance;

    this[PRIVATE.STORE][PRIVATE.DESTROYED] = true;
    this[PRIVATE.STORE][PRIVATE.INITIALIZED] = false;

    logger.success(`🗑️ ${this[PRIVATE.STORE][PRIVATE.NAME]} уничтожен`);
  }
}

// ============================================================
// 29. ЭКСПОРТ ПО УМОЛЧАНИЮ
// ============================================================

export default BasePanel;

// ============================================================
// 30. ГЛОБАЛЬНАЯ РЕГИСТРАЦИЯ
// ============================================================

if (typeof window !== 'undefined') {
  window.BasePanel = BasePanel;
  window.PRIVATE_SYMBOLS = PRIVATE;
  window.PUBLIC_SYMBOLS = PUBLIC;

  console.log('╔═══════════════════════════════════════════════════════════════════════════════╗');
  console.log('║              📦 BASE PANEL (100% СИМВОЛЫ) v2.5.1                           ║');
  console.log('╠═══════════════════════════════════════════════════════════════════════════════╣');
  console.log(`║  📦 Приватных символов:     ${String(Object.keys(PRIVATE).length).padStart(3)}                                    ║`);
  console.log(`║  🔓 Публичных символов:      ${String(Object.keys(PUBLIC).length).padStart(3)}                                    ║`);
  console.log(`║  📊 Всего символов:          ${String(Object.keys(PRIVATE).length + Object.keys(PUBLIC).length).padStart(3)}                                    ║`);
  console.log('║                                                                               ║');
  console.log('║  ✨ НОВОЕ: метод focus() для поднятия панели                                 ║');
  console.log('║  📋 Доступно в window.__panelSymbols:                                          ║');
  console.log('║    PRIVATE_SYMBOLS           - все приватные символы                          ║');
  console.log('║    PUBLIC_SYMBOLS            - все публичные символы                          ║');
  console.log('║    BasePanel                 - базовый класс                                  ║');
  console.log('║    BasePanel.getPrivate()    - получить приватные символы                     ║');
  console.log('║    BasePanel.getPublic()     - получить публичные символы                     ║');
  console.log('║    BasePanel.getSymbols()    - получить все символы                           ║');
  console.log('╚═══════════════════════════════════════════════════════════════════════════════╝');

  console.log('📋 НОВЫЕ КОМАНДЫ:');
  console.log('  panel.focus()                - поднять панель на передний план');
  console.log('  panel[PUBLIC.FOCUS]          - публичный символ focus');
}
