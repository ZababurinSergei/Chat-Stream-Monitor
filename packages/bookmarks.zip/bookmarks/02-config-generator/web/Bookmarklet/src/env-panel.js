// web/Bookmarklet/src/env-panel.mjs
// Панель управления ENV — расширение BasePanel через Object.defineProperties
// 100% СИМВОЛЫ — полная изоляция и безопасность
// Версия: 2.4.6

// ============================================================
// 1. ★★★ ИМПОРТЫ ★★★
// ============================================================

import BasePanel, {
  generatePanelId,
  generateInstanceId,
} from './base-panel.mjs';

// ★★★ ПОЛУЧАЕМ PRIVATE И PUBLIC ЧЕРЕЗ СТАТИЧЕСКИЙ МЕТОД ★★★
// Это должно быть сделано ДО использования PRIVATE
const PRIVATE = BasePanel.getPrivate();
const PUBLIC = BasePanel.getPublic();

// ============================================================
// 2. ★★★ ПРИВАТНЫЕ СИМВОЛЫ ENV ★★★
// ============================================================

const ENV_PRIVATE = {
  // Основные символы
  BUILD_BODY: Symbol('env-panel.buildBody'),
  GET_ICON: Symbol('env-panel.getIcon'),
  GET_TITLE: Symbol('env-panel.getTitle'),

  // Символы состояния
  ENV_STATE: Symbol('env-panel.state'),
  ENV_CONFIG: Symbol('env-panel.config'),
  ENV_CACHE: Symbol('env-panel.cache'),

  // Символы DOM
  GROUPS_CONTAINER: Symbol('env-panel.groupsContainer'),
  ACTIONS_CONTAINER: Symbol('env-panel.actionsContainer'),
  COMMANDS_CONTAINER: Symbol('env-panel.commandsContainer'),
  STATUS_BADGE: Symbol('env-panel.statusBadge'),

  // Символы данных
  PRESETS: Symbol('env-panel.presets'),
  CURRENT_NAMESPACE: Symbol('env-panel.currentNamespace'),
  PREVIOUS_NAMESPACE: Symbol('env-panel.previousNamespace'),

  // Символы обработчиков
  HANDLERS: Symbol('env-panel.handlers'),
  EVENT_HANDLERS: Symbol('env-panel.eventHandlers'),

  // Символы таймеров
  TIMERS: Symbol('env-panel.timers'),
  DEBOUNCE_TIMER: Symbol('env-panel.debounceTimer'),

  // Символы логгера
  LOGGER: Symbol('env-panel.logger'),
  LOG_HISTORY: Symbol('env-panel.logHistory'),

  // Символы хранения
  STORAGE_KEY: Symbol('env-panel.storageKey'),
  SAVE_STATE: Symbol('env-panel.saveState'),
  LOAD_STATE: Symbol('env-panel.loadState'),

  // Символы методов
  UPDATE_UI: Symbol('env-panel.updateUI'),
  UPDATE_BADGE: Symbol('env-panel.updateBadge'),
  UPDATE_PRESETS: Symbol('env-panel.updatePresets'),
  UPDATE_ACTIONS: Symbol('env-panel.updateActions'),
  HANDLE_PRESET: Symbol('env-panel.handlePreset'),
  HANDLE_ACTION: Symbol('env-panel.handleAction'),
  SET_NAMESPACE: Symbol('env-panel.setNamespace'),
  GET_NAMESPACE: Symbol('env-panel.getNamespace'),
  RESET_NAMESPACE: Symbol('env-panel.resetNamespace'),
  EMIT: Symbol('env-panel.emit'),
  ON: Symbol('env-panel.on'),
  OFF: Symbol('env-panel.off'),

  // ★★★ НОВЫЕ СИМВОЛЫ ДЛЯ УПРАВЛЕНИЯ ОБРАБОТЧИКАМИ ★★★
  HANDLER_IDS: Symbol('env-panel.handlerIds'),
  BOUND_FOCUS: Symbol('env-panel.boundFocus'),
};

// ============================================================
// 3. ★★★ ПУБЛИЧНЫЕ СИМВОЛЫ ENV ★★★
// ============================================================

const ENV_PUBLIC = {
  API: Symbol.for('env-panel.api'),
  STATE: Symbol.for('env-panel.state'),
  CONFIG: Symbol.for('env-panel.config'),
  LOGGER: Symbol.for('env-panel.logger'),
  EVENTS: Symbol.for('env-panel.events'),
  INSTANCE: Symbol.for('env-panel.instance'),
  NAMESPACE: Symbol.for('env-panel.namespace'),
  PRESETS: Symbol.for('env-panel.presets'),
};

// ============================================================
// 4. ★★★ КОНФИГУРАЦИЯ ENV ★★★
// ============================================================

const ENV_CONFIG = {
  GROUPS: {
    '🌊 Flow': {
      presets: [
        { name: 'Все flow', value: 'wasm:flow:*' },
        { name: 'Flow шаги', value: 'wasm:flow:step:*' },
        { name: 'Flow чекпоинты', value: 'wasm:flow:checkpoint:*' },
        { name: 'Flow ветки', value: 'wasm:flow:branch:*' },
      ],
    },
    '🧠 Memory': {
      presets: [
        { name: 'Все память', value: 'wasm:memory:*' },
        { name: 'Чтение памяти', value: 'wasm:memory:read:*' },
        { name: 'Запись памяти', value: 'wasm:memory:write:*' },
      ],
    },
    '⚡ Generate': {
      presets: [
        { name: 'Все генерация', value: 'wasm:generate:*' },
        { name: 'JSON генерация', value: 'wasm:generate:json:*' },
        { name: 'C генерация', value: 'wasm:generate:c:*' },
        { name: 'ENV генерация', value: 'wasm:generate:env:*' },
      ],
    },
    '🔧 API': {
      presets: [
        { name: 'Все API', value: 'wasm:api:*' },
        { name: 'API вызовы', value: 'wasm:api:call:*' },
        { name: 'API ошибки', value: 'wasm:api:error:*' },
      ],
    },
    '🚨 Errors': {
      presets: [
        { name: 'Все ошибки', value: 'wasm:error:*' },
        { name: 'Критические', value: 'wasm:error:critical:*' },
      ],
    },
    '📊 All': {
      presets: [
        { name: 'ВСЕ ЛОГИ', value: 'wasm:*' },
        { name: 'Все кроме памяти', value: '*,-wasm:memory:*' },
        { name: 'Flow+Generate+Memory', value: 'wasm:flow:*,wasm:generate:*,wasm:memory:*' },
        { name: 'Только ошибки', value: 'wasm:error:*' },
      ],
    },
    '🎯 Custom': {
      presets: [
        { name: 'Отключить всё', value: '' },
        { name: 'Только flow и generate', value: 'wasm:flow:*,wasm:generate:*' },
        { name: 'Только memory и errors', value: 'wasm:memory:*,wasm:error:*' },
        { name: 'Flow + API', value: 'wasm:flow:*,wasm:api:*' },
      ],
    },
    '📦 Bookmarklet': {
      presets: [
        { name: 'Все bookmarklet', value: 'bookmarklet:*' },
        { name: 'Только main', value: 'bookmarklet:main' },
        { name: 'Только loader', value: 'bookmarklet:loader' },
        { name: 'Только SW', value: 'bookmarklet:sw' },
        { name: 'Только панели', value: 'bookmarklet:panels' },
        { name: 'Все кроме SW', value: 'bookmarklet:*,-bookmarklet:sw' },
      ],
    },
  },
  ACTIONS: [
    { text: '📊', title: 'Показать ENV', action: 'showEnv' },
    { text: '🔊', title: 'Включить все логи', action: 'enableAll' },
    { text: '🔇', title: 'Отключить все логи', action: 'disableAll' },
    { text: '📦', title: 'Логи букмарклета', action: 'enableBookmarklet' },
    { text: '🔄', title: 'Синхронизировать', action: 'sync' },
    { text: '📤', title: 'Экспортировать', action: 'export' },
    { text: '🔄', title: 'Сбросить состояние', action: 'reset' },
    { text: '📜', title: 'История', action: 'history' },
    { text: '🧠', title: 'SharedMemory', action: 'sharedMemory' },
  ],
  STORAGE_KEY: 'env-panel-state',
  DEBOUNCE_DELAY: 300,
  AUTO_UPDATE_INTERVAL: 30000,
  MAX_HISTORY: 100,
  DEFAULT_NAMESPACE: '',
};

// ============================================================
// 5. ★★★ ПОЛУЧЕНИЕ ENV ★★★
// ============================================================

function getEnv() {
  if (typeof window.ENV !== 'undefined') return window.ENV;
  if (typeof ENV !== 'undefined') return ENV;

  return {
    debug: {
      namespace: '',
      enable: ns => {
        console.log(`🔍 DEBUG enabled: ${ns}`);
      },
      disable: () => {
        console.log('🔍 DEBUG disabled');
      },
      getConfig: () => ({
        namespace: '',
        hideDate: false,
        colors: true,
        depth: 2,
        showHidden: false,
      }),
      enabled: () => false,
      setOptions: () => {},
      getHistory: () => [],
      clearHistory: () => {},
      logStatus: () => console.log('🔍 DEBUG: off'),
      help: () => console.log('📋 DEBUG help: use enable(namespace)'),
    },
  };
}

// ============================================================
// 6. ★★★ ПОЛУЧЕНИЕ ЭКЗЕМПЛЯРА ★★★
// ============================================================

function getInstance() {
  return window.__bookmarkletInstance || window.R || null;
}

// ============================================================
// 7. ★★★ ПОСТРОЕНИЕ ТЕЛА ENV ★★★
// ============================================================

function buildEnvBody(panelInstance) {
  const body = document.createElement('div');
  body.id = 'panel-body';

  Object.assign(body.style, {
    flex: '1',
    overflowY: 'auto',
    padding: '10px 14px 14px 14px',
    scrollbarWidth: 'thin',
    scrollbarColor: 'rgba(102,126,234,0.3) transparent',
  });

  // Информация
  const info = document.createElement('div');
  Object.assign(info.style, {
    color: '#8899bb',
    fontSize: '12px',
    marginBottom: '10px',
    padding: '8px 12px',
    background: 'rgba(255,255,255,0.03)',
    borderRadius: '6px',
    border: '1px solid rgba(255,255,255,0.05)',
  });
  info.textContent = '⚡ ' + panelInstance[PRIVATE.NAME];
  body.appendChild(info);

  // Группы пресетов
  const groupsContainer = document.createElement('div');
  groupsContainer.id = 'env-groups';
  groupsContainer.style.cssText = 'display:flex;flex-direction:column;gap:8px;';

  const env = getEnv();
  const currentNS = env?.debug?.namespace || '';
  panelInstance[ENV_PRIVATE.CURRENT_NAMESPACE] = currentNS;

  for (const [groupName, group] of Object.entries(ENV_CONFIG.GROUPS)) {
    const groupEl = document.createElement('div');
    groupEl.style.cssText = 'border:1px solid rgba(255,255,255,0.05);border-radius:8px;padding:8px 10px;background:rgba(255,255,255,0.02);';

    const titleEl = document.createElement('div');
    titleEl.style.cssText = 'font-size:10px;font-weight:bold;color:#8899bb;text-transform:uppercase;letter-spacing:0.5px;margin-bottom:4px;';
    titleEl.textContent = groupName;
    groupEl.appendChild(titleEl);

    const btnsContainer = document.createElement('div');
    btnsContainer.style.cssText = 'display:flex;flex-wrap:wrap;gap:3px;';

    for (const preset of group.presets) {
      const active = currentNS === preset.value;
      const btn = document.createElement('button');
      btn.textContent = preset.name;
      btn.dataset.preset = preset.value || '';
      btn.className = 'preset-btn';
      btn.style.cssText = `
        padding: 3px 8px;
        border: 1px solid ${active ? '#667eea' : 'rgba(255,255,255,0.05)'};
        border-radius: 4px;
        background: ${active ? 'rgba(102,126,234,0.3)' : 'rgba(255,255,255,0.03)'};
        color: ${active ? '#fff' : '#8899bb'};
        font-size: 10px;
        cursor: pointer;
        transition: all 0.2s;
        font-family: inherit;
        white-space: nowrap;
      `;

      btn.addEventListener('mouseenter', function() {
        const a = this.dataset.preset === currentNS;
        this.style.background = a ? 'rgba(102,126,234,0.4)' : 'rgba(255,255,255,0.08)';
        this.style.transform = 'translateY(-1px)';
      });

      btn.addEventListener('mouseleave', function() {
        const a = this.dataset.preset === currentNS;
        this.style.background = a ? 'rgba(102,126,234,0.3)' : 'rgba(255,255,255,0.03)';
        this.style.transform = 'translateY(0)';
      });

      btn.addEventListener('click', function() {
        panelInstance[ENV_PRIVATE.HANDLE_PRESET](this.dataset.preset);
      });

      btnsContainer.appendChild(btn);
    }
    groupEl.appendChild(btnsContainer);
    groupsContainer.appendChild(groupEl);
  }

  body.appendChild(groupsContainer);
  panelInstance[ENV_PRIVATE.GROUPS_CONTAINER] = groupsContainer;

  // Быстрые действия
  const actionsContainer = document.createElement('div');
  actionsContainer.id = 'env-actions';
  actionsContainer.style.cssText = `
    margin-top: 10px;
    padding-top: 10px;
    border-top: 1px solid rgba(255,255,255,0.05);
    display: flex;
    gap: 4px;
    flex-wrap: wrap;
  `;

  for (const action of ENV_CONFIG.ACTIONS) {
    const btn = document.createElement('button');
    btn.textContent = action.text;
    btn.title = action.title || '';
    btn.dataset.action = action.action;
    btn.className = 'action-btn';
    btn.style.cssText = `
      padding: 4px 10px;
      border: 1px solid rgba(255,255,255,0.05);
      border-radius: 4px;
      background: rgba(255,255,255,0.03);
      color: #8899bb;
      font-size: 10px;
      cursor: pointer;
      font-family: inherit;
      transition: all 0.2s;
    `;

    btn.addEventListener('mouseenter', function() {
      this.style.background = 'rgba(255,255,255,0.08)';
      this.style.transform = 'translateY(-1px)';
    });

    btn.addEventListener('mouseleave', function() {
      this.style.background = 'rgba(255,255,255,0.03)';
      this.style.transform = 'translateY(0)';
    });

    btn.addEventListener('click', function() {
      panelInstance[ENV_PRIVATE.HANDLE_ACTION](this.dataset.action);
    });

    actionsContainer.appendChild(btn);
  }

  body.appendChild(actionsContainer);
  panelInstance[ENV_PRIVATE.ACTIONS_CONTAINER] = actionsContainer;

  // Команды
  const commandsContainer = document.createElement('div');
  commandsContainer.id = 'env-commands';
  commandsContainer.style.cssText = `
    margin-top: 8px;
    padding: 6px 10px;
    background: rgba(0,0,0,0.3);
    border-radius: 4px;
    font-size: 9px;
    color: #636e72;
    font-family: monospace;
    border: 1px solid rgba(255,255,255,0.03);
  `;

  commandsContainer.innerHTML = `
    <div style="color:#8899bb;font-weight:bold;font-size:9px;margin-bottom:2px;">📋 Команды:</div>
    <div style="display:flex;flex-wrap:wrap;gap:2px 8px;">
      <code style="color:#667eea;">ENV.debug.enable("wasm:*")</code>
      <code style="color:#667eea;">ENV.debug.disable()</code>
      <code style="color:#667eea;">window.__envPanel.toggle()</code>
    </div>
    <div style="display:flex;flex-wrap:wrap;gap:2px 8px;margin-top:2px;color:#445;">
      <code style="color:#fdcb6e;">ENV.debug.setOptions({ depth: 4 })</code>
      <code style="color:#fdcb6e;">ENV.debug.getConfig()</code>
    </div>
  `;

  body.appendChild(commandsContainer);
  panelInstance[ENV_PRIVATE.COMMANDS_CONTAINER] = commandsContainer;

  // Статус бейдж
  const badge = document.getElementById('panel-status-badge');
  if (badge) {
    panelInstance[ENV_PRIVATE.STATUS_BADGE] = badge;
    panelInstance[ENV_PRIVATE.UPDATE_BADGE]();
  }

  return body;
}

// ============================================================
// 8. ★★★ КЛАСС ENV PANEL ★★★
// ============================================================

class EnvPanel extends BasePanel {
  constructor(options = {}) {
    // Устанавливаем префикс и тип
    options.panelPrefix = options.panelPrefix || 'env';
    options.type = options.type || 'env';
    options.panelType = options.panelType || 'env';

    // ★★★ ВЫЗЫВАЕМ КОНСТРУКТОР РОДИТЕЛЯ ★★★
    super(options);

    // ★★★ ИНИЦИАЛИЗАЦИЯ ПРИВАТНЫХ СВОЙСТВ ★★★
    this[ENV_PRIVATE.CURRENT_NAMESPACE] = '';
    this[ENV_PRIVATE.PREVIOUS_NAMESPACE] = '';
    this[ENV_PRIVATE.GROUPS_CONTAINER] = null;
    this[ENV_PRIVATE.ACTIONS_CONTAINER] = null;
    this[ENV_PRIVATE.COMMANDS_CONTAINER] = null;
    this[ENV_PRIVATE.STATUS_BADGE] = null;
    this[ENV_PRIVATE.TIMERS] = new Map();
    this[ENV_PRIVATE.DEBOUNCE_TIMER] = null;
    this[ENV_PRIVATE.EVENT_HANDLERS] = new Map();
    this[ENV_PRIVATE.LOG_HISTORY] = [];
    this[ENV_PRIVATE.ENV_CACHE] = new Map();
    this[ENV_PRIVATE.ENV_STATE] = {
      namespace: '',
      isEnabled: false,
      lastAction: null,
      timestamp: null,
    };

    // ★★★ ХРАНИЛИЩЕ ДЛЯ ID ОБРАБОТЧИКОВ ★★★
    this[ENV_PRIVATE.HANDLER_IDS] = new Set();
    this[ENV_PRIVATE.BOUND_FOCUS] = this._handleFocus.bind(this);

    // ★★★ ПЕРЕОПРЕДЕЛЯЕМ МЕТОДЫ ЧЕРЕЗ defineProperty ★★★

    // 1. BUILD_BODY
    Object.defineProperty(this, PRIVATE.BUILD_BODY, {
      value() {
        return buildEnvBody(this);
      },
      configurable: true,
      enumerable: false,
      writable: false,
    });

    // 2. Иконка
    Object.defineProperty(this, ENV_PRIVATE.GET_ICON, {
      value() {
        return '🔍';
      },
      configurable: true,
      enumerable: false,
      writable: false,
    });

    // 3. Заголовок
    Object.defineProperty(this, ENV_PRIVATE.GET_TITLE, {
      value() {
        return this[PRIVATE.NAME] || 'ENV Control';
      },
      configurable: true,
      enumerable: false,
      writable: false,
    });

    // ★★★ ЗАГРУЗКА СОСТОЯНИЯ ★★★
    this[ENV_PRIVATE.LOAD_STATE]();

    // ★★★ НАСТРОЙКА АВТО-ОБНОВЛЕНИЯ ★★★
    this._setupAutoUpdate();

    // ★★★ НАСТРОЙКА ОБРАБОТЧИКОВ ★★★
    this._setupHandlers();

    // ★★★ НАСТРОЙКА СЛУШАТЕЛЕЙ ★★★
    this._setupListeners();

    // ★★★ ЗАГРУЗКА ТЕКУЩЕГО NAMESPACE ★★★
    const env = getEnv();
    if (env?.debug?.namespace) {
      this[ENV_PRIVATE.SET_NAMESPACE](env.debug.namespace);
    }

    // Если панель уже построена — перестраиваем тело
    const existingBody = this[PRIVATE.PANEL]?.querySelector('#panel-body');
    if (existingBody) {
      const newBody = this[PRIVATE.BUILD_BODY]();
      existingBody.replaceWith(newBody);
      this[PRIVATE.BODY] = newBody;
    }

    // ★★★ ОБНОВЛЯЕМ UI ★★★
    this[ENV_PRIVATE.UPDATE_UI]();

    // ★★★ ЭКСПОРТ СИМВОЛОВ ★★★
    this._exportSymbols();
  }

  // ============================================================
  // 9. ★★★ ЭКСПОРТ СИМВОЛОВ (ОПРЕДЕЛЯЕМ МЕТОД) ★★★
  // ============================================================

  _exportSymbols() {
    if (typeof window === 'undefined') return;

    window[ENV_PUBLIC.API] = {
      setNamespace: this.setNamespace.bind(this),
      getNamespace: this.getNamespace.bind(this),
      resetNamespace: this.resetNamespace.bind(this),
      updateUI: this.updateUI.bind(this),
      getState: this.getState.bind(this),
      saveState: this.saveState.bind(this),
      loadState: this.loadState.bind(this),
      on: this.on.bind(this),
      off: this.off.bind(this),
      emit: this.emit.bind(this),
    };

    window[ENV_PUBLIC.STATE] = this.getState.bind(this);
    window[ENV_PUBLIC.CONFIG] = ENV_CONFIG;
    window[ENV_PUBLIC.LOGGER] = this[PRIVATE.LOGGER];
    window[ENV_PUBLIC.INSTANCE] = this;
    window[ENV_PUBLIC.NAMESPACE] = this.getNamespace.bind(this);
    window[ENV_PUBLIC.PRESETS] = ENV_CONFIG.GROUPS;

    window.__envPanel = this;
  }

  // ============================================================
  // 10. ★★★ ОБРАБОТЧИК ФОКУСА ★★★
  // ============================================================

  _handleFocus(event) {
    const panel = this[PRIVATE.PANEL];
    if (!panel) return;
    if (this[PRIVATE.DESTROYED]) return;

    if (event?.target?.closest('.panel-controls')) return;
    if (event?.target?.closest('button')) return;
    if (event?.target?.closest('input')) return;
    if (event?.target?.closest('select')) return;

    this.focus();
  }

  // ============================================================
  // 11. ★★★ НАСТРОЙКА АВТО-ОБНОВЛЕНИЯ ★★★
  // ============================================================

  _setupAutoUpdate() {
    const timer = setInterval(() => {
      if (this[PRIVATE.DESTROYED]) return;

      const env = getEnv();
      const currentNS = env?.debug?.namespace || '';
      const cachedNS = this[ENV_PRIVATE.CURRENT_NAMESPACE];

      if (currentNS !== cachedNS) {
        this[ENV_PRIVATE.CURRENT_NAMESPACE] = currentNS;
        this[ENV_PRIVATE.UPDATE_UI]();
      }
    }, ENV_CONFIG.AUTO_UPDATE_INTERVAL);

    this[ENV_PRIVATE.TIMERS].set('autoUpdate', timer);
  }

  // ============================================================
  // 12. ★★★ НАСТРОЙКА ОБРАБОТЧИКОВ ★★★
  // ============================================================
  
  _setupHandlers() {
    const panel = this[PRIVATE.PANEL];
    if (!panel) return;

    this._removeHandlers();

    const minBtn = panel.querySelector('#panel-minimize-btn');
    const maxBtn = panel.querySelector('#panel-maximize-btn');
    const closeBtn = panel.querySelector('#panel-close-btn');
    const header = panel.querySelector('#panel-header');

    const self = this;

    // ★★★ ФУНКЦИЯ ДЛЯ ПОДНЯТИЯ ПАНЕЛИ С СБРОСОМ Z-INDEX ★★★
    const bringToFront = () => {
      if (self[PRIVATE.DESTROYED]) return;
      if (!self[PRIVATE.PANEL]) return;

      // ★★★ ВЫЗЫВАЕМ МЕТОД FOCUS РОДИТЕЛЯ ★★★
      self.focus();
    };

    if (minBtn) {
      const handler = (e) => {
        e.stopPropagation();
        if (!self[PRIVATE.DESTROYED]) {
          self[PRIVATE.TOGGLE_MINIMIZE](panel);
          // ★★★ ПОСЛЕ МИНИМИЗАЦИИ ПОДНИМАЕМ ПАНЕЛЬ ★★★
          bringToFront();
        }
      };
      minBtn.addEventListener('click', handler);
      this[ENV_PRIVATE.HANDLER_IDS].add({ element: minBtn, event: 'click', handler });
    }

    if (maxBtn) {
      const handler = (e) => {
        e.stopPropagation();
        if (!self[PRIVATE.DESTROYED]) {
          self[PRIVATE.TOGGLE_FULLSCREEN](panel);
          // ★★★ ПОСЛЕ ПОЛНОЭКРАННОГО РЕЖИМА ПОДНИМАЕМ ПАНЕЛЬ ★★★
          bringToFront();
        }
      };
      maxBtn.addEventListener('click', handler);
      this[ENV_PRIVATE.HANDLER_IDS].add({ element: maxBtn, event: 'click', handler });
    }

    if (closeBtn) {
      const handler = (e) => {
        e.stopPropagation();
        if (!self[PRIVATE.DESTROYED]) {
          self[PRIVATE.CLOSE_PANEL](panel);
        }
      };
      closeBtn.addEventListener('click', handler);
      this[ENV_PRIVATE.HANDLER_IDS].add({ element: closeBtn, event: 'click', handler });
    }

    if (header) {
      const dblClickHandler = (e) => {
        if (e.target.closest('.panel-controls')) return;
        if (!self[PRIVATE.DESTROYED] && maxBtn) {
          maxBtn.click();
        }
      };
      header.addEventListener('dblclick', dblClickHandler);
      this[ENV_PRIVATE.HANDLER_IDS].add({ element: header, event: 'dblclick', handler: dblClickHandler });

      // ★★★ ФОКУС ПРИ КЛИКЕ НА ШАПКУ ★★★
      const focusHandler = (e) => {
        if (e.target.closest('.panel-controls')) return;
        bringToFront();
      };
      header.addEventListener('mousedown', focusHandler);
      this[ENV_PRIVATE.HANDLER_IDS].add({ element: header, event: 'mousedown', handler: focusHandler });
    }

    // ★★★ КЛИК ПО ПАНЕЛИ — ФОКУС ★★★
    const panelFocusHandler = (e) => {
      if (e.target.closest('.panel-controls')) return;
      if (e.target.closest('button')) return;
      if (e.target.closest('input')) return;
      if (e.target.closest('select')) return;
      bringToFront();
    };
    panel.addEventListener('mousedown', panelFocusHandler);
    this[ENV_PRIVATE.HANDLER_IDS].add({ element: panel, event: 'mousedown', handler: panelFocusHandler });
  }

  // ============================================================
  // 13. ★★★ УДАЛЕНИЕ ОБРАБОТЧИКОВ ★★★
  // ============================================================

  _removeHandlers() {
    for (const item of this[ENV_PRIVATE.HANDLER_IDS]) {
      try {
        item.element.removeEventListener(item.event, item.handler);
      } catch (e) {
        // Игнорируем ошибки при удалении
      }
    }
    this[ENV_PRIVATE.HANDLER_IDS].clear();
  }

  // ============================================================
  // 14. ★★★ НАСТРОЙКА СЛУШАТЕЛЕЙ ★★★
  // ============================================================

  _setupListeners() {
    this._storageHandler = (e) => {
      if (this[PRIVATE.DESTROYED]) return;
      if (e.key === 'debug' && e.newValue !== null) {
        const ns = e.newValue;
        this[ENV_PRIVATE.CURRENT_NAMESPACE] = ns;
        this[ENV_PRIVATE.UPDATE_UI]();
      }
    };
    window.addEventListener('storage', this._storageHandler);

    const env = getEnv();
    if (env?.debug?.on) {
      this._envHandler = (data) => {
        if (this[PRIVATE.DESTROYED]) return;
        const ns = data.namespace || '';
        this[ENV_PRIVATE.CURRENT_NAMESPACE] = ns;
        this[ENV_PRIVATE.UPDATE_UI]();
      };
      env.debug.on('change', this._envHandler);
    }
  }

  // ============================================================
  // 15. ★★★ ОБНОВЛЕНИЕ UI ★★★
  // ============================================================

  [ENV_PRIVATE.UPDATE_UI]() {
    this[ENV_PRIVATE.UPDATE_PRESETS]();
    this[ENV_PRIVATE.UPDATE_ACTIONS]();
    this[ENV_PRIVATE.UPDATE_BADGE]();
    this[ENV_PRIVATE.SAVE_STATE]();
  }

  [ENV_PRIVATE.UPDATE_PRESETS]() {
    const container = this[ENV_PRIVATE.GROUPS_CONTAINER];
    if (!container) return;

    const current = this[ENV_PRIVATE.CURRENT_NAMESPACE] || '';
    const buttons = container.querySelectorAll('.preset-btn');

    for (const btn of buttons) {
      const preset = btn.dataset.preset || '';
      const active = preset === current;

      btn.style.background = active ? 'rgba(102,126,234,0.3)' : 'rgba(255,255,255,0.03)';
      btn.style.color = active ? '#fff' : '#8899bb';
      btn.style.borderColor = active ? '#667eea' : 'rgba(255,255,255,0.05)';
    }
  }

  [ENV_PRIVATE.UPDATE_ACTIONS]() {
    const container = this[ENV_PRIVATE.ACTIONS_CONTAINER];
    if (!container) return;

    const current = this[ENV_PRIVATE.CURRENT_NAMESPACE] || '';
    const isEnabled = !!current;

    const buttons = container.querySelectorAll('.action-btn');
    for (const btn of buttons) {
      const action = btn.dataset.action;
      if (action === 'enableAll') {
        btn.style.color = isEnabled ? '#00b894' : '#8899bb';
        btn.style.background = isEnabled ? 'rgba(0,184,148,0.1)' : 'rgba(255,255,255,0.03)';
      }
    }
  }

  [ENV_PRIVATE.UPDATE_BADGE]() {
    const badge = this[ENV_PRIVATE.STATUS_BADGE];
    if (!badge) return;

    const current = this[ENV_PRIVATE.CURRENT_NAMESPACE] || '';
    const isOn = !!current;

    badge.textContent = current || 'off';
    badge.style.background = isOn ? 'rgba(0,184,148,0.15)' : 'rgba(255,255,255,0.05)';
    badge.style.color = isOn ? '#00b894' : '#636e72';
    badge.style.borderColor = isOn ? 'rgba(0,184,148,0.2)' : 'rgba(255,255,255,0.05)';
  }

  // ============================================================
  // 16. ★★★ ОБРАБОТКА ПРЕСЕТА ★★★
  // ============================================================

  [ENV_PRIVATE.HANDLE_PRESET](preset) {
    const previous = this[ENV_PRIVATE.CURRENT_NAMESPACE];
    this[ENV_PRIVATE.PREVIOUS_NAMESPACE] = previous;

    if (preset !== undefined && preset !== null) {
      this[ENV_PRIVATE.SET_NAMESPACE](preset);
    }

    this[ENV_PRIVATE.EMIT]('preset', {
      preset,
      previous,
      current: this[ENV_PRIVATE.CURRENT_NAMESPACE],
      timestamp: Date.now(),
    });
  }

  // ============================================================
  // 17. ★★★ ОБРАБОТКА ДЕЙСТВИЯ ★★★
  // ============================================================

  [ENV_PRIVATE.HANDLE_ACTION](action) {
    const logger = this[PRIVATE.LOGGER];

    switch (action) {
      case 'enableAll':
        this[ENV_PRIVATE.SET_NAMESPACE]('wasm:*');
        break;
      case 'disableAll':
        this[ENV_PRIVATE.SET_NAMESPACE]('');
        break;
      case 'enableBookmarklet':
        this[ENV_PRIVATE.SET_NAMESPACE]('bookmarklet:*');
        break;
      case 'showEnv':
        const env = getEnv();
        if (env?.debug?.getConfig) {
          const config = env.debug.getConfig();
          logger.info('📊 ENV Config:', config);
          alert('📊 ENV Config:\n' + JSON.stringify(config, null, 2));
        }
        break;
      case 'sync':
        const inst = getInstance();
        if (inst && inst.sync) {
          inst.sync('merge');
          logger.success('✅ Синхронизация выполнена');
        }
        break;
      case 'export':
        const inst2 = getInstance();
        if (inst2 && inst2.export) {
          const json = inst2.export();
          navigator.clipboard.writeText(json).then(() => {
            logger.success('✅ Состояние скопировано в буфер обмена');
          });
        }
        break;
      case 'reset':
        if (confirm('Сбросить состояние к дефолтному?')) {
          const inst3 = getInstance();
          if (inst3 && inst3.reset) {
            inst3.reset();
            this[ENV_PRIVATE.SET_NAMESPACE]('');
            logger.success('✅ Состояние сброшено');
          }
        }
        break;
      case 'history':
        const inst4 = getInstance();
        if (inst4 && inst4.getHistory) {
          const history = inst4.getHistory();
          logger.info('📜 История изменений:', history);
          alert('📜 История изменений:\n' + JSON.stringify(history.slice(-10), null, 2));
        }
        break;
      case 'sharedMemory':
        const inst5 = getInstance();
        if (inst5 && inst5.checkSharedMemory) {
          const status = inst5.checkSharedMemory();
          logger.info('🧠 SharedMemory статус:', status);
          alert('🧠 SharedMemory статус:\n' + JSON.stringify(status, null, 2));
        }
        break;
      default:
        logger.warn(`⚠️ Неизвестное действие: ${action}`);
        break;
    }

    this[ENV_PRIVATE.EMIT]('action', {
      action,
      timestamp: Date.now(),
      namespace: this[ENV_PRIVATE.CURRENT_NAMESPACE],
    });
  }

  // ============================================================
  // 18. ★★★ УСТАНОВКА NAMESPACE ★★★
  // ============================================================

  [ENV_PRIVATE.SET_NAMESPACE](namespace) {
    const previous = this[ENV_PRIVATE.CURRENT_NAMESPACE];
    const normalized = namespace || '';

    if (normalized === previous) return;

    this[ENV_PRIVATE.PREVIOUS_NAMESPACE] = previous;
    this[ENV_PRIVATE.CURRENT_NAMESPACE] = normalized;

    const env = getEnv();
    if (env?.debug) {
      if (normalized) {
        env.debug.enable(normalized);
      } else {
        env.debug.disable();
      }
    }

    try {
      localStorage.setItem('debug', normalized);
    } catch (e) {}

    this[ENV_PRIVATE.UPDATE_UI]();
    this[ENV_PRIVATE.SAVE_STATE]();

    this[ENV_PRIVATE.EMIT]('namespaceChange', {
      previous,
      current: normalized,
      timestamp: Date.now(),
    });

    const logger = this[PRIVATE.LOGGER];
    logger.info(`🔍 Namespace: ${normalized || 'off'}`);
  }

  [ENV_PRIVATE.GET_NAMESPACE]() {
    return this[ENV_PRIVATE.CURRENT_NAMESPACE] || '';
  }

  [ENV_PRIVATE.RESET_NAMESPACE]() {
    return this[ENV_PRIVATE.SET_NAMESPACE](ENV_CONFIG.DEFAULT_NAMESPACE);
  }

  // ============================================================
  // 19. ★★★ СОХРАНЕНИЕ/ЗАГРУЗКА СОСТОЯНИЯ ★★★
  // ============================================================

  [ENV_PRIVATE.SAVE_STATE]() {
    try {
      const state = {
        namespace: this[ENV_PRIVATE.CURRENT_NAMESPACE],
        previous: this[ENV_PRIVATE.PREVIOUS_NAMESPACE],
        timestamp: Date.now(),
        version: '2.4.6',
      };
      localStorage.setItem(ENV_CONFIG.STORAGE_KEY, JSON.stringify(state));
    } catch (e) {
      // Игнорируем ошибки localStorage
    }
  }

  [ENV_PRIVATE.LOAD_STATE]() {
    try {
      const saved = localStorage.getItem(ENV_CONFIG.STORAGE_KEY);
      if (saved) {
        const state = JSON.parse(saved);
        if (state.namespace !== undefined) {
          this[ENV_PRIVATE.CURRENT_NAMESPACE] = state.namespace;
        }
        if (state.previous !== undefined) {
          this[ENV_PRIVATE.PREVIOUS_NAMESPACE] = state.previous;
        }
      }
    } catch (e) {
      // Игнорируем ошибки
    }
  }

  // ============================================================
  // 20. ★★★ СОБЫТИЯ ★★★
  // ============================================================

  [ENV_PRIVATE.ON](event, callback) {
    if (typeof callback !== 'function') {
      this[PRIVATE.LOGGER].warn(`⚠️ Некорректный callback для события ${event}`);
      return () => {};
    }

    const handlers = this[ENV_PRIVATE.EVENT_HANDLERS];
    if (!handlers.has(event)) {
      handlers.set(event, []);
    }
    handlers.get(event).push(callback);

    return () => this[ENV_PRIVATE.OFF](event, callback);
  }

  [ENV_PRIVATE.OFF](event, callback) {
    const handlers = this[ENV_PRIVATE.EVENT_HANDLERS];
    if (handlers.has(event)) {
      const list = handlers.get(event);
      const index = list.indexOf(callback);
      if (index !== -1) {
        list.splice(index, 1);
      }
      if (list.length === 0) {
        handlers.delete(event);
      }
    }
  }

  [ENV_PRIVATE.EMIT](event, data) {
    const handlers = this[ENV_PRIVATE.EVENT_HANDLERS];
    if (handlers.has(event)) {
      const list = handlers.get(event);
      for (const callback of list) {
        try {
          callback(data);
        } catch (e) {
          this[PRIVATE.LOGGER].error(`❌ Ошибка в обработчике ${event}:`, e.message);
        }
      }
    }

    if (typeof window !== 'undefined') {
      try {
        const customEvent = new CustomEvent(`env-panel:${event}`, {
          detail: data,
        });
        window.dispatchEvent(customEvent);
      } catch (e) {
        // Игнорируем
      }
    }
  }

  // ============================================================
  // 21. ★★★ ПУБЛИЧНЫЕ МЕТОДЫ ★★★
  // ============================================================

  setNamespace(namespace) {
    return this[ENV_PRIVATE.SET_NAMESPACE](namespace);
  }

  getNamespace() {
    return this[ENV_PRIVATE.GET_NAMESPACE]();
  }

  resetNamespace() {
    return this[ENV_PRIVATE.RESET_NAMESPACE]();
  }

  updateUI() {
    return this[ENV_PRIVATE.UPDATE_UI]();
  }

  on(event, callback) {
    return this[ENV_PRIVATE.ON](event, callback);
  }

  off(event, callback) {
    return this[ENV_PRIVATE.OFF](event, callback);
  }

  emit(event, data) {
    return this[ENV_PRIVATE.EMIT](event, data);
  }

  saveState() {
    return this[ENV_PRIVATE.SAVE_STATE]();
  }

  loadState() {
    return this[ENV_PRIVATE.LOAD_STATE]();
  }

  focus() {
    if (this[PRIVATE.DESTROYED]) return this;
    if (!this[PRIVATE.PANEL]) return this;

    super.focus();
    return this;
  }

  // ============================================================
  // 22. ★★★ УНИЧТОЖЕНИЕ ★★★
  // ============================================================

  destroy() {
    if (this[PRIVATE.DESTROYED]) return;

    const logger = this[PRIVATE.LOGGER];
    logger.warn('🗑️ Уничтожение ENV панели...');

    this._removeHandlers();

    if (this._storageHandler) {
      window.removeEventListener('storage', this._storageHandler);
      this._storageHandler = null;
    }
    if (this._envHandler) {
      const env = getEnv();
      if (env?.debug?.off) {
        env.debug.off('change', this._envHandler);
      }
      this._envHandler = null;
    }

    for (const [key, timer] of this[ENV_PRIVATE.TIMERS]) {
      clearInterval(timer);
      clearTimeout(timer);
    }
    this[ENV_PRIVATE.TIMERS].clear();

    if (this[ENV_PRIVATE.DEBOUNCE_TIMER]) {
      clearTimeout(this[ENV_PRIVATE.DEBOUNCE_TIMER]);
      this[ENV_PRIVATE.DEBOUNCE_TIMER] = null;
    }

    this[ENV_PRIVATE.EVENT_HANDLERS].clear();
    this[ENV_PRIVATE.ENV_CACHE].clear();

    if (typeof window !== 'undefined') {
      delete window[ENV_PUBLIC.API];
      delete window[ENV_PUBLIC.STATE];
      delete window[ENV_PUBLIC.CONFIG];
      delete window[ENV_PUBLIC.LOGGER];
      delete window[ENV_PUBLIC.INSTANCE];
      delete window[ENV_PUBLIC.NAMESPACE];
      delete window[ENV_PUBLIC.PRESETS];
      if (window.__envPanel === this) {
        delete window.__envPanel;
      }
    }

    super.destroy();

    logger.success('✅ ENV панель уничтожена');
  }
}

// ============================================================
// 23. ★★★ ОСНОВНАЯ ФУНКЦИЯ ★★★
// ============================================================

export default async function (props = {}, callback = null) {
  const instanceId = props.id || generateInstanceId();
  const panelId = props.panelId || generatePanelId('env');
  const name = props.name || (typeof document !== 'undefined' && document.title) || 'ENV Control';

  const existingPanel = document.getElementById(panelId);
  if (existingPanel) {
    const isVisible = existingPanel.style.display !== 'none';
    if (!isVisible) {
      existingPanel.style.display = 'flex';
      existingPanel.style.opacity = '1';
      existingPanel.style.transform = 'scale(1)';
    }
    if (typeof callback === 'function') {
      try {
        callback({
          success: true,
          action: 'toggle',
          visible: !isVisible,
          panel: existingPanel,
          existing: true,
          panelId,
          instanceId,
        });
      } catch (cbError) {
        console.error(`[ENV] Ошибка в callback: ${cbError.message}`);
      }
    }
    return existingPanel.__envPanelInstance || existingPanel;
  }

  const panelInstance = new EnvPanel({
    id: instanceId,
    panelId,
    name,
    position: props.position || { x: 100, y: 100 },
    size: props.size || { width: 420, height: 520 },
    zIndex: props.zIndex || 99996,
    callback,
    debug: props.debug !== false,
  });

  const panelElement = panelInstance[PRIVATE.PANEL];
  if (panelElement) {
    panelElement.__envPanelInstance = panelInstance;
  }

  if (typeof window !== 'undefined') {
    window.__envPanel = panelInstance;
  }

  return panelInstance;
}

// ============================================================
// 24. ★★★ ЭКСПОРТЫ ★★★
// ============================================================

export {
  EnvPanel,
  ENV_PRIVATE,
  ENV_PUBLIC,
  ENV_CONFIG,
  getEnv,
  getInstance,
  buildEnvBody,
};

// ============================================================
// 25. ★★★ ГЛОБАЛЬНЫЙ ЭКСПОРТ ★★★
// ============================================================

if (typeof window !== 'undefined') {
  window.EnvPanel = EnvPanel;
  window.ENV_PRIVATE = ENV_PRIVATE;
  window.ENV_PUBLIC = ENV_PUBLIC;
  window.ENV_CONFIG = ENV_CONFIG;

  console.log('╔═══════════════════════════════════════════════════════════════════╗');
  console.log('║              📦 ENV PANEL (100% СИМВОЛЫ) v2.4.6                 ║');
  console.log('╠═══════════════════════════════════════════════════════════════════╣');
  console.log(`║  🔑 ENV_PRIVATE символов: ${Object.keys(ENV_PRIVATE).length}     ║`);
  console.log(`║  🔓 ENV_PUBLIC символов:  ${Object.keys(ENV_PUBLIC).length}     ║`);
  console.log(`║  📊 Всего ENV символов:   ${Object.keys(ENV_PRIVATE).length + Object.keys(ENV_PUBLIC).length} ║`);
  console.log('╠═══════════════════════════════════════════════════════════════════╣');
  console.log('║  ✅ ИСПРАВЛЕНО: PRIVATE определён ДО использования              ║');
  console.log('║  ✅ ИСПРАВЛЕНО: _exportSymbols определён как метод класса       ║');
  console.log('║  ✅ Загрузка состояния из localStorage                          ║');
  console.log('║  ✅ Авто-обновление при изменении ENV                           ║');
  console.log('║  ✅ События: preset, action, namespaceChange                    ║');
  console.log('║  ✅ Синхронизация с ENV.debug                                  ║');
  console.log('║  ✅ 8+ групп пресетов                                          ║');
  console.log('║  ✅ 9 быстрых действий                                         ║');
  console.log('║  ✅ ИСПРАВЛЕНА: повторное переключение фокуса                  ║');
  console.log('║  ✅ ИСПРАВЛЕНО: удаление старых обработчиков                   ║');
  console.log('║  ✅ ИСПРАВЛЕНО: проверка контекста при вызове focus            ║');
  console.log('╚═══════════════════════════════════════════════════════════════════╝');
}
