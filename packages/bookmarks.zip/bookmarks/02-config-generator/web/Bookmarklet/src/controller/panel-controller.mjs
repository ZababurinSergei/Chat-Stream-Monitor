// web/Bookmarklet/src/controller/panel-controller.mjs
// Базовый контроллер для панелей — 100% СИМВОЛЫ
// Полная изоляция и безопасность
// Версия: 2.1.0

// ============================================================
// 1. ПРИВАТНЫЕ СИМВОЛЫ (100% изоляция)
// ============================================================

export const PANEL_CONTROLLER_SYMBOLS = {
  // ============================================================
  // ОСНОВНЫЕ СИМВОЛЫ (10)
  // ============================================================

  // DOM элементы
  PANEL: Symbol('panel-controller.panel'),
  MIN_BTN: Symbol('panel-controller.minBtn'),
  MAX_BTN: Symbol('panel-controller.maxBtn'),
  CLOSE_BTN: Symbol('panel-controller.closeBtn'),
  HEADER: Symbol('panel-controller.header'),
  BODY: Symbol('panel-controller.body'),
  RESIZE: Symbol('panel-controller.resize'),

  // Действия
  ACTIONS: Symbol('panel-controller.actions'),
  ACTION_HANDLERS: Symbol('panel-controller.actionHandlers'),

  // Состояние
  STATE: Symbol('panel-controller.state'),
  INITIALIZED: Symbol('panel-controller.initialized'),
  DESTROYED: Symbol('panel-controller.destroyed'),

  // ============================================================
  // ДАННЫЕ (8)
  // ============================================================

  ID: Symbol('panel-controller.id'),
  NAME: Symbol('panel-controller.name'),
  TYPE: Symbol('panel-controller.type'),
  VERSION: Symbol('panel-controller.version'),
  PANEL_ID: Symbol('panel-controller.panelId'),
  PANEL_TYPE: Symbol('panel-controller.panelType'),
  POSITION: Symbol('panel-controller.position'),
  SIZE: Symbol('panel-controller.size'),
  Z_INDEX: Symbol('panel-controller.zIndex'),

  // ============================================================
  // МЕТАДАННЫЕ (6)
  // ============================================================

  METADATA: Symbol('panel-controller.metadata'),
  CONTEXT: Symbol('panel-controller.context'),
  LOG_HISTORY: Symbol('panel-controller.logHistory'),
  TIMERS: Symbol('panel-controller.timers'),
  CACHE: Symbol('panel-controller.cache'),
  LISTENERS: Symbol('panel-controller.listeners'),

  // ============================================================
  // БЕЗОПАСНОСТЬ (4)
  // ============================================================

  SECURE: Symbol('panel-controller.secure'),
  VALIDATOR: Symbol('panel-controller.validator'),
  SANDBOX: Symbol('panel-controller.sandbox'),
  PERMISSIONS: Symbol('panel-controller.permissions'),

  // ============================================================
  // СОБЫТИЯ (4)
  // ============================================================

  EVENT_HANDLERS: Symbol('panel-controller.eventHandlers'),
  EVENT_QUEUE: Symbol('panel-controller.eventQueue'),
  EVENT_BUS: Symbol('panel-controller.eventBus'),
  EVENT_SUBSCRIBERS: Symbol('panel-controller.eventSubscribers'),

  // ============================================================
  // МЕТОДЫ (ПРИВАТНЫЕ) — 24
  // ============================================================

  // Управление состоянием
  SET_STATE: Symbol('panel-controller.setState'),
  GET_STATE: Symbol('panel-controller.getState'),
  UPDATE_STATE: Symbol('panel-controller.updateState'),
  RESET_STATE: Symbol('panel-controller.resetState'),

  // Действия
  SHOW: Symbol('panel-controller.show'),
  HIDE: Symbol('panel-controller.hide'),
  TOGGLE: Symbol('panel-controller.toggle'),
  MINIMIZE: Symbol('panel-controller.minimize'),
  MAXIMIZE: Symbol('panel-controller.maximize'),
  FULLSCREEN: Symbol('panel-controller.fullscreen'),
  CLOSE: Symbol('panel-controller.close'),
  FOCUS: Symbol('panel-controller.focus'),
  RESIZE: Symbol('panel-controller.resize'),
  MOVE: Symbol('panel-controller.move'),

  // Обработчики
  SETUP_HANDLERS: Symbol('panel-controller.setupHandlers'),
  SETUP_DRAG: Symbol('panel-controller.setupDrag'),
  SETUP_RESIZE: Symbol('panel-controller.setupResize'),
  HANDLE_ACTION: Symbol('panel-controller.handleAction'),
  HANDLE_EVENT: Symbol('panel-controller.handleEvent'),

  // Утилиты
  VALIDATE: Symbol('panel-controller.validate'),
  SANITIZE: Symbol('panel-controller.sanitize'),
  LOG: Symbol('panel-controller.log'),
  GET_LOGGER: Symbol('panel-controller.getLogger'),

  // Жизненный цикл
  INIT: Symbol('panel-controller.init'),
  DESTROY: Symbol('panel-controller.destroy'),
  RESET: Symbol('panel-controller.reset'),
  RELOAD: Symbol('panel-controller.reload'),

  // ============================================================
  // ДОПОЛНИТЕЛЬНЫЕ СИМВОЛЫ (12)
  // ============================================================

  // Работа с DOM
  CREATE_ELEMENT: Symbol('panel-controller.createElement'),
  GET_ELEMENT: Symbol('panel-controller.getElement'),
  UPDATE_ELEMENT: Symbol('panel-controller.updateElement'),
  REMOVE_ELEMENT: Symbol('panel-controller.removeElement'),

  // Анимация
  ANIMATE: Symbol('panel-controller.animate'),
  TRANSITION: Symbol('panel-controller.transition'),

  // Синхронизация
  SYNC: Symbol('panel-controller.sync'),
  SAVE: Symbol('panel-controller.save'),
  LOAD: Symbol('panel-controller.load'),

  // Экспорт/Импорт
  EXPORT: Symbol('panel-controller.export'),
  IMPORT: Symbol('panel-controller.import'),

  // Отладка
  DEBUG: Symbol('panel-controller.debug'),
  TRACE: Symbol('panel-controller.trace'),
};

// ============================================================
// 2. ПУБЛИЧНЫЕ СИМВОЛЫ (доступны через Symbol.for)
// ============================================================

export const PUBLIC_PANEL_CONTROLLER = {
  API: Symbol.for('panel-controller.api'),
  STATE: Symbol.for('panel-controller.state'),
  CONFIG: Symbol.for('panel-controller.config'),
  LOGGER: Symbol.for('panel-controller.logger'),
  INSTANCE: Symbol.for('panel-controller.instance'),
  EVENTS: Symbol.for('panel-controller.events'),
  ACTIONS: Symbol.for('panel-controller.actions'),
  PANEL: Symbol.for('panel-controller.panel'),
};

// ============================================================
// 3. КОНФИГУРАЦИЯ
// ============================================================

const DEFAULT_CONFIG = {
  version: '2.1.0',
  debug: true,
  minWidth: 320,
  minHeight: 300,
  maxWidth: '90vw',
  maxHeight: '90vh',
  zIndex: 99996,
  animationDuration: 300,
  dragHandle: '#panel-header',
  resizeHandle: '#panel-resize',
};

const DEFAULT_STATE = {
  visible: true,
  minimized: false,
  fullscreen: false,
  focused: false,
  position: { x: 100, y: 100 },
  size: { width: 420, height: 520 },
  zIndex: 99996,
  opacity: 1,
  scale: 1,
};

// ============================================================
// 4. ВАЛИДАТОР (с приватными символами)
// ============================================================

const VALIDATOR = {
  [PANEL_CONTROLLER_SYMBOLS.VALIDATOR]: {
    isValidId: id => id && typeof id === 'string' && id.length > 0,
    isValidName: name => name && typeof name === 'string' && name.length > 0,
    isValidType: type => ['main', 'env', 'logs', 'debug', 'manager', 'widget'].includes(type),
    isValidPanel: panel => panel && panel instanceof HTMLElement,
    isValidPosition: pos =>
      pos && typeof pos === 'object' && typeof pos.x === 'number' && typeof pos.y === 'number',
    isValidSize: size =>
      size &&
      typeof size === 'object' &&
      typeof size.width === 'number' &&
      typeof size.height === 'number',
    isValidCallback: fn => typeof fn === 'function',
    isValidConfig: config => config && typeof config === 'object',
    isValidAction: action => action && typeof action === 'string' && action.length > 0,
  },
  [PANEL_CONTROLLER_SYMBOLS.SECURE]: {
    sanitize: value => {
      if (value === null || value === undefined) return null;
      if (typeof value === 'string') return value.replace(/[<>]/g, '');
      if (typeof value === 'object') {
        try {
          return JSON.parse(JSON.stringify(value));
        } catch {
          return null;
        }
      }
      return value;
    },
    validate: (value, schema) => {
      if (!schema) return true;
      if (schema.type && typeof value !== schema.type) return false;
      if (schema.min !== undefined && value < schema.min) return false;
      if (schema.max !== undefined && value > schema.max) return false;
      if (schema.pattern && !schema.pattern.test(value)) return false;
      return true;
    },
    deepClone: obj => {
      if (obj === null || obj === undefined) return obj;
      if (typeof obj !== 'object') return obj;
      if (obj instanceof Date) return new Date(obj.getTime());
      if (obj instanceof Array)
        return obj.map(item => VALIDATOR[PANEL_CONTROLLER_SYMBOLS.SECURE].deepClone(item));
      if (obj instanceof Map) {
        const cloned = new Map();
        for (const [key, value] of obj) {
          cloned.set(key, VALIDATOR[PANEL_CONTROLLER_SYMBOLS.SECURE].deepClone(value));
        }
        return cloned;
      }
      const cloned = {};
      for (const key in obj) {
        if (Object.prototype.hasOwnProperty.call(obj, key)) {
          try {
            cloned[key] = VALIDATOR[PANEL_CONTROLLER_SYMBOLS.SECURE].deepClone(obj[key]);
          } catch {
            cloned[key] = obj[key];
          }
        }
      }
      return cloned;
    },
  },
};

// ============================================================
// 5. ЛОГГЕР С ПРИВЯЗКОЙ КОНТЕКСТА (100% СИМВОЛЫ)
// ============================================================

const LOGGER_SYMBOLS = {
  HISTORY: Symbol('logger.history'),
  MAX_HISTORY: Symbol('logger.maxHistory'),
  DEBUG: Symbol('logger.debug'),
  INSTANCE_ID: Symbol('logger.instanceId'),
  LEVEL: Symbol('logger.level'),
  COLORS: Symbol('logger.colors'),
  TIMESTAMP: Symbol('logger.timestamp'),
  FORMATTERS: Symbol('logger.formatters'),
  FILTERS: Symbol('logger.filters'),
  OUTPUTS: Symbol('logger.outputs'),
  CONTEXT: Symbol('logger.context'),
  METADATA: Symbol('logger.metadata'),
  CHILDREN: Symbol('logger.children'),
  PARENT: Symbol('logger.parent'),
  SILENT: Symbol('logger.silent'),
  PRETTY: Symbol('logger.pretty'),
};

function createLogger(debug = true, instanceId = 'PanelController') {
  const state = {
    [LOGGER_SYMBOLS.HISTORY]: [],
    [LOGGER_SYMBOLS.MAX_HISTORY]: 200,
    [LOGGER_SYMBOLS.DEBUG]: debug,
    [LOGGER_SYMBOLS.INSTANCE_ID]: instanceId,
    [LOGGER_SYMBOLS.LEVEL]: 'INFO',
    [LOGGER_SYMBOLS.COLORS]: true,
    [LOGGER_SYMBOLS.TIMESTAMP]: true,
    [LOGGER_SYMBOLS.SILENT]: false,
    [LOGGER_SYMBOLS.PRETTY]: false,
    [LOGGER_SYMBOLS.CONTEXT]: new Map(),
    [LOGGER_SYMBOLS.METADATA]: new Map(),
    [LOGGER_SYMBOLS.FORMATTERS]: new Map(),
    [LOGGER_SYMBOLS.FILTERS]: new Map(),
    [LOGGER_SYMBOLS.OUTPUTS]: new Map(),
    [LOGGER_SYMBOLS.CHILDREN]: new Map(),
    [LOGGER_SYMBOLS.PARENT]: null,
  };

  const logMethod = function (level, message, data = null) {
    if (this[LOGGER_SYMBOLS.SILENT]) return;
    if (!this[LOGGER_SYMBOLS.DEBUG] && level !== 'error') return;

    const timestamp = new Date().toISOString().slice(11, 23);
    const prefix = `[${timestamp}] [${this[LOGGER_SYMBOLS.INSTANCE_ID]}]`;

    this[LOGGER_SYMBOLS.HISTORY].push({ timestamp, level, message, data });
    if (this[LOGGER_SYMBOLS.HISTORY].length > this[LOGGER_SYMBOLS.MAX_HISTORY]) {
      this[LOGGER_SYMBOLS.HISTORY].shift();
    }

    if (data !== null && data !== undefined) {
      console.log(`${prefix} ${message}`, data);
    } else {
      console.log(`${prefix} ${message}`);
    }
  };

  const boundLog = logMethod.bind(state);

  const logger = {
    [LOGGER_SYMBOLS.HISTORY]: state[LOGGER_SYMBOLS.HISTORY],
    [LOGGER_SYMBOLS.MAX_HISTORY]: state[LOGGER_SYMBOLS.MAX_HISTORY],
    [LOGGER_SYMBOLS.DEBUG]: state[LOGGER_SYMBOLS.DEBUG],
    [LOGGER_SYMBOLS.INSTANCE_ID]: state[LOGGER_SYMBOLS.INSTANCE_ID],
    [LOGGER_SYMBOLS.LEVEL]: state[LOGGER_SYMBOLS.LEVEL],
    [LOGGER_SYMBOLS.COLORS]: state[LOGGER_SYMBOLS.COLORS],
    [LOGGER_SYMBOLS.TIMESTAMP]: state[LOGGER_SYMBOLS.TIMESTAMP],
    [LOGGER_SYMBOLS.SILENT]: state[LOGGER_SYMBOLS.SILENT],
    [LOGGER_SYMBOLS.PRETTY]: state[LOGGER_SYMBOLS.PRETTY],
    [LOGGER_SYMBOLS.CONTEXT]: state[LOGGER_SYMBOLS.CONTEXT],
    [LOGGER_SYMBOLS.METADATA]: state[LOGGER_SYMBOLS.METADATA],
    [LOGGER_SYMBOLS.FORMATTERS]: state[LOGGER_SYMBOLS.FORMATTERS],
    [LOGGER_SYMBOLS.FILTERS]: state[LOGGER_SYMBOLS.FILTERS],
    [LOGGER_SYMBOLS.OUTPUTS]: state[LOGGER_SYMBOLS.OUTPUTS],
    [LOGGER_SYMBOLS.CHILDREN]: state[LOGGER_SYMBOLS.CHILDREN],
    [LOGGER_SYMBOLS.PARENT]: state[LOGGER_SYMBOLS.PARENT],

    // Основные методы
    error: function (msg, d) {
      boundLog('error', `❌ ${msg}`, d);
    },
    warn: function (msg, d) {
      boundLog('warn', `⚠️ ${msg}`, d);
    },
    info: function (msg, d) {
      boundLog('info', `ℹ️ ${msg}`, d);
    },
    debug: function (msg, d) {
      boundLog('debug', `🔍 ${msg}`, d);
    },
    success: function (msg, d) {
      boundLog('info', `✅ ${msg}`, d);
    },

    // Стилизованные методы
    header: function (title) {
      console.log('%c' + '═'.repeat(70), 'color: #636e72;');
      console.log(
        '%c  📦 ' + title,
        'background: #1a1a2e; color: #fff; padding: 4px 12px; border-radius: 4px; font-weight: bold;'
      );
      console.log('%c' + '═'.repeat(70), 'color: #636e72;');
    },

    separator: function () {
      console.log('%c' + '─'.repeat(70), 'color: #636e72;');
    },

    symbol: function (name, symbol) {
      console.log(`  🔑 ${name}: ${String(symbol)}`);
    },

    private: function (name, symbol) {
      console.log(`  🔒 ${name}: ${String(symbol)}`);
    },

    // Управление
    getHistory: function () {
      return [...this[LOGGER_SYMBOLS.HISTORY]];
    },
    clearHistory: function () {
      this[LOGGER_SYMBOLS.HISTORY] = [];
      return this;
    },
    setDebug: function (enabled) {
      this[LOGGER_SYMBOLS.DEBUG] = enabled;
      return this;
    },
    setLevel: function (level) {
      this[LOGGER_SYMBOLS.LEVEL] = level;
      return this;
    },
    getLevel: function () {
      return this[LOGGER_SYMBOLS.LEVEL];
    },

    // Контекст
    setContext: function (key, value) {
      this[LOGGER_SYMBOLS.CONTEXT].set(key, value);
      return this;
    },
    getContext: function (key) {
      return this[LOGGER_SYMBOLS.CONTEXT].get(key) || null;
    },
    clearContext: function () {
      this[LOGGER_SYMBOLS.CONTEXT].clear();
      return this;
    },

    // Метаданные
    setMetadata: function (key, value) {
      this[LOGGER_SYMBOLS.METADATA].set(key, value);
      return this;
    },
    getMetadata: function (key) {
      return this[LOGGER_SYMBOLS.METADATA].get(key) || null;
    },
    clearMetadata: function () {
      this[LOGGER_SYMBOLS.METADATA].clear();
      return this;
    },

    // Дочерние логгеры
    child: function (name, options = {}) {
      const child = createLogger(
        this[LOGGER_SYMBOLS.DEBUG],
        `${this[LOGGER_SYMBOLS.INSTANCE_ID]}:${name}`
      );
      child[LOGGER_SYMBOLS.PARENT] = this;
      this[LOGGER_SYMBOLS.CHILDREN].set(name, child);
      return child;
    },
    getChild: function (name) {
      return this[LOGGER_SYMBOLS.CHILDREN].get(name) || null;
    },
    getChildren: function () {
      return new Map(this[LOGGER_SYMBOLS.CHILDREN]);
    },
    removeChild: function (name) {
      const child = this[LOGGER_SYMBOLS.CHILDREN].get(name);
      if (child) {
        child[LOGGER_SYMBOLS.PARENT] = null;
        this[LOGGER_SYMBOLS.CHILDREN].delete(name);
        return true;
      }
      return false;
    },

    // Статистика
    getStats: function () {
      return {
        total: this[LOGGER_SYMBOLS.HISTORY].length,
        byLevel: this[LOGGER_SYMBOLS.HISTORY].reduce((acc, entry) => {
          acc[entry.level] = (acc[entry.level] || 0) + 1;
          return acc;
        }, {}),
        oldest: this[LOGGER_SYMBOLS.HISTORY][0]?.timestamp || null,
        newest:
          this[LOGGER_SYMBOLS.HISTORY][this[LOGGER_SYMBOLS.HISTORY].length - 1]?.timestamp || null,
        children: this[LOGGER_SYMBOLS.CHILDREN].size,
        context: Object.fromEntries(this[LOGGER_SYMBOLS.CONTEXT]),
        metadata: Object.fromEntries(this[LOGGER_SYMBOLS.METADATA]),
      };
    },
  };

  return logger;
}

// ============================================================
// 6. ОСНОВНОЙ КЛАСС PANEL CONTROLLER (100% СИМВОЛЫ)
// ============================================================

export class PanelController {
  constructor(options = {}) {
    // ============================================================
    // 6.1 ИНИЦИАЛИЗАЦИЯ
    // ============================================================

    const debug = options.debug !== false;
    const config = { ...DEFAULT_CONFIG, ...options.config };

    // ID и основные свойства
    this[PANEL_CONTROLLER_SYMBOLS.ID] =
      options.id || 'panel-' + Date.now() + '-' + Math.random().toString(36).substr(2, 4);
    this[PANEL_CONTROLLER_SYMBOLS.NAME] = options.name || 'Panel';
    this[PANEL_CONTROLLER_SYMBOLS.TYPE] = options.type || 'main';
    this[PANEL_CONTROLLER_SYMBOLS.VERSION] = options.version || DEFAULT_CONFIG.version;
    this[PANEL_CONTROLLER_SYMBOLS.PANEL_ID] = options.panelId || 'panel-' + Date.now();
    this[PANEL_CONTROLLER_SYMBOLS.PANEL_TYPE] = options.panelType || 'main';

    // Логгер
    this[PANEL_CONTROLLER_SYMBOLS.LOG] = createLogger(
      debug,
      `PanelController:${this[PANEL_CONTROLLER_SYMBOLS.ID].slice(-6)}`
    );
    const logger = this[PANEL_CONTROLLER_SYMBOLS.LOG];

    // ============================================================
    // 6.2 DOM ЭЛЕМЕНТЫ
    // ============================================================

    this[PANEL_CONTROLLER_SYMBOLS.PANEL] = options.panel || null;
    this[PANEL_CONTROLLER_SYMBOLS.MIN_BTN] = options.minBtn || null;
    this[PANEL_CONTROLLER_SYMBOLS.MAX_BTN] = options.maxBtn || null;
    this[PANEL_CONTROLLER_SYMBOLS.CLOSE_BTN] = options.closeBtn || null;
    this[PANEL_CONTROLLER_SYMBOLS.HEADER] = options.header || null;
    this[PANEL_CONTROLLER_SYMBOLS.BODY] = options.body || null;
    this[PANEL_CONTROLLER_SYMBOLS.RESIZE] = options.resize || null;

    // ============================================================
    // 6.3 ДЕЙСТВИЯ
    // ============================================================

    this[PANEL_CONTROLLER_SYMBOLS.ACTIONS] = options.actions || {};
    this[PANEL_CONTROLLER_SYMBOLS.ACTION_HANDLERS] = new Map();

    // ============================================================
    // 6.4 СОСТОЯНИЕ
    // ============================================================

    this[PANEL_CONTROLLER_SYMBOLS.STATE] = {
      ...DEFAULT_STATE,
      ...options.state,
      position: { ...DEFAULT_STATE.position, ...(options.state?.position || {}) },
      size: { ...DEFAULT_STATE.size, ...(options.state?.size || {}) },
    };

    this[PANEL_CONTROLLER_SYMBOLS.INITIALIZED] = false;
    this[PANEL_CONTROLLER_SYMBOLS.DESTROYED] = false;

    // ============================================================
    // 6.5 МЕТАДАННЫЕ
    // ============================================================

    this[PANEL_CONTROLLER_SYMBOLS.METADATA] = {
      created: Date.now(),
      lastAccess: Date.now(),
      lastUpdate: Date.now(),
      runCount: 0,
      errorCount: 0,
      actionCount: 0,
    };

    this[PANEL_CONTROLLER_SYMBOLS.CONTEXT] = {
      url: typeof window !== 'undefined' ? window.location.href : '',
      title: typeof window !== 'undefined' ? document.title : '',
      userAgent: typeof navigator !== 'undefined' ? navigator.userAgent : '',
      origin: typeof window !== 'undefined' ? window.location.origin : '',
    };

    this[PANEL_CONTROLLER_SYMBOLS.LOG_HISTORY] = [];
    this[PANEL_CONTROLLER_SYMBOLS.TIMERS] = new Map();
    this[PANEL_CONTROLLER_SYMBOLS.CACHE] = new Map();
    this[PANEL_CONTROLLER_SYMBOLS.LISTENERS] = [];
    this[PANEL_CONTROLLER_SYMBOLS.EVENT_HANDLERS] = new Map();
    this[PANEL_CONTROLLER_SYMBOLS.EVENT_QUEUE] = [];
    this[PANEL_CONTROLLER_SYMBOLS.EVENT_BUS] = new Map();
    this[PANEL_CONTROLLER_SYMBOLS.EVENT_SUBSCRIBERS] = new Map();

    // ============================================================
    // 6.6 ПЕСОЧНИЦА И РАЗРЕШЕНИЯ
    // ============================================================

    this[PANEL_CONTROLLER_SYMBOLS.SANDBOX] = {
      allowedActions: options.allowedActions || [
        'show',
        'hide',
        'toggle',
        'minimize',
        'maximize',
        'fullscreen',
        'close',
        'focus',
      ],
      allowedEvents: options.allowedEvents || ['click', 'mousedown', 'mouseup', 'keydown', 'keyup'],
      restricted: options.restricted || false,
    };

    this[PANEL_CONTROLLER_SYMBOLS.PERMISSIONS] = {
      canModifyDOM: options.canModifyDOM !== false,
      canAccessStorage: options.canAccessStorage !== false,
      canUseEvents: options.canUseEvents !== false,
      canUseTimers: options.canUseTimers !== false,
    };

    // ============================================================
    // 6.7 ПОЗИЦИЯ И РАЗМЕР
    // ============================================================

    this[PANEL_CONTROLLER_SYMBOLS.POSITION] = {
      x: options.position?.x || DEFAULT_STATE.position.x,
      y: options.position?.y || DEFAULT_STATE.position.y,
      unit: options.position?.unit || 'px',
    };

    this[PANEL_CONTROLLER_SYMBOLS.SIZE] = {
      width: options.size?.width || DEFAULT_STATE.size.width,
      height: options.size?.height || DEFAULT_STATE.size.height,
      unit: options.size?.unit || 'px',
    };

    this[PANEL_CONTROLLER_SYMBOLS.Z_INDEX] = options.zIndex || DEFAULT_STATE.zIndex;

    // ============================================================
    // 6.8 ИНИЦИАЛИЗАЦИЯ
    // ============================================================

    logger.header('СОЗДАНИЕ PANEL CONTROLLER (100% СИМВОЛЫ)');
    logger.info(`📦 Версия: ${this[PANEL_CONTROLLER_SYMBOLS.VERSION]}`);
    logger.info(`📌 ID: ${this[PANEL_CONTROLLER_SYMBOLS.ID].slice(-8)}`);
    logger.info(`📌 Имя: ${this[PANEL_CONTROLLER_SYMBOLS.NAME]}`);
    logger.info(`📌 Тип: ${this[PANEL_CONTROLLER_SYMBOLS.TYPE]}`);
    logger.info(`📌 Panel ID: ${this[PANEL_CONTROLLER_SYMBOLS.PANEL_ID]}`);

    logger.separator();
    logger.info(`🔑 ПРИВАТНЫХ СИМВОЛОВ: ${Object.keys(PANEL_CONTROLLER_SYMBOLS).length}`);
    logger.info(`🔑 ПУБЛИЧНЫХ СИМВОЛОВ: ${Object.keys(PUBLIC_PANEL_CONTROLLER).length}`);
    logger.separator();

    // Настройка обработчиков
    this[PANEL_CONTROLLER_SYMBOLS.INIT]();

    // Экспорт символов
    this[PANEL_CONTROLLER_SYMBOLS.EXPORT_SYMBOLS]?.();

    this[PANEL_CONTROLLER_SYMBOLS.INITIALIZED] = true;
    logger.success('✅ Panel Controller инициализирован (100% символы)');
    logger.header('ГОТОВ');
  }

  // ============================================================
  // 7. ИНИЦИАЛИЗАЦИЯ
  // ============================================================

  [PANEL_CONTROLLER_SYMBOLS.INIT]() {
    const logger = this[PANEL_CONTROLLER_SYMBOLS.LOG];
    logger.info('🔧 Инициализация...');

    // Применяем начальное состояние
    this[PANEL_CONTROLLER_SYMBOLS.APPLY_STATE]();

    // Настраиваем обработчики
    this[PANEL_CONTROLLER_SYMBOLS.SETUP_HANDLERS]();

    // Настраиваем перетаскивание
    this[PANEL_CONTROLLER_SYMBOLS.SETUP_DRAG]();

    // Настраиваем ресайз
    this[PANEL_CONTROLLER_SYMBOLS.SETUP_RESIZE]();

    // Регистрируем действия
    this[PANEL_CONTROLLER_SYMBOLS.REGISTER_ACTIONS]();

    // Загружаем сохранённое состояние
    this[PANEL_CONTROLLER_SYMBOLS.LOAD]();

    logger.success('✅ Инициализация завершена');
  }

  // ============================================================
  // 8. ПРИМЕНЕНИЕ СОСТОЯНИЯ
  // ============================================================

  [PANEL_CONTROLLER_SYMBOLS.APPLY_STATE]() {
    const panel = this[PANEL_CONTROLLER_SYMBOLS.PANEL];
    const state = this[PANEL_CONTROLLER_SYMBOLS.STATE];
    if (!panel) return;

    // Позиция
    panel.style.left = state.position.x + 'px';
    panel.style.top = state.position.y + 'px';

    // Размер
    panel.style.width = state.size.width + 'px';
    panel.style.height = state.size.height + 'px';

    // Z-index
    panel.style.zIndex = state.zIndex;

    // Видимость
    if (state.visible) {
      panel.style.display = 'flex';
    } else {
      panel.style.display = 'none';
    }

    // Минимизация
    if (state.minimized) {
      panel.classList.add('minimized');
      panel.style.height = '44px';
      panel.style.minHeight = '44px';
      panel.style.maxHeight = '44px';
      if (this[PANEL_CONTROLLER_SYMBOLS.MIN_BTN]) {
        this[PANEL_CONTROLLER_SYMBOLS.MIN_BTN].textContent = '□';
      }
    } else {
      panel.classList.remove('minimized');
      panel.style.height = state.size.height + 'px';
      panel.style.minHeight = '';
      panel.style.maxHeight = '';
      if (this[PANEL_CONTROLLER_SYMBOLS.MIN_BTN]) {
        this[PANEL_CONTROLLER_SYMBOLS.MIN_BTN].textContent = '─';
      }
    }

    // Полноэкранный режим
    if (state.fullscreen) {
      panel.classList.add('fullscreen');
      panel.style.width = '100vw';
      panel.style.height = '100vh';
      panel.style.top = '0';
      panel.style.left = '0';
      panel.style.borderRadius = '0';
      panel.style.border = 'none';
      panel.style.maxWidth = '100vw';
      panel.style.maxHeight = '100vh';
      panel.style.minWidth = '100vw';
      panel.style.minHeight = '100vh';
      panel.style.zIndex = '999999';
      document.body.style.overflow = 'hidden';
      if (this[PANEL_CONTROLLER_SYMBOLS.MAX_BTN]) {
        this[PANEL_CONTROLLER_SYMBOLS.MAX_BTN].textContent = '⧉';
      }
      if (this[PANEL_CONTROLLER_SYMBOLS.RESIZE]) {
        this[PANEL_CONTROLLER_SYMBOLS.RESIZE].style.display = 'none';
      }
    } else {
      panel.classList.remove('fullscreen');
      panel.style.width = state.size.width + 'px';
      panel.style.height = state.size.height + 'px';
      panel.style.top = state.position.y + 'px';
      panel.style.left = state.position.x + 'px';
      panel.style.borderRadius = '12px';
      panel.style.border = '1px solid rgba(255,255,255,0.08)';
      panel.style.maxWidth = '';
      panel.style.maxHeight = '';
      panel.style.minWidth = '320px';
      panel.style.minHeight = '300px';
      panel.style.zIndex = state.zIndex;
      document.body.style.overflow = '';
      if (this[PANEL_CONTROLLER_SYMBOLS.MAX_BTN]) {
        this[PANEL_CONTROLLER_SYMBOLS.MAX_BTN].textContent = '□';
      }
      if (this[PANEL_CONTROLLER_SYMBOLS.RESIZE]) {
        this[PANEL_CONTROLLER_SYMBOLS.RESIZE].style.display = '';
      }
    }

    // Фокус
    if (state.focused) {
      this[PANEL_CONTROLLER_SYMBOLS.FOCUS]();
    }
  }

  // ============================================================
  // 9. НАСТРОЙКА ОБРАБОТЧИКОВ
  // ============================================================

  [PANEL_CONTROLLER_SYMBOLS.SETUP_HANDLERS]() {
    const logger = this[PANEL_CONTROLLER_SYMBOLS.LOG];
    const panel = this[PANEL_CONTROLLER_SYMBOLS.PANEL];

    if (!panel) {
      logger.warn('⚠️ Панель не передана, обработчики не настроены');
      return;
    }

    logger.info('👂 Настройка обработчиков...');

    // Клик по панели — фокус
    panel.addEventListener('mousedown', e => {
      if (e.target.closest('.panel-controls')) return;
      if (e.target.closest('button')) return;
      if (e.target.closest('input')) return;
      if (e.target.closest('select')) return;
      if (e.target.closest('textarea')) return;
      this[PANEL_CONTROLLER_SYMBOLS.FOCUS]();
    });

    // Минимизация
    const minBtn = this[PANEL_CONTROLLER_SYMBOLS.MIN_BTN];
    if (minBtn) {
      minBtn.addEventListener('click', e => {
        e.stopPropagation();
        e.preventDefault();
        this[PANEL_CONTROLLER_SYMBOLS.MINIMIZE]();
      });
    }

    // Полноэкранный режим
    const maxBtn = this[PANEL_CONTROLLER_SYMBOLS.MAX_BTN];
    if (maxBtn) {
      maxBtn.addEventListener('click', e => {
        e.stopPropagation();
        e.preventDefault();
        this[PANEL_CONTROLLER_SYMBOLS.FULLSCREEN]();
      });
    }

    // Закрытие
    const closeBtn = this[PANEL_CONTROLLER_SYMBOLS.CLOSE_BTN];
    if (closeBtn) {
      closeBtn.addEventListener('click', e => {
        e.stopPropagation();
        e.preventDefault();
        this[PANEL_CONTROLLER_SYMBOLS.CLOSE]();
      });
    }

    // Двойной клик по шапке
    const header = this[PANEL_CONTROLLER_SYMBOLS.HEADER] || panel.querySelector('#panel-header');
    if (header) {
      header.addEventListener('dblclick', e => {
        if (e.target.closest('.panel-controls')) return;
        this[PANEL_CONTROLLER_SYMBOLS.FULLSCREEN]();
      });
    }

    // Клавиатурные сокращения
    document.addEventListener('keydown', e => {
      if (!this[PANEL_CONTROLLER_SYMBOLS.STATE].visible) return;
      if (e.key === 'Escape' && this[PANEL_CONTROLLER_SYMBOLS.STATE].fullscreen) {
        this[PANEL_CONTROLLER_SYMBOLS.FULLSCREEN]();
      }
      if ((e.ctrlKey || e.metaKey) && e.key === 'm') {
        e.preventDefault();
        this[PANEL_CONTROLLER_SYMBOLS.MINIMIZE]();
      }
    });

    // Обработка изменения размера окна
    window.addEventListener('resize', () => {
      this[PANEL_CONTROLLER_SYMBOLS.HANDLE_RESIZE]();
    });

    logger.success('✅ Обработчики настроены');
  }

  // ============================================================
  // 10. ПЕРЕТАСКИВАНИЕ
  // ============================================================

  [PANEL_CONTROLLER_SYMBOLS.SETUP_DRAG]() {
    const logger = this[PANEL_CONTROLLER_SYMBOLS.LOG];
    const panel = this[PANEL_CONTROLLER_SYMBOLS.PANEL];
    const header = this[PANEL_CONTROLLER_SYMBOLS.HEADER] || panel?.querySelector('#panel-header');

    if (!panel || !header) {
      logger.warn('⚠️ Панель или шапка не найдены, перетаскивание отключено');
      return;
    }

    logger.info('🖱️ Настройка перетаскивания...');

    let isDragging = false;
    let offsetX = 0,
      offsetY = 0;
    let startX = 0,
      startY = 0;
    let rafId = null;
    let hasMoved = false;

    const onMouseDown = e => {
      if (e.target.closest('.panel-controls')) return;
      if (this[PANEL_CONTROLLER_SYMBOLS.STATE].fullscreen) return;
      if (e.button !== 0) return;

      e.preventDefault();
      isDragging = true;
      hasMoved = false;

      const rect = panel.getBoundingClientRect();
      offsetX = e.clientX - rect.left;
      offsetY = e.clientY - rect.top;
      startX = rect.left;
      startY = rect.top;

      panel.style.transition = 'none';
      panel.style.cursor = 'grabbing';
      document.body.style.cursor = 'grabbing';
      document.body.style.userSelect = 'none';

      this[PANEL_CONTROLLER_SYMBOLS.FOCUS]();

      document.addEventListener('mousemove', onMouseMove, { passive: true });
      document.addEventListener('mouseup', onMouseUp, { passive: true });
    };

    const onMouseMove = e => {
      if (!isDragging) return;
      e.preventDefault();
      hasMoved = true;

      if (rafId) cancelAnimationFrame(rafId);
      rafId = requestAnimationFrame(() => {
        let x = e.clientX - offsetX;
        let y = e.clientY - offsetY;

        const maxX = window.innerWidth - panel.offsetWidth;
        const maxY = window.innerHeight - panel.offsetHeight;
        x = Math.max(0, Math.min(maxX, x));
        y = Math.max(0, Math.min(maxY, y));

        panel.style.transform = `translate(${x - startX}px, ${y - startY}px)`;
        panel.dataset.x = x;
        panel.dataset.y = y;

        this[PANEL_CONTROLLER_SYMBOLS.POSITION] = { x, y };
        rafId = null;
      });
    };

    const onMouseUp = () => {
      if (!isDragging) return;
      isDragging = false;

      document.removeEventListener('mousemove', onMouseMove);
      document.removeEventListener('mouseup', onMouseUp);

      const x = parseInt(panel.dataset.x) || parseInt(panel.style.left) || 100;
      const y = parseInt(panel.dataset.y) || parseInt(panel.style.top) || 100;

      panel.style.transform = 'none';
      panel.style.left = x + 'px';
      panel.style.top = y + 'px';
      panel.style.cursor = '';
      document.body.style.cursor = '';
      document.body.style.userSelect = '';

      this[PANEL_CONTROLLER_SYMBOLS.POSITION] = { x, y };
      this[PANEL_CONTROLLER_SYMBOLS.STATE].position = { x, y };

      if (rafId) {
        cancelAnimationFrame(rafId);
        rafId = null;
      }

      if (hasMoved) {
        this[PANEL_CONTROLLER_SYMBOLS.SAVE]();
      }
    };

    header.addEventListener('mousedown', onMouseDown);

    logger.success('✅ Перетаскивание настроено');
  }

  // ============================================================
  // 11. РЕСАЙЗ
  // ============================================================

  [PANEL_CONTROLLER_SYMBOLS.SETUP_RESIZE]() {
    const logger = this[PANEL_CONTROLLER_SYMBOLS.LOG];
    const panel = this[PANEL_CONTROLLER_SYMBOLS.PANEL];
    const resize = this[PANEL_CONTROLLER_SYMBOLS.RESIZE] || panel?.querySelector('#panel-resize');

    if (!panel || !resize) {
      logger.warn('⚠️ Панель или ресайз не найдены, ресайз отключён');
      return;
    }

    logger.info('📐 Настройка ресайза...');

    let isResizing = false;
    let startX = 0,
      startY = 0;
    let startW = 0,
      startH = 0;
    let rafId = null;

    const onMouseDown = e => {
      if (this[PANEL_CONTROLLER_SYMBOLS.STATE].fullscreen) return;
      e.stopPropagation();
      e.preventDefault();

      isResizing = true;

      startX = e.clientX;
      startY = e.clientY;
      startW = panel.offsetWidth;
      startH = panel.offsetHeight;

      panel.style.transition = 'none';
      document.body.style.cursor = 'nwse-resize';
      document.body.style.userSelect = 'none';

      this[PANEL_CONTROLLER_SYMBOLS.FOCUS]();

      document.addEventListener('mousemove', onMouseMove, { passive: true });
      document.addEventListener('mouseup', onMouseUp, { passive: true });
    };

    const onMouseMove = e => {
      if (!isResizing) return;
      e.preventDefault();

      if (rafId) cancelAnimationFrame(rafId);
      rafId = requestAnimationFrame(() => {
        const minW = parseInt(DEFAULT_CONFIG.minWidth) || 320;
        const minH = parseInt(DEFAULT_CONFIG.minHeight) || 300;
        const maxW = window.innerWidth * 0.9;
        const maxH = window.innerHeight * 0.9;

        let w = Math.max(minW, Math.min(maxW, startW + (e.clientX - startX)));
        let h = Math.max(minH, Math.min(maxH, startH + (e.clientY - startY)));

        // Сохраняем пропорции при Shift
        if (e.shiftKey) {
          const ratio = startW / startH;
          if (w / h > ratio) {
            w = h * ratio;
          } else {
            h = w / ratio;
          }
        }

        panel.style.width = w + 'px';
        panel.style.height = h + 'px';

        this[PANEL_CONTROLLER_SYMBOLS.SIZE] = { width: w, height: h };
        this[PANEL_CONTROLLER_SYMBOLS.STATE].size = { width: w, height: h };
        rafId = null;
      });
    };

    const onMouseUp = () => {
      if (!isResizing) return;
      isResizing = false;

      document.removeEventListener('mousemove', onMouseMove);
      document.removeEventListener('mouseup', onMouseUp);

      panel.style.transition = '';
      document.body.style.cursor = '';
      document.body.style.userSelect = '';

      if (rafId) {
        cancelAnimationFrame(rafId);
        rafId = null;
      }

      this[PANEL_CONTROLLER_SYMBOLS.SAVE]();
    };

    resize.addEventListener('mousedown', onMouseDown);

    logger.success('✅ Ресайз настроен');
  }

  // ============================================================
  // 12. ОБРАБОТКА ИЗМЕНЕНИЯ РАЗМЕРА ОКНА
  // ============================================================

  [PANEL_CONTROLLER_SYMBOLS.HANDLE_RESIZE]() {
    const panel = this[PANEL_CONTROLLER_SYMBOLS.PANEL];
    if (!panel || this[PANEL_CONTROLLER_SYMBOLS.STATE].fullscreen) return;

    const maxW = window.innerWidth * 0.9;
    const maxH = window.innerHeight * 0.9;
    const w = parseInt(panel.style.width) || panel.offsetWidth;
    const h = parseInt(panel.style.height) || panel.offsetHeight;
    const left = parseInt(panel.style.left) || panel.offsetLeft;
    const top = parseInt(panel.style.top) || panel.offsetTop;

    let needUpdate = false;

    if (w > maxW) {
      panel.style.width = maxW + 'px';
      needUpdate = true;
    }
    if (h > maxH) {
      panel.style.height = maxH + 'px';
      needUpdate = true;
    }
    if (left + w > window.innerWidth) {
      panel.style.left = Math.max(0, window.innerWidth - w - 10) + 'px';
      needUpdate = true;
    }
    if (top + h > window.innerHeight) {
      panel.style.top = Math.max(0, window.innerHeight - h - 10) + 'px';
      needUpdate = true;
    }

    if (needUpdate) {
      this[PANEL_CONTROLLER_SYMBOLS.SAVE]();
    }
  }

  // ============================================================
  // 13. ДЕЙСТВИЯ
  // ============================================================

  [PANEL_CONTROLLER_SYMBOLS.REGISTER_ACTIONS]() {
    const logger = this[PANEL_CONTROLLER_SYMBOLS.LOG];
    const actions = this[PANEL_CONTROLLER_SYMBOLS.ACTIONS];

    if (!actions) {
      logger.warn('⚠️ Действия не переданы');
      return;
    }

    logger.info('📋 Регистрация действий...');

    const handlers = this[PANEL_CONTROLLER_SYMBOLS.ACTION_HANDLERS];

    for (const [name, handler] of Object.entries(actions)) {
      if (typeof handler === 'function') {
        handlers.set(name, handler);
        logger.debug(`  ✅ Зарегистрировано действие: ${name}`);
      }
    }

    logger.success(`✅ Зарегистрировано ${handlers.size} действий`);
  }

  [PANEL_CONTROLLER_SYMBOLS.HANDLE_ACTION](action, ...args) {
    const logger = this[PANEL_CONTROLLER_SYMBOLS.LOG];
    const handlers = this[PANEL_CONTROLLER_SYMBOLS.ACTION_HANDLERS];

    // Проверка разрешений
    const sandbox = this[PANEL_CONTROLLER_SYMBOLS.SANDBOX];
    if (sandbox.restricted && !sandbox.allowedActions.includes(action)) {
      logger.warn(`⚠️ Действие "${action}" запрещено в песочнице`);
      return { success: false, error: 'Action not allowed in sandbox' };
    }

    if (handlers.has(action)) {
      logger.debug(`🔧 Выполнение действия: ${action}`);
      this[PANEL_CONTROLLER_SYMBOLS.METADATA].actionCount++;
      try {
        const result = handlers.get(action)(...args);
        this[PANEL_CONTROLLER_SYMBOLS.SAVE]();
        return result;
      } catch (error) {
        logger.error(`❌ Ошибка выполнения действия ${action}: ${error.message}`);
        this[PANEL_CONTROLLER_SYMBOLS.METADATA].errorCount++;
        return { success: false, error: error.message };
      }
    }

    logger.warn(`⚠️ Действие "${action}" не найдено`);
    return { success: false, error: `Action "${action}" not found` };
  }

  // ============================================================
  // 14. ОСНОВНЫЕ МЕТОДЫ
  // ============================================================

  [PANEL_CONTROLLER_SYMBOLS.SHOW]() {
    const panel = this[PANEL_CONTROLLER_SYMBOLS.PANEL];
    if (!panel) return false;

    panel.style.display = 'flex';
    panel.style.visibility = 'visible';
    panel.style.opacity = '1';
    panel.style.transform = 'scale(1)';

    this[PANEL_CONTROLLER_SYMBOLS.STATE].visible = true;
    this[PANEL_CONTROLLER_SYMBOLS.METADATA].lastUpdate = Date.now();

    this[PANEL_CONTROLLER_SYMBOLS.HANDLE_EVENT]('show', {
      panel: this[PANEL_CONTROLLER_SYMBOLS.PANEL],
    });
    this[PANEL_CONTROLLER_SYMBOLS.SAVE]();

    return true;
  }

  [PANEL_CONTROLLER_SYMBOLS.HIDE]() {
    const panel = this[PANEL_CONTROLLER_SYMBOLS.PANEL];
    if (!panel) return false;

    panel.style.display = 'none';

    this[PANEL_CONTROLLER_SYMBOLS.STATE].visible = false;
    this[PANEL_CONTROLLER_SYMBOLS.METADATA].lastUpdate = Date.now();

    this[PANEL_CONTROLLER_SYMBOLS.HANDLE_EVENT]('hide', {
      panel: this[PANEL_CONTROLLER_SYMBOLS.PANEL],
    });
    this[PANEL_CONTROLLER_SYMBOLS.SAVE]();

    return true;
  }

  [PANEL_CONTROLLER_SYMBOLS.TOGGLE]() {
    const panel = this[PANEL_CONTROLLER_SYMBOLS.PANEL];
    if (!panel) return false;

    const isVisible = panel.style.display !== 'none';
    const result = isVisible
      ? this[PANEL_CONTROLLER_SYMBOLS.HIDE]()
      : this[PANEL_CONTROLLER_SYMBOLS.SHOW]();

    this[PANEL_CONTROLLER_SYMBOLS.HANDLE_EVENT]('toggle', {
      panel: this[PANEL_CONTROLLER_SYMBOLS.PANEL],
      visible: !isVisible,
    });

    return result;
  }

  [PANEL_CONTROLLER_SYMBOLS.MINIMIZE]() {
    const panel = this[PANEL_CONTROLLER_SYMBOLS.PANEL];
    const minBtn = this[PANEL_CONTROLLER_SYMBOLS.MIN_BTN];
    if (!panel) return false;

    const isMinimized = panel.classList.contains('minimized');

    if (isMinimized) {
      panel.classList.remove('minimized');
      panel.style.height = this[PANEL_CONTROLLER_SYMBOLS.STATE].size.height + 'px';
      panel.style.minHeight = '';
      panel.style.maxHeight = '';
      const body = panel.querySelector('#panel-body');
      if (body) body.style.display = '';
      const resize = panel.querySelector('#panel-resize');
      if (resize) resize.style.display = '';
      if (minBtn) minBtn.textContent = '─';
    } else {
      panel.classList.add('minimized');
      panel.style.height = '44px';
      panel.style.minHeight = '44px';
      panel.style.maxHeight = '44px';
      const body = panel.querySelector('#panel-body');
      if (body) body.style.display = 'none';
      const resize = panel.querySelector('#panel-resize');
      if (resize) resize.style.display = 'none';
      if (minBtn) minBtn.textContent = '□';
    }

    this[PANEL_CONTROLLER_SYMBOLS.STATE].minimized = !isMinimized;
    this[PANEL_CONTROLLER_SYMBOLS.METADATA].lastUpdate = Date.now();

    this[PANEL_CONTROLLER_SYMBOLS.HANDLE_EVENT]('minimize', {
      panel: this[PANEL_CONTROLLER_SYMBOLS.PANEL],
      minimized: !isMinimized,
    });
    this[PANEL_CONTROLLER_SYMBOLS.SAVE]();

    return !isMinimized;
  }

  [PANEL_CONTROLLER_SYMBOLS.FULLSCREEN]() {
    const panel = this[PANEL_CONTROLLER_SYMBOLS.PANEL];
    const maxBtn = this[PANEL_CONTROLLER_SYMBOLS.MAX_BTN];
    if (!panel) return false;

    const isFullscreen = panel.classList.contains('fullscreen');

    if (isFullscreen) {
      panel.classList.remove('fullscreen');
      const prevWidth =
        parseInt(panel.dataset.prevWidth) || this[PANEL_CONTROLLER_SYMBOLS.STATE].size.width;
      const prevHeight =
        parseInt(panel.dataset.prevHeight) || this[PANEL_CONTROLLER_SYMBOLS.STATE].size.height;
      const prevLeft =
        panel.dataset.prevLeft || this[PANEL_CONTROLLER_SYMBOLS.STATE].position.x + 'px';
      const prevTop =
        panel.dataset.prevTop || this[PANEL_CONTROLLER_SYMBOLS.STATE].position.y + 'px';

      panel.style.width = prevWidth + 'px';
      panel.style.height = prevHeight + 'px';
      panel.style.top = prevTop;
      panel.style.left = prevLeft;
      panel.style.borderRadius = '12px';
      panel.style.border = '1px solid rgba(255,255,255,0.08)';
      panel.style.maxWidth = '';
      panel.style.maxHeight = '';
      panel.style.minWidth = '320px';
      panel.style.minHeight = '300px';
      panel.style.zIndex = this[PANEL_CONTROLLER_SYMBOLS.STATE].zIndex;
      document.body.style.overflow = '';

      if (this[PANEL_CONTROLLER_SYMBOLS.RESIZE]) {
        this[PANEL_CONTROLLER_SYMBOLS.RESIZE].style.display = '';
      }

      if (maxBtn) maxBtn.textContent = '□';

      this[PANEL_CONTROLLER_SYMBOLS.STATE].fullscreen = false;
    } else {
      panel.classList.add('fullscreen');
      panel.dataset.prevWidth = panel.offsetWidth;
      panel.dataset.prevHeight = panel.offsetHeight;
      panel.dataset.prevLeft = panel.style.left || panel.offsetLeft + 'px';
      panel.dataset.prevTop = panel.style.top || panel.offsetTop + 'px';

      panel.style.width = '100vw';
      panel.style.height = '100vh';
      panel.style.top = '0';
      panel.style.left = '0';
      panel.style.borderRadius = '0';
      panel.style.border = 'none';
      panel.style.maxWidth = '100vw';
      panel.style.maxHeight = '100vh';
      panel.style.minWidth = '100vw';
      panel.style.minHeight = '100vh';
      panel.style.zIndex = '999999';
      document.body.style.overflow = 'hidden';

      if (this[PANEL_CONTROLLER_SYMBOLS.RESIZE]) {
        this[PANEL_CONTROLLER_SYMBOLS.RESIZE].style.display = 'none';
      }

      if (maxBtn) maxBtn.textContent = '⧉';

      this[PANEL_CONTROLLER_SYMBOLS.STATE].fullscreen = true;
      this[PANEL_CONTROLLER_SYMBOLS.STATE].minimized = false;

      // Если была минимизирована - разворачиваем
      if (panel.classList.contains('minimized')) {
        panel.classList.remove('minimized');
        if (this[PANEL_CONTROLLER_SYMBOLS.MIN_BTN]) {
          this[PANEL_CONTROLLER_SYMBOLS.MIN_BTN].textContent = '─';
        }
      }
    }

    this[PANEL_CONTROLLER_SYMBOLS.METADATA].lastUpdate = Date.now();

    this[PANEL_CONTROLLER_SYMBOLS.HANDLE_EVENT]('fullscreen', {
      panel: this[PANEL_CONTROLLER_SYMBOLS.PANEL],
      fullscreen: !isFullscreen,
    });
    this[PANEL_CONTROLLER_SYMBOLS.SAVE]();

    return !isFullscreen;
  }

  [PANEL_CONTROLLER_SYMBOLS.CLOSE]() {
    const panel = this[PANEL_CONTROLLER_SYMBOLS.PANEL];
    if (!panel) return false;

    panel.style.display = 'none';
    this[PANEL_CONTROLLER_SYMBOLS.STATE].visible = false;
    this[PANEL_CONTROLLER_SYMBOLS.METADATA].lastUpdate = Date.now();

    this[PANEL_CONTROLLER_SYMBOLS.HANDLE_EVENT]('close', {
      panel: this[PANEL_CONTROLLER_SYMBOLS.PANEL],
    });
    this[PANEL_CONTROLLER_SYMBOLS.SAVE]();

    return true;
  }

  [PANEL_CONTROLLER_SYMBOLS.FOCUS]() {
    const panel = this[PANEL_CONTROLLER_SYMBOLS.PANEL];
    if (!panel) return false;

    const allWindows = document.querySelectorAll(
      '.panel-container, #widget-app, #env-control-panel, #logs-control-panel, #debug-control-panel, .widget-window'
    );

    let maxZ = 99999;
    allWindows.forEach(win => {
      if (win !== panel && win.style.display !== 'none') {
        const z = parseInt(win.style.zIndex) || 0;
        if (z > maxZ) maxZ = z;
      }
    });

    const newZ = maxZ + 1;
    panel.style.zIndex = newZ;
    this[PANEL_CONTROLLER_SYMBOLS.STATE].zIndex = newZ;
    this[PANEL_CONTROLLER_SYMBOLS.STATE].focused = true;

    allWindows.forEach(win => win.classList.remove('active-window'));
    panel.classList.add('active-window');

    this[PANEL_CONTROLLER_SYMBOLS.HANDLE_EVENT]('focus', {
      panel: this[PANEL_CONTROLLER_SYMBOLS.PANEL],
      zIndex: newZ,
    });

    return newZ;
  }

  [PANEL_CONTROLLER_SYMBOLS.RESIZE](width, height) {
    const panel = this[PANEL_CONTROLLER_SYMBOLS.PANEL];
    if (!panel) return false;

    if (this[PANEL_CONTROLLER_SYMBOLS.STATE].fullscreen) {
      this[PANEL_CONTROLLER_SYMBOLS.FULLSCREEN]();
    }

    const minW = parseInt(DEFAULT_CONFIG.minWidth) || 320;
    const minH = parseInt(DEFAULT_CONFIG.minHeight) || 300;
    const maxW = window.innerWidth * 0.9;
    const maxH = window.innerHeight * 0.9;

    const w = Math.max(minW, Math.min(maxW, width));
    const h = Math.max(minH, Math.min(maxH, height));

    panel.style.width = w + 'px';
    panel.style.height = h + 'px';

    this[PANEL_CONTROLLER_SYMBOLS.SIZE] = { width: w, height: h };
    this[PANEL_CONTROLLER_SYMBOLS.STATE].size = { width: w, height: h };

    this[PANEL_CONTROLLER_SYMBOLS.HANDLE_EVENT]('resize', {
      panel: this[PANEL_CONTROLLER_SYMBOLS.PANEL],
      width: w,
      height: h,
    });
    this[PANEL_CONTROLLER_SYMBOLS.SAVE]();

    return { width: w, height: h };
  }

  [PANEL_CONTROLLER_SYMBOLS.MOVE](x, y) {
    const panel = this[PANEL_CONTROLLER_SYMBOLS.PANEL];
    if (!panel) return false;

    if (this[PANEL_CONTROLLER_SYMBOLS.STATE].fullscreen) {
      this[PANEL_CONTROLLER_SYMBOLS.FULLSCREEN]();
    }

    const maxX = window.innerWidth - panel.offsetWidth;
    const maxY = window.innerHeight - panel.offsetHeight;

    const newX = Math.max(0, Math.min(maxX, x));
    const newY = Math.max(0, Math.min(maxY, y));

    panel.style.left = newX + 'px';
    panel.style.top = newY + 'px';

    this[PANEL_CONTROLLER_SYMBOLS.POSITION] = { x: newX, y: newY };
    this[PANEL_CONTROLLER_SYMBOLS.STATE].position = { x: newX, y: newY };

    this[PANEL_CONTROLLER_SYMBOLS.HANDLE_EVENT]('move', {
      panel: this[PANEL_CONTROLLER_SYMBOLS.PANEL],
      x: newX,
      y: newY,
    });
    this[PANEL_CONTROLLER_SYMBOLS.SAVE]();

    return { x: newX, y: newY };
  }

  // ============================================================
  // 15. СОБЫТИЯ
  // ============================================================

  [PANEL_CONTROLLER_SYMBOLS.HANDLE_EVENT](event, data) {
    const handlers = this[PANEL_CONTROLLER_SYMBOLS.EVENT_HANDLERS];
    const queue = this[PANEL_CONTROLLER_SYMBOLS.EVENT_QUEUE];
    const bus = this[PANEL_CONTROLLER_SYMBOLS.EVENT_BUS];
    const subscribers = this[PANEL_CONTROLLER_SYMBOLS.EVENT_SUBSCRIBERS];

    // Добавляем в очередь
    queue.push({ event, data, timestamp: Date.now() });
    if (queue.length > 100) queue.shift();

    // Вызываем обработчики
    if (handlers.has(event)) {
      const callbacks = handlers.get(event);
      for (const callback of callbacks) {
        try {
          callback(data);
        } catch (error) {
          const logger = this[PANEL_CONTROLLER_SYMBOLS.LOG];
          logger.error(`❌ Ошибка в обработчике ${event}: ${error.message}`);
        }
      }
    }

    // Вызываем подписчиков
    if (subscribers.has(event)) {
      const callbacks = subscribers.get(event);
      for (const callback of callbacks) {
        try {
          callback(data);
        } catch (error) {
          const logger = this[PANEL_CONTROLLER_SYMBOLS.LOG];
          logger.error(`❌ Ошибка в подписчике ${event}: ${error.message}`);
        }
      }
    }

    // Отправляем в шину
    if (bus.has(event)) {
      const callbacks = bus.get(event);
      for (const callback of callbacks) {
        try {
          callback(data);
        } catch (error) {
          const logger = this[PANEL_CONTROLLER_SYMBOLS.LOG];
          logger.error(`❌ Ошибка в шине ${event}: ${error.message}`);
        }
      }
    }
  }

  on(event, callback) {
    const handlers = this[PANEL_CONTROLLER_SYMBOLS.EVENT_HANDLERS];
    if (!handlers.has(event)) {
      handlers.set(event, []);
    }
    handlers.get(event).push(callback);
    return () => this.off(event, callback);
  }

  off(event, callback) {
    const handlers = this[PANEL_CONTROLLER_SYMBOLS.EVENT_HANDLERS];
    if (handlers.has(event)) {
      const callbacks = handlers.get(event);
      const index = callbacks.indexOf(callback);
      if (index !== -1) {
        callbacks.splice(index, 1);
      }
      if (callbacks.length === 0) {
        handlers.delete(event);
      }
    }
  }

  emit(event, data) {
    this[PANEL_CONTROLLER_SYMBOLS.HANDLE_EVENT](event, data);
  }

  subscribe(event, callback) {
    const subscribers = this[PANEL_CONTROLLER_SYMBOLS.EVENT_SUBSCRIBERS];
    if (!subscribers.has(event)) {
      subscribers.set(event, []);
    }
    subscribers.get(event).push(callback);
    return () => this.unsubscribe(event, callback);
  }

  unsubscribe(event, callback) {
    const subscribers = this[PANEL_CONTROLLER_SYMBOLS.EVENT_SUBSCRIBERS];
    if (subscribers.has(event)) {
      const callbacks = subscribers.get(event);
      const index = callbacks.indexOf(callback);
      if (index !== -1) {
        callbacks.splice(index, 1);
      }
      if (callbacks.length === 0) {
        subscribers.delete(event);
      }
    }
  }

  // ============================================================
  // 16. СИНХРОНИЗАЦИЯ
  // ============================================================

  [PANEL_CONTROLLER_SYMBOLS.SAVE]() {
    const logger = this[PANEL_CONTROLLER_SYMBOLS.LOG];
    const permissions = this[PANEL_CONTROLLER_SYMBOLS.PERMISSIONS];

    if (!permissions.canAccessStorage) {
      logger.debug('💾 Сохранение запрещено (нет прав)');
      return false;
    }

    try {
      const state = {
        id: this[PANEL_CONTROLLER_SYMBOLS.ID],
        position: this[PANEL_CONTROLLER_SYMBOLS.POSITION],
        size: this[PANEL_CONTROLLER_SYMBOLS.SIZE],
        zIndex: this[PANEL_CONTROLLER_SYMBOLS.Z_INDEX],
        visible: this[PANEL_CONTROLLER_SYMBOLS.STATE].visible,
        minimized: this[PANEL_CONTROLLER_SYMBOLS.STATE].minimized,
        fullscreen: this[PANEL_CONTROLLER_SYMBOLS.STATE].fullscreen,
        timestamp: Date.now(),
        version: this[PANEL_CONTROLLER_SYMBOLS.VERSION],
      };

      const key = `panel-controller-${this[PANEL_CONTROLLER_SYMBOLS.PANEL_ID]}`;
      localStorage.setItem(key, JSON.stringify(state));

      logger.debug(`💾 Состояние сохранено (${key})`);
      return true;
    } catch (error) {
      logger.error(`❌ Ошибка сохранения: ${error.message}`);
      return false;
    }
  }

  [PANEL_CONTROLLER_SYMBOLS.LOAD]() {
    const logger = this[PANEL_CONTROLLER_SYMBOLS.LOG];
    const permissions = this[PANEL_CONTROLLER_SYMBOLS.PERMISSIONS];

    if (!permissions.canAccessStorage) {
      logger.debug('📥 Загрузка запрещена (нет прав)');
      return false;
    }

    try {
      const key = `panel-controller-${this[PANEL_CONTROLLER_SYMBOLS.PANEL_ID]}`;
      const saved = localStorage.getItem(key);

      if (!saved) {
        logger.debug('📥 Сохранённое состояние не найдено');
        return false;
      }

      const state = JSON.parse(saved);

      // Проверяем версию
      if (state.version !== this[PANEL_CONTROLLER_SYMBOLS.VERSION]) {
        logger.warn(
          `⚠️ Версия состояния (${state.version}) не совпадает с текущей (${this[PANEL_CONTROLLER_SYMBOLS.VERSION]})`
        );
      }

      // Применяем состояние
      if (state.position) {
        this[PANEL_CONTROLLER_SYMBOLS.POSITION] = state.position;
        this[PANEL_CONTROLLER_SYMBOLS.STATE].position = state.position;
      }

      if (state.size) {
        this[PANEL_CONTROLLER_SYMBOLS.SIZE] = state.size;
        this[PANEL_CONTROLLER_SYMBOLS.STATE].size = state.size;
      }

      if (state.zIndex) {
        this[PANEL_CONTROLLER_SYMBOLS.Z_INDEX] = state.zIndex;
        this[PANEL_CONTROLLER_SYMBOLS.STATE].zIndex = state.zIndex;
      }

      if (state.visible !== undefined) {
        this[PANEL_CONTROLLER_SYMBOLS.STATE].visible = state.visible;
      }

      if (state.minimized !== undefined) {
        this[PANEL_CONTROLLER_SYMBOLS.STATE].minimized = state.minimized;
      }

      if (state.fullscreen !== undefined) {
        this[PANEL_CONTROLLER_SYMBOLS.STATE].fullscreen = state.fullscreen;
      }

      // Применяем состояние к DOM
      this[PANEL_CONTROLLER_SYMBOLS.APPLY_STATE]();

      logger.info(`📥 Состояние загружено (${key})`);
      return true;
    } catch (error) {
      logger.error(`❌ Ошибка загрузки: ${error.message}`);
      return false;
    }
  }

  // ============================================================
  // 17. УПРАВЛЕНИЕ СОСТОЯНИЕМ
  // ============================================================

  [PANEL_CONTROLLER_SYMBOLS.GET_STATE]() {
    return {
      id: this[PANEL_CONTROLLER_SYMBOLS.ID],
      name: this[PANEL_CONTROLLER_SYMBOLS.NAME],
      type: this[PANEL_CONTROLLER_SYMBOLS.TYPE],
      version: this[PANEL_CONTROLLER_SYMBOLS.VERSION],
      panelId: this[PANEL_CONTROLLER_SYMBOLS.PANEL_ID],
      panelType: this[PANEL_CONTROLLER_SYMBOLS.PANEL_TYPE],
      initialized: this[PANEL_CONTROLLER_SYMBOLS.INITIALIZED],
      destroyed: this[PANEL_CONTROLLER_SYMBOLS.DESTROYED],
      ...this[PANEL_CONTROLLER_SYMBOLS.STATE],
      position: { ...this[PANEL_CONTROLLER_SYMBOLS.POSITION] },
      size: { ...this[PANEL_CONTROLLER_SYMBOLS.SIZE] },
      zIndex: this[PANEL_CONTROLLER_SYMBOLS.Z_INDEX],
      metadata: { ...this[PANEL_CONTROLLER_SYMBOLS.METADATA] },
      context: { ...this[PANEL_CONTROLLER_SYMBOLS.CONTEXT] },
      eventQueueSize: this[PANEL_CONTROLLER_SYMBOLS.EVENT_QUEUE].length,
      eventHandlers: this[PANEL_CONTROLLER_SYMBOLS.EVENT_HANDLERS].size,
      subscribers: this[PANEL_CONTROLLER_SYMBOLS.EVENT_SUBSCRIBERS].size,
      actionsCount: this[PANEL_CONTROLLER_SYMBOLS.ACTION_HANDLERS].size,
      permissions: { ...this[PANEL_CONTROLLER_SYMBOLS.PERMISSIONS] },
      sandbox: { ...this[PANEL_CONTROLLER_SYMBOLS.SANDBOX] },
    };
  }

  getState() {
    return this[PANEL_CONTROLLER_SYMBOLS.GET_STATE]();
  }

  [PANEL_CONTROLLER_SYMBOLS.UPDATE_STATE](updates) {
    const oldState = this[PANEL_CONTROLLER_SYMBOLS.GET_STATE]();
    Object.assign(this[PANEL_CONTROLLER_SYMBOLS.STATE], updates);
    this[PANEL_CONTROLLER_SYMBOLS.APPLY_STATE]();
    this[PANEL_CONTROLLER_SYMBOLS.SAVE]();
    this[PANEL_CONTROLLER_SYMBOLS.HANDLE_EVENT]('stateChange', {
      oldState,
      newState: this[PANEL_CONTROLLER_SYMBOLS.GET_STATE](),
      updates,
    });
    return this[PANEL_CONTROLLER_SYMBOLS.GET_STATE]();
  }

  [PANEL_CONTROLLER_SYMBOLS.RESET_STATE]() {
    const oldState = this[PANEL_CONTROLLER_SYMBOLS.GET_STATE]();
    this[PANEL_CONTROLLER_SYMBOLS.STATE] = { ...DEFAULT_STATE };
    this[PANEL_CONTROLLER_SYMBOLS.POSITION] = { ...DEFAULT_STATE.position };
    this[PANEL_CONTROLLER_SYMBOLS.SIZE] = { ...DEFAULT_STATE.size };
    this[PANEL_CONTROLLER_SYMBOLS.Z_INDEX] = DEFAULT_STATE.zIndex;
    this[PANEL_CONTROLLER_SYMBOLS.APPLY_STATE]();
    this[PANEL_CONTROLLER_SYMBOLS.SAVE]();
    this[PANEL_CONTROLLER_SYMBOLS.HANDLE_EVENT]('reset', {
      oldState,
      newState: this[PANEL_CONTROLLER_SYMBOLS.GET_STATE](),
    });
    return this[PANEL_CONTROLLER_SYMBOLS.GET_STATE]();
  }

  // ============================================================
  // 18. УТИЛИТЫ
  // ============================================================

  [PANEL_CONTROLLER_SYMBOLS.VALIDATE](value, schema) {
    return VALIDATOR[PANEL_CONTROLLER_SYMBOLS.SECURE].validate(value, schema);
  }

  [PANEL_CONTROLLER_SYMBOLS.SANITIZE](value) {
    return VALIDATOR[PANEL_CONTROLLER_SYMBOLS.SECURE].sanitize(value);
  }

  [PANEL_CONTROLLER_SYMBOLS.LOG](level, message, data = null) {
    const logger = this[PANEL_CONTROLLER_SYMBOLS.LOG];
    if (level === 'error') logger.error(message, data);
    else if (level === 'warn') logger.warn(message, data);
    else if (level === 'debug') logger.debug(message, data);
    else if (level === 'success') logger.success(message, data);
    else logger.info(message, data);
    return this;
  }

  [PANEL_CONTROLLER_SYMBOLS.GET_LOGGER]() {
    return this[PANEL_CONTROLLER_SYMBOLS.LOG];
  }

  // ============================================================
  // 19. ЭКСПОРТ/ИМПОРТ
  // ============================================================

  [PANEL_CONTROLLER_SYMBOLS.EXPORT]() {
    const state = this[PANEL_CONTROLLER_SYMBOLS.GET_STATE]();
    return {
      ...state,
      position: { ...this[PANEL_CONTROLLER_SYMBOLS.POSITION] },
      size: { ...this[PANEL_CONTROLLER_SYMBOLS.SIZE] },
      metadata: { ...this[PANEL_CONTROLLER_SYMBOLS.METADATA] },
      timestamp: Date.now(),
      exportedBy: this[PANEL_CONTROLLER_SYMBOLS.ID],
    };
  }

  [PANEL_CONTROLLER_SYMBOLS.IMPORT](data) {
    const logger = this[PANEL_CONTROLLER_SYMBOLS.LOG];
    if (!data || typeof data !== 'object') {
      logger.error('❌ Неверный формат данных для импорта');
      return false;
    }

    try {
      this[PANEL_CONTROLLER_SYMBOLS.POSITION] =
        data.position || this[PANEL_CONTROLLER_SYMBOLS.POSITION];
      this[PANEL_CONTROLLER_SYMBOLS.SIZE] = data.size || this[PANEL_CONTROLLER_SYMBOLS.SIZE];
      this[PANEL_CONTROLLER_SYMBOLS.Z_INDEX] =
        data.zIndex || this[PANEL_CONTROLLER_SYMBOLS.Z_INDEX];

      if (data.visible !== undefined) this[PANEL_CONTROLLER_SYMBOLS.STATE].visible = data.visible;
      if (data.minimized !== undefined)
        this[PANEL_CONTROLLER_SYMBOLS.STATE].minimized = data.minimized;
      if (data.fullscreen !== undefined)
        this[PANEL_CONTROLLER_SYMBOLS.STATE].fullscreen = data.fullscreen;

      if (data.metadata) {
        Object.assign(this[PANEL_CONTROLLER_SYMBOLS.METADATA], data.metadata);
      }

      this[PANEL_CONTROLLER_SYMBOLS.APPLY_STATE]();
      this[PANEL_CONTROLLER_SYMBOLS.SAVE]();

      logger.info('📥 Состояние импортировано');
      return true;
    } catch (error) {
      logger.error(`❌ Ошибка импорта: ${error.message}`);
      return false;
    }
  }

  // ============================================================
  // 20. ОТЛАДКА
  // ============================================================

  [PANEL_CONTROLLER_SYMBOLS.DEBUG]() {
    const logger = this[PANEL_CONTROLLER_SYMBOLS.LOG];
    const state = this[PANEL_CONTROLLER_SYMBOLS.GET_STATE]();

    logger.header('🐛 ОТЛАДКА PANEL CONTROLLER');
    logger.info('📊 Состояние:', state);

    logger.separator();
    logger.info('🔑 ПРИВАТНЫЕ СИМВОЛЫ:');
    for (const key of Object.keys(PANEL_CONTROLLER_SYMBOLS)) {
      logger.private(key, PANEL_CONTROLLER_SYMBOLS[key]);
    }

    logger.separator();
    logger.info('🔓 ПУБЛИЧНЫЕ СИМВОЛЫ:');
    for (const key of Object.keys(PUBLIC_PANEL_CONTROLLER)) {
      logger.symbol(key, PUBLIC_PANEL_CONTROLLER[key]);
    }

    logger.separator();
    logger.info('📋 ДЕЙСТВИЯ:');
    const actions = Array.from(this[PANEL_CONTROLLER_SYMBOLS.ACTION_HANDLERS].keys());
    for (const action of actions) {
      logger.info(`  🔧 ${action}`);
    }

    logger.separator();
    logger.info('📋 СОБЫТИЯ:');
    const events = Array.from(this[PANEL_CONTROLLER_SYMBOLS.EVENT_HANDLERS].keys());
    for (const event of events) {
      logger.info(
        `  📢 ${event} (${this[PANEL_CONTROLLER_SYMBOLS.EVENT_HANDLERS].get(event).length} обработчиков)`
      );
    }

    logger.separator();
    logger.info('📋 ИСТОРИЯ ЛОГОВ:');
    const history = this[PANEL_CONTROLLER_SYMBOLS.LOG].getHistory();
    logger.info(`  Всего: ${history.length} записей`);
    for (const entry of history.slice(-5)) {
      logger.info(`  ${entry.timestamp} [${entry.level}] ${entry.message}`);
    }

    logger.header('ГОТОВ');
    return state;
  }

  [PANEL_CONTROLLER_SYMBOLS.TRACE]() {
    console.trace('📍 Трассировка вызова');
    return this;
  }

  // ============================================================
  // 21. ЖИЗНЕННЫЙ ЦИКЛ
  // ============================================================

  [PANEL_CONTROLLER_SYMBOLS.RESET]() {
    const logger = this[PANEL_CONTROLLER_SYMBOLS.LOG];
    logger.warn('🔄 Сброс контроллера...');

    this[PANEL_CONTROLLER_SYMBOLS.RESET_STATE]();
    this[PANEL_CONTROLLER_SYMBOLS.CACHE].clear();
    this[PANEL_CONTROLLER_SYMBOLS.LISTENERS] = [];
    this[PANEL_CONTROLLER_SYMBOLS.LOG_HISTORY] = [];
    this[PANEL_CONTROLLER_SYMBOLS.EVENT_QUEUE] = [];
    this[PANEL_CONTROLLER_SYMBOLS.METADATA] = {
      created: Date.now(),
      lastAccess: Date.now(),
      lastUpdate: Date.now(),
      runCount: 0,
      errorCount: 0,
      actionCount: 0,
    };

    logger.success('✅ Контроллер сброшен');
    return this;
  }

  [PANEL_CONTROLLER_SYMBOLS.RELOAD]() {
    const logger = this[PANEL_CONTROLLER_SYMBOLS.LOG];
    logger.info('🔄 Перезагрузка контроллера...');

    this[PANEL_CONTROLLER_SYMBOLS.RESET]();
    this[PANEL_CONTROLLER_SYMBOLS.INIT]();

    logger.success('✅ Контроллер перезагружен');
    return this;
  }

  [PANEL_CONTROLLER_SYMBOLS.DESTROY]() {
    if (this[PANEL_CONTROLLER_SYMBOLS.DESTROYED]) {
      const logger = this[PANEL_CONTROLLER_SYMBOLS.LOG];
      logger.warn('⚠️ Контроллер уже уничтожен');
      return;
    }

    const logger = this[PANEL_CONTROLLER_SYMBOLS.LOG];
    logger.warn('🗑️ Уничтожение контроллера...');

    // Очищаем таймеры
    for (const [key, timer] of this[PANEL_CONTROLLER_SYMBOLS.TIMERS]) {
      clearInterval(timer);
      clearTimeout(timer);
    }
    this[PANEL_CONTROLLER_SYMBOLS.TIMERS].clear();

    // Очищаем кеш
    this[PANEL_CONTROLLER_SYMBOLS.CACHE].clear();

    // Очищаем слушатели
    this[PANEL_CONTROLLER_SYMBOLS.LISTENERS] = [];
    this[PANEL_CONTROLLER_SYMBOLS.EVENT_HANDLERS].clear();
    this[PANEL_CONTROLLER_SYMBOLS.EVENT_SUBSCRIBERS].clear();
    this[PANEL_CONTROLLER_SYMBOLS.EVENT_QUEUE] = [];
    this[PANEL_CONTROLLER_SYMBOLS.ACTION_HANDLERS].clear();

    // Удаляем глобальные ссылки
    if (typeof window !== 'undefined') {
      delete window.__panelController;
      delete window[PUBLIC_PANEL_CONTROLLER.API];
      delete window[PUBLIC_PANEL_CONTROLLER.STATE];
      delete window[PUBLIC_PANEL_CONTROLLER.CONFIG];
      delete window[PUBLIC_PANEL_CONTROLLER.LOGGER];
      delete window[PUBLIC_PANEL_CONTROLLER.INSTANCE];
      delete window[PUBLIC_PANEL_CONTROLLER.EVENTS];
      delete window[PUBLIC_PANEL_CONTROLLER.ACTIONS];
      delete window[PUBLIC_PANEL_CONTROLLER.PANEL];
    }

    this[PANEL_CONTROLLER_SYMBOLS.DESTROYED] = true;
    this[PANEL_CONTROLLER_SYMBOLS.INITIALIZED] = false;

    logger.success('✅ Контроллер уничтожен');
  }

  // ============================================================
  // 22. ПУБЛИЧНЫЕ МЕТОДЫ (ОБЕРТКИ)
  // ============================================================

  show() {
    return this[PANEL_CONTROLLER_SYMBOLS.SHOW]();
  }
  hide() {
    return this[PANEL_CONTROLLER_SYMBOLS.HIDE]();
  }
  toggle() {
    return this[PANEL_CONTROLLER_SYMBOLS.TOGGLE]();
  }
  minimize() {
    return this[PANEL_CONTROLLER_SYMBOLS.MINIMIZE]();
  }
  fullscreen() {
    return this[PANEL_CONTROLLER_SYMBOLS.FULLSCREEN]();
  }
  close() {
    return this[PANEL_CONTROLLER_SYMBOLS.CLOSE]();
  }
  focus() {
    return this[PANEL_CONTROLLER_SYMBOLS.FOCUS]();
  }
  resize(w, h) {
    return this[PANEL_CONTROLLER_SYMBOLS.RESIZE](w, h);
  }
  move(x, y) {
    return this[PANEL_CONTROLLER_SYMBOLS.MOVE](x, y);
  }

  getState() {
    return this[PANEL_CONTROLLER_SYMBOLS.GET_STATE]();
  }
  updateState(updates) {
    return this[PANEL_CONTROLLER_SYMBOLS.UPDATE_STATE](updates);
  }
  resetState() {
    return this[PANEL_CONTROLLER_SYMBOLS.RESET_STATE]();
  }

  on(event, callback) {
    return this.on(event, callback);
  }
  off(event, callback) {
    return this.off(event, callback);
  }
  emit(event, data) {
    return this[PANEL_CONTROLLER_SYMBOLS.HANDLE_EVENT](event, data);
  }
  subscribe(event, callback) {
    return this.subscribe(event, callback);
  }
  unsubscribe(event, callback) {
    return this.unsubscribe(event, callback);
  }

  action(action, ...args) {
    return this[PANEL_CONTROLLER_SYMBOLS.HANDLE_ACTION](action, ...args);
  }

  save() {
    return this[PANEL_CONTROLLER_SYMBOLS.SAVE]();
  }
  load() {
    return this[PANEL_CONTROLLER_SYMBOLS.LOAD]();
  }
  export() {
    return this[PANEL_CONTROLLER_SYMBOLS.EXPORT]();
  }
  import(data) {
    return this[PANEL_CONTROLLER_SYMBOLS.IMPORT](data);
  }

  reset() {
    return this[PANEL_CONTROLLER_SYMBOLS.RESET]();
  }
  reload() {
    return this[PANEL_CONTROLLER_SYMBOLS.RELOAD]();
  }
  destroy() {
    return this[PANEL_CONTROLLER_SYMBOLS.DESTROY]();
  }

  debug() {
    return this[PANEL_CONTROLLER_SYMBOLS.DEBUG]();
  }
  trace() {
    return this[PANEL_CONTROLLER_SYMBOLS.TRACE]();
  }

  getLogger() {
    return this[PANEL_CONTROLLER_SYMBOLS.GET_LOGGER]();
  }
  getPanel() {
    return this[PANEL_CONTROLLER_SYMBOLS.PANEL];
  }
  getActions() {
    return this[PANEL_CONTROLLER_SYMBOLS.ACTION_HANDLERS];
  }
  getEventHandlers() {
    return this[PANEL_CONTROLLER_SYMBOLS.EVENT_HANDLERS];
  }
  getSubscribers() {
    return this[PANEL_CONTROLLER_SYMBOLS.EVENT_SUBSCRIBERS];
  }
  getEventQueue() {
    return [...this[PANEL_CONTROLLER_SYMBOLS.EVENT_QUEUE]];
  }
  getPermissions() {
    return { ...this[PANEL_CONTROLLER_SYMBOLS.PERMISSIONS] };
  }
  getSandbox() {
    return { ...this[PANEL_CONTROLLER_SYMBOLS.SANDBOX] };
  }
  getCache() {
    return new Map(this[PANEL_CONTROLLER_SYMBOLS.CACHE]);
  }
  getTimers() {
    return new Map(this[PANEL_CONTROLLER_SYMBOLS.TIMERS]);
  }
  getMetadata() {
    return { ...this[PANEL_CONTROLLER_SYMBOLS.METADATA] };
  }
  getContext() {
    return { ...this[PANEL_CONTROLLER_SYMBOLS.CONTEXT] };
  }

  // ============================================================
  // 23. ГЕТТЕРЫ ДЛЯ ПРИВАТНЫХ ДАННЫХ (ТОЛЬКО ДЛЯ ЧТЕНИЯ)
  // ============================================================

  get [PANEL_CONTROLLER_SYMBOLS.ID]() {
    return this[PANEL_CONTROLLER_SYMBOLS.ID];
  }
  get [PANEL_CONTROLLER_SYMBOLS.NAME]() {
    return this[PANEL_CONTROLLER_SYMBOLS.NAME];
  }
  get [PANEL_CONTROLLER_SYMBOLS.TYPE]() {
    return this[PANEL_CONTROLLER_SYMBOLS.TYPE];
  }
  get [PANEL_CONTROLLER_SYMBOLS.VERSION]() {
    return this[PANEL_CONTROLLER_SYMBOLS.VERSION];
  }
  get [PANEL_CONTROLLER_SYMBOLS.PANEL_ID]() {
    return this[PANEL_CONTROLLER_SYMBOLS.PANEL_ID];
  }
  get [PANEL_CONTROLLER_SYMBOLS.PANEL_TYPE]() {
    return this[PANEL_CONTROLLER_SYMBOLS.PANEL_TYPE];
  }
  get [PANEL_CONTROLLER_SYMBOLS.INITIALIZED]() {
    return this[PANEL_CONTROLLER_SYMBOLS.INITIALIZED];
  }
  get [PANEL_CONTROLLER_SYMBOLS.DESTROYED]() {
    return this[PANEL_CONTROLLER_SYMBOLS.DESTROYED];
  }
  get [PANEL_CONTROLLER_SYMBOLS.STATE]() {
    return this[PANEL_CONTROLLER_SYMBOLS.GET_STATE]();
  }
  get [PANEL_CONTROLLER_SYMBOLS.POSITION]() {
    return { ...this[PANEL_CONTROLLER_SYMBOLS.POSITION] };
  }
  get [PANEL_CONTROLLER_SYMBOLS.SIZE]() {
    return { ...this[PANEL_CONTROLLER_SYMBOLS.SIZE] };
  }
  get [PANEL_CONTROLLER_SYMBOLS.Z_INDEX]() {
    return this[PANEL_CONTROLLER_SYMBOLS.Z_INDEX];
  }
  get [PANEL_CONTROLLER_SYMBOLS.METADATA]() {
    return { ...this[PANEL_CONTROLLER_SYMBOLS.METADATA] };
  }
  get [PANEL_CONTROLLER_SYMBOLS.CONTEXT]() {
    return { ...this[PANEL_CONTROLLER_SYMBOLS.CONTEXT] };
  }
  get [PANEL_CONTROLLER_SYMBOLS.PANEL]() {
    return this[PANEL_CONTROLLER_SYMBOLS.PANEL];
  }
  get [PANEL_CONTROLLER_SYMBOLS.ACTIONS]() {
    return this[PANEL_CONTROLLER_SYMBOLS.ACTIONS];
  }
}

// ============================================================
// 24. ЭКСПОРТ ПО УМОЛЧАНИЮ
// ============================================================

export default PanelController;

// ============================================================
// 25. ГЛОБАЛЬНАЯ РЕГИСТРАЦИЯ
// ============================================================

if (typeof window !== 'undefined') {
  window.PanelController = PanelController;
  window.PANEL_CONTROLLER_SYMBOLS = PANEL_CONTROLLER_SYMBOLS;
  window.PUBLIC_PANEL_CONTROLLER = PUBLIC_PANEL_CONTROLLER;

  console.log('📦 ./controller/panel-controller.mjs загружен (100% СИМВОЛЫ)');
  console.log(`🔑 ПРИВАТНЫХ СИМВОЛОВ: ${Object.keys(PANEL_CONTROLLER_SYMBOLS).length}`);
  console.log(`🔑 ПУБЛИЧНЫХ СИМВОЛОВ: ${Object.keys(PUBLIC_PANEL_CONTROLLER).length}`);
  console.log('');
  console.log('📋 ДОСТУПНЫЕ КОМАНДЫ:');
  console.log(
    '  const controller = new PanelController({ panel: document.getElementById("panel") });'
  );
  console.log('  controller.show() / hide() / toggle()');
  console.log('  controller.minimize() / fullscreen() / close()');
  console.log('  controller.focus() / resize(w, h) / move(x, y)');
  console.log('  controller.on(event, callback) / emit(event, data)');
  console.log('  controller.action("show") / controller.action("custom", args)');
  console.log('  controller.save() / load() / export() / import()');
  console.log('  controller.getState() / updateState() / resetState()');
  console.log('  controller.debug() / trace() / destroy()');
  console.log('  controller.getPanel() / getLogger() / getActions()');
}
