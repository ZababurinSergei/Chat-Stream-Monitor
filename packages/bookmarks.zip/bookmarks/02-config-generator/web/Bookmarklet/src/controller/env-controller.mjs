// web/Bookmarklet/src/controller/env-controller.mjs
// 100% СИМВОЛЫ — полная изоляция и безопасность
// Контроллер ENV панели
// Версия: 2.1.9

import { PanelController, PANEL_CONTROLLER_SYMBOLS } from './panel-controller.mjs';
import { ENV_ACTIONS } from '../action/env-actions.mjs';
import ENV_TEMPLATE from '../template/env-template.mjs';

// ============================================================
// 1. ПРИВАТНЫЕ СИМВОЛЫ ENV КОНТРОЛЛЕРА (100% изоляция)
// ============================================================

export const ENV_CONTROLLER_SYMBOLS = {
  // Основные символы
  ID: Symbol('env-controller.id'),
  NAME: Symbol('env-controller.name'),
  TYPE: Symbol('env-controller.type'),
  VERSION: Symbol('env-controller.version'),
  PANEL_ID: Symbol('env-controller.panelId'),
  INSTANCE_ID: Symbol('env-controller.instanceId'),

  // Состояние
  CURRENT_NAMESPACE: Symbol('env-controller.currentNamespace'),
  PREVIOUS_NAMESPACE: Symbol('env-controller.previousNamespace'),
  IS_INITIALIZED: Symbol('env-controller.isInitialized'),
  IS_DESTROYED: Symbol('env-controller.isDestroyed'),
  LAST_UPDATE: Symbol('env-controller.lastUpdate'),
  UPDATE_COUNT: Symbol('env-controller.updateCount'),

  // DOM элементы
  GROUPS_CONTAINER: Symbol('env-controller.groupsContainer'),
  ACTIONS_CONTAINER: Symbol('env-controller.actionsContainer'),
  COMMANDS_CONTAINER: Symbol('env-controller.commandsContainer'),
  STATUS_BADGE: Symbol('env-controller.statusBadge'),

  // Данные
  PRESETS: Symbol('env-controller.presets'),
  PRESETS_MAP: Symbol('env-controller.presetsMap'),
  ACTIONS_MAP: Symbol('env-controller.actionsMap'),
  COMMANDS_MAP: Symbol('env-controller.commandsMap'),
  CACHE: Symbol('env-controller.cache'),
  METADATA: Symbol('env-controller.metadata'),
  CONTEXT: Symbol('env-controller.context'),
  LOG_HISTORY: Symbol('env-controller.logHistory'),

  // Таймеры
  TIMERS: Symbol('env-controller.timers'),
  RAF_ID: Symbol('env-controller.rafId'),
  DEBOUNCE_ID: Symbol('env-controller.debounceId'),
  AUTO_UPDATE_ID: Symbol('env-controller.autoUpdateId'),

  // Слушатели
  LISTENERS: Symbol('env-controller.listeners'),
  EVENT_HANDLERS: Symbol('env-controller.eventHandlers'),
  DOM_OBSERVER: Symbol('env-controller.domObserver'),
  MUTATION_OBSERVER: Symbol('env-controller.mutationObserver'),

  // Безопасность
  SECURE: Symbol('env-controller.secure'),
  VALIDATOR: Symbol('env-controller.validator'),
  SANITIZER: Symbol('env-controller.sanitizer'),

  // Методы
  INIT: Symbol('env-controller.init'),
  SETUP_UI: Symbol('env-controller.setupUI'),
  SETUP_HANDLERS: Symbol('env-controller.setupHandlers'),
  SETUP_OBSERVERS: Symbol('env-controller.setupObservers'),
  UPDATE_UI: Symbol('env-controller.updateUI'),
  UPDATE_BADGE: Symbol('env-controller.updateBadge'),
  UPDATE_PRESETS: Symbol('env-controller.updatePresets'),
  UPDATE_ACTIONS: Symbol('env-controller.updateActions'),
  UPDATE_COMMANDS: Symbol('env-controller.updateCommands'),
  HANDLE_PRESET: Symbol('env-controller.handlePreset'),
  HANDLE_ACTION: Symbol('env-controller.handleAction'),
  HANDLE_COMMAND: Symbol('env-controller.handleCommand'),
  SET_NAMESPACE: Symbol('env-controller.setNamespace'),
  GET_NAMESPACE: Symbol('env-controller.getNamespace'),
  RESET_NAMESPACE: Symbol('env-controller.resetNamespace'),
  SAVE_STATE: Symbol('env-controller.saveState'),
  LOAD_STATE: Symbol('env-controller.loadState'),
  EXPORT_STATE: Symbol('env-controller.exportState'),
  IMPORT_STATE: Symbol('env-controller.importState'),
  GET_STATE: Symbol('env-controller.getState'),
  GET_STATS: Symbol('env-controller.getStats'),
  RESET: Symbol('env-controller.reset'),
  DESTROY: Symbol('env-controller.destroy'),
  EMIT: Symbol('env-controller.emit'),
  ON: Symbol('env-controller.on'),
  OFF: Symbol('env-controller.off'),
  LOG: Symbol('env-controller.log'),
  DEBUG: Symbol('env-controller.debug'),
  ERROR: Symbol('env-controller.error'),
  WARN: Symbol('env-controller.warn'),
  INFO: Symbol('env-controller.info'),
  SUCCESS: Symbol('env-controller.success'),
  TRACE: Symbol('env-controller.trace'),
};

// ============================================================
// 2. ПУБЛИЧНЫЕ СИМВОЛЫ (доступны через Symbol.for)
// ============================================================

export const PUBLIC_ENV = {
  API: Symbol.for('env-controller.api'),
  STATE: Symbol.for('env-controller.state'),
  CONFIG: Symbol.for('env-controller.config'),
  LOGGER: Symbol.for('env-controller.logger'),
  EVENTS: Symbol.for('env-controller.events'),
  INSTANCE: Symbol.for('env-controller.instance'),
  NAMESPACE: Symbol.for('env-controller.namespace'),
  PRESETS: Symbol.for('env-controller.presets'),
};

// ============================================================
// 3. КОНФИГУРАЦИЯ (100% СИМВОЛЫ)
// ============================================================

const CONFIG_SYMBOLS = {
  STORAGE_KEY: Symbol('config.storageKey'),
  PRESETS_KEY: Symbol('config.presetsKey'),
  AUTO_UPDATE_INTERVAL: Symbol('config.autoUpdateInterval'),
  DEBOUNCE_DELAY: Symbol('config.debounceDelay'),
  MAX_HISTORY: Symbol('config.maxHistory'),
  DEFAULT_NAMESPACE: Symbol('config.defaultNamespace'),
  PRESETS: Symbol('config.presets'),
};

const CONFIG = {
  [CONFIG_SYMBOLS.STORAGE_KEY]: 'env-controller-state',
  [CONFIG_SYMBOLS.PRESETS_KEY]: 'env-controller-presets',
  [CONFIG_SYMBOLS.AUTO_UPDATE_INTERVAL]: 30000,
  [CONFIG_SYMBOLS.DEBOUNCE_DELAY]: 300,
  [CONFIG_SYMBOLS.MAX_HISTORY]: 100,
  [CONFIG_SYMBOLS.DEFAULT_NAMESPACE]: '',
  [CONFIG_SYMBOLS.PRESETS]: [
    { name: 'Все flow', value: 'wasm:flow:*' },
    { name: 'Flow шаги', value: 'wasm:flow:step:*' },
    { name: 'Все память', value: 'wasm:memory:*' },
    { name: 'Все генерация', value: 'wasm:generate:*' },
    { name: 'Все API', value: 'wasm:api:*' },
    { name: 'Все ошибки', value: 'wasm:error:*' },
    { name: 'ВСЕ ЛОГИ', value: 'wasm:*' },
    { name: 'Все кроме памяти', value: '*,-wasm:memory:*' },
    { name: 'Отключить всё', value: '' },
  ],
};

// ============================================================
// 4. ЛОГГЕР (100% СИМВОЛЫ)
// ============================================================

const LOGGER_SYMBOLS = {
  HISTORY: Symbol('logger.history'),
  MAX_HISTORY: Symbol('logger.maxHistory'),
  DEBUG: Symbol('logger.debug'),
  INSTANCE_ID: Symbol('logger.instanceId'),
  LEVEL: Symbol('logger.level'),
  TIMESTAMP: Symbol('logger.timestamp'),
  COLORS: Symbol('logger.colors'),
  OUTPUT: Symbol('logger.output'),
};

function createEnvLogger(debug = true, instanceId = 'EnvController') {
  const loggerState = {
    [LOGGER_SYMBOLS.HISTORY]: [],
    [LOGGER_SYMBOLS.MAX_HISTORY]: 200,
    [LOGGER_SYMBOLS.DEBUG]: debug,
    [LOGGER_SYMBOLS.INSTANCE_ID]: instanceId,
    [LOGGER_SYMBOLS.LEVEL]: 'info',
    [LOGGER_SYMBOLS.TIMESTAMP]: true,
    [LOGGER_SYMBOLS.COLORS]: true,
    [LOGGER_SYMBOLS.OUTPUT]: console,
  };

  const logMethod = function (level, message, data = null) {
    if (!this[LOGGER_SYMBOLS.DEBUG] && level !== 'error') {
      return;
    }

    const timestamp = this[LOGGER_SYMBOLS.TIMESTAMP]
      ? `[${new Date().toISOString().slice(11, 23)}]`
      : '';
    const prefix = `${timestamp} [${this[LOGGER_SYMBOLS.INSTANCE_ID]}]`;
    const output = this[LOGGER_SYMBOLS.OUTPUT];

    this[LOGGER_SYMBOLS.HISTORY].push({ timestamp, level, message, data });
    if (this[LOGGER_SYMBOLS.HISTORY].length > this[LOGGER_SYMBOLS.MAX_HISTORY]) {
      this[LOGGER_SYMBOLS.HISTORY].shift();
    }

    const styles = this[LOGGER_SYMBOLS.COLORS]
      ? {
        error: 'color: #ff6b6b; font-weight: bold;',
        warn: 'color: #fdcb6e; font-weight: bold;',
        info: 'color: #74b9ff; font-weight: bold;',
        debug: 'color: #a29bfe;',
        success: 'color: #00b894; font-weight: bold;',
        trace: 'color: #dfe6e9; font-style: italic;',
      }
      : {};

    const style = styles[level] || styles.info;

    if (data !== null && data !== undefined) {
      if (typeof data === 'object') {
        output.log(`%c${prefix} ${message}`, style, data);
      } else {
        output.log(`%c${prefix} ${message}`, style, data);
      }
    } else {
      output.log(`%c${prefix} ${message}`, style);
    }
  };

  const boundLog = logMethod.bind(loggerState);

  const logger = {
    error: (msg, d) => boundLog('error', `❌ ${msg}`, d),
    warn: (msg, d) => boundLog('warn', `⚠️ ${msg}`, d),
    info: (msg, d) => boundLog('info', `ℹ️ ${msg}`, d),
    debug: (msg, d) => boundLog('debug', `🔍 ${msg}`, d),
    success: (msg, d) => boundLog('info', `✅ ${msg}`, d),
    trace: (msg, d) => boundLog('trace', `🐛 ${msg}`, d),

    header: (title) => {
      const output = loggerState[LOGGER_SYMBOLS.OUTPUT];
      output.log('%c' + '═'.repeat(70), 'color: #636e72;');
      output.log(
        '%c  📦 ' + title,
        'background: #1a1a2e; color: #fff; padding: 4px 12px; border-radius: 4px; font-weight: bold;'
      );
      output.log('%c' + '═'.repeat(70), 'color: #636e72;');
    },

    separator: () => {
      const output = loggerState[LOGGER_SYMBOLS.OUTPUT];
      output.log('%c' + '─'.repeat(70), 'color: #636e72;');
    },

    symbol: (name, symbol) => {
      const output = loggerState[LOGGER_SYMBOLS.OUTPUT];
      output.log(`  🔑 ${name}: ${String(symbol)}`);
    },

    private: (name, symbol) => {
      const output = loggerState[LOGGER_SYMBOLS.OUTPUT];
      output.log(`  🔒 ${name}: ${String(symbol)}`);
    },

    getHistory: () => [...loggerState[LOGGER_SYMBOLS.HISTORY]],
    clearHistory: () => {
      loggerState[LOGGER_SYMBOLS.HISTORY] = [];
      return logger;
    },
    setDebug: (enabled) => {
      loggerState[LOGGER_SYMBOLS.DEBUG] = enabled;
      return logger;
    },
    setLevel: (level) => {
      loggerState[LOGGER_SYMBOLS.LEVEL] = level;
      return logger;
    },
    getLevel: () => loggerState[LOGGER_SYMBOLS.LEVEL],
    setOutput: (output) => {
      loggerState[LOGGER_SYMBOLS.OUTPUT] = output;
      return logger;
    },
  };

  return logger;
}

// ============================================================
// 5. ВАЛИДАТОР (100% СИМВОЛЫ)
// ============================================================

const VALIDATOR_SYMBOLS = {
  IS_VALID_NAMESPACE: Symbol('validator.isValidNamespace'),
  IS_VALID_PRESET: Symbol('validator.isValidPreset'),
  IS_VALID_ACTION: Symbol('validator.isValidAction'),
  IS_VALID_COMMAND: Symbol('validator.isValidCommand'),
  IS_VALID_STATE: Symbol('validator.isValidState'),
  SANITIZE_NAMESPACE: Symbol('validator.sanitizeNamespace'),
  NORMALIZE_NAMESPACE: Symbol('validator.normalizeNamespace'),
};

const VALIDATOR = {
  [VALIDATOR_SYMBOLS.IS_VALID_NAMESPACE]: (ns) => {
    return typeof ns === 'string' && ns.length < 1000;
  },

  [VALIDATOR_SYMBOLS.IS_VALID_PRESET]: (preset) => {
    return preset && typeof preset === 'object' && typeof preset.name === 'string' && typeof preset.value === 'string';
  },

  [VALIDATOR_SYMBOLS.IS_VALID_ACTION]: (action) => {
    return typeof action === 'function';
  },

  [VALIDATOR_SYMBOLS.IS_VALID_COMMAND]: (cmd) => {
    return typeof cmd === 'string' && cmd.length < 500;
  },

  [VALIDATOR_SYMBOLS.IS_VALID_STATE]: (state) => {
    return state && typeof state === 'object' && typeof state.namespace === 'string';
  },

  [VALIDATOR_SYMBOLS.SANITIZE_NAMESPACE]: (ns) => {
    if (!ns) return '';
    if (typeof ns !== 'string') return '';
    return ns.replace(/[^a-zA-Z0-9:*\-_,]/g, '').trim();
  },

  [VALIDATOR_SYMBOLS.NORMALIZE_NAMESPACE]: (ns) => {
    if (!ns) return '';
    if (typeof ns !== 'string') return '';
    return ns.trim();
  },
};

// ============================================================
// 6. ОСНОВНОЙ КЛАСС ENV CONTROLLER (100% СИМВОЛЫ)
// ============================================================

export class EnvController extends PanelController {
  constructor(options = {}) {
    // Создаём панель если не передана
    if (!options.panel) {
      const panel = document.createElement('div');
      panel.id = options.panelId || 'env-control-panel';
      panel.style.cssText = options.style || '';
      options.panel = panel;
    }

    // Передаём действия ENV
    options.actions = ENV_ACTIONS;

    super(options);

    // ============================================================
    // 6.1 ИНИЦИАЛИЗАЦИЯ ПРИВАТНЫХ СВОЙСТВ
    // ============================================================

    this[ENV_CONTROLLER_SYMBOLS.ID] = options.id || 'env-' + Date.now() + '-' + Math.random().toString(36).substr(2, 4);
    this[ENV_CONTROLLER_SYMBOLS.NAME] = options.name || 'ENV Control';
    this[ENV_CONTROLLER_SYMBOLS.TYPE] = options.type || 'env';
    this[ENV_CONTROLLER_SYMBOLS.VERSION] = options.version || '2.1.9';
    this[ENV_CONTROLLER_SYMBOLS.PANEL_ID] = options.panelId || 'env-control-panel';
    this[ENV_CONTROLLER_SYMBOLS.INSTANCE_ID] = this[ENV_CONTROLLER_SYMBOLS.ID];

    // Состояние
    this[ENV_CONTROLLER_SYMBOLS.CURRENT_NAMESPACE] = '';
    this[ENV_CONTROLLER_SYMBOLS.PREVIOUS_NAMESPACE] = '';
    this[ENV_CONTROLLER_SYMBOLS.IS_INITIALIZED] = false;
    this[ENV_CONTROLLER_SYMBOLS.IS_DESTROYED] = false;
    this[ENV_CONTROLLER_SYMBOLS.LAST_UPDATE] = null;
    this[ENV_CONTROLLER_SYMBOLS.UPDATE_COUNT] = 0;

    // DOM элементы
    this[ENV_CONTROLLER_SYMBOLS.GROUPS_CONTAINER] = null;
    this[ENV_CONTROLLER_SYMBOLS.ACTIONS_CONTAINER] = null;
    this[ENV_CONTROLLER_SYMBOLS.COMMANDS_CONTAINER] = null;
    this[ENV_CONTROLLER_SYMBOLS.STATUS_BADGE] = null;

    // Данные
    this[ENV_CONTROLLER_SYMBOLS.PRESETS] = [];
    this[ENV_CONTROLLER_SYMBOLS.PRESETS_MAP] = new Map();
    this[ENV_CONTROLLER_SYMBOLS.ACTIONS_MAP] = new Map();
    this[ENV_CONTROLLER_SYMBOLS.COMMANDS_MAP] = new Map();
    this[ENV_CONTROLLER_SYMBOLS.CACHE] = new Map();
    this[ENV_CONTROLLER_SYMBOLS.METADATA] = {
      created: Date.now(),
      lastAccess: Date.now(),
      lastUpdate: Date.now(),
      updateCount: 0,
      errorCount: 0,
      namespaceChanges: 0,
    };
    this[ENV_CONTROLLER_SYMBOLS.CONTEXT] = {
      url: typeof window !== 'undefined' ? window.location.href : '',
      title: typeof window !== 'undefined' ? document.title : '',
      userAgent: typeof navigator !== 'undefined' ? navigator.userAgent : '',
    };
    this[ENV_CONTROLLER_SYMBOLS.LOG_HISTORY] = [];

    // Таймеры
    this[ENV_CONTROLLER_SYMBOLS.TIMERS] = new Map();
    this[ENV_CONTROLLER_SYMBOLS.RAF_ID] = null;
    this[ENV_CONTROLLER_SYMBOLS.DEBOUNCE_ID] = null;
    this[ENV_CONTROLLER_SYMBOLS.AUTO_UPDATE_ID] = null;

    // Слушатели
    this[ENV_CONTROLLER_SYMBOLS.LISTENERS] = [];
    this[ENV_CONTROLLER_SYMBOLS.EVENT_HANDLERS] = new Map();
    this[ENV_CONTROLLER_SYMBOLS.DOM_OBSERVER] = null;
    this[ENV_CONTROLLER_SYMBOLS.MUTATION_OBSERVER] = null;

    // Логгер
    this[ENV_CONTROLLER_SYMBOLS.LOG] = createEnvLogger(
      options.debug !== false,
      `EnvController:${this[ENV_CONTROLLER_SYMBOLS.ID].slice(-6)}`
    );
    const logger = this[ENV_CONTROLLER_SYMBOLS.LOG];

    // ============================================================
    // 6.2 ЗАГРУЗКА СОСТОЯНИЯ
    // ============================================================

    this[ENV_CONTROLLER_SYMBOLS.LOAD_STATE]();

    // ============================================================
    // 6.3 ИНИЦИАЛИЗАЦИЯ
    // ============================================================

    logger.header(`СОЗДАНИЕ ENV КОНТРОЛЛЕРА (100% СИМВОЛЫ)`);
    logger.info(`📦 ID: ${this[ENV_CONTROLLER_SYMBOLS.ID]}`);
    logger.info(`📌 Имя: ${this[ENV_CONTROLLER_SYMBOLS.NAME]}`);
    logger.info(`📌 Тип: ${this[ENV_CONTROLLER_SYMBOLS.TYPE]}`);
    logger.info(`📌 Версия: ${this[ENV_CONTROLLER_SYMBOLS.VERSION]}`);
    logger.info(`📌 Panel ID: ${this[ENV_CONTROLLER_SYMBOLS.PANEL_ID]}`);
    logger.info(`📌 Отладка: ${options.debug !== false ? '✅' : '❌'}`);

    // Инициализируем пресеты
    this[ENV_CONTROLLER_SYMBOLS.PRESETS] = CONFIG[CONFIG_SYMBOLS.PRESETS] || [];

    // Строим карту пресетов
    for (const preset of this[ENV_CONTROLLER_SYMBOLS.PRESETS]) {
      this[ENV_CONTROLLER_SYMBOLS.PRESETS_MAP].set(preset.value, preset);
    }

    // Инициализируем UI
    this[ENV_CONTROLLER_SYMBOLS.INIT]();

    // Устанавливаем текущий namespace
    const currentNS = ENV_ACTIONS.getDebugNamespace();
    this[ENV_CONTROLLER_SYMBOLS.CURRENT_NAMESPACE] = currentNS;

    // Настраиваем авто-обновление
    this[ENV_CONTROLLER_SYMBOLS.SETUP_OBSERVERS]();

    // Устанавливаем флаг
    this[ENV_CONTROLLER_SYMBOLS.IS_INITIALIZED] = true;

    logger.success(`✅ EnvController инициализирован (namespace: ${currentNS || 'off'})`);
    logger.header('ГОТОВ');
  }

  // ============================================================
  // 6.4 ★★★ ИНИЦИАЛИЗАЦИЯ UI ★★★
  // ============================================================

  [ENV_CONTROLLER_SYMBOLS.INIT]() {
    const logger = this[ENV_CONTROLLER_SYMBOLS.LOG];
    logger.info('🔧 Инициализация UI...');

    this[ENV_CONTROLLER_SYMBOLS.SETUP_UI]();
    this[ENV_CONTROLLER_SYMBOLS.SETUP_HANDLERS]();

    logger.success('✅ UI инициализирован');
  }

  // ============================================================
  // 6.5 ★★★ НАСТРОЙКА UI ★★★
  // ============================================================

  [ENV_CONTROLLER_SYMBOLS.SETUP_UI]() {
    const logger = this[ENV_CONTROLLER_SYMBOLS.LOG];
    const panel = this.getPanel();
    if (!panel) {
      logger.error('❌ Панель не найдена');
      return;
    }

    logger.info('🎨 Настройка UI...');

    // Строим тело из шаблона
    const currentNS = this[ENV_CONTROLLER_SYMBOLS.CURRENT_NAMESPACE];
    const bodyContent = ENV_TEMPLATE.body(currentNS);
    const body = panel.querySelector('#panel-body');

    if (body) {
      body.innerHTML = bodyContent;
      logger.debug('✅ Тело панели обновлено');
    } else {
      logger.warn('⚠️ Тело панели не найдено');
    }

    // Сохраняем контейнеры
    this[ENV_CONTROLLER_SYMBOLS.GROUPS_CONTAINER] = document.getElementById('env-groups');
    this[ENV_CONTROLLER_SYMBOLS.ACTIONS_CONTAINER] = document.getElementById('env-actions');
    this[ENV_CONTROLLER_SYMBOLS.COMMANDS_CONTAINER] = document.getElementById('env-commands');
    this[ENV_CONTROLLER_SYMBOLS.STATUS_BADGE] = document.getElementById('panel-status-badge');

    // Обновляем UI
    this[ENV_CONTROLLER_SYMBOLS.UPDATE_UI]();

    logger.success('✅ UI настроен');
  }

  // ============================================================
  // 6.6 ★★★ НАСТРОЙКА ОБРАБОТЧИКОВ ★★★
  // ============================================================

  [ENV_CONTROLLER_SYMBOLS.SETUP_HANDLERS]() {
    const logger = this[ENV_CONTROLLER_SYMBOLS.LOG];
    const panel = this.getPanel();

    if (!panel) {
      logger.error('❌ Панель не найдена');
      return;
    }

    logger.info('👂 Настройка обработчиков...');

    // Пресеты
    panel.querySelectorAll('.preset-btn').forEach((btn) => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const preset = btn.dataset.preset;
        if (preset !== undefined) {
          this[ENV_CONTROLLER_SYMBOLS.HANDLE_PRESET](preset);
        }
      });

      // Добавляем hover эффект
      btn.addEventListener('mouseenter', () => {
        const isActive = btn.dataset.preset === this[ENV_CONTROLLER_SYMBOLS.CURRENT_NAMESPACE];
        btn.style.background = isActive ? 'rgba(102,126,234,0.4)' : 'rgba(255,255,255,0.08)';
        btn.style.transform = 'translateY(-1px)';
      });

      btn.addEventListener('mouseleave', () => {
        const isActive = btn.dataset.preset === this[ENV_CONTROLLER_SYMBOLS.CURRENT_NAMESPACE];
        btn.style.background = isActive ? 'rgba(102,126,234,0.3)' : 'rgba(255,255,255,0.03)';
        btn.style.transform = 'translateY(0)';
      });
    });

    // Действия
    panel.querySelectorAll('.action-btn').forEach((btn) => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const action = btn.dataset.action;
        if (action) {
          this[ENV_CONTROLLER_SYMBOLS.HANDLE_ACTION](action);
        }
      });

      // Добавляем hover эффект
      btn.addEventListener('mouseenter', () => {
        btn.style.background = 'rgba(255,255,255,0.08)';
        btn.style.transform = 'translateY(-1px)';
      });

      btn.addEventListener('mouseleave', () => {
        btn.style.background = 'rgba(255,255,255,0.03)';
        btn.style.transform = 'translateY(0)';
      });
    });

    // Команды (копирование при клике)
    panel.querySelectorAll('#env-commands code').forEach((code) => {
      code.addEventListener('click', () => {
        const text = code.textContent;
        if (text) {
          navigator.clipboard.writeText(text).then(() => {
            logger.success(`📋 Команда скопирована: ${text}`);
          }).catch(() => {
            logger.warn(`⚠️ Не удалось скопировать: ${text}`);
          });
        }
      });
    });

    // Обновляем UI при изменении ENV
    if (typeof window.ENV !== 'undefined' && window.ENV.on) {
      window.ENV.on('debug', (data) => {
        const ns = data.namespace || '';
        this[ENV_CONTROLLER_SYMBOLS.CURRENT_NAMESPACE] = ns;
        this[ENV_CONTROLLER_SYMBOLS.UPDATE_UI]();
      });
    }

    logger.success(`✅ Обработчиков настроено: ${panel.querySelectorAll('.preset-btn').length + panel.querySelectorAll('.action-btn').length}`);
  }

  // ============================================================
  // 6.7 ★★★ НАСТРОЙКА НАБЛЮДАТЕЛЕЙ ★★★
  // ============================================================

  [ENV_CONTROLLER_SYMBOLS.SETUP_OBSERVERS]() {
    const logger = this[ENV_CONTROLLER_SYMBOLS.LOG];
    logger.info('🔭 Настройка наблюдателей...');

    // Авто-обновление
    const interval = CONFIG[CONFIG_SYMBOLS.AUTO_UPDATE_INTERVAL];
    const timer = setInterval(() => {
      if (!this[ENV_CONTROLLER_SYMBOLS.IS_DESTROYED]) {
        const ns = ENV_ACTIONS.getDebugNamespace();
        if (ns !== this[ENV_CONTROLLER_SYMBOLS.CURRENT_NAMESPACE]) {
          this[ENV_CONTROLLER_SYMBOLS.CURRENT_NAMESPACE] = ns;
          this[ENV_CONTROLLER_SYMBOLS.UPDATE_UI]();
          logger.debug(`🔄 Авто-обновление: ${ns || 'off'}`);
        }
      }
    }, interval);

    this[ENV_CONTROLLER_SYMBOLS.TIMERS].set('autoUpdate', timer);
    this[ENV_CONTROLLER_SYMBOLS.AUTO_UPDATE_ID] = timer;

    // MutationObserver для отслеживания изменений в DOM
    if (typeof MutationObserver !== 'undefined') {
      const panel = this.getPanel();
      if (panel) {
        const observer = new MutationObserver((mutations) => {
          for (const mutation of mutations) {
            if (mutation.type === 'attributes' && mutation.attributeName === 'style') {
              // Обновляем состояние при изменении стилей
              this[ENV_CONTROLLER_SYMBOLS.SAVE_STATE]();
            }
          }
        });

        observer.observe(panel, {
          attributes: true,
          attributeFilter: ['style', 'class'],
          subtree: false,
        });

        this[ENV_CONTROLLER_SYMBOLS.MUTATION_OBSERVER] = observer;
        logger.debug('✅ MutationObserver настроен');
      }
    }

    // Слушаем изменения localStorage
    window.addEventListener('storage', (e) => {
      if (e.key === 'debug' && e.newValue !== null) {
        this[ENV_CONTROLLER_SYMBOLS.CURRENT_NAMESPACE] = e.newValue;
        this[ENV_CONTROLLER_SYMBOLS.UPDATE_UI]();
        logger.debug(`🔄 Изменение localStorage: ${e.newValue || 'off'}`);
      }
    });

    logger.success('✅ Наблюдатели настроены');
  }

  // ============================================================
  // 6.8 ★★★ ОБНОВЛЕНИЕ UI ★★★
  // ============================================================

  [ENV_CONTROLLER_SYMBOLS.UPDATE_UI]() {
    const logger = this[ENV_CONTROLLER_SYMBOLS.LOG];
    const current = this[ENV_CONTROLLER_SYMBOLS.CURRENT_NAMESPACE] || '';

    this[ENV_CONTROLLER_SYMBOLS.UPDATE_COUNT]++;
    this[ENV_CONTROLLER_SYMBOLS.LAST_UPDATE] = Date.now();
    this[ENV_CONTROLLER_SYMBOLS.METADATA].lastUpdate = Date.now();
    this[ENV_CONTROLLER_SYMBOLS.METADATA].updateCount++;

    // Обновляем пресеты
    this[ENV_CONTROLLER_SYMBOLS.UPDATE_PRESETS]();

    // Обновляем бейдж
    this[ENV_CONTROLLER_SYMBOLS.UPDATE_BADGE]();

    // Сохраняем состояние
    this[ENV_CONTROLLER_SYMBOLS.SAVE_STATE]();

    logger.debug(`🔄 UI обновлён: ${current || 'off'}`);
  }

  // ============================================================
  // 6.9 ★★★ ОБНОВЛЕНИЕ ПРЕСЕТОВ ★★★
  // ============================================================

  [ENV_CONTROLLER_SYMBOLS.UPDATE_PRESETS]() {
    const container = this[ENV_CONTROLLER_SYMBOLS.GROUPS_CONTAINER];
    if (!container) return;

    const current = this[ENV_CONTROLLER_SYMBOLS.CURRENT_NAMESPACE] || '';
    const buttons = container.querySelectorAll('.preset-btn');

    for (const btn of buttons) {
      const preset = btn.dataset.preset || '';
      const active = preset === current;

      btn.style.background = active ? 'rgba(102,126,234,0.3)' : 'rgba(255,255,255,0.03)';
      btn.style.color = active ? '#fff' : '#8899bb';
      btn.style.borderColor = active ? '#667eea' : 'rgba(255,255,255,0.05)';
      btn.style.fontWeight = active ? 'bold' : 'normal';
    }
  }

  // ============================================================
  // 6.10 ★★★ ОБНОВЛЕНИЕ БЕЙДЖА ★★★
  // ============================================================

  [ENV_CONTROLLER_SYMBOLS.UPDATE_BADGE]() {
    const badge = this[ENV_CONTROLLER_SYMBOLS.STATUS_BADGE];
    if (!badge) return;

    const current = this[ENV_CONTROLLER_SYMBOLS.CURRENT_NAMESPACE] || '';
    const isOn = current && current !== 'off' && current !== '';

    badge.textContent = current || 'off';
    badge.style.background = isOn ? 'rgba(0,184,148,0.15)' : 'rgba(255,255,255,0.05)';
    badge.style.color = isOn ? '#00b894' : '#636e72';
    badge.style.borderColor = isOn ? 'rgba(0,184,148,0.2)' : 'rgba(255,255,255,0.05)';
    badge.style.fontWeight = isOn ? 'bold' : 'normal';

    // Тултип
    badge.title = isOn ? `Active: ${current}` : 'Debug disabled';
  }

  // ============================================================
  // 6.11 ★★★ ОБРАБОТКА ПРЕСЕТА ★★★
  // ============================================================

  [ENV_CONTROLLER_SYMBOLS.HANDLE_PRESET](preset) {
    const logger = this[ENV_CONTROLLER_SYMBOLS.LOG];
    const previous = this[ENV_CONTROLLER_SYMBOLS.CURRENT_NAMESPACE];

    logger.debug(`🎯 Пресет: ${preset || 'off'}`);

    if (preset !== undefined && preset !== null) {
      this[ENV_CONTROLLER_SYMBOLS.PREVIOUS_NAMESPACE] = previous;
      this[ENV_CONTROLLER_SYMBOLS.SET_NAMESPACE](preset);
    }

    // Эмитим событие
    this[ENV_CONTROLLER_SYMBOLS.EMIT]('preset', {
      preset,
      previous,
      current: this[ENV_CONTROLLER_SYMBOLS.CURRENT_NAMESPACE],
      timestamp: Date.now(),
    });
  }

  // ============================================================
  // 6.12 ★★★ ОБРАБОТКА ДЕЙСТВИЯ ★★★
  // ============================================================

  [ENV_CONTROLLER_SYMBOLS.HANDLE_ACTION](action) {
    const logger = this[ENV_CONTROLLER_SYMBOLS.LOG];

    logger.debug(`⚡ Действие: ${action}`);

    switch (action) {
      case 'enable-all':
        this[ENV_CONTROLLER_SYMBOLS.SET_NAMESPACE]('wasm:*');
        break;
      case 'disable-all':
        this[ENV_CONTROLLER_SYMBOLS.SET_NAMESPACE']('');
        break;
      case 'show-config':
        this[ENV_CONTROLLER_SYMBOLS.ENV_ACTIONS].showConfig?.();
        break;
      case 'help':
        this[ENV_CONTROLLER_SYMBOLS.ENV_ACTIONS].help?.();
        break;
      default:
        logger.warn(`⚠️ Неизвестное действие: ${action}`);
        break;
    }

    // Эмитим событие
    this[ENV_CONTROLLER_SYMBOLS.EMIT]('action', {
      action,
      timestamp: Date.now(),
      namespace: this[ENV_CONTROLLER_SYMBOLS.CURRENT_NAMESPACE],
    });
  }

  // ============================================================
  // 6.13 ★★★ УСТАНОВКА NAMESPACE ★★★
  // ============================================================

  [ENV_CONTROLLER_SYMBOLS.SET_NAMESPACE](namespace) {
    const logger = this[ENV_CONTROLLER_SYMBOLS.LOG];
    const previous = this[ENV_CONTROLLER_SYMBOLS.CURRENT_NAMESPACE];

    // Валидация
    const sanitized = VALIDATOR[VALIDATOR_SYMBOLS.SANITIZE_NAMESPACE](namespace);
    const normalized = VALIDATOR[VALIDATOR_SYMBOLS.NORMALIZE_NAMESPACE](sanitized);

    if (normalized !== previous) {
      this[ENV_CONTROLLER_SYMBOLS.PREVIOUS_NAMESPACE] = previous;
      this[ENV_CONTROLLER_SYMBOLS.CURRENT_NAMESPACE] = normalized;
      this[ENV_CONTROLLER_SYMBOLS.METADATA].namespaceChanges++;
      this[ENV_CONTROLLER_SYMBOLS.METADATA].lastUpdate = Date.now();

      // Устанавливаем через ENV_ACTIONS
      if (normalized) {
        ENV_ACTIONS.enableDebug(normalized);
      } else {
        ENV_ACTIONS.disableDebug();
      }

      // Обновляем UI
      this[ENV_CONTROLLER_SYMBOLS.UPDATE_UI]();

      // Сохраняем состояние
      this[ENV_CONTROLLER_SYMBOLS.SAVE_STATE]();

      // Эмитим событие
      this[ENV_CONTROLLER_SYMBOLS.EMIT]('namespaceChange', {
        previous,
        current: normalized,
        timestamp: Date.now(),
      });

      logger.success(`🔍 Namespace изменён: ${previous || 'off'} → ${normalized || 'off'}`);
    } else {
      logger.debug(`ℹ️ Namespace не изменился: ${normalized || 'off'}`);
    }

    return normalized;
  }

  // ============================================================
  // 6.14 ★★★ ПОЛУЧЕНИЕ NAMESPACE ★★★
  // ============================================================

  [ENV_CONTROLLER_SYMBOLS.GET_NAMESPACE]() {
    return this[ENV_CONTROLLER_SYMBOLS.CURRENT_NAMESPACE] || '';
  }

  // ============================================================
  // 6.15 ★★★ СБРОС NAMESPACE ★★★
  // ============================================================

  [ENV_CONTROLLER_SYMBOLS.RESET_NAMESPACE]() {
    const defaultNS = CONFIG[CONFIG_SYMBOLS.DEFAULT_NAMESPACE];
    return this[ENV_CONTROLLER_SYMBOLS.SET_NAMESPACE](defaultNS);
  }

  // ============================================================
  // 6.16 ★★★ СОХРАНЕНИЕ СОСТОЯНИЯ ★★★
  // ============================================================

  [ENV_CONTROLLER_SYMBOLS.SAVE_STATE]() {
    try {
      const state = {
        namespace: this[ENV_CONTROLLER_SYMBOLS.CURRENT_NAMESPACE],
        previous: this[ENV_CONTROLLER_SYMBOLS.PREVIOUS_NAMESPACE],
        metadata: this[ENV_CONTROLLER_SYMBOLS.METADATA],
        lastUpdate: this[ENV_CONTROLLER_SYMBOLS.LAST_UPDATE],
        updateCount: this[ENV_CONTROLLER_SYMBOLS.UPDATE_COUNT],
        version: this[ENV_CONTROLLER_SYMBOLS.VERSION],
        timestamp: Date.now(),
      };

      const key = CONFIG[CONFIG_SYMBOLS.STORAGE_KEY];
      localStorage.setItem(key, JSON.stringify(state));

      // Кешируем
      this[ENV_CONTROLLER_SYMBOLS.CACHE].set('state', state);
    } catch (e) {
      const logger = this[ENV_CONTROLLER_SYMBOLS.LOG];
      logger.warn(`⚠️ Не удалось сохранить состояние: ${e.message}`);
    }
  }

  // ============================================================
  // 6.17 ★★★ ЗАГРУЗКА СОСТОЯНИЯ ★★★
  // ============================================================

  [ENV_CONTROLLER_SYMBOLS.LOAD_STATE]() {
    try {
      const key = CONFIG[CONFIG_SYMBOLS.STORAGE_KEY];
      const saved = localStorage.getItem(key);

      if (saved) {
        const state = JSON.parse(saved);

        if (state.namespace !== undefined) {
          this[ENV_CONTROLLER_SYMBOLS.CURRENT_NAMESPACE] = state.namespace;
        }

        if (state.previous !== undefined) {
          this[ENV_CONTROLLER_SYMBOLS.PREVIOUS_NAMESPACE] = state.previous;
        }

        if (state.metadata) {
          this[ENV_CONTROLLER_SYMBOLS.METADATA] = {
            ...this[ENV_CONTROLLER_SYMBOLS.METADATA],
            ...state.metadata,
          };
        }

        if (state.lastUpdate) {
          this[ENV_CONTROLLER_SYMBOLS.LAST_UPDATE] = state.lastUpdate;
        }

        if (state.updateCount) {
          this[ENV_CONTROLLER_SYMBOLS.UPDATE_COUNT] = state.updateCount;
        }

        const logger = this[ENV_CONTROLLER_SYMBOLS.LOG];
        logger.debug(`✅ Состояние загружено: ${state.namespace || 'off'}`);
      }
    } catch (e) {
      const logger = this[ENV_CONTROLLER_SYMBOLS.LOG];
      logger.warn(`⚠️ Не удалось загрузить состояние: ${e.message}`);
    }
  }

  // ============================================================
  // 6.18 ★★★ ЭКСПОРТ СОСТОЯНИЯ ★★★
  // ============================================================

  [ENV_CONTROLLER_SYMBOLS.EXPORT_STATE]() {
    const state = {
      id: this[ENV_CONTROLLER_SYMBOLS.ID],
      name: this[ENV_CONTROLLER_SYMBOLS.NAME],
      type: this[ENV_CONTROLLER_SYMBOLS.TYPE],
      version: this[ENV_CONTROLLER_SYMBOLS.VERSION],
      namespace: this[ENV_CONTROLLER_SYMBOLS.CURRENT_NAMESPACE],
      previous: this[ENV_CONTROLLER_SYMBOLS.PREVIOUS_NAMESPACE],
      metadata: this[ENV_CONTROLLER_SYMBOLS.METADATA],
      presets: this[ENV_CONTROLLER_SYMBOLS.PRESETS],
      context: this[ENV_CONTROLLER_SYMBOLS.CONTEXT],
      timestamp: Date.now(),
    };

    return JSON.stringify(state, null, 2);
  }

  // ============================================================
  // 6.19 ★★★ ИМПОРТ СОСТОЯНИЯ ★★★
  // ============================================================

  [ENV_CONTROLLER_SYMBOLS.IMPORT_STATE](json) {
    const logger = this[ENV_CONTROLLER_SYMBOLS.LOG];

    try {
      const state = JSON.parse(json);

      if (state.namespace !== undefined) {
        this[ENV_CONTROLLER_SYMBOLS.SET_NAMESPACE](state.namespace);
      }

      if (state.presets) {
        this[ENV_CONTROLLER_SYMBOLS.PRESETS] = state.presets;
        this[ENV_CONTROLLER_SYMBOLS.PRESETS_MAP].clear();
        for (const preset of state.presets) {
          this[ENV_CONTROLLER_SYMBOLS.PRESETS_MAP].set(preset.value, preset);
        }
        this[ENV_CONTROLLER_SYMBOLS.UPDATE_UI]();
      }

      logger.success('✅ Состояние импортировано');
      return true;
    } catch (e) {
      logger.error(`❌ Ошибка импорта: ${e.message}`);
      return false;
    }
  }

  // ============================================================
  // 6.20 ★★★ ПОЛУЧЕНИЕ СОСТОЯНИЯ ★★★
  // ============================================================

  [ENV_CONTROLLER_SYMBOLS.GET_STATE]() {
    return {
      id: this[ENV_CONTROLLER_SYMBOLS.ID],
      name: this[ENV_CONTROLLER_SYMBOLS.NAME],
      type: this[ENV_CONTROLLER_SYMBOLS.TYPE],
      version: this[ENV_CONTROLLER_SYMBOLS.VERSION],
      namespace: this[ENV_CONTROLLER_SYMBOLS.CURRENT_NAMESPACE],
      previous: this[ENV_CONTROLLER_SYMBOLS.PREVIOUS_NAMESPACE],
      initialized: this[ENV_CONTROLLER_SYMBOLS.IS_INITIALIZED],
      destroyed: this[ENV_CONTROLLER_SYMBOLS.IS_DESTROYED],
      updateCount: this[ENV_CONTROLLER_SYMBOLS.UPDATE_COUNT],
      lastUpdate: this[ENV_CONTROLLER_SYMBOLS.LAST_UPDATE],
      metadata: this[ENV_CONTROLLER_SYMBOLS.METADATA],
      presetsCount: this[ENV_CONTROLLER_SYMBOLS.PRESETS].length,
      panelId: this[ENV_CONTROLLER_SYMBOLS.PANEL_ID],
      instanceId: this[ENV_CONTROLLER_SYMBOLS.INSTANCE_ID],
    };
  }

  // ============================================================
  // 6.21 ★★★ ПОЛУЧЕНИЕ СТАТИСТИКИ ★★★
  // ============================================================

  [ENV_CONTROLLER_SYMBOLS.GET_STATS]() {
    const state = this[ENV_CONTROLLER_SYMBOLS.GET_STATE]();
    const cache = this[ENV_CONTROLLER_SYMBOLS.CACHE];
    const handlers = this[ENV_CONTROLLER_SYMBOLS.EVENT_HANDLERS];
    const logger = this[ENV_CONTROLLER_SYMBOLS.LOG];

    return {
      ...state,
      cacheSize: cache.size,
      cacheKeys: Array.from(cache.keys()),
      handlersCount: handlers.size,
      handlersEvents: Array.from(handlers.keys()),
      logHistoryCount: logger.getHistory().length,
      timersCount: this[ENV_CONTROLLER_SYMBOLS.TIMERS].size,
      hasRaf: !!this[ENV_CONTROLLER_SYMBOLS.RAF_ID],
      hasDebounce: !!this[ENV_CONTROLLER_SYMBOLS.DEBOUNCE_ID],
      hasAutoUpdate: !!this[ENV_CONTROLLER_SYMBOLS.AUTO_UPDATE_ID],
      hasObserver: !!this[ENV_CONTROLLER_SYMBOLS.MUTATION_OBSERVER],
      namespaceChanges: this[ENV_CONTROLLER_SYMBOLS.METADATA].namespaceChanges || 0,
    };
  }

  // ============================================================
  // 6.22 ★★★ СБРОС ★★★
  // ============================================================

  [ENV_CONTROLLER_SYMBOLS.RESET]() {
    const logger = this[ENV_CONTROLLER_SYMBOLS.LOG];
    logger.warn('🔄 Сброс состояния...');

    // Сбрасываем namespace
    this[ENV_CONTROLLER_SYMBOLS.RESET_NAMESPACE]();

    // Очищаем кеш
    this[ENV_CONTROLLER_SYMBOLS.CACHE].clear();

    // Сбрасываем метаданные
    this[ENV_CONTROLLER_SYMBOLS.METADATA] = {
      created: Date.now(),
      lastAccess: Date.now(),
      lastUpdate: Date.now(),
      updateCount: 0,
      errorCount: 0,
      namespaceChanges: 0,
    };

    this[ENV_CONTROLLER_SYMBOLS.UPDATE_COUNT] = 0;
    this[ENV_CONTROLLER_SYMBOLS.LAST_UPDATE] = null;

    // Обновляем UI
    this[ENV_CONTROLLER_SYMBOLS.UPDATE_UI]();

    // Сохраняем состояние
    this[ENV_CONTROLLER_SYMBOLS.SAVE_STATE]();

    // Эмитим событие
    this[ENV_CONTROLLER_SYMBOLS.EMIT]('reset', {
      timestamp: Date.now(),
      namespace: this[ENV_CONTROLLER_SYMBOLS.CURRENT_NAMESPACE],
    });

    logger.success('✅ Состояние сброшено');
    return this;
  }

  // ============================================================
  // 6.23 ★★★ УНИЧТОЖЕНИЕ ★★★
  // ============================================================

  [ENV_CONTROLLER_SYMBOLS.DESTROY]() {
    if (this[ENV_CONTROLLER_SYMBOLS.IS_DESTROYED]) {
      const logger = this[ENV_CONTROLLER_SYMBOLS.LOG];
      logger.warn('⚠️ Контроллер уже уничтожен');
      return;
    }

    const logger = this[ENV_CONTROLLER_SYMBOLS.LOG];
    logger.warn('🗑️ Уничтожение EnvController...');

    // Очищаем таймеры
    const timers = this[ENV_CONTROLLER_SYMBOLS.TIMERS];
    for (const [key, timer] of timers) {
      clearTimeout(timer);
      clearInterval(timer);
    }
    timers.clear();

    if (this[ENV_CONTROLLER_SYMBOLS.RAF_ID]) {
      cancelAnimationFrame(this[ENV_CONTROLLER_SYMBOLS.RAF_ID]);
      this[ENV_CONTROLLER_SYMBOLS.RAF_ID] = null;
    }

    if (this[ENV_CONTROLLER_SYMBOLS.DEBOUNCE_ID]) {
      clearTimeout(this[ENV_CONTROLLER_SYMBOLS.DEBOUNCE_ID]);
      this[ENV_CONTROLLER_SYMBOLS.DEBOUNCE_ID] = null;
    }

    if (this[ENV_CONTROLLER_SYMBOLS.AUTO_UPDATE_ID]) {
      clearInterval(this[ENV_CONTROLLER_SYMBOLS.AUTO_UPDATE_ID]);
      this[ENV_CONTROLLER_SYMBOLS.AUTO_UPDATE_ID] = null;
    }

    // Отключаем наблюдателя
    if (this[ENV_CONTROLLER_SYMBOLS.MUTATION_OBSERVER]) {
      this[ENV_CONTROLLER_SYMBOLS.MUTATION_OBSERVER].disconnect();
      this[ENV_CONTROLLER_SYMBOLS.MUTATION_OBSERVER] = null;
    }

    // Очищаем слушатели
    this[ENV_CONTROLLER_SYMBOLS.LISTENERS] = [];
    this[ENV_CONTROLLER_SYMBOLS.EVENT_HANDLERS].clear();

    // Очищаем кеш
    this[ENV_CONTROLLER_SYMBOLS.CACHE].clear();

    // Удаляем ссылки на DOM элементы
    this[ENV_CONTROLLER_SYMBOLS.GROUPS_CONTAINER] = null;
    this[ENV_CONTROLLER_SYMBOLS.ACTIONS_CONTAINER] = null;
    this[ENV_CONTROLLER_SYMBOLS.COMMANDS_CONTAINER] = null;
    this[ENV_CONTROLLER_SYMBOLS.STATUS_BADGE] = null;

    // Удаляем глобальные ссылки
    if (typeof window !== 'undefined') {
      delete window[PUBLIC_ENV.API];
      delete window[PUBLIC_ENV.STATE];
      delete window[PUBLIC_ENV.CONFIG];
      delete window[PUBLIC_ENV.LOGGER];
      delete window[PUBLIC_ENV.EVENTS];
      delete window[PUBLIC_ENV.INSTANCE];
      delete window[PUBLIC_ENV.NAMESPACE];
      delete window[PUBLIC_ENV.PRESETS];

      if (window.__envController === this) {
        delete window.__envController;
      }
    }

    // Вызываем destroy родителя
    super.destroy();

    this[ENV_CONTROLLER_SYMBOLS.IS_DESTROYED] = true;
    this[ENV_CONTROLLER_SYMBOLS.IS_INITIALIZED] = false;

    logger.success('✅ EnvController уничтожен');
  }

  // ============================================================
  // 6.24 ★★★ СОБЫТИЯ ★★★
  // ============================================================

  [ENV_CONTROLLER_SYMBOLS.ON](event, callback) {
    const logger = this[ENV_CONTROLLER_SYMBOLS.LOG];

    if (typeof callback !== 'function') {
      logger.warn(`⚠️ Некорректный callback для события ${event}`);
      return () => {};
    }

    const handlers = this[ENV_CONTROLLER_SYMBOLS.EVENT_HANDLERS];
    if (!handlers.has(event)) {
      handlers.set(event, []);
    }
    handlers.get(event).push(callback);

    return () => this[ENV_CONTROLLER_SYMBOLS.OFF](event, callback);
  }

  [ENV_CONTROLLER_SYMBOLS.OFF](event, callback) {
    const handlers = this[ENV_CONTROLLER_SYMBOLS.EVENT_HANDLERS];
    if (handlers.has(event)) {
      const list = handlers.get(event);
      const index = list.indexOf(callback);
      if (index !== -1) {
        list.splice(index, 1);
      }
      if (list.length === 0) {
        handlers.delete(event);
      }
    }
  }

  [ENV_CONTROLLER_SYMBOLS.EMIT](event, data) {
    const handlers = this[ENV_CONTROLLER_SYMBOLS.EVENT_HANDLERS];
    const logger = this[ENV_CONTROLLER_SYMBOLS.LOG];

    if (handlers.has(event)) {
      const list = handlers.get(event);
      for (const callback of list) {
        try {
          callback(data);
        } catch (e) {
          logger.error(`❌ Ошибка в обработчике ${event}:`, e.message);
        }
      }
    }

    // Отправляем глобальное событие
    if (typeof window !== 'undefined') {
      try {
        const customEvent = new CustomEvent(`env-controller:${event}`, {
          detail: data,
        });
        window.dispatchEvent(customEvent);
      } catch (e) {
        // Игнорируем ошибки dispatchEvent
      }
    }
  }

  // ============================================================
  // 6.25 ★★★ ЛОГИРОВАНИЕ ★★★
  // ============================================================

  [ENV_CONTROLLER_SYMBOLS.LOG](level, message, data) {
    const logger = this[ENV_CONTROLLER_SYMBOLS.LOG];
    const method = logger[level] || logger.info;
    method(message, data);
  }

  [ENV_CONTROLLER_SYMBOLS.DEBUG](message, data) {
    this[ENV_CONTROLLER_SYMBOLS.LOG]('debug', message, data);
  }

  [ENV_CONTROLLER_SYMBOLS.ERROR](message, data) {
    this[ENV_CONTROLLER_SYMBOLS.LOG]('error', message, data);
  }

  [ENV_CONTROLLER_SYMBOLS.WARN](message, data) {
    this[ENV_CONTROLLER_SYMBOLS.LOG]('warn', message, data);
  }

  [ENV_CONTROLLER_SYMBOLS.INFO](message, data) {
    this[ENV_CONTROLLER_SYMBOLS.LOG]('info', message, data);
  }

  [ENV_CONTROLLER_SYMBOLS.SUCCESS](message, data) {
    this[ENV_CONTROLLER_SYMBOLS.LOG]('success', message, data);
  }

  [ENV_CONTROLLER_SYMBOLS.TRACE](message, data) {
    this[ENV_CONTROLLER_SYMBOLS.LOG]('trace', message, data);
  }

  // ============================================================
  // 6.26 ★★★ ПУБЛИЧНЫЕ МЕТОДЫ ★★★
  // ============================================================

  setNamespace(namespace) {
    return this[ENV_CONTROLLER_SYMBOLS.SET_NAMESPACE](namespace);
  }

  getNamespace() {
    return this[ENV_CONTROLLER_SYMBOLS.GET_NAMESPACE]();
  }

  resetNamespace() {
    return this[ENV_CONTROLLER_SYMBOLS.RESET_NAMESPACE]();
  }

  updateUI() {
    return this[ENV_CONTROLLER_SYMBOLS.UPDATE_UI]();
  }

  getState() {
    return this[ENV_CONTROLLER_SYMBOLS.GET_STATE]();
  }

  getStats() {
    return this[ENV_CONTROLLER_SYMBOLS.GET_STATS]();
  }

  reset() {
    return this[ENV_CONTROLLER_SYMBOLS.RESET]();
  }

  destroy() {
    return this[ENV_CONTROLLER_SYMBOLS.DESTROY]();
  }

  on(event, callback) {
    return this[ENV_CONTROLLER_SYMBOLS.ON](event, callback);
  }

  off(event, callback) {
    return this[ENV_CONTROLLER_SYMBOLS.OFF](event, callback);
  }

  emit(event, data) {
    return this[ENV_CONTROLLER_SYMBOLS.EMIT](event, data);
  }

  exportState() {
    return this[ENV_CONTROLLER_SYMBOLS.EXPORT_STATE]();
  }

  importState(json) {
    return this[ENV_CONTROLLER_SYMBOLS.IMPORT_STATE](json);
  }

  saveState() {
    return this[ENV_CONTROLLER_SYMBOLS.SAVE_STATE]();
  }

  loadState() {
    return this[ENV_CONTROLLER_SYMBOLS.LOAD_STATE]();
  }

  // ============================================================
  // 6.27 ★★★ ГЕТТЕРЫ ★★★
  // ============================================================

  get id() {
    return this[ENV_CONTROLLER_SYMBOLS.ID];
  }

  get name() {
    return this[ENV_CONTROLLER_SYMBOLS.NAME];
  }

  get type() {
    return this[ENV_CONTROLLER_SYMBOLS.TYPE];
  }

  get version() {
    return this[ENV_CONTROLLER_SYMBOLS.VERSION];
  }

  get panelId() {
    return this[ENV_CONTROLLER_SYMBOLS.PANEL_ID];
  }

  get instanceId() {
    return this[ENV_CONTROLLER_SYMBOLS.INSTANCE_ID];
  }

  get namespace() {
    return this[ENV_CONTROLLER_SYMBOLS.CURRENT_NAMESPACE];
  }

  get isInitialized() {
    return this[ENV_CONTROLLER_SYMBOLS.IS_INITIALIZED];
  }

  get isDestroyed() {
    return this[ENV_CONTROLLER_SYMBOLS.IS_DESTROYED];
  }

  get metadata() {
    return { ...this[ENV_CONTROLLER_SYMBOLS.METADATA] };
  }

  get context() {
    return { ...this[ENV_CONTROLLER_SYMBOLS.CONTEXT] };
  }

  get presets() {
    return [...this[ENV_CONTROLLER_SYMBOLS.PRESETS]];
  }

  get logger() {
    return this[ENV_CONTROLLER_SYMBOLS.LOG];
  }
}

// ============================================================
// 7. ★★★ ЭКСПОРТЫ ★★★
// ============================================================

export {
  ENV_CONTROLLER_SYMBOLS,
  PUBLIC_ENV,
  CONFIG_SYMBOLS,
  CONFIG,
  LOGGER_SYMBOLS,
  VALIDATOR_SYMBOLS,
  createEnvLogger,
};

// ============================================================
// 8. ★★★ ДЕФОЛТНЫЙ ЭКСПОРТ ★★★
// ============================================================

export default EnvController;

// ============================================================
// 9. ★★★ ГЛОБАЛЬНАЯ РЕГИСТРАЦИЯ ★★★
// ============================================================

if (typeof window !== 'undefined') {
  // Экспорт через публичные символы
  window[PUBLIC_ENV.API] = {
    setNamespace: (ns) => window.__envController?.setNamespace(ns),
    getNamespace: () => window.__envController?.getNamespace(),
    resetNamespace: () => window.__envController?.resetNamespace(),
    updateUI: () => window.__envController?.updateUI(),
    getState: () => window.__envController?.getState(),
    getStats: () => window.__envController?.getStats(),
    reset: () => window.__envController?.reset(),
    destroy: () => window.__envController?.destroy(),
    exportState: () => window.__envController?.exportState(),
    importState: (json) => window.__envController?.importState(json),
    saveState: () => window.__envController?.saveState(),
    loadState: () => window.__envController?.loadState(),
  };

  window[PUBLIC_ENV.STATE] = () => window.__envController?.getState();
  window[PUBLIC_ENV.CONFIG] = CONFIG;
  window[PUBLIC_ENV.LOGGER] = createEnvLogger(true, 'Global');
  window[PUBLIC_ENV.EVENTS] = {
    on: (event, cb) => window.__envController?.on(event, cb),
    off: (event, cb) => window.__envController?.off(event, cb),
    emit: (event, data) => window.__envController?.emit(event, data),
  };
  window[PUBLIC_ENV.INSTANCE] = null;
  window[PUBLIC_ENV.NAMESPACE] = () => window.__envController?.namespace || '';
  window[PUBLIC_ENV.PRESETS] = () => window.__envController?.presets || [];

  // Создаём глобальный экземпляр
  const globalController = new EnvController({
    debug: true,
    name: 'Global ENV Controller',
    panelId: 'env-control-panel-global',
  });

  window.__envController = globalController;
  window[PUBLIC_ENV.INSTANCE] = globalController;

  // Глобальные команды
  window.__env = {
    controller: globalController,
    setNamespace: globalController.setNamespace.bind(globalController),
    getNamespace: globalController.getNamespace.bind(globalController),
    resetNamespace: globalController.resetNamespace.bind(globalController),
    updateUI: globalController.updateUI.bind(globalController),
    getState: globalController.getState.bind(globalController),
    getStats: globalController.getStats.bind(globalController),
    reset: globalController.reset.bind(globalController),
    destroy: globalController.destroy.bind(globalController),
    on: globalController.on.bind(globalController),
    off: globalController.off.bind(globalController),
    emit: globalController.emit.bind(globalController),
    exportState: globalController.exportState.bind(globalController),
    importState: globalController.importState.bind(globalController),
    saveState: globalController.saveState.bind(globalController),
    loadState: globalController.loadState.bind(globalController),
    getSymbols: () => ({
      ENV_CONTROLLER_SYMBOLS: { ...ENV_CONTROLLER_SYMBOLS },
      PUBLIC_ENV: { ...PUBLIC_ENV },
      CONFIG_SYMBOLS: { ...CONFIG_SYMBOLS },
      LOGGER_SYMBOLS: { ...LOGGER_SYMBOLS },
      VALIDATOR_SYMBOLS: { ...VALIDATOR_SYMBOLS },
      PANEL_CONTROLLER_SYMBOLS: { ...PANEL_CONTROLLER_SYMBOLS },
    }),
  };

  // Баннер
  console.log('╔═══════════════════════════════════════════════════════════════════════════════╗');
  console.log('║              📦 ENV CONTROLLER (100% СИМВОЛЫ) v2.1.9                         ║');
  console.log('╠═══════════════════════════════════════════════════════════════════════════════╣');
  console.log('║  📋 Все логи выводятся в консоль с цветовой разметкой                       ║');
  console.log('║  🔑 Полная изоляция через приватные символы                                 ║');
  console.log('║  🔓 Публичные символы через Symbol.for                                      ║');
  console.log('║  🔧 Управление DEBUG namespace                                              ║');
  console.log('║  📊 Полная статистика и метаданные                                          ║');
  console.log('║  💾 Сохранение и загрузка состояния                                         ║');
  console.log('║  📡 Система событий (on/off/emit)                                          ║');
  console.log('║  🔭 Авто-обновление и наблюдатели                                          ║');
  console.log('║  🎯 Пресеты и быстрые действия                                              ║');
  console.log('╚═══════════════════════════════════════════════════════════════════════════════╝');

  console.log('📋 КОМАНДЫ ОТЛАДКИ (__env):');
  console.log('  __env.setNamespace("wasm:*")  - установить DEBUG');
  console.log('  __env.getNamespace()          - получить текущий DEBUG');
  console.log('  __env.resetNamespace()        - сбросить DEBUG');
  console.log('  __env.updateUI()              - обновить UI');
  console.log('  __env.getState()              - получить состояние');
  console.log('  __env.getStats()              - статистика');
  console.log('  __env.reset()                 - сбросить всё');
  console.log('  __env.destroy()               - уничтожить');
  console.log('  __env.on(event, cb)           - подписка на события');
  console.log('  __env.off(event, cb)          - отписка');
  console.log('  __env.emit(event, data)       - отправка события');
  console.log('  __env.exportState()           - экспорт состояния');
  console.log('  __env.importState(json)       - импорт состояния');
  console.log('  __env.saveState()             - сохранить состояние');
  console.log('  __env.loadState()             - загрузить состояние');
  console.log('  __env.getSymbols()            - получить все символы');
  console.log('');

  console.log('📋 СОБЫТИЯ:');
  console.log('  preset, action, namespaceChange, reset');
  console.log('');

  console.log('📋 ПРИВАТНЫХ СИМВОЛОВ ENV:', Object.keys(ENV_CONTROLLER_SYMBOLS).length);
  console.log('📋 ПУБЛИЧНЫХ СИМВОЛОВ ENV:', Object.keys(PUBLIC_ENV).length);
  console.log('📋 КОНФИГ СИМВОЛОВ:', Object.keys(CONFIG_SYMBOLS).length);
  console.log('📋 ЛОГГЕР СИМВОЛОВ:', Object.keys(LOGGER_SYMBOLS).length);
  console.log('📋 ВАЛИДАТОР СИМВОЛОВ:', Object.keys(VALIDATOR_SYMBOLS).length);
  console.log('═══════════════════════════════════════════════════════════════════════════════');
}

// ============================================================
// 10. ★★★ ПРИМЕР ИСПОЛЬЗОВАНИЯ ★★★
// ============================================================

/*
// Создание контроллера
import EnvController from './controller/env-controller.mjs';

const controller = new EnvController({
  debug: true,
  name: 'My ENV Controller',
  panelId: 'my-env-panel',
});

// Установка namespace
controller.setNamespace('wasm:flow:*');

// Подписка на события
controller.on('preset', (data) => {
  console.log('Preset changed:', data);
});

// Получение состояния
const state = controller.getState();
console.log('State:', state);

// Сброс
controller.reset();

// Уничтожение
controller.destroy();
*/
