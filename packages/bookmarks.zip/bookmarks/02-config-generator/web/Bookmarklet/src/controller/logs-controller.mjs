// web/Bookmarklet/src/controller/logs-controller.mjs
// 100% СИМВОЛЫ — полная изоляция и безопасность
// Контроллер Logs панели
// Версия: 2.1.9

// ============================================================
// 1. ИМПОРТЫ
// ============================================================

import { PanelController, PANEL_CONTROLLER_SYMBOLS } from './panel-controller.mjs';
import { LOGS_ACTIONS } from '../action/logs-actions.mjs';
import LOGS_TEMPLATE from '../template/logs-template.mjs';
import { LOGS_ACTIONS_SYMBOLS } from '../action/logs-actions.mjs';

// ============================================================
// 2. ПРИВАТНЫЕ СИМВОЛЫ (100% изоляция)
// ============================================================

const PRIVATE = {
  // Основные символы контроллера
  ID: Symbol('logs-controller.id'),
  NAME: Symbol('logs-controller.name'),
  TYPE: Symbol('logs-controller.type'),
  VERSION: Symbol('logs-controller.version'),

  // Символы состояния
  INITIALIZED: Symbol('logs-controller.initialized'),
  DESTROYED: Symbol('logs-controller.destroyed'),
  IS_HOOKED: Symbol('logs-controller.isHooked'),
  IS_PAUSED: Symbol('logs-controller.isPaused'),
  IS_FOLLOWING: Symbol('logs-controller.isFollowing'),
  LOG_COUNT: Symbol('logs-controller.logCount'),
  LOG_LIMIT: Symbol('logs-controller.logLimit'),

  // Символы DOM
  PANEL: Symbol('logs-controller.panel'),
  CONSOLE_EL: Symbol('logs-controller.consoleEl'),
  FILTER_INPUT: Symbol('logs-controller.filterInput'),
  LEVEL_SELECT: Symbol('logs-controller.levelSelect'),
  PAUSE_BTN: Symbol('logs-controller.pauseBtn'),
  CLEAR_BTN: Symbol('logs-controller.clearBtn'),
  EXPORT_BTN: Symbol('logs-controller.exportBtn'),
  FOLLOW_BTN: Symbol('logs-controller.followBtn'),
  STATUS_EL: Symbol('logs-controller.statusEl'),
  TOTAL_EL: Symbol('logs-controller.totalEl'),
  ERRORS_EL: Symbol('logs-controller.errorsEl'),
  WARNINGS_EL: Symbol('logs-controller.warningsEl'),
  BADGE_EL: Symbol('logs-controller.badgeEl'),

  // Символы данных
  LOGS: Symbol('logs-controller.logs'),
  ACTIONS: Symbol('logs-controller.actions'),
  TEMPLATE: Symbol('logs-controller.template'),
  CACHE: Symbol('logs-controller.cache'),
  METADATA: Symbol('logs-controller.metadata'),
  CONTEXT: Symbol('logs-controller.context'),
  HISTORY: Symbol('logs-controller.history'),

  // Символы таймеров
  TIMERS: Symbol('logs-controller.timers'),
  RAF_ID: Symbol('logs-controller.rafId'),
  FLUSH_TIMER: Symbol('logs-controller.flushTimer'),
  AUTO_SCROLL_TIMER: Symbol('logs-controller.autoScrollTimer'),

  // Символы логгера
  LOGGER: Symbol('logs-controller.logger'),
  LOG_HISTORY: Symbol('logs-controller.logHistory'),

  // Символы событий
  EVENT_HANDLERS: Symbol('logs-controller.eventHandlers'),
  ON_LOG_ADDED: Symbol('logs-controller.onLogAdded'),
  ON_LOGS_CLEARED: Symbol('logs-controller.onLogsCleared'),
  ON_PAUSE_TOGGLE: Symbol('logs-controller.onPauseToggle'),
  ON_FOLLOW_TOGGLE: Symbol('logs-controller.onFollowToggle'),
  ON_EXPORT: Symbol('logs-controller.onExport'),

  // Символы методов (приватные)
  INIT: Symbol('logs-controller.init'),
  SETUP_UI: Symbol('logs-controller.setupUI'),
  SETUP_HANDLERS: Symbol('logs-controller.setupHandlers'),
  UPDATE_UI: Symbol('logs-controller.updateUI'),
  UPDATE_STATS: Symbol('logs-controller.updateStats'),
  RENDER_LOGS: Symbol('logs-controller.renderLogs'),
  ADD_LOG: Symbol('logs-controller.addLog'),
  CLEAR_LOGS: Symbol('logs-controller.clearLogs'),
  EXPORT_LOGS: Symbol('logs-controller.exportLogs'),
  TOGGLE_PAUSE: Symbol('logs-controller.togglePause'),
  TOGGLE_FOLLOW: Symbol('logs-controller.toggleFollow'),
  HOOK_CONSOLE: Symbol('logs-controller.hookConsole'),
  UNHOOK_CONSOLE: Symbol('logs-controller.unhookConsole'),
  FLUSH_LOGS: Symbol('logs-controller.flushLogs'),
  AUTO_SCROLL: Symbol('logs-controller.autoScroll'),
  GET_LOGS: Symbol('logs-controller.getLogs'),
  GET_STATE: Symbol('logs-controller.getState'),
  GET_STATS: Symbol('logs-controller.getStats'),
  RESET: Symbol('logs-controller.reset'),
  DESTROY: Symbol('logs-controller.destroy'),
  EMIT: Symbol('logs-controller.emit'),
  ON: Symbol('logs-controller.on'),
  OFF: Symbol('logs-controller.off'),

  // Символы конфигурации
  CONFIG: Symbol('logs-controller.config'),
  DEFAULTS: Symbol('logs-controller.defaults'),
  LIMITS: Symbol('logs-controller.limits'),
};

// ============================================================
// 3. ПУБЛИЧНЫЕ СИМВОЛЫ (доступны через Symbol.for)
// ============================================================

const PUBLIC = {
  API: Symbol.for('logs-controller.api'),
  STATE: Symbol.for('logs-controller.state'),
  CONFIG: Symbol.for('logs-controller.config'),
  LOGGER: Symbol.for('logs-controller.logger'),
  EVENTS: Symbol.for('logs-controller.events'),
  INSTANCE: Symbol.for('logs-controller.instance'),
  ACTIONS: Symbol.for('logs-controller.actions'),
};

// ============================================================
// 4. КОНФИГУРАЦИЯ (100% СИМВОЛЫ)
// ============================================================

const CONFIG_SYMBOLS = {
  MAX_LOGS: Symbol('config.maxLogs'),
  DEFAULT_LEVEL: Symbol('config.defaultLevel'),
  FLUSH_INTERVAL: Symbol('config.flushInterval'),
  AUTO_SCROLL_DELAY: Symbol('config.autoScrollDelay'),
  STORAGE_KEY: Symbol('config.storageKey'),
  LOG_LEVELS: Symbol('config.logLevels'),
};

const CONFIG = {
  [CONFIG_SYMBOLS.MAX_LOGS]: 1000,
  [CONFIG_SYMBOLS.DEFAULT_LEVEL]: 'info',
  [CONFIG_SYMBOLS.FLUSH_INTERVAL]: 100,
  [CONFIG_SYMBOLS.AUTO_SCROLL_DELAY]: 50,
  [CONFIG_SYMBOLS.STORAGE_KEY]: 'logs-controller-state',
  [CONFIG_SYMBOLS.LOG_LEVELS]: ['debug', 'info', 'warn', 'error', 'success'],
};

// ============================================================
// 5. ЛОГГЕР (100% СИМВОЛЫ)
// ============================================================

const LOGGER_SYMBOLS = {
  HISTORY: Symbol('logger.history'),
  MAX_HISTORY: Symbol('logger.maxHistory'),
  DEBUG: Symbol('logger.debug'),
  INSTANCE_ID: Symbol('logger.instanceId'),
  LEVEL: Symbol('logger.level'),
  COLORS: Symbol('logger.colors'),
  TIMESTAMP: Symbol('logger.timestamp'),
  OUTPUT: Symbol('logger.output'),
};

function createLogsControllerLogger(debug = true, instanceId = 'LogsController') {
  const loggerState = {
    [LOGGER_SYMBOLS.HISTORY]: [],
    [LOGGER_SYMBOLS.MAX_HISTORY]: 200,
    [LOGGER_SYMBOLS.DEBUG]: debug,
    [LOGGER_SYMBOLS.INSTANCE_ID]: instanceId,
    [LOGGER_SYMBOLS.LEVEL]: 'info',
    [LOGGER_SYMBOLS.COLORS]: true,
    [LOGGER_SYMBOLS.TIMESTAMP]: true,
    [LOGGER_SYMBOLS.OUTPUT]: console,
  };

  const logMethod = function (level, message, data = null) {
    if (!this[LOGGER_SYMBOLS.DEBUG] && level !== 'error') {
      return;
    }

    const timestamp = this[LOGGER_SYMBOLS.TIMESTAMP]
      ? `[${new Date().toISOString().slice(11, 23)}]`
      : '';
    const prefix = `${timestamp} [${this[LOGGER_SYMBOLS.INSTANCE_ID]}]`;
    const output = this[LOGGER_SYMBOLS.OUTPUT];

    this[LOGGER_SYMBOLS.HISTORY].push({ timestamp, level, message, data });
    if (this[LOGGER_SYMBOLS.HISTORY].length > this[LOGGER_SYMBOLS.MAX_HISTORY]) {
      this[LOGGER_SYMBOLS.HISTORY].shift();
    }

    const styles = this[LOGGER_SYMBOLS.COLORS]
      ? {
          error: 'color: #ff6b6b; font-weight: bold;',
          warn: 'color: #fdcb6e; font-weight: bold;',
          info: 'color: #74b9ff; font-weight: bold;',
          debug: 'color: #a29bfe;',
          success: 'color: #00b894; font-weight: bold;',
        }
      : {};

    const style = styles[level] || styles.info;

    if (data !== null && data !== undefined) {
      if (typeof data === 'object') {
        output.log(`%c${prefix} ${message}`, style, data);
      } else {
        output.log(`%c${prefix} ${message}`, style, data);
      }
    } else {
      output.log(`%c${prefix} ${message}`, style);
    }
  };

  const boundLog = logMethod.bind(loggerState);

  const logger = {
    error: (msg, d) => boundLog('error', `❌ ${msg}`, d),
    warn: (msg, d) => boundLog('warn', `⚠️ ${msg}`, d),
    info: (msg, d) => boundLog('info', `ℹ️ ${msg}`, d),
    debug: (msg, d) => boundLog('debug', `🔍 ${msg}`, d),
    success: (msg, d) => boundLog('info', `✅ ${msg}`, d),

    header: title => {
      const output = loggerState[LOGGER_SYMBOLS.OUTPUT];
      output.log('%c' + '═'.repeat(70), 'color: #636e72;');
      output.log(
        '%c  📦 ' + title,
        'background: #1a1a2e; color: #fff; padding: 4px 12px; border-radius: 4px; font-weight: bold;'
      );
      output.log('%c' + '═'.repeat(70), 'color: #636e72;');
    },

    separator: () => {
      const output = loggerState[LOGGER_SYMBOLS.OUTPUT];
      output.log('%c' + '─'.repeat(70), 'color: #636e72;');
    },

    getHistory: () => [...loggerState[LOGGER_SYMBOLS.HISTORY]],
    clearHistory: () => {
      loggerState[LOGGER_SYMBOLS.HISTORY] = [];
      return logger;
    },
    setDebug: enabled => {
      loggerState[LOGGER_SYMBOLS.DEBUG] = enabled;
      return logger;
    },
    setLevel: level => {
      loggerState[LOGGER_SYMBOLS.LEVEL] = level;
      return logger;
    },
    getLevel: () => loggerState[LOGGER_SYMBOLS.LEVEL],
    setOutput: output => {
      loggerState[LOGGER_SYMBOLS.OUTPUT] = output;
      return logger;
    },
  };

  return logger;
}

// ============================================================
// 6. ВАЛИДАТОР (100% СИМВОЛЫ)
// ============================================================

const VALIDATOR_SYMBOLS = {
  IS_VALID_LOG: Symbol('validator.isValidLog'),
  IS_VALID_LEVEL: Symbol('validator.isValidLevel'),
  IS_VALID_MESSAGE: Symbol('validator.isValidMessage'),
  IS_VALID_PANEL: Symbol('validator.isValidPanel'),
  IS_VALID_ELEMENT: Symbol('validator.isValidElement'),
  SANITIZE: Symbol('validator.sanitize'),
  CHECK_LIMITS: Symbol('validator.checkLimits'),
};

const VALIDATOR = {
  [VALIDATOR_SYMBOLS.IS_VALID_LOG]: entry => {
    return (
      entry &&
      typeof entry === 'object' &&
      entry.level &&
      typeof entry.message === 'string' &&
      entry.timestamp instanceof Date
    );
  },

  [VALIDATOR_SYMBOLS.IS_VALID_LEVEL]: level => {
    const levels = CONFIG[CONFIG_SYMBOLS.LOG_LEVELS];
    return level && typeof level === 'string' && levels.includes(level);
  },

  [VALIDATOR_SYMBOLS.IS_VALID_MESSAGE]: message => {
    return message !== undefined && message !== null && typeof message !== 'function';
  },

  [VALIDATOR_SYMBOLS.IS_VALID_PANEL]: panel => {
    return panel && typeof panel === 'object' && panel instanceof HTMLElement;
  },

  [VALIDATOR_SYMBOLS.IS_VALID_ELEMENT]: el => {
    return el && typeof el === 'object' && el instanceof HTMLElement;
  },

  [VALIDATOR_SYMBOLS.SANITIZE]: value => {
    if (value === null || value === undefined) return null;
    if (typeof value === 'string') {
      return value.replace(/[<>]/g, '').trim();
    }
    if (typeof value === 'object') {
      try {
        return JSON.parse(JSON.stringify(value));
      } catch {
        return null;
      }
    }
    return value;
  },

  [VALIDATOR_SYMBOLS.CHECK_LIMITS]: logs => {
    const max = CONFIG[CONFIG_SYMBOLS.MAX_LOGS];
    if (logs && Array.isArray(logs) && logs.length > max) {
      return logs.slice(-Math.floor(max * 0.8));
    }
    return logs;
  },
};

// ============================================================
// 7. ОСНОВНОЙ КЛАСС LOGS CONTROLLER (100% СИМВОЛЫ)
// ============================================================

class LogsController extends PanelController {
  constructor(options = {}) {
    // Вызов конструктора родителя
    super(options);

    // ============================================================
    // 7.1 ИНИЦИАЛИЗАЦИЯ ПРИВАТНЫХ СВОЙСТВ
    // ============================================================

    // Основные свойства
    this[PRIVATE.ID] =
      options.id || 'logs-' + Date.now() + '-' + Math.random().toString(36).substr(2, 4);
    this[PRIVATE.NAME] = options.name || 'Logs Control';
    this[PRIVATE.TYPE] = options.type || 'logs';
    this[PRIVATE.VERSION] = options.version || '2.1.9';

    // Состояние
    this[PRIVATE.INITIALIZED] = false;
    this[PRIVATE.DESTROYED] = false;
    this[PRIVATE.IS_HOOKED] = false;
    this[PRIVATE.IS_PAUSED] = false;
    this[PRIVATE.IS_FOLLOWING] = true;
    this[PRIVATE.LOG_COUNT] = 0;
    this[PRIVATE.LOG_LIMIT] = CONFIG[CONFIG_SYMBOLS.MAX_LOGS];

    // DOM элементы
    this[PRIVATE.PANEL] = options.panel || null;
    this[PRIVATE.CONSOLE_EL] = null;
    this[PRIVATE.FILTER_INPUT] = null;
    this[PRIVATE.LEVEL_SELECT] = null;
    this[PRIVATE.PAUSE_BTN] = null;
    this[PRIVATE.CLEAR_BTN] = null;
    this[PRIVATE.EXPORT_BTN] = null;
    this[PRIVATE.FOLLOW_BTN] = null;
    this[PRIVATE.STATUS_EL] = null;
    this[PRIVATE.TOTAL_EL] = null;
    this[PRIVATE.ERRORS_EL] = null;
    this[PRIVATE.WARNINGS_EL] = null;
    this[PRIVATE.BADGE_EL] = null;

    // Данные
    this[PRIVATE.LOGS] = [];
    this[PRIVATE.ACTIONS] = options.actions || LOGS_ACTIONS;
    this[PRIVATE.TEMPLATE] = options.template || LOGS_TEMPLATE;
    this[PRIVATE.CACHE] = new Map();
    this[PRIVATE.METADATA] = {
      created: Date.now(),
      lastAccess: Date.now(),
      lastUpdate: Date.now(),
      totalAdded: 0,
      totalCleared: 0,
      totalExported: 0,
    };
    this[PRIVATE.CONTEXT] = {
      url: typeof window !== 'undefined' ? window.location.href : '',
      title: typeof window !== 'undefined' ? document.title : '',
      userAgent: typeof navigator !== 'undefined' ? navigator.userAgent : '',
    };
    this[PRIVATE.HISTORY] = [];

    // Таймеры
    this[PRIVATE.TIMERS] = new Map();
    this[PRIVATE.RAF_ID] = null;
    this[PRIVATE.FLUSH_TIMER] = null;
    this[PRIVATE.AUTO_SCROLL_TIMER] = null;

    // Логгер
    this[PRIVATE.LOGGER] =
      options.logger || createLogsControllerLogger(options.debug !== false, 'LogsController');
    this[PRIVATE.LOG_HISTORY] = [];

    // События
    this[PRIVATE.EVENT_HANDLERS] = new Map();

    // Конфигурация
    this[PRIVATE.CONFIG] = {
      ...CONFIG,
      ...options.config,
    };

    // ============================================================
    // 7.2 ЗАГРУЗКА СОХРАНЁННОГО СОСТОЯНИЯ
    // ============================================================

    this._loadState();

    // ============================================================
    // 7.3 ИНИЦИАЛИЗАЦИЯ
    // ============================================================

    this[PRIVATE.INIT]();

    // ============================================================
    // 7.4 ЭКСПОРТ СИМВОЛОВ
    // ============================================================

    this._exportSymbols();

    // ============================================================
    // 7.5 ЛОГИРОВАНИЕ
    // ============================================================

    const logger = this[PRIVATE.LOGGER];
    logger.header('СОЗДАНИЕ LOGS CONTROLLER (100% СИМВОЛЫ)');
    logger.info(`📦 Версия: ${this[PRIVATE.VERSION]}`);
    logger.info(`📌 ID: ${this[PRIVATE.ID]}`);
    logger.info(`📌 Имя: ${this[PRIVATE.NAME]}`);
    logger.info(`📌 Тип: ${this[PRIVATE.TYPE]}`);
    logger.info(`📌 Лимит логов: ${this[PRIVATE.LOG_LIMIT]}`);
    logger.info(`📌 Слежение: ${this[PRIVATE.IS_FOLLOWING] ? '✅' : '❌'}`);
    logger.info(`📌 Пауза: ${this[PRIVATE.IS_PAUSED] ? '✅' : '❌'}`);
    logger.success('✅ LogsController создан');
    logger.header('ГОТОВ');
  }

  // ============================================================
  // 8. ★★★ ИНИЦИАЛИЗАЦИЯ ★★★
  // ============================================================

  [PRIVATE.INIT]() {
    const logger = this[PRIVATE.LOGGER];
    logger.info('🔧 Инициализация LogsController...');

    // Настройка UI
    this[PRIVATE.SETUP_UI]();

    // Настройка обработчиков
    this[PRIVATE.SETUP_HANDLERS]();

    // Установка перехвата console
    this[PRIVATE.HOOK_CONSOLE]();

    // Приветственные логи
    setTimeout(() => {
      this[PRIVATE.ADD_LOG]('info', '✅ Панель логов запущена');
      this[PRIVATE.ADD_LOG]('info', '📝 Все console.log() теперь отображаются здесь');
      this[PRIVATE.ADD_LOG]('debug', '🔍 Уровень логирования: info');
      this[PRIVATE.ADD_LOG]('success', '🎯 Слежение: включено');
    }, 100);

    this[PRIVATE.INITIALIZED] = true;
    logger.success('✅ Инициализация завершена');
  }

  // ============================================================
  // 9. ★★★ НАСТРОЙКА UI ★★★
  // ============================================================

  [PRIVATE.SETUP_UI]() {
    const logger = this[PRIVATE.LOGGER];
    const panel = this[PRIVATE.PANEL];

    if (!panel) {
      logger.warn('⚠️ Панель не найдена, создаём...');
      return;
    }

    logger.info('🎨 Настройка UI...');

    // Находим элементы
    this[PRIVATE.CONSOLE_EL] = panel.querySelector('#logs-console');
    this[PRIVATE.FILTER_INPUT] = panel.querySelector('#logs-filter');
    this[PRIVATE.LEVEL_SELECT] = panel.querySelector('#logs-level');
    this[PRIVATE.PAUSE_BTN] = panel.querySelector('#logs-pause-btn');
    this[PRIVATE.CLEAR_BTN] = panel.querySelector('#logs-clear-btn');
    this[PRIVATE.EXPORT_BTN] = panel.querySelector('#logs-export-btn');
    this[PRIVATE.FOLLOW_BTN] = panel.querySelector('#logs-follow-btn');
    this[PRIVATE.STATUS_EL] = panel.querySelector('#logs-status');
    this[PRIVATE.TOTAL_EL] = panel.querySelector('#logs-total');
    this[PRIVATE.ERRORS_EL] = panel.querySelector('#logs-errors');
    this[PRIVATE.WARNINGS_EL] = panel.querySelector('#logs-warnings');
    this[PRIVATE.BADGE_EL] = document.getElementById('panel-status-badge');

    // Проверяем наличие элементов
    const elements = {
      console: this[PRIVATE.CONSOLE_EL],
      filter: this[PRIVATE.FILTER_INPUT],
      level: this[PRIVATE.LEVEL_SELECT],
      pause: this[PRIVATE.PAUSE_BTN],
      clear: this[PRIVATE.CLEAR_BTN],
      export: this[PRIVATE.EXPORT_BTN],
      follow: this[PRIVATE.FOLLOW_BTN],
      status: this[PRIVATE.STATUS_EL],
      total: this[PRIVATE.TOTAL_EL],
      errors: this[PRIVATE.ERRORS_EL],
      warnings: this[PRIVATE.WARNINGS_EL],
      badge: this[PRIVATE.BADGE_EL],
    };

    let missing = 0;
    for (const [name, el] of Object.entries(elements)) {
      if (!el) {
        logger.debug(`  ⚠️ Элемент не найден: #logs-${name}`);
        missing++;
      }
    }

    if (missing > 0) {
      logger.warn(`⚠️ ${missing} элементов не найдены`);
    } else {
      logger.success('✅ Все элементы найдены');
    }

    // Начальный рендеринг
    this[PRIVATE.RENDER_LOGS]();
    this[PRIVATE.UPDATE_STATS]();

    // Устанавливаем начальное состояние кнопок
    if (this[PRIVATE.FOLLOW_BTN]) {
      this[PRIVATE.FOLLOW_BTN].textContent = '▶️ Следить';
      this[PRIVATE.FOLLOW_BTN].style.borderColor = 'rgba(0,184,148,0.3)';
      this[PRIVATE.FOLLOW_BTN].style.background = 'rgba(0,184,148,0.1)';
      this[PRIVATE.FOLLOW_BTN].style.color = '#00b894';
    }

    if (this[PRIVATE.PAUSE_BTN]) {
      this[PRIVATE.PAUSE_BTN].textContent = '⏸️ Пауза';
    }

    logger.success('✅ UI настроен');
  }

  // ============================================================
  // 10. ★★★ НАСТРОЙКА ОБРАБОТЧИКОВ ★★★
  // ============================================================

  [PRIVATE.SETUP_HANDLERS]() {
    const logger = this[PRIVATE.LOGGER];
    logger.info('👂 Настройка обработчиков...');

    // Фильтр
    if (this[PRIVATE.FILTER_INPUT]) {
      this[PRIVATE.FILTER_INPUT].addEventListener('input', () => {
        this[PRIVATE.RENDER_LOGS]();
        this[PRIVATE.EMIT]('filter', { value: this[PRIVATE.FILTER_INPUT].value });
      });
      logger.debug('✅ Фильтр настроен');
    }

    // Уровень
    if (this[PRIVATE.LEVEL_SELECT]) {
      this[PRIVATE.LEVEL_SELECT].addEventListener('change', () => {
        this[PRIVATE.RENDER_LOGS]();
        this[PRIVATE.EMIT]('levelChange', { value: this[PRIVATE.LEVEL_SELECT].value });
      });
      logger.debug('✅ Выбор уровня настроен');
    }

    // Пауза
    if (this[PRIVATE.PAUSE_BTN]) {
      this[PRIVATE.PAUSE_BTN].addEventListener('click', () => {
        this[PRIVATE.TOGGLE_PAUSE]();
      });
      logger.debug('✅ Кнопка паузы настроена');
    }

    // Очистка
    if (this[PRIVATE.CLEAR_BTN]) {
      this[PRIVATE.CLEAR_BTN].addEventListener('click', () => {
        this[PRIVATE.CLEAR_LOGS]();
      });
      logger.debug('✅ Кнопка очистки настроена');
    }

    // Экспорт
    if (this[PRIVATE.EXPORT_BTN]) {
      this[PRIVATE.EXPORT_BTN].addEventListener('click', () => {
        this[PRIVATE.EXPORT_LOGS]();
      });
      logger.debug('✅ Кнопка экспорта настроена');
    }

    // Слежение
    if (this[PRIVATE.FOLLOW_BTN]) {
      this[PRIVATE.FOLLOW_BTN].addEventListener('click', () => {
        this[PRIVATE.TOGGLE_FOLLOW]();
      });
      logger.debug('✅ Кнопка слежения настроена');
    }

    // Обработка изменения размера консоли
    if (this[PRIVATE.CONSOLE_EL]) {
      const resizeObserver = new ResizeObserver(() => {
        if (this[PRIVATE.IS_FOLLOWING]) {
          this[PRIVATE.AUTO_SCROLL]();
        }
      });
      resizeObserver.observe(this[PRIVATE.CONSOLE_EL]);

      // Сохраняем для очистки
      this[PRIVATE.TIMERS].set('resizeObserver', resizeObserver);
      logger.debug('✅ ResizeObserver настроен');
    }

    // Обработка клика по бейджу
    if (this[PRIVATE.BADGE_EL]) {
      this[PRIVATE.BADGE_EL].addEventListener('click', () => {
        this[PRIVATE.TOGGLE_PAUSE]();
      });
      logger.debug('✅ Бейдж настроен');
    }

    logger.success('✅ Все обработчики настроены');
  }

  // ============================================================
  // 11. ★★★ ДОБАВЛЕНИЕ ЛОГА ★★★
  // ============================================================

  [PRIVATE.ADD_LOG](level, ...args) {
    if (this[PRIVATE.IS_PAUSED]) {
      this[PRIVATE.LOGGER].debug('⏸️ Пауза, лог не добавлен');
      return null;
    }

    const logger = this[PRIVATE.LOGGER];

    // Форматируем сообщение
    let message = '';
    if (args.length > 0) {
      message = args
        .map(a => {
          if (a === null) return 'null';
          if (a === undefined) return 'undefined';
          if (typeof a === 'object') {
            try {
              return JSON.stringify(a);
            } catch {
              return '[Object]';
            }
          }
          return String(a);
        })
        .join(' ');
    }

    if (!message) {
      message = '(empty)';
    }

    // Создаём запись
    const entry = {
      id: Date.now() + '-' + Math.random().toString(36).substr(2, 4),
      timestamp: new Date(),
      level: VALIDATOR[VALIDATOR_SYMBOLS.IS_VALID_LEVEL](level)
        ? level
        : CONFIG[CONFIG_SYMBOLS.DEFAULT_LEVEL],
      message: VALIDATOR[VALIDATOR_SYMBOLS.SANITIZE](message),
      raw: args,
    };

    // Добавляем в логи
    this[PRIVATE.LOGS].push(entry);
    this[PRIVATE.LOG_COUNT]++;
    this[PRIVATE.METADATA].totalAdded++;
    this[PRIVATE.METADATA].lastUpdate = Date.now();

    // Ограничиваем количество
    if (this[PRIVATE.LOGS].length > this[PRIVATE.LOG_LIMIT]) {
      this[PRIVATE.LOGS] = this[PRIVATE.LOGS].slice(-Math.floor(this[PRIVATE.LOG_LIMIT] * 0.8));
    }

    // Обновляем UI
    this[PRIVATE.UPDATE_STATS]();

    // Буферизация рендеринга
    if (this[PRIVATE.FLUSH_TIMER]) {
      clearTimeout(this[PRIVATE.FLUSH_TIMER]);
    }

    this[PRIVATE.FLUSH_TIMER] = setTimeout(() => {
      this[PRIVATE.RENDER_LOGS]();
      if (this[PRIVATE.IS_FOLLOWING]) {
        this[PRIVATE.AUTO_SCROLL]();
      }
      this[PRIVATE.FLUSH_TIMER] = null;
    }, CONFIG[CONFIG_SYMBOLS.FLUSH_INTERVAL]);

    // Сохраняем состояние
    this._saveState();

    // Событие
    this[PRIVATE.EMIT]('logAdded', { entry, count: this[PRIVATE.LOGS].length });

    return entry;
  }

  // ============================================================
  // 12. ★★★ РЕНДЕРИНГ ЛОГОВ ★★★
  // ============================================================

  [PRIVATE.RENDER_LOGS]() {
    const consoleEl = this[PRIVATE.CONSOLE_EL];
    if (!consoleEl) return;

    const logger = this[PRIVATE.LOGGER];
    logger.debug('🎨 Рендеринг логов...');

    // Получаем фильтры
    const filter = this[PRIVATE.FILTER_INPUT]?.value?.toLowerCase() || '';
    const levelFilter = this[PRIVATE.LEVEL_SELECT]?.value || 'all';

    // Фильтруем логи
    let filtered = this[PRIVATE.LOGS];
    if (filter) {
      filtered = filtered.filter(e => e.message.toLowerCase().includes(filter));
    }
    if (levelFilter !== 'all') {
      filtered = filtered.filter(e => e.level === levelFilter);
    }

    // Ограничиваем для производительности
    const maxDisplay = 500;
    if (filtered.length > maxDisplay) {
      filtered = filtered.slice(-maxDisplay);
    }

    // Рендерим
    if (filtered.length === 0) {
      const emptyMsg = filter
        ? '📭 Нет логов по вашему фильтру'
        : '📭 Логи будут отображаться здесь...';
      consoleEl.innerHTML = `<div class="logs-empty" style="color:#8899bb;text-align:center;padding:20px;font-style:italic;">${emptyMsg}</div>`;
      return;
    }

    const entries = this[PRIVATE.IS_FOLLOWING] ? filtered : filtered.slice(-100);

    let html = '';
    for (const entry of entries) {
      const time = entry.timestamp.toLocaleTimeString();
      const levelLabel = entry.level.toUpperCase();
      const color = this._getLevelColor(entry.level);
      const message = this._escapeHtml(entry.message);

      html += `
        <div class="logs-entry" style="
          padding:2px 0;
          border-bottom:1px solid rgba(255,255,255,0.03);
          display:flex;
          gap:6px;
          align-items:flex-start;
        ">
          <span class="logs-time" style="
            color:#8899bb;
            font-size:9px;
            min-width:60px;
            flex-shrink:0;
          ">${time}</span>
          <span class="logs-level ${entry.level}" style="
            font-size:9px;
            padding:0 5px;
            border-radius:3px;
            font-weight:600;
            flex-shrink:0;
            color:${color};
          ">${levelLabel}</span>
          <span class="logs-message" style="
            color:#dfe6e9;
            word-break:break-all;
            flex:1;
          ">${message}</span>
        </div>
      `;
    }

    consoleEl.innerHTML = html;

    // Обновляем статус
    if (this[PRIVATE.STATUS_EL]) {
      const count = filtered.length;
      const total = this[PRIVATE.LOGS].length;
      this[PRIVATE.STATUS_EL].textContent = `📊 Показано ${count} из ${total}`;
    }

    logger.debug(`✅ Рендеринг завершён (${filtered.length} записей)`);
  }

  // ============================================================
  // 13. ★★★ ОБНОВЛЕНИЕ СТАТИСТИКИ ★★★
  // ============================================================

  [PRIVATE.UPDATE_STATS]() {
    const logger = this[PRIVATE.LOGGER];
    const total = this[PRIVATE.LOGS].length;
    const errors = this[PRIVATE.LOGS].filter(e => e.level === 'error').length;
    const warnings = this[PRIVATE.LOGS].filter(e => e.level === 'warn').length;

    if (this[PRIVATE.TOTAL_EL]) {
      this[PRIVATE.TOTAL_EL].textContent = total;
    }

    if (this[PRIVATE.ERRORS_EL]) {
      this[PRIVATE.ERRORS_EL].textContent = errors;
    }

    if (this[PRIVATE.WARNINGS_EL]) {
      this[PRIVATE.WARNINGS_EL].textContent = warnings;
    }

    if (this[PRIVATE.STATUS_EL]) {
      const status = this[PRIVATE.IS_PAUSED] ? '⏸️ Пауза' : '▶️ Активен';
      this[PRIVATE.STATUS_EL].textContent = status;
      this[PRIVATE.STATUS_EL].style.color = this[PRIVATE.IS_PAUSED] ? '#fdcb6e' : '#00b894';
    }

    if (this[PRIVATE.BADGE_EL]) {
      const status = this[PRIVATE.IS_PAUSED] ? '⏸️ Пауза' : '▶️ Активен';
      this[PRIVATE.BADGE_EL].textContent = `📋 ${total}`;
      this[PRIVATE.BADGE_EL].style.background = this[PRIVATE.IS_PAUSED]
        ? 'rgba(253,203,110,0.15)'
        : 'rgba(0,184,148,0.15)';
      this[PRIVATE.BADGE_EL].style.color = this[PRIVATE.IS_PAUSED] ? '#fdcb6e' : '#00b894';
    }

    // Событие
    this[PRIVATE.EMIT]('statsUpdate', {
      total,
      errors,
      warnings,
      isPaused: this[PRIVATE.IS_PAUSED],
      isFollowing: this[PRIVATE.IS_FOLLOWING],
    });

    logger.debug(`📊 Статистика: ${total} логов, ${errors} ошибок, ${warnings} предупреждений`);
  }

  // ============================================================
  // 14. ★★★ УПРАВЛЕНИЕ ПАУЗОЙ ★★★
  // ============================================================

  [PRIVATE.TOGGLE_PAUSE]() {
    this[PRIVATE.IS_PAUSED] = !this[PRIVATE.IS_PAUSED];

    if (this[PRIVATE.PAUSE_BTN]) {
      this[PRIVATE.PAUSE_BTN].textContent = this[PRIVATE.IS_PAUSED] ? '▶️ Возобновить' : '⏸️ Пауза';
    }

    if (this[PRIVATE.BADGE_EL]) {
      const status = this[PRIVATE.IS_PAUSED] ? '⏸️ Пауза' : '▶️ Активен';
      this[PRIVATE.BADGE_EL].textContent = status;
      this[PRIVATE.BADGE_EL].style.background = this[PRIVATE.IS_PAUSED]
        ? 'rgba(253,203,110,0.15)'
        : 'rgba(0,184,148,0.15)';
      this[PRIVATE.BADGE_EL].style.color = this[PRIVATE.IS_PAUSED] ? '#fdcb6e' : '#00b894';
    }

    this[PRIVATE.UPDATE_STATS]();
    this._saveState();

    this[PRIVATE.EMIT]('pauseToggle', { isPaused: this[PRIVATE.IS_PAUSED] });

    const logger = this[PRIVATE.LOGGER];
    logger.info(`⏸️ Пауза: ${this[PRIVATE.IS_PAUSED] ? 'включена' : 'выключена'}`);

    return this[PRIVATE.IS_PAUSED];
  }

  // ============================================================
  // 15. ★★★ УПРАВЛЕНИЕ СЛЕЖЕНИЕМ ★★★
  // ============================================================

  [PRIVATE.TOGGLE_FOLLOW]() {
    this[PRIVATE.IS_FOLLOWING] = !this[PRIVATE.IS_FOLLOWING];

    if (this[PRIVATE.FOLLOW_BTN]) {
      this[PRIVATE.FOLLOW_BTN].textContent = this[PRIVATE.IS_FOLLOWING]
        ? '▶️ Следить'
        : '⏹️ Не следить';
      this[PRIVATE.FOLLOW_BTN].style.borderColor = this[PRIVATE.IS_FOLLOWING]
        ? 'rgba(0,184,148,0.3)'
        : 'rgba(255,255,255,0.1)';
      this[PRIVATE.FOLLOW_BTN].style.background = this[PRIVATE.IS_FOLLOWING]
        ? 'rgba(0,184,148,0.1)'
        : 'rgba(255,255,255,0.05)';
      this[PRIVATE.FOLLOW_BTN].style.color = this[PRIVATE.IS_FOLLOWING] ? '#00b894' : '#8899bb';
    }

    if (this[PRIVATE.IS_FOLLOWING]) {
      this[PRIVATE.AUTO_SCROLL]();
    }

    this._saveState();

    this[PRIVATE.EMIT]('followToggle', { isFollowing: this[PRIVATE.IS_FOLLOWING] });

    const logger = this[PRIVATE.LOGGER];
    logger.info(`📌 Слежение: ${this[PRIVATE.IS_FOLLOWING] ? 'включено' : 'выключено'}`);

    return this[PRIVATE.IS_FOLLOWING];
  }

  // ============================================================
  // 16. ★★★ ОЧИСТКА ЛОГОВ ★★★
  // ============================================================

  [PRIVATE.CLEAR_LOGS]() {
    const logger = this[PRIVATE.LOGGER];
    const count = this[PRIVATE.LOGS].length;

    this[PRIVATE.LOGS] = [];
    this[PRIVATE.LOG_COUNT] = 0;
    this[PRIVATE.METADATA].totalCleared += count;
    this[PRIVATE.METADATA].lastUpdate = Date.now();

    this[PRIVATE.RENDER_LOGS]();
    this[PRIVATE.UPDATE_STATS]();
    this._saveState();

    this[PRIVATE.EMIT]('logsCleared', { count });

    logger.info(`🗑️ Очищено ${count} логов`);
    return count;
  }

  // ============================================================
  // 17. ★★★ ЭКСПОРТ ЛОГОВ ★★★
  // ============================================================

  [PRIVATE.EXPORT_LOGS]() {
    const logger = this[PRIVATE.LOGGER];
    const data = JSON.stringify(this[PRIVATE.LOGS], null, 2);

    try {
      const blob = new Blob([data], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `logs-${new Date().toISOString().slice(0, 19).replace(/[:.]/g, '-')}.json`;
      a.click();
      URL.revokeObjectURL(url);

      this[PRIVATE.METADATA].totalExported++;
      this._saveState();

      this[PRIVATE.EMIT]('logsExported', { count: this[PRIVATE.LOGS].length });

      logger.success(`📥 Экспортировано ${this[PRIVATE.LOGS].length} записей`);
      return true;
    } catch (error) {
      logger.error(`❌ Ошибка экспорта: ${error.message}`);
      return false;
    }
  }

  // ============================================================
  // 18. ★★★ ПЕРЕХВАТ CONSOLE ★★★
  // ============================================================

  [PRIVATE.HOOK_CONSOLE]() {
    if (this[PRIVATE.IS_HOOKED]) {
      this[PRIVATE.LOGGER].debug('ℹ️ Перехват уже установлен');
      return;
    }

    const logger = this[PRIVATE.LOGGER];
    logger.info('🔧 Установка перехвата console...');

    // Сохраняем оригинальные методы
    const originalLog = console.log;
    const originalDebug = console.debug;
    const originalInfo = console.info;
    const originalWarn = console.warn;
    const originalError = console.error;

    // Ссылка на контроллер
    const self = this;

    // Переопределяем методы
    console.log = function (...args) {
      originalLog.apply(console, args);
      self[PRIVATE.ADD_LOG]('info', ...args);
    };

    console.debug = function (...args) {
      originalDebug.apply(console, args);
      self[PRIVATE.ADD_LOG]('debug', ...args);
    };

    console.info = function (...args) {
      originalInfo.apply(console, args);
      self[PRIVATE.ADD_LOG]('info', ...args);
    };

    console.warn = function (...args) {
      originalWarn.apply(console, args);
      self[PRIVATE.ADD_LOG]('warn', ...args);
    };

    console.error = function (...args) {
      originalError.apply(console, args);
      self[PRIVATE.ADD_LOG]('error', ...args);
    };

    // Сохраняем оригиналы для восстановления
    this[PRIVATE.CACHE].set('originalConsole', {
      log: originalLog,
      debug: originalDebug,
      info: originalInfo,
      warn: originalWarn,
      error: originalError,
    });

    this[PRIVATE.IS_HOOKED] = true;
    this._saveState();

    this[PRIVATE.EMIT]('consoleHooked', { hooked: true });

    logger.success('✅ Перехват console установлен');
  }

  // ============================================================
  // 19. ★★★ ОТКЛЮЧЕНИЕ ПЕРЕХВАТА ★★★
  // ============================================================

  [PRIVATE.UNHOOK_CONSOLE]() {
    if (!this[PRIVATE.IS_HOOKED]) {
      this[PRIVATE.LOGGER].debug('ℹ️ Перехват не установлен');
      return;
    }

    const logger = this[PRIVATE.LOGGER];
    logger.info('🔧 Отключение перехвата console...');

    const originals = this[PRIVATE.CACHE].get('originalConsole');
    if (originals) {
      console.log = originals.log;
      console.debug = originals.debug;
      console.info = originals.info;
      console.warn = originals.warn;
      console.error = originals.error;
    }

    this[PRIVATE.IS_HOOKED] = false;
    this[PRIVATE.CACHE].delete('originalConsole');
    this._saveState();

    this[PRIVATE.EMIT]('consoleHooked', { hooked: false });

    logger.success('✅ Перехват console отключен');
  }

  // ============================================================
  // 20. ★★★ АВТО-СКРОЛЛ ★★★
  // ============================================================

  [PRIVATE.AUTO_SCROLL]() {
    const consoleEl = this[PRIVATE.CONSOLE_EL];
    if (!consoleEl) return;

    if (this[PRIVATE.AUTO_SCROLL_TIMER]) {
      clearTimeout(this[PRIVATE.AUTO_SCROLL_TIMER]);
    }

    this[PRIVATE.AUTO_SCROLL_TIMER] = setTimeout(() => {
      consoleEl.scrollTop = consoleEl.scrollHeight;
      this[PRIVATE.AUTO_SCROLL_TIMER] = null;
    }, CONFIG[CONFIG_SYMBOLS.AUTO_SCROLL_DELAY]);
  }

  // ============================================================
  // 21. ★★★ ВСПОМОГАТЕЛЬНЫЕ МЕТОДЫ ★★★
  // ============================================================

  _getLevelColor(level) {
    const colors = {
      debug: '#667eea',
      info: '#74b9ff',
      warn: '#fdcb6e',
      error: '#ff6b6b',
      success: '#00b894',
    };
    return colors[level] || '#8899bb';
  }

  _escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }

  _saveState() {
    try {
      const state = {
        id: this[PRIVATE.ID],
        isPaused: this[PRIVATE.IS_PAUSED],
        isFollowing: this[PRIVATE.IS_FOLLOWING],
        isHooked: this[PRIVATE.IS_HOOKED],
        logCount: this[PRIVATE.LOGS].length,
        metadata: this[PRIVATE.METADATA],
        timestamp: Date.now(),
        version: this[PRIVATE.VERSION],
      };
      localStorage.setItem(CONFIG[CONFIG_SYMBOLS.STORAGE_KEY], JSON.stringify(state));
    } catch (e) {
      this[PRIVATE.LOGGER].debug('⚠️ Не удалось сохранить состояние:', e.message);
    }
  }

  _loadState() {
    try {
      const saved = localStorage.getItem(CONFIG[CONFIG_SYMBOLS.STORAGE_KEY]);
      if (saved) {
        const state = JSON.parse(saved);
        if (state.isPaused !== undefined) {
          this[PRIVATE.IS_PAUSED] = state.isPaused;
        }
        if (state.isFollowing !== undefined) {
          this[PRIVATE.IS_FOLLOWING] = state.isFollowing;
        }
        if (state.isHooked !== undefined) {
          this[PRIVATE.IS_HOOKED] = state.isHooked;
        }
        if (state.metadata) {
          Object.assign(this[PRIVATE.METADATA], state.metadata);
        }
        this[PRIVATE.LOGGER].debug('✅ Состояние загружено');
      }
    } catch (e) {
      this[PRIVATE.LOGGER].debug('⚠️ Не удалось загрузить состояние:', e.message);
    }
  }

  // ============================================================
  // 22. ★★★ ЭКСПОРТ СИМВОЛОВ ★★★
  // ============================================================

  _exportSymbols() {
    if (typeof window === 'undefined') return;

    window[PUBLIC.API] = this;
    window[PUBLIC.STATE] = this[PRIVATE.GET_STATE].bind(this);
    window[PUBLIC.CONFIG] = this[PRIVATE.CONFIG];
    window[PUBLIC.LOGGER] = this[PRIVATE.LOGGER];
    window[PUBLIC.INSTANCE] = this;
    window[PUBLIC.ACTIONS] = {
      addLog: this[PRIVATE.ADD_LOG].bind(this),
      clearLogs: this[PRIVATE.CLEAR_LOGS].bind(this),
      exportLogs: this[PRIVATE.EXPORT_LOGS].bind(this),
      togglePause: this[PRIVATE.TOGGLE_PAUSE].bind(this),
      toggleFollow: this[PRIVATE.TOGGLE_FOLLOW].bind(this),
      hookConsole: this[PRIVATE.HOOK_CONSOLE].bind(this),
      unhookConsole: this[PRIVATE.UNHOOK_CONSOLE].bind(this),
    };
    window[PUBLIC.EVENTS] = {
      on: this[PRIVATE.ON].bind(this),
      off: this[PRIVATE.OFF].bind(this),
      emit: this[PRIVATE.EMIT].bind(this),
    };

    window.__logsController = this;
    window.__logsControllerSymbols = {
      PRIVATE: { ...PRIVATE },
      PUBLIC: { ...PUBLIC },
      CONFIG_SYMBOLS: { ...CONFIG_SYMBOLS },
      LOGGER_SYMBOLS: { ...LOGGER_SYMBOLS },
      VALIDATOR_SYMBOLS: { ...VALIDATOR_SYMBOLS },
      version: this[PRIVATE.VERSION],
    };
  }

  // ============================================================
  // 23. ★★★ ПУБЛИЧНЫЕ МЕТОДЫ (ОБЕРТКИ) ★★★
  // ============================================================

  [PRIVATE.GET_LOGS](filter = null, levelFilter = null) {
    let filtered = this[PRIVATE.LOGS];
    if (filter) {
      const lowerFilter = filter.toLowerCase();
      filtered = filtered.filter(e => e.message.toLowerCase().includes(lowerFilter));
    }
    if (levelFilter && levelFilter !== 'all') {
      filtered = filtered.filter(e => e.level === levelFilter);
    }
    return filtered;
  }

  [PRIVATE.GET_STATE]() {
    return {
      id: this[PRIVATE.ID],
      name: this[PRIVATE.NAME],
      type: this[PRIVATE.TYPE],
      version: this[PRIVATE.VERSION],
      initialized: this[PRIVATE.INITIALIZED],
      destroyed: this[PRIVATE.DESTROYED],
      isPaused: this[PRIVATE.IS_PAUSED],
      isFollowing: this[PRIVATE.IS_FOLLOWING],
      isHooked: this[PRIVATE.IS_HOOKED],
      logCount: this[PRIVATE.LOGS].length,
      logLimit: this[PRIVATE.LOG_LIMIT],
      metadata: { ...this[PRIVATE.METADATA] },
      context: { ...this[PRIVATE.CONTEXT] },
      config: { ...this[PRIVATE.CONFIG] },
      hasPanel: !!this[PRIVATE.PANEL],
      hasConsole: !!this[PRIVATE.CONSOLE_EL],
    };
  }

  [PRIVATE.GET_STATS]() {
    const total = this[PRIVATE.LOGS].length;
    const errors = this[PRIVATE.LOGS].filter(e => e.level === 'error').length;
    const warnings = this[PRIVATE.LOGS].filter(e => e.level === 'warn').length;
    const debug = this[PRIVATE.LOGS].filter(e => e.level === 'debug').length;
    const info = this[PRIVATE.LOGS].filter(e => e.level === 'info').length;
    const success = this[PRIVATE.LOGS].filter(e => e.level === 'success').length;

    return {
      total,
      byLevel: { errors, warnings, debug, info, success },
      isPaused: this[PRIVATE.IS_PAUSED],
      isFollowing: this[PRIVATE.IS_FOLLOWING],
      isHooked: this[PRIVATE.IS_HOOKED],
      limit: this[PRIVATE.LOG_LIMIT],
      usage: total > 0 ? `${((total / this[PRIVATE.LOG_LIMIT]) * 100).toFixed(1)}%` : '0%',
      metadata: { ...this[PRIVATE.METADATA] },
      uptime: Date.now() - this[PRIVATE.METADATA].created,
    };
  }

  [PRIVATE.RESET]() {
    const logger = this[PRIVATE.LOGGER];
    logger.warn('🔄 Сброс LogsController...');

    this[PRIVATE.LOGS] = [];
    this[PRIVATE.LOG_COUNT] = 0;
    this[PRIVATE.IS_PAUSED] = false;
    this[PRIVATE.IS_FOLLOWING] = true;
    this[PRIVATE.METADATA] = {
      created: Date.now(),
      lastAccess: Date.now(),
      lastUpdate: Date.now(),
      totalAdded: 0,
      totalCleared: 0,
      totalExported: 0,
    };

    this[PRIVATE.RENDER_LOGS]();
    this[PRIVATE.UPDATE_STATS]();
    this._saveState();

    this[PRIVATE.EMIT]('reset', { timestamp: Date.now() });

    logger.success('✅ LogsController сброшен');
    return this;
  }

  [PRIVATE.DESTROY]() {
    if (this[PRIVATE.DESTROYED]) {
      this[PRIVATE.LOGGER].warn('⚠️ LogsController уже уничтожен');
      return;
    }

    const logger = this[PRIVATE.LOGGER];
    logger.warn('🗑️ Уничтожение LogsController...');

    // Отключаем перехват
    this[PRIVATE.UNHOOK_CONSOLE]();

    // Очищаем таймеры
    for (const [key, timer] of this[PRIVATE.TIMERS]) {
      if (timer instanceof ResizeObserver) {
        timer.disconnect();
      } else {
        clearTimeout(timer);
        clearInterval(timer);
      }
    }
    this[PRIVATE.TIMERS].clear();

    if (this[PRIVATE.FLUSH_TIMER]) {
      clearTimeout(this[PRIVATE.FLUSH_TIMER]);
      this[PRIVATE.FLUSH_TIMER] = null;
    }

    if (this[PRIVATE.AUTO_SCROLL_TIMER]) {
      clearTimeout(this[PRIVATE.AUTO_SCROLL_TIMER]);
      this[PRIVATE.AUTO_SCROLL_TIMER] = null;
    }

    if (this[PRIVATE.RAF_ID]) {
      cancelAnimationFrame(this[PRIVATE.RAF_ID]);
      this[PRIVATE.RAF_ID] = null;
    }

    // Очищаем данные
    this[PRIVATE.LOGS] = [];
    this[PRIVATE.CACHE].clear();
    this[PRIVATE.EVENT_HANDLERS].clear();
    this[PRIVATE.HISTORY] = [];

    // Удаляем глобальные ссылки
    if (typeof window !== 'undefined') {
      delete window[PUBLIC.API];
      delete window[PUBLIC.STATE];
      delete window[PUBLIC.CONFIG];
      delete window[PUBLIC.LOGGER];
      delete window[PUBLIC.INSTANCE];
      delete window[PUBLIC.ACTIONS];
      delete window[PUBLIC.EVENTS];
      delete window.__logsController;
      delete window.__logsControllerSymbols;
    }

    this[PRIVATE.DESTROYED] = true;
    this[PRIVATE.INITIALIZED] = false;

    this[PRIVATE.EMIT]('destroyed', { timestamp: Date.now() });

    logger.success('✅ LogsController уничтожен');
  }

  // ============================================================
  // 24. ★★★ СОБЫТИЯ ★★★
  // ============================================================

  [PRIVATE.ON](event, callback) {
    if (typeof callback !== 'function') {
      this[PRIVATE.LOGGER].warn(`⚠️ Некорректный callback для события ${event}`);
      return () => {};
    }

    if (!this[PRIVATE.EVENT_HANDLERS].has(event)) {
      this[PRIVATE.EVENT_HANDLERS].set(event, []);
    }
    this[PRIVATE.EVENT_HANDLERS].get(event).push(callback);

    return () => this[PRIVATE.OFF](event, callback);
  }

  [PRIVATE.OFF](event, callback) {
    if (this[PRIVATE.EVENT_HANDLERS].has(event)) {
      const handlers = this[PRIVATE.EVENT_HANDLERS].get(event);
      const index = handlers.indexOf(callback);
      if (index !== -1) {
        handlers.splice(index, 1);
      }
      if (handlers.length === 0) {
        this[PRIVATE.EVENT_HANDLERS].delete(event);
      }
    }
  }

  [PRIVATE.EMIT](event, data) {
    if (this[PRIVATE.EVENT_HANDLERS].has(event)) {
      const handlers = this[PRIVATE.EVENT_HANDLERS].get(event);
      for (const callback of handlers) {
        try {
          callback(data);
        } catch (error) {
          this[PRIVATE.LOGGER].error(`❌ Ошибка в обработчике ${event}:`, error.message);
        }
      }
    }
  }

  // ============================================================
  // 25. ★★★ ПУБЛИЧНЫЕ МЕТОДЫ (ДЛЯ ВНЕШНЕГО ИСПОЛЬЗОВАНИЯ) ★★★
  // ============================================================

  addLog(level, ...args) {
    return this[PRIVATE.ADD_LOG](level, ...args);
  }

  getLogs(filter = null, levelFilter = null) {
    return this[PRIVATE.GET_LOGS](filter, levelFilter);
  }

  clearLogs() {
    return this[PRIVATE.CLEAR_LOGS]();
  }

  exportLogs() {
    return this[PRIVATE.EXPORT_LOGS]();
  }

  togglePause() {
    return this[PRIVATE.TOGGLE_PAUSE]();
  }

  toggleFollow() {
    return this[PRIVATE.TOGGLE_FOLLOW]();
  }

  hookConsole() {
    return this[PRIVATE.HOOK_CONSOLE]();
  }

  unhookConsole() {
    return this[PRIVATE.UNHOOK_CONSOLE]();
  }

  isPaused() {
    return this[PRIVATE.IS_PAUSED];
  }

  isFollowing() {
    return this[PRIVATE.IS_FOLLOWING];
  }

  isHooked() {
    return this[PRIVATE.IS_HOOKED];
  }

  renderLogs() {
    return this[PRIVATE.RENDER_LOGS]();
  }

  updateStats() {
    return this[PRIVATE.UPDATE_STATS]();
  }

  getState() {
    return this[PRIVATE.GET_STATE]();
  }

  getStats() {
    return this[PRIVATE.GET_STATS]();
  }

  reset() {
    return this[PRIVATE.RESET]();
  }

  destroy() {
    return this[PRIVATE.DESTROY]();
  }

  on(event, callback) {
    return this[PRIVATE.ON](event, callback);
  }

  off(event, callback) {
    return this[PRIVATE.OFF](event, callback);
  }

  emit(event, data) {
    return this[PRIVATE.EMIT](event, data);
  }

  // ============================================================
  // 26. ★★★ ГЕТТЕРЫ ДЛЯ ПРИВАТНЫХ ДАННЫХ ★★★
  // ============================================================

  get [PRIVATE.ID]() {
    return this[PRIVATE.ID];
  }

  get [PRIVATE.NAME]() {
    return this[PRIVATE.NAME];
  }

  get [PRIVATE.TYPE]() {
    return this[PRIVATE.TYPE];
  }

  get [PRIVATE.VERSION]() {
    return this[PRIVATE.VERSION];
  }

  get [PRIVATE.INITIALIZED]() {
    return this[PRIVATE.INITIALIZED];
  }

  get [PRIVATE.DESTROYED]() {
    return this[PRIVATE.DESTROYED];
  }

  get [PRIVATE.IS_PAUSED]() {
    return this[PRIVATE.IS_PAUSED];
  }

  get [PRIVATE.IS_FOLLOWING]() {
    return this[PRIVATE.IS_FOLLOWING];
  }

  get [PRIVATE.IS_HOOKED]() {
    return this[PRIVATE.IS_HOOKED];
  }

  get [PRIVATE.LOGS]() {
    return this[PRIVATE.LOGS];
  }

  get [PRIVATE.PANEL]() {
    return this[PRIVATE.PANEL];
  }

  get [PRIVATE.CONSOLE_EL]() {
    return this[PRIVATE.CONSOLE_EL];
  }

  get [PRIVATE.CONFIG]() {
    return this[PRIVATE.CONFIG];
  }

  get [PRIVATE.LOGGER]() {
    return this[PRIVATE.LOGGER];
  }

  get [PRIVATE.METADATA]() {
    return this[PRIVATE.METADATA];
  }

  get [PRIVATE.CONTEXT]() {
    return this[PRIVATE.CONTEXT];
  }

  get [PRIVATE.CACHE]() {
    return this[PRIVATE.CACHE];
  }
}

// ============================================================
// 27. ★★★ СОЗДАНИЕ ЭКЗЕМПЛЯРА ★★★
// ============================================================

let logsControllerInstance = null;

export function getLogsController(options = {}) {
  if (!logsControllerInstance) {
    logsControllerInstance = new LogsController(options);
    if (typeof window !== 'undefined') {
      window.__logsControllerInstance = logsControllerInstance;
    }
  }
  return logsControllerInstance;
}

// ============================================================
// 28. ★★★ ЭКСПОРТЫ ★★★
// ============================================================

export {
  PRIVATE,
  PUBLIC,
  CONFIG_SYMBOLS,
  LOGGER_SYMBOLS,
  VALIDATOR_SYMBOLS,
  CONFIG,
  LogsController,
  getLogsController,
};

// ============================================================
// 29. ★★★ ДЕФОЛТНЫЙ ЭКСПОРТ ★★★
// ============================================================

export default LogsController;

// ============================================================
// 30. ★★★ ГЛОБАЛЬНАЯ РЕГИСТРАЦИЯ ★★★
// ============================================================

if (typeof window !== 'undefined') {
  const controller = getLogsController({
    debug: true,
    version: '2.1.9',
    name: 'Logs Control',
  });

  console.log('╔═══════════════════════════════════════════════════════════════════════════════╗');
  console.log('║              📦 LOGS CONTROLLER (100% СИМВОЛЫ) v2.1.9                       ║');
  console.log('╠═══════════════════════════════════════════════════════════════════════════════╣');
  console.log('║  📋 Все логи выводятся в консоль с цветовой разметкой                       ║');
  console.log('║  🔑 Полная изоляция через приватные символы                                 ║');
  console.log('║  🔓 Публичные символы через Symbol.for                                      ║');
  console.log('║  📊 Перехват console.log/error/warn/debug/info                              ║');
  console.log('║  🎯 Слежение и пауза                                                        ║');
  console.log('║  🔍 Фильтрация по уровню и тексту                                           ║');
  console.log('║  📥 Экспорт логов в JSON                                                    ║');
  console.log('║  💾 Сохранение состояния в localStorage                                     ║');
  console.log('║  📡 События: logAdded, logsCleared, logsExported, pauseToggle, followToggle ║');
  console.log('╚═══════════════════════════════════════════════════════════════════════════════╝');

  console.log('📋 КОМАНДЫ ОТЛАДКИ (__logsController):');
  console.log('  __logsController.addLog("info", "Hello")   - добавить лог');
  console.log('  __logsController.getLogs()                 - получить логи');
  console.log('  __logsController.clearLogs()               - очистить логи');
  console.log('  __logsController.exportLogs()              - экспортировать логи');
  console.log('  __logsController.togglePause()             - пауза/возобновить');
  console.log('  __logsController.toggleFollow()            - слежение вкл/выкл');
  console.log('  __logsController.hookConsole()             - перехват console');
  console.log('  __logsController.unhookConsole()           - отключить перехват');
  console.log('  __logsController.getState()                - состояние');
  console.log('  __logsController.getStats()                - статистика');
  console.log('  __logsController.reset()                   - сбросить');
  console.log('  __logsController.destroy()                 - уничтожить');
  console.log('  __logsController.on(event, cb)             - подписка');
  console.log('  __logsController.off(event, cb)            - отписка');
  console.log('  __logsController.emit(event, data)         - событие');
  console.log('');

  console.log('📋 СОБЫТИЯ:');
  console.log('  logAdded      - добавлен лог');
  console.log('  logsCleared   - логи очищены');
  console.log('  logsExported  - логи экспортированы');
  console.log('  pauseToggle   - пауза переключена');
  console.log('  followToggle  - слежение переключено');
  console.log('  consoleHooked - перехват console установлен/отключен');
  console.log('  reset         - сброс');
  console.log('  destroyed     - уничтожение');
  console.log('  filter        - изменён фильтр');
  console.log('  levelChange   - изменён уровень');
  console.log('  statsUpdate   - обновлена статистика');
  console.log('');

  console.log('📋 ПРИВАТНЫХ СИМВОЛОВ:', Object.keys(PRIVATE).length);
  console.log('📋 ПУБЛИЧНЫХ СИМВОЛОВ:', Object.keys(PUBLIC).length);
  console.log('📋 КОНФИГ СИМВОЛОВ:', Object.keys(CONFIG_SYMBOLS).length);
  console.log('📋 ЛОГГЕР СИМВОЛОВ:', Object.keys(LOGGER_SYMBOLS).length);
  console.log('📋 ВАЛИДАТОР СИМВОЛОВ:', Object.keys(VALIDATOR_SYMBOLS).length);
  console.log('═══════════════════════════════════════════════════════════════════════════════');
}
