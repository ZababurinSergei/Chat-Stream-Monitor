// web/debug.mjs - Browser implementation of debug library
// Совместим с Node.js debug API

import ENV from './env.mjs';

// Получаем глобальный объект
const getGlobal = () => {
  if (typeof globalThis !== 'undefined') return globalThis;
  if (typeof window !== 'undefined') return window;
  if (typeof global !== 'undefined') return global;
  if (typeof self !== 'undefined') return self;
  return {};
};

const GLOBAL = getGlobal();

// Счетчик для цветов
let colorCounter = 0;
const COLORS = [
  '#e6194b',
  '#3cb44b',
  '#ffe119',
  '#4363d8',
  '#f58231',
  '#911eb4',
  '#46f0f0',
  '#f032e6',
  '#bcf60c',
  '#fabebe',
  '#008080',
  '#e6beff',
  '#9a6324',
  '#fffac8',
  '#800000',
  '#aaffc3',
  '#808000',
  '#ffd8b1',
  '#000075',
  '#808080',
  '#ffffff',
  '#000000',
  '#ff6b6b',
  '#ffd93d',
  '#6bcb77',
  '#4d96ff',
  '#ff6bd6',
  '#845ec2',
  '#ff9671',
  '#ffc75f',
  '#f9ed69',
  '#d65db1',
  '#ff6f91',
  '#ff9671',
  '#ffc75f',
];

function getColor(namespace) {
  let hash = 0;
  for (let i = 0; i < namespace.length; i++) {
    hash = (hash << 5) - hash + namespace.charCodeAt(i);
    hash = hash & hash;
  }
  return COLORS[Math.abs(hash) % COLORS.length];
}

function getTimestamp() {
  const now = new Date();
  return now.toISOString().replace('T', ' ').slice(0, 23);
}

function formatArgs(args, namespace, config) {
  const color = getColor(namespace);
  const timestamp = config.hideDate ? '' : `${getTimestamp()} `;
  const prefix = `${timestamp}${namespace}`;

  // Используем console.debug с CSS стилями
  const styles = [`color: ${color}; font-weight: bold;`, 'color: inherit;'];

  return [styles, prefix, ...args];
}

// Функция создания debug экземпляра
function createDebug(namespace) {
  const config = ENV.DEBUG;

  // Проверяем включен ли namespace
  const enabled = (() => {
    if (!config.namespace) return false;
    if (config.namespace === '*') return true;

    const parts = config.namespace.split(',').map(p => p.trim());
    let result = false;

    for (const part of parts) {
      if (part === '*') {
        result = true;
      } else if (part.endsWith('*') && namespace.startsWith(part.slice(0, -1))) {
        result = true;
      } else if (part === namespace) {
        result = true;
      } else if (part.startsWith('-')) {
        const exclude = part.slice(1);
        if (
          exclude === '*' ||
          exclude === namespace ||
          (exclude.endsWith('*') && namespace.startsWith(exclude.slice(0, -1)))
        ) {
          result = false;
        }
      }
    }

    return result;
  })();

  // Основная функция логирования
  function debug(...args) {
    if (!enabled) return;

    try {
      const [styles, prefix, ...rest] = formatArgs(args, namespace, config);

      // Проверяем форматтеры в строке
      let formattedArgs = rest;
      if (typeof rest[0] === 'string') {
        let str = rest[0];
        let idx = 1;

        // Обрабатываем %s, %d, %j, %o, %O
        const newArgs = [];
        let currentStr = str;
        let replacements = 0;

        for (let i = 1; i < rest.length; i++) {
          const arg = rest[i];
          const formatted = formatValue(arg, config);
          newArgs.push(formatted);
        }

        // Собираем сообщение
        const message = str.replace(/%[sdoOj%]/g, match => {
          if (match === '%%') return '%';
          if (replacements >= newArgs.length) return match;
          const value = newArgs[replacements++];
          if (match === '%j') {
            try {
              return JSON.stringify(value);
            } catch {
              return '[Circular]';
            }
          }
          return String(value);
        });

        // Добавляем оставшиеся аргументы
        const remaining = newArgs.slice(replacements);
        if (remaining.length > 0) {
          console.debug(`%c${prefix}%c ${message}`, ...styles, ...remaining);
        } else {
          console.debug(`%c${prefix}%c ${message}`, ...styles);
        }
      } else {
        // Если первый аргумент не строка
        console.debug(`%c${prefix}%c`, ...styles, ...rest);
      }
    } catch (error) {
      // Fallback если что-то пошло не так
      console.debug(`[${namespace}]`, ...args);
    }
  }

  // Свойства и методы
  debug.enabled = enabled;
  debug.namespace = namespace;

  // Метод extend для создания дочерних namespace
  debug.extend = function (subNamespace) {
    const newNamespace = namespace + ':' + subNamespace;
    return createDebug(newNamespace);
  };

  // Переопределение log метода (как в Node.js)
  debug.log = console.debug.bind(console);

  // Метод для форматирования значений
  function formatValue(value, config) {
    if (value === null) return 'null';
    if (value === undefined) return 'undefined';
    if (typeof value === 'string') return value;
    if (typeof value === 'number') return String(value);
    if (typeof value === 'boolean') return String(value);
    if (value instanceof Error) return value.stack || value.message;

    try {
      if (config.depth > 0) {
        return JSON.stringify(value, null, config.depth);
      }
      return JSON.stringify(value);
    } catch {
      return String(value);
    }
  }

  return debug;
}

// Глобальный API debug
const debug = createDebug;

// Методы управления
debug.enable = function (namespaces) {
  ENV.debug.enable(namespaces);
};

debug.disable = function () {
  ENV.debug.disable();
};

debug.enabled = function (namespace) {
  return ENV.debug.enabled(namespace);
};

// Форматтеры (как в Node.js)
debug.formatters = {
  o: v => {
    try {
      return JSON.stringify(v, null, 2);
    } catch {
      return String(v);
    }
  },
  O: v => {
    try {
      return JSON.stringify(v, null, 4);
    } catch {
      return String(v);
    }
  },
  s: v => String(v),
  d: v => String(Number(v)),
  j: v => {
    try {
      return JSON.stringify(v);
    } catch {
      return '[Circular]';
    }
  },
};

// Проверяем наличие глобального debug в ENV
if (GLOBAL.DEBUG) {
  debug.enable(GLOBAL.DEBUG);
}

// Добавляем глобальный доступ
GLOBAL.debug = debug;
GLOBAL.__debug = debug;

console.log('🔍 debug library initialized');
console.log(`  Current DEBUG: ${ENV.DEBUG.namespace || '(none)'}`);
console.log('  Use debug.enable("wasm:*") to enable logging');
console.log('  Use debug.disable() to disable logging');
console.log('  Use debug.enabled("wasm:test") to check if enabled');
console.log('');
console.log('📋 Available formatters:');
console.log('  %s  - String');
console.log('  %d  - Number');
console.log('  %j  - JSON (circular safe)');
console.log('  %o  - Object (pretty, 2 spaces)');
console.log('  %O  - Object (pretty, 4 spaces)');
console.log('  %%  - Percent sign');
console.log('');
console.log('📋 Examples:');
console.log('  const log = debug("app");');
console.log('  log("Hello %s", "world");');
console.log('  log("Object: %o", { foo: "bar" });');
console.log('  const subLog = log.extend("sub");');
console.log('  subLog("Nested logger");');

export default debug;
