// web/wasm-logger.mjs - WASM specific logging
// Полная версия с поддержкой flow (metaflow-подобные цепочки)

import debug from './debug.mjs';

// ============================================================
// ОСНОВНЫЕ ЛОГГЕРЫ
// ============================================================

export const log = debug('wasm');
export const logMemory = debug('wasm:memory');
export const logGenerate = debug('wasm:generate');
export const logApi = debug('wasm:api');
export const logError = debug('wasm:error');
export const logFlow = debug('wasm:flow');
export const logStep = debug('wasm:step');
export const logWasm = debug('wasm:wasm');
export const logRuntime = debug('wasm:runtime');

// ============================================================
// ДОЧЕРНИЕ ЛОГГЕРЫ ДЛЯ ДЕТАЛИЗАЦИИ
// ============================================================

// Память
export const logMemoryRead = logMemory.extend('read');
export const logMemoryWrite = logMemory.extend('write');
export const logMemoryAlloc = logMemory.extend('alloc');
export const logMemoryFree = logMemory.extend('free');

// Генерация
export const logGenerateJson = logGenerate.extend('json');
export const logGenerateC = logGenerate.extend('c');
export const logGenerateEnv = logGenerate.extend('env');
export const logGenerateAll = logGenerate.extend('all');

// API
export const logApiCall = logApi.extend('call');
export const logApiResult = logApi.extend('result');
export const logApiError = logApi.extend('error');

// Runtime
export const logRuntimeInit = logRuntime.extend('init');
export const logRuntimeReady = logRuntime.extend('ready');
export const logRuntimeError = logRuntime.extend('error');

// ============================================================
// ФУНКЦИИ ДЛЯ РАБОТЫ С FLOW (METAFLOW-ПОДОБНЫЕ ЦЕПОЧКИ)
// ============================================================

/**
 * Создает логгер для цепочки шагов (как в metaflow)
 * @param {Function} baseLogger - Базовый логгер
 * @param {string} flowName - Имя потока
 * @param {Object} options - Опции
 * @returns {Object} Объект с методами для управления flow
 */
export function createStepLogger(baseLogger, flowName, options = {}) {
  const flowLogger = baseLogger.extend(flowName);
  let stepCounter = 0;
  let branchCounter = 0;
  const startTime = performance.now();
  const steps = [];
  const checkpoints = [];
  const branches = [];

  return {
    /**
     * Добавляет шаг в поток
     * @param {string} name - Имя шага
     * @param {*} data - Данные шага
     * @returns {Function} Логгер для этого шага
     */
    step(name, data = null) {
      stepCounter++;
      const stepLogger = flowLogger.extend(`step${String(stepCounter).padStart(3, '0')}`);
      const timestamp = new Date().toISOString();

      steps.push({
        number: stepCounter,
        name: name,
        timestamp: timestamp,
        data: data,
      });

      const prefix = `[${timestamp}] ▶️ Step ${String(stepCounter).padStart(3, '0')}: ${name}`;
      stepLogger(prefix);

      if (data !== null) {
        if (typeof data === 'object') {
          stepLogger('  📦 Data: %O', data);
        } else {
          stepLogger('  📦 Data: %s', String(data));
        }
      }

      // Возвращаем функцию для логирования внутри шага
      return function (message, ...args) {
        stepLogger(`    └─ ${message}`, ...args);
      };
    },

    /**
     * Начинает новый поток
     * @param {string} description - Описание потока
     */
    start(description) {
      const timestamp = new Date().toISOString();
      flowLogger(`🚀 [${timestamp}] START: ${description}`);
      flowLogger(`  ──────────────────────────────────────────────`);
      stepCounter = 0;
      branchCounter = 0;
      return this;
    },

    /**
     * Завершает поток
     * @param {string} description - Описание завершения
     */
    end(description) {
      const timestamp = new Date().toISOString();
      const elapsed = ((performance.now() - startTime) / 1000).toFixed(2);
      flowLogger(`  ──────────────────────────────────────────────`);
      flowLogger(`✅ [${timestamp}] END: ${description}`);
      flowLogger(`  ⏱️ Total time: ${elapsed}s`);
      flowLogger(
        `  📊 Steps: ${stepCounter}, Branches: ${branchCounter}, Checkpoints: ${checkpoints.length}`
      );
      return this;
    },

    /**
     * Добавляет контрольную точку
     * @param {string} name - Имя контрольной точки
     * @param {*} data - Данные
     */
    checkpoint(name, data = null) {
      const timestamp = new Date().toISOString();
      const checkpointLogger = flowLogger.extend('checkpoint');

      checkpoints.push({
        name: name,
        timestamp: timestamp,
        data: data,
      });

      checkpointLogger(`📌 [${timestamp}] ${name}`);
      if (data !== null) {
        if (typeof data === 'object') {
          checkpointLogger('  📊 %O', data);
        } else {
          checkpointLogger('  📊 %s', String(data));
        }
      }
      return this;
    },

    /**
     * Создает ветку выполнения
     * @param {string} name - Имя ветки
     * @returns {Object} Логгер для ветки
     */
    branch(name) {
      branchCounter++;
      const branchName = `branch${String(branchCounter).padStart(3, '0')}:${name}`;
      const branchLogger = createStepLogger(flowLogger, branchName);

      branches.push({
        number: branchCounter,
        name: name,
        logger: branchLogger,
      });

      flowLogger(`🌿 Branch ${branchCounter}: ${name} created`);
      return branchLogger;
    },

    /**
     * Логирует ошибку в потоке
     * @param {string} message - Сообщение об ошибке
     * @param {Error} error - Объект ошибки
     */
    error(message, error = null) {
      const timestamp = new Date().toISOString();
      const errorLogger = flowLogger.extend('error');
      errorLogger(`❌ [${timestamp}] ${message}`);
      if (error) {
        errorLogger('  📋 %O', error);
        if (error.stack) {
          errorLogger('  📚 Stack: %s', error.stack);
        }
      }
      return this;
    },

    /**
     * Логирует предупреждение
     * @param {string} message - Сообщение
     * @param {*} data - Данные
     */
    warn(message, data = null) {
      const timestamp = new Date().toISOString();
      const warnLogger = flowLogger.extend('warn');
      warnLogger(`⚠️ [${timestamp}] ${message}`);
      if (data !== null) {
        warnLogger('  📊 %O', data);
      }
      return this;
    },

    /**
     * Логирует информационное сообщение
     * @param {string} message - Сообщение
     * @param {*} data - Данные
     */
    info(message, data = null) {
      const timestamp = new Date().toISOString();
      const infoLogger = flowLogger.extend('info');
      infoLogger(`ℹ️ [${timestamp}] ${message}`);
      if (data !== null) {
        infoLogger('  📊 %O', data);
      }
      return this;
    },

    /**
     * Возвращает статистику потока
     * @returns {Object} Статистика
     */
    getStats() {
      return {
        flowName: flowName,
        startTime: new Date(startTime).toISOString(),
        elapsed: ((performance.now() - startTime) / 1000).toFixed(2) + 's',
        stepCount: stepCounter,
        branchCount: branchCounter,
        checkpointCount: checkpoints.length,
        steps: steps,
        checkpoints: checkpoints,
        branches: branches,
      };
    },

    /**
     * Создает таймер для измерения времени выполнения
     * @param {string} name - Имя таймера
     * @returns {Object} Объект с методами start/end
     */
    timer(name) {
      const timerLogger = flowLogger.extend(`timer:${name}`);
      let startTime = null;

      return {
        start: () => {
          startTime = performance.now();
          timerLogger(`⏱️ ${name} - started`);
          return this;
        },
        end: (message = '') => {
          if (startTime === null) {
            timerLogger(`⚠️ ${name} - timer was not started`);
            return this;
          }
          const elapsed = (performance.now() - startTime).toFixed(2);
          timerLogger(`⏱️ ${name} - ${elapsed}ms ${message}`);
          startTime = null;
          return this;
        },
        lap: (label = '') => {
          if (startTime === null) {
            timerLogger(`⚠️ ${name} - timer was not started`);
            return this;
          }
          const elapsed = (performance.now() - startTime).toFixed(2);
          timerLogger(`⏱️ ${name} - ${elapsed}ms [${label}]`);
          return this;
        },
      };
    },

    /**
     * Создает дочерний логгер для подпроцесса
     * @param {string} subName - Имя подпроцесса
     * @returns {Object} Логгер подпроцесса
     */
    subflow(subName) {
      const subLogger = createStepLogger(flowLogger, `${flowName}:${subName}`);
      subLogger.start(`Subflow: ${subName}`);
      return subLogger;
    },
  };
}

// ============================================================
// ФУНКЦИИ ДЛЯ ИЗМЕРЕНИЯ ВРЕМЕНИ
// ============================================================

/**
 * Измеряет время выполнения функции и логирует результат
 * @param {Function} logger - Логгер для вывода
 * @param {string} name - Имя операции
 * @param {Function} fn - Функция для выполнения
 * @param {*} context - Контекст для функции
 * @returns {*} Результат функции
 */
export function measureStep(logger, name, fn, context = null) {
  const start = performance.now();
  logger(`⏱️ ${name} - start`);

  try {
    const result = context ? fn.call(context) : fn();
    const time = (performance.now() - start).toFixed(2);
    const memory = performance.memory
      ? `, memory: ${(performance.memory.usedJSHeapSize / 1024 / 1024).toFixed(2)}MB`
      : '';
    logger(`✅ ${name} - done (${time}ms${memory})`);

    if (result !== undefined && result !== null) {
      if (typeof result === 'object') {
        logger(`  📦 Result: %O`, result);
      } else if (typeof result === 'string' && result.length > 100) {
        logger(`  📦 Result: ${result.substring(0, 100)}... (${result.length} chars)`);
      } else {
        logger(`  📦 Result: %s`, String(result));
      }
    }

    return result;
  } catch (error) {
    const time = (performance.now() - start).toFixed(2);
    logger(`❌ ${name} - error after ${time}ms: ${error.message}`);
    if (error.stack) {
      logger(`  📚 ${error.stack.split('\n').slice(0, 3).join('\n  📚 ')}`);
    }
    throw error;
  }
}

/**
 * Создает обертку для функции с логированием
 * @param {Function} logger - Логгер для вывода
 * @param {Function} fn - Функция для обертки
 * @param {string} name - Имя функции
 * @returns {Function} Обернутая функция
 */
export function traceFunction(logger, fn, name) {
  return function (...args) {
    logger(`🔍 ${name} called`);
    if (args.length > 0) {
      logger(`  📥 Args: %O`, args);
    }

    try {
      const result = fn.apply(this, args);
      if (result !== undefined && result !== null) {
        if (typeof result === 'object' && !(result instanceof Promise)) {
          logger(`  📤 Result: %O`, result);
        } else if (typeof result === 'string' && result.length > 100) {
          logger(`  📤 Result: ${result.substring(0, 100)}... (${result.length} chars)`);
        } else {
          logger(`  📤 Result: %s`, String(result));
        }
      }
      return result;
    } catch (error) {
      logger(`  ❌ Error: ${error.message}`);
      throw error;
    }
  };
}

/**
 * Измеряет время выполнения асинхронной функции
 * @param {Function} logger - Логгер для вывода
 * @param {string} name - Имя операции
 * @param {Function} fn - Асинхронная функция
 * @param {*} context - Контекст
 * @returns {Promise} Результат
 */
export async function measureAsyncStep(logger, name, fn, context = null) {
  const start = performance.now();
  logger(`⏱️ ${name} - async start`);

  try {
    const result = context ? await fn.call(context) : await fn();
    const time = (performance.now() - start).toFixed(2);
    logger(`✅ ${name} - async done (${time}ms)`);
    return result;
  } catch (error) {
    const time = (performance.now() - start).toFixed(2);
    logger(`❌ ${name} - async error after ${time}ms: ${error.message}`);
    throw error;
  }
}

// ============================================================
// СПЕЦИАЛИЗИРОВАННЫЕ ЛОГГЕРЫ ДЛЯ WASM
// ============================================================

/**
 * Создает логгер для работы с WASM
 * @param {string} flowName - Имя потока
 * @param {Object} options - Опции
 * @returns {Object} Специализированный логгер
 */
export function createWasmLogger(flowName, options = {}) {
  const flow = createStepLogger(logWasm, flowName);
  const moduleRef = options.module || null;

  return {
    flow: flow,

    /**
     * Логирует вызов WASM функции
     * @param {string} funcName - Имя функции
     * @param {Array} args - Аргументы
     * @param {*} result - Результат
     */
    call: function (funcName, args, result = null) {
      const callLogger = flow.step(`wasm:${funcName}`);
      callLogger(`📞 Calling ${funcName}`);
      if (args && args.length > 0) {
        callLogger(`  📥 Args: %O`, args);
      }
      if (result !== null) {
        if (typeof result === 'number' && result > 0 && result < 100000) {
          callLogger(`  📤 Result: ${result} (ptr)`);
        } else {
          callLogger(`  📤 Result: %O`, result);
        }
      }
      return this;
    },

    /**
     * Логирует работу с памятью
     */
    memory: {
      read: function (ptr, size) {
        const memLogger = flow.step('memory:read');
        memLogger(`📖 Read at ${ptr}, size ${size}`);

        if (moduleRef && moduleRef.HEAPU8) {
          try {
            const bytes = [];
            for (let i = 0; i < Math.min(size || 64, moduleRef.HEAPU8.length - ptr); i++) {
              bytes.push(moduleRef.HEAPU8[ptr + i]);
            }
            memLogger(`  📊 Bytes: [${bytes.join(', ')}]`);

            // Пытаемся прочитать как строку
            if (bytes.length > 0) {
              let str = '';
              let end = ptr;
              while (end < moduleRef.HEAPU8.length && moduleRef.HEAPU8[end] !== 0) {
                end++;
              }
              if (end > ptr) {
                const slice = moduleRef.HEAPU8.slice(ptr, Math.min(end, ptr + 200));
                const decoder = new TextDecoder('utf-8');
                str = decoder.decode(slice);
                memLogger(`  📄 String: "${str}${str.length > 200 ? '...' : ''}"`);
              }
            }
          } catch (e) {
            memLogger(`  ⚠️ Error reading memory: ${e.message}`);
          }
        }
        return this;
      },

      write: function (ptr, data) {
        const memLogger = flow.step('memory:write');
        memLogger(`✏️ Write at ${ptr}`);
        if (typeof data === 'string') {
          memLogger(`  📄 Data: "${data.substring(0, 200)}${data.length > 200 ? '...' : ''}"`);
        } else if (Array.isArray(data)) {
          memLogger(`  📊 Data: [${data.slice(0, 32).join(', ')}${data.length > 32 ? '...' : ''}]`);
        } else {
          memLogger(`  📊 Data: %O`, data);
        }
        return this;
      },

      alloc: function (size) {
        const memLogger = flow.step('memory:alloc');
        memLogger(`📦 Allocate ${size} bytes`);
        return this;
      },

      free: function (ptr) {
        const memLogger = flow.step('memory:free');
        memLogger(`🗑️ Free at ${ptr}`);
        return this;
      },
    },

    /**
     * Логирует экспорты модуля
     */
    exports: function () {
      if (moduleRef) {
        const exports = Object.keys(moduleRef).filter(k => k.startsWith('_'));
        const step = flow.step('exports');
        step(`📋 Available exports: ${exports.length}`);
        exports.forEach(name => {
          step(`  ├─ ${name}`);
        });
      }
      return this;
    },

    /**
     * Логирует состояние модуля
     */
    state: function () {
      const step = flow.step('state');
      if (moduleRef) {
        step('📊 Module state:');
        step(`  HEAPU8: ${moduleRef.HEAPU8 ? moduleRef.HEAPU8.length : 'undefined'}`);
        step(`  memory: ${moduleRef.memory ? moduleRef.memory.buffer.byteLength : 'undefined'}`);
        step(
          `  wasmMemory: ${moduleRef.wasmMemory ? moduleRef.wasmMemory.buffer.byteLength : 'undefined'}`
        );
        step(
          `  exports: ${
            Object.keys(moduleRef)
              .filter(k => k.startsWith('_'))
              .join(', ') || 'none'
          }`
        );
      } else {
        step('⚠️ No module reference');
      }
      return this;
    },

    /**
     * Создает таймер для WASM операции
     */
    timer: function (name) {
      return flow.timer(name);
    },
  };
}

// ============================================================
// ФУНКЦИЯ ДЛЯ СОЗДАНИЯ ПОЛНОГО FLOW ЛОГГЕРА
// ============================================================

/**
 * Создает полный flow логгер для приложения
 * @param {string} flowName - Имя потока
 * @param {Object} options - Опции
 * @returns {Object} Полный логгер
 */
export function createFlowLogger(flowName, options = {}) {
  const baseLogger = options.logger || logFlow;
  const flow = createStepLogger(baseLogger, flowName);

  return {
    ...flow,

    /**
     * Специализированные методы для WASM
     */
    wasm: {
      call: (funcName, ...args) => {
        const callLogger = flow.step(`wasm:${funcName}`);
        callLogger(`📞 Calling ${funcName}`);
        if (args.length > 0) {
          callLogger('  📥 Args: %o', args);
        }
        return {
          result: value => {
            callLogger(`  📤 Result: %o`, value);
            return value;
          },
          error: error => {
            callLogger(`  ❌ Error: ${error.message}`);
            throw error;
          },
          ptr: ptr => {
            callLogger(`  📍 Ptr: ${ptr}`);
            return ptr;
          },
        };
      },

      memory: {
        read: (ptr, size) => {
          const memLogger = flow.step('memory:read');
          memLogger(`📖 Read at ${ptr}, size ${size}`);
          return {
            bytes: bytes => {
              memLogger(
                `  📊 Bytes: [${bytes.slice(0, 32).join(', ')}${bytes.length > 32 ? '...' : ''}]`
              );
              return bytes;
            },
            string: str => {
              if (str) {
                memLogger(`  📄 String: "${str.slice(0, 200)}${str.length > 200 ? '...' : ''}"`);
              } else {
                memLogger(`  📄 String: (null or empty)`);
              }
              return str;
            },
            hex: bytes => {
              const hex = bytes
                .slice(0, 64)
                .map(b => b.toString(16).padStart(2, '0'))
                .join(' ');
              memLogger(`  🔢 Hex: ${hex}${bytes.length > 64 ? '...' : ''}`);
              return bytes;
            },
          };
        },

        write: (ptr, data) => {
          const memLogger = flow.step('memory:write');
          memLogger(`✏️ Write at ${ptr}: %o`, data);
          return this;
        },
      },
    },

    /**
     * Метод для логирования цепочки вызовов
     */
    chain: function (name) {
      const chainLogger = flow.branch(`chain:${name}`);
      return chainLogger;
    },

    /**
     * Метод для группировки логов
     */
    group: function (name, fn) {
      const groupLogger = flow.branch(`group:${name}`);
      groupLogger.start(`Group: ${name}`);
      try {
        fn(groupLogger);
      } finally {
        groupLogger.end(`Group: ${name}`);
      }
      return this;
    },
  };
}

// ============================================================
// УТИЛИТЫ ДЛЯ ОТЛАДКИ
// ============================================================

/**
 * Создает дамп памяти для отладки
 * @param {Object} module - Модуль WASM
 * @param {number} ptr - Указатель
 * @param {number} size - Размер
 * @param {Function} logger - Логгер
 * @returns {Object} Дамп памяти
 */
export function dumpMemory(module, ptr, size = 64, logger = logMemory) {
  if (!module || !module.HEAPU8) {
    logger('⚠️ Module or HEAPU8 not available');
    return null;
  }

  try {
    const heap = module.HEAPU8;
    const maxSize = Math.min(size, heap.length - ptr);

    if (maxSize <= 0 || ptr >= heap.length) {
      logger(`⚠️ Invalid ptr: ${ptr}, heap length: ${heap.length}`);
      return null;
    }

    const bytes = [];
    const hex = [];
    const ascii = [];

    for (let i = 0; i < maxSize; i++) {
      const byte = heap[ptr + i];
      bytes.push(byte);
      hex.push(byte.toString(16).padStart(2, '0'));
      ascii.push(byte >= 32 && byte <= 126 ? String.fromCharCode(byte) : '.');
    }

    const dump = {
      ptr: ptr,
      size: maxSize,
      bytes: bytes,
      hex: hex.join(' '),
      ascii: ascii.join(''),
      string: null,
    };

    // Пытаемся прочитать как строку
    let end = ptr;
    while (end < heap.length && heap[end] !== 0) {
      end++;
    }
    if (end > ptr) {
      const slice = heap.slice(ptr, Math.min(end, ptr + 1000));
      const decoder = new TextDecoder('utf-8');
      dump.string = decoder.decode(slice);
    }

    logger('📊 Memory dump:');
    logger(`  📍 Ptr: ${ptr}, Size: ${maxSize}`);
    logger(`  🔢 Hex: ${dump.hex}`);
    logger(`  📝 ASCII: ${dump.ascii}`);
    if (dump.string) {
      logger(`  📄 String: "${dump.string.slice(0, 200)}${dump.string.length > 200 ? '...' : ''}"`);
    }

    return dump;
  } catch (error) {
    logger(`❌ Error dumping memory: ${error.message}`);
    return null;
  }
}

// ============================================================
// ЭКСПОРТ ПО УМОЛЧАНИЮ
// ============================================================

export default {
  // Основные логгеры
  log,
  logMemory,
  logGenerate,
  logApi,
  logError,
  logFlow,
  logStep,
  logWasm,
  logRuntime,

  // Дочерние логгеры
  logMemoryRead,
  logMemoryWrite,
  logMemoryAlloc,
  logMemoryFree,
  logGenerateJson,
  logGenerateC,
  logGenerateEnv,
  logGenerateAll,
  logApiCall,
  logApiResult,
  logApiError,
  logRuntimeInit,
  logRuntimeReady,
  logRuntimeError,

  // Функции
  createStepLogger,
  createFlowLogger,
  createWasmLogger,
  measureStep,
  measureAsyncStep,
  traceFunction,
  dumpMemory,
};
