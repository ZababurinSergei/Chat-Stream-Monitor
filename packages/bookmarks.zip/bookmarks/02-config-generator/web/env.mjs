// web/env.mjs - Environment Configuration with Proxy support
// Этот файл определяет ENV объект с прокси для отслеживания изменений
// Поддерживает как браузер, так и Node.js окружение

// ============================================================
// 1. ПОЛУЧЕНИЕ ГЛОБАЛЬНОГО ОБЪЕКТА
// ============================================================

const getGlobal = () => {
  if (typeof globalThis !== 'undefined') return globalThis;
  if (typeof window !== 'undefined') return window;
  if (typeof global !== 'undefined') return global;
  if (typeof self !== 'undefined') return self;
  return {};
};

const GLOBAL = getGlobal();

// ============================================================
// 2. КОНФИГУРАЦИЯ ПО УМОЛЧАНИЮ
// ============================================================

const DEFAULT_DEBUG_NAMESPACE = '';
const DEFAULT_OPTIONS = {
  hideDate: false,
  colors: true,
  depth: 2,
  showHidden: false,
};

// ============================================================
// 3. ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ
// ============================================================

/**
 * Проверяет, включен ли указанный namespace в паттерне DEBUG
 * Поддерживает wildcards (*) и исключения (-)
 */
function isDebugEnabled(namespace, pattern) {
  if (!pattern || pattern === '') return false;
  if (pattern === '*') return true;

  const parts = pattern.split(',').map(p => p.trim());
  let enabled = false;

  for (const part of parts) {
    if (part === '') continue;

    if (part === '*') {
      enabled = true;
    } else if (part.endsWith('*') && namespace.startsWith(part.slice(0, -1))) {
      enabled = true;
    } else if (part === namespace) {
      enabled = true;
    } else if (part.startsWith('-')) {
      const exclude = part.slice(1);
      if (exclude === '*') {
        enabled = false;
      } else if (exclude.endsWith('*') && namespace.startsWith(exclude.slice(0, -1))) {
        enabled = false;
      } else if (exclude === namespace) {
        enabled = false;
      }
    }
  }

  return enabled;
}

/**
 * Получает значение из источника по приоритету
 */
function getDebugFromSources() {
  // URL параметры (наивысший приоритет)
  if (typeof window !== 'undefined' && window.location) {
    const params = new URLSearchParams(window.location.search);
    const fromURL = params.get('debug');
    if (fromURL !== null) return fromURL;
  }

  // localStorage
  if (GLOBAL.localStorage) {
    const fromStorage = GLOBAL.localStorage.getItem('debug');
    if (fromStorage !== null) return fromStorage;
  }

  // Глобальная переменная
  if (GLOBAL.DEBUG !== undefined) return GLOBAL.DEBUG;

  // Значение по умолчанию
  return DEFAULT_DEBUG_NAMESPACE;
}

function getOptionsFromSources() {
  const options = { ...DEFAULT_OPTIONS };

  if (GLOBAL.localStorage) {
    const hideDate = GLOBAL.localStorage.getItem('debug_hide_date');
    if (hideDate !== null) options.hideDate = hideDate === 'true';

    const colors = GLOBAL.localStorage.getItem('debug_colors');
    if (colors !== null) options.colors = colors !== 'false';

    const depth = GLOBAL.localStorage.getItem('debug_depth');
    if (depth !== null) options.depth = parseInt(depth, 10) || 2;

    const showHidden = GLOBAL.localStorage.getItem('debug_show_hidden');
    if (showHidden !== null) options.showHidden = showHidden === 'true';
  }

  if (GLOBAL.DEBUG_HIDE_DATE !== undefined) options.hideDate = GLOBAL.DEBUG_HIDE_DATE === 'true';
  if (GLOBAL.DEBUG_COLORS !== undefined) options.colors = GLOBAL.DEBUG_COLORS !== 'false';
  if (GLOBAL.DEBUG_DEPTH !== undefined) options.depth = parseInt(GLOBAL.DEBUG_DEPTH, 10) || 2;
  if (GLOBAL.DEBUG_SHOW_HIDDEN !== undefined)
    options.showHidden = GLOBAL.DEBUG_SHOW_HIDDEN === 'true';

  return options;
}

// ============================================================
// 4. ОБНОВЛЕНИЕ UI СТАТУСА
// ============================================================

function updateDebugStatusUI(namespace) {
  if (typeof document === 'undefined') return;

  const debugStatus = document.getElementById('debug-status');
  if (debugStatus) {
    const isEnabled = namespace && namespace !== '';
    if (isEnabled) {
      debugStatus.textContent = `🔍 Debug: ${namespace}`;
      debugStatus.style.color = '#00b894';
      debugStatus.title = `Active debug namespaces: ${namespace}`;
    } else {
      debugStatus.textContent = '🔍 Debug: off';
      debugStatus.style.color = '#636e72';
      debugStatus.title = 'Debug is disabled';
    }
  }

  const debugStatusLabel = document.getElementById('debug-status-label');
  if (debugStatusLabel) {
    const isEnabled = namespace && namespace !== '';
    debugStatusLabel.textContent = isEnabled ? namespace : 'off';
    debugStatusLabel.className = `badge ${isEnabled ? 'badge-success' : 'badge-info'}`;
  }

  const debugPreset = document.getElementById('debug-preset');
  if (debugPreset) {
    const options = debugPreset.options;
    let found = false;
    for (let i = 0; i < options.length; i++) {
      if (options[i].value === namespace) {
        debugPreset.selectedIndex = i;
        found = true;
        break;
      }
    }
    if (!found && namespace) {
      // Удаляем старые custom опции
      for (let i = options.length - 1; i >= 0; i--) {
        if (options[i].text && options[i].text.startsWith('custom:')) {
          debugPreset.remove(i);
        }
      }
      const opt = document.createElement('option');
      opt.value = namespace;
      opt.textContent = `custom: ${namespace}`;
      opt.selected = true;
      debugPreset.appendChild(opt);
    }
    if (!namespace) {
      debugPreset.selectedIndex = 0;
    }
  }
}

// ============================================================
// 5. СОЗДАНИЕ ПРОКСИ ДЛЯ ENV
// ============================================================

// Внутреннее состояние
const state = {
  debugNamespace: getDebugFromSources(),
  options: getOptionsFromSources(),
  listeners: [],
  history: [],
  maxHistory: 100,
};

// Обработчики событий для отслеживания изменений
const eventHandlers = {
  onChange: null,
  onDebugChange: null,
  onOptionsChange: null,
};

/**
 * Вызывает все зарегистрированные слушатели
 */
function notifyListeners(type, data) {
  const listeners = state.listeners.filter(l => l.type === type || l.type === '*');
  for (const listener of listeners) {
    try {
      listener.callback(data);
    } catch (error) {
      console.error('[ENV] Listener error:', error);
    }
  }
}

/**
 * Добавляет запись в историю изменений
 */
function addToHistory(type, key, oldValue, newValue) {
  state.history.push({
    timestamp: new Date().toISOString(),
    type,
    key,
    oldValue,
    newValue,
  });
  if (state.history.length > state.maxHistory) {
    state.history.shift();
  }
}

/**
 * Сохраняет настройки в localStorage
 */
function persistToStorage(key, value) {
  try {
    if (GLOBAL.localStorage) {
      if (value === null || value === undefined || value === '') {
        GLOBAL.localStorage.removeItem(key);
      } else {
        GLOBAL.localStorage.setItem(key, String(value));
      }
    }
  } catch (e) {
    // Игнорируем ошибки localStorage
  }
}

// ============================================================
// 6. ОСНОВНОЙ ENV ОБЪЕКТ
// ============================================================

const envObject = {};

// Свойства DEBUG с getter/setter
Object.defineProperty(envObject, 'DEBUG', {
  get() {
    return {
      get namespace() {
        return state.debugNamespace;
      },
      set namespace(value) {
        const oldValue = state.debugNamespace;
        const newValue = value || '';

        if (oldValue === newValue) return;

        state.debugNamespace = newValue;
        persistToStorage('debug', newValue);
        GLOBAL.DEBUG = newValue;

        addToHistory('debug', 'namespace', oldValue, newValue);
        notifyListeners('debug', { namespace: newValue, oldValue });
        notifyListeners('change', { type: 'debug', namespace: newValue, oldValue });

        updateDebugStatusUI(newValue);

        if (eventHandlers.onDebugChange) {
          try {
            eventHandlers.onDebugChange(newValue, oldValue);
          } catch (e) {}
        }
      },

      get hideDate() {
        return state.options.hideDate;
      },
      set hideDate(value) {
        const oldValue = state.options.hideDate;
        const newValue = Boolean(value);
        if (oldValue === newValue) return;

        state.options.hideDate = newValue;
        persistToStorage('debug_hide_date', String(newValue));
        addToHistory('options', 'hideDate', oldValue, newValue);
        notifyListeners('options', { hideDate: newValue, oldValue });
        notifyListeners('change', { type: 'options', key: 'hideDate', value: newValue, oldValue });

        if (eventHandlers.onOptionsChange) {
          try {
            eventHandlers.onOptionsChange({ hideDate: newValue });
          } catch (e) {}
        }
      },

      get colors() {
        return state.options.colors;
      },
      set colors(value) {
        const oldValue = state.options.colors;
        const newValue = value !== false;
        if (oldValue === newValue) return;

        state.options.colors = newValue;
        persistToStorage('debug_colors', String(newValue));
        addToHistory('options', 'colors', oldValue, newValue);
        notifyListeners('options', { colors: newValue, oldValue });
        notifyListeners('change', { type: 'options', key: 'colors', value: newValue, oldValue });

        if (eventHandlers.onOptionsChange) {
          try {
            eventHandlers.onOptionsChange({ colors: newValue });
          } catch (e) {}
        }
      },

      get depth() {
        return state.options.depth;
      },
      set depth(value) {
        const oldValue = state.options.depth;
        const newValue = Math.max(0, parseInt(value, 10) || 0);
        if (oldValue === newValue) return;

        state.options.depth = newValue;
        persistToStorage('debug_depth', String(newValue));
        addToHistory('options', 'depth', oldValue, newValue);
        notifyListeners('options', { depth: newValue, oldValue });
        notifyListeners('change', { type: 'options', key: 'depth', value: newValue, oldValue });

        if (eventHandlers.onOptionsChange) {
          try {
            eventHandlers.onOptionsChange({ depth: newValue });
          } catch (e) {}
        }
      },

      get showHidden() {
        return state.options.showHidden;
      },
      set showHidden(value) {
        const oldValue = state.options.showHidden;
        const newValue = Boolean(value);
        if (oldValue === newValue) return;

        state.options.showHidden = newValue;
        persistToStorage('debug_show_hidden', String(newValue));
        addToHistory('options', 'showHidden', oldValue, newValue);
        notifyListeners('options', { showHidden: newValue, oldValue });
        notifyListeners('change', {
          type: 'options',
          key: 'showHidden',
          value: newValue,
          oldValue,
        });

        if (eventHandlers.onOptionsChange) {
          try {
            eventHandlers.onOptionsChange({ showHidden: newValue });
          } catch (e) {}
        }
      },

      get config() {
        return {
          namespace: state.debugNamespace,
          hideDate: state.options.hideDate,
          colors: state.options.colors,
          depth: state.options.depth,
          showHidden: state.options.showHidden,
        };
      },
    };
  },
  enumerable: true,
  configurable: true,
});

// ============================================================
// 7. МЕТОДЫ УПРАВЛЕНИЯ
// ============================================================

envObject.debug = {
  /**
   * Включить отладку для указанных namespace
   */
  enable(namespaces) {
    envObject.DEBUG.namespace = namespaces;
    console.log(`🔍 Debug enabled: ${namespaces}`);
    this.logStatus();
    return this;
  },

  /**
   * Отключить отладку полностью
   */
  disable() {
    envObject.DEBUG.namespace = '';
    console.log('🔍 Debug disabled');
    this.logStatus();
    return this;
  },

  /**
   * Проверить, включен ли namespace
   */
  enabled(namespace) {
    return isDebugEnabled(namespace, state.debugNamespace);
  },

  /**
   * Получить текущую конфигурацию
   */
  getConfig() {
    return {
      namespace: state.debugNamespace,
      hideDate: state.options.hideDate,
      colors: state.options.colors,
      depth: state.options.depth,
      showHidden: state.options.showHidden,
    };
  },

  /**
   * Установить опции форматирования
   */
  setOptions(options) {
    const changes = [];
    if (options.hideDate !== undefined) {
      const oldValue = state.options.hideDate;
      envObject.DEBUG.hideDate = options.hideDate;
      changes.push({ key: 'hideDate', old: oldValue, new: options.hideDate });
    }
    if (options.colors !== undefined) {
      const oldValue = state.options.colors;
      envObject.DEBUG.colors = options.colors;
      changes.push({ key: 'colors', old: oldValue, new: options.colors });
    }
    if (options.depth !== undefined) {
      const oldValue = state.options.depth;
      envObject.DEBUG.depth = options.depth;
      changes.push({ key: 'depth', old: oldValue, new: options.depth });
    }
    if (options.showHidden !== undefined) {
      const oldValue = state.options.showHidden;
      envObject.DEBUG.showHidden = options.showHidden;
      changes.push({ key: 'showHidden', old: oldValue, new: options.showHidden });
    }

    console.log('🔍 Debug options updated:', this.getConfig());
    notifyListeners('options-change', { changes, config: this.getConfig() });

    if (eventHandlers.onChange) {
      try {
        eventHandlers.onChange({ type: 'options', changes, config: this.getConfig() });
      } catch (e) {}
    }

    return this;
  },

  /**
   * Вывести статус debug в консоль
   */
  logStatus() {
    const config = this.getConfig();
    const status = config.namespace ? `enabled: ${config.namespace}` : 'disabled';
    console.log(`🔍 Debug status: ${status}`);
    console.log('  Options:', {
      hideDate: config.hideDate,
      colors: config.colors,
      depth: config.depth,
      showHidden: config.showHidden,
    });
    return this;
  },

  /**
   * Показать справку по использованию debug
   */
  help() {
    console.log(`
╔═══════════════════════════════════════════════════════════════════╗
║                    🔍 DEBUG COMMANDS                              ║
╠═══════════════════════════════════════════════════════════════════╣
║                                                                   ║
║  Включение/выключение:                                            ║
║    ENV.debug.enable('wasm:*')      - все wasm логи               ║
║    ENV.debug.enable('wasm:memory:*') - логи памяти               ║
║    ENV.debug.enable('wasm:generate:*') - логи генерации          ║
║    ENV.debug.enable('wasm:flow:*') - логи потока (metaflow)      ║
║    ENV.debug.enable('wasm:api:*')  - логи API                    ║
║    ENV.debug.enable('wasm:error:*') - логи ошибок                ║
║    ENV.debug.disable()             - отключить все               ║
║                                                                   ║
║  Комбинированные паттерны:                                        ║
║    ENV.debug.enable('wasm:*, -wasm:memory') - все кроме памяти   ║
║    ENV.debug.enable('wasm:memory:read,wasm:generate') - два      ║
║                                                                   ║
║  Настройки:                                                       ║
║    ENV.debug.setOptions({ depth: 4 }) - глубина инспекции        ║
║    ENV.debug.setOptions({ hideDate: true }) - скрыть дату        ║
║    ENV.debug.setOptions({ colors: false }) - отключить цвета     ║
║                                                                   ║
║  Информация:                                                      ║
║    ENV.debug.getConfig()          - текущая конфигурация         ║
║    ENV.debug.enabled('wasm:test') - проверка namespace           ║
║    ENV.debug.logStatus()          - статус debug                 ║
║                                                                   ║
║  Отслеживание изменений:                                          ║
║    ENV.on('debug', callback)      - подписка на изменения debug  ║
║    ENV.on('options', callback)    - подписка на изменения опций  ║
║    ENV.on('change', callback)     - подписка на любые изменения  ║
║    ENV.off('debug', callback)     - отписка                      ║
║    ENV.getHistory()               - история изменений            ║
║                                                                   ║
║  Сохранение настроек:                                             ║
║    localStorage.setItem('debug', 'wasm:*')                       ║
║    localStorage.removeItem('debug')                              ║
║                                                                   ║
║  URL параметры:                                                   ║
║    ?debug=wasm:*                                                 ║
║                                                                   ║
╚═══════════════════════════════════════════════════════════════════╝
    `);
    return this;
  },

  /**
   * Получить историю изменений
   */
  getHistory() {
    return [...state.history];
  },

  /**
   * Очистить историю изменений
   */
  clearHistory() {
    state.history = [];
    return this;
  },
};

// ============================================================
// 8. УПРАВЛЕНИЕ СОБЫТИЯМИ
// ============================================================

/**
 * Подписаться на изменения
 */
envObject.on = function (type, callback) {
  if (typeof callback !== 'function') {
    console.warn('[ENV] Callback must be a function');
    return this;
  }
  state.listeners.push({ type, callback });
  return this;
};

/**
 * Отписаться от изменений
 */
envObject.off = function (type, callback) {
  state.listeners = state.listeners.filter(l => !(l.type === type && l.callback === callback));
  return this;
};

/**
 * Установить обработчик изменений (устаревший, используйте on)
 */
envObject.setOnChange = function (callback) {
  if (typeof callback === 'function') {
    eventHandlers.onChange = callback;
  }
  return this;
};

/**
 * Установить обработчик изменений debug
 */
envObject.setOnDebugChange = function (callback) {
  if (typeof callback === 'function') {
    eventHandlers.onDebugChange = callback;
  }
  return this;
};

/**
 * Установить обработчик изменений опций
 */
envObject.setOnOptionsChange = function (callback) {
  if (typeof callback === 'function') {
    eventHandlers.onOptionsChange = callback;
  }
  return this;
};

// ============================================================
// 9. ДОПОЛНИТЕЛЬНЫЕ МЕТОДЫ
// ============================================================

/**
 * Получить полную конфигурацию
 */
envObject.getConfig = function () {
  return this.debug.getConfig();
};

/**
 * Получить историю изменений
 */
envObject.getHistory = function () {
  return this.debug.getHistory();
};

/**
 * Очистить историю
 */
envObject.clearHistory = function () {
  return this.debug.clearHistory();
};

/**
 * Сбросить все настройки до значений по умолчанию
 */
envObject.reset = function () {
  const oldNamespace = state.debugNamespace;
  const oldOptions = { ...state.options };

  state.debugNamespace = DEFAULT_DEBUG_NAMESPACE;
  state.options = { ...DEFAULT_OPTIONS };

  persistToStorage('debug', null);
  persistToStorage('debug_hide_date', null);
  persistToStorage('debug_colors', null);
  persistToStorage('debug_depth', null);
  persistToStorage('debug_show_hidden', null);

  GLOBAL.DEBUG = DEFAULT_DEBUG_NAMESPACE;

  addToHistory(
    'reset',
    'all',
    { namespace: oldNamespace, options: oldOptions },
    {
      namespace: state.debugNamespace,
      options: state.options,
    }
  );

  notifyListeners('debug', { namespace: state.debugNamespace, oldValue: oldNamespace });
  notifyListeners('options', { options: state.options, oldValue: oldOptions });
  notifyListeners('change', {
    type: 'reset',
    namespace: state.debugNamespace,
    options: state.options,
    old: { namespace: oldNamespace, options: oldOptions },
  });

  updateDebugStatusUI(state.debugNamespace);

  if (eventHandlers.onChange) {
    try {
      eventHandlers.onChange({
        type: 'reset',
        config: this.debug.getConfig(),
        old: { namespace: oldNamespace, options: oldOptions },
      });
    } catch (e) {}
  }

  console.log('🔍 ENV reset to defaults');
  return this;
};

/**
 * Загрузить настройки из объекта
 */
envObject.load = function (config) {
  if (!config || typeof config !== 'object') return this;

  const changes = [];

  if (config.namespace !== undefined) {
    const oldValue = state.debugNamespace;
    envObject.DEBUG.namespace = config.namespace;
    changes.push({ key: 'namespace', old: oldValue, new: config.namespace });
  }

  if (config.hideDate !== undefined) {
    const oldValue = state.options.hideDate;
    envObject.DEBUG.hideDate = config.hideDate;
    changes.push({ key: 'hideDate', old: oldValue, new: config.hideDate });
  }

  if (config.colors !== undefined) {
    const oldValue = state.options.colors;
    envObject.DEBUG.colors = config.colors;
    changes.push({ key: 'colors', old: oldValue, new: config.colors });
  }

  if (config.depth !== undefined) {
    const oldValue = state.options.depth;
    envObject.DEBUG.depth = config.depth;
    changes.push({ key: 'depth', old: oldValue, new: config.depth });
  }

  if (config.showHidden !== undefined) {
    const oldValue = state.options.showHidden;
    envObject.DEBUG.showHidden = config.showHidden;
    changes.push({ key: 'showHidden', old: oldValue, new: config.showHidden });
  }

  if (changes.length > 0) {
    notifyListeners('change', { type: 'load', changes, config: this.debug.getConfig() });
    if (eventHandlers.onChange) {
      try {
        eventHandlers.onChange({ type: 'load', changes, config: this.debug.getConfig() });
      } catch (e) {}
    }
  }

  return this;
};

// ============================================================
// 10. СОЗДАНИЕ ПРОКСИ
// ============================================================

const ENV = new Proxy(envObject, {
  get(target, prop, receiver) {
    const value = Reflect.get(target, prop, receiver);

    // Если свойство - функция, возвращаем её
    if (typeof value === 'function') {
      return value.bind(target);
    }

    return value;
  },

  set(target, prop, value, receiver) {
    // Обработка прямой установки свойств DEBUG
    if (prop === 'DEBUG') {
      if (value && typeof value === 'object') {
        if (value.namespace !== undefined) {
          target.DEBUG.namespace = value.namespace;
        }
        if (value.hideDate !== undefined) {
          target.DEBUG.hideDate = value.hideDate;
        }
        if (value.colors !== undefined) {
          target.DEBUG.colors = value.colors;
        }
        if (value.depth !== undefined) {
          target.DEBUG.depth = value.depth;
        }
        if (value.showHidden !== undefined) {
          target.DEBUG.showHidden = value.showHidden;
        }
        return true;
      }
      // Если пытаются заменить DEBUG на что-то другое - игнорируем
      console.warn('[ENV] DEBUG cannot be replaced, use ENV.DEBUG.namespace = ...');
      return true;
    }

    return Reflect.set(target, prop, value, receiver);
  },
});

// ============================================================
// 11. ИНИЦИАЛИЗАЦИЯ ГЛОБАЛЬНЫХ ОБЪЕКТОВ
// ============================================================

// Добавляем ENV в глобальный объект
if (GLOBAL) {
  GLOBAL.ENV = ENV;
  GLOBAL.__DEBUG_CONFIG = ENV.DEBUG.config;

  // Добавляем сокращенные команды
  GLOBAL.debug = {
    enable: ns => ENV.debug.enable(ns),
    disable: () => ENV.debug.disable(),
    enabled: ns => ENV.debug.enabled(ns),
    getConfig: () => ENV.debug.getConfig(),
    setOptions: opts => ENV.debug.setOptions(opts),
    help: () => ENV.debug.help(),
    logStatus: () => ENV.debug.logStatus(),
    getHistory: () => ENV.debug.getHistory(),
    clearHistory: () => ENV.debug.clearHistory(),
    on: (type, cb) => ENV.on(type, cb),
    off: (type, cb) => ENV.off(type, cb),
  };

  // Показываем приветствие
  console.log('╔═══════════════════════════════════════════════════════════════════╗');
  console.log('║                    📦 ENV CONFIGURATION LOADED                    ║');
  console.log('╠═══════════════════════════════════════════════════════════════════╣');
  console.log(`║  DEBUG: ${state.debugNamespace || '(none)'}`);
  console.log(`║  Hide Date: ${state.options.hideDate}`);
  console.log(`║  Colors: ${state.options.colors}`);
  console.log(`║  Depth: ${state.options.depth}`);
  console.log(`║  Show Hidden: ${state.options.showHidden}`);
  console.log('╠═══════════════════════════════════════════════════════════════════╣');
  console.log('║  📝 Команды в консоли:                                          ║');
  console.log('║    ENV.debug.enable(\\"wasm:*\\")     - включить все wasm логи      ║');
  console.log('║    ENV.debug.disable()            - отключить логи              ║');
  console.log('║    ENV.debug.help()               - показать справку            ║');
  console.log('║    ENV.debug.logStatus()          - статус debug                ║');
  console.log('║    ENV.debug.getConfig()          - текущая конфигурация        ║');
  console.log('║    ENV.on(\\"debug\\", cb)           - подписка на изменения       ║');
  console.log('║    ENV.getHistory()               - история изменений           ║');
  console.log('╚═══════════════════════════════════════════════════════════════════╝');

  // Показываем статус debug в UI
  setTimeout(() => updateDebugStatusUI(state.debugNamespace), 100);
}

// ============================================================
// 12. ОБРАБОТКА ИЗМЕНЕНИЙ URL ПАРАМЕТРОВ (SPA)
// ============================================================

if (typeof window !== 'undefined') {
  let lastDebugParam = null;

  function checkURLForDebug() {
    const params = new URLSearchParams(window.location.search);
    const debugParam = params.get('debug');

    if (debugParam !== null && debugParam !== state.debugNamespace) {
      const oldValue = state.debugNamespace;
      state.debugNamespace = debugParam;
      persistToStorage('debug', debugParam);
      GLOBAL.DEBUG = debugParam;

      addToHistory('url', 'debug', oldValue, debugParam);
      notifyListeners('debug', { namespace: debugParam, oldValue });
      notifyListeners('change', { type: 'url', namespace: debugParam, oldValue });

      updateDebugStatusUI(debugParam);

      if (eventHandlers.onDebugChange) {
        try {
          eventHandlers.onDebugChange(debugParam, oldValue);
        } catch (e) {}
      }

      console.log(`🔍 Debug updated from URL: ${debugParam}`);
    }
    lastDebugParam = debugParam;
  }

  // Перехват изменений URL
  const originalPushState = window.history.pushState;
  const originalReplaceState = window.history.replaceState;

  window.history.pushState = function (...args) {
    originalPushState.apply(this, args);
    checkURLForDebug();
  };

  window.history.replaceState = function (...args) {
    originalReplaceState.apply(this, args);
    checkURLForDebug();
  };

  window.addEventListener('popstate', checkURLForDebug);
}

// ============================================================
// 13. ОБРАБОТКА ОШИБОК
// ============================================================

if (typeof window !== 'undefined') {
  window.addEventListener('error', event => {
    if (isDebugEnabled('wasm:error', state.debugNamespace)) {
      console.error('[wasm:error]', event.error || event.message);
    }
  });

  window.addEventListener('unhandledrejection', event => {
    if (isDebugEnabled('wasm:error', state.debugNamespace)) {
      console.error('[wasm:error] Unhandled rejection:', event.reason);
    }
  });
}

// ============================================================
// 14. ТЕСТОВЫЕ КОМАНДЫ ДЛЯ РАЗРАБОТКИ
// ============================================================

if (GLOBAL.DEVELOPMENT || GLOBAL.NODE_ENV === 'development') {
  ENV._test = {
    testNamespaces: [
      'wasm:*',
      'wasm:memory:*',
      'wasm:generate:*',
      'wasm:flow:*',
      'wasm:api:*',
      'wasm:error:*',
      'wasm:memory:read,wasm:generate',
      '*, -wasm:memory',
    ],

    testAll() {
      console.log('🧪 Тестирование всех namespace...');
      let results = [];
      for (const ns of this.testNamespaces) {
        ENV.debug.enable(ns);
        results.push({
          namespace: ns,
          enabled: isDebugEnabled('wasm:test', ns),
          config: ENV.debug.getConfig(),
        });
      }
      ENV.debug.disable();
      console.table(results);
      return results;
    },

    testListeners() {
      console.log('🧪 Тестирование слушателей...');
      const log = data => console.log('📢 Event:', data);

      ENV.on('debug', log);
      ENV.on('options', log);
      ENV.on('change', log);

      ENV.debug.enable('test:*');
      ENV.debug.setOptions({ depth: 5 });

      // Отписка
      ENV.off('debug', log);
      ENV.off('options', log);
      ENV.off('change', log);

      console.log('✅ Тест слушателей завершен');
    },

    testHistory() {
      console.log('🧪 Тестирование истории...');
      ENV.debug.clearHistory();

      ENV.debug.enable('wasm:*');
      ENV.debug.setOptions({ depth: 3, hideDate: true });
      ENV.debug.disable();

      const history = ENV.debug.getHistory();
      console.log(`📊 История (${history.length} записей):`);
      console.table(history);
      return history;
    },
  };

  console.log('🧪 Тестовые команды:');
  console.log('  ENV._test.testAll()      - тест всех namespace');
  console.log('  ENV._test.testListeners() - тест слушателей');
  console.log('  ENV._test.testHistory()   - тест истории');
}

// ============================================================
// 15. ЭКСПОРТ
// ============================================================

console.log('✅ env.mjs полностью загружен (с прокси и отслеживанием изменений)');

export default ENV;
