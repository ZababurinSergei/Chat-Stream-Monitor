// web/app.mjs - Main application with debug support

import ENV from './env.mjs';
import debug from './debug.mjs';
import wasmLogger from './wasm-logger.mjs';
import ConfigGenerator from './config_generator.mjs';

// Извлекаем логгеры
const {
  log,
  logMemory,
  logGenerate,
  logApi,
  logError,
  logFlow,
  logStep,
  createFlowLogger,
  measureStep,
  traceFunction,
} = wasmLogger;

// Создаем flow логгер для основного потока
const flow = createFlowLogger('app');

// Получаем глобальный объект
const GLOBAL = typeof globalThis !== 'undefined' ? globalThis : window;

// Передаем ENV в глобальный объект
GLOBAL.ENV = ENV;

let wasmAPI = null;
let isModuleReady = false;

flow.start('Application initialization');

const Module = {
  print(text) {
    log(`[WASM stdout] ${text}`);
    const output = document.getElementById('output');
    if (output) {
      output.innerHTML += `<div class="stdout">${text}</div>`;
    }
  },

  printErr(text) {
    logError(`[WASM stderr] ${text}`);
    const output = document.getElementById('output');
    if (output) {
      output.innerHTML += `<div class="stderr">❌ ${text}</div>`;
    }
  },

  locateFile(path) {
    log(`📍 locateFile: ${path}`);
    return './' + path;
  },

  setStatus(text) {
    const status = document.getElementById('status');
    if (status) {
      if (text) {
        status.textContent = text;
        status.style.display = 'block';
      } else {
        status.style.display = 'none';
      }
    }
    log(`[Status] ${text || 'Готово'}`);
  },

  onAbort(what) {
    logError(`❌ Аварийное завершение: ${what}`);
    const status = document.getElementById('status');
    if (status) {
      status.textContent = `❌ Ошибка: ${what}`;
      status.style.color = 'red';
    }
    showError(`Модуль не загружен: ${what}`);
  },

  onRuntimeInitialized() {
    flow.checkpoint('Runtime initialized');
    log('✅ [onRuntimeInitialized] Модуль готов!');

    const exported = Object.keys(Module).filter(k => k.startsWith('_'));
    log(`🔍 Доступные экспорты: ${exported.join(', ')}`);

    Module.setStatus('Модуль загружен');
    isModuleReady = true;
    hideLoading();
    hideError();

    const controls = document.getElementById('controls');
    if (controls) {
      controls.style.display = 'flex';
    }

    const statusText = document.getElementById('status-text');
    if (statusText) {
      statusText.textContent = '✅ Модуль загружен и готов к работе';
      statusText.style.color = '#00b894';
    }

    wasmAPI = createWasmAPI();
    setupUIHandlers();
  },

  postRun() {
    log('🎯 [postRun] Выполнение завершено');
    Module.setStatus('Готов к работе');
    flow.end('Application initialized');
  },
};

// ============================================
// ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ
// ============================================

function showLoading() {
  const loader = document.getElementById('loader');
  if (loader) {
    loader.style.display = 'block';
  }
  const status = document.getElementById('status');
  if (status) {
    status.textContent = 'Загрузка WASM модуля...';
    status.style.display = 'block';
  }
}

function hideLoading() {
  const loader = document.getElementById('loader');
  if (loader) {
    loader.style.display = 'none';
  }
}

function showError(message) {
  const error = document.getElementById('error');
  if (error) {
    error.textContent = message;
    error.style.display = 'block';
  }
}

function hideError() {
  const error = document.getElementById('error');
  if (error) {
    error.style.display = 'none';
  }
}

// ============================================
// ФУНКЦИЯ ЧТЕНИЯ СТРОК ИЗ ПАМЯТИ С DEBUG
// ============================================

function readStringFromMemory(ptr) {
  const memLogger = flow.wasm.memory;
  logMemory(`🔍 Чтение строки по ptr: ${ptr}`);

  if (!ptr) {
    logMemory('❌ ptr = null');
    return null;
  }

  // Логируем состояние памяти
  const memoryInfo = {
    hasHEAPU8: !!Module.HEAPU8,
    hasMemory: !!Module.memory,
    hasWasmMemory: !!Module.wasmMemory,
    heapU8Length: Module.HEAPU8?.length || 0,
    memoryLength: Module.memory?.buffer?.byteLength || 0,
  };
  logMemory('📊 Состояние памяти: %o', memoryInfo);

  // 1. Через HEAPU8
  if (Module.HEAPU8 && Module.HEAPU8.buffer) {
    logMemory(`  📌 HEAPU8.length: ${Module.HEAPU8.length}`);
    try {
      if (ptr < Module.HEAPU8.length) {
        let end = ptr;
        while (end < Module.HEAPU8.length && Module.HEAPU8[end] !== 0) {
          end++;
        }
        const length = end - ptr;
        logMemory(`  📏 Длина строки: ${length} байт`);

        if (length > 0 && length < 100000) {
          const slice = Module.HEAPU8.slice(ptr, end);
          const decoder = new TextDecoder('utf-8');
          const str = decoder.decode(slice);
          logMemory(`  ✅ Прочитано через HEAPU8: ${str.length} символов`);
          logMemory(
            `  📄 Первые 200 символов: "${str.substring(0, 200)}${str.length > 200 ? '...' : ''}"`
          );
          return str;
        }
      }
    } catch (e) {
      logError(`  ❌ Ошибка HEAPU8: ${e.message}`);
    }
  }

  // 2. Через memory
  if (Module.memory && Module.memory.buffer) {
    try {
      const view = new Uint8Array(Module.memory.buffer);
      if (ptr < view.length) {
        let end = ptr;
        while (end < view.length && view[end] !== 0) {
          end++;
        }
        const length = end - ptr;
        if (length > 0 && length < 100000) {
          const slice = view.slice(ptr, end);
          const decoder = new TextDecoder('utf-8');
          const str = decoder.decode(slice);
          logMemory(`  ✅ Прочитано через memory: ${str.length} символов`);
          return str;
        }
      }
    } catch (e) {
      logError(`  ❌ Ошибка memory: ${e.message}`);
    }
  }

  // 3. Через wasmMemory
  if (Module.wasmMemory && Module.wasmMemory.buffer) {
    try {
      const view = new Uint8Array(Module.wasmMemory.buffer);
      if (ptr < view.length) {
        let end = ptr;
        while (end < view.length && view[end] !== 0) {
          end++;
        }
        const length = end - ptr;
        if (length > 0 && length < 100000) {
          const slice = view.slice(ptr, end);
          const decoder = new TextDecoder('utf-8');
          const str = decoder.decode(slice);
          logMemory(`  ✅ Прочитано через wasmMemory: ${str.length} символов`);
          return str;
        }
      }
    } catch (e) {
      logError(`  ❌ Ошибка wasmMemory: ${e.message}`);
    }
  }

  logMemory(`❌ Не удалось прочитать строку по ptr ${ptr}`);
  return null;
}

// ============================================
// API ДЛЯ РАБОТЫ С МОДУЛЕМ
// ============================================

function createWasmAPI() {
  const apiLogger = flow.branch('api');
  apiLogger.start('Creating WASM API');

  logApi('🔧 Создание WASM API');

  if (!Module) {
    logError('❌ Модуль не инициализирован');
    throw new Error('Модуль не инициализирован');
  }

  const exportedFunctions = Object.keys(Module).filter(k => k.startsWith('_'));
  logApi(`📋 Экспортированные функции: ${exportedFunctions.join(', ')}`);
  apiLogger.checkpoint('Exports found', { count: exportedFunctions.length });

  const api = {
    generateJSON() {
      const step = flow.step('generateJSON');
      step('📄 Генерация JSON...');

      return measureStep(step, 'generateJSON', () => {
        try {
          if (!Module._generate_config_json) {
            const error = 'Function _generate_config_json not found';
            step(`❌ ${error}`);
            logError(`❌ ${error}`);
            logError(
              `  Доступные функции: ${Object.keys(Module)
                .filter(k => k.startsWith('_'))
                .join(', ')}`
            );
            throw new Error(error);
          }

          step('  Вызов _generate_config_json()');
          const ptr = Module._generate_config_json();
          step(`  Получен ptr: ${ptr}`);

          const result = readStringFromMemory(ptr);
          step(`  Результат: ${result ? `получен (${result.length} символов)` : 'NULL'}`);

          if (Module._free_config_string) {
            step('  Освобождение памяти');
            Module._free_config_string(ptr);
          }

          return result;
        } catch (error) {
          step(`❌ Ошибка: ${error.message}`);
          logError(`❌ Ошибка generateJSON: ${error.message}`);
          return null;
        }
      });
    },

    generateC() {
      const step = flow.step('generateC');
      step('⚡ Генерация C header...');

      return measureStep(step, 'generateC', () => {
        try {
          if (!Module._generate_config_c) {
            throw new Error('Function _generate_config_c not found');
          }
          const ptr = Module._generate_config_c();
          const result = readStringFromMemory(ptr);
          if (Module._free_config_string) {
            Module._free_config_string(ptr);
          }
          return result;
        } catch (error) {
          logError(`❌ Ошибка generateC: ${error.message}`);
          return null;
        }
      });
    },

    generateEnv() {
      const step = flow.step('generateEnv');
      step('🌍 Генерация ENV...');

      return measureStep(step, 'generateEnv', () => {
        try {
          if (!Module._generate_config_env) {
            throw new Error('Function _generate_config_env not found');
          }
          const ptr = Module._generate_config_env();
          const result = readStringFromMemory(ptr);
          if (Module._free_config_string) {
            Module._free_config_string(ptr);
          }
          return result;
        } catch (error) {
          logError(`❌ Ошибка generateEnv: ${error.message}`);
          return null;
        }
      });
    },

    generateAll() {
      const step = flow.step('generateAll');
      step('📊 Генерация всех форматов...');

      const results = {
        json: this.generateJSON(),
        c: this.generateC(),
        env: this.generateEnv(),
      };
      step(`  Результаты: JSON=${!!results.json}, C=${!!results.c}, ENV=${!!results.env}`);
      return results;
    },

    isReady() {
      return isModuleReady;
    },
  };

  apiLogger.end('API created');
  return api;
}

// ============================================
// ФУНКЦИИ ДЛЯ РАБОТЫ С МАТРИЦЕЙ (как в C коде)
// ============================================

let matrix = [];
let n = 0;

function rnd(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function inputMatrix(mode) {
  if (mode === 1) {
    for (let i = 0; i < n; i++) {
      matrix[i] = [];
      for (let j = 0; j < n; j++) {
        matrix[i][j] = rnd(-10, 20);
      }
    }
    displayResult('info', '✅ Матрица успешно заполнена случайными числами.');
  } else if (mode === 2) {
    displayResult('info', '📝 Введите элементы матрицы построчно (через пробел):');
    for (let i = 0; i < n; i++) {
      const input = prompt(`Строка ${i + 1} (введите ${n} чисел через пробел):`);
      if (input) {
        const nums = input.trim().split(/\\s+/).map(Number);
        if (nums.length >= n) {
          matrix[i] = nums.slice(0, n);
        } else {
          displayResult('error', `❌ Ошибка: введено меньше ${n} чисел.`);
          return;
        }
      } else {
        displayResult('error', '❌ Ввод отменен.');
        return;
      }
    }
    displayResult('info', '✅ Матрица успешно введена.');
  }
}

function printMatrix() {
  if (!matrix || matrix.length === 0) {
    displayResult('error', '❌ Матрица пуста. Сначала заполните её.');
    return;
  }

  let output = '\\n📊 Матрица:\\n';
  for (let i = 0; i < n; i++) {
    let row = '';
    for (let j = 0; j < n; j++) {
      row += String(matrix[i][j]).padStart(4);
    }
    output += row + '\\n';
  }
  displayResult('matrix', output);
}

function printColumnSums() {
  if (!matrix || matrix.length === 0) {
    displayResult('error', '❌ Матрица пуста. Сначала заполните её.');
    return;
  }

  let output = '\\n📊 Суммы элементов по столбцам:\\n';
  for (let j = 0; j < n; j++) {
    let col_sum = 0;
    for (let i = 0; i < n; i++) {
      col_sum += matrix[i][j];
    }
    output += `Столбец ${j + 1}: ${col_sum}\\n`;
  }
  displayResult('info', output);
}

function sumBelowDiagonalAbs() {
  if (!matrix || matrix.length === 0) {
    displayResult('error', '❌ Матрица пуста. Сначала заполните её.');
    return;
  }

  let sum = 0;
  for (let i = 0; i < n; i++) {
    for (let j = 0; j < n; j++) {
      if (i > j) {
        sum += Math.abs(matrix[i][j]);
      }
    }
  }
  displayResult('info', `📊 Сумма модулей элементов ниже главной диагонали: ${sum}`);
}

// ============================================
// ИНИЦИАЛИЗАЦИЯ МАТРИЦЫ
// ============================================

function initMatrix(size) {
  n = size;
  matrix = [];
  for (let i = 0; i < n; i++) {
    matrix[i] = [];
    for (let j = 0; j < n; j++) {
      matrix[i][j] = 0;
    }
  }
}

// ============================================
// UI ОБРАБОТЧИКИ
// ============================================

function setupUIHandlers() {
  // === Кнопки для матрицы ===

  const btnRandom = document.getElementById('btn-random');
  if (btnRandom) {
    btnRandom.addEventListener('click', () => {
      const sizeInput = document.getElementById('matrix-size');
      if (sizeInput) {
        n = parseInt(sizeInput.value) || 3;
        if (n <= 0) {
          displayResult('error', '❌ Некорректный размер матрицы.');
          return;
        }
        initMatrix(n);
        inputMatrix(1);
        displayResult('info', `✅ Матрица ${n}x${n} заполнена случайными числами.`);
      }
    });
  }

  const btnManual = document.getElementById('btn-manual');
  if (btnManual) {
    btnManual.addEventListener('click', () => {
      const sizeInput = document.getElementById('matrix-size');
      if (sizeInput) {
        n = parseInt(sizeInput.value) || 3;
        if (n <= 0) {
          displayResult('error', '❌ Некорректный размер матрицы.');
          return;
        }
        initMatrix(n);
        inputMatrix(2);
      }
    });
  }

  const btnPrint = document.getElementById('btn-print');
  if (btnPrint) {
    btnPrint.addEventListener('click', () => {
      printMatrix();
    });
  }

  const btnColSums = document.getElementById('btn-col-sums');
  if (btnColSums) {
    btnColSums.addEventListener('click', () => {
      printColumnSums();
    });
  }

  const btnDiagSum = document.getElementById('btn-diag-sum');
  if (btnDiagSum) {
    btnDiagSum.addEventListener('click', () => {
      sumBelowDiagonalAbs();
    });
  }

  // === Кнопки для WASM ===

  const btnJSON = document.getElementById('btn-generate-json');
  if (btnJSON) {
    btnJSON.addEventListener('click', () => {
      if (!wasmAPI || !wasmAPI.isReady()) {
        showError('Модуль еще не загружен');
        return;
      }

      const result = wasmAPI.generateJSON();
      displayResult('json', result);
    });
  }

  const btnC = document.getElementById('btn-generate-c');
  if (btnC) {
    btnC.addEventListener('click', () => {
      if (!wasmAPI || !wasmAPI.isReady()) {
        showError('Модуль еще не загружен');
        return;
      }
      const result = wasmAPI.generateC();
      displayResult('c', result);
    });
  }

  const btnEnv = document.getElementById('btn-generate-env');
  if (btnEnv) {
    btnEnv.addEventListener('click', () => {
      if (!wasmAPI || !wasmAPI.isReady()) {
        showError('Модуль еще не загружен');
        return;
      }
      const result = wasmAPI.generateEnv();
      displayResult('env', result);
    });
  }

  const btnAll = document.getElementById('btn-generate-all');
  if (btnAll) {
    btnAll.addEventListener('click', () => {
      if (!wasmAPI || !wasmAPI.isReady()) {
        showError('Модуль еще не загружен');
        return;
      }
      const results = wasmAPI.generateAll();
      displayResult('all', results);
    });
  }

  const btnClear = document.getElementById('btn-clear');
  if (btnClear) {
    btnClear.addEventListener('click', () => {
      const output = document.getElementById('output');
      if (output) {
        output.innerHTML = '';
      }
    });
  }

  const btnClearMatrix = document.getElementById('btn-clear-matrix');
  if (btnClearMatrix) {
    btnClearMatrix.addEventListener('click', () => {
      matrix = [];
      n = 0;
      displayResult('info', '🧹 Матрица очищена.');
    });
  }
}

// ============================================
// ОТОБРАЖЕНИЕ РЕЗУЛЬТАТОВ
// ============================================

function displayResult(type, data) {
  const output = document.getElementById('output');
  if (!output) {
    return;
  }

  const block = document.createElement('div');
  block.className = 'result-block';

  const header = document.createElement('div');
  header.className = 'result-header';

  const timestamp = new Date().toLocaleTimeString();

  const typeNames = {
    json: '📄 JSON конфигурация',
    c: '⚡ C Header',
    env: '🌍 ENV',
    all: '📊 Все форматы',
    matrix: '📊 Матрица',
    info: 'ℹ️ Информация',
    error: '❌ Ошибка',
  };

  header.textContent = `${typeNames[type] || type.toUpperCase()} [${timestamp}]:`;

  const content = document.createElement('pre');
  content.className = 'result-content';

  if (type === 'all') {
    content.textContent = JSON.stringify(data, null, 2);
  } else if (type === 'json' || type === 'c' || type === 'env') {
    if (typeof data === 'string') {
      try {
        const parsed = JSON.parse(data);
        content.textContent = JSON.stringify(parsed, null, 2);
      } catch {
        content.textContent = data;
      }
    } else {
      content.textContent = String(data);
    }
  } else {
    content.textContent = String(data);
  }

  const copyBtn = document.createElement('button');
  copyBtn.textContent = '📋 Копировать';
  copyBtn.className = 'copy-btn';
  copyBtn.addEventListener('click', function () {
    navigator.clipboard
      .writeText(content.textContent)
      .then(() => {
        this.textContent = '✅ Скопировано!';
        setTimeout(() => {
          this.textContent = '📋 Копировать';
        }, 2000);
      })
      .catch(() => {
        const range = document.createRange();
        range.selectNode(content);
        window.getSelection().removeAllRanges();
        window.getSelection().addRange(range);
        document.execCommand('copy');
        this.textContent = '✅ Скопировано!';
        setTimeout(() => {
          this.textContent = '📋 Копировать';
        }, 2000);
      });
  });

  block.appendChild(header);
  block.appendChild(content);
  block.appendChild(copyBtn);

  output.insertBefore(block, output.firstChild);

  const maxBlocks = 50;
  while (output.children.length > maxBlocks) {
    output.removeChild(output.lastChild);
  }
}

function generateAllConfigs() {
  if (!wasmAPI || !wasmAPI.isReady()) {
    return;
  }

  console.log('📊 Генерация всех конфигураций...');
  try {
    const results = wasmAPI.generateAll();
    if (results.json) {
      displayResult('json', results.json);
    }
  } catch (error) {
    console.error('Ошибка генерации:', error);
  }
}

// ============================================
// ЗАГРУЗКА WASM МОДУЛЯ
// ============================================

async function loadWasmModule() {
  showLoading();
  hideError();

  try {
    log('⏳ Загрузка WASM модуля...');

    const moduleInstance = await ConfigGenerator(Module);

    // Сохраняем ссылки на экспорты
    Module._generate_config_json = moduleInstance._generate_config_json;
    Module._generate_config_c = moduleInstance._generate_config_c;
    Module._generate_config_env = moduleInstance._generate_config_env;
    Module._free_config_string = moduleInstance._free_config_string;

    // Сохраняем ссылку на память
    Module.wasmMemory = moduleInstance.wasmMemory || moduleInstance.memory;
    Module.memory = moduleInstance.memory;

    // Вызываем onRuntimeInitialized если он есть
    if (moduleInstance.onRuntimeInitialized) {
      moduleInstance.onRuntimeInitialized();
    }

    log('✅ WASM модуль загружен!');
  } catch (error) {
    logError(`❌ Ошибка загрузки WASM: ${error.message}`);
    showError(`Ошибка загрузки модуля: ${error.message}`);
    hideLoading();

    const statusText = document.getElementById('status-text');
    if (statusText) {
      statusText.textContent = `❌ Ошибка: ${error.message}`;
      statusText.style.color = '#ff6b6b';
    }
  }
}

// ============================================
// ИНИЦИАЛИЗАЦИЯ
// ============================================

document.addEventListener('DOMContentLoaded', () => {
  log('📄 DOM загружен, инициализация...');

  const statusText = document.getElementById('status-text');
  if (statusText) {
    statusText.textContent = '⏳ Загрузка WASM модуля...';
    statusText.style.color = '#fdcb6e';
  }

  loadWasmModule();

  log('✅ Модуль настроен, ожидаем загрузки WASM...');
});

// ============================================
// ОБРАБОТКА ОШИБОК
// ============================================

window.addEventListener('error', event => {
  logError(`Глобальная ошибка: ${event.error || event.message}`);
  showError(`Ошибка: ${event.message || 'Неизвестная ошибка'}`);
  hideLoading();
});

window.addEventListener('unhandledrejection', event => {
  logError(`Необработанное обещание: ${event.reason}`);
  showError(`Ошибка: ${event.reason || 'Неизвестная ошибка'}`);
});

// ============================================
// ГЛОБАЛЬНЫЙ ДОСТУП ДЛЯ ОТЛАДКИ
// ============================================

GLOBAL.WasmAPI = {
  getInstance() {
    return wasmAPI;
  },
  isReady() {
    return isModuleReady;
  },
  generateJSON() {
    return wasmAPI?.generateJSON();
  },
  generateC() {
    return wasmAPI?.generateC();
  },
  generateEnv() {
    return wasmAPI?.generateEnv();
  },
  generateAll() {
    return wasmAPI?.generateAll();
  },
  debug: {
    enable: ns => ENV.debug.enable(ns),
    disable: () => ENV.debug.disable(),
    enabled: ns => ENV.debug.enabled(ns),
    getConfig: () => ENV.debug.getConfig(),
    flow: flow,
  },
  matrix: {
    get: () => matrix,
    getSize: () => n,
    setSize: size => {
      n = size;
      initMatrix(n);
    },
    random: () => {
      inputMatrix(1);
    },
    print: () => printMatrix(),
    columnSums: () => printColumnSums(),
    diagSum: () => sumBelowDiagonalAbs(),
    clear: () => {
      matrix = [];
      n = 0;
    },
  },
};

GLOBAL.benchmarkWasm = function (count = 100) {
  if (!wasmAPI || !wasmAPI.isReady()) {
    console.error('Модуль не готов');
    return;
  }

  console.log(`🚀 Бенчмарк: генерация ${count} раз...`);
  const start = performance.now();

  for (let i = 0; i < count; i++) {
    wasmAPI.generateJSON();
  }

  const end = performance.now();
  const time = (end - start).toFixed(2);
  console.log(`✅ ${count} генераций за ${time}ms (${(time / count).toFixed(2)}ms за одну)`);

  return { count, time, avg: time / count };
};

log('📦 app.mjs загружен');
log('📝 Доступные команды в консоли:');
log('  ENV.debug.enable("wasm:*")    - включить все wasm логи');
log('  ENV.debug.enable("wasm:flow:*") - включить логи потока');
log('  ENV.debug.disable()           - отключить логи');
log('  WasmAPI.generateJSON()        - сгенерировать JSON');
log('  WasmAPI.debug.flow.step()     - добавить шаг в flow');
log('  WasmAPI.matrix.random()       - заполнить матрицу');
log('  WasmAPI.matrix.print()        - вывести матрицу');
log('  WasmAPI.matrix.columnSums()   - суммы по столбцам');
log('  WasmAPI.matrix.diagSum()      - сумма ниже диагонали');
log('  WasmAPI.matrix.setSize(N)     - изменить размер матрицы');
log('  benchmarkWasm(100)            - бенчмарк WASM');
