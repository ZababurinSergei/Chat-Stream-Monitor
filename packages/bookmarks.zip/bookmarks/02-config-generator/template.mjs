// packages/mtproto-mqtt-gateway/metaflow/02-config-generator/template.mjs
// 100% СИМВОЛЫ — полная изоляция и безопасность
// Версия: 2.0.3
// ИСПРАВЛЕНО: Обработка ошибок парсинга для файлов с синтаксическими ошибками
// ДОБАВЛЕНО: Отображение количества синтаксических ошибок в AST

// ============================================================
// 1. ПРИВАТНЫЕ СИМВОЛЫ (100% изоляция)
// ============================================================

const PRIVATE = {
  // Основные символы
  CONFIG: Symbol('template.config'),
  LOGGER: Symbol('template.logger'),
  STATE: Symbol('template.state'),
  CACHE: Symbol('template.cache'),
  VERSION: Symbol('template.version'),
  BUILD: Symbol('template.build'),
  INITIALIZED: Symbol('template.initialized'),
  IS_DESTROYED: Symbol('template.isDestroyed'),

  // Данные
  CODE: Symbol('template.code'),
  FILENAME: Symbol('template.filename'),
  LANGUAGE: Symbol('template.language'),
  LINE_COUNT: Symbol('template.lineCount'),
  EXT: Symbol('template.ext'),
  CONTEXT: Symbol('template.context'),

  // Метаданные
  METADATA: Symbol('template.metadata'),
  LOG_HISTORY: Symbol('template.logHistory'),

  // Слушатели
  LISTENERS: Symbol('template.listeners'),
  EVENT_HANDLERS: Symbol('template.eventHandlers'),

  // Безопасность
  SECURE: Symbol('template.secure'),
  VALIDATOR: Symbol('template.validator'),

  // Методы
  INIT: Symbol('template.init'),
  RENDER: Symbol('template.render'),
  ESCAPE: Symbol('template.escape'),
  GET_STATE: Symbol('template.getState'),
  RESET: Symbol('template.reset'),
  DESTROY: Symbol('template.destroy'),
  GENERATE_HTML: Symbol('template.generateHtml'),
  GENERATE_HEADER: Symbol('template.generateHeader'),
  GENERATE_TABS: Symbol('template.generateTabs'),
  GENERATE_MAIN: Symbol('template.generateMain'),
  GENERATE_COMPARE: Symbol('template.generateCompare'),
  GENERATE_HISTORY: Symbol('template.generateHistory'),
  GENERATE_FOOTER: Symbol('template.generateFooter'),
  GENERATE_STYLES: Symbol('template.generateStyles'),
  GENERATE_SCRIPTS: Symbol('template.generateScripts'),
  DETECT_EXT: Symbol('template.detectExt'),
  DETECT_LANGUAGE: Symbol('template.detectLanguage'),
  GET_LANGUAGE_COLOR: Symbol('template.getLanguageColor'),
  GET_CACHE_KEY: Symbol('template.getCacheKey'),
  ERROR_PAGE: Symbol('template.errorPage'),
  EXPORT_SYMBOLS: Symbol('template.exportSymbols'),
  COUNT_ERRORS: Symbol('template.countErrors'),
  COUNT_ALL_NODES: Symbol('template.countAllNodes'),
  RENDER_NODE: Symbol('template.renderNode'),
  NODE_TO_JSON: Symbol('template.nodeToJSON'),
  FORMAT_JSON: Symbol('template.formatJSON'),
  UPDATE_STATS: Symbol('template.updateStats'),
  PARSE_CODE: Symbol('template.parseCode'),
  COMPUTE_DIFF: Symbol('template.computeDiff'),
  UPDATE_DIFF_UI: Symbol('template.updateDiffUI'),
  UPDATE_DIFF_OVERLAY: Symbol('template.updateDiffOverlay'),
  SAVE_HISTORY: Symbol('template.saveHistory'),
  UPDATE_HISTORY_UI: Symbol('template.updateHistoryUI'),
  GENERATE_GIT_PATCH: Symbol('template.generateGitPatch'),
  DOWNLOAD_FILE: Symbol('template.downloadFile'),
};

// ============================================================
// 2. ПУБЛИЧНЫЕ СИМВОЛЫ (доступны через Symbol.for)
// ============================================================

const PUBLIC = {
  API: Symbol.for('template.api'),
  STATE: Symbol.for('template.state'),
  CONFIG: Symbol.for('template.config'),
  LOGGER: Symbol.for('template.logger'),
  INSTANCE: Symbol.for('template.instance'),
  EVENTS: Symbol.for('template.events'),
  RENDER: Symbol.for('template.render'),
};

// ============================================================
// 3. КОНФИГУРАЦИЯ
// ============================================================

const DEFAULT_CONFIG = {
  version: '2.0.3',
  build: '2026-07-20',
  debug: true,
  maxCacheSize: 100,
  cacheTTL: 3600000,
  treeSitterVersion: '0.26.11',
  treeSitterJavaScriptVersion: '0.23.1',
  defaultLanguage: 'javascript',
};

// ============================================================
// 4. КАРТА ЯЗЫКОВ
// ============================================================

const LANGUAGE_MAP = {
  '.js': 'javascript',
  '.mjs': 'javascript',
  '.cjs': 'javascript',
  '.ts': 'typescript',
  '.vue': 'vue',
  '.html': 'html',
  '.htm': 'html',
  '.css': 'css',
  '.scss': 'scss',
  '.json': 'json',
  '.c': 'c',
  '.h': 'c',
  '.cpp': 'cpp',
  '.cc': 'cpp',
  '.hpp': 'cpp',
  '.cxx': 'cpp',
  '.sh': 'shell',
  '.bash': 'shell',
  '.md': 'markdown',
  '.txt': 'text',
  '.xml': 'xml',
  '.svg': 'xml',
  '.yaml': 'yaml',
  '.yml': 'yaml',
  '.toml': 'toml',
  '.py': 'python',
  '.rb': 'ruby',
  '.go': 'go',
  '.rs': 'rust',
  '.swift': 'swift',
  '.kt': 'kotlin',
  '.java': 'java',
  '.php': 'php',
  '.lua': 'lua',
  '.r': 'r',
  '.sql': 'sql',
};

// ============================================================
// 5. ЦВЕТА ДЛЯ ЯЗЫКОВ
// ============================================================

const LANGUAGE_COLORS = {
  javascript: '#f7df1e',
  typescript: '#3178c6',
  vue: '#41b883',
  html: '#e34f26',
  css: '#264de4',
  c: '#4169e1',
  cpp: '#00599c',
  json: '#f5a623',
  shell: '#4ec9b0',
  python: '#3776ab',
  ruby: '#cc342d',
  go: '#00add8',
  rust: '#dea584',
  swift: '#fa7340',
  kotlin: '#7f52ff',
  java: '#007396',
  php: '#777bb3',
  lua: '#000080',
  sql: '#00758f',
  markdown: '#083fa1',
  text: '#808080',
};

// ============================================================
// 6. ЛОГГЕР (100% СИМВОЛЫ)
// ============================================================

const LOGGER_SYMBOLS = {
  HISTORY: Symbol('logger.history'),
  MAX_HISTORY: Symbol('logger.maxHistory'),
  DEBUG: Symbol('logger.debug'),
  INSTANCE_ID: Symbol('logger.instanceId'),
};

function createLogger(debug = true, instanceId = 'Template') {
  const state = {
    [LOGGER_SYMBOLS.HISTORY]: [],
    [LOGGER_SYMBOLS.MAX_HISTORY]: 200,
    [LOGGER_SYMBOLS.DEBUG]: debug,
    [LOGGER_SYMBOLS.INSTANCE_ID]: instanceId,
  };

  const logMethod = function (level, message, data = null) {
    if (!this[LOGGER_SYMBOLS.DEBUG] && level !== 'error') {
      return;
    }

    const timestamp = new Date().toISOString().slice(11, 23);
    const prefix = `[${timestamp}] [${this[LOGGER_SYMBOLS.INSTANCE_ID]}]`;

    this[LOGGER_SYMBOLS.HISTORY].push({ timestamp, level, message, data });
    if (this[LOGGER_SYMBOLS.HISTORY].length > this[LOGGER_SYMBOLS.MAX_HISTORY]) {
      this[LOGGER_SYMBOLS.HISTORY].shift();
    }

    if (data !== null && data !== undefined) {
      console.log(`${prefix} ${message}`, data);
    } else {
      console.log(`${prefix} ${message}`);
    }
  };

  const boundLog = logMethod.bind(state);

  const methods = {
    error: function (msg, d) {
      boundLog('error', `❌ ${msg}`, d);
    },
    warn: function (msg, d) {
      boundLog('warn', `⚠️ ${msg}`, d);
    },
    info: function (msg, d) {
      boundLog('info', `ℹ️ ${msg}`, d);
    },
    debug: function (msg, d) {
      boundLog('debug', `🔍 ${msg}`, d);
    },
    success: function (msg, d) {
      boundLog('info', `✅ ${msg}`, d);
    },

    header: function (title) {
      console.log('%c' + '═'.repeat(70), 'color: #636e72;');
      console.log(
          '%c  📦 ' + title,
          'background: #1a1a2e; color: #fff; padding: 4px 12px; border-radius: 4px; font-weight: bold;'
      );
      console.log('%c' + '═'.repeat(70), 'color: #636e72;');
    },

    separator: function () {
      console.log('%c' + '─'.repeat(70), 'color: #636e72;');
    },

    symbol: function (name, symbol) {
      console.log(`  🔑 ${name}: ${String(symbol)}`);
    },

    private: function (name, symbol) {
      console.log(`  🔒 ${name}: ${String(symbol)}`);
    },

    getHistory: function () {
      return [...this[LOGGER_SYMBOLS.HISTORY]];
    },

    clearHistory: function () {
      this[LOGGER_SYMBOLS.HISTORY] = [];
      return this;
    },

    setDebug: function (enabled) {
      this[LOGGER_SYMBOLS.DEBUG] = enabled;
      return this;
    },
  };

  const logger = {};
  for (const [key, fn] of Object.entries(methods)) {
    logger[key] = fn.bind(state);
  }

  logger[LOGGER_SYMBOLS.HISTORY] = state[LOGGER_SYMBOLS.HISTORY];
  logger[LOGGER_SYMBOLS.MAX_HISTORY] = state[LOGGER_SYMBOLS.MAX_HISTORY];
  logger[LOGGER_SYMBOLS.DEBUG] = state[LOGGER_SYMBOLS.DEBUG];
  logger[LOGGER_SYMBOLS.INSTANCE_ID] = state[LOGGER_SYMBOLS.INSTANCE_ID];

  return logger;
}

// ============================================================
// 7. ВАЛИДАТОР (100% СИМВОЛЫ)
// ============================================================

const VALIDATOR = {
  [PRIVATE.VALIDATOR]: {
    isValidCode: (code) => code && typeof code === 'string',
    isValidFilename: (name) => name && typeof name === 'string' && name.length > 0,
    isValidLanguage: (lang) => lang && typeof lang === 'string' && lang.length > 0,
    isValidLineCount: (count) => typeof count === 'number' && count >= 0,
    isValidConfig: (config) => config && typeof config === 'object',
    isValidCallback: (fn) => typeof fn === 'function',
  },
  [PRIVATE.SECURE]: {
    sanitize: (value) => {
      if (value === null || value === undefined) return null;
      if (typeof value === 'string') return value.replace(/[<>]/g, '');
      if (typeof value === 'object') {
        try {
          return JSON.parse(JSON.stringify(value));
        } catch {
          return null;
        }
      }
      return value;
    },
    escapeHtml: (text) => {
      if (!text) return '';
      return text
          .replace(/&/g, '&amp;')
          .replace(/</g, '&lt;')
          .replace(/>/g, '&gt;')
          .replace(/"/g, '&quot;')
          .replace(/'/g, '&#039;');
    },
    escapeJs: (text) => {
      if (!text) return '';
      return text
          .replace(/\\/g, '\\\\')
          .replace(/`/g, '\\`')
          .replace(/\$/g, '\\$')
          .replace(/\\r/g, '')
          .replace(/\\n/g, '\\n');
    },
  },
};

// ============================================================
// 8. ОСНОВНОЙ КЛАСС ШАБЛОНА (100% СИМВОЛЫ)
// ============================================================

class Template {
  constructor(options = {}) {
    // Используем обычные свойства вместо геттеров
    this._config = { ...DEFAULT_CONFIG, ...options };
    this._version = options.version || DEFAULT_CONFIG.version;
    this._build = options.build || DEFAULT_CONFIG.build;
    this._logger = createLogger(this._config.debug !== false, 'Template');

    const logger = this._logger;

    this._state = {
      code: '',
      filename: '',
      language: '',
      lineCount: 0,
      ext: '',
      initialized: false,
      destroyed: false,
      lastRender: null,
      renderCount: 0,
    };

    this._cache = new Map();
    this._metadata = {
      created: Date.now(),
      lastAccess: Date.now(),
      lastUpdate: Date.now(),
      renderCount: 0,
      errorCount: 0,
    };
    this._logHistory = [];
    this._listeners = [];
    this._eventHandlers = new Map();
    this._context = {
      url: typeof window !== 'undefined' ? window.location.href : '',
      title: typeof window !== 'undefined' ? document.title : '',
    };

    this[PRIVATE.INIT]();
    this[PRIVATE.EXPORT_SYMBOLS]();

    logger.success('✅ Шаблон создан (100% символы)');
    logger.header('ГОТОВ');
  }

  // ============================================================
  // 9. ИНИЦИАЛИЗАЦИЯ
  // ============================================================

  [PRIVATE.INIT]() {
    const logger = this._logger;
    logger.header('СОЗДАНИЕ ШАБЛОНА (100% СИМВОЛЫ)');
    logger.info(`📦 Версия: ${this._version}`);
    logger.info(`📅 Сборка: ${this._build}`);
    logger.info(`📌 Отладка: ${this._config.debug ? '✅' : '❌'}`);
    logger.separator();
    logger.info(`🔑 ПРИВАТНЫХ СИМВОЛОВ: ${Object.keys(PRIVATE).length}`);
    logger.info(`🔑 ПУБЛИЧНЫХ СИМВОЛОВ: ${Object.keys(PUBLIC).length}`);
    logger.separator();

    this._state.initialized = true;
  }

  // ============================================================
  // 10. ЭКСПОРТ СИМВОЛОВ
  // ============================================================

  [PRIVATE.EXPORT_SYMBOLS]() {
    if (typeof window !== 'undefined') {
      window.__template = this;
      window[PUBLIC.API] = this;
      window[PUBLIC.STATE] = this[PRIVATE.GET_STATE].bind(this);
      window[PUBLIC.CONFIG] = this._config;
      window[PUBLIC.LOGGER] = this._logger;
      window[PUBLIC.INSTANCE] = this;
      window[PUBLIC.RENDER] = this.render.bind(this);
      window[PUBLIC.EVENTS] = {
        on: this.on.bind(this),
        off: this.off.bind(this),
        emit: this.emit.bind(this),
      };

      window.__templateSymbols = {
        PRIVATE: { ...PRIVATE },
        PUBLIC: { ...PUBLIC },
        version: this._version,
        build: this._build,
      };
    }
  }

  // ============================================================
  // 11. ОСНОВНОЙ МЕТОД РЕНДЕРИНГА
  // ============================================================

  render(code, fileInfo = {}) {
    const logger = this._logger;
    logger.header('РЕНДЕРИНГ ШАБЛОНА');

    if (!VALIDATOR[PRIVATE.VALIDATOR].isValidCode(code)) {
      const error = 'Код не может быть пустым';
      logger.error(`❌ ${error}`);
      return this[PRIVATE.ERROR_PAGE](error);
    }

    const filename = fileInfo.filename || 'code';
    const ext = fileInfo.ext || this[PRIVATE.DETECT_EXT](filename);
    const language = fileInfo.language || this[PRIVATE.DETECT_LANGUAGE](ext);
    const lineCount = fileInfo.lineCount || code.split('\n').length;

    this._state.code = code;
    this._state.filename = filename;
    this._state.language = language;
    this._state.lineCount = lineCount;
    this._state.ext = ext;
    this._state.lastRender = Date.now();
    this._state.renderCount++;
    this._metadata.renderCount++;
    this._metadata.lastUpdate = Date.now();

    logger.info(`📄 Файл: ${filename}`);
    logger.info(`📋 Язык: ${language}`);
    logger.info(`📏 Строк: ${lineCount}`);
    logger.info(`📐 Размер: ${code.length} символов`);

    const cacheKey = this[PRIVATE.GET_CACHE_KEY](code, filename, language);
    if (this._cache.has(cacheKey)) {
      const cached = this._cache.get(cacheKey);
      if (Date.now() - cached.timestamp < this._config.cacheTTL) {
        logger.debug('📦 Используем кешированную версию');
        return cached.html;
      }
      this._cache.delete(cacheKey);
    }

    const html = this[PRIVATE.GENERATE_HTML](code, filename, language, lineCount, ext);

    if (code.length < 100 * 1024) {
      this._cache.set(cacheKey, {
        html,
        timestamp: Date.now(),
        size: html.length,
      });
      if (this._cache.size > this._config.maxCacheSize) {
        const keys = Array.from(this._cache.keys());
        for (let i = 0; i < Math.floor(keys.length / 2); i++) {
          this._cache.delete(keys[i]);
        }
      }
    }

    logger.success(`✅ Шаблон отрендерен (${html.length} символов)`);
    logger.header('ГОТОВ');

    return html;
  }

  // ============================================================
  // 12. ГЕНЕРАЦИЯ HTML
  // ============================================================

  [PRIVATE.GENERATE_HTML](code, filename, language, lineCount, ext) {
    const escapedCode = VALIDATOR[PRIVATE.SECURE].escapeJs(code);
    const color = this[PRIVATE.GET_LANGUAGE_COLOR](language);

    const styles = this[PRIVATE.GENERATE_STYLES]();
    const scripts = this[PRIVATE.GENERATE_SCRIPTS](code, filename, language);

    return `<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>📄 ${filename} — Tree-sitter Code Viewer</title>
    <style>${styles}</style>
</head>
<body>
    ${this[PRIVATE.GENERATE_HEADER](filename, language, lineCount, color)}
    ${this[PRIVATE.GENERATE_TABS]()}
    ${this[PRIVATE.GENERATE_MAIN](escapedCode)}
    ${this[PRIVATE.GENERATE_COMPARE]()}
    ${this[PRIVATE.GENERATE_HISTORY]()}
    ${this[PRIVATE.GENERATE_FOOTER](code.length, lineCount)}

    <script type="importmap">
    {
        "imports": {
            "web-tree-sitter": "https://cdn.jsdelivr.net/npm/web-tree-sitter@${this._config.treeSitterVersion}/web-tree-sitter.js"
        }
    }
    </script>

    <script type="module">
    ${scripts}
    </script>
</body>
</html>`;
  }

  // ============================================================
  // 13. ГЕНЕРАЦИЯ СТИЛЕЙ
  // ============================================================

  [PRIVATE.GENERATE_STYLES]() {
    return `
* { margin: 0; padding: 0; box-sizing: border-box; }
body { font-family: 'Segoe UI', system-ui, sans-serif; background: #1e1e1e; color: #d4d4d4; height: 100vh; display: flex; flex-direction: column; overflow: hidden; }
.header { background: #252526; padding: 6px 16px; border-bottom: 1px solid #3c3c3c; display: flex; justify-content: space-between; align-items: center; flex-shrink: 0; flex-wrap: wrap; gap: 6px; min-height: 40px; }
.header h1 { font-size: 14px; font-weight: 600; display: flex; align-items: center; gap: 8px; color: #cccccc; }
.header h1 small { font-size: 11px; font-weight: 400; color: #808080; }
.header .file-info { display: flex; gap: 12px; font-size: 11px; color: #808080; }
.header .file-info .lang { color: #4ec9b0; }
.lang-tag { display: inline-block; padding: 1px 8px; border-radius: 10px; font-size: 10px; font-weight: 600; background: rgba(78, 201, 176, 0.15); color: #4ec9b0; }
.lang-tag.javascript { background: rgba(247, 223, 30, 0.15); color: #f7df1e; }
.lang-tag.typescript { background: rgba(49, 120, 198, 0.2); color: #3178c6; }
.lang-tag.vue { background: rgba(65, 184, 131, 0.2); color: #41b883; }
.lang-tag.html { background: rgba(227, 79, 38, 0.2); color: #e34f26; }
.lang-tag.css { background: rgba(38, 77, 228, 0.2); color: #264de4; }
.lang-tag.c { background: rgba(65, 105, 225, 0.2); color: #4169e1; }
.lang-tag.json { background: rgba(0, 0, 0, 0.3); color: #f5a623; }
.controls { display: flex; gap: 6px; align-items: center; flex-wrap: wrap; }
.status { display: flex; align-items: center; gap: 6px; font-size: 11px; padding: 3px 10px; border-radius: 12px; background: #2d2d2d; }
.status-dot { width: 8px; height: 8px; border-radius: 50%; display: inline-block; }
.status-dot.loading { background: #f0883e; animation: pulse 1.5s ease-in-out infinite; }
.status-dot.ready { background: #4ec9b0; }
.status-dot.error { background: #f48771; }
@keyframes pulse { 0%, 100% { opacity: 1; } 50% { opacity: 0.3; } }
.main-tabs { display: flex; background: #252526; border-bottom: 1px solid #3c3c3c; flex-shrink: 0; padding: 0 12px; gap: 0; }
.main-tab { padding: 6px 14px; color: #808080; cursor: pointer; border-bottom: 2px solid transparent; font-size: 12px; transition: all 0.2s; background: none; border-top: none; border-left: none; border-right: none; font-family: inherit; }
.main-tab:hover { color: #cccccc; }
.main-tab.active { color: #e6e6e6; border-bottom-color: #007acc; }
.main-container { display: flex; flex: 1; overflow: hidden; }
.pane { flex: 1; display: flex; flex-direction: column; border-right: 1px solid #3c3c3c; min-width: 200px; }
.pane:last-child { border-right: none; }
.pane-header { padding: 4px 12px; background: #252526; border-bottom: 1px solid #3c3c3c; font-size: 11px; font-weight: 500; color: #808080; display: flex; justify-content: space-between; align-items: center; flex-shrink: 0; min-height: 28px; }
.pane-content { flex: 1; overflow: hidden; position: relative; }
.pane-content > div { display: none; width: 100%; height: 100%; overflow: auto; }
.pane-content > div.active { display: block; }
.resize-handle { width: 4px; background: transparent; cursor: col-resize; flex-shrink: 0; transition: background 0.2s; position: relative; }
.resize-handle:hover, .resize-handle.active { background: #007acc; }
.editor-container { position: relative; height: 100%; background: #1e1e1e; }
#code-input { width: 100%; height: 100%; padding: 12px 16px; background: #1e1e1e; color: #d4d4d4; border: none; outline: none; resize: none; font-family: 'JetBrains Mono', 'Fira Code', 'Consolas', monospace; font-size: 13px; line-height: 1.7; tab-size: 2; }
#code-input::selection { background: #264f78; }
#code-input:focus { box-shadow: inset 0 0 0 1px #007acc; }
.copy-btn { position: absolute; top: 8px; right: 8px; background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); color: #808080; padding: 2px 10px; border-radius: 4px; font-size: 10px; cursor: pointer; transition: all 0.2s; font-family: inherit; z-index: 10; }
.copy-btn:hover { background: rgba(255,255,255,0.1); color: #d4d4d4; }
.copy-btn.copied { background: rgba(78, 201, 176, 0.2); color: #4ec9b0; border-color: #4ec9b0; }
.diff-overlay { position: absolute; top: 0; left: 0; right: 0; bottom: 0; pointer-events: none; overflow: hidden; padding: 12px 16px; font-family: 'JetBrains Mono', 'Fira Code', 'Consolas', monospace; font-size: 13px; line-height: 1.7; white-space: pre-wrap; color: transparent; }
.diff-overlay .added { background: rgba(46, 160, 67, 0.2); border-left: 3px solid #4ec9b0; }
.diff-overlay .removed { background: rgba(248, 81, 73, 0.2); border-left: 3px solid #f48771; }
.diff-overlay .changed { background: rgba(240, 136, 62, 0.2); border-left: 3px solid #d29922; }
.pane-tabs { display: flex; background: #252526; border-bottom: 1px solid #3c3c3c; flex-shrink: 0; padding: 0 8px; gap: 0; }
.pane-tab { padding: 4px 10px; color: #808080; cursor: pointer; border-bottom: 2px solid transparent; font-size: 11px; background: none; border-top: none; border-left: none; border-right: none; font-family: inherit; }
.pane-tab:hover { color: #cccccc; }
.pane-tab.active { color: #e6e6e6; border-bottom-color: #007acc; }
#tree-output, #json-output { padding: 12px 16px; background: #1e1e1e; overflow-y: auto; font-family: 'JetBrains Mono', 'Fira Code', 'Consolas', monospace; font-size: 12px; line-height: 1.7; white-space: pre-wrap; word-break: break-all; height: 100%; }
.node-type { color: #d2a8ff; font-weight: bold; }
.node-range { color: #808080; font-size: 10px; }
.node-text { color: #ce9178; }
.node-error { color: #f48771; background: rgba(248, 81, 73, 0.1); border-radius: 3px; padding: 0 4px; }
.json-key { color: #9cdcfe; }
.json-string { color: #ce9178; }
.json-number { color: #b5cea8; }
.json-boolean { color: #569cd6; }
.json-null { color: #808080; }
.json-bracket { color: #d4d4d4; }
#comparePanel { display: none; flex: 1; overflow: hidden; background: #1e1e1e; }
#comparePanel.active { display: flex; }
.diff-container { display: flex; height: 100%; width: 100%; font-family: 'JetBrains Mono', 'Fira Code', 'Consolas', monospace; font-size: 13px; line-height: 1.7; background: #1e1e1e; position: relative; }
.diff-column { flex: 1; overflow: auto; padding: 4px 0; position: relative; }
.diff-column:first-child { border-right: 1px solid #3c3c3c; }
.diff-column:last-child { border-left: 1px solid #3c3c3c; }
.diff-column-header { position: sticky; top: 0; z-index: 10; background: #252526; padding: 3px 12px 3px 40px; font-size: 11px; color: #808080; border-bottom: 1px solid #3c3c3c; display: flex; justify-content: space-between; align-items: center; min-height: 24px; font-family: 'Segoe UI', system-ui, sans-serif; }
.diff-line { display: flex; align-items: stretch; min-height: 22px; padding: 0 12px 0 0; position: relative; }
.diff-line:hover { background: rgba(255, 255, 255, 0.03); }
.diff-line-number { width: 40px; min-width: 40px; padding: 0 8px; color: #4a4a4a; text-align: right; user-select: none; font-size: 12px; background: transparent; flex-shrink: 0; }
.diff-line-content { flex: 1; padding: 0 8px; white-space: pre-wrap; word-break: break-all; position: relative; font-size: 13px; }
.diff-line.removed { background: rgba(248, 81, 73, 0.08); }
.diff-line.removed .diff-line-number { color: #f48771; }
.diff-line.removed .diff-line-content { background: rgba(248, 81, 73, 0.08); }
.diff-line.added { background: rgba(46, 160, 67, 0.08); }
.diff-line.added .diff-line-number { color: #4ec9b0; }
.diff-line.added .diff-line-content { background: rgba(46, 160, 67, 0.08); }
.diff-line.changed .diff-line-content { background: rgba(240, 136, 62, 0.08); }
.diff-line.changed .diff-line-number { color: #d29922; }
.diff-line.empty .diff-line-content { opacity: 0.3; }
.diff-change-block { position: relative; margin: 2px 0; border-radius: 4px; border: 1px solid transparent; transition: border-color 0.3s; }
.diff-change-block:hover { border-color: rgba(255, 255, 255, 0.3); }
.diff-change-block .diff-line { padding-left: 12px; }
.diff-change-block .diff-line:first-child { padding-top: 1px; }
.diff-change-block .diff-line:last-child { padding-bottom: 1px; }
.diff-change-block.changed-block { background: rgba(240, 136, 62, 0.05); border-left: 3px solid #d29922; }
.diff-change-block.added-block { background: rgba(46, 160, 67, 0.05); border-left: 3px solid #4ec9b0; }
.diff-change-block.removed-block { background: rgba(248, 81, 73, 0.05); border-left: 3px solid #f48771; }
.diff-change-block.connected { border-color: rgba(255, 255, 255, 0.2); box-shadow: 0 0 20px rgba(255, 255, 255, 0.05); }
.diff-gutter { width: 20px; min-width: 20px; background: #1e1e1e; display: flex; flex-direction: column; align-items: center; padding: 4px 0; border-left: 1px solid #2d2d2d; border-right: 1px solid #2d2d2d; position: relative; overflow: hidden; }
.diff-gutter-line { height: 22px; min-height: 22px; display: flex; align-items: center; justify-content: center; font-size: 10px; color: #4a4a4a; }
.diff-gutter-line.marker { color: #4a4a4a; }
.diff-gutter-line.added-marker { color: #4ec9b0; }
.diff-gutter-line.removed-marker { color: #f48771; }
.diff-gutter-line.changed-marker { color: #d29922; }
#historyPanel { display: none; flex: 1; overflow: hidden; background: #1e1e1e; }
#historyPanel.active { display: flex; }
.history-item { padding: 6px 10px; border-bottom: 1px solid #2d2d2d; font-size: 12px; cursor: pointer; transition: background 0.2s; }
.history-item:hover { background: #2d2d2d; }
.history-item .time { color: #808080; font-size: 11px; }
.history-item .nodes { color: #4ec9b0; }
.patch-panel { background: #252526; border-top: 1px solid #3c3c3c; padding: 8px 12px; max-height: 200px; overflow-y: auto; flex-shrink: 0; display: none; }
.patch-panel.active { display: block; }
.patch-panel .patch-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px; font-size: 12px; color: #808080; }
.patch-panel .patch-content { font-family: 'JetBrains Mono', 'Fira Code', 'Consolas', monospace; font-size: 11px; line-height: 1.6; white-space: pre-wrap; color: #d4d4d4; background: #1e1e1e; padding: 8px; border-radius: 4px; max-height: 150px; overflow-y: auto; }
.patch-panel .patch-content .diff-added { color: #4ec9b0; }
.patch-panel .patch-content .diff-removed { color: #f48771; }
.footer { background: #252526; padding: 4px 16px; border-top: 1px solid #3c3c3c; font-size: 11px; color: #808080; display: flex; justify-content: space-between; flex-shrink: 0; flex-wrap: wrap; gap: 4px; min-height: 28px; align-items: center; }
.footer .stats { display: flex; gap: 12px; flex-wrap: wrap; }
.footer .stats span { display: flex; align-items: center; gap: 4px; }
.btn { background: #2d2d2d; border: 1px solid #3c3c3c; color: #cccccc; padding: 2px 10px; border-radius: 4px; font-size: 11px; cursor: pointer; transition: all 0.2s; font-family: inherit; }
.btn:hover { background: #3c3c3c; border-color: #4c4c4c; }
.btn-primary { background: #007acc; border-color: #007acc; color: white; }
.btn-primary:hover { background: #1a8cd8; border-color: #1a8cd8; }
@media (max-width: 768px) { .main-container { flex-direction: column; } .pane { border-right: none; border-bottom: 1px solid #3c3c3c; max-height: 50vh; } .diff-container { flex-direction: column; } .diff-column:first-child { border-right: none; border-bottom: 1px solid #3c3c3c; } .diff-column:last-child { border-left: none; border-top: 1px solid #3c3c3c; } .resize-handle { display: none; } .diff-gutter { display: none; } }
::-webkit-scrollbar { width: 6px; height: 6px; }
::-webkit-scrollbar-track { background: #1e1e1e; }
::-webkit-scrollbar-thumb { background: #3c3c3c; border-radius: 3px; }
::-webkit-scrollbar-thumb:hover { background: #4c4c4c; }`;
  }

  // ============================================================
  // 14. ГЕНЕРАЦИЯ СКРИПТОВ (ОБНОВЛЕНО С ОБРАБОТКОЙ ОШИБОК)
  // ============================================================

  [PRIVATE.GENERATE_SCRIPTS](code, filename, language) {
    const escapedCode = VALIDATOR[PRIVATE.SECURE].escapeJs(code);

    return `
import * as treeSitter from 'web-tree-sitter';

const { Parser, Language } = treeSitter;

// === DOM ===
const codeInput = document.getElementById('code-input');
const treeOutput = document.getElementById('tree-output');
const jsonOutput = document.getElementById('json-output');
const diffOverlay = document.getElementById('diffOverlay');
const diffLeftContent = document.getElementById('diffLeftContent');
const diffRightContent = document.getElementById('diffRightContent');
const diffGutter = document.getElementById('diffGutter');
const diffOldTime = document.getElementById('diffOldTime');
const diffNewTime = document.getElementById('diffNewTime');
const statusDot = document.getElementById('statusDot');
const statusText = document.getElementById('statusText');
const nodeCount = document.getElementById('nodeCount');
const errorCount = document.getElementById('errorCount');
const charCount = document.getElementById('charCount');
const lineCount = document.getElementById('lineCount');
const historyCount = document.getElementById('historyCount');
const infoMsg = document.getElementById('info-msg');
const mainContainer = document.getElementById('mainContainer');
const comparePanel = document.getElementById('comparePanel');
const historyPanel = document.getElementById('historyPanel');
const historyTree = document.getElementById('historyTree');
const leftPane = document.getElementById('leftPane');
const rightPane = document.getElementById('rightPane');
const resizeHandle = document.getElementById('resizeHandle');
const saveJsonBtn = document.getElementById('saveJsonBtn');
const saveAstBtn = document.getElementById('saveAstBtn');
const savePatchBtn = document.getElementById('savePatchBtn');
const resetBtn = document.getElementById('resetBtn');
const copyBtn = document.getElementById('copyBtn');

// === Состояние ===
let parser = null;
let currentTree = null;
let history = [];
let historyIndex = -1;
let previousCode = '';
let isInitialized = false;
let lastSavedCode = '';
let currentJsonData = null;
let isResizing = false;
let originalCode = codeInput.value;

charCount.textContent = originalCode.length;
lineCount.textContent = originalCode.split('\\n').length;

// === Копирование ===
copyBtn.addEventListener('click', async () => {
    try {
        await navigator.clipboard.writeText(codeInput.value);
        copyBtn.textContent = '✅ Скопировано!';
        copyBtn.classList.add('copied');
        setTimeout(() => {
            copyBtn.textContent = '📋 Копировать';
            copyBtn.classList.remove('copied');
        }, 2000);
    } catch {
        const range = document.createRange();
        range.selectNode(codeInput);
        window.getSelection().removeAllRanges();
        window.getSelection().addRange(range);
        document.execCommand('copy');
        copyBtn.textContent = '✅ Скопировано!';
        copyBtn.classList.add('copied');
        setTimeout(() => {
            copyBtn.textContent = '📋 Копировать';
            copyBtn.classList.remove('copied');
        }, 2000);
    }
});

// === Ресайз ===
function initResize() {
    let startX, startLeftWidth, startRightWidth;
    const container = mainContainer;

    resizeHandle.addEventListener('mousedown', (e) => {
        isResizing = true;
        startX = e.clientX;
        startLeftWidth = leftPane.offsetWidth;
        startRightWidth = rightPane.offsetWidth;
        resizeHandle.classList.add('active');
        document.body.style.cursor = 'col-resize';
        document.body.style.userSelect = 'none';
    });

    document.addEventListener('mousemove', (e) => {
        if (!isResizing) return;
        const diff = e.clientX - startX;
        const totalWidth = container.offsetWidth - resizeHandle.offsetWidth;
        const newLeftWidth = Math.max(200, Math.min(totalWidth - 200, startLeftWidth + diff));
        const newRightWidth = totalWidth - newLeftWidth;

        leftPane.style.flex = 'none';
        leftPane.style.width = newLeftWidth + 'px';
        rightPane.style.flex = 'none';
        rightPane.style.width = newRightWidth + 'px';
    });

    document.addEventListener('mouseup', () => {
        if (isResizing) {
            isResizing = false;
            resizeHandle.classList.remove('active');
            document.body.style.cursor = '';
            document.body.style.userSelect = '';
        }
    });
}

// === История ===
function saveHistory(code, tree) {
    if (code === lastSavedCode && history.length > 0) return;

    const entry = {
        id: Date.now(),
        timestamp: new Date().toLocaleTimeString(),
        code: code,
        treeString: tree ? tree.rootNode.toString() : '',
        nodeCount: tree ? countAllNodes(tree.rootNode) : 0,
        errorCount: tree ? countErrors(tree.rootNode) : 0,
        diff: history.length > 0 ? generateDiff(history[history.length - 1].code, code) : ''
    };

    if (historyIndex < history.length - 1) {
        history = history.slice(0, historyIndex + 1);
    }

    history.push(entry);
    historyIndex = history.length - 1;
    lastSavedCode = code;
    updateHistoryUI();
    updateDiffUI();
}

function generateDiff(oldCode, newCode) {
    const oldLines = oldCode.split('\\n');
    const newLines = newCode.split('\\n');
    let diff = '';

    let i = 0, j = 0;
    while (i < oldLines.length || j < newLines.length) {
        if (i < oldLines.length && j < newLines.length && oldLines[i] === newLines[j]) {
            i++; j++;
        } else {
            if (i < oldLines.length) {
                diff += \`- \${oldLines[i]}\\n\`;
                i++;
            }
            if (j < newLines.length) {
                diff += \`+ \${newLines[j]}\\n\`;
                j++;
            }
        }
    }
    return diff;
}

function countAllNodes(node) {
    if (!node) return 0;
    let count = 1;
    if (node.children) {
        for (const child of node.children) count += countAllNodes(child);
    }
    return count;
}

function countErrors(node) {
    if (!node) return 0;
    let count = (node.type === 'ERROR' || node.type === 'MISSING') ? 1 : 0;
    if (node.children) {
        for (const child of node.children) count += countErrors(child);
    }
    return count;
}

function updateHistoryUI() {
    historyCount.textContent = history.length;
    if (history.length === 0) {
        historyTree.innerHTML = '<div style="color:#4a4a4a;padding:12px;">История пуста</div>';
        return;
    }
    let html = '<div style="display:flex;flex-direction:column;gap:4px;">';
    for (let i = history.length - 1; i >= 0; i--) {
        const entry = history[i];
        const isActive = i === historyIndex;
        const diffLines = entry.diff ? entry.diff.split('\\n').filter(l => l.trim()).length : 0;

        html += \`
                <div class="history-item" style="\${isActive ? 'background:#2d2d2d;border-left:3px solid #007acc;' : 'border-left:3px solid transparent;'}" data-index="\${i}">
                    <div style="display:flex;justify-content:space-between;align-items:center;">
                        <div>
                            <span class="time">\${entry.timestamp}</span>
                            <span class="nodes">📊 \${entry.nodeCount} узлов</span>
                            \${entry.errorCount > 0 ? ' <span style="color:#d29922;">⚠️ \${entry.errorCount}</span>' : ''}
                            \${diffLines > 0 ? ' <span style="color:#4ec9b0;">📝 \${diffLines} изменений</span>' : ''}
                        </div>
                        <div style="display:flex;gap:4px;">
                            \${isActive ? '<span style="color:#4ec9b0;font-size:10px;">◀ текущая</span>' : ''}
                            <button class="btn" style="font-size:9px;padding:1px 6px;" data-restore="\${i}">↺</button>
                        </div>
                    </div>
                    <div style="font-size:10px;color:#4a4a4a;margin-top:2px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">
                        \${entry.code.substring(0, 80)}\${entry.code.length > 80 ? '...' : ''}
                    </div>
                    \${entry.diff ? \`
                        <div style="font-size:10px;color:#808080;margin-top:4px;font-family:monospace;background:#1e1e1e;padding:4px 8px;border-radius:4px;max-height:60px;overflow-y:auto;white-space:pre-wrap;">
                            \${entry.diff}
                        </div>
                    \` : ''}
                </div>
            \`;
    }
    html += '</div>';
    historyTree.innerHTML = html;

    historyTree.querySelectorAll('[data-restore]').forEach(el => {
        el.addEventListener('click', (e) => {
            e.stopPropagation();
            const index = parseInt(el.dataset.restore);
            if (index >= 0 && index < history.length) {
                historyIndex = index;
                codeInput.value = history[index].code;
                parseCode();
                updateHistoryUI();
            }
        });
    });

    historyTree.querySelectorAll('.history-item').forEach(el => {
        el.addEventListener('click', () => {
            const index = parseInt(el.dataset.index);
            if (index >= 0 && index < history.length && index !== historyIndex) {
                historyIndex = index;
                codeInput.value = history[index].code;
                parseCode();
                updateHistoryUI();
            }
        });
    });
}

// === Основные функции ===
function updateStatus(type, text) {
    statusDot.className = \`status-dot \${type}\`;
    statusText.innerText = text;
}

function escapeHtml(text) {
    return text.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

function renderNode(node, depth = 0) {
    if (!node) return '';
    const indent = '  '.repeat(depth);
    const isNamed = node.isNamed || false;
    const type = node.type || 'UNKNOWN';
    const isMissing = node.isMissing || false;
    const hasError = type === 'ERROR' || isMissing;
    let result = '';

    if (!isNamed && type !== 'ERROR' && type !== 'MISSING') {
        if (node.children && node.children.length > 0) {
            for (const child of node.children) result += renderNode(child, depth);
        }
        return result;
    }

    let line = \`\${indent}\`;
    if (hasError) {
        line += \`<span class="node-error">\${isMissing ? 'MISSING' : 'ERROR'} \${type}</span>\`;
    } else {
        line += \`<span class="node-type">\${type}</span>\`;
    }

    const startRow = node.startPosition?.row ?? 0;
    const startCol = node.startPosition?.column ?? 0;
    const endRow = node.endPosition?.row ?? 0;
    const endCol = node.endPosition?.column ?? 0;
    line += \` <span class="node-range">[\${startRow}:\${startCol}] → [\${endRow}:\${endCol}]</span>\`;

    if ((node.children?.length ?? 0) === 0 && isNamed) {
        const text = codeInput.value.substring(node.startIndex ?? 0, node.endIndex ?? 0);
        if (text && text.trim()) {
            line += \` : "<span class="node-text">\${escapeHtml(text)}</span>"\`;
        }
    }
    result += line + '\\n';

    if (node.children) {
        for (const child of node.children) result += renderNode(child, depth + 1);
    }
    return result;
}

function nodeToJSON(node) {
    if (!node) return null;
    const obj = {
        type: node.type || 'UNKNOWN',
        isNamed: node.isNamed || false,
        isMissing: node.isMissing || false,
        isError: node.type === 'ERROR' || node.isMissing || false,
        startPosition: node.startPosition || { row: 0, column: 0 },
        endPosition: node.endPosition || { row: 0, column: 0 },
        startIndex: node.startIndex || 0,
        endIndex: node.endIndex || 0,
    };

    if ((node.children?.length ?? 0) === 0 && obj.isNamed) {
        obj.text = codeInput.value.substring(obj.startIndex, obj.endIndex);
    }

    if (node.children && node.children.length > 0) {
        obj.children = node.children.map(child => nodeToJSON(child)).filter(Boolean);
    }
    return obj;
}

function formatJSON(obj, indent = 0) {
    if (obj === null) return '<span class="json-null">null</span>';
    if (typeof obj === 'string') return \`<span class="json-string">"\${escapeHtml(obj)}"</span>\`;
    if (typeof obj === 'number') return \`<span class="json-number">\${obj}</span>\`;
    if (typeof obj === 'boolean') return \`<span class="json-boolean">\${obj}</span>\`;
    if (Array.isArray(obj)) {
        if (obj.length === 0) return '<span class="json-bracket">[]</span>';
        const items = obj.map(item => formatJSON(item, indent + 2));
        return \`<span class="json-bracket">[</span>\\n\${items.map((item, i) => ' '.repeat(indent + 2) + item + (i < items.length - 1 ? ',' : '')).join('\\n')}\\n\${' '.repeat(indent)}<span class="json-bracket">]</span>\`;
    }
    if (typeof obj === 'object') {
        const keys = Object.keys(obj);
        if (keys.length === 0) return '<span class="json-bracket">{}</span>';
        const items = keys.map(key => {
            const value = formatJSON(obj[key], indent + 2);
            return \`<span class="json-key">"\${escapeHtml(key)}"</span>: \${value}\`;
        });
        return \`<span class="json-bracket">{</span>\\n\${items.map((item, i) => ' '.repeat(indent + 2) + item + (i < items.length - 1 ? ',' : '')).join('\\n')}\\n\${' '.repeat(indent)}<span class="json-bracket">}</span>\`;
    }
    return String(obj);
}

function updateStats(code, tree) {
    charCount.textContent = code.length;
    const lines = code.split('\\n');
    lineCount.textContent = lines.length;
    if (tree) {
        const root = tree.rootNode;
        nodeCount.textContent = countAllNodes(root);
        errorCount.textContent = countErrors(root);
    }
}

// === VSCode Style Diff ===
function computeDiff(oldCode, newCode) {
    const oldLines = oldCode.split('\\n');
    const newLines = newCode.split('\\n');

    function findLCS(a, b) {
        const m = a.length;
        const n = b.length;
        const dp = Array(m + 1).fill(null).map(() => Array(n + 1).fill(0));

        for (let i = 1; i <= m; i++) {
            for (let j = 1; j <= n; j++) {
                if (a[i-1] === b[j-1]) {
                    dp[i][j] = dp[i-1][j-1] + 1;
                } else {
                    dp[i][j] = Math.max(dp[i-1][j], dp[i][j-1]);
                }
            }
        }
        return dp;
    }

    function backtrackLCS(a, b, dp, i, j) {
        if (i === 0 || j === 0) return [];
        if (a[i-1] === b[j-1]) {
            return [...backtrackLCS(a, b, dp, i-1, j-1), a[i-1]];
        }
        if (dp[i-1][j] > dp[i][j-1]) {
            return backtrackLCS(a, b, dp, i-1, j);
        }
        return backtrackLCS(a, b, dp, i, j-1);
    }

    const dp = findLCS(oldLines, newLines);
    const lcs = backtrackLCS(oldLines, newLines, dp, oldLines.length, newLines.length);

    const result = [];
    let i = 0, j = 0;
    let lcsIndex = 0;
    let currentBlock = null;
    let blockId = 0;

    function flushBlock() {
        if (currentBlock && currentBlock.lines.length > 0) {
            currentBlock.id = blockId++;
            result.push({ type: 'block', lines: currentBlock.lines, blockType: currentBlock.blockType, id: currentBlock.id });
            currentBlock = null;
        }
    }

    while (i < oldLines.length || j < newLines.length || lcsIndex < lcs.length) {
        if (lcsIndex < lcs.length) {
            const match = lcs[lcsIndex];

            while (i < oldLines.length && oldLines[i] !== match) {
                if (!currentBlock) {
                    currentBlock = { lines: [], blockType: 'removed' };
                }
                currentBlock.lines.push({
                    type: 'removed',
                    oldLine: oldLines[i],
                    newLine: '',
                    oldNum: i + 1,
                    newNum: '-'
                });
                i++;
            }

            while (j < newLines.length && newLines[j] !== match) {
                if (!currentBlock) {
                    currentBlock = { lines: [], blockType: 'added' };
                }
                if (currentBlock.blockType !== 'added') currentBlock.blockType = 'changed';
                currentBlock.lines.push({
                    type: 'added',
                    oldLine: '',
                    newLine: newLines[j],
                    oldNum: '-',
                    newNum: j + 1
                });
                j++;
            }

            if (i < oldLines.length && j < newLines.length && oldLines[i] === newLines[j]) {
                flushBlock();
                result.push({
                    type: 'same',
                    oldLine: oldLines[i],
                    newLine: newLines[j],
                    oldNum: i + 1,
                    newNum: j + 1
                });
                i++;
                j++;
                lcsIndex++;
            }
        } else {
            if (i < oldLines.length) {
                if (!currentBlock) {
                    currentBlock = { lines: [], blockType: 'removed' };
                }
                currentBlock.lines.push({
                    type: 'removed',
                    oldLine: oldLines[i],
                    newLine: '',
                    oldNum: i + 1,
                    newNum: '-'
                });
                i++;
            }
            if (j < newLines.length) {
                if (!currentBlock) {
                    currentBlock = { lines: [], blockType: 'added' };
                }
                if (currentBlock.blockType !== 'added') currentBlock.blockType = 'changed';
                currentBlock.lines.push({
                    type: 'added',
                    oldLine: '',
                    newLine: newLines[j],
                    oldNum: '-',
                    newNum: j + 1
                });
                j++;
            }
        }
    }

    flushBlock();
    return result;
}

function renderDiffLines(diffResult, side) {
    let html = '';
    for (const item of diffResult) {
        if (item.type === 'block') {
            const blockType = item.blockType || 'changed';
            html += \`<div class="diff-change-block \${blockType}-block connected" data-block-id="\${item.id}">\`;
            for (const line of item.lines) {
                const content = side === 'left' ? line.oldLine : line.newLine;
                const num = side === 'left' ? line.oldNum : line.newNum;
                const isEmpty = content === '';
                const typeClass = line.type === 'same' ? 'same' : line.type;

                html += \`
                        <div class="diff-line \${typeClass} \${isEmpty ? 'empty' : ''}">
                            <span class="diff-line-number">\${num}</span>
                            <span class="diff-line-content">\${escapeHtml(content)}</span>
                        </div>
                    \`;
            }
            html += '</div>';
        } else {
            const content = side === 'left' ? item.oldLine : item.newLine;
            const num = side === 'left' ? item.oldNum : item.newNum;
            const isEmpty = content === '';
            const typeClass = item.type === 'same' ? 'same' : item.type;

            html += \`
                    <div class="diff-line \${typeClass} \${isEmpty ? 'empty' : ''}">
                        <span class="diff-line-number">\${num}</span>
                        <span class="diff-line-content">\${escapeHtml(content)}</span>
                    </div>
                \`;
        }
    }
    return html;
}

function renderGutter(diffResult) {
    let html = '';
    for (const item of diffResult) {
        if (item.type === 'block') {
            for (const line of item.lines) {
                let marker = '·';
                let cls = 'marker';
                if (line.type === 'added') { marker = '+'; cls = 'added-marker'; }
                else if (line.type === 'removed') { marker = '−'; cls = 'removed-marker'; }
                else if (line.type === 'changed') { marker = '∼'; cls = 'changed-marker'; }
                html += \`<div class="diff-gutter-line \${cls}">\${marker}</div>\`;
            }
        } else {
            let marker = '·';
            let cls = 'marker';
            if (item.type === 'added') { marker = '+'; cls = 'added-marker'; }
            else if (item.type === 'removed') { marker = '−'; cls = 'removed-marker'; }
            else if (item.type === 'changed') { marker = '∼'; cls = 'changed-marker'; }
            html += \`<div class="diff-gutter-line \${cls}">\${marker}</div>\`;
        }
    }
    return html;
}

function updateDiffUI() {
    if (!originalCode) {
        diffLeftContent.innerHTML = '<div style="padding:16px;color:#4a4a4a;">Нет оригинальной версии</div>';
        diffRightContent.innerHTML = '<div style="padding:16px;color:#4a4a4a;">Нет данных</div>';
        diffGutter.innerHTML = '';
        diffOldTime.textContent = '';
        diffNewTime.textContent = '';
        return;
    }

    const currentCode = codeInput.value;
    diffOldTime.textContent = 'оригинал';
    diffNewTime.textContent = 'текущая';

    const diffResult = computeDiff(originalCode, currentCode);

    diffLeftContent.innerHTML = renderDiffLines(diffResult, 'left');
    diffRightContent.innerHTML = renderDiffLines(diffResult, 'right');
    diffGutter.innerHTML = renderGutter(diffResult);
}

function updateDiffOverlay() {
    if (!originalCode) {
        diffOverlay.innerHTML = '';
        return;
    }

    const oldLines = originalCode.split('\\n');
    const newLines = codeInput.value.split('\\n');
    let diffHtml = '';

    for (let i = 0; i < newLines.length; i++) {
        const line = newLines[i];
        let className = '';
        if (i < oldLines.length) {
            if (line !== oldLines[i]) className = 'changed';
        } else {
            className = 'added';
        }
        if (className) {
            diffHtml += \`<div class="\${className}">\${escapeHtml(line)}</div>\`;
        } else if (line) {
            diffHtml += \`<div>\${escapeHtml(line)}</div>\`;
        }
    }
    diffOverlay.innerHTML = diffHtml;
}

// === ОСНОВНАЯ ФУНКЦИЯ ПАРСИНГА (ОБНОВЛЕНА С ОБРАБОТКОЙ ОШИБОК) ===
function parseCode() {
    if (!parser) {
        treeOutput.innerHTML = '⏳ Парсер не инициализирован';
        return;
    }
    try {
        const sourceCode = codeInput.value;
        if (!sourceCode.trim()) {
            treeOutput.innerHTML = '<span style="color:#4a4a4a;">Пустой файл</span>';
            jsonOutput.innerHTML = '<span style="color:#4a4a4a;">Нет данных</span>';
            return;
        }

        currentTree = parser.parse(sourceCode);
        const rootNode = currentTree.rootNode;

        // Подсчет ошибок
        const errors = countErrors(rootNode);
        
        // Рендерим дерево
        treeOutput.innerHTML = renderNode(rootNode, 0) || '<span style="color:#4a4a4a;">Дерево пустое</span>';

        // Если есть ошибки, показываем предупреждение
        if (errors > 0) {
            const errorMsg = \`⚠️ Обнаружено \${errors} синтаксических ошибок. Дерево может быть неполным.\`;
            treeOutput.innerHTML = \`<div style="color:#d29922;padding:4px 8px;background:rgba(253,203,110,0.1);border-radius:4px;margin-bottom:8px;border-left:3px solid #d29922;">\${errorMsg}</div>\` + treeOutput.innerHTML;
            infoMsg.textContent = errorMsg;
            infoMsg.style.color = "#d29922";
        } else {
            infoMsg.textContent = "✅ Обновлено";
            infoMsg.style.color = "#4ec9b0";
        }

        currentJsonData = nodeToJSON(rootNode);
        jsonOutput.innerHTML = formatJSON(currentJsonData);

        updateStats(sourceCode, currentTree);

        if (sourceCode !== previousCode && isInitialized) {
            saveHistory(sourceCode, currentTree);
        }
        previousCode = sourceCode;

        if (comparePanel.style.display === 'flex') {
            updateDiffUI();
        }

        updateDiffOverlay();

    } catch (err) {
        // Если парсер полностью упал, показываем ошибку
        treeOutput.innerHTML = \`<span class="node-error">❌ Ошибка парсинга: \${escapeHtml(err.message)}</span>\`;
        jsonOutput.innerHTML = \`<span class="node-error">❌ Ошибка парсинга</span>\`;
        infoMsg.textContent = "❌ Ошибка парсинга";
        infoMsg.style.color = "#f48771";
        console.error(err);
    }
}

// === Сохранение ===
function downloadFile(content, filename, mimeType = 'text/plain') {
    const blob = new Blob([content], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
}

function generateGitPatch(oldCode, newCode) {
    const oldLines = oldCode.split('\\n');
    const newLines = newCode.split('\\n');
    let patch = '';

    patch += \`diff --git a/file.\${language} b/file.\${language}\\n\`;
    patch += \`index \${Date.now().toString(16)}..\${(Date.now() + 1).toString(16)} 100644\\n\`;
    patch += \`--- a/file.\${language}\\n\`;
    patch += \`+++ b/file.\${language}\\n\`;

    let i = 0, j = 0;
    let hunks = [];
    let currentHunk = null;

    while (i < oldLines.length || j < newLines.length) {
        if (i < oldLines.length && j < newLines.length && oldLines[i] === newLines[j]) {
            if (currentHunk) {
                currentHunk.context.push({ old: i + 1, new: j + 1, line: oldLines[i] });
            }
            i++; j++;
        } else {
            if (!currentHunk) {
                currentHunk = {
                    startOld: i + 1,
                    startNew: j + 1,
                    removed: [],
                    added: [],
                    context: []
                };
            }
            if (i < oldLines.length) {
                currentHunk.removed.push(oldLines[i]);
                i++;
            }
            if (j < newLines.length) {
                currentHunk.added.push(newLines[j]);
                j++;
            }
            if (currentHunk.removed.length + currentHunk.added.length > 20) {
                hunks.push(currentHunk);
                currentHunk = null;
            }
        }
    }
    if (currentHunk) hunks.push(currentHunk);

    for (const hunk of hunks) {
        const contextLines = hunk.context.slice(-3);
        const startOld = contextLines.length > 0 ? contextLines[0].old : hunk.startOld;
        const startNew = contextLines.length > 0 ? contextLines[0].new : hunk.startNew;
        const oldCount = hunk.removed.length + contextLines.length;
        const newCount = hunk.added.length + contextLines.length;

        patch += \`@@ -\${startOld},\${oldCount} +\${startNew},\${newCount} @@\\n\`;

        for (const ctx of contextLines) {
            patch += \` \${ctx.line}\\n\`;
        }
        for (const line of hunk.removed) {
            patch += \`-\${line}\\n\`;
        }
        for (const line of hunk.added) {
            patch += \`+\${line}\\n\`;
        }
    }

    return patch;
}

saveJsonBtn.addEventListener('click', () => {
    if (currentJsonData) {
        downloadFile(JSON.stringify(currentJsonData, null, 2), \`ast_\${Date.now()}.json\`, 'application/json');
        infoMsg.textContent = "✅ JSON сохранен";
    }
});

saveAstBtn.addEventListener('click', () => {
    if (currentTree) {
        downloadFile(currentTree.rootNode.toString(), \`ast_\${Date.now()}.txt\`, 'text/plain');
        infoMsg.textContent = "✅ AST сохранен";
    }
});

savePatchBtn.addEventListener('click', () => {
    if (originalCode && codeInput.value !== originalCode) {
        const patch = generateGitPatch(originalCode, codeInput.value);
        downloadFile(patch, \`patch_\${Date.now()}.diff\`, 'text/plain');
        infoMsg.textContent = "✅ Патч сохранен";
        infoMsg.style.color = "#4ec9b0";
    } else {
        infoMsg.textContent = "❌ Нет изменений для патча";
        infoMsg.style.color = "#f48771";
    }
});

// === Сброс к оригиналу ===
resetBtn.addEventListener('click', () => {
    if (originalCode) {
        codeInput.value = originalCode;
        parseCode();
        infoMsg.textContent = "↺ Сброшено к оригиналу";
        infoMsg.style.color = "#4ec9b0";
        setTimeout(() => {
            infoMsg.textContent = "✅ Готово";
        }, 1500);
    }
});

// === Инициализация парсера ===
async function initParser() {
    try {
        updateStatus('loading', 'Инициализация...');
        infoMsg.textContent = 'Загрузка WASM...';

        await Parser.init({
            locateFile: (scriptName) => {
                return \`https://cdn.jsdelivr.net/npm/web-tree-sitter@${this._config.treeSitterVersion}/\${scriptName}\`;
            }
        });

        parser = new Parser();

        const JavaScript = await Language.load(
            'https://cdn.jsdelivr.net/npm/tree-sitter-javascript@${this._config.treeSitterJavaScriptVersion}/tree-sitter-javascript.wasm'
        );

        parser.setLanguage(JavaScript);

        updateStatus('ready', 'Готов');
        infoMsg.textContent = '✅ Парсер готов!';
        infoMsg.style.color = "#4ec9b0";

        isInitialized = true;
        previousCode = codeInput.value;
        originalCode = codeInput.value;
        parseCode();

        if (currentTree) {
            saveHistory(codeInput.value, currentTree);
        }

        codeInput.addEventListener('input', parseCode);

        codeInput.addEventListener('keydown', (e) => {
            if (e.key === 'Tab') {
                e.preventDefault();
                const start = codeInput.selectionStart;
                const end = codeInput.selectionEnd;
                codeInput.value = codeInput.value.substring(0, start) + '  ' + codeInput.value.substring(end);
                codeInput.selectionStart = codeInput.selectionEnd = start + 2;
                parseCode();
            }
            if ((e.ctrlKey || e.metaKey) && e.key === 'z' && historyIndex > 0) {
                e.preventDefault();
                historyIndex--;
                codeInput.value = history[historyIndex].code;
                parseCode();
                updateHistoryUI();
            }
            if ((e.ctrlKey || e.metaKey) && e.key === 'y' && historyIndex < history.length - 1) {
                e.preventDefault();
                historyIndex++;
                codeInput.value = history[historyIndex].code;
                parseCode();
                updateHistoryUI();
            }
        });

    } catch (error) {
        console.error(error);
        updateStatus('error', 'Ошибка');
        treeOutput.innerHTML = \`<span class="node-error">❌ \${escapeHtml(error.message)}</span>\`;
        infoMsg.textContent = "❌ Ошибка";
        infoMsg.style.color = "#f48771";
    }
}

// === Табы ===
document.querySelectorAll('.pane-tab').forEach(tab => {
    tab.addEventListener('click', () => {
        const parent = tab.closest('.pane-tabs');
        parent.querySelectorAll('.pane-tab').forEach(t => t.classList.remove('active'));
        tab.classList.add('active');

        const target = tab.dataset.tab;
        const content = tab.closest('.pane').querySelector('.pane-content');
        content.querySelectorAll('.pane-content > div').forEach(el => el.classList.remove('active'));
        const targetEl = content.querySelector(\`#right-\${target}\`);
        if (targetEl) targetEl.classList.add('active');
    });
});

// === Главные табы ===
document.querySelectorAll('.main-tab').forEach(tab => {
    tab.addEventListener('click', () => {
        document.querySelectorAll('.main-tab').forEach(t => t.classList.remove('active'));
        tab.classList.add('active');

        const tabName = tab.dataset.tab;

        mainContainer.style.display = 'none';
        comparePanel.style.display = 'none';
        comparePanel.classList.remove('active');
        historyPanel.style.display = 'none';

        if (tabName === 'editor') {
            mainContainer.style.display = 'flex';
        } else if (tabName === 'compare') {
            comparePanel.style.display = 'flex';
            comparePanel.classList.add('active');
            updateDiffUI();
        } else if (tabName === 'history') {
            historyPanel.style.display = 'flex';
            updateHistoryUI();
        }
    });
});

// === Запуск ===
initResize();
initParser();

console.log('🌳 Tree-sitter Code Viewer загружен!');
console.log('📌 Управление:');
console.log('  Перетаскивание разделителя - изменение размера панелей');
console.log('  Ctrl+Z - отмена, Ctrl+Y - повтор');
console.log('  Клик по истории - восстановление версии');
console.log('  Кнопка "Патч" - сохранение Git-совместимого патча');
`;
  }

  // ============================================================
  // 15. ГЕНЕРАЦИЯ КОМПОНЕНТОВ HTML
  // ============================================================

  [PRIVATE.GENERATE_HEADER](filename, language, lineCount, color) {
    return `
<div class="header">
    <h1>
        🌳 Tree-sitter <small>Code Viewer</small>
        <span class="lang-tag ${language}" style="background:${color}20;color:${color};">${language}</span>
    </h1>
    <div class="file-info">
        <span>📄 ${filename}</span>
        <span>📏 ${lineCount} строк</span>
    </div>
    <div class="controls">
        <div class="status" id="status">
            <span class="status-dot loading" id="statusDot"></span>
            <span id="statusText">Инициализация...</span>
        </div>
    </div>
</div>`;
  }

  [PRIVATE.GENERATE_TABS]() {
    return `
<div class="main-tabs" id="mainTabs">
    <button class="main-tab active" data-tab="editor">📝 Редактор</button>
    <button class="main-tab" data-tab="compare">🔍 Сравнение</button>
    <button class="main-tab" data-tab="history">📜 История</button>
</div>`;
  }

  [PRIVATE.GENERATE_MAIN](escapedCode) {
    return `
<div class="main-container" id="mainContainer">
    <div class="pane" id="leftPane">
        <div class="pane-header">
            <span>💻 Редактор</span>
            <div style="display:flex;gap:4px;align-items:center;">
                <span id="leftPaneInfo" style="font-size:10px;color:#4a4a4a;"></span>
                <button class="btn" id="resetBtn" style="font-size:10px;">↺ Сброс</button>
            </div>
        </div>
        <div class="pane-content">
            <div class="active" id="left-code">
                <div class="editor-container" style="position:relative;">
                    <textarea id="code-input" spellcheck="false">${escapedCode}</textarea>
                    <button class="copy-btn" id="copyBtn">📋 Копировать</button>
                    <div class="diff-overlay" id="diffOverlay"></div>
                </div>
            </div>
        </div>
    </div>

    <div class="resize-handle" id="resizeHandle"></div>

    <div class="pane" id="rightPane">
        <div class="pane-header">
            <span>🌿 AST / JSON</span>
            <div style="display:flex;gap:4px;">
                <button class="btn" id="saveJsonBtn" style="font-size:10px;">💾 JSON</button>
                <button class="btn" id="saveAstBtn" style="font-size:10px;">💾 AST</button>
                <button class="btn btn-primary" id="savePatchBtn" style="font-size:10px;">📋 Патч</button>
            </div>
        </div>
        <div class="pane-tabs">
            <button class="pane-tab active" data-tab="ast">🌿 AST</button>
            <button class="pane-tab" data-tab="json">📋 JSON</button>
        </div>
        <div class="pane-content">
            <div class="active" id="right-ast"><div id="tree-output" style="height:100%;padding:8px 12px;"></div></div>
            <div id="right-json"><div id="json-output" style="height:100%;padding:8px 12px;"></div></div>
        </div>
    </div>
</div>`;
  }

  [PRIVATE.GENERATE_COMPARE]() {
    return `
<div id="comparePanel">
    <div class="diff-container" id="diffContainer">
        <div class="diff-column" id="diffLeft">
            <div class="diff-column-header">
                <span>📜 Оригинал</span>
                <span id="diffOldTime" style="font-weight:400;color:#4a4a4a;"></span>
            </div>
            <div id="diffLeftContent"></div>
        </div>
        <div class="diff-gutter" id="diffGutter"></div>
        <div class="diff-column" id="diffRight">
            <div class="diff-column-header">
                <span>🆕 Текущая версия</span>
                <span id="diffNewTime" style="font-weight:400;color:#4a4a4a;"></span>
            </div>
            <div id="diffRightContent"></div>
        </div>
    </div>
</div>`;
  }

  [PRIVATE.GENERATE_HISTORY]() {
    return `
<div id="historyPanel">
    <div style="display:flex;flex-direction:column;height:100%;">
        <div class="pane-header" style="border-bottom:1px solid #3c3c3c;">
            <span>📜 История изменений</span>
            <span style="font-size:10px;color:#4a4a4a;">Клик для восстановления</span>
        </div>
        <div id="historyTree" style="flex:1;overflow-y:auto;padding:8px 12px;"></div>
    </div>
</div>`;
  }

  [PRIVATE.GENERATE_FOOTER](codeLength, lineCount) {
    return `
<div class="footer">
    <div class="stats">
        <span>📊 Узлов: <strong id="nodeCount">0</strong></span>
        <span>⚠️ Ошибок: <strong id="errorCount">0</strong></span>
        <span>📏 Символов: <strong id="charCount">${codeLength}</strong></span>
        <span>📄 Строк: <strong id="lineCount">${lineCount}</strong></span>
        <span>📜 Версий: <strong id="historyCount">0</strong></span>
    </div>
    <div>
        <span id="info-msg" style="color:#4a4a4a;font-size:11px;">Загрузка...</span>
    </div>
</div>`;
  }

  // ============================================================
  // 16. ВСПОМОГАТЕЛЬНЫЕ МЕТОДЫ
  // ============================================================

  [PRIVATE.DETECT_EXT](filename) {
    const ext = filename.split('.').pop();
    return ext ? '.' + ext : '';
  }

  [PRIVATE.DETECT_LANGUAGE](ext) {
    return LANGUAGE_MAP[ext] || DEFAULT_CONFIG.defaultLanguage;
  }

  [PRIVATE.GET_LANGUAGE_COLOR](language) {
    return LANGUAGE_COLORS[language] || '#808080';
  }

  [PRIVATE.GET_CACHE_KEY](code, filename, language) {
    return `${filename}:${language}:${code.length}`;
  }

  [PRIVATE.ERROR_PAGE](message) {
    return `
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Ошибка</title>
    <style>
        body { font-family: monospace; background: #1e1e1e; color: #d4d4d4; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; }
        .container { text-align: center; }
        h1 { font-size: 48px; color: #f48771; margin: 0; }
        .error { color: #f48771; }
        .info { color: #808080; margin-top: 20px; }
    </style>
</head>
<body>
    <div class="container">
        <h1>❌ Ошибка</h1>
        <p class="error">${VALIDATOR[PRIVATE.SECURE].escapeHtml(message)}</p>
        <p class="info"><a href="/" style="color: #667eea;">← На главную</a></p>
    </div>
</body>
</html>`;
  }

  // ============================================================
  // 17. СОБЫТИЯ
  // ============================================================

  on(event, callback) {
    if (!VALIDATOR[PRIVATE.VALIDATOR].isValidCallback(callback)) {
      this._logger.warn(`⚠️ Некорректный callback для события ${event}`);
      return () => {};
    }

    if (!this._eventHandlers.has(event)) {
      this._eventHandlers.set(event, []);
    }
    this._eventHandlers.get(event).push(callback);

    return () => this.off(event, callback);
  }

  off(event, callback) {
    if (this._eventHandlers.has(event)) {
      const handlers = this._eventHandlers.get(event);
      const index = handlers.indexOf(callback);
      if (index !== -1) {
        handlers.splice(index, 1);
      }
      if (handlers.length === 0) {
        this._eventHandlers.delete(event);
      }
    }
  }

  emit(event, data) {
    if (this._eventHandlers.has(event)) {
      const handlers = this._eventHandlers.get(event);
      for (const callback of handlers) {
        try {
          callback(data);
        } catch (error) {
          this._logger.error(`❌ Ошибка в обработчике ${event}:`, error);
        }
      }
    }
  }

  // ============================================================
  // 18. ПОЛУЧЕНИЕ СОСТОЯНИЯ
  // ============================================================

  [PRIVATE.GET_STATE]() {
    return {
      version: this._version,
      build: this._build,
      initialized: this._state.initialized,
      destroyed: this._state.destroyed,
      code: this._state.code ? this._state.code.length : 0,
      filename: this._state.filename,
      language: this._state.language,
      lineCount: this._state.lineCount,
      renderCount: this._state.renderCount,
      cacheSize: this._cache.size,
      metadata: { ...this._metadata },
      context: { ...this._context },
      config: { ...this._config },
    };
  }

  getState() {
    return this[PRIVATE.GET_STATE]();
  }

  // ============================================================
  // 19. СБРОС И УНИЧТОЖЕНИЕ
  // ============================================================

  reset() {
    const logger = this._logger;
    logger.warn('🔄 Сброс состояния...');

    this._state.code = '';
    this._state.filename = '';
    this._state.language = '';
    this._state.lineCount = 0;
    this._state.ext = '';
    this._state.renderCount = 0;
    this._state.lastRender = null;

    this._cache.clear();
    this._logHistory = [];

    this._metadata = {
      created: Date.now(),
      lastAccess: Date.now(),
      lastUpdate: Date.now(),
      renderCount: 0,
      errorCount: 0,
    };

    this.emit('reset', { timestamp: Date.now() });
    logger.success('✅ Состояние сброшено');
    return this;
  }

  destroy() {
    if (this._state.destroyed) {
      this._logger.warn('⚠️ Шаблон уже уничтожен');
      return;
    }

    const logger = this._logger;
    logger.warn('🗑️ Уничтожение шаблона...');

    this._cache.clear();
    this._eventHandlers.clear();
    this._listeners = [];
    this._logHistory = [];

    if (typeof window !== 'undefined') {
      delete window.__template;
      delete window[PUBLIC.API];
      delete window[PUBLIC.STATE];
      delete window[PUBLIC.CONFIG];
      delete window[PUBLIC.LOGGER];
      delete window[PUBLIC.INSTANCE];
      delete window[PUBLIC.RENDER];
      delete window[PUBLIC.EVENTS];
      delete window.__templateSymbols;
    }

    this._state.destroyed = true;
    this._state.initialized = false;

    this.emit('destroyed', { timestamp: Date.now() });
    logger.success('✅ Шаблон уничтожен');
  }
}

// ============================================================
// 20. ГЕТТЕРЫ ДЛЯ ПРИВАТНЫХ ДАННЫХ (ТОЛЬКО ДЛЯ ЧТЕНИЯ)
// ============================================================

Object.defineProperties(Template.prototype, {
  [PRIVATE.CONFIG]: {
    get() { return this._config; }
  },
  [PRIVATE.LOGGER]: {
    get() { return this._logger; }
  },
  [PRIVATE.STATE]: {
    get() { return this._state; }
  },
  [PRIVATE.CACHE]: {
    get() { return this._cache; }
  },
  [PRIVATE.VERSION]: {
    get() { return this._version; }
  },
  [PRIVATE.BUILD]: {
    get() { return this._build; }
  },
  [PRIVATE.METADATA]: {
    get() { return this._metadata; }
  },
  [PRIVATE.CONTEXT]: {
    get() { return this._context; }
  },
});

// ============================================================
// 21. СОЗДАНИЕ ЭКЗЕМПЛЯРА
// ============================================================

let templateInstance = null;

function getTemplateInstance(options = {}) {
  if (!templateInstance) {
    templateInstance = new Template(options);
    if (typeof window !== 'undefined') {
      window.__templateInstance = templateInstance;
    }
  }
  return templateInstance;
}

// ============================================================
// 22. ЭКСПОРТ
// ============================================================

export default async function (code, fileInfo = {}) {
  const template = getTemplateInstance();
  return template.render(code, fileInfo);
}

export {
  Template,
  getTemplateInstance,
  PRIVATE,
  PUBLIC,
  DEFAULT_CONFIG,
  LANGUAGE_MAP,
  LANGUAGE_COLORS,
};

// ============================================================
// 23. ИНИЦИАЛИЗАЦИЯ ПРИ ЗАГРУЗКЕ
// ============================================================

if (typeof window !== 'undefined') {
  const template = getTemplateInstance({
    debug: true,
    version: '2.0.3',
    build: '2026-07-20',
  });

  console.log('╔═══════════════════════════════════════════════════════════════════════════════╗');
  console.log('║              📦 TEMPLATE (100% СИМВОЛЫ)                                     ║');
  console.log('╠═══════════════════════════════════════════════════════════════════════════════╣');
  console.log('║  📋 Все логи выводятся в консоль с цветовой разметкой                       ║');
  console.log('║  🔑 Полная изоляция через приватные символы                                 ║');
  console.log('║  🔓 Публичные символы через Symbol.for                                      ║');
  console.log('║  🌳 Интеграция с Tree-sitter для анализа кода                               ║');
  console.log('║  📄 Поддержка всех языков программирования                                  ║');
  console.log('║  🔄 VSCode-style diff и Git-патчи                                           ║');
  console.log('║  📜 История изменений с возможностью восстановления                         ║');
  console.log('║  ⚠️ Отображение количества синтаксических ошибок                            ║');
  console.log('║  ✅ Обработка ошибок парсинга для файлов с синтаксическими ошибками         ║');
  console.log('╚═══════════════════════════════════════════════════════════════════════════════╝');

  console.log('📋 ДОСТУПНЫЕ КОМАНДЫ:');
  console.log('  __template.render(code, fileInfo)  - рендеринг шаблона');
  console.log('  __template.getState()              - состояние');
  console.log('  __template.reset()                 - сбросить');
  console.log('  __template.destroy()               - уничтожить');
  console.log('  __template.on(event, cb)           - подписка');
  console.log('  __template.emit(event, data)       - событие');
  console.log('  window.PRIVATE_SYMBOLS             - приватные символы');
  console.log('  window.PUBLIC_SYMBOLS              - публичные символы');
  console.log('');
  console.log('📋 ПРИВАТНЫХ СИМВОЛОВ:', Object.keys(PRIVATE).length);
  console.log('📋 ПУБЛИЧНЫХ СИМВОЛОВ:', Object.keys(PUBLIC).length);
}

// ============================================================
// 24. КОМАНДЫ ДЛЯ ОТЛАДКИ
// ============================================================

if (typeof window !== 'undefined') {
  window.__tmpl = {
    instance: window.__templateInstance || window.__template,
    render: (code, info) => window.__templateInstance?.render(code, info),
    getState: () => window.__templateInstance?.getState?.(),
    reset: () => window.__templateInstance?.reset?.(),
    destroy: () => window.__templateInstance?.destroy?.(),
    getSymbols: () => ({
      PRIVATE: { ...PRIVATE },
      PUBLIC: { ...PUBLIC },
    }),
  };

  console.log('📋 КОМАНДЫ ОТЛАДКИ (__tmpl):');
  console.log('  __tmpl.render(code, info)   - рендеринг');
  console.log('  __tmpl.getState()           - состояние');
  console.log('  __tmpl.reset()              - сбросить');
  console.log('  __tmpl.destroy()            - уничтожить');
  console.log('  __tmpl.getSymbols()         - получить символы');
}
