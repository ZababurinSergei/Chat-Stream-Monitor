// packages/mtproto-mqtt-gateway/metaflow/02-config-generator/server.mjs
// 100% СИМВОЛЫ — полная изоляция и безопасность
// Версия: 2.1.0
// ДОБАВЛЕНО: Проверка Origin/Referer для безопасности
// ДОБАВЛЕНО: Защитные заголовки для запросов извне

import { createServer } from 'http';
import { extname, join, dirname, resolve, basename } from 'path';
import { fileURLToPath } from 'url';
import { existsSync, readFileSync, statSync } from 'fs';

const __dirname = dirname(fileURLToPath(import.meta.url));
const __filename = fileURLToPath(import.meta.url);

// ============================================================
// 1. ПРИВАТНЫЕ СИМВОЛЫ (100% изоляция)
// ============================================================

const PRIVATE = {
  // Основные символы
  CONFIG: Symbol('server.config'),
  LOGGER: Symbol('server.logger'),
  STATE: Symbol('server.state'),
  CACHE: Symbol('server.cache'),
  VERSION: Symbol('server.version'),
  BUILD: Symbol('server.build'),
  INITIALIZED: Symbol('server.initialized'),
  IS_RUNNING: Symbol('server.isRunning'),
  IS_DESTROYED: Symbol('server.isDestroyed'),

  // Данные
  PORT: Symbol('server.port'),
  HOST: Symbol('server.host'),
  ROOT: Symbol('server.root'),
  WEB_ROOT: Symbol('server.webRoot'),
  TEMPLATE: Symbol('server.template'),
  TEMPLATE_LOADED: Symbol('server.templateLoaded'),

  // Метаданные
  METADATA: Symbol('server.metadata'),
  CONTEXT: Symbol('server.context'),
  LOG_HISTORY: Symbol('server.logHistory'),

  // Слушатели
  LISTENERS: Symbol('server.listeners'),
  EVENT_HANDLERS: Symbol('server.eventHandlers'),

  // Безопасность
  SECURE: Symbol('server.secure'),
  VALIDATOR: Symbol('server.validator'),

  // Таймеры
  TIMERS: Symbol('server.timers'),
  START_TIME: Symbol('server.startTime'),

  // ★★★ НОВЫЕ СИМВОЛЫ ДЛЯ ORIGIN ★★★
  IS_ORIGIN_REQUEST: Symbol('server.isOriginRequest'),
  IS_SAME_ORIGIN: Symbol('server.isSameOrigin'),
  ADD_SECURITY_HEADERS: Symbol('server.addSecurityHeaders'),
  GET_CURRENT_ORIGIN: Symbol('server.getCurrentOrigin'),

  // Методы
  INIT: Symbol('server.init'),
  HANDLE_REQUEST: Symbol('server.handleRequest'),
  SERVE_STATIC: Symbol('server.serveStatic'),
  SERVE_CODE: Symbol('server.serveCode'),
  RENDER_TEMPLATE: Symbol('server.renderTemplate'),
  DETECT_LANGUAGE: Symbol('server.detectLanguage'),
  GET_MIME_TYPE: Symbol('server.getMimeType'),
  IS_CODE_FILE: Symbol('server.isCodeFile'),
  IS_HTML_FILE: Symbol('server.isHtmlFile'),
  IS_WELL_KNOWN: Symbol('server.isWellKnown'),
  ERROR_404: Symbol('server.error404'),
  ERROR_404_WITH_DETAILS: Symbol('server.error404WithDetails'),
  ERROR_500: Symbol('server.error500'),
  GET_STATE: Symbol('server.getState'),
  RESET: Symbol('server.reset'),
  DESTROY: Symbol('server.destroy'),
  EXPORT_SYMBOLS: Symbol('server.exportSymbols'),
  PRINT_BANNER: Symbol('server.printBanner'),
  LOAD_TEMPLATE: Symbol('server.loadTemplate'),
  SEND_FILE: Symbol('server.sendFile'),
  NORMALIZE_PATH: Symbol('server.normalizePath'),
  FIND_FILE: Symbol('server.findFile'),
  SHOULD_RENDER_WITH_TEMPLATE: Symbol('server.shouldRenderWithTemplate'),
  IS_SERVICE_WORKER: Symbol('server.isServiceWorker'),
  FILE_EXISTS: Symbol('server.fileExists'),
  IS_ROOT_REQUEST: Symbol('server.isRootRequest'),
  IS_ALWAYS_RENDER_FILE: Symbol('server.isAlwaysRenderFile'),
};

// ============================================================
// 2. ПУБЛИЧНЫЕ СИМВОЛЫ (доступны через Symbol.for)
// ============================================================

const PUBLIC = {
  API: Symbol.for('server.api'),
  STATE: Symbol.for('server.state'),
  CONFIG: Symbol.for('server.config'),
  LOGGER: Symbol.for('server.logger'),
  INSTANCE: Symbol.for('server.instance'),
  EVENTS: Symbol.for('server.events'),
  RENDER: Symbol.for('server.render'),
};

// ============================================================
// 3. КОНФИГУРАЦИЯ
// ============================================================

const DEFAULT_CONFIG = {
  version: '2.1.0',
  build: '2026-07-21',
  debug: true,
  port: 8081,
  host: '0.0.0.0',
  maxCacheSize: 100,
  cacheTTL: 3600000,
  templateCacheTTL: 300000,
  // ★★★ НОВЫЕ НАСТРОЙКИ БЕЗОПАСНОСТИ ★★★
  security: {
    checkOrigin: true,
    allowExternal: false,
    addSecurityHeaders: true,
    strictReferrer: true,
  },
};

// ============================================================
// 4. MIME ТИПЫ
// ============================================================

const MIME_TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.mjs': 'application/javascript; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.cjs': 'application/javascript; charset=utf-8',
  '.ts': 'application/typescript; charset=utf-8',
  '.vue': 'text/plain; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.wasm': 'application/wasm',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.gif': 'image/gif',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
  '.txt': 'text/plain; charset=utf-8',
  '.xml': 'application/xml',
  '.pdf': 'application/pdf',
  '.zip': 'application/zip',
  '.map': 'application/json',
  '.woff': 'font/woff',
  '.woff2': 'font/woff2',
  '.ttf': 'font/ttf',
  '.eot': 'application/vnd.ms-fontobject',
  '.otf': 'font/otf',
  '.sh': 'text/plain; charset=utf-8',
  '.md': 'text/markdown; charset=utf-8',
  '.c': 'text/plain; charset=utf-8',
  '.h': 'text/plain; charset=utf-8',
  '.cpp': 'text/plain; charset=utf-8',
  '.hpp': 'text/plain; charset=utf-8',
  '.cc': 'text/plain; charset=utf-8',
  '.py': 'text/plain; charset=utf-8',
  '.rb': 'text/plain; charset=utf-8',
  '.go': 'text/plain; charset=utf-8',
  '.rs': 'text/plain; charset=utf-8',
  '.swift': 'text/plain; charset=utf-8',
  '.kt': 'text/plain; charset=utf-8',
  '.java': 'text/plain; charset=utf-8',
  '.php': 'text/plain; charset=utf-8',
  '.lua': 'text/plain; charset=utf-8',
  '.toml': 'text/plain; charset=utf-8',
  '.yaml': 'text/plain; charset=utf-8',
  '.yml': 'text/plain; charset=utf-8',
  '.sql': 'text/plain; charset=utf-8',
};

// ============================================================
// 5. КАРТА ЯЗЫКОВ
// ============================================================

const LANGUAGE_MAP = {
  '.js': 'javascript',
  '.mjs': 'javascript',
  '.cjs': 'javascript',
  '.ts': 'typescript',
  '.vue': 'vue',
  '.html': 'html',
  '.htm': 'html',
  '.css': 'css',
  '.scss': 'scss',
  '.json': 'json',
  '.c': 'c',
  '.h': 'c',
  '.cpp': 'cpp',
  '.cc': 'cpp',
  '.hpp': 'cpp',
  '.cxx': 'cpp',
  '.sh': 'shell',
  '.bash': 'shell',
  '.md': 'markdown',
  '.txt': 'text',
  '.xml': 'xml',
  '.svg': 'xml',
  '.yaml': 'yaml',
  '.yml': 'yaml',
  '.toml': 'toml',
  '.py': 'python',
  '.rb': 'ruby',
  '.go': 'go',
  '.rs': 'rust',
  '.swift': 'swift',
  '.kt': 'kotlin',
  '.java': 'java',
  '.php': 'php',
  '.lua': 'lua',
  '.r': 'r',
  '.sql': 'sql',
};

// ============================================================
// 6. СПИСОК ФАЙЛОВ ДЛЯ ВСЕГДА РЕНДЕРИНГА ЧЕРЕЗ ШАБЛОН
// ============================================================

const ALWAYS_RENDER_FILES = [
  'server.mjs', 'server.js',
  'widget.mjs', 'widget.js',
  'app.mjs', 'app.js',
  'debug.mjs', 'debug.js',
  'env.mjs', 'env.js',
  'wasm-logger.mjs', 'wasm-logger.js',
  'template.mjs', 'template.js',
  'bookmarklet.js', 'bookmarklet.mjs',
  'index.js', 'main.js',
  'manager.js', 'manager.mjs',
  'sw.js',
];

// ============================================================
// 7. ЛОГГЕР (100% СИМВОЛЫ)
// ============================================================

const LOGGER_SYMBOLS = {
  HISTORY: Symbol('logger.history'),
  MAX_HISTORY: Symbol('logger.maxHistory'),
  DEBUG: Symbol('logger.debug'),
  INSTANCE_ID: Symbol('logger.instanceId'),
};

function createLogger(debug = true, instanceId = 'Server') {
  const state = {
    [LOGGER_SYMBOLS.HISTORY]: [],
    [LOGGER_SYMBOLS.MAX_HISTORY]: 200,
    [LOGGER_SYMBOLS.DEBUG]: debug,
    [LOGGER_SYMBOLS.INSTANCE_ID]: instanceId,
  };

  const logMethod = function (level, message, data = null) {
    if (!this[LOGGER_SYMBOLS.DEBUG] && level !== 'error') {
      return;
    }

    const timestamp = new Date().toISOString().slice(11, 23);
    const prefix = `[${timestamp}] [${this[LOGGER_SYMBOLS.INSTANCE_ID]}]`;

    this[LOGGER_SYMBOLS.HISTORY].push({ timestamp, level, message, data });
    if (this[LOGGER_SYMBOLS.HISTORY].length > this[LOGGER_SYMBOLS.MAX_HISTORY]) {
      this[LOGGER_SYMBOLS.HISTORY].shift();
    }

    if (data !== null && data !== undefined) {
      console.log(`${prefix} ${message}`, data);
    } else {
      console.log(`${prefix} ${message}`);
    }
  };

  const boundLog = logMethod.bind(state);

  const methods = {
    error (msg, d) {
      boundLog('error', `❌ ${msg}`, d);
    },
    warn (msg, d) {
      boundLog('warn', `⚠️ ${msg}`, d);
    },
    info (msg, d) {
      boundLog('info', `ℹ️ ${msg}`, d);
    },
    debug (msg, d) {
      boundLog('debug', `🔍 ${msg}`, d);
    },
    success (msg, d) {
      boundLog('info', `✅ ${msg}`, d);
    },

    header (title) {
      console.log('%c' + '═'.repeat(70), 'color: #636e72;');
      console.log(
        '%c  🚀 ' + title,
        'background: #1a1a2e; color: #fff; padding: 4px 12px; border-radius: 4px; font-weight: bold;',
      );
      console.log('%c' + '═'.repeat(70), 'color: #636e72;');
    },

    separator () {
      console.log('%c' + '─'.repeat(70), 'color: #636e72;');
    },

    symbol (name, symbol) {
      console.log(`  🔑 ${name}: ${String(symbol)}`);
    },

    private (name, symbol) {
      console.log(`  🔒 ${name}: ${String(symbol)}`);
    },

    getHistory () {
      return [...this[LOGGER_SYMBOLS.HISTORY]];
    },

    clearHistory () {
      this[LOGGER_SYMBOLS.HISTORY] = [];
      return this;
    },

    setDebug (enabled) {
      this[LOGGER_SYMBOLS.DEBUG] = enabled;
      return this;
    },
  };

  const logger = {};
  for (const [key, fn] of Object.entries(methods)) {
    logger[key] = fn.bind(state);
  }

  logger[LOGGER_SYMBOLS.HISTORY] = state[LOGGER_SYMBOLS.HISTORY];
  logger[LOGGER_SYMBOLS.MAX_HISTORY] = state[LOGGER_SYMBOLS.MAX_HISTORY];
  logger[LOGGER_SYMBOLS.DEBUG] = state[LOGGER_SYMBOLS.DEBUG];
  logger[LOGGER_SYMBOLS.INSTANCE_ID] = state[LOGGER_SYMBOLS.INSTANCE_ID];

  return logger;
}

// ============================================================
// 8. ВАЛИДАТОР (100% СИМВОЛЫ)
// ============================================================

const VALIDATOR = {
  [PRIVATE.VALIDATOR]: {
    isValidPort: port => typeof port === 'number' && port > 0 && port < 65536,
    isValidHost: host => host && typeof host === 'string' && host.length > 0,
    isValidPath: path => path && typeof path === 'string' && path.length > 0,
    isValidConfig: config => config && typeof config === 'object',
    isValidCallback: fn => typeof fn === 'function',
    isValidCode: code => code && typeof code === 'string',
    isValidOrigin: origin => origin && typeof origin === 'string' && origin.length > 0,
  },
  [PRIVATE.SECURE]: {
    sanitize: value => {
      if (value === null || value === undefined) {return null;}
      if (typeof value === 'string') {return value.replace(/[<>]/g, '');}
      if (typeof value === 'object') {
        try {
          return JSON.parse(JSON.stringify(value));
        } catch {
          return null;
        }
      }
      return value;
    },
    escapeHtml: text => {
      if (!text) {return '';}
      return text
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');
    },
    safePath: path => {
      if (!path) {return '';}
      return path.replace(/\.\./g, '').replace(/\\/g, '/');
    },
  },
};

// ============================================================
// 9. ОСНОВНОЙ КЛАСС СЕРВЕРА (100% СИМВОЛЫ)
// ============================================================

class Server {
  constructor(options = {}) {
    // Используем обычные свойства вместо геттеров
    this._config = { ...DEFAULT_CONFIG, ...options };
    this._version = options.version || DEFAULT_CONFIG.version;
    this._build = options.build || DEFAULT_CONFIG.build;
    this._port = options.port || DEFAULT_CONFIG.port;
    this._host = options.host || DEFAULT_CONFIG.host;
    this._root = options.root || resolve(__dirname, '.');
    this._webRoot = options.webRoot || join(__dirname, 'web');

    this._logger = createLogger(this._config.debug !== false, 'Server');
    const logger = this._logger;

    this._state = {
      initialized: false,
      running: false,
      destroyed: false,
      startTime: null,
      requestCount: 0,
      errorCount: 0,
    };

    this._cache = new Map();
    this._templateCache = new Map();
    this._metadata = {
      created: Date.now(),
      lastAccess: Date.now(),
      lastUpdate: Date.now(),
    };
    this._context = {
      cwd: process.cwd(),
      nodeVersion: process.version,
      platform: process.platform,
    };
    this._logHistory = [];
    this._listeners = [];
    this._eventHandlers = new Map();
    this._timers = new Map();
    this._startTime = null;

    this._template = null;
    this._templateLoaded = false;
    this._templateLoading = false;
    this._templatePromise = null;

    this._server = null;

    this[PRIVATE.INIT]();
    this[PRIVATE.EXPORT_SYMBOLS]();

    logger.success('✅ Сервер создан (100% символы)');
    logger.header('ГОТОВ');
  }

  // ============================================================
  // 10. ИНИЦИАЛИЗАЦИЯ
  // ============================================================

  [PRIVATE.INIT]() {
    const logger = this._logger;
    logger.header('СОЗДАНИЕ СЕРВЕРА (100% СИМВОЛЫ)');
    logger.info(`📦 Версия: ${this._version}`);
    logger.info(`📅 Сборка: ${this._build}`);
    logger.info(`📍 Порт: ${this._port}`);
    logger.info(`📍 Хост: ${this._host}`);
    logger.info(`📁 Корень: ${this._root}`);
    logger.info(`📁 Web: ${this._webRoot}`);
    logger.info(`📌 Отладка: ${this._config.debug ? '✅' : '❌'}`);
    logger.info(`🔒 Проверка Origin: ${this._config.security?.checkOrigin ? '✅' : '❌'}`);
    logger.separator();
    logger.info(`🔑 ПРИВАТНЫХ СИМВОЛОВ: ${Object.keys(PRIVATE).length}`);
    logger.info(`🔑 ПУБЛИЧНЫХ СИМВОЛОВ: ${Object.keys(PUBLIC).length}`);
    logger.separator();

    this._state.initialized = true;
  }

  // ============================================================
  // 11. ЭКСПОРТ СИМВОЛОВ
  // ============================================================

  [PRIVATE.EXPORT_SYMBOLS]() {
    if (typeof window !== 'undefined') {
      window.__server = this;
      window[PUBLIC.API] = this;
      window[PUBLIC.STATE] = this[PRIVATE.GET_STATE].bind(this);
      window[PUBLIC.CONFIG] = this._config;
      window[PUBLIC.LOGGER] = this._logger;
      window[PUBLIC.INSTANCE] = this;
      window[PUBLIC.EVENTS] = {
        on: this.on.bind(this),
        off: this.off.bind(this),
        emit: this.emit.bind(this),
      };

      window.__serverSymbols = {
        PRIVATE: { ...PRIVATE },
        PUBLIC: { ...PUBLIC },
        version: this._version,
        build: this._build,
      };
    }
  }

  // ============================================================
  // 12. ЗАГРУЗКА ШАБЛОНА
  // ============================================================

  async [PRIVATE.LOAD_TEMPLATE]() {
    const logger = this._logger;

    if (this._templateLoaded && this._template) {
      return this._template;
    }

    if (this._templateLoading) {
      return this._templatePromise;
    }

    this._templateLoading = true;
    logger.info('📦 Загрузка шаблона...');

    this._templatePromise = (async () => {
      try {
        const templateModule = await import('./template.mjs');
        this._template = templateModule.default || templateModule;
        this._templateLoaded = true;
        this._templateLoading = false;
        logger.success('✅ Шаблон загружен');
        return this._template;
      } catch (error) {
        this._templateLoading = false;
        this._templateLoaded = false;
        logger.error(`❌ Ошибка загрузки шаблона: ${error.message}`);
        throw error;
      }
    })();

    return this._templatePromise;
  }

  // ============================================================
  // 13. ЗАПУСК СЕРВЕРА
  // ============================================================

  async start() {
    const logger = this._logger;

    if (this._state.running) {
      logger.warn('⚠️ Сервер уже запущен');
      return;
    }

    if (this._state.destroyed) {
      logger.error('❌ Сервер уничтожен');
      return;
    }

    logger.header('ЗАПУСК СЕРВЕРА');

    try {
      await this[PRIVATE.LOAD_TEMPLATE]();

      this._server = createServer((req, res) => {
        this[PRIVATE.HANDLE_REQUEST](req, res);
      });

      this._startTime = Date.now();
      this._state.startTime = this._startTime;

      return new Promise((resolve, reject) => {
        this._server.listen(this._port, this._host, () => {
          this._state.running = true;
          logger.success(`✅ Сервер запущен на http://${this._host}:${this._port}`);
          this[PRIVATE.PRINT_BANNER]();
          resolve(this);
        });

        this._server.on('error', error => {
          this._state.errorCount++;
          logger.error(`❌ Ошибка сервера: ${error.message}`);
          reject(error);
        });
      });
    } catch (error) {
      logger.error(`❌ Ошибка запуска: ${error.message}`);
      throw error;
    }
  }

  // ============================================================
  // 14. НОРМАЛИЗАЦИЯ ПУТИ
  // ============================================================

  [PRIVATE.NORMALIZE_PATH](pathname) {
    if (!pathname || pathname === '/' || pathname === '') {
      return '/index.html';
    }

    if (pathname.startsWith('/.well-known/')) {
      return pathname;
    }

    let normalized = pathname.replace(/\/\/+/g, '/');

    if (normalized.endsWith('/')) {
      normalized += 'index.html';
    }

    return normalized;
  }

  // ============================================================
  // 15. ПРОВЕРКА СУЩЕСТВОВАНИЯ ФАЙЛА
  // ============================================================

  [PRIVATE.FILE_EXISTS](pathname) {
    const filePath = join(this._webRoot, pathname);
    try {
      if (existsSync(filePath)) {
        const stats = statSync(filePath);
        return stats.isFile();
      }
    } catch (error) {
      // Игнорируем ошибки
    }
    return false;
  }

  // ============================================================
  // 16. ПРОВЕРКА КОРНЕВОГО ЗАПРОСА
  // ============================================================

  [PRIVATE.IS_ROOT_REQUEST](pathname) {
    return pathname === '/' || pathname === '' || pathname === '/index.html';
  }

  // ============================================================
  // 17. ПРОВЕРКА ФАЙЛА ДЛЯ ВСЕГДА РЕНДЕРИНГА
  // ============================================================

  [PRIVATE.IS_ALWAYS_RENDER_FILE](filename) {
    return ALWAYS_RENDER_FILES.includes(filename);
  }

  // ============================================================
  // 18. ★★★ ПРОВЕРКА ORIGIN / REFERER (НОВЫЙ СИМВОЛ) ★★★
  // ============================================================

  [PRIVATE.IS_ORIGIN_REQUEST](req) {
    const logger = this._logger;
    const config = this._config;

    // Если проверка Origin отключена — всегда true
    if (!config.security?.checkOrigin) {
      logger.debug('🔍 Проверка Origin отключена');
      return true;
    }

    // 1. Проверяем Origin
    const origin = req.headers.origin;
    if (origin) {
      const isSame = this[PRIVATE.IS_SAME_ORIGIN](origin);
      logger.debug(`🔍 Origin: ${origin} → ${isSame ? '✅' : '❌'}`);
      return isSame;
    }

    // 2. Проверяем Referer
    const referer = req.headers.referer || req.headers.referrer;
    if (referer) {
      try {
        const refererUrl = new URL(referer);
        const isSame = this[PRIVATE.IS_SAME_ORIGIN](refererUrl.origin);
        logger.debug(`🔍 Referer: ${referer} → ${isSame ? '✅' : '❌'}`);
        return isSame;
      } catch (error) {
        logger.debug(`⚠️ Неверный Referer: ${referer}`);
        return false;
      }
    }

    // 3. Если нет ни Origin, ни Referer
    logger.debug(`🔍 Нет Origin и Referer — считаем запросом извне`);
    return false;
  }

  // ============================================================
  // 19. ★★★ СРАВНЕНИЕ ORIGIN (НОВЫЙ СИМВОЛ) ★★★
  // ============================================================

  [PRIVATE.IS_SAME_ORIGIN](origin) {
    if (!origin) {return false;}

    const currentOrigin = this[PRIVATE.GET_CURRENT_ORIGIN]();

    try {
      const originUrl = new URL(origin);
      const currentUrl = new URL(currentOrigin);

      const isSame =
                originUrl.protocol === currentUrl.protocol &&
                originUrl.hostname === currentUrl.hostname &&
                (originUrl.port || (originUrl.protocol === 'https:' ? 443 : 80)) ===
                (currentUrl.port || (currentUrl.protocol === 'https:' ? 443 : 80));

      return isSame;
    } catch (error) {
      // Если не удалось распарсить, сравниваем строки
      return origin === currentOrigin;
    }
  }

  // ============================================================
  // 20. ★★★ ПОЛУЧЕНИЕ ТЕКУЩЕГО ORIGIN (НОВЫЙ СИМВОЛ) ★★★
  // ============================================================

  [PRIVATE.GET_CURRENT_ORIGIN]() {
    const protocol = this._config.ssl ? 'https' : 'http';
    const host = this._host === '0.0.0.0' ? 'localhost' : this._host;
    const port = this._port;
    return `${protocol}://${host}:${port}`;
  }

  // ============================================================
  // 21. ★★★ ДОБАВЛЕНИЕ ЗАЩИТНЫХ ЗАГОЛОВКОВ (НОВЫЙ СИМВОЛ) ★★★
  // ============================================================

  [PRIVATE.ADD_SECURITY_HEADERS](res) {
    const config = this._config;

    if (!config.security?.addSecurityHeaders) {
      return;
    }

    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('X-Frame-Options', 'DENY');
    res.setHeader('Referrer-Policy', config.security?.strictReferrer ? 'strict-origin-when-cross-origin' : 'no-referrer-when-downgrade');
    res.setHeader('X-XSS-Protection', '1; mode=block');
    res.setHeader('X-Permitted-Cross-Domain-Policies', 'none');

    // Если запрос извне — добавляем дополнительные заголовки
    res.setHeader('Cross-Origin-Resource-Policy', 'same-origin');
    res.setHeader('Cross-Origin-Embedder-Policy', 'require-corp');
    res.setHeader('Cross-Origin-Opener-Policy', 'same-origin');

    this._logger.debug('🔒 Защитные заголовки добавлены');
  }

  // ============================================================
  // 22. ПРОВЕРКА — НУЖНО ЛИ РЕНДЕРИТЬ ЧЕРЕЗ ШАБЛОН (ОБНОВЛЕНО)
  // ============================================================

  [PRIVATE.SHOULD_RENDER_WITH_TEMPLATE](pathname, req) {
    const logger = this._logger;
    const ext = extname(pathname);
    const filename = basename(pathname);

    // ★★★ 1. HTML ФАЙЛЫ — НЕ РЕНДЕРИМ ЧЕРЕЗ ШАБЛОН ★★★
    if (ext === '.html' || ext === '.htm') {
      logger.debug(`📄 HTML файл: ${filename} — отдаем как есть`);
      return false;
    }

    // ★★★ 2. КОРНЕВОЙ ЗАПРОС — НЕ РЕНДЕРИМ ЧЕРЕЗ ШАБЛОН ★★★
    if (this[PRIVATE.IS_ROOT_REQUEST](pathname)) {
      logger.debug(`📄 Корневой запрос: ${pathname} — НЕ рендерим через шаблон`);
      return false;
    }

    // ★★★ 3. НЕ КОДОВЫЕ ФАЙЛЫ — НЕ РЕНДЕРИМ ★★★
    const isCodeFile = this[PRIVATE.IS_CODE_FILE](ext);
    if (!isCodeFile) {
      logger.debug(`📄 Не кодовый файл: ${filename} — НЕ рендерим через шаблон`);
      return false;
    }

    // ★★★ 4. ПРОВЕРКА СУЩЕСТВОВАНИЯ ФАЙЛА ★★★
    const fileExists = this[PRIVATE.FILE_EXISTS](pathname);

    // ★★★ 5. ПРОВЕРКА ORIGIN / REFERER ★★★
    const isOrigin = this[PRIVATE.IS_ORIGIN_REQUEST](req);
    logger.debug(`📌 Origin проверка: ${isOrigin ? '✅' : '❌'}`);

    // ★★★ 6. ЕСЛИ ФАЙЛ СУЩЕСТВУЕТ И ЭТО ЗАПРОС С ТОГО ЖЕ ORIGIN — ОТДАЕМ КАК СТАТИКУ ★★★
    if (fileExists && isOrigin) {
      logger.debug(`📄 Кодовый файл существует (с origin): ${filename} — отдаем как статику`);
      return false;
    }

    // ★★★ 7. ЕСЛИ ФАЙЛ СУЩЕСТВУЕТ, НО ЗАПРОС ИЗВНЕ — ОТДАЕМ С ПРЕДУПРЕЖДЕНИЕМ ★★★
    if (fileExists && !isOrigin) {
      logger.warn(`⚠️ Запрос извне к файлу: ${filename}  — рендерим через шаблон`);
      // Добавляем заголовки безопасности для этого ответа
      // this[PRIVATE.ADD_SECURITY_HEADERS](res);
      return true;
    }

    // ★★★ 8. ЕСЛИ ФАЙЛ В СПИСКЕ ALWAYS_RENDER — РЕНДЕРИМ ЧЕРЕЗ ШАБЛОН ★★★
    const isAlwaysRender = this[PRIVATE.IS_ALWAYS_RENDER_FILE](filename);
    if (isAlwaysRender) {
      logger.debug(`📄 Файл в списке alwaysRender (не существует): ${filename} — рендерим через шаблон`);
      return true;
    }

    // ★★★ 9. ПО УМОЛЧАНИЮ — НЕ РЕНДЕРИМ ★★★
    logger.debug(`📄 Кодовый файл не существует и не в alwaysRender: ${filename} — НЕ рендерим`);
    return false;
  }

  // ============================================================
  // 23. ПОИСК ФАЙЛА
  // ============================================================

  [PRIVATE.FIND_FILE](pathname) {
    const logger = this._logger;
    const searchPaths = [];

    // 1. Основной путь в web директории
    const webPath = join(this._webRoot, pathname);
    searchPaths.push(webPath);
    logger.debug(`🔍 Поиск: ${webPath}`);

    // 2. Для .well-known путей проверяем несколько вариантов
    if (pathname.startsWith('/.well-known/')) {
      const relativePath = pathname.replace('/.well-known/', '');
      searchPaths.push(join(this._webRoot, '.well-known', relativePath));
      searchPaths.push(join(this._root, '.well-known', relativePath));
      searchPaths.push(join(__dirname, '.well-known', relativePath));
    }

    // 3. Если путь заканчивается на /index.html — пробуем без index.html
    if (pathname.endsWith('/index.html')) {
      const dirPath = pathname.slice(0, -10);
      searchPaths.push(join(this._webRoot, dirPath));
    }

    // 4. В корне проекта
    searchPaths.push(join(this._root, pathname));

    // 5. В текущей директории
    searchPaths.push(join(__dirname, pathname));

    for (const searchPath of searchPaths) {
      try {
        if (existsSync(searchPath)) {
          const stats = statSync(searchPath);
          if (stats.isFile()) {
            logger.debug(`✅ Найден файл: ${searchPath}`);
            return searchPath;
          }
          if (stats.isDirectory()) {
            const indexPath = join(searchPath, 'index.html');
            if (existsSync(indexPath)) {
              logger.debug(`✅ Найден index.html: ${indexPath}`);
              return indexPath;
            }
          }
        } else {
          logger.debug(`❌ Файл не найден: ${searchPath}`);
        }
      } catch (error) {
        logger.debug(`⚠️ Ошибка проверки ${searchPath}: ${error.message}`);
      }
    }

    return null;
  }

  // ============================================================
  // 24. ОБРАБОТЧИК ЗАПРОСОВ (ОБНОВЛЕНО)
  // ============================================================

  [PRIVATE.HANDLE_REQUEST](req, res) {
    const logger = this._logger;
    this._state.requestCount++;

    const url = new URL(req.url, `http://${req.headers.host}`);
    let pathname = url.pathname;

    try {
      pathname = decodeURIComponent(pathname);
    } catch {
      pathname = url.pathname;
    }

    pathname = this[PRIVATE.NORMALIZE_PATH](pathname);

    const ext = extname(pathname);
    const isHtmlFile = ext === '.html' || ext === '.htm';
    const isCodeFile = this[PRIVATE.IS_CODE_FILE](ext);
    const isWellKnown = pathname.startsWith('/.well-known/');

    logger.debug(`📥 ${req.method} ${pathname} (ext: ${ext || 'no ext'}, isCodeFile: ${isCodeFile})`);

    // ============================================================
    // 0. .well-known ФАЙЛЫ — ОТДАЕМ КАК СТАТИКУ
    // ============================================================

    if (isWellKnown) {
      this[PRIVATE.SERVE_STATIC](pathname, req, res);
      return;
    }

    // ============================================================
    // 1. HTML ФАЙЛЫ — ОТДАЕМ КАК ЕСТЬ
    // ============================================================

    if (isHtmlFile) {
      this[PRIVATE.SERVE_STATIC](pathname, req, res);
      return;
    }

    // ============================================================
    // 2. КОДОВЫЕ ФАЙЛЫ — ПРОВЕРЯЕМ НУЖНО ЛИ РЕНДЕРИТЬ
    // ============================================================

    if (isCodeFile) {
      const shouldRender = this[PRIVATE.SHOULD_RENDER_WITH_TEMPLATE](pathname, req);
      if (shouldRender) {
        this[PRIVATE.SERVE_CODE](pathname, req, res);
        return;
      } else {
        this[PRIVATE.SERVE_STATIC](pathname, req, res);
        return;
      }
    }

    // ============================================================
    // 3. ВСЕ ОСТАЛЬНЫЕ ФАЙЛЫ — КАК СТАТИКА
    // ============================================================

    this[PRIVATE.SERVE_STATIC](pathname, req, res);
  }

  // ============================================================
  // 25. ОБСЛУЖИВАНИЕ СТАТИЧЕСКИХ ФАЙЛОВ (ОБНОВЛЕНО)
  // ============================================================

  [PRIVATE.SERVE_STATIC](pathname, req, res) {
    const logger = this._logger;

    const filePath = this[PRIVATE.FIND_FILE](pathname);

    if (filePath) {
      // Добавляем защитные заголовки если нужно
      this[PRIVATE.ADD_SECURITY_HEADERS](res);
      this[PRIVATE.SEND_FILE](filePath, res);
      return;
    }

    logger.warn(`❌ Файл не найден: ${pathname}`);
    this[PRIVATE.ERROR_404_WITH_DETAILS](res, pathname);
  }

  // ============================================================
  // 26. ОТПРАВКА ФАЙЛА
  // ============================================================

  [PRIVATE.SEND_FILE](filePath, res) {
    const logger = this._logger;
    const ext = extname(filePath);
    const mimeType = this[PRIVATE.GET_MIME_TYPE](ext);
    const filename = basename(filePath);

    try {
      const content = readFileSync(filePath);
      const size = content.length;

      logger.info(`📤 Отправка: ${filename} (${size} байт, ${mimeType})`);

      res.writeHead(200, {
        'Content-Type': mimeType,
        'Content-Length': size,
        'Cache-Control': 'no-cache, no-store, must-revalidate',
        'Pragma': 'no-cache',
        'Expires': '0',
      });
      res.end(content);
    } catch (error) {
      logger.error(`❌ Ошибка чтения файла ${filename}: ${error.message}`);
      this[PRIVATE.ERROR_500](res, error);
    }
  }

  // ============================================================
  // 27. ОБСЛУЖИВАНИЕ КОДОВЫХ ФАЙЛОВ (ЧЕРЕЗ ШАБЛОН)
  // ============================================================

  [PRIVATE.SERVE_CODE](pathname, req, res) {
    const logger = this._logger;

    const filePath = this[PRIVATE.FIND_FILE](pathname);

    if (filePath) {
      try {
        const content = readFileSync(filePath, 'utf-8');
        const ext = extname(filePath);
        const filename = basename(filePath);
        const language = this[PRIVATE.DETECT_LANGUAGE](ext);
        const lines = content.split('\n').length;

        logger.info(`📄 Код через шаблон: ${filename} (${language}, ${lines} строк)`);
        this[PRIVATE.RENDER_TEMPLATE](res, content, {
          filename,
          language,
          lineCount: lines,
          ext,
          path: filePath,
        });
        return;
      } catch (error) {
        logger.error(`❌ Ошибка чтения кода: ${error.message}`);
      }
    }

    this[PRIVATE.ERROR_404](res, pathname);
  }

  // ============================================================
  // 28. РЕНДЕРИНГ ШАБЛОНА
  // ============================================================

  async [PRIVATE.RENDER_TEMPLATE](res, code, fileInfo) {
    const logger = this._logger;

    try {
      if (!this._templateLoaded) {
        await this[PRIVATE.LOAD_TEMPLATE]();
      }

      if (!this._template) {
        throw new Error('Шаблон не загружен');
      }

      const cacheKey = `${fileInfo.filename}:${fileInfo.language}:${code.length}`;
      if (this._templateCache.has(cacheKey)) {
        const cached = this._templateCache.get(cacheKey);
        if (Date.now() - cached.timestamp < this._config.templateCacheTTL) {
          logger.debug(`📦 Кеш шаблона: ${fileInfo.filename}`);
          res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
          res.end(cached.html);
          return;
        }
        this._templateCache.delete(cacheKey);
      }

      const html = await this._template(code, fileInfo);

      if (code.length < 100 * 1024) {
        this._templateCache.set(cacheKey, {
          html,
          timestamp: Date.now(),
          size: html.length,
        });
        if (this._templateCache.size > this._config.maxCacheSize) {
          const keys = Array.from(this._templateCache.keys());
          for (let i = 0; i < Math.floor(keys.length / 2); i++) {
            this._templateCache.delete(keys[i]);
          }
        }
      }

      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
      res.end(html);

      logger.debug(`✅ Рендеринг: ${fileInfo.filename} (${html.length} байт)`);
    } catch (error) {
      logger.error(`❌ Ошибка рендеринга: ${error.message}`);
      this[PRIVATE.ERROR_500](res, error);
    }
  }

  // ============================================================
  // 29. ВСПОМОГАТЕЛЬНЫЕ МЕТОДЫ
  // ============================================================

  [PRIVATE.DETECT_LANGUAGE](ext) {
    return LANGUAGE_MAP[ext] || 'text';
  }

  [PRIVATE.GET_MIME_TYPE](ext) {
    return MIME_TYPES[ext] || 'application/octet-stream';
  }

  [PRIVATE.IS_CODE_FILE](ext) {
    const codeExts = ['.js', '.mjs', '.cjs', '.ts', '.vue'];
    return codeExts.includes(ext);
  }

  [PRIVATE.IS_HTML_FILE](ext) {
    return ext === '.html' || ext === '.htm';
  }

  // ============================================================
  // 30. ОШИБКИ
  // ============================================================

  [PRIVATE.ERROR_404](res, pathname) {
    res.writeHead(404, { 'Content-Type': 'text/html; charset=utf-8' });
    res.end(`\n<!DOCTYPE html>\n<html>\n<head>\n  <title>404 - Файл не найден</title>\n  <style>\n    body { font-family: monospace; background: #1e1e1e; color: #d4d4d4; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; }\n    .container { text-align: center; }\n    h1 { font-size: 72px; color: #f48771; margin: 0; }\n    .file { color: #4ec9b0; }\n    .info { color: #808080; margin-top: 20px; }\n    a { color: #667eea; text-decoration: none; }\n    a:hover { text-decoration: underline; }\n  </style>\n</head>\n<body>\n  <div class="container">\n    <h1>404</h1>\n    <p>Файл <span class="file">${VALIDATOR[PRIVATE.SECURE].escapeHtml(pathname)}</span> не найден</p>\n    <p class="info"><a href="/">← На главную</a></p>\n  </div>\n</body>\n</html>`);
  }

  [PRIVATE.ERROR_404_WITH_DETAILS](res, pathname) {
    const logger = this._logger;

    const webIndexPath = join(this._webRoot, 'index.html');
    const webPathExists = existsSync(webIndexPath);
    const requestedPath = join(this._webRoot, pathname);
    const requestedExists = existsSync(requestedPath);

    logger.warn(`📊 404: ${pathname}`);
    logger.warn(`   Web: ${this._webRoot}`);
    logger.warn(`   index.html: ${webPathExists ? '✅' : '❌'}`);
    logger.warn(`   Запрошенный путь: ${requestedPath} (${requestedExists ? '✅' : '❌'})`);

    res.writeHead(404, { 'Content-Type': 'text/html; charset=utf-8' });
    res.end(`\n<!DOCTYPE html>\n<html>\n<head>\n  <title>404 - Файл не найден</title>\n  <style>\n    body { font-family: monospace; background: #1e1e1e; color: #d4d4d4; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; }\n    .container { text-align: center; max-width: 600px; }\n    h1 { font-size: 72px; color: #f48771; margin: 0; }\n    .file { color: #4ec9b0; }\n    .info { color: #808080; margin-top: 20px; }\n    a { color: #667eea; text-decoration: none; }\n    a:hover { text-decoration: underline; }\n    .paths {\n      font-size: 12px;\n      color: #808080;\n      margin-top: 20px;\n      text-align: left;\n      background: rgba(0,0,0,0.3);\n      padding: 16px;\n      border-radius: 8px;\n      border: 1px solid rgba(255,255,255,0.05);\n    }\n    .paths .found { color: #4ec9b0; }\n    .paths .not-found { color: #f48771; }\n    .paths .label { color: #636e72; }\n  </style>\n</head>\n<body>\n  <div class="container">\n    <h1>404</h1>\n    <p>Файл <span class="file">${VALIDATOR[PRIVATE.SECURE].escapeHtml(pathname)}</span> не найден</p>\n    <p class="info"><a href="/">← На главную</a></p>\n    <div class="paths">\n      <div><span class="label">📁 Web:</span> ${this._webRoot}</div>\n      <div><span class="label">📄 index.html:</span> ${webPathExists ? '✅ <span class="found">найден</span>' : '❌ <span class="not-found">не найден</span>'}</div>\n      <div><span class="label">📄 ${pathname}:</span> ${requestedExists ? '✅ <span class="found">найден</span>' : '❌ <span class="not-found">не найден</span>'}</div>\n      <div><span class="label">📁 Корень:</span> ${this._root}</div>\n      <div style="margin-top:8px;font-size:11px;color:#636e72;">\n        💡 Убедитесь, что файл <code>${pathname}</code> существует в директории web\n      </div>\n    </div>\n  </div>\n</body>\n</html>`);
  }

  [PRIVATE.ERROR_500](res, error) {
    res.writeHead(500, { 'Content-Type': 'text/html; charset=utf-8' });
    res.end(`\n<!DOCTYPE html>\n<html>\n<head>\n  <title>500 - Ошибка сервера</title>\n  <style>\n    body { font-family: monospace; background: #1e1e1e; color: #d4d4d4; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; }\n    .container { text-align: center; max-width: 600px; }\n    h1 { font-size: 48px; color: #f48771; margin: 0; }\n    .error { color: #f48771; }\n    .info { color: #808080; margin-top: 20px; }\n    .stack { color: #636e72; font-size: 12px; text-align: left; background: rgba(0,0,0,0.3); padding: 12px; border-radius: 4px; margin-top: 12px; overflow: auto; max-height: 200px; }\n    a { color: #667eea; text-decoration: none; }\n    a:hover { text-decoration: underline; }\n  </style>\n</head>\n<body>\n  <div class="container">\n    <h1>500</h1>\n    <p class="error">❌ Внутренняя ошибка сервера</p>\n    <p style="color: #f48771;">${VALIDATOR[PRIVATE.SECURE].escapeHtml(error.message)}</p>\n    ${error.stack ? `<div class="stack">${VALIDATOR[PRIVATE.SECURE].escapeHtml(error.stack)}</div>` : ''}\n    <p class="info"><a href="/">← На главную</a></p>\n  </div>\n</body>\n</html>`);
  }

  // ============================================================
  // 31. ПЕЧАТЬ БАННЕРА
  // ============================================================

  [PRIVATE.PRINT_BANNER]() {
    const logger = this._logger;
    const port = this._port;
    const host = this._host;
    const hostDisplay = host === '0.0.0.0' ? 'localhost' : host;

    logger.header('СЕРВЕР ЗАПУЩЕН');
    console.log(`  🌐 URL: http://${hostDisplay}:${port}`);
    console.log(`  📁 Web: ${this._webRoot}`);
    console.log(`  📁 Корень: ${this._root}`);
    console.log(`  📌 Версия: ${this._version}`);
    console.log(`  📌 Сборка: ${this._build}`);
    console.log(`  📌 Отладка: ${this._config.debug ? '✅' : '❌'}`);
    console.log(`  🔒 Проверка Origin: ${this._config.security?.checkOrigin ? '✅' : '❌'}`);
    console.log('');
    console.log('  📋 ДОСТУПНЫЕ ПУТИ:');
    console.log(`    • http://${hostDisplay}:${port}/ → /index.html`);
    console.log(`    • http://${hostDisplay}:${port}/index.html`);
    console.log(`    • http://${hostDisplay}:${port}/Bookmarklet/manager.html`);
    console.log(`    • .js/.mjs/.cjs/.ts/.vue — как статика (если файл существует)`);
    console.log(`    • .js/.mjs/.cjs/.ts/.vue — через шаблон (если файл в alwaysRender и не существует)`);
    console.log(`    • .html/.htm — отдаются как есть`);
    console.log(`    • /.well-known/ — статические файлы`);
    console.log(`    • sw.js — через шаблон (если не существует)`);
    console.log('');
    console.log('  🔒 БЕЗОПАСНОСТЬ:');
    console.log(`    • Проверка Origin: ${this._config.security?.checkOrigin ? '✅' : '❌'}`);
    console.log(`    • Защитные заголовки: ${this._config.security?.addSecurityHeaders ? '✅' : '❌'}`);
    console.log(`    • External access: ${this._config.security?.allowExternal ? '✅ разрешён' : '❌ ограничен'}`);
    console.log('');
    console.log('  📌 ПРИМЕРЫ:');
    console.log(`    • http://${hostDisplay}:${port}/ (index.html)`);
    console.log(`    • http://${hostDisplay}:${port}/widget.mjs (статика, если файл существует)`);
    console.log(`    • http://${hostDisplay}:${port}/Bookmarklet/bookmarklet.js (статика)`);
    console.log(`    • http://${hostDisplay}:${port}/server.mjs (шаблон, если файл не существует)`);
    console.log(`    • http://${hostDisplay}:${port}/sw.js (шаблон, если файл не существует)`);
    console.log('');
    console.log('  📋 КОМАНДЫ ОТЛАДКИ:');
    console.log('    curl http://localhost:' + port + '/Bookmarklet/bookmarklet.js');
    console.log('    open http://localhost:' + port + '/');
    logger.header('ГОТОВ');
  }

  // ============================================================
  // 32. ОСТАНОВКА
  // ============================================================

  stop() {
    const logger = this._logger;

    if (!this._state.running) {
      logger.warn('⚠️ Сервер не запущен');
      return;
    }

    logger.info('⏹️ Остановка сервера...');

    return new Promise(resolve => {
      if (this._server) {
        this._server.close(() => {
          this._state.running = false;
          logger.success('✅ Сервер остановлен');
          resolve();
        });
      } else {
        this._state.running = false;
        resolve();
      }
    });
  }

  // ============================================================
  // 33. СОБЫТИЯ
  // ============================================================

  on(event, callback) {
    if (!VALIDATOR[PRIVATE.VALIDATOR].isValidCallback(callback)) {
      this._logger.warn(`⚠️ Некорректный callback для события ${event}`);
      return () => {};
    }

    if (!this._eventHandlers.has(event)) {
      this._eventHandlers.set(event, []);
    }
    this._eventHandlers.get(event).push(callback);

    return () => this.off(event, callback);
  }

  off(event, callback) {
    if (this._eventHandlers.has(event)) {
      const handlers = this._eventHandlers.get(event);
      const index = handlers.indexOf(callback);
      if (index !== -1) {
        handlers.splice(index, 1);
      }
      if (handlers.length === 0) {
        this._eventHandlers.delete(event);
      }
    }
  }

  emit(event, data) {
    if (this._eventHandlers.has(event)) {
      const handlers = this._eventHandlers.get(event);
      for (const callback of handlers) {
        try {
          callback(data);
        } catch (error) {
          this._logger.error(`❌ Ошибка в обработчике ${event}:`, error);
        }
      }
    }
  }

  // ============================================================
  // 34. ПОЛУЧЕНИЕ СОСТОЯНИЯ
  // ============================================================

  [PRIVATE.GET_STATE]() {
    return {
      version: this._version,
      build: this._build,
      port: this._port,
      host: this._host,
      root: this._root,
      webRoot: this._webRoot,
      initialized: this._state.initialized,
      running: this._state.running,
      destroyed: this._state.destroyed,
      requestCount: this._state.requestCount,
      errorCount: this._state.errorCount,
      startTime: this._startTime,
      uptime: this._startTime ? Date.now() - this._startTime : 0,
      templateLoaded: this._templateLoaded,
      cacheSize: this._cache.size,
      templateCacheSize: this._templateCache.size,
      metadata: { ...this._metadata },
      context: { ...this._context },
      config: { ...this._config },
      security: {
        checkOrigin: this._config.security?.checkOrigin || false,
        addSecurityHeaders: this._config.security?.addSecurityHeaders || false,
        allowExternal: this._config.security?.allowExternal || false,
      },
    };
  }

  getState() {
    return this[PRIVATE.GET_STATE]();
  }

  // ============================================================
  // 35. СБРОС И УНИЧТОЖЕНИЕ
  // ============================================================

  reset() {
    const logger = this._logger;
    logger.warn('🔄 Сброс состояния...');

    this._cache.clear();
    this._templateCache.clear();
    this._logHistory = [];
    this._state.requestCount = 0;
    this._state.errorCount = 0;

    this._metadata = {
      created: Date.now(),
      lastAccess: Date.now(),
      lastUpdate: Date.now(),
    };

    this.emit('reset', { timestamp: Date.now() });
    logger.success('✅ Состояние сброшено');
    return this;
  }

  destroy() {
    if (this._state.destroyed) {
      this._logger.warn('⚠️ Сервер уже уничтожен');
      return;
    }

    const logger = this._logger;
    logger.warn('🗑️ Уничтожение сервера...');

    if (this._state.running) {
      this.stop();
    }

    for (const [key, timer] of this._timers) {
      clearInterval(timer);
      clearTimeout(timer);
    }
    this._timers.clear();

    this._cache.clear();
    this._templateCache.clear();
    this._eventHandlers.clear();
    this._listeners = [];
    this._logHistory = [];

    if (typeof window !== 'undefined') {
      delete window.__server;
      delete window[PUBLIC.API];
      delete window[PUBLIC.STATE];
      delete window[PUBLIC.CONFIG];
      delete window[PUBLIC.LOGGER];
      delete window[PUBLIC.INSTANCE];
      delete window[PUBLIC.EVENTS];
      delete window.__serverSymbols;
    }

    this._state.destroyed = true;
    this._state.initialized = false;
    this._state.running = false;

    this.emit('destroyed', { timestamp: Date.now() });
    logger.success('✅ Сервер уничтожен');
  }
}

// ============================================================
// 36. СОЗДАНИЕ ЭКЗЕМПЛЯРА
// ============================================================

let serverInstance = null;

function getServerInstance(options = {}) {
  if (!serverInstance) {
    serverInstance = new Server(options);
    if (typeof window !== 'undefined') {
      window.__serverInstance = serverInstance;
    }
  }
  return serverInstance;
}

// ============================================================
// 37. ЭКСПОРТ
// ============================================================

export default getServerInstance;

export {
  Server,
  getServerInstance,
  PRIVATE,
  PUBLIC,
  DEFAULT_CONFIG,
  MIME_TYPES,
  LANGUAGE_MAP,
  ALWAYS_RENDER_FILES,
};

// ============================================================
// 38. ЗАПУСК
// ============================================================

const isMainModule = import.meta.url === `file://${process.argv[1]}`;

// if (isMainModule) {
  const port = parseInt(process.env.PORT) || 8081;
  const host = process.env.HOST || '0.0.0.0';
  const debug = process.env.DEBUG !== 'false';

  const server = getServerInstance({
    port,
    host,
    debug,
    security: {
      checkOrigin: true,
      addSecurityHeaders: true,
      allowExternal: false,
      strictReferrer: true,
    },
  });

  server.start().catch(error => {
    console.error('❌ Ошибка запуска сервера:', error);
    process.exit(1);
  });

  const shutdown = async () => {
    console.log('\n🛑 Получен сигнал остановки...');
    try {
      await server.stop();
      process.exit(0);
    } catch (error) {
      console.error('❌ Ошибка остановки:', error);
      process.exit(1);
    }
  };

  process.on('SIGINT', shutdown);
  process.on('SIGTERM', shutdown);
// }

// ============================================================
// 39. КОМАНДЫ ДЛЯ ОТЛАДКИ
// ============================================================

if (typeof window !== 'undefined') {
  window.__srv = {
    instance: window.__serverInstance || window.__server,
    getState: () => window.__serverInstance?.getState?.(),
    start: () => window.__serverInstance?.start?.(),
    stop: () => window.__serverInstance?.stop?.(),
    reset: () => window.__serverInstance?.reset?.(),
    destroy: () => window.__serverInstance?.destroy?.(),
    getSymbols: () => ({
      PRIVATE: { ...PRIVATE },
      PUBLIC: { ...PUBLIC },
    }),
  };

  console.log('📋 КОМАНДЫ ОТЛАДКИ (__srv):');
  console.log('  __srv.getState()   - состояние');
  console.log('  __srv.start()      - запустить');
  console.log('  __srv.stop()       - остановить');
  console.log('  __srv.reset()      - сбросить');
  console.log('  __srv.destroy()    - уничтожить');
  console.log('  __srv.getSymbols() - получить символы');
  console.log('');
  console.log('🔒 БЕЗОПАСНОСТЬ:');
  console.log('  Проверка Origin: ✅ включена');
  console.log('  Защитные заголовки: ✅ включены');
  console.log('  Внешние запросы: ❌ ограничены');
}
