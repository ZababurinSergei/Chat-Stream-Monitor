// config_generator.c
#include "config_generator.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <stdarg.h>
#include <math.h>
#include <getopt.h>

// ============================================================================
// Вспомогательные функции для работы со строками
// ============================================================================

static char* str_append(char *dest, const char *src) {
    if (!dest) {
        dest = malloc(strlen(src) + 1);
        if (dest) strcpy(dest, src);
        return dest;
    }
    size_t new_len = strlen(dest) + strlen(src) + 1;
    char *new = realloc(dest, new_len);
    if (new) {
        strcat(new, src);
        return new;
    }
    return dest;
}

static char* str_append_format(char *dest, const char *format, ...) {
    char buffer[1024];
    va_list args;
    va_start(args, format);
    vsnprintf(buffer, sizeof(buffer), format, args);
    va_end(args);
    return str_append(dest, buffer);
}

static int is_valid_city_code(const char *code) {
    if (!code || strlen(code) != 3) return 0;
    for (int i = 0; i < 3; i++) {
        if (code[i] < 'A' || code[i] > 'Z') return 0;
    }
    return 1;
}

// ============================================================================
// Инициализация конфига
// ============================================================================

void config_init(config_t *cfg) {
    if (!cfg) return;

    memset(cfg, 0, sizeof(config_t));

    // Версия
    strcpy(cfg->version, "2.0.0");
    strcpy(cfg->description, "MTProto MQTT Gateway Configuration");

    // Workspace
    strcpy(cfg->workspace_name, "mqtt.onemesh.ru");
    strcpy(cfg->workspace_description, "Корневой путь брокера для сохранения структуры всех входящих сообщений");

    // Namespace
    strcpy(cfg->namespace_base, "msh/RU/SPB/2/e/ELITE");
    strcpy(cfg->namespace_network, "msh");
    strcpy(cfg->namespace_region, "RU");
    strcpy(cfg->namespace_city, "SPB");
    strcpy(cfg->namespace_version, "2");
    strcpy(cfg->namespace_type, "e");
    strcpy(cfg->namespace_name, "ELITE");

    // Metaflow
    strcpy(cfg->metaflow_path, ".metaflow");
    strcpy(cfg->metaflow_state_file, ".metaflow/state.json");
    strcpy(cfg->metaflow_report_file, ".metaflow/report.json");
    strcpy(cfg->metaflow_summary_file, ".metaflow/summary.txt");
    strcpy(cfg->metaflow_history_dir, ".metaflow/history/");

    // Broker
    strcpy(cfg->broker_host, "mqtt.onemesh.ru");
    cfg->broker_port = 1883;
    cfg->broker_tls_port = 8883;
    strcpy(cfg->broker_protocol, "mqtt");
    strcpy(cfg->broker_username, "onemesh");
    strcpy(cfg->broker_password, "onecat");
    cfg->broker_clean_session = 1;
    cfg->broker_reconnect_period = 1000;
    cfg->broker_connect_timeout = 30000;
    cfg->broker_keepalive = 60;

    // Routing
    cfg->max_hops = 5;
    cfg->default_qos = 1;
    cfg->default_retain = 0;
    cfg->enable_logging = 1;
    cfg->enable_stats = 1;
    cfg->cycle_detection = 1;
    cfg->broadcast_to_all = 0;

    // Crypto
    strcpy(cfg->crypto_type, "hybrid");
    strcpy(cfg->crypto_kem, "ML-KEM-768");
    strcpy(cfg->crypto_signature, "ML-DSA-65");
    strcpy(cfg->crypto_classic, "ECDH-X25519");
    cfg->encryption_enabled = 1;
    cfg->pq_enabled = 1;

    // Monitoring
    cfg->monitoring_enabled = 1;
    cfg->monitoring_interval = 60;
    cfg->monitoring_node_offline = 1;
    cfg->monitoring_high_latency = 1;
    cfg->monitoring_message_drop = 1;
    cfg->monitoring_error_rate = 1;
    cfg->monitoring_latency_ms = 1000;
    cfg->monitoring_error_rate_percent = 5;
    cfg->monitoring_message_drop_percent = 10;

    // Intervals
    cfg->position_interval = 30000;
    cfg->text_message_interval = 60000;
    cfg->node_info_interval = 120000;
    cfg->map_report_interval = 0;
    cfg->initial_delay = 2000;
    cfg->periodic_message_interval = 15000;

    cfg->city_count = 0;
    cfg->rule_count = 0;
    cfg->node_count = 0;
    cfg->test_node_count = 0;
}

// ============================================================================
// Установка основных параметров
// ============================================================================

void config_set_workspace(config_t *cfg, const char *name, const char *description) {
    if (!cfg) return;
    if (name) strcpy(cfg->workspace_name, name);
    if (description) strcpy(cfg->workspace_description, description);
}

void config_set_namespace(config_t *cfg, const char *network, const char *region,
                          const char *city, const char *version,
                          const char *type, const char *namespace_name) {
    if (!cfg) return;

    if (network) strcpy(cfg->namespace_network, network);
    if (region) strcpy(cfg->namespace_region, region);
    if (city) strcpy(cfg->namespace_city, city);
    if (version) strcpy(cfg->namespace_version, version);
    if (type) strcpy(cfg->namespace_type, type);
    if (namespace_name) strcpy(cfg->namespace_name, namespace_name);

    snprintf(cfg->namespace_base, sizeof(cfg->namespace_base),
             "%s/%s/%s/%s/%s/%s",
             cfg->namespace_network, cfg->namespace_region, cfg->namespace_city,
             cfg->namespace_version, cfg->namespace_type, cfg->namespace_name);
}

void config_set_metaflow(config_t *cfg, const char *path) {
    if (!cfg) return;
    if (path) {
        strcpy(cfg->metaflow_path, path);
        snprintf(cfg->metaflow_state_file, sizeof(cfg->metaflow_state_file),
                 "%s/state.json", path);
        snprintf(cfg->metaflow_report_file, sizeof(cfg->metaflow_report_file),
                 "%s/report.json", path);
        snprintf(cfg->metaflow_summary_file, sizeof(cfg->metaflow_summary_file),
                 "%s/summary.txt", path);
        snprintf(cfg->metaflow_history_dir, sizeof(cfg->metaflow_history_dir),
                 "%s/history/", path);
    }
}

void config_set_broker(config_t *cfg, const char *host, int port,
                       const char *username, const char *password) {
    if (!cfg) return;
    if (host) strcpy(cfg->broker_host, host);
    if (port > 0) cfg->broker_port = port;
    if (username) strcpy(cfg->broker_username, username);
    if (password) strcpy(cfg->broker_password, password);
}

// ============================================================================
// Работа с городами
// ============================================================================

int config_add_city(config_t *cfg, const char *code, const char *name,
                    int topics, int messages, double lat, double lon) {
    if (!cfg || !code || !name) return -1;
    if (cfg->city_count >= MAX_CITIES) return -2;
    if (!is_valid_city_code(code)) return -3;

    int idx = cfg->city_count++;
    strcpy(cfg->cities[idx].code, code);
    strcpy(cfg->cities[idx].name, name);
    cfg->cities[idx].topics = topics;
    cfg->cities[idx].messages = messages;
    cfg->cities[idx].lat = lat;
    cfg->cities[idx].lon = lon;
    cfg->cities[idx].enabled = 1;

    snprintf(cfg->cities[idx].namespace_path, sizeof(cfg->cities[idx].namespace_path),
             "%s/%s/%s/%s/%s/%s",
             cfg->namespace_network, cfg->namespace_region, code,
             cfg->namespace_version, cfg->namespace_type, cfg->namespace_name);

    snprintf(cfg->cities[idx].full_path, sizeof(cfg->cities[idx].full_path),
             "%s/%s", cfg->workspace_name, cfg->cities[idx].namespace_path);

    return idx;
}

city_t* config_get_city(config_t *cfg, const char *code) {
    if (!cfg || !code) return NULL;
    for (int i = 0; i < cfg->city_count; i++) {
        if (strcmp(cfg->cities[i].code, code) == 0) {
            return &cfg->cities[i];
        }
    }
    return NULL;
}

// ============================================================================
// Работа с правилами маршрутизации
// ============================================================================

int config_add_rule(config_t *cfg, const char *name, const char *source,
                    const char *target, int priority, int qos, int retain) {
    if (!cfg || !name || !source || !target) return -1;
    if (cfg->rule_count >= MAX_RULES) return -2;

    int idx = cfg->rule_count++;
    strcpy(cfg->rules[idx].name, name);
    strcpy(cfg->rules[idx].source, source);
    strcpy(cfg->rules[idx].target, target);
    cfg->rules[idx].priority = priority;
    cfg->rules[idx].qos = qos;
    cfg->rules[idx].retain = retain;
    cfg->rules[idx].enabled = 1;

    return idx;
}

// ============================================================================
// Работа с узлами
// ============================================================================

int config_add_node(config_t *cfg, const char *id, const char *name,
                    const char *type, const char *city, int hop_limit) {
    if (!cfg || !id || !name || !type || !city) return -1;
    if (cfg->node_count >= MAX_NODES) return -2;

    int idx = cfg->node_count++;
    strcpy(cfg->nodes[idx].id, id);
    strcpy(cfg->nodes[idx].name, name);
    strcpy(cfg->nodes[idx].type, type);
    strcpy(cfg->nodes[idx].city, city);
    cfg->nodes[idx].hop_limit = hop_limit > 0 ? hop_limit : 5;
    cfg->nodes[idx].qos = 1;
    cfg->nodes[idx].retain = 0;
    cfg->nodes[idx].enabled = 1;

    snprintf(cfg->nodes[idx].topic, sizeof(cfg->nodes[idx].topic),
             "/devices/%s/status", id);

    snprintf(cfg->nodes[idx].full_topic, sizeof(cfg->nodes[idx].full_topic),
             "%s/%s/%s/%s/%s/%s/%s/devices/%s/status",
             cfg->workspace_name, cfg->namespace_network, cfg->namespace_region,
             city, cfg->namespace_version, cfg->namespace_type,
             cfg->namespace_name, id);

    snprintf(cfg->nodes[idx].metaflow_state, sizeof(cfg->nodes[idx].metaflow_state),
             "%s/%s/%s/%s/%s/%s/%s/.metaflow/state.json",
             cfg->workspace_name, cfg->namespace_network, cfg->namespace_region,
             city, cfg->namespace_version, cfg->namespace_type,
             cfg->namespace_name);

    snprintf(cfg->nodes[idx].metaflow_history, sizeof(cfg->nodes[idx].metaflow_history),
             "%s/%s/%s/%s/%s/%s/%s/.metaflow/history/",
             cfg->workspace_name, cfg->namespace_network, cfg->namespace_region,
             city, cfg->namespace_version, cfg->namespace_type,
             cfg->namespace_name);

    return idx;
}

int config_add_subscription(config_t *cfg, int node_idx, const char *topic) {
    if (!cfg || node_idx < 0 || node_idx >= cfg->node_count || !topic) return -1;
    if (cfg->nodes[node_idx].subscription_count >= MAX_SUBSCRIPTIONS) return -2;

    int idx = cfg->nodes[node_idx].subscription_count++;
    strcpy(cfg->nodes[node_idx].subscriptions[idx], topic);
    return idx;
}

int config_add_outgoing_topic(config_t *cfg, int node_idx, const char *topic) {
    if (!cfg || node_idx < 0 || node_idx >= cfg->node_count || !topic) return -1;
    if (cfg->nodes[node_idx].outgoing_count >= MAX_OUTGOING) return -2;

    int idx = cfg->nodes[node_idx].outgoing_count++;
    strcpy(cfg->nodes[node_idx].outgoing_topics[idx], topic);
    return idx;
}

// ============================================================================
// Работа с тестовыми узлами
// ============================================================================

int config_add_test_node(config_t *cfg, const char *name, const char *id,
                         uint32_t node_id, const char *city) {
    if (!cfg || !name || !id || !city) return -1;
    if (cfg->test_node_count >= MAX_TEST_NODES) return -2;

    int idx = cfg->test_node_count++;
    strcpy(cfg->test_nodes[idx].name, name);
    strcpy(cfg->test_nodes[idx].id, id);
    cfg->test_nodes[idx].node_id = node_id;
    strcpy(cfg->test_nodes[idx].city, city);
    cfg->test_nodes[idx].hw_model = 4;
    cfg->test_nodes[idx].role = 0;
    cfg->test_nodes[idx].is_licensed = 0;
    strcpy(cfg->test_nodes[idx].firmware_version, "2.2.9");
    cfg->test_nodes[idx].lora_region = 9;
    cfg->test_nodes[idx].lora_modem_preset = 0;
    cfg->test_nodes[idx].has_default_channel = 1;

    snprintf(cfg->test_nodes[idx].topic, sizeof(cfg->test_nodes[idx].topic),
             "/devices/%s/status", id);

    return idx;
}

void config_set_test_node_position(config_t *cfg, int idx,
                                   int32_t lat_i, int32_t lon_i, int32_t altitude) {
    if (!cfg || idx < 0 || idx >= cfg->test_node_count) return;
    cfg->test_nodes[idx].position.latitude_i = lat_i;
    cfg->test_nodes[idx].position.longitude_i = lon_i;
    cfg->test_nodes[idx].position.altitude = altitude;
    cfg->test_nodes[idx].position.time = (uint32_t)time(NULL);
    cfg->test_nodes[idx].position.timestamp = (uint32_t)time(NULL);
}

// ============================================================================
// Генерация JSON
// ============================================================================

char* config_to_json(const config_t *cfg) {
    if (!cfg) return NULL;

    char *result = NULL;
    char buffer[256];

    result = str_append(result, "{\n");
    result = str_append_format(result, "  \"version\": \"%s\",\n", cfg->version);
    result = str_append_format(result, "  \"description\": \"%s\",\n", cfg->description);

    // Workspace
    result = str_append(result, "  \"workspace\": {\n");
    result = str_append_format(result, "    \"name\": \"%s\",\n", cfg->workspace_name);
    result = str_append_format(result, "    \"description\": \"%s\"\n", cfg->workspace_description);
    result = str_append(result, "  },\n");

    // Metaflow
    result = str_append(result, "  \"metaflow\": {\n");
    result = str_append_format(result, "    \"path\": \"%s\",\n", cfg->metaflow_path);
    result = str_append_format(result, "    \"state_file\": \"%s\",\n", cfg->metaflow_state_file);
    result = str_append_format(result, "    \"report_file\": \"%s\",\n", cfg->metaflow_report_file);
    result = str_append_format(result, "    \"summary_file\": \"%s\",\n", cfg->metaflow_summary_file);
    result = str_append_format(result, "    \"history_dir\": \"%s\"\n", cfg->metaflow_history_dir);
    result = str_append(result, "  },\n");

    // Namespace
    result = str_append(result, "  \"namespace\": {\n");
    result = str_append_format(result, "    \"base\": \"%s\",\n", cfg->namespace_base);
    result = str_append(result, "    \"components\": {\n");
    result = str_append_format(result, "      \"network\": \"%s\",\n", cfg->namespace_network);
    result = str_append_format(result, "      \"region\": \"%s\",\n", cfg->namespace_region);
    result = str_append_format(result, "      \"city\": \"%s\",\n", cfg->namespace_city);
    result = str_append_format(result, "      \"version\": \"%s\",\n", cfg->namespace_version);
    result = str_append_format(result, "      \"type\": \"%s\",\n", cfg->namespace_type);
    result = str_append_format(result, "      \"namespace\": \"%s\"\n", cfg->namespace_name);
    result = str_append(result, "    }\n");
    result = str_append(result, "  },\n");

    // Broker
    result = str_append(result, "  \"broker\": {\n");
    result = str_append_format(result, "    \"host\": \"%s\",\n", cfg->broker_host);
    result = str_append_format(result, "    \"port\": %d,\n", cfg->broker_port);
    result = str_append_format(result, "    \"tls_port\": %d,\n", cfg->broker_tls_port);
    result = str_append_format(result, "    \"protocol\": \"%s\",\n", cfg->broker_protocol);
    result = str_append_format(result, "    \"username\": \"%s\",\n", cfg->broker_username);
    result = str_append_format(result, "    \"password\": \"%s\",\n", cfg->broker_password);
    result = str_append_format(result, "    \"clean_session\": %s,\n", cfg->broker_clean_session ? "true" : "false");
    result = str_append_format(result, "    \"reconnect_period\": %d,\n", cfg->broker_reconnect_period);
    result = str_append_format(result, "    \"connect_timeout\": %d,\n", cfg->broker_connect_timeout);
    result = str_append_format(result, "    \"keepalive\": %d\n", cfg->broker_keepalive);
    result = str_append(result, "  },\n");

    // Cities
    result = str_append(result, "  \"cities\": {\n");
    for (int i = 0; i < cfg->city_count; i++) {
        result = str_append_format(result, "    \"%s\": {\n", cfg->cities[i].code);
        result = str_append_format(result, "      \"name\": \"%s\",\n", cfg->cities[i].name);
        result = str_append_format(result, "      \"topics\": %d,\n", cfg->cities[i].topics);
        result = str_append_format(result, "      \"messages\": %d,\n", cfg->cities[i].messages);
        result = str_append_format(result, "      \"enabled\": %s,\n", cfg->cities[i].enabled ? "true" : "false");
        result = str_append_format(result, "      \"lat\": %.6f,\n", cfg->cities[i].lat);
        result = str_append_format(result, "      \"lon\": %.6f,\n", cfg->cities[i].lon);
        result = str_append_format(result, "      \"namespace\": \"%s\",\n", cfg->cities[i].namespace_path);
        result = str_append_format(result, "      \"full_path\": \"%s\"\n", cfg->cities[i].full_path);
        result = str_append(result, i < cfg->city_count - 1 ? "    },\n" : "    }\n");
    }
    result = str_append(result, "  },\n");

    // Routing
    result = str_append(result, "  \"routing\": {\n");
    result = str_append_format(result, "    \"max_hops\": %d,\n", cfg->max_hops);
    result = str_append_format(result, "    \"default_qos\": %d,\n", cfg->default_qos);
    result = str_append_format(result, "    \"default_retain\": %s,\n", cfg->default_retain ? "true" : "false");
    result = str_append_format(result, "    \"enable_logging\": %s,\n", cfg->enable_logging ? "true" : "false");
    result = str_append_format(result, "    \"enable_stats\": %s,\n", cfg->enable_stats ? "true" : "false");
    result = str_append_format(result, "    \"cycle_detection\": %s,\n", cfg->cycle_detection ? "true" : "false");
    result = str_append_format(result, "    \"broadcast_to_all\": %s,\n", cfg->broadcast_to_all ? "true" : "false");
    result = str_append(result, "    \"metaflow\": {\n");
    result = str_append_format(result, "      \"log_to_history\": true,\n");
    result = str_append_format(result, "      \"history_file\": \"{NAMESPACE}/.metaflow/history/{timestamp}.json\",\n");
    result = str_append_format(result, "      \"state_file\": \"{NAMESPACE}/.metaflow/state.json\"\n");
    result = str_append(result, "    },\n");
    result = str_append(result, "    \"rules\": [\n");
    for (int i = 0; i < cfg->rule_count; i++) {
        result = str_append(result, "      {\n");
        result = str_append_format(result, "        \"name\": \"%s\",\n", cfg->rules[i].name);
        result = str_append_format(result, "        \"source\": \"%s\",\n", cfg->rules[i].source);
        result = str_append_format(result, "        \"target\": \"%s\",\n", cfg->rules[i].target);
        result = str_append_format(result, "        \"priority\": %d,\n", cfg->rules[i].priority);
        result = str_append_format(result, "        \"qos\": %d,\n", cfg->rules[i].qos);
        result = str_append_format(result, "        \"retain\": %s,\n", cfg->rules[i].retain ? "true" : "false");
        result = str_append_format(result, "        \"enabled\": %s\n", cfg->rules[i].enabled ? "true" : "false");
        result = str_append(result, i < cfg->rule_count - 1 ? "      },\n" : "      }\n");
    }
    result = str_append(result, "    ]\n");
    result = str_append(result, "  },\n");

    // Nodes
    result = str_append(result, "  \"nodes\": [\n");
    for (int i = 0; i < cfg->node_count; i++) {
        const node_t *n = &cfg->nodes[i];
        result = str_append(result, "    {\n");
        result = str_append_format(result, "      \"id\": \"%s\",\n", n->id);
        result = str_append_format(result, "      \"name\": \"%s\",\n", n->name);
        result = str_append_format(result, "      \"type\": \"%s\",\n", n->type);
        result = str_append_format(result, "      \"city\": \"%s\",\n", n->city);
        result = str_append_format(result, "      \"enabled\": %s,\n", n->enabled ? "true" : "false");
        result = str_append_format(result, "      \"hop_limit\": %d,\n", n->hop_limit);
        result = str_append_format(result, "      \"qos\": %d,\n", n->qos);
        result = str_append_format(result, "      \"retain\": %s,\n", n->retain ? "true" : "false");
        result = str_append_format(result, "      \"topic\": \"%s\",\n", n->topic);
        result = str_append_format(result, "      \"full_topic\": \"%s\",\n", n->full_topic);
        result = str_append(result, "      \"subscriptions\": [\n");
        for (int j = 0; j < n->subscription_count; j++) {
            result = str_append_format(result, "        \"%s\"%s\n",
                                       n->subscriptions[j],
                                       j < n->subscription_count - 1 ? "," : "");
        }
        result = str_append(result, "      ],\n");
        result = str_append(result, "      \"outgoing_topics\": [\n");
        for (int j = 0; j < n->outgoing_count; j++) {
            result = str_append_format(result, "        \"%s\"%s\n",
                                       n->outgoing_topics[j],
                                       j < n->outgoing_count - 1 ? "," : "");
        }
        result = str_append(result, "      ],\n");
        result = str_append(result, "      \"metaflow\": {\n");
        result = str_append_format(result, "        \"state\": \"%s\",\n", n->metaflow_state);
        result = str_append_format(result, "        \"history\": \"%s\"\n", n->metaflow_history);
        result = str_append(result, "      },\n");
        result = str_append(result, "      \"metadata\": {\n");
        result = str_append_format(result, "        \"type\": \"%s\",\n", n->type);
        result = str_append_format(result, "        \"firmware\": \"2.0.0\",\n");
        result = str_append_format(result, "        \"location\": \"%s\",\n", n->city);
        result = str_append_format(result, "        \"role\": \"%s\",\n", n->type);
        result = str_append_format(result, "        \"version\": \"%s\"\n", cfg->version);
        result = str_append(result, "      }\n");
        result = str_append(result, i < cfg->node_count - 1 ? "    },\n" : "    }\n");
    }
    result = str_append(result, "  ],\n");

    // Test nodes
    result = str_append(result, "  \"test_nodes\": [\n");
    for (int i = 0; i < cfg->test_node_count; i++) {
        const test_node_t *tn = &cfg->test_nodes[i];
        result = str_append(result, "    {\n");
        result = str_append_format(result, "      \"name\": \"%s\",\n", tn->name);
        result = str_append_format(result, "      \"id\": \"%s\",\n", tn->id);
        result = str_append_format(result, "      \"node_id\": %u,\n", tn->node_id);
        result = str_append_format(result, "      \"city\": \"%s\",\n", tn->city);
        result = str_append_format(result, "      \"hw_model\": %d,\n", tn->hw_model);
        result = str_append_format(result, "      \"role\": %d,\n", tn->role);
        result = str_append_format(result, "      \"is_licensed\": %s,\n", tn->is_licensed ? "true" : "false");
        result = str_append_format(result, "      \"firmware_version\": \"%s\",\n", tn->firmware_version);
        result = str_append_format(result, "      \"lora_region\": %d,\n", tn->lora_region);
        result = str_append_format(result, "      \"lora_modem_preset\": %d,\n", tn->lora_modem_preset);
        result = str_append_format(result, "      \"has_default_channel\": %s,\n", tn->has_default_channel ? "true" : "false");
        result = str_append_format(result, "      \"topic\": \"%s\",\n", tn->topic);
        result = str_append(result, "      \"position\": {\n");
        result = str_append_format(result, "        \"latitude_i\": %d,\n", tn->position.latitude_i);
        result = str_append_format(result, "        \"longitude_i\": %d,\n", tn->position.longitude_i);
        result = str_append_format(result, "        \"altitude\": %d,\n", tn->position.altitude);
        result = str_append_format(result, "        \"time\": %u,\n", tn->position.time);
        result = str_append_format(result, "        \"location_source\": 1,\n");
        result = str_append_format(result, "        \"altitude_source\": 1,\n");
        result = str_append_format(result, "        \"timestamp\": %u,\n", tn->position.timestamp);
        result = str_append_format(result, "        \"gps_accuracy\": 3000,\n");
        result = str_append_format(result, "        \"fix_type\": 3,\n");
        result = str_append_format(result, "        \"sats_in_view\": 8,\n");
        result = str_append_format(result, "        \"precision_bits\": 32\n");
        result = str_append(result, "      },\n");
        result = str_append_format(result, "      \"public_key\": \"public_key_%ld_%s\",\n",
                                   (long)time(NULL), tn->id);
        result = str_append_format(result, "      \"description\": \"%s\"\n", tn->name);
        result = str_append(result, i < cfg->test_node_count - 1 ? "    },\n" : "    }\n");
    }
    result = str_append(result, "  ],\n");

    // Monitoring
    result = str_append(result, "  \"monitoring\": {\n");
    result = str_append_format(result, "    \"enabled\": %s,\n", cfg->monitoring_enabled ? "true" : "false");
    result = str_append_format(result, "    \"interval\": %d,\n", cfg->monitoring_interval);
    result = str_append(result, "    \"alert_on\": {\n");
    result = str_append_format(result, "      \"node_offline\": %s,\n", cfg->monitoring_node_offline ? "true" : "false");
    result = str_append_format(result, "      \"high_latency\": %s,\n", cfg->monitoring_high_latency ? "true" : "false");
    result = str_append_format(result, "      \"message_drop\": %s,\n", cfg->monitoring_message_drop ? "true" : "false");
    result = str_append_format(result, "      \"error_rate\": %s\n", cfg->monitoring_error_rate ? "true" : "false");
    result = str_append(result, "    },\n");
    result = str_append(result, "    \"thresholds\": {\n");
    result = str_append_format(result, "      \"latency_ms\": %d,\n", cfg->monitoring_latency_ms);
    result = str_append_format(result, "      \"error_rate_percent\": %d,\n", cfg->monitoring_error_rate_percent);
    result = str_append_format(result, "      \"message_drop_percent\": %d\n", cfg->monitoring_message_drop_percent);
    result = str_append(result, "    },\n");
    result = str_append(result, "    \"metaflow\": {\n");
    result = str_append_format(result, "      \"report_file\": \"%s\",\n", cfg->metaflow_report_file);
    result = str_append_format(result, "      \"summary_file\": \"%s\"\n", cfg->metaflow_summary_file);
    result = str_append(result, "    }\n");
    result = str_append(result, "  },\n");

    // Intervals
    result = str_append(result, "  \"intervals\": {\n");
    result = str_append_format(result, "    \"position_interval\": %d,\n", cfg->position_interval);
    result = str_append_format(result, "    \"text_message_interval\": %d,\n", cfg->text_message_interval);
    result = str_append_format(result, "    \"node_info_interval\": %d,\n", cfg->node_info_interval);
    result = str_append_format(result, "    \"map_report_interval\": %d,\n", cfg->map_report_interval);
    result = str_append_format(result, "    \"initial_delay\": %d,\n", cfg->initial_delay);
    result = str_append_format(result, "    \"periodic_message_interval\": %d\n", cfg->periodic_message_interval);
    result = str_append(result, "  },\n");

    // Crypto
    result = str_append(result, "  \"crypto\": {\n");
    result = str_append_format(result, "    \"type\": \"%s\",\n", cfg->crypto_type);
    result = str_append_format(result, "    \"kem\": \"%s\",\n", cfg->crypto_kem);
    result = str_append_format(result, "    \"signature\": \"%s\",\n", cfg->crypto_signature);
    result = str_append_format(result, "    \"classic\": \"%s\",\n", cfg->crypto_classic);
    result = str_append_format(result, "    \"encryption\": %s,\n", cfg->encryption_enabled ? "true" : "false");
    result = str_append_format(result, "    \"pq_enabled\": %s\n", cfg->pq_enabled ? "true" : "false");
    result = str_append(result, "  }\n");

    result = str_append(result, "}\n");
    return result;
}

// ============================================================================
// Генерация C header
// ============================================================================

char* config_to_c_header(const config_t *cfg) {
    if (!cfg) return NULL;

    char *result = NULL;
    char buffer[256];

    result = str_append(result, "// config.h - Автоматически сгенерированный конфиг\n");
    result = str_append(result, "// Generated: ");
    time_t now = time(NULL);
    strftime(buffer, sizeof(buffer), "%Y-%m-%d %H:%M:%S", localtime(&now));
    result = str_append(result, buffer);
    result = str_append(result, "\n\n");
    result = str_append(result, "#ifndef CONFIG_H\n");
    result = str_append(result, "#define CONFIG_H\n\n");

    // Версия
    result = str_append_format(result, "#define CONFIG_VERSION \"%s\"\n\n", cfg->version);

    // Workspace
    result = str_append(result, "// ============================================================\n");
    result = str_append(result, "// WORKSPACE\n");
    result = str_append(result, "// ============================================================\n");
    result = str_append_format(result, "#define WORKSPACE_NAME \"%s\"\n", cfg->workspace_name);
    result = str_append_format(result, "#define WORKSPACE_DESCRIPTION \"%s\"\n\n", cfg->workspace_description);

    // Metaflow
    result = str_append(result, "// ============================================================\n");
    result = str_append(result, "// METFLOW\n");
    result = str_append(result, "// ============================================================\n");
    result = str_append_format(result, "#define METFLOW_PATH \"%s\"\n", cfg->metaflow_path);
    result = str_append_format(result, "#define METFLOW_STATE_FILE \"%s\"\n", cfg->metaflow_state_file);
    result = str_append_format(result, "#define METFLOW_REPORT_FILE \"%s\"\n", cfg->metaflow_report_file);
    result = str_append_format(result, "#define METFLOW_SUMMARY_FILE \"%s\"\n", cfg->metaflow_summary_file);
    result = str_append_format(result, "#define METFLOW_HISTORY_DIR \"%s\"\n\n", cfg->metaflow_history_dir);

    // Namespace
    result = str_append(result, "// ============================================================\n");
    result = str_append(result, "// NAMESPACE\n");
    result = str_append(result, "// ============================================================\n");
    result = str_append_format(result, "#define NAMESPACE_BASE \"%s\"\n", cfg->namespace_base);
    result = str_append_format(result, "#define NETWORK \"%s\"\n", cfg->namespace_network);
    result = str_append_format(result, "#define REGION \"%s\"\n", cfg->namespace_region);
    result = str_append_format(result, "#define CITY \"%s\"\n", cfg->namespace_city);
    result = str_append_format(result, "#define VERSION \"%s\"\n", cfg->namespace_version);
    result = str_append_format(result, "#define TYPE \"%s\"\n", cfg->namespace_type);
    result = str_append_format(result, "#define NAMESPACE_NAME \"%s\"\n\n", cfg->namespace_name);

    // Broker
    result = str_append(result, "// ============================================================\n");
    result = str_append(result, "// BROKER\n");
    result = str_append(result, "// ============================================================\n");
    result = str_append_format(result, "#define BROKER_HOST \"%s\"\n", cfg->broker_host);
    result = str_append_format(result, "#define BROKER_PORT %d\n", cfg->broker_port);
    result = str_append_format(result, "#define BROKER_TLS_PORT %d\n", cfg->broker_tls_port);
    result = str_append_format(result, "#define BROKER_PROTOCOL \"%s\"\n", cfg->broker_protocol);
    result = str_append_format(result, "#define BROKER_USERNAME \"%s\"\n", cfg->broker_username);
    result = str_append_format(result, "#define BROKER_PASSWORD \"%s\"\n", cfg->broker_password);
    result = str_append_format(result, "#define BROKER_CLEAN_SESSION %d\n", cfg->broker_clean_session);
    result = str_append_format(result, "#define BROKER_RECONNECT_PERIOD %d\n", cfg->broker_reconnect_period);
    result = str_append_format(result, "#define BROKER_CONNECT_TIMEOUT %d\n", cfg->broker_connect_timeout);
    result = str_append_format(result, "#define BROKER_KEEPALIVE %d\n\n", cfg->broker_keepalive);

    // Routing
    result = str_append(result, "// ============================================================\n");
    result = str_append(result, "// ROUTING\n");
    result = str_append(result, "// ============================================================\n");
    result = str_append_format(result, "#define MAX_HOPS %d\n", cfg->max_hops);
    result = str_append_format(result, "#define DEFAULT_QOS %d\n", cfg->default_qos);
    result = str_append_format(result, "#define DEFAULT_RETAIN %d\n", cfg->default_retain);
    result = str_append_format(result, "#define ENABLE_LOGGING %d\n", cfg->enable_logging);
    result = str_append_format(result, "#define ENABLE_STATS %d\n", cfg->enable_stats);
    result = str_append_format(result, "#define CYCLE_DETECTION %d\n", cfg->cycle_detection);
    result = str_append_format(result, "#define BROADCAST_TO_ALL %d\n\n", cfg->broadcast_to_all);

    // Crypto
    result = str_append(result, "// ============================================================\n");
    result = str_append(result, "// CRYPTO\n");
    result = str_append(result, "// ============================================================\n");
    result = str_append_format(result, "#define CRYPTO_TYPE \"%s\"\n", cfg->crypto_type);
    result = str_append_format(result, "#define CRYPTO_KEM \"%s\"\n", cfg->crypto_kem);
    result = str_append_format(result, "#define CRYPTO_SIGNATURE \"%s\"\n", cfg->crypto_signature);
    result = str_append_format(result, "#define CRYPTO_CLASSIC \"%s\"\n", cfg->crypto_classic);
    result = str_append_format(result, "#define ENCRYPTION_ENABLED %d\n", cfg->encryption_enabled);
    result = str_append_format(result, "#define PQ_ENABLED %d\n\n", cfg->pq_enabled);

    // Cities
    result = str_append(result, "// ============================================================\n");
    result = str_append(result, "// CITIES\n");
    result = str_append(result, "// ============================================================\n");
    result = str_append_format(result, "#define CITY_COUNT %d\n", cfg->city_count);
    for (int i = 0; i < cfg->city_count; i++) {
        result = str_append_format(result, "#define CITY_%d_CODE \"%s\"\n", i, cfg->cities[i].code);
        result = str_append_format(result, "#define CITY_%d_NAME \"%s\"\n", i, cfg->cities[i].name);
        result = str_append_format(result, "#define CITY_%d_TOPICS %d\n", i, cfg->cities[i].topics);
        result = str_append_format(result, "#define CITY_%d_MESSAGES %d\n", i, cfg->cities[i].messages);
        result = str_append_format(result, "#define CITY_%d_LAT %.6f\n", i, cfg->cities[i].lat);
        result = str_append_format(result, "#define CITY_%d_LON %.6f\n", i, cfg->cities[i].lon);
        result = str_append_format(result, "#define CITY_%d_NAMESPACE \"%s\"\n", i, cfg->cities[i].namespace_path);
    }
    result = str_append(result, "\n");

    // Monitoring
    result = str_append(result, "// ============================================================\n");
    result = str_append(result, "// MONITORING\n");
    result = str_append(result, "// ============================================================\n");
    result = str_append_format(result, "#define MONITORING_ENABLED %d\n", cfg->monitoring_enabled);
    result = str_append_format(result, "#define MONITORING_INTERVAL %d\n", cfg->monitoring_interval);
    result = str_append_format(result, "#define MONITORING_LATENCY_MS %d\n", cfg->monitoring_latency_ms);
    result = str_append_format(result, "#define MONITORING_ERROR_RATE_PERCENT %d\n", cfg->monitoring_error_rate_percent);
    result = str_append_format(result, "#define MONITORING_MESSAGE_DROP_PERCENT %d\n\n", cfg->monitoring_message_drop_percent);

    // Intervals
    result = str_append(result, "// ============================================================\n");
    result = str_append(result, "// INTERVALS\n");
    result = str_append(result, "// ============================================================\n");
    result = str_append_format(result, "#define POSITION_INTERVAL %d\n", cfg->position_interval);
    result = str_append_format(result, "#define TEXT_MESSAGE_INTERVAL %d\n", cfg->text_message_interval);
    result = str_append_format(result, "#define NODE_INFO_INTERVAL %d\n", cfg->node_info_interval);
    result = str_append_format(result, "#define MAP_REPORT_INTERVAL %d\n", cfg->map_report_interval);
    result = str_append_format(result, "#define INITIAL_DELAY %d\n", cfg->initial_delay);
    result = str_append_format(result, "#define PERIODIC_MESSAGE_INTERVAL %d\n\n", cfg->periodic_message_interval);

    // Структуры
    result = str_append(result, "// ============================================================\n");
    result = str_append(result, "// STRUCTURES\n");
    result = str_append(result, "// ============================================================\n");
    result = str_append(result, "\n");
    result = str_append(result, "typedef struct {\n");
    result = str_append(result, "    char code[8];\n");
    result = str_append(result, "    char name[64];\n");
    result = str_append(result, "    int topics;\n");
    result = str_append(result, "    int messages;\n");
    result = str_append(result, "    int enabled;\n");
    result = str_append(result, "    double lat;\n");
    result = str_append(result, "    double lon;\n");
    result = str_append(result, "    char namespace_path[128];\n");
    result = str_append(result, "    char full_path[256];\n");
    result = str_append(result, "} city_t;\n\n");

    result = str_append(result, "typedef struct {\n");
    result = str_append(result, "    char name[64];\n");
    result = str_append(result, "    char source[128];\n");
    result = str_append(result, "    char target[128];\n");
    result = str_append(result, "    int priority;\n");
    result = str_append(result, "    int qos;\n");
    result = str_append(result, "    int retain;\n");
    result = str_append(result, "    int enabled;\n");
    result = str_append(result, "} rule_t;\n\n");

    result = str_append(result, "typedef struct {\n");
    result = str_append(result, "    int32_t latitude_i;\n");
    result = str_append(result, "    int32_t longitude_i;\n");
    result = str_append(result, "    int32_t altitude;\n");
    result = str_append(result, "    uint32_t time;\n");
    result = str_append(result, "    uint32_t timestamp;\n");
    result = str_append(result, "    int gps_accuracy;\n");
    result = str_append(result, "    int fix_type;\n");
    result = str_append(result, "    int sats_in_view;\n");
    result = str_append(result, "    int precision_bits;\n");
    result = str_append(result, "} test_node_position_t;\n\n");

    result = str_append(result, "typedef struct {\n");
    result = str_append(result, "    char name[64];\n");
    result = str_append(result, "    char id[32];\n");
    result = str_append(result, "    uint32_t node_id;\n");
    result = str_append(result, "    char city[8];\n");
    result = str_append(result, "    int hw_model;\n");
    result = str_append(result, "    int role;\n");
    result = str_append(result, "    int is_licensed;\n");
    result = str_append(result, "    char firmware_version[32];\n");
    result = str_append(result, "    int lora_region;\n");
    result = str_append(result, "    int lora_modem_preset;\n");
    result = str_append(result, "    int has_default_channel;\n");
    result = str_append(result, "    char topic[128];\n");
    result = str_append(result, "    test_node_position_t position;\n");
    result = str_append(result, "} test_node_t;\n\n");

    result = str_append(result, "#endif // CONFIG_H\n");
    return result;
}

// ============================================================================
// Генерация .env файла
// ============================================================================

char* config_to_env(const config_t *cfg) {
    if (!cfg) return NULL;

    char *result = NULL;
    char buffer[256];

    result = str_append(result, "# MTProto MQTT Gateway Configuration\n");
    result = str_append(result, "# Generated: ");
    time_t now = time(NULL);
    strftime(buffer, sizeof(buffer), "%Y-%m-%d %H:%M:%S", localtime(&now));
    result = str_append(result, buffer);
    result = str_append(result, "\n\n");

    // Workspace
    result = str_append(result, "# ============================================================\n");
    result = str_append(result, "# WORKSPACE\n");
    result = str_append(result, "# ============================================================\n");
    result = str_append_format(result, "WORKSPACE_NAME=%s\n", cfg->workspace_name);
    result = str_append_format(result, "WORKSPACE_DESCRIPTION=%s\n\n", cfg->workspace_description);

    // Metaflow
    result = str_append(result, "# ============================================================\n");
    result = str_append(result, "# METFLOW\n");
    result = str_append(result, "# ============================================================\n");
    result = str_append_format(result, "METFLOW_PATH=%s\n", cfg->metaflow_path);
    result = str_append_format(result, "METFLOW_STATE_FILE=%s\n", cfg->metaflow_state_file);
    result = str_append_format(result, "METFLOW_REPORT_FILE=%s\n", cfg->metaflow_report_file);
    result = str_append_format(result, "METFLOW_SUMMARY_FILE=%s\n", cfg->metaflow_summary_file);
    result = str_append_format(result, "METFLOW_HISTORY_DIR=%s\n\n", cfg->metaflow_history_dir);

    // Namespace
    result = str_append(result, "# ============================================================\n");
    result = str_append(result, "# NAMESPACE\n");
    result = str_append(result, "# ============================================================\n");
    result = str_append_format(result, "NAMESPACE_BASE=%s\n", cfg->namespace_base);
    result = str_append_format(result, "NETWORK=%s\n", cfg->namespace_network);
    result = str_append_format(result, "REGION=%s\n", cfg->namespace_region);
    result = str_append_format(result, "CITY=%s\n", cfg->namespace_city);
    result = str_append_format(result, "VERSION=%s\n", cfg->namespace_version);
    result = str_append_format(result, "TYPE=%s\n", cfg->namespace_type);
    result = str_append_format(result, "NAMESPACE_NAME=%s\n\n", cfg->namespace_name);

    // Broker
    result = str_append(result, "# ============================================================\n");
    result = str_append(result, "# BROKER\n");
    result = str_append(result, "# ============================================================\n");
    result = str_append_format(result, "BROKER_HOST=%s\n", cfg->broker_host);
    result = str_append_format(result, "BROKER_PORT=%d\n", cfg->broker_port);
    result = str_append_format(result, "BROKER_TLS_PORT=%d\n", cfg->broker_tls_port);
    result = str_append_format(result, "BROKER_PROTOCOL=%s\n", cfg->broker_protocol);
    result = str_append_format(result, "BROKER_USERNAME=%s\n", cfg->broker_username);
    result = str_append_format(result, "BROKER_PASSWORD=%s\n", cfg->broker_password);
    result = str_append_format(result, "BROKER_CLEAN_SESSION=%d\n", cfg->broker_clean_session);
    result = str_append_format(result, "BROKER_RECONNECT_PERIOD=%d\n", cfg->broker_reconnect_period);
    result = str_append_format(result, "BROKER_CONNECT_TIMEOUT=%d\n", cfg->broker_connect_timeout);
    result = str_append_format(result, "BROKER_KEEPALIVE=%d\n\n", cfg->broker_keepalive);

    // Routing
    result = str_append(result, "# ============================================================\n");
    result = str_append(result, "# ROUTING\n");
    result = str_append(result, "# ============================================================\n");
    result = str_append_format(result, "MAX_HOPS=%d\n", cfg->max_hops);
    result = str_append_format(result, "DEFAULT_QOS=%d\n", cfg->default_qos);
    result = str_append_format(result, "DEFAULT_RETAIN=%d\n", cfg->default_retain);
    result = str_append_format(result, "ENABLE_LOGGING=%d\n", cfg->enable_logging);
    result = str_append_format(result, "ENABLE_STATS=%d\n", cfg->enable_stats);
    result = str_append_format(result, "CYCLE_DETECTION=%d\n", cfg->cycle_detection);
    result = str_append_format(result, "BROADCAST_TO_ALL=%d\n\n", cfg->broadcast_to_all);

    // Crypto
    result = str_append(result, "# ============================================================\n");
    result = str_append(result, "# CRYPTO\n");
    result = str_append(result, "# ============================================================\n");
    result = str_append_format(result, "CRYPTO_TYPE=%s\n", cfg->crypto_type);
    result = str_append_format(result, "CRYPTO_KEM=%s\n", cfg->crypto_kem);
    result = str_append_format(result, "CRYPTO_SIGNATURE=%s\n", cfg->crypto_signature);
    result = str_append_format(result, "CRYPTO_CLASSIC=%s\n", cfg->crypto_classic);
    result = str_append_format(result, "ENCRYPTION_ENABLED=%d\n", cfg->encryption_enabled);
    result = str_append_format(result, "PQ_ENABLED=%d\n\n", cfg->pq_enabled);

    // Monitoring
    result = str_append(result, "# ============================================================\n");
    result = str_append(result, "# MONITORING\n");
    result = str_append(result, "# ============================================================\n");
    result = str_append_format(result, "MONITORING_ENABLED=%d\n", cfg->monitoring_enabled);
    result = str_append_format(result, "MONITORING_INTERVAL=%d\n", cfg->monitoring_interval);
    result = str_append_format(result, "MONITORING_LATENCY_MS=%d\n", cfg->monitoring_latency_ms);
    result = str_append_format(result, "MONITORING_ERROR_RATE_PERCENT=%d\n", cfg->monitoring_error_rate_percent);
    result = str_append_format(result, "MONITORING_MESSAGE_DROP_PERCENT=%d\n\n", cfg->monitoring_message_drop_percent);

    // Intervals
    result = str_append(result, "# ============================================================\n");
    result = str_append(result, "# INTERVALS\n");
    result = str_append(result, "# ============================================================\n");
    result = str_append_format(result, "POSITION_INTERVAL=%d\n", cfg->position_interval);
    result = str_append_format(result, "TEXT_MESSAGE_INTERVAL=%d\n", cfg->text_message_interval);
    result = str_append_format(result, "NODE_INFO_INTERVAL=%d\n", cfg->node_info_interval);
    result = str_append_format(result, "MAP_REPORT_INTERVAL=%d\n", cfg->map_report_interval);
    result = str_append_format(result, "INITIAL_DELAY=%d\n", cfg->initial_delay);
    result = str_append_format(result, "PERIODIC_MESSAGE_INTERVAL=%d\n", cfg->periodic_message_interval);

    return result;
}

// ============================================================================
// Освобождение памяти
// ============================================================================

void config_free_struct(config_t *cfg) {
    if (cfg) free(cfg);
}

// ============================================================================
// Генерация случайного конфига
// ============================================================================

config_t* config_generate_random(void) {
    srand((unsigned int)time(NULL));

    config_t *cfg = malloc(sizeof(config_t));
    if (!cfg) return NULL;

    config_init(cfg);

    // Список городов
    const char *city_codes[] = {"SPB", "MOS", "EKB", "NSK", "RZN", "UFA", "TOL", "TYM", "KRY", "SAR"};
    const char *city_names[] = {"Санкт-Петербург", "Москва", "Екатеринбург", "Новосибирск",
                                "Рязань", "Уфа", "Тольятти", "Тюмень", "Крым", "Саратов"};
    double city_coords[][2] = {
        {59.9386, 30.3141},
        {55.7558, 37.6173},
        {56.8389, 60.6057},
        {55.0084, 82.9357},
        {54.6293, 39.7359},
        {54.7351, 55.9587},
        {53.5078, 49.4204},
        {57.1613, 65.5250},
        {44.9521, 34.1024},
        {51.5336, 46.0342}
    };

    // Случайный выбор основного города
    int main_city = rand() % 10;
    config_set_namespace(cfg, "msh", "RU", city_codes[main_city], "2", "e", "ELITE");
    config_add_city(cfg, city_codes[main_city], city_names[main_city],
                    50 + rand() % 150, 100 + rand() % 2000,
                    city_coords[main_city][0], city_coords[main_city][1]);

    // Добавляем случайные города
    int num_cities = 2 + rand() % 5;
    int used[10] = {0};
    used[main_city] = 1;

    for (int i = 0; i < num_cities && i < 9; i++) {
        int idx;
        do {
            idx = rand() % 10;
        } while (used[idx]);
        used[idx] = 1;
        config_add_city(cfg, city_codes[idx], city_names[idx],
                        10 + rand() % 80, 10 + rand() % 500,
                        city_coords[idx][0], city_coords[idx][1]);
    }

    // Случайные правила маршрутизации
    const char *rule_names[] = {
        "Все статусы устройств в мониторинг",
        "Все телеметрии в группу сенсоров",
        "Все позиции в группу трекинга",
        "Экстренные сообщения админу",
        "Все алерты в мониторинг",
        "Публичные сообщения в основной чат"
    };
    const char *rule_sources[] = {
        "/devices/+/status",
        "/devices/+/telemetry",
        "/devices/+/position",
        "/broadcast/emergency",
        "/alert/+",
        "/broadcast/public"
    };
    const char *rule_targets[] = {
        "/groups/monitoring/chat",
        "/groups/sensors/data",
        "/groups/tracking/positions",
        "/users/admin/inbox",
        "/groups/monitoring/alerts",
        "/groups/main/chat"
    };

    int num_rules = 3 + rand() % 4;
    for (int i = 0; i < num_rules && i < 6; i++) {
        config_add_rule(cfg, rule_names[i], rule_sources[i], rule_targets[i],
                        1 + rand() % 3, rand() % 3, rand() % 2);
    }

    // Случайные узлы
    const char *node_names[] = {"router", "gateway1", "device1", "device2", "device3"};
    const char *node_types[] = {"gateway", "gateway", "device", "device", "device"};
    const char *node_cities[] = {"SPB", "MOS", "EKB", "NSK", "RZN"};

    int num_nodes = 1 + rand() % 5;
    for (int i = 0; i < num_nodes && i < 5; i++) {
        int city_idx = rand() % cfg->city_count;
        int idx = config_add_node(cfg, node_names[i], node_names[i],
                                   node_types[i], cfg->cities[city_idx].code,
                                   3 + rand() % 5);
        if (idx >= 0) {
            // Добавляем подписки
            config_add_subscription(cfg, idx, "/+");
            config_add_subscription(cfg, idx, "/devices/+/+");
            config_add_subscription(cfg, idx, "/groups/+/+");
            config_add_subscription(cfg, idx, "/users/+/+");
            // Добавляем исходящие топики
            config_add_outgoing_topic(cfg, idx, "/groups/monitoring/chat");
            config_add_outgoing_topic(cfg, idx, "/groups/sensors/data");
        }
    }

    // Случайные тестовые узлы
    const char *test_names[] = {"Node Alpha", "Node Beta", "Node Gamma"};
    const char *test_ids[] = {"!89300eff599f98", "!62ee367d61d75", "!d04312a0e41ad8"};
    uint32_t test_node_ids[] = {969739942, 552233547, 1943347143};

    int num_test = 1 + rand() % 3;
    for (int i = 0; i < num_test && i < 3; i++) {
        int city_idx = rand() % cfg->city_count;
        int idx = config_add_test_node(cfg, test_names[i], test_ids[i],
                                        test_node_ids[i], cfg->cities[city_idx].code);
        if (idx >= 0) {
            // Случайные координаты
            int lat = 585000000 + rand() % 1000000;
            int lon = 496000000 + rand() % 1000000;
            config_set_test_node_position(cfg, idx, lat, lon, 100 + rand() % 200);
        }
    }

    // Случайные параметры
    cfg->max_hops = 3 + rand() % 5;
    cfg->default_qos = rand() % 3;
    cfg->enable_logging = rand() % 2;
    cfg->enable_stats = rand() % 2;
    cfg->cycle_detection = rand() % 2;
    cfg->encryption_enabled = rand() % 2;
    cfg->pq_enabled = rand() % 2;

    // Случайные интервалы
    cfg->position_interval = 10000 + rand() % 50000;
    cfg->text_message_interval = 30000 + rand() % 90000;
    cfg->node_info_interval = 60000 + rand() % 120000;
    cfg->periodic_message_interval = 5000 + rand() % 20000;

    // Случайный порт
    cfg->broker_port = 1883 + (rand() % 100);

    return cfg;
}

// ============================================================================
// Функция сохранения в файл
// ============================================================================

int save_to_file(const char *filename, const char *content) {
    if (!filename || !content) return -1;

    FILE *file = fopen(filename, "w");
    if (!file) {
        fprintf(stderr, "❌ Ошибка: Не удалось открыть файл %s\n", filename);
        return -1;
    }

    fprintf(file, "%s", content);
    fclose(file);
    return 0;
}

// ============================================================================
// Вывод справки
// ============================================================================

void print_help() {
    printf("============================================================\n");
    printf("  MTProto MQTT Config Generator\n");
    printf("  Версия 2.0.0\n");
    printf("============================================================\n\n");
    printf("Использование: ./config_test [ОПЦИИ]\n\n");
    printf("Опции:\n");
    printf("  -j, --json     Вывести JSON в stdout или сохранить в файл\n");
    printf("  -c, --c        Вывести C header в stdout или сохранить в файл\n");
    printf("  -e, --env      Вывести .env в stdout или сохранить в файл\n");
    printf("  -a, --all      Вывести все форматы в stdout или сохранить в файлы\n");
    printf("  -o, --output   Сохранить в файл (по умолчанию: вывод в stdout)\n");
    printf("                 Для -j: {prefix}.json\n");
    printf("                 Для -c: {prefix}.h\n");
    printf("                 Для -e: {prefix}.env\n");
    printf("                 Для -a: config.json, config.h, .env\n");
    printf("  -h, --help     Показать эту справку\n\n");
    printf("Примеры:\n");
    printf("  ./config_test --json              # Вывод JSON в stdout\n");
    printf("  ./config_test --c                 # Вывод C header в stdout\n");
    printf("  ./config_test --env               # Вывод .env в stdout\n");
    printf("  ./config_test --all               # Вывод всех форматов в stdout\n");
    printf("  ./config_test --json -o myconfig  # Сохранение в myconfig.json\n");
    printf("  ./config_test --c -o myconfig     # Сохранение в myconfig.h\n");
    printf("  ./config_test --env -o myconfig   # Сохранение в myconfig.env\n");
    printf("  ./config_test --all -o config     # Сохранение во все файлы\n\n");
}

// ============================================================================
// WASM экспорт - ИСПРАВЛЕННЫЙ БЛОК
// ============================================================================

#ifdef __EMSCRIPTEN__
#include <emscripten.h>

// Используем extern "C" для предотвращения name mangling
// Это гарантирует, что имена функций не будут изменены компилятором C++
#ifdef __cplusplus
extern "C" {
#endif

EMSCRIPTEN_KEEPALIVE
char* generate_config_json(void) {
    config_t *cfg = config_generate_random();
    if (!cfg) return NULL;
    char *result = config_to_json(cfg);
    config_free_struct(cfg);
    return result;
}

EMSCRIPTEN_KEEPALIVE
char* generate_config_c(void) {
    config_t *cfg = config_generate_random();
    if (!cfg) return NULL;
    char *result = config_to_c_header(cfg);
    config_free_struct(cfg);
    return result;
}

EMSCRIPTEN_KEEPALIVE
char* generate_config_env(void) {
    config_t *cfg = config_generate_random();
    if (!cfg) return NULL;
    char *result = config_to_env(cfg);
    config_free_struct(cfg);
    return result;
}

// Функция для освобождения строк, возвращаемых WASM
// Объявлена как EMSCRIPTEN_KEEPALIVE и защищена extern "C"
EMSCRIPTEN_KEEPALIVE
void free_config_string(char *ptr) {
    if (ptr) {
        free(ptr);
    }
}

#ifdef __cplusplus
}
#endif

#endif // __EMSCRIPTEN__

// ============================================================================
// Основная функция
// ============================================================================

#ifndef __EMSCRIPTEN__
int main(int argc, char *argv[]) {
    // Парсинг аргументов командной строки
    static struct option long_options[] = {
        {"json",    no_argument, 0, 'j'},
        {"c",       no_argument, 0, 'c'},
        {"env",     no_argument, 0, 'e'},
        {"all",     no_argument, 0, 'a'},
        {"output",  required_argument, 0, 'o'},
        {"help",    no_argument, 0, 'h'},
        {0, 0, 0, 0}
    };

    int generate_json = 0;
    int generate_c = 0;
    int generate_env = 0;
    char output_prefix[256] = "";
    int save_to_file_flag = 0;
    int opt;

    while ((opt = getopt_long(argc, argv, "jceao:h", long_options, NULL)) != -1) {
        switch (opt) {
            case 'j':
                generate_json = 1;
                break;
            case 'c':
                generate_c = 1;
                break;
            case 'e':
                generate_env = 1;
                break;
            case 'a':
                generate_json = 1;
                generate_c = 1;
                generate_env = 1;
                break;
            case 'o':
                strncpy(output_prefix, optarg, sizeof(output_prefix) - 1);
                output_prefix[sizeof(output_prefix) - 1] = '\0';
                save_to_file_flag = 1;
                break;
            case 'h':
                print_help();
                return 0;
            default:
                fprintf(stderr, "❌ Неизвестная опция. Используйте --help для справки.\n");
                return 1;
        }
    }

    // Если не указаны опции, показываем справку
    if (!generate_json && !generate_c && !generate_env) {
        print_help();
        return 0;
    }

    printf("============================================================\n");
    printf("  MTProto MQTT Config Generator v2.0\n");
    printf("============================================================\n\n");

    // Генерация конфига
    printf("⏳ Генерация конфигурации...\n");
    config_t *cfg = config_generate_random();
    if (!cfg) {
        fprintf(stderr, "❌ Ошибка генерации конфига\n");
        return 1;
    }

    printf("✅ Конфиг сгенерирован:\n");
    printf("  Городов: %d\n", cfg->city_count);
    printf("  Правил: %d\n", cfg->rule_count);
    printf("  Узлов: %d\n", cfg->node_count);
    printf("  Тестовых узлов: %d\n\n", cfg->test_node_count);

    int success = 1;

    // Генерация JSON
    if (generate_json) {
        char *json = config_to_json(cfg);
        if (json) {
            if (save_to_file_flag) {
                char filename[512];
                if (strlen(output_prefix) > 0) {
                    snprintf(filename, sizeof(filename), "%s.json", output_prefix);
                } else {
                    strcpy(filename, "config.json");
                }
                printf("📄 Сохранение JSON в %s...\n", filename);
                if (save_to_file(filename, json) == 0) {
                    printf("✅ JSON сохранен в %s\n", filename);
                } else {
                    success = 0;
                }
            } else {
                printf("📄 JSON:\n%s\n", json);
            }
            free(json);
        } else {
            fprintf(stderr, "❌ Ошибка генерации JSON\n");
            success = 0;
        }
    }

    // Генерация C header
    if (generate_c) {
        char *header = config_to_c_header(cfg);
        if (header) {
            if (save_to_file_flag) {
                char filename[512];
                if (strlen(output_prefix) > 0) {
                    snprintf(filename, sizeof(filename), "%s.h", output_prefix);
                } else {
                    strcpy(filename, "config.h");
                }
                printf("🔧 Сохранение C header в %s...\n", filename);
                if (save_to_file(filename, header) == 0) {
                    printf("✅ C header сохранен в %s\n", filename);
                } else {
                    success = 0;
                }
            } else {
                printf("🔧 C Header:\n%s\n", header);
            }
            free(header);
        } else {
            fprintf(stderr, "❌ Ошибка генерации C header\n");
            success = 0;
        }
    }

    // Генерация .env
    if (generate_env) {
        char *env = config_to_env(cfg);
        if (env) {
            if (save_to_file_flag) {
                char filename[512];
                if (strlen(output_prefix) > 0) {
                    snprintf(filename, sizeof(filename), "%s.env", output_prefix);
                } else {
                    strcpy(filename, "config.env");
                }
                printf("📝 Сохранение .env в %s...\n", filename);
                if (save_to_file(filename, env) == 0) {
                    printf("✅ .env сохранен в %s\n", filename);
                } else {
                    success = 0;
                }
            } else {
                printf("📝 .env:\n%s\n", env);
            }
            free(env);
        } else {
            fprintf(stderr, "❌ Ошибка генерации .env\n");
            success = 0;
        }
    }

    config_free_struct(cfg);

    printf("\n");
    if (success) {
        if (save_to_file_flag) {
            printf("✅ Все файлы успешно сгенерированы!\n");
        } else {
            printf("✅ Все данные выведены в stdout!\n");
        }
    } else {
        printf("⚠️ Некоторые файлы не были созданы. Проверьте ошибки выше.\n");
    }

    return success ? 0 : 1;
}
#endif // __EMSCRIPTEN__
