// config_generator.h
#ifndef CONFIG_GENERATOR_H
#define CONFIG_GENERATOR_H

#include <stdint.h>
#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

// ============================================================================
// Максимальные размеры и константы
// ============================================================================

#define MAX_STRING_LEN     256
#define MAX_CITIES         32
#define MAX_RULES          64
#define MAX_NODES          32
#define MAX_TEST_NODES     32
#define MAX_SUBSCRIPTIONS  32
#define MAX_OUTGOING       16
#define MAX_CITY_COUNT     32
#define MAX_RULE_COUNT     64
#define MAX_NODE_COUNT     32

// ============================================================================
// Структура города
// ============================================================================

typedef struct {
    char code[8];
    char name[64];
    int topics;
    int messages;
    int enabled;
    double lat;
    double lon;
    char namespace_path[128];
    char full_path[256];
    char metaflow_path[256];
    char metaflow_state[256];
    char metaflow_history[256];
} city_t;

// ============================================================================
// Структура правила маршрутизации
// ============================================================================

typedef struct {
    char name[128];
    char source[256];
    char target[256];
    int priority;
    int qos;
    int retain;
    int enabled;
} routing_rule_t;

// ============================================================================
// Структура узла (ноды)
// ============================================================================

typedef struct {
    char id[64];
    char name[128];
    char type[32];
    char city[8];
    int enabled;
    int hop_limit;
    int qos;
    int retain;
    char topic[256];
    char full_topic[512];
    char subscriptions[32][256];
    int subscription_count;
    char outgoing_topics[16][256];
    int outgoing_count;
    char metaflow_state[256];
    char metaflow_history[256];
} node_t;

// ============================================================================
// Структура позиции тестового узла
// ============================================================================

typedef struct {
    int32_t latitude_i;
    int32_t longitude_i;
    int32_t altitude;
    uint32_t time;
    uint32_t timestamp;
    int gps_accuracy;
    int fix_type;
    int sats_in_view;
    int precision_bits;
} test_node_position_t;

// ============================================================================
// Структура тестового узла
// ============================================================================

typedef struct {
    char name[64];
    char id[32];
    uint32_t node_id;
    char city[8];
    int hw_model;
    int role;
    int is_licensed;
    char firmware_version[32];
    int lora_region;
    int lora_modem_preset;
    int has_default_channel;
    char topic[128];
    test_node_position_t position;
} test_node_t;

// ============================================================================
// Основная структура конфига
// ============================================================================

typedef struct {
    // Версия и описание
    char version[16];
    char description[256];

    // Workspace
    char workspace_name[64];
    char workspace_description[256];

    // Namespace
    char namespace_base[128];
    char namespace_network[16];
    char namespace_region[8];
    char namespace_city[8];
    char namespace_version[4];
    char namespace_type[8];
    char namespace_name[32];

    // Metaflow
    char metaflow_path[128];
    char metaflow_state_file[256];
    char metaflow_report_file[256];
    char metaflow_summary_file[256];
    char metaflow_history_dir[256];

    // Broker
    char broker_host[64];
    int broker_port;
    int broker_tls_port;
    char broker_protocol[8];
    char broker_username[32];
    char broker_password[32];
    int broker_clean_session;
    int broker_reconnect_period;
    int broker_connect_timeout;
    int broker_keepalive;

    // Cities
    city_t cities[MAX_CITIES];
    int city_count;

    // Routing
    int max_hops;
    int default_qos;
    int default_retain;
    int enable_logging;
    int enable_stats;
    int cycle_detection;
    int broadcast_to_all;
    routing_rule_t rules[MAX_RULES];
    int rule_count;

    // Nodes
    node_t nodes[MAX_NODES];
    int node_count;

    // Test Nodes
    test_node_t test_nodes[MAX_TEST_NODES];
    int test_node_count;

    // Monitoring
    int monitoring_enabled;
    int monitoring_interval;
    int monitoring_node_offline;
    int monitoring_high_latency;
    int monitoring_message_drop;
    int monitoring_error_rate;
    int monitoring_latency_ms;
    int monitoring_error_rate_percent;
    int monitoring_message_drop_percent;

    // Intervals
    int position_interval;
    int text_message_interval;
    int node_info_interval;
    int map_report_interval;
    int initial_delay;
    int periodic_message_interval;

    // Crypto
    char crypto_type[16];
    char crypto_kem[32];
    char crypto_signature[32];
    char crypto_classic[32];
    int encryption_enabled;
    int pq_enabled;
} config_t;

// ============================================================================
// Основные функции
// ============================================================================

/**
 * Инициализация конфига значениями по умолчанию
 * @param cfg Указатель на структуру конфига
 */
void config_init(config_t *cfg);

/**
 * Установка workspace
 * @param cfg Указатель на структуру конфига
 * @param name Имя workspace
 * @param description Описание workspace
 */
void config_set_workspace(config_t *cfg, const char *name, const char *description);

/**
 * Установка namespace
 * @param cfg Указатель на структуру конфига
 * @param network Сеть (msh)
 * @param region Регион (RU)
 * @param city Город (SPB)
 * @param version Версия (2)
 * @param type Тип (e, json)
 * @param namespace_name Имя namespace (ELITE)
 */
void config_set_namespace(config_t *cfg, const char *network, const char *region,
                          const char *city, const char *version,
                          const char *type, const char *namespace_name);

/**
 * Установка metaflow пути
 * @param cfg Указатель на структуру конфига
 * @param path Путь к .metaflow
 */
void config_set_metaflow(config_t *cfg, const char *path);

/**
 * Установка настроек брокера
 * @param cfg Указатель на структуру конфига
 * @param host Хост брокера
 * @param port Порт
 * @param username Имя пользователя
 * @param password Пароль
 */
void config_set_broker(config_t *cfg, const char *host, int port,
                       const char *username, const char *password);

/**
 * Добавление города
 * @param cfg Указатель на структуру конфига
 * @param code Код города (SPB)
 * @param name Название города
 * @param topics Количество топиков
 * @param messages Количество сообщений
 * @param lat Широта
 * @param lon Долгота
 * @return Индекс добавленного города или код ошибки
 */
int config_add_city(config_t *cfg, const char *code, const char *name,
                    int topics, int messages, double lat, double lon);

/**
 * Получение города по коду
 * @param cfg Указатель на структуру конфига
 * @param code Код города
 * @return Указатель на город или NULL
 */
city_t* config_get_city(config_t *cfg, const char *code);

/**
 * Добавление правила маршрутизации
 * @param cfg Указатель на структуру конфига
 * @param name Название правила
 * @param source Исходный топик
 * @param target Целевой топик
 * @param priority Приоритет
 * @param qos QoS
 * @param retain Retain
 * @return Индекс добавленного правила или код ошибки
 */
int config_add_rule(config_t *cfg, const char *name, const char *source,
                    const char *target, int priority, int qos, int retain);

/**
 * Добавление узла
 * @param cfg Указатель на структуру конфига
 * @param id ID узла
 * @param name Имя узла
 * @param type Тип узла
 * @param city Город
 * @param hop_limit Лимит прыжков
 * @return Индекс добавленного узла или код ошибки
 */
int config_add_node(config_t *cfg, const char *id, const char *name,
                    const char *type, const char *city, int hop_limit);

/**
 * Добавление подписки для узла
 * @param cfg Указатель на структуру конфига
 * @param node_idx Индекс узла
 * @param topic Топик для подписки
 * @return Индекс подписки или код ошибки
 */
int config_add_subscription(config_t *cfg, int node_idx, const char *topic);

/**
 * Добавление исходящего топика для узла
 * @param cfg Указатель на структуру конфига
 * @param node_idx Индекс узла
 * @param topic Исходящий топик
 * @return Индекс топика или код ошибки
 */
int config_add_outgoing_topic(config_t *cfg, int node_idx, const char *topic);

/**
 * Добавление тестового узла
 * @param cfg Указатель на структуру конфига
 * @param name Имя узла
 * @param id ID узла
 * @param node_id Числовой ID узла
 * @param city Город
 * @return Индекс добавленного тестового узла или код ошибки
 */
int config_add_test_node(config_t *cfg, const char *name, const char *id,
                         uint32_t node_id, const char *city);

/**
 * Установка позиции тестового узла
 * @param cfg Указатель на структуру конфига
 * @param idx Индекс тестового узла
 * @param lat_i Широта (целое)
 * @param lon_i Долгота (целое)
 * @param altitude Высота
 */
void config_set_test_node_position(config_t *cfg, int idx,
                                   int32_t lat_i, int32_t lon_i, int32_t altitude);

// ============================================================================
// Функции экспорта
// ============================================================================

/**
 * Экспорт конфига в JSON
 * @param cfg Указатель на структуру конфига
 * @return Строка JSON (нужно освободить через config_free)
 */
char* config_to_json(const config_t *cfg);

/**
 * Экспорт конфига в C header
 * @param cfg Указатель на структуру конфига
 * @return Строка с C header (нужно освободить через config_free)
 */
char* config_to_c_header(const config_t *cfg);

/**
 * Экспорт конфига в .env формат
 * @param cfg Указатель на структуру конфига
 * @return Строка с .env (нужно освободить через config_free)
 */
char* config_to_env(const config_t *cfg);

/**
 * Освобождение памяти строки
 * @param str Строка для освобождения
 */
void config_free(char *str);

/**
 * Освобождение структуры конфига
 * @param cfg Указатель на структуру конфига
 */
void config_free_struct(config_t *cfg);

// ============================================================================
// Функции генерации
// ============================================================================

/**
 * Генерация случайного конфига
 * @return Указатель на структуру конфига (нужно освободить через config_free_struct)
 */
config_t* config_generate_random(void);

// ============================================================================
// WASM экспорт
// ============================================================================

#ifdef __EMSCRIPTEN__
#include <emscripten.h>

/**
 * Генерация JSON конфига (WASM)
 * @return Строка JSON (нужно освободить через config_free)
 */
EMSCRIPTEN_KEEPALIVE
char* generate_config_json(void);

/**
 * Генерация C header (WASM)
 * @return Строка с C header (нужно освободить через config_free)
 */
EMSCRIPTEN_KEEPALIVE
char* generate_config_c(void);

/**
 * Генерация .env (WASM)
 * @return Строка с .env (нужно освободить через config_free)
 */
EMSCRIPTEN_KEEPALIVE
char* generate_config_env(void);

/**
 * Освобождение строки (WASM)
 * @param ptr Указатель на строку
 */
EMSCRIPTEN_KEEPALIVE
void config_free(char *ptr);

#endif // __EMSCRIPTEN__

#ifdef __cplusplus
}
#endif

#endif // CONFIG_GENERATOR_H
