#!/bin/bash
# install-emscripten.sh - Установка emscripten по официальной документации

# ═══════════════════════════════════════════════════════════════════════════════
#  🚀 ФЛАГИ И ПАРАМЕТРЫ
# ═══════════════════════════════════════════════════════════════════════════════

SHOW_CONTENT=0          # -s/--show-content - показать содержимое скрипта
SHOW_GRAPH=0            # -g/--graph - показать граф структуры скрипта
ANALYZE=0               # -a/--analyze - проанализировать содержимое и создать объект
EXECUTE_AND_SHOW=1      # По умолчанию: выполнить и показать комментарий без задержки

# ═══════════════════════════════════════════════════════════════════════════════
#  🎨 ЦВЕТА И СТИЛИ
# ═══════════════════════════════════════════════════════════════════════════════

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
MAGENTA='\033[0;35m'
WHITE='\033[1;37m'
GRAY='\033[0;90m'
NC='\033[0m' # No Color
BOLD='\033[1m'
DIM='\033[2m'

# ═══════════════════════════════════════════════════════════════════════════════
#  📐 ДИЗАЙНЕРСКИЕ РАЗДЕЛИТЕЛИ
# ═══════════════════════════════════════════════════════════════════════════════

SEP_MAIN="╔═══════════════════════════════════════════════════════════════════════════════╗"
SEP_MAIN_BOTTOM="╚═══════════════════════════════════════════════════════════════════════════════╝"
SEP_SECTION="┌───────────────────────────────────────────────────────────────────────────────────┐"
SEP_SECTION_BOTTOM="└───────────────────────────────────────────────────────────────────────────────────┘"
SEP_SUB="├───────────────────────────────────────────────────────────────────────────────────┤"
SEP_LINE="─────────────────────────────────────────────────────────────────────────────────────"

print_separator() {
    local type="${1:-main}"
    local char="${2:-═}"
    local length="${3:-80}"

    case "$type" in
        main)
            echo -e "${CYAN}${SEP_MAIN}${NC}"
            ;;
        main_bottom)
            echo -e "${CYAN}${SEP_MAIN_BOTTOM}${NC}"
            ;;
        section)
            echo -e "${BLUE}${SEP_SECTION}${NC}"
            ;;
        section_bottom)
            echo -e "${BLUE}${SEP_SECTION_BOTTOM}${NC}"
            ;;
        sub)
            echo -e "${GRAY}${SEP_SUB}${NC}"
            ;;
        line)
            echo -e "${DIM}${SEP_LINE}${NC}"
            ;;
        *)
            echo -e "${DIM}─────────────────────────────────────────────────────────────────────────────────────${NC}"
            ;;
    esac
}

print_centered() {
    local text="$1"
    local color="${2:-$WHITE}"
    local width=80
    local padding=$(( (width - ${#text}) / 2 ))
    printf "${color}%*s%s%*s${NC}\n" $padding "" "$text" $padding ""
}

print_section_header() {
    local title="$1"
    local icon="${2:-📦}"
    echo ""
    print_separator "section"
    print_centered "${icon}  ${BOLD}${title}${NC}" "$CYAN"
    print_separator "section_bottom"
    echo ""
}

# ═══════════════════════════════════════════════════════════════════════════════
#  📋 ФУНКЦИЯ ПОКАЗА ВЕРСИЙ
# ═══════════════════════════════════════════════════════════════════════════════

show_versions() {
    print_section_header "📋 ДОСТУПНЫЕ ВЕРСИИ EMSCRIPTEN" "📋"

    echo -e "${BOLD}${CYAN}┌─────────────────────────────────────────────────────────────────────┐${NC}"
    echo -e "${BOLD}${CYAN}│  📦 Список доступных версий Emscripten                            │${NC}"
    echo -e "${BOLD}${CYAN}├─────────────────────────────────────────────────────────────────────┤${NC}"

    # Проверяем наличие emsdk
    if [ -d "$EMSDK_DIR" ] && [ -f "$EMSDK_DIR/emsdk" ]; then
        echo -e "${GREEN}│  ✅ Используем существующий emsdk${NC}"
        cd "$EMSDK_DIR" || return 1

        # Обновляем список версий
        ./emsdk update-tags 2>/dev/null || true

        # Получаем список версий
        local versions=$(./emsdk list 2>/dev/null | grep -E "^[[:space:]]*[0-9]+\.[0-9]+\.[0-9]+" | awk '{print $1}' | sort -Vr | head -30)

        if [ -n "$versions" ]; then
            echo -e "${CYAN}│${NC}"
            echo "$versions" | while read -r ver; do
                if [ -n "$ver" ]; then
                    echo -e "${GREEN}│  📌 ${WHITE}${ver}${NC}"
                fi
            done
        else
            echo -e "${YELLOW}│  ⚠️  Не удалось получить список версий через emsdk${NC}"
        fi
    else
        echo -e "${YELLOW}│  ⚠️  emsdk не найден, клонируем временно...${NC}"

        # Временное клонирование для получения списка
        local tmp_dir=$(mktemp -d)
        cd "$tmp_dir" || return 1

        if git clone --depth 1 https://github.com/emscripten-core/emsdk.git 2>/dev/null; then
            cd emsdk || return 1
            ./emsdk update-tags 2>/dev/null || true

            local versions=$(./emsdk list 2>/dev/null | grep -E "^[[:space:]]*[0-9]+\.[0-9]+\.[0-9]+" | awk '{print $1}' | sort -Vr | head -30)

            if [ -n "$versions" ]; then
                echo -e "${CYAN}│${NC}"
                echo "$versions" | while read -r ver; do
                    if [ -n "$ver" ]; then
                        echo -e "${GREEN}│  📌 ${WHITE}${ver}${NC}"
                    fi
                done
            else
                echo -e "${YELLOW}│  ⚠️  Не удалось получить список версий${NC}"
            fi

            cd /tmp
            rm -rf "$tmp_dir"
        else
            echo -e "${RED}│  ❌ Ошибка клонирования emsdk${NC}"
            cd /tmp
            rm -rf "$tmp_dir"
            return 1
        fi
    fi

    echo -e "${BOLD}${CYAN}└─────────────────────────────────────────────────────────────────────┘${NC}"
    echo ""

    # Показываем специальные версии
    echo -e "${BOLD}${MAGENTA}📌 СПЕЦИАЛЬНЫЕ ВЕРСИИ${NC}"
    echo -e "${SEP_LINE}"
    echo -e "${CYAN}  latest          ${DIM}- Последняя стабильная версия${NC}"
    echo -e "${CYAN}  latest-fastcomp ${DIM}- Последняя версия с fastcomp backend${NC}"
    echo -e "${CYAN}  latest-upstream ${DIM}- Последняя версия с upstream backend${NC}"
    echo -e "${CYAN}  incoming        ${DIM}- Последняя разрабатываемая версия${NC}"
    echo -e "${CYAN}  tot             ${DIM}- Tip-of-tree (самая свежая)${NC}"
    echo ""

    echo -e "${BOLD}📋 Использование:${NC}"
    echo -e "  ${GREEN}./install-emscripten.sh -v 3.1.50${NC}  ${DIM}# Установить конкретную версию${NC}"
    echo -e "  ${GREEN}./install-emscripten.sh${NC}           ${DIM}# Установить последнюю версию${NC}"
    echo -e "  ${GREEN}./install-emscripten.sh -l${NC}        ${DIM}# Показать этот список${NC}"
    echo ""
}

# ═══════════════════════════════════════════════════════════════════════════════
#  📊 ФУНКЦИИ ВИЗУАЛИЗАЦИИ ГРАФА (ДИНАМИЧЕСКАЯ)
# ═══════════════════════════════════════════════════════════════════════════════

show_graph() {
    print_section_header "🌐 СТРУКТУРА СКРИПТА (ГРАФ)" "🌐"

    echo -e "${BOLD}${CYAN}┌─────────────────────────────────────────────────────────────────────┐${NC}"
    echo -e "${BOLD}${CYAN}│  🏗️  ГРАФ ВЫПОЛНЕНИЯ: $(basename "$0")                              │${NC}"
    echo -e "${BOLD}${CYAN}├─────────────────────────────────────────────────────────────────────┤${NC}"

    # ────────────────────────────────────────────────────────────────────────
    # 1️⃣ АНАЛИЗИРУЕМ СТРУКТУРУ СКРИПТА
    # ────────────────────────────────────────────────────────────────────────

    # Собираем все секции (разделители)
    local sections=$(grep -n "^# ═══════════════════════════════════════════════════════════════════════════════" "$0" | cut -d: -f1)
    local section_names=$(grep -n "^#  [A-Za-zА-Яа-я0-9 ]*$" "$0" | grep -v "═" | cut -d: -f2- | sed 's/^# //' | sed 's/^[[:space:]]*//')

    # Собираем все функции
    local functions=$(grep -n "^[[:space:]]*[a-zA-Z_][a-zA-Z0-9_]*()[[:space:]]*{" "$0" | sed 's/[[:space:]]*{//' | sed 's/^[[:space:]]*//')

    # Собираем все переменные
    local variables=$(grep -n "^[[:space:]]*[A-Z_][A-Z0-9_]*=" "$0" | head -10)

    # ────────────────────────────────────────────────────────────────────────
    # 2️⃣ ПОСТРОЕНИЕ ГРАФА
    # ────────────────────────────────────────────────────────────────────────

    local node_count=0
    local prev_node=""

    # Добавляем START узел
    echo -e "${GREEN}│  🚀 START: Запуск скрипта${NC}"
    echo -e "${YELLOW}│  │${NC}"
    echo -e "${YELLOW}│  ▼${NC}"
    echo -e "${YELLOW}│  │${NC}"
    node_count=$((node_count + 1))

    # Проходим по секциям и создаем узлы
    if [ -n "$section_names" ]; then
        while IFS= read -r section; do
            # Пропускаем пустые строки
            [ -z "$section" ] && continue

            # Определяем иконку для секции
            local icon="📋"
            local color="${GREEN}"
            local node_name=""

            case "$section" in
                *"ФЛАГИ"*|*"ПАРАМЕТРЫ"*)
                    icon="⚙️"
                    node_name="PARAMS: Параметры и флаги"
                    ;;
                *"ЦВЕТА"*|*"СТИЛИ"*)
                    icon="🎨"
                    node_name="COLORS: Цветовая схема"
                    ;;
                *"РАЗДЕЛИТЕЛИ"*|*"ДИЗАЙН"*)
                    icon="📐"
                    node_name="DESIGN: Дизайнерские разделители"
                    ;;
                *"ГРАФ"*|*"ВИЗУАЛИЗАЦИЯ"*)
                    icon="📊"
                    node_name="GRAPH: Визуализация графа"
                    ;;
                *"АНАЛИЗ"*)
                    icon="🔍"
                    node_name="ANALYZE: Анализ содержимого"
                    ;;
                *"СОДЕРЖИМОЕ"*)
                    icon="📄"
                    node_name="CONTENT: Показ содержимого"
                    ;;
                *"ФАЙЛ"*)
                    icon="🗂️"
                    node_name="FILES: Работа с файлами"
                    ;;
                *"УСТАНОВК"*|*"INSTALL"*)
                    icon="📦"
                    node_name="INSTALL: Основная установка"
                    ;;
                *"АКТИВАЦИ"*|*"ACTIVATE"*)
                    icon="🔄"
                    node_name="ACTIVATE: Активация окружения"
                    ;;
                *"ПРОВЕРК"*|*"CHECK"*|*"TEST"*)
                    icon="🧪"
                    node_name="TEST: Проверка и тестирование"
                    ;;
                *"ОСНОВНАЯ"*|*"MAIN"*)
                    icon="🎯"
                    node_name="MAIN: Основная функция"
                    ;;
                *"СПРАВК"*|*"HELP"*)
                    icon="📚"
                    node_name="HELP: Справка"
                    ;;
                *"ЗАПУСК"*|*"RUN"*)
                    icon="🏃"
                    node_name="RUN: Запуск"
                    ;;
                *)
                    icon="📋"
                    node_name="SECTION: ${section}"
                    ;;
            esac

            # Рисуем узел секции
            echo -e "${color}│  ${icon} ${node_name}${NC}"

            # Показываем функции в этой секции
            local section_line=$(echo "$section_names" | grep -n "$section" | cut -d: -f1 | head -1)
            if [ -n "$section_line" ]; then
                local start_line=$((section_line + 1))
                local end_line=$((section_line + 10))

                # Ищем функции между секциями
                local funcs_in_section=$(echo "$functions" | awk -v start="$start_line" -v end="$end_line" '$1 >= start && $1 <= end' | head -3)
                if [ -n "$funcs_in_section" ]; then
                    echo -e "${DIM}│    ├─ Функции:${NC}"
                    echo "$funcs_in_section" | while read -r func_line; do
                        local func_name=$(echo "$func_line" | sed 's/^[0-9]*://' | sed 's/[[:space:]]*{//')
                        echo -e "${DIM}│    │  🔧 ${func_name}()${NC}"
                    done
                fi
            fi

            # Рисуем соединение
            echo -e "${YELLOW}│  │${NC}"
            echo -e "${YELLOW}│  ▼${NC}"
            echo -e "${YELLOW}│  │${NC}"
            node_count=$((node_count + 1))

        done <<< "$section_names"
    fi

    # Добавляем FINISH узел
    echo -e "${GREEN}│  ✅ FINISH: Завершение скрипта${NC}"

    echo -e "${BOLD}${CYAN}└─────────────────────────────────────────────────────────────────────┘${NC}"
    echo ""

    # ────────────────────────────────────────────────────────────────────────
    # 3️⃣ СТАТИСТИКА
    # ────────────────────────────────────────────────────────────────────────

    echo -e "${BOLD}${MAGENTA}📊 СТАТИСТИКА СТРУКТУРЫ${NC}"
    echo -e "${SEP_LINE}"
    echo -e "${CYAN}  📦 Всего узлов:     ${WHITE}${node_count}${NC}"
    echo -e "${CYAN}  🔧 Функций:        ${WHITE}$(echo "$functions" | wc -l)${NC}"
    echo -e "${CYAN}  📋 Секций:         ${WHITE}$(echo "$section_names" | wc -l)${NC}"
    echo -e "${CYAN}  📦 Переменных:     ${WHITE}$(echo "$variables" | wc -l)${NC}"
    echo ""

    # ────────────────────────────────────────────────────────────────────────
    # 4️⃣ ЛЕГЕНДА
    # ────────────────────────────────────────────────────────────────────────

    echo -e "${DIM}📌 Легенда узлов:${NC}"
    echo -e "${GREEN}  🚀 START     ${DIM}- Точка входа${NC}"
    echo -e "${GREEN}  ⚙️  PARAMS    ${DIM}- Параметры и флаги${NC}"
    echo -e "${GREEN}  🎨 COLORS    ${DIM}- Цветовая схема${NC}"
    echo -e "${GREEN}  📐 DESIGN    ${DIM}- Дизайнерские разделители${NC}"
    echo -e "${GREEN}  📊 GRAPH     ${DIM}- Визуализация графа${NC}"
    echo -e "${GREEN}  🔍 ANALYZE   ${DIM}- Анализ содержимого${NC}"
    echo -e "${GREEN}  📄 CONTENT   ${DIM}- Показ содержимого${NC}"
    echo -e "${GREEN}  🗂️  FILES    ${DIM}- Работа с файлами${NC}"
    echo -e "${GREEN}  📦 INSTALL   ${DIM}- Основная установка${NC}"
    echo -e "${GREEN}  🔄 ACTIVATE  ${DIM}- Активация окружения${NC}"
    echo -e "${GREEN}  🧪 TEST      ${DIM}- Проверка и тестирование${NC}"
    echo -e "${GREEN}  🎯 MAIN      ${DIM}- Основная функция${NC}"
    echo -e "${GREEN}  📚 HELP      ${DIM}- Справка${NC}"
    echo -e "${GREEN}  🏃 RUN       ${DIM}- Запуск${NC}"
    echo -e "${GREEN}  ✅ FINISH    ${DIM}- Завершение${NC}"
    echo ""
}

# ═══════════════════════════════════════════════════════════════════════════════
#  🔍 ФУНКЦИИ АНАЛИЗА СОДЕРЖИМОГО
# ═══════════════════════════════════════════════════════════════════════════════

analyze_script() {
    print_section_header "🔍 АНАЛИЗ СОДЕРЖИМОГО" "🔍"

    # Создаем объект с данными о скрипте
    local script_name=$(basename "$0")
    local script_path=$(realpath "$0")
    local script_size=$(stat -c%s "$0" 2>/dev/null || echo "0")
    local line_count=$(wc -l < "$0" 2>/dev/null || echo "0")
    local func_count=$(grep -c "^[[:space:]]*[a-zA-Z_][a-zA-Z0-9_]*()[[:space:]]*{" "$0" 2>/dev/null || echo "0")
    local var_count=$(grep -c "^[[:space:]]*[a-zA-Z_][a-zA-Z0-9_]*=" "$0" 2>/dev/null || echo "0")

    echo -e "${BOLD}${MAGENTA}📊 СТАТИСТИКА СКРИПТА${NC}"
    echo -e "${SEP_LINE}"
    echo -e "${CYAN}  📁 Имя:          ${WHITE}$script_name${NC}"
    echo -e "${CYAN}  📂 Путь:         ${WHITE}$script_path${NC}"
    echo -e "${CYAN}  📏 Размер:       ${WHITE}$(numfmt --to=iec $script_size 2>/dev/null || echo "${script_size} байт")${NC}"
    echo -e "${CYAN}  📄 Строк:        ${WHITE}$line_count${NC}"
    echo -e "${CYAN}  🔧 Функций:      ${WHITE}$func_count${NC}"
    echo -e "${CYAN}  📦 Переменных:   ${WHITE}$var_count${NC}"
    echo ""

    # Анализ структуры
    echo -e "${BOLD}${MAGENTA}📋 СТРУКТУРА ФУНКЦИЙ${NC}"
    echo -e "${SEP_LINE}"

    # Собираем все функции
    local functions=$(grep "^[[:space:]]*[a-zA-Z_][a-zA-Z0-9_]*()[[:space:]]*{" "$0" | sed 's/[[:space:]]*{//' | sed 's/^[[:space:]]*//')

    if [ -n "$functions" ]; then
        local idx=0
        while IFS= read -r func; do
            idx=$((idx + 1))
            # Находим строку с функцией
            local line_num=$(grep -n "^[[:space:]]*${func}[[:space:]]*()" "$0" | cut -d: -f1 | head -1)
            echo -e "${GREEN}  ${idx}. ${WHITE}${func}${NC} ${DIM}(строка: ${line_num})${NC}"
        done <<< "$functions"
    else
        echo -e "${YELLOW}  ⚠️  Функции не найдены${NC}"
    fi
    echo ""

    # Анализ переменных
    echo -e "${BOLD}${MAGENTA}📦 ОСНОВНЫЕ ПЕРЕМЕННЫЕ${NC}"
    echo -e "${SEP_LINE}"

    local variables=$(grep "^[[:space:]]*[A-Z_][A-Z0-9_]*=" "$0" | head -10 | sed 's/^[[:space:]]*//')

    if [ -n "$variables" ]; then
        while IFS= read -r var; do
            local name=$(echo "$var" | cut -d= -f1)
            local value=$(echo "$var" | cut -d= -f2- | head -c 50)
            echo -e "${CYAN}  📌 ${WHITE}${name}${NC} ${DIM}= ${value}${NC}"
        done <<< "$variables"
    else
        echo -e "${YELLOW}  ⚠️  Переменные не найдены${NC}"
    fi
    echo ""

    # Создаем JSON объект
    echo -e "${BOLD}${MAGENTA}📄 ОБЪЕКТ НА ОСНОВЕ СОДЕРЖИМОГО (JSON)${NC}"
    echo -e "${SEP_LINE}"

    cat << EOF
{
  "script": {
    "name": "${script_name}",
    "path": "${script_path}",
    "size": ${script_size},
    "lines": ${line_count},
    "functions": ${func_count},
    "variables": ${var_count}
  },
  "structure": {
    "functions": [
$(grep "^[[:space:]]*[a-zA-Z_][a-zA-Z0-9_]*()[[:space:]]*{" "$0" | sed 's/[[:space:]]*{//' | sed 's/^[[:space:]]*//' | while read -r func; do
    echo "      \"${func}\","
done | sed '$ s/,$//')
    ]
  },
  "metadata": {
    "analyzed_at": "$(date -Iseconds)",
    "version": "${VERSION}",
    "emscripten_version": "$(emcc --version 2>/dev/null | head -1 || echo 'not installed')"
  }
}
EOF
    echo ""
}

# ═══════════════════════════════════════════════════════════════════════════════
#  📄 ФУНКЦИЯ ПОКАЗА СОДЕРЖИМОГО
# ═══════════════════════════════════════════════════════════════════════════════

show_content() {
    print_section_header "📄 СОДЕРЖИМОЕ СКРИПТА" "📄"

    echo -e "${DIM}┌─────────────────────────────────────────────────────────────────────┐${NC}"
    echo -e "${DIM}│  📄 ${WHITE}install-emscripten.sh${NC}${DIM} - Полный текст${NC}"
    echo -e "${DIM}└─────────────────────────────────────────────────────────────────────┘${NC}"
    echo ""

    # Показываем содержимое с номерами строк
    local line_num=1
    while IFS= read -r line; do
        printf "${DIM}%4d${NC}  ${line}\n" "$line_num"
        line_num=$((line_num + 1))
    done < "$0"

    echo ""
    echo -e "${DIM}┌─────────────────────────────────────────────────────────────────────┐${NC}"
    echo -e "${DIM}│  📊 ИТОГО: $((line_num - 1)) строк${NC}"
    echo -e "${DIM}└─────────────────────────────────────────────────────────────────────┘${NC}"
}

# ═══════════════════════════════════════════════════════════════════════════════
#  📋 ОСТАЛЬНЫЕ ФУНКЦИИ (ОСНОВНАЯ ЛОГИКА)
# ═══════════════════════════════════════════════════════════════════════════════

print_header() {
    echo ""
    print_separator "main"
    print_centered "🛠️  УСТАНОВКА EMSCRIPTEN" "$CYAN"
    print_centered "Официальная документация" "$DIM"
    print_separator "main_bottom"
    echo ""
}

print_step() {
    echo -e "${CYAN}▶ $1${NC}"
}

print_success() {
    echo -e "${GREEN}✅ $1${NC}"
}

print_error() {
    echo -e "${RED}❌ $1${NC}"
    INSTALL_ERROR=1
}

print_warning() {
    echo -e "${YELLOW}⚠️  $1${NC}"
}

print_info() {
    echo -e "${BLUE}ℹ️  $1${NC}"
}

# ═══════════════════════════════════════════════════════════════════════════════
#  🗂️ ФУНКЦИИ РАБОТЫ С ФАЙЛАМИ
# ═══════════════════════════════════════════════════════════════════════════════

file_exists() {
    local path="$1"
    if [ -e "$path" ] || [ -L "$path" ]; then
        return 0
    else
        return 1
    fi
}

safe_remove() {
    local path="$1"
    local description="${2:-$path}"

    if file_exists "$path"; then
        print_info "Найден: $description"
        if [ -L "$path" ]; then
            local target=$(readlink "$path" 2>/dev/null)
            print_info "  Симлинк -> $target"
        elif [ -f "$path" ]; then
            local size=$(du -h "$path" 2>/dev/null | cut -f1)
            print_info "  Файл, размер: $size"
        elif [ -d "$path" ]; then
            local count=$(find "$path" -type f 2>/dev/null | wc -l)
            print_info "  Директория, файлов: $count"
        fi

        if rm -rf "$path" 2>/dev/null; then
            print_success "Удалено: $description"
            return 0
        elif sudo rm -rf "$path" 2>/dev/null; then
            print_success "Удалено (sudo): $description"
            return 0
        else
            print_error "Не удалось удалить: $description"
            return 1
        fi
    else
        print_info "Не найден: $description"
        return 2
    fi
}

# ═══════════════════════════════════════════════════════════════════════════════
#  🔍 ОСНОВНЫЕ ФУНКЦИИ УСТАНОВКИ
# ═══════════════════════════════════════════════════════════════════════════════

check_dependencies() {
    print_step "Проверка зависимостей..."
    echo -e "${DIM}─────────────────────────────────────────────────────────────────────${NC}"

    local missing=()

    if command -v git &> /dev/null; then
        print_success "git найден: $(git --version | head -1)"
    else
        missing+=("git")
        print_error "git не установлен"
    fi

    if command -v python3 &> /dev/null; then
        print_success "python3 найден: $(python3 --version | head -1)"
    elif command -v python &> /dev/null; then
        print_success "python найден: $(python --version | head -1)"
    else
        missing+=("python3")
        print_error "python3 не установлен"
    fi

    if command -v curl &> /dev/null; then
        print_success "curl найден: $(curl --version | head -1)"
    else
        print_warning "curl не установлен (опционально)"
    fi

    echo ""
    if [ ${#missing[@]} -gt 0 ]; then
        print_warning "Отсутствуют зависимости: ${missing[*]}"
        echo ""
        echo "Установите их согласно документации:"
        echo "  sudo apt-get install -y python3 git curl"
        echo ""
        read -p "Продолжить установку? (y/N): " -n 1 -r
        echo
        if [[ ! $REPLY =~ ^[Yy]$ ]]; then
            print_error "Установка отменена"
            exit 1
        fi
    else
        print_success "Все зависимости установлены"
    fi
}

cleanup_broken_links() {
    print_step "Очистка битых симлинков..."

    local cleaned=0
    local files_to_check=(
        "/usr/local/bin/emcc"
        "/usr/local/bin/emcc.py"
        "/usr/bin/emcc"
        "/usr/bin/emcc.py"
        "/bin/emcc"
        "/bin/emcc.py"
    )

    for path in "${files_to_check[@]}"; do
        if file_exists "$path"; then
            print_info "Найден: $path"
            if [ -L "$path" ]; then
                local target=$(readlink "$path" 2>/dev/null)
                print_info "  Симлинк -> $target"
                if [ ! -e "$target" ] && [ ! -x "$target" ]; then
                    print_warning "  БИТЫЙ СИМЛИНК!"
                    if sudo rm -f "$path" 2>/dev/null; then
                        print_success "  Удален: $path"
                        cleaned=$((cleaned + 1))
                    fi
                else
                    print_success "  Симлинк рабочий"
                fi
            elif [ -f "$path" ]; then
                if file "$path" | grep -q "ELF\|script\|text"; then
                    print_success "  Файл: $(file -b "$path" | cut -d, -f1)"
                else
                    if sudo rm -f "$path" 2>/dev/null; then
                        print_success "  Удален: $path"
                        cleaned=$((cleaned + 1))
                    fi
                fi
            fi
        fi
    done

    [ $cleaned -gt 0 ] && print_success "Очищено битых симлинков: $cleaned" || print_success "Битых симлинков не найдено"
}

activate_emscripten() {
    print_step "Активация emscripten..."

    if ! file_exists "$EMSDK_DIR/emsdk_env.sh"; then
        print_error "Файл активации не найден"
        return 1
    fi

    print_info "Выполняется: source $EMSDK_DIR/emsdk_env.sh"
    source "$EMSDK_DIR/emsdk_env.sh" 2>/dev/null

    if [ $? -eq 0 ] && command -v emcc &> /dev/null; then
        print_success "emscripten активирован успешно!"
        print_info "emcc: $(which emcc)"
        return 0
    else
        print_error "Ошибка активации emscripten"
        return 1
    fi
}

test_emcc() {
    if ! command -v emcc &> /dev/null; then
        return 1
    fi

    local version=$(emcc --version 2>/dev/null | head -1)
    [ -z "$version" ] && return 1

    cat > /tmp/test_emcc.c << 'EOF'
#include <stdio.h>
int main() {
    printf("Hello from emscripten!\n");
    return 0;
}
EOF

    emcc /tmp/test_emcc.c -o /tmp/test_emcc.js 2>/dev/null
    local result=$?
    rm -f /tmp/test_emcc.c /tmp/test_emcc.js /tmp/test_emcc.wasm
    return $result
}

install_emscripten() {
    print_step "Установка emscripten (версия: ${VERSION})..."

    cleanup_broken_links

    if check_emscripten; then
        print_warning "emscripten уже установлен в $EMSDK_DIR"
        if test_emcc; then
            print_success "emcc работает корректно"
            return 0
        fi
    fi

    if ! cd "$EMSDK_DIR" 2>/dev/null; then
        print_info "Клонирование emsdk..."
        git clone https://github.com/emscripten-core/emsdk.git "$EMSDK_DIR" || {
            print_error "Ошибка клонирования"
            return 1
        }
        cd "$EMSDK_DIR" || return 1
    fi

    print_info "Обновление и установка..."
    ./emsdk update 2>/dev/null
    ./emsdk install "$VERSION" || { print_error "Ошибка установки"; return 1; }
    ./emsdk activate "$VERSION" || { print_error "Ошибка активации"; return 1; }

    activate_emscripten
    test_emcc && print_success "emcc работает корректно!" || print_warning "emcc требует активации"

    if file_exists "$HOME/.bashrc" && ! grep -q "emsdk_env.sh" "$HOME/.bashrc" 2>/dev/null; then
        print_info "Добавление в ~/.bashrc..."
        echo -e "\n# Emscripten SDK (официальная установка)\nsource \"$EMSDK_DIR/emsdk_env.sh\" > /dev/null 2>&1" >> "$HOME/.bashrc"
        print_success "Добавлено в ~/.bashrc"
    fi

    print_success "Установка завершена!"
    return 0
}

check_emscripten() {
    file_exists "$EMSDK_DIR" && file_exists "$EMSDK_DIR/emsdk_env.sh"
    return $?
}

check_emcc_version() {
    if command -v emcc &> /dev/null; then
        print_success "✅ emcc работает!"
        return 0
    else
        print_error "❌ emcc НЕ ДОСТУПЕН!"
        return 1
    fi
}

show_full_info() {
    echo ""
    print_separator "main"
    print_centered "📦 EMSCRIPTEN УСТАНОВЛЕН" "$GREEN"
    print_separator "main_bottom"
    echo ""

    if command -v emcc &> /dev/null; then
        print_success "emcc найден!"
        echo ""
        echo -e "${BOLD}📦 Версия:${NC}"
        echo -e "${DIM}─────────────────────────────────────────────────────────────────────${NC}"
        emcc --version 2>/dev/null
        echo -e "${DIM}─────────────────────────────────────────────────────────────────────${NC}"
        echo ""
        echo -e "${BOLD}📍 Путь:${NC} $(which emcc)"
        echo ""
    else
        print_warning "emcc не доступен в текущей сессии"
        echo ""
        echo "⚠️  Для активации выполните:"
        echo "  source $EMSDK_DIR/emsdk_env.sh"
        echo ""
    fi

    echo -e "${BOLD}📋 Для сборки проекта:${NC}"
    echo "  ./build.sh"
    echo ""
    echo -e "${BOLD}📋 Документация:${NC}"
    echo "  https://emscripten.org/docs/getting_started/downloads.html"
    echo ""
}

# ═══════════════════════════════════════════════════════════════════════════════
#  🎯 ОСНОВНАЯ ФУНКЦИЯ
# ═══════════════════════════════════════════════════════════════════════════════

main() {
    # Парсим аргументы
    while [[ $# -gt 0 ]]; do
        case $1 in
            -h|--help)
                show_help
                exit 0
                ;;
            -v|--version)
                [ -n "$2" ] && VERSION="$2" || { print_error "Не указана версия"; exit 1; }
                shift 2
                ;;
            -l|--list)
                show_versions
                exit 0
                ;;
            -c|--check)
                check_installation
                exit $?
                ;;
            -a|--activate)
                only_activate
                exit $?
                ;;
            -C|--clean)
                only_clean
                exit $?
                ;;
            -f|--force)
                force_reinstall
                exit $?
                ;;
            -s|--show-content)
                SHOW_CONTENT=1
                shift
                ;;
            -g|--graph)
                SHOW_GRAPH=1
                shift
                ;;
            -A|--analyze)
                ANALYZE=1
                shift
                ;;
            --no-show)
                EXECUTE_AND_SHOW=0
                shift
                ;;
            *)
                print_error "Неизвестная опция: $1"
                show_help
                exit 1
                ;;
        esac
    done

    # Если запрошен показ содержимого
    if [ $SHOW_CONTENT -eq 1 ]; then
        show_content
        exit 0
    fi

    # Если запрошен граф
    if [ $SHOW_GRAPH -eq 1 ]; then
        show_graph
        exit 0
    fi

    # Если запрошен анализ
    if [ $ANALYZE -eq 1 ]; then
        analyze_script
        exit 0
    fi

    # Основная установка
    print_header
    print_info "Версия для установки: ${VERSION}"
    echo ""

    check_dependencies
    install_emscripten

    if [ $? -eq 0 ] && [ $INSTALL_ERROR -eq 0 ]; then
        echo ""
        print_success "✅ Установка завершена успешно!"
        echo ""

        if command -v emcc &> /dev/null; then
            print_success "✅ emcc работает!"
            echo ""
        fi

        show_full_info

        echo ""
        echo -e "${DIM}Для активации в новой сессии:${NC}"
        echo "  source $EMSDK_DIR/emsdk_env.sh"
        echo ""
        echo -e "${DIM}Или просто перезапустите терминал${NC}"
    else
        print_error "❌ Ошибка установки"
        echo ""
        echo "⚠️  Что нужно сделать:"
        echo "1. Проверить интернет-соединение"
        echo "2. Установить вручную:"
        echo "   git clone https://github.com/emscripten-core/emsdk.git ~/emsdk"
        echo "   cd ~/emsdk && ./emsdk install latest && ./emsdk activate latest"
        echo "   source ./emsdk_env.sh"
        echo "3. Или использовать: ./install-emscripten.sh -f"
        exit 1
    fi
}

# ═══════════════════════════════════════════════════════════════════════════════
#  📚 СПРАВКА
# ═══════════════════════════════════════════════════════════════════════════════

show_help() {
    echo ""
    print_separator "main"
    print_centered "📚 СПРАВКА" "$CYAN"
    print_separator "main_bottom"
    echo ""

    echo -e "${BOLD}Использование:${NC} ./install-emscripten.sh [OPTIONS]"
    echo ""
    echo -e "${BOLD}📦 Установка Emscripten согласно официальной документации${NC}"
    echo ""
    echo -e "${BOLD}Опции:${NC}"
    echo "  -h, --help          Показать эту справку"
    echo "  -v, --version VER   Установить конкретную версию (по умолчанию: latest)"
    echo "  -l, --list          Показать доступные версии"
    echo "  -c, --check         Проверить установку"
    echo "  -a, --activate      Только активировать emscripten"
    echo "  -C, --clean         Очистить битые симлинки с проверкой"
    echo "  -f, --force         Принудительная переустановка"
    echo ""
    echo -e "${BOLD}📊 Визуализация и анализ:${NC}"
    echo "  -s, --show-content  Показать полное содержимое скрипта с нумерацией"
    echo "  -g, --graph         Показать граф структуры скрипта"
    echo "  -A, --analyze       Проанализировать содержимое и создать объект"
    echo ""
    echo -e "${BOLD}Примеры:${NC}"
    echo "  ./install-emscripten.sh              # Установить последнюю версию"
    echo "  ./install-emscripten.sh -v 3.1.50   # Установить версию 3.1.50"
    echo "  ./install-emscripten.sh -s          # Показать содержимое скрипта"
    echo "  ./install-emscripten.sh -g          # Показать граф структуры"
    echo "  ./install-emscripten.sh -A          # Анализ и создание объекта"
    echo "  ./install-emscripten.sh -f          # Принудительная переустановка"
    echo ""
    echo -e "${BOLD}📋 Официальная документация:${NC}"
    echo "  https://emscripten.org/docs/getting_started/downloads.html"
    echo ""
}

# ═══════════════════════════════════════════════════════════════════════════════
#  🏃 ЗАПУСК
# ═══════════════════════════════════════════════════════════════════════════════

main "$@"
