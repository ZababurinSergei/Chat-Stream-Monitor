// tests/wasm-memory-test.mjs
// Тесты управления памятью для WASM модуля Config Generator

import { describe, it, before, after, assert } from 'node:test';
import { strict as assert } from 'node:assert';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const __dirname = dirname(fileURLToPath(import.meta.url));

describe('Тесты управления памятью WASM модуля', () => {
  let moduleInstance = null;
  let ConfigGenerator = null;
  const WASM_PATH = join(__dirname, '../web/config_generator.mjs');

  // ============================================================
  // ПОДГОТОВКА - ЗАГРУЗКА МОДУЛЯ
  // ============================================================
  before(async () => {
    try {
      const module = await import(WASM_PATH);
      ConfigGenerator = module.default;

      moduleInstance = await ConfigGenerator({
        print: text => console.log(`[WASM] ${text}`),
        printErr: text => console.error(`[WASM ERR] ${text}`),
        onRuntimeInitialized: () => {
          console.log('✅ WASM Runtime инициализирован для тестов памяти');
        },
      });

      assert.ok(moduleInstance, 'Модуль должен быть загружен');
      console.log('✅ Модуль WASM успешно загружен для тестов памяти');
    } catch (error) {
      console.error('❌ Ошибка загрузки WASM модуля:', error);
      throw error;
    }
  });

  // ============================================================
  // ОЧИСТКА ПОСЛЕ ТЕСТОВ
  // ============================================================
  after(async () => {
    console.log('🧹 Очистка после тестов памяти...');
    // Освобождаем все возможные ресурсы
    if (moduleInstance && moduleInstance._free_config_string) {
      // Пытаемся освободить любые зависшие указатели
      // (в реальном коде нужно отслеживать все указатели)
    }
    console.log('✅ Очистка завершена');
  });

  // ============================================================
  // ТЕСТ 1: БАЗОВОЕ ВЫДЕЛЕНИЕ ПАМЯТИ
  // ============================================================
  describe('Базовое выделение памяти', () => {
    it('должен выделять память для строк JSON', () => {
      const ptr = moduleInstance._generate_config_json();

      // Проверяем что указатель валидный (не нулевой)
      assert.ok(ptr > 0, 'Указатель должен быть больше 0');
      assert.ok(ptr < 1000000000, 'Указатель должен быть в разумных пределах');

      // Проверяем что память доступна для чтения
      const heap = moduleInstance.HEAPU8;
      if (heap) {
        assert.ok(heap.length > ptr, 'HEAPU8 должен быть доступен по указателю');
      } else if (moduleInstance.memory) {
        const view = new Uint8Array(moduleInstance.memory.buffer);
        assert.ok(view.length > ptr, 'Память должна быть доступна по указателю');
      }

      // Освобождаем память
      moduleInstance._free_config_string(ptr);
    });

    it('должен выделять память для C заголовков', () => {
      const ptr = moduleInstance._generate_config_c();
      assert.ok(ptr > 0, 'Указатель должен быть больше 0');
      moduleInstance._free_config_string(ptr);
    });

    it('должен выделять память для ENV файлов', () => {
      const ptr = moduleInstance._generate_config_env();
      assert.ok(ptr > 0, 'Указатель должен быть больше 0');
      moduleInstance._free_config_string(ptr);
    });

    it('должен возвращать разные указатели при последовательных вызовах', () => {
      const ptr1 = moduleInstance._generate_config_json();
      const ptr2 = moduleInstance._generate_config_json();

      assert.notStrictEqual(ptr1, ptr2, 'Указатели должны быть разными');

      moduleInstance._free_config_string(ptr1);
      moduleInstance._free_config_string(ptr2);
    });
  });

  // ============================================================
  // ТЕСТ 2: УТЕЧКИ ПАМЯТИ
  // ============================================================
  describe('Обнаружение утечек памяти', () => {
    it('не должен иметь утечек при множественной генерации JSON', async () => {
      // Замеряем начальное использование памяти
      const initialMemory = process.memoryUsage().heapUsed;
      const iterations = 1000;

      console.log(`📊 Начальная память: ${(initialMemory / 1024 / 1024).toFixed(2)} MB`);

      // Генерируем много конфигов с освобождением
      for (let i = 0; i < iterations; i++) {
        const ptr = moduleInstance._generate_config_json();
        const jsonString = moduleInstance.UTF8ToString(ptr);
        // Проверяем что строка не пустая
        assert.ok(jsonString.length > 100, `Итерация ${i}: строка должна быть непустой`);
        moduleInstance._free_config_string(ptr);
      }

      // Принудительный GC если доступен
      if (global.gc) {
        global.gc();
        console.log('🧹 Принудительный GC выполнен');
      }

      // Замеряем конечное использование памяти
      const finalMemory = process.memoryUsage().heapUsed;
      const memoryGrowth = finalMemory - initialMemory;

      console.log(`📊 Конечная память: ${(finalMemory / 1024 / 1024).toFixed(2)} MB`);
      console.log(`📊 Рост памяти: ${(memoryGrowth / 1024 / 1024).toFixed(2)} MB`);

      // Допускаем небольшой рост памяти (не более 50MB)
      assert.ok(
        memoryGrowth < 50 * 1024 * 1024,
        `Рост памяти (${(memoryGrowth / 1024 / 1024).toFixed(2)} MB) должен быть меньше 50MB`
      );
    });

    it('не должен иметь утечек при множественной генерации C заголовков', async () => {
      const initialMemory = process.memoryUsage().heapUsed;
      const iterations = 1000;

      for (let i = 0; i < iterations; i++) {
        const ptr = moduleInstance._generate_config_c();
        moduleInstance._free_config_string(ptr);
      }

      if (global.gc) {
        global.gc();
      }

      const finalMemory = process.memoryUsage().heapUsed;
      const memoryGrowth = finalMemory - initialMemory;

      console.log(`📊 Рост памяти (C заголовки): ${(memoryGrowth / 1024 / 1024).toFixed(2)} MB`);

      assert.ok(
        memoryGrowth < 50 * 1024 * 1024,
        `Рост памяти (${(memoryGrowth / 1024 / 1024).toFixed(2)} MB) должен быть меньше 50MB`
      );
    });

    it('не должен иметь утечек при множественной генерации ENV файлов', async () => {
      const initialMemory = process.memoryUsage().heapUsed;
      const iterations = 1000;

      for (let i = 0; i < iterations; i++) {
        const ptr = moduleInstance._generate_config_env();
        moduleInstance._free_config_string(ptr);
      }

      if (global.gc) {
        global.gc();
      }

      const finalMemory = process.memoryUsage().heapUsed;
      const memoryGrowth = finalMemory - initialMemory;

      console.log(`📊 Рост памяти (ENV): ${(memoryGrowth / 1024 / 1024).toFixed(2)} MB`);

      assert.ok(
        memoryGrowth < 50 * 1024 * 1024,
        `Рост памяти (${(memoryGrowth / 1024 / 1024).toFixed(2)} MB) должен быть меньше 50MB`
      );
    });

    it('не должен иметь утечек при чередовании разных типов генерации', async () => {
      const initialMemory = process.memoryUsage().heapUsed;
      const iterations = 500;

      for (let i = 0; i < iterations; i++) {
        // Чередуем разные типы
        const ptr1 = moduleInstance._generate_config_json();
        moduleInstance._free_config_string(ptr1);

        const ptr2 = moduleInstance._generate_config_c();
        moduleInstance._free_config_string(ptr2);

        const ptr3 = moduleInstance._generate_config_env();
        moduleInstance._free_config_string(ptr3);
      }

      if (global.gc) {
        global.gc();
      }

      const finalMemory = process.memoryUsage().heapUsed;
      const memoryGrowth = finalMemory - initialMemory;

      console.log(`📊 Рост памяти (чередование): ${(memoryGrowth / 1024 / 1024).toFixed(2)} MB`);

      assert.ok(
        memoryGrowth < 50 * 1024 * 1024,
        `Рост памяти (${(memoryGrowth / 1024 / 1024).toFixed(2)} MB) должен быть меньше 50MB`
      );
    });
  });

  // ============================================================
  // ТЕСТ 3: ПАРАЛЛЕЛЬНОЕ ВЫДЕЛЕНИЕ ПАМЯТИ
  // ============================================================
  describe('Параллельное выделение памяти', () => {
    it('должен корректно обрабатывать множество одновременных указателей', () => {
      const pointers = [];
      const count = 100;

      console.log(`📊 Выделение ${count} указателей одновременно...`);

      // Выделяем память для множества строк
      for (let i = 0; i < count; i++) {
        const ptr = moduleInstance._generate_config_json();
        pointers.push(ptr);
      }

      // Проверяем что все указатели уникальны
      const uniquePointers = new Set(pointers);
      assert.strictEqual(
        uniquePointers.size,
        pointers.length,
        'Все указатели должны быть уникальными'
      );

      // Проверяем что все строки читаются корректно
      for (let i = 0; i < pointers.length; i++) {
        const ptr = pointers[i];
        const jsonString = moduleInstance.UTF8ToString(ptr);
        assert.ok(jsonString.length > 100, `Строка ${i} должна быть непустой`);
      }

      // Освобождаем память
      console.log(`🧹 Освобождение ${count} указателей...`);
      for (const ptr of pointers) {
        moduleInstance._free_config_string(ptr);
      }

      console.log('✅ Все указатели освобождены');
    });

    it('должен корректно обрабатывать частичное освобождение', () => {
      const pointers = [];
      const count = 50;

      // Выделяем память
      for (let i = 0; i < count; i++) {
        const ptr = moduleInstance._generate_config_json();
        pointers.push(ptr);
      }

      // Освобождаем каждый второй указатель
      for (let i = 0; i < pointers.length; i += 2) {
        moduleInstance._free_config_string(pointers[i]);
        pointers[i] = 0; // Отмечаем как освобожденный
      }

      // Проверяем что оставшиеся указатели все еще валидны
      for (let i = 1; i < pointers.length; i += 2) {
        const ptr = pointers[i];
        assert.ok(ptr > 0, `Указатель ${i} должен быть валидным`);
        const jsonString = moduleInstance.UTF8ToString(ptr);
        assert.ok(jsonString.length > 0, `Строка ${i} должна быть читаемой`);
        moduleInstance._free_config_string(ptr);
      }
    });
  });

  // ============================================================
  // ТЕСТ 4: БЕЗОПАСНОСТЬ ПАМЯТИ
  // ============================================================
  describe('Безопасность работы с памятью', () => {
    it('должен корректно обрабатывать освобождение нулевого указателя', () => {
      // Освобождение NULL должно быть безопасным
      assert.doesNotThrow(() => {
        moduleInstance._free_config_string(0);
      }, 'Освобождение нулевого указателя не должно вызывать ошибку');
    });

    it('должен корректно обрабатывать освобождение отрицательного указателя', () => {
      // Освобождение отрицательного указателя не должно падать
      assert.doesNotThrow(() => {
        moduleInstance._free_config_string(-1);
      }, 'Освобождение отрицательного указателя не должно вызывать ошибку');
    });

    it('должен корректно обрабатывать повторное освобождение', () => {
      const ptr = moduleInstance._generate_config_json();
      assert.ok(ptr > 0, 'Указатель должен быть валидным');

      // Первое освобождение
      moduleInstance._free_config_string(ptr);

      // Повторное освобождение должно быть безопасным
      assert.doesNotThrow(() => {
        moduleInstance._free_config_string(ptr);
      }, 'Повторное освобождение не должно вызывать ошибку');
    });

    it('должен корректно обрабатывать чтение по невалидному указателю', () => {
      const invalidPtr = 999999999;

      // Чтение по невалидному указателю не должно падать
      assert.doesNotThrow(() => {
        const str = moduleInstance.UTF8ToString(invalidPtr);
        // Может вернуть пустую строку или неопределенное значение
      }, 'Чтение по невалидному указателю не должно вызывать ошибку');
    });

    it('должен корректно обрабатывать чтение по указателю за пределами памяти', () => {
      const heapSize = moduleInstance.HEAPU8
        ? moduleInstance.HEAPU8.length
        : moduleInstance.memory?.buffer?.byteLength || 0;

      if (heapSize > 0) {
        const beyondPtr = heapSize + 1000;
        assert.doesNotThrow(() => {
          const str = moduleInstance.UTF8ToString(beyondPtr);
        }, 'Чтение за пределами памяти не должно вызывать ошибку');
      }
    });
  });

  // ============================================================
  // ТЕСТ 5: РАБОТА СО СТРОКАМИ В ПАМЯТИ
  // ============================================================
  describe('Работа со строками в памяти', () => {
    it('должен корректно кодировать и декодировать UTF-8 строки', () => {
      const ptr = moduleInstance._generate_config_json();
      const jsonString = moduleInstance.UTF8ToString(ptr);
      moduleInstance._free_config_string(ptr);

      // Проверяем что строка содержит валидный UTF-8
      const encoder = new TextEncoder();
      const encoded = encoder.encode(jsonString);

      // Декодируем обратно
      const decoder = new TextDecoder();
      const decoded = decoder.decode(encoded);

      assert.strictEqual(
        jsonString,
        decoded,
        'UTF-8 кодирование/декодирование должно сохранять строку'
      );
    });

    it('должен корректно обрабатывать длинные строки (> 10KB)', () => {
      const ptr = moduleInstance._generate_config_json();
      const jsonString = moduleInstance.UTF8ToString(ptr);
      moduleInstance._free_config_string(ptr);

      // JSON конфиг должен быть достаточно большим
      assert.ok(
        jsonString.length > 2000,
        `Длина JSON строки (${jsonString.length}) должна быть больше 2000 символов`
      );

      // Проверяем что строка может быть обработана
      const config = JSON.parse(jsonString);
      assert.ok(config, 'Длинная строка должна парситься в JSON');
    });

    it('должен корректно обрабатывать специальные символы в строках', () => {
      const ptr = moduleInstance._generate_config_env();
      const envContent = moduleInstance.UTF8ToString(ptr);
      moduleInstance._free_config_string(ptr);

      // Проверяем наличие специальных символов (если они есть в конфиге)
      // В .env файле могут быть #, =, _, -
      assert.ok(envContent.includes('='), 'ENV содержимое должно содержать символ "="');

      // Проверяем что содержимое читается как текст
      const lines = envContent.split('\n');
      assert.ok(lines.length > 10, 'Должно быть несколько строк');
    });

    it('должен корректно обрабатывать пустые строки', () => {
      // Генерируем строку и проверяем что она не пустая
      const ptr = moduleInstance._generate_config_json();
      const jsonString = moduleInstance.UTF8ToString(ptr);
      moduleInstance._free_config_string(ptr);

      assert.ok(jsonString.length > 0, 'Строка не должна быть пустой');

      // Проверяем что строка не состоит только из пробелов
      assert.ok(jsonString.trim().length > 0, 'Строка не должна состоять только из пробелов');
    });
  });

  // ============================================================
  // ТЕСТ 6: СТРЕСС-ТЕСТЫ
  // ============================================================
  describe('Стресс-тесты памяти', () => {
    it('должен выдерживать интенсивную нагрузку (10000 генераций)', async function () {
      // Увеличиваем таймаут для этого теста
      this.timeout(60000);

      const iterations = 10000;
      console.log(`📊 Запуск стресс-теста: ${iterations} генераций...`);

      const start = performance.now();

      for (let i = 0; i < iterations; i++) {
        const ptr = moduleInstance._generate_config_json();
        const jsonString = moduleInstance.UTF8ToString(ptr);

        // Периодически проверяем валидность
        if (i % 100 === 0) {
          try {
            JSON.parse(jsonString);
          } catch (error) {
            console.error(`❌ Ошибка на итерации ${i}:`, error);
            throw error;
          }
        }

        moduleInstance._free_config_string(ptr);
      }

      const end = performance.now();
      const totalTime = (end - start) / 1000;

      console.log(`📊 Стресс-тест завершен:`);
      console.log(`   Итераций: ${iterations}`);
      console.log(`   Время: ${totalTime.toFixed(2)} сек`);
      console.log(`   Среднее: ${((totalTime * 1000) / iterations).toFixed(2)} мс на итерацию`);

      assert.ok(
        totalTime < 300,
        `Стресс-тест (${iterations} итераций) должен завершиться за < 300 сек (заняло ${totalTime.toFixed(2)} сек)`
      );
    });

    it('должен выдерживать чередование типов в стресс-режиме', async function () {
      this.timeout(60000);

      const iterations = 5000;
      console.log(`📊 Стресс-тест чередования: ${iterations} итераций...`);

      const start = performance.now();

      for (let i = 0; i < iterations; i++) {
        const type = i % 3;
        let ptr;

        switch (type) {
          case 0:
            ptr = moduleInstance._generate_config_json();
            break;
          case 1:
            ptr = moduleInstance._generate_config_c();
            break;
          case 2:
            ptr = moduleInstance._generate_config_env();
            break;
        }

        // Проверяем что указатель валидный
        assert.ok(ptr > 0, `Итерация ${i}: указатель должен быть валидным`);

        // Читаем строку
        const str = moduleInstance.UTF8ToString(ptr);
        assert.ok(str.length > 0, `Итерация ${i}: строка не должна быть пустой`);

        moduleInstance._free_config_string(ptr);
      }

      const end = performance.now();
      const totalTime = (end - start) / 1000;

      console.log(`📊 Стресс-тест чередования завершен:`);
      console.log(`   Итераций: ${iterations}`);
      console.log(`   Время: ${totalTime.toFixed(2)} сек`);
      console.log(`   Среднее: ${((totalTime * 1000) / iterations).toFixed(2)} мс на итерацию`);

      assert.ok(
        totalTime < 200,
        `Стресс-тест чередования должен завершиться за < 200 сек (заняло ${totalTime.toFixed(2)} сек)`
      );
    });
  });

  // ============================================================
  // ТЕСТ 7: ИНФОРМАЦИЯ О ПАМЯТИ
  // ============================================================
  describe('Информация о состоянии памяти', () => {
    it('должен предоставлять доступ к HEAPU8', () => {
      const heap = moduleInstance.HEAPU8;
      if (heap) {
        assert.ok(heap instanceof Uint8Array, 'HEAPU8 должен быть Uint8Array');
        assert.ok(heap.length > 0, 'HEAPU8 должен иметь размер > 0');
        console.log(`📊 HEAPU8 размер: ${(heap.length / 1024 / 1024).toFixed(2)} MB`);
      } else {
        console.log('⚠️ HEAPU8 не доступен, проверяем memory');
        const memory = moduleInstance.memory;
        if (memory) {
          assert.ok(memory.buffer instanceof ArrayBuffer, 'memory.buffer должен быть ArrayBuffer');
          console.log(
            `📊 memory размер: ${(memory.buffer.byteLength / 1024 / 1024).toFixed(2)} MB`
          );
        }
      }
    });

    it('должен предоставлять доступ к wasmMemory', () => {
      const wasmMemory = moduleInstance.wasmMemory;
      if (wasmMemory) {
        assert.ok(
          wasmMemory.buffer instanceof ArrayBuffer,
          'wasmMemory.buffer должен быть ArrayBuffer'
        );
        console.log(
          `📊 wasmMemory размер: ${(wasmMemory.buffer.byteLength / 1024 / 1024).toFixed(2)} MB`
        );
      } else {
        console.log('⚠️ wasmMemory не доступен');
      }
    });

    it('должен корректно обрабатывать запросы на выделение памяти', () => {
      // Проверяем что можно выделить и освободить память многократно
      const ptrs = [];

      for (let i = 0; i < 10; i++) {
        const ptr = moduleInstance._generate_config_json();
        ptrs.push(ptr);

        // Проверяем что указатель в допустимом диапазоне
        assert.ok(ptr > 0 && ptr < 100000000, 'Указатель должен быть в допустимом диапазоне');
      }

      // Освобождаем все
      for (const ptr of ptrs) {
        moduleInstance._free_config_string(ptr);
      }

      console.log('✅ 10 последовательных выделений/освобождений выполнено успешно');
    });
  });

  // ============================================================
  // ТЕСТ 8: КРОСС-БРАУЗЕРНАЯ СОВМЕСТИМОСТЬ
  // ============================================================
  describe('Кросс-браузерная совместимость памяти', () => {
    it('должен корректно работать с TextDecoder для UTF-8 строк', () => {
      const ptr = moduleInstance._generate_config_json();
      const jsonString = moduleInstance.UTF8ToString(ptr);
      moduleInstance._free_config_string(ptr);

      // Используем TextDecoder для декодирования
      const encoder = new TextEncoder();
      const bytes = encoder.encode(jsonString);
      const decoder = new TextDecoder('utf-8', { fatal: true });

      // Декодирование не должно вызывать ошибок
      assert.doesNotThrow(() => {
        const decoded = decoder.decode(bytes);
        assert.strictEqual(
          decoded,
          jsonString,
          'Декодированная строка должна совпадать с оригиналом'
        );
      }, 'TextDecoder должен корректно декодировать UTF-8 строку');
    });

    it('должен корректно работать в ограниченной памяти (имитация браузера)', () => {
      // Создаем искусственное ограничение памяти
      const originalHeap = moduleInstance.HEAPU8;

      // Проверяем что можно работать даже с небольшим буфером
      if (originalHeap) {
        const limitedHeap = new Uint8Array(
          originalHeap.buffer,
          0,
          Math.min(originalHeap.length, 1024 * 1024)
        );
        // Проверяем что указатели в пределах доступной памяти
        const ptr = moduleInstance._generate_config_json();
        // Указатель может быть за пределами ограниченного буфера
        // Но это нормально, так как WASM управляет своей памятью
        assert.ok(ptr > 0, 'Указатель должен быть валидным даже при ограниченной памяти');
        moduleInstance._free_config_string(ptr);
      }
    });
  });

  // ============================================================
  // ТЕСТ 9: ВЫВОД ИНФОРМАЦИИ О ПАМЯТИ (HELP)
  // ============================================================
  describe('Диагностика памяти', () => {
    it('должен выводить информацию о памяти для отладки', () => {
      console.log('\n📊 ДИАГНОСТИКА ПАМЯТИ');
      console.log('═══════════════════════════════════════════════════════════');

      // Информация о HEAP
      if (moduleInstance.HEAPU8) {
        console.log(`  HEAPU8: ${moduleInstance.HEAPU8.length} байт`);
        console.log(`  HEAPU8 тип: ${moduleInstance.HEAPU8.constructor.name}`);
      }

      // Информация о memory
      if (moduleInstance.memory) {
        console.log(`  memory: ${moduleInstance.memory.buffer.byteLength} байт`);
      }

      // Информация о wasmMemory
      if (moduleInstance.wasmMemory) {
        console.log(`  wasmMemory: ${moduleInstance.wasmMemory.buffer.byteLength} байт`);
      }

      // Экспортированные функции
      const exports = Object.keys(moduleInstance).filter(k => k.startsWith('_'));
      console.log(`  Экспортированные функции: ${exports.length}`);
      console.log(`    ${exports.join(', ')}`);

      console.log('═══════════════════════════════════════════════════════════\n');

      // Проверяем что диагностика выполняется без ошибок
      assert.ok(true, 'Диагностика выполнена успешно');
    });
  });
});

// Экспорт для использования в других тестах
export { moduleInstance, ConfigGenerator };

console.log('✅ tests/wasm-memory-test.mjs загружен');
console.log('📋 Для запуска: node --test tests/wasm-memory-test.mjs');
console.log('📋 С включенным GC: node --expose-gc --test tests/wasm-memory-test.mjs');
