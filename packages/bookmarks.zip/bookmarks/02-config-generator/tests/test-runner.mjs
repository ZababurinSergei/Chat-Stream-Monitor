// tests/test-runner.mjs
// Запускатор тестов для WASM модуля Config Generator
// Поддерживает групповой запуск, отчеты и фильтрацию тестов

import { exec } from 'node:child_process';
import { promisify } from 'node:util';
import { readdir, stat, mkdir, writeFile, readFile } from 'node:fs/promises';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createInterface } from 'node:readline';

const execAsync = promisify(exec);
const __dirname = dirname(fileURLToPath(import.meta.url));

// ============================================================
// КОНФИГУРАЦИЯ ЗАПУСКАТОРА
// ============================================================

const CONFIG = {
  // Директория с тестами
  testsDir: join(__dirname, '.'),

  // Директория для отчетов
  reportsDir: join(__dirname, 'reports'),

  // Шаблон имен тестовых файлов
  testPattern: /^wasm-.*\.mjs$/,

  // Таймаут для каждого теста (мс)
  timeout: 30000,

  // Флаги Node.js для тестов
  nodeFlags: [
    '--expose-gc',
    '--experimental-vm-modules',
    '--no-warnings',
  ],

  // Цвета для вывода
  colors: {
    reset: '\x1b[0m',
    red: '\x1b[31m',
    green: '\x1b[32m',
    yellow: '\x1b[33m',
    blue: '\x1b[34m',
    magenta: '\x1b[35m',
    cyan: '\x1b[36m',
    white: '\x1b[37m',
    gray: '\x1b[90m',
    bold: '\x1b[1m',
  },
};

// ============================================================
// ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ
// ============================================================

/**
 * Вывод цветного текста
 */
function colorize(text, color) {
  return `${CONFIG.colors[color] || ''}${text}${CONFIG.colors.reset}`;
}

/**
 * Вывод заголовка
 */
function printHeader(title) {
  const line = '═'.repeat(Math.min(80, title.length + 4));
  console.log('');
  console.log(colorize(`╔${line}╗`, 'cyan'));
  console.log(colorize(`║ ${title} ║`, 'cyan'));
  console.log(colorize(`╚${line}╝`, 'cyan'));
  console.log('');
}

/**
 * Вывод статистики
 */
function printStats(stats) {
  console.log('');
  console.log(colorize('📊 СТАТИСТИКА ТЕСТОВ', 'bold'));
  console.log(colorize('═══════════════════════════════════════════════════════════', 'gray'));
  console.log(`  ${colorize('✅ Пройдено:', 'green')}  ${stats.passed}`);
  console.log(`  ${colorize('❌ Провалено:', 'red')}  ${stats.failed}`);
  console.log(`  ${colorize('⏭️ Пропущено:', 'yellow')} ${stats.skipped}`);
  console.log(`  ${colorize('📦 Всего:', 'cyan')}     ${stats.total}`);
  console.log(`  ${colorize('⏱️ Время:', 'magenta')}   ${stats.duration}с`);
  console.log(colorize('═══════════════════════════════════════════════════════════', 'gray'));
  console.log('');
}

/**
 * Вывод результата теста
 */
function printTestResult(name, result, error = null) {
  const icon = result === 'passed' ? '✅' : result === 'failed' ? '❌' : '⏭️';
  const color = result === 'passed' ? 'green' : result === 'failed' ? 'red' : 'yellow';

  console.log(`  ${colorize(icon, color)} ${colorize(name, color)}`);

  if (error) {
    console.log(colorize(`    ⚠️ ${error.message}`, 'red'));
    if (error.stack) {
      const stackLines = error.stack.split('\n').slice(0, 3);
      console.log(colorize(`    📚 ${stackLines.join('\n    ')}`, 'gray'));
    }
  }
}

/**
 * Задержка
 */
function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// ============================================================
// ПОИСК ТЕСТОВ
// ============================================================

/**
 * Поиск всех тестовых файлов
 */
async function findTestFiles() {
  const files = [];
  const entries = await readdir(CONFIG.testsDir, { withFileTypes: true });

  for (const entry of entries) {
    if (entry.isFile() && CONFIG.testPattern.test(entry.name)) {
      files.push(join(CONFIG.testsDir, entry.name));
    }
  }

  return files.sort();
}

/**
 * Фильтрация тестов по имени
 */
function filterTests(files, filter) {
  if (!filter) {return files;}
  return files.filter(file => {
    const basename = file.split('/').pop();
    return basename.includes(filter);
  });
}

// ============================================================
// ЗАПУСК ТЕСТОВ
// ============================================================

/**
 * Запуск одного тестового файла
 */
async function runTestFile(filePath, options = {}) {
  const {
    timeout = CONFIG.timeout,
    verbose = false,
    collectCoverage = false,
  } = options;

  const fileName = filePath.split('/').pop();
  const startTime = Date.now();

  console.log(colorize(`\n▶️ Запуск: ${fileName}`, 'blue'));
  console.log(colorize(`   📂 ${filePath}`, 'gray'));

  try {
    // Формируем команду
    const flags = CONFIG.nodeFlags.join(' ');
    const testCmd = `node ${flags} --test ${filePath}`;

    // Запускаем тест
    const { stdout, stderr } = await execAsync(testCmd, {
      timeout,
      maxBuffer: 1024 * 1024 * 10, // 10MB
    });

    const duration = ((Date.now() - startTime) / 1000).toFixed(2);

    // Анализируем вывод
    const hasFailures = stdout.includes('✖') || stdout.includes('failed') || stderr.includes('fail');
    const hasPassed = stdout.includes('✔') || stdout.includes('passed');

    // Выводим результат
    if (verbose || hasFailures) {
      console.log(colorize(`\n📄 Вывод:`, 'cyan'));
      console.log(stdout || '(пусто)');
      if (stderr) {
        console.log(colorize(`\n⚠️ STDERR:`, 'yellow'));
        console.log(stderr);
      }
    }

    const result = {
      file: fileName,
      path: filePath,
      passed: !hasFailures && !stderr.includes('Error'),
      duration,
      stdout,
      stderr,
      hasFailures,
      hasPassed,
    };

    return result;

  } catch (error) {
    const duration = ((Date.now() - startTime) / 1000).toFixed(2);

    // Проверяем таймаут
    if (error.code === 'ETIMEDOUT' || error.killed) {
      console.log(colorize(`   ⏱️ Таймаут (${timeout}мс)`, 'red'));
      return {
        file: fileName,
        path: filePath,
        passed: false,
        duration,
        error: new Error(`Таймаут: тест превысил ${timeout}мс`),
        stdout: error.stdout || '',
        stderr: error.stderr || '',
        hasFailures: true,
        hasPassed: false,
      };
    }

    // Другие ошибки
    console.log(colorize(`   ❌ Ошибка выполнения:`, 'red'));
    console.log(colorize(`   ${error.message}`, 'red'));

    return {
      file: fileName,
      path: filePath,
      passed: false,
      duration,
      error,
      stdout: error.stdout || '',
      stderr: error.stderr || '',
      hasFailures: true,
      hasPassed: false,
    };
  }
}

/**
 * Запуск всех тестов
 */
async function runAllTests(options = {}) {
  const {
    filter = null,
    verbose = false,
    timeout = CONFIG.timeout,
    parallel = false,
    collectCoverage = false,
  } = options;

  printHeader('🧪 ЗАПУСК ТЕСТОВ WASM МОДУЛЯ');

  // Находим тесты
  let testFiles = await findTestFiles();

  if (testFiles.length === 0) {
    console.log(colorize('⚠️ Тестовые файлы не найдены', 'yellow'));
    console.log(colorize(`   Искал в: ${CONFIG.testsDir}`, 'gray'));
    console.log(colorize(`   Шаблон: ${CONFIG.testPattern}`, 'gray'));
    return {
      total: 0,
      passed: 0,
      failed: 0,
      skipped: 0,
      duration: 0,
      results: [],
    };
  }

  // Фильтруем
  if (filter) {
    testFiles = filterTests(testFiles, filter);
    console.log(colorize(`📋 Фильтр: "${filter}"`, 'cyan'));
    console.log(colorize(`   Найдено: ${testFiles.length} файлов`, 'gray'));
  } else {
    console.log(colorize(`📋 Найдено тестов: ${testFiles.length}`, 'cyan'));
  }

  console.log(colorize(`📂 Директория: ${CONFIG.testsDir}`, 'gray'));
  console.log('');

  // Запускаем тесты
  const startTime = Date.now();
  const results = [];
  const stats = {
    total: testFiles.length,
    passed: 0,
    failed: 0,
    skipped: 0,
  };

  if (parallel) {
    // Параллельный запуск
    console.log(colorize('⚡ Параллельный режим', 'magenta'));
    const promises = testFiles.map(file => runTestFile(file, { timeout, verbose, collectCoverage }));
    const resultsArray = await Promise.all(promises);

    for (const result of resultsArray) {
      results.push(result);
      if (result.passed) {
        stats.passed++;
      } else {
        stats.failed++;
      }
    }
  } else {
    // Последовательный запуск
    for (const file of testFiles) {
      const result = await runTestFile(file, { timeout, verbose, collectCoverage });
      results.push(result);

      if (result.passed) {
        stats.passed++;
        printTestResult(result.file, 'passed');
      } else {
        stats.failed++;
        printTestResult(result.file, 'failed', result.error);
      }
    }
  }

  const duration = ((Date.now() - startTime) / 1000).toFixed(2);
  stats.duration = duration;

  // Выводим статистику
  printStats(stats);

  // Сохраняем отчет
  await saveReport(results, stats);

  return {
    ...stats,
    results,
  };
}

// ============================================================
// СОЗДАНИЕ ОТЧЕТОВ
// ============================================================

/**
 * Создание директории для отчетов
 */
async function ensureReportsDir() {
  try {
    await mkdir(CONFIG.reportsDir, { recursive: true });
  } catch (error) {
    if (error.code !== 'EEXIST') {
      throw error;
    }
  }
}

/**
 * Сохранение отчета
 */
async function saveReport(results, stats) {
  await ensureReportsDir();

  const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
  const reportFile = join(CONFIG.reportsDir, `test-report-${timestamp}.json`);

  const report = {
    timestamp: new Date().toISOString(),
    stats,
    results: results.map(r => ({
      file: r.file,
      passed: r.passed,
      duration: r.duration,
      hasFailures: r.hasFailures,
      error: r.error ? {
        message: r.error.message,
        stack: r.error.stack,
      } : null,
    })),
  };

  await writeFile(reportFile, JSON.stringify(report, null, 2));
  console.log(colorize(`📄 Отчет сохранен: ${reportFile}`, 'cyan'));

  return reportFile;
}

/**
 * Загрузка последнего отчета
 */
async function loadLastReport() {
  try {
    const files = await readdir(CONFIG.reportsDir);
    const reportFiles = files
      .filter(f => f.startsWith('test-report-') && f.endsWith('.json'))
      .sort()
      .reverse();

    if (reportFiles.length === 0) {
      return null;
    }

    const lastFile = join(CONFIG.reportsDir, reportFiles[0]);
    const content = await readFile(lastFile, 'utf-8');
    return JSON.parse(content);
  } catch (error) {
    return null;
  }
}

/**
 * Показ последнего отчета
 */
async function showLastReport() {
  const report = await loadLastReport();

  if (!report) {
    console.log(colorize('⚠️ Отчеты не найдены', 'yellow'));
    return;
  }

  printHeader('📊 ПОСЛЕДНИЙ ОТЧЕТ');
  console.log(colorize(`📅 Дата: ${report.timestamp}`, 'gray'));
  printStats(report.stats);

  console.log(colorize('📋 Детали:', 'bold'));
  console.log(colorize('═══════════════════════════════════════════════════════════', 'gray'));

  for (const result of report.results) {
    const icon = result.passed ? '✅' : '❌';
    const color = result.passed ? 'green' : 'red';
    console.log(`  ${colorize(icon, color)} ${colorize(result.file, color)} ${colorize(`(${result.duration}s)`, 'gray')}`);
    if (result.error) {
      console.log(colorize(`    ⚠️ ${result.error.message}`, 'red'));
    }
  }

  console.log(colorize('═══════════════════════════════════════════════════════════', 'gray'));
}

// ============================================================
// # ИНТЕРАКТИВНЫЙ РЕЖИМ
// ============================================================

/**
 * Интерактивный режим запуска тестов
 */
async function interactiveMode() {
  const rl = createInterface({
    input: process.stdin,
    output: process.stdout,
  });

  const question = query => new Promise(resolve => {
    rl.question(query, resolve);
  });

  printHeader('🧪 ИНТЕРАКТИВНЫЙ ЗАПУСК ТЕСТОВ');

  console.log(colorize('📋 Доступные действия:', 'bold'));
  console.log('  1. Запустить все тесты');
  console.log('  2. Запустить тесты с фильтром');
  console.log('  3. Показать последний отчет');
  console.log('  4. Выйти');
  console.log('');

  const choice = await question(colorize('👉 Выберите действие (1-4): ', 'cyan'));

  rl.close();

  switch (choice.trim()) {
    case '1':
      await runAllTests({ verbose: true });
      break;
    case '2': {
      const filter = await question(colorize('🔍 Введите фильтр (часть имени файла): ', 'cyan'));
      await runAllTests({ filter: filter.trim(), verbose: true });
      break;
    }
    case '3':
      await showLastReport();
      break;
    case '4':
      console.log(colorize('👋 До свидания!', 'cyan'));
      break;
    default:
      console.log(colorize('❌ Неверный выбор', 'red'));
  }
}

// ============================================================
// # ОСНОВНАЯ ФУНКЦИЯ
// ============================================================

/**
 * Парсинг аргументов командной строки
 */
function parseArgs() {
  const args = process.argv.slice(2);
  const options = {
    filter: null,
    verbose: false,
    parallel: false,
    timeout: CONFIG.timeout,
    collectCoverage: false,
    interactive: false,
    report: false,
    help: false,
  };

  for (let i = 0; i < args.length; i++) {
    const arg = args[i];

    switch (arg) {
      case '-f':
      case '--filter':
        options.filter = args[++i];
        break;
      case '-v':
      case '--verbose':
        options.verbose = true;
        break;
      case '-p':
      case '--parallel':
        options.parallel = true;
        break;
      case '-t':
      case '--timeout':
        options.timeout = parseInt(args[++i]) * 1000;
        break;
      case '-c':
      case '--coverage':
        options.collectCoverage = true;
        break;
      case '-i':
      case '--interactive':
        options.interactive = true;
        break;
      case '-r':
      case '--report':
        options.report = true;
        break;
      case '-h':
      case '--help':
        options.help = true;
        break;
      default:
        // Если аргумент не начинается с -, считаем его фильтром
        if (!arg.startsWith('-')) {
          options.filter = arg;
        }
    }
  }

  return options;
}

/**
 * Вывод справки
 */
function showHelp() {
  console.log('');
  console.log(colorize('📚 ИСПОЛЬЗОВАНИЕ: node test-runner.mjs [ОПЦИИ] [ФИЛЬТР]', 'bold'));
  console.log('');
  console.log(colorize('ОПЦИИ:', 'cyan'));
  console.log('  -f, --filter <строка>   Фильтр по имени тестового файла');
  console.log('  -v, --verbose          Подробный вывод');
  console.log('  -p, --parallel         Параллельный запуск тестов');
  console.log('  -t, --timeout <сек>    Таймаут для каждого теста (по умолчанию: 30с)');
  console.log('  -c, --coverage         Сбор покрытия кода (требуется инструментарий)');
  console.log('  -i, --interactive      Интерактивный режим');
  console.log('  -r, --report           Показать последний отчет');
  console.log('  -h, --help             Показать эту справку');
  console.log('');
  console.log(colorize('ПРИМЕРЫ:', 'cyan'));
  console.log('  node test-runner.mjs                      # Запуск всех тестов');
  console.log('  node test-runner.mjs -f memory           # Только тесты памяти');
  console.log('  node test-runner.mjs -v -p               # Подробно + параллельно');
  console.log('  node test-runner.mjs -i                  # Интерактивный режим');
  console.log('  node test-runner.mjs -r                  # Показать последний отчет');
  console.log('');
}

// ============================================================
// # ЗАПУСК
// ============================================================

/**
 * Главная функция
 */
async function main() {
  const options = parseArgs();

  // Показываем справку
  if (options.help) {
    showHelp();
    process.exit(0);
  }

  // Показываем отчет
  if (options.report) {
    await showLastReport();
    process.exit(0);
  }

  // Интерактивный режим
  if (options.interactive) {
    await interactiveMode();
    process.exit(0);
  }

  // Запуск тестов
  try {
    const stats = await runAllTests({
      filter: options.filter,
      verbose: options.verbose,
      parallel: options.parallel,
      timeout: options.timeout,
      collectCoverage: options.collectCoverage,
    });

    // Выход с соответствующим кодом
    if (stats.failed > 0) {
      process.exit(1);
    } else {
      process.exit(0);
    }
  } catch (error) {
    console.error(colorize(`❌ Критическая ошибка: ${error.message}`, 'red'));
    console.error(error.stack);
    process.exit(1);
  }
}

// Запускаем если файл выполняется напрямую
if (import.meta.url === `file://${process.argv[1]}`) {
  main();
}

// Экспорты для использования в других модулях
export {
  runAllTests,
  runTestFile,
  findTestFiles,
  filterTests,
  saveReport,
  showLastReport,
  interactiveMode,
  CONFIG,
};

console.log('✅ tests/test-runner.mjs загружен');
console.log('📋 Команды для запуска:');
console.log('   node test-runner.mjs           - запустить все тесты');
console.log('   node test-runner.mjs -i        - интерактивный режим');
console.log('   node test-runner.mjs -f memory - запустить тесты памяти');
console.log('   node test-runner.mjs -r        - показать последний отчет');
console.log('   node test-runner.mjs -h        - справка');
