// tests/wasm-integration.mjs
// Интеграционные тесты для WASM модуля Config Generator
// Проверяют взаимодействие WASM с файловой системой, нативным бинарником и браузерным окружением

import { describe, it, before, after, assert } from 'node:test';
import { strict as assert } from 'node:assert';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
import fs from 'node:fs/promises';
import { exec } from 'node:child_process';
import { promisify } from 'node:util';

const execAsync = promisify(exec);
const __dirname = dirname(fileURLToPath(import.meta.url));

describe('Интеграционные тесты WASM модуля', () => {
  let moduleInstance = null;
  let ConfigGenerator = null;
  const WASM_PATH = join(__dirname, '../web/config_generator.mjs');
  const OUTPUT_DIR = join(__dirname, 'fixtures/output');

  // ============================================================
  // ПОДГОТОВКА - загрузка модуля и создание директорий
  // ============================================================
  before(async () => {
    // Создаем директорию для выходных файлов тестов
    await fs.mkdir(OUTPUT_DIR, { recursive: true });

    console.log('📦 Загрузка WASM модуля для интеграционных тестов...');

    try {
      const module = await import(WASM_PATH);
      ConfigGenerator = module.default;

      moduleInstance = await ConfigGenerator({
        print: text => console.log(`[WASM] ${text}`),
        printErr: text => console.error(`[WASM ERR] ${text}`),
      });

      console.log('✅ WASM модуль успешно загружен');
    } catch (error) {
      console.error('❌ Ошибка загрузки WASM модуля:', error);
      throw error;
    }
  });

  // ============================================================
  // ОЧИСТКА - удаление временных файлов
  // ============================================================
  after(async () => {
    console.log('🧹 Очистка временных файлов...');
    try {
      await fs.rm(OUTPUT_DIR, { recursive: true, force: true });
      console.log('✅ Очистка завершена');
    } catch (error) {
      console.warn('⚠️ Ошибка при очистке:', error.message);
    }
  });

  // ============================================================
  // ТЕСТ 1: Генерация и сохранение файлов
  // ============================================================
  describe('Генерация и сохранение файлов', () => {
    it('должен генерировать JSON конфиг и сохранять в файл', async () => {
      // Генерируем JSON через WASM
      const ptr = moduleInstance._generate_config_json();
      const jsonString = moduleInstance.UTF8ToString(ptr);
      moduleInstance._free_config_string(ptr);

      // Проверяем что строка не пустая
      assert.ok(jsonString, 'JSON строка не должна быть пустой');
      assert.ok(jsonString.length > 100, 'JSON должен быть достаточно большим');

      // Сохраняем в файл
      const outputPath = join(OUTPUT_DIR, 'config.json');
      await fs.writeFile(outputPath, jsonString);

      // Проверяем что файл создан
      const stat = await fs.stat(outputPath);
      assert.ok(stat.size > 0, 'Файл должен иметь содержимое');

      // Проверяем что файл читается и валидный JSON
      const content = await fs.readFile(outputPath, 'utf-8');
      const config = JSON.parse(content);

      // Проверяем структуру сохраненного конфига
      assert.ok(config.version, 'Должна быть версия');
      assert.ok(config.workspace, 'Должен быть workspace');
      assert.ok(config.broker, 'Должны быть настройки брокера');
      assert.ok(config.namespace, 'Должен быть namespace');
      assert.ok(Array.isArray(config.nodes), 'Должен быть массив узлов');

      console.log(`✅ JSON сохранен в ${outputPath}, размер: ${(stat.size / 1024).toFixed(2)}KB`);
    });

    it('должен генерировать C header и сохранять в файл', async () => {
      // Генерируем C header через WASM
      const ptr = moduleInstance._generate_config_c();
      const headerContent = moduleInstance.UTF8ToString(ptr);
      moduleInstance._free_config_string(ptr);

      assert.ok(headerContent, 'C header не должен быть пустым');
      assert.ok(headerContent.includes('#ifndef'), 'Должен быть include guard');

      // Сохраняем в файл
      const outputPath = join(OUTPUT_DIR, 'config.h');
      await fs.writeFile(outputPath, headerContent);

      // Проверяем файл
      const stat = await fs.stat(outputPath);
      assert.ok(stat.size > 0, 'Файл должен иметь содержимое');

      const content = await fs.readFile(outputPath, 'utf-8');

      // Проверяем наличие ключевых макросов
      const requiredMacros = [
        '#define WORKSPACE_NAME',
        '#define BROKER_HOST',
        '#define NAMESPACE_BASE',
        '#define MAX_HOPS',
      ];

      for (const macro of requiredMacros) {
        assert.ok(content.includes(macro), `Должен быть макрос: ${macro}`);
      }

      // Проверяем наличие структур
      const requiredStructs = ['city_t', 'rule_t', 'test_node_t'];

      for (const structName of requiredStructs) {
        assert.ok(content.includes(structName), `Должна быть структура: ${structName}`);
      }

      console.log(
        `✅ C header сохранен в ${outputPath}, размер: ${(stat.size / 1024).toFixed(2)}KB`
      );
    });

    it('должен генерировать .env файл и сохранять', async () => {
      // Генерируем .env через WASM
      const ptr = moduleInstance._generate_config_env();
      const envContent = moduleInstance.UTF8ToString(ptr);
      moduleInstance._free_config_string(ptr);

      assert.ok(envContent, '.env не должен быть пустым');
      assert.ok(envContent.includes('='), 'Должны быть переменные');

      // Сохраняем в файл
      const outputPath = join(OUTPUT_DIR, 'config.env');
      await fs.writeFile(outputPath, envContent);

      // Проверяем файл
      const stat = await fs.stat(outputPath);
      assert.ok(stat.size > 0, 'Файл должен иметь содержимое');

      const content = await fs.readFile(outputPath, 'utf-8');

      // Проверяем наличие ключевых переменных
      const requiredVars = [
        'WORKSPACE_NAME=',
        'BROKER_HOST=',
        'BROKER_PORT=',
        'NAMESPACE_BASE=',
        'MAX_HOPS=',
      ];

      for (const varName of requiredVars) {
        assert.ok(content.includes(varName), `Должна быть переменная: ${varName}`);
      }

      // Проверяем наличие комментариев
      assert.ok(content.includes('#'), 'Должны быть комментарии');

      console.log(`✅ .env сохранен в ${outputPath}, размер: ${(stat.size / 1024).toFixed(2)}KB`);
    });

    it('должен генерировать все форматы одновременно', async () => {
      // Генерируем JSON
      const jsonPtr = moduleInstance._generate_config_json();
      const jsonContent = moduleInstance.UTF8ToString(jsonPtr);
      moduleInstance._free_config_string(jsonPtr);

      // Генерируем C header
      const cPtr = moduleInstance._generate_config_c();
      const cContent = moduleInstance.UTF8ToString(cPtr);
      moduleInstance._free_config_string(cPtr);

      // Генерируем .env
      const envPtr = moduleInstance._generate_config_env();
      const envContent = moduleInstance.UTF8ToString(envPtr);
      moduleInstance._free_config_string(envPtr);

      // Сохраняем все файлы
      await Promise.all([
        fs.writeFile(join(OUTPUT_DIR, 'all_config.json'), jsonContent),
        fs.writeFile(join(OUTPUT_DIR, 'all_config.h'), cContent),
        fs.writeFile(join(OUTPUT_DIR, 'all_config.env'), envContent),
      ]);

      // Проверяем что все файлы созданы
      const files = await fs.readdir(OUTPUT_DIR);
      const expectedFiles = ['all_config.json', 'all_config.h', 'all_config.env'];

      for (const expectedFile of expectedFiles) {
        assert.ok(files.includes(expectedFile), `Должен быть файл: ${expectedFile}`);
      }

      console.log('✅ Все форматы успешно сгенерированы и сохранены');
    });
  });

  // ============================================================
  // ТЕСТ 2: Сравнение с нативным бинарником
  // ============================================================
  describe('Сравнение с нативным бинарником', () => {
    it('должен генерировать схожую структуру с нативным бинарником', async function () {
      // Проверяем наличие нативного бинарника
      const binPath = join(__dirname, '../bin/config_generator');

      try {
        await fs.access(binPath, fs.constants.X_OK);
      } catch {
        console.log('⚠️ Нативный бинарник не найден, пропускаем тест сравнения');
        this.skip();
        return;
      }

      console.log('🔍 Сравнение WASM и нативного бинарника...');

      // Генерируем через WASM
      const wasmPtr = moduleInstance._generate_config_json();
      const wasmJson = moduleInstance.UTF8ToString(wasmPtr);
      moduleInstance._free_config_string(wasmPtr);

      // Генерируем через нативный бинарник
      const { stdout: nativeJson } = await execAsync(`${binPath} --json`);

      // Парсим оба конфига
      const wasmConfig = JSON.parse(wasmJson);
      const nativeConfig = JSON.parse(nativeJson);

      // Проверяем основные ключи (структура должна совпадать)
      const requiredKeys = ['version', 'workspace', 'broker', 'namespace', 'nodes', 'cities'];

      for (const key of requiredKeys) {
        assert.ok(wasmConfig[key] !== undefined, `WASM конфиг должен иметь ключ "${key}"`);
        assert.ok(nativeConfig[key] !== undefined, `Нативный конфиг должен иметь ключ "${key}"`);
      }

      // Проверяем что версия совпадает
      assert.strictEqual(wasmConfig.version, nativeConfig.version, 'Версии должны совпадать');

      // Проверяем структуру брокера
      assert.ok(wasmConfig.broker.host, 'WASM должен иметь host брокера');
      assert.ok(nativeConfig.broker.host, 'Нативный должен иметь host брокера');
      assert.ok(wasmConfig.broker.port > 0, 'WASM должен иметь порт');
      assert.ok(nativeConfig.broker.port > 0, 'Нативный должен иметь порт');

      console.log('✅ Структуры WASM и нативного бинарника совпадают');
    });

    it('должен генерировать валидный C header аналогичный нативному', async function () {
      const binPath = join(__dirname, '../bin/config_generator');

      try {
        await fs.access(binPath, fs.constants.X_OK);
      } catch {
        console.log('⚠️ Нативный бинарник не найден, пропускаем тест');
        this.skip();
        return;
      }

      // Генерируем через WASM
      const wasmPtr = moduleInstance._generate_config_c();
      const wasmHeader = moduleInstance.UTF8ToString(wasmPtr);
      moduleInstance._free_config_string(wasmPtr);

      // Генерируем через нативный бинарник
      const { stdout: nativeHeader } = await execAsync(`${binPath} --c`);

      // Проверяем наличие общих макросов
      const commonMacros = ['WORKSPACE_NAME', 'BROKER_HOST', 'NAMESPACE_BASE'];

      for (const macro of commonMacros) {
        assert.ok(wasmHeader.includes(`#define ${macro}`), `WASM должен иметь макрос ${macro}`);
        assert.ok(
          nativeHeader.includes(`#define ${macro}`),
          `Нативный должен иметь макрос ${macro}`
        );
      }

      console.log('✅ C header структура совпадает с нативным бинарником');
    });
  });

  // ============================================================
  // ТЕСТ 3: Браузерная совместимость
  // ============================================================
  describe('Браузерная совместимость', () => {
    it('должен генерировать JSON совместимый с браузером', () => {
      const ptr = moduleInstance._generate_config_json();
      const jsonString = moduleInstance.UTF8ToString(ptr);
      moduleInstance._free_config_string(ptr);

      // Проверяем что JSON парсится в браузерном окружении
      // (эмулируем браузерный парсинг)
      const config = JSON.parse(jsonString);

      // Проверяем что все значения сериализуемы обратно в JSON
      const reSerialized = JSON.stringify(config);
      const reParsed = JSON.parse(reSerialized);

      // Сравниваем структуры
      assert.deepStrictEqual(
        Object.keys(config).sort(),
        Object.keys(reParsed).sort(),
        'Структура должна сохраняться при повторной сериализации'
      );

      // Проверяем что нет циклических ссылок
      assert.doesNotThrow(() => {
        JSON.stringify(config);
      }, 'Не должно быть циклических ссылок');

      console.log('✅ JSON совместим с браузером');
    });

    it('должен работать с ограниченной памятью браузера', () => {
      const ptr = moduleInstance._generate_config_json();
      const jsonString = moduleInstance.UTF8ToString(ptr);
      moduleInstance._free_config_string(ptr);

      // Эмулируем ограниченную память браузера
      // (обычно браузер выделяет ~2GB, но мы проверяем что конфиг разумного размера)
      const sizeInBytes = new Blob([jsonString]).size;
      const sizeInKB = sizeInBytes / 1024;
      const sizeInMB = sizeInKB / 1024;

      console.log(`📊 Размер конфига: ${sizeInKB.toFixed(2)}KB (${sizeInMB.toFixed(2)}MB)`);

      // Конфиг должен быть меньше 10MB (разумный размер для браузера)
      assert.ok(
        sizeInBytes < 10 * 1024 * 1024,
        `Размер конфига (${sizeInMB.toFixed(2)}MB) должен быть меньше 10MB`
      );

      // Проверяем что конфиг можно отобразить в браузере
      // (эмулируем вставку в DOM)
      const div = document?.createElement('div');
      if (div) {
        div.textContent = jsonString.substring(0, 1000);
        // Это только для проверки, что строка не вызывает ошибок
        assert.ok(div.textContent.length > 0, 'Строку можно вставить в DOM');
      }

      console.log('✅ Конфиг совместим с ограничениями браузера');
    });

    it('должен корректно обрабатывать Unicode символы для браузера', () => {
      const ptr = moduleInstance._generate_config_json();
      const jsonString = moduleInstance.UTF8ToString(ptr);
      moduleInstance._free_config_string(ptr);

      // Проверяем что строка содержит только валидный UTF-8
      const encoder = new TextEncoder();
      const decoder = new TextDecoder();

      try {
        const encoded = encoder.encode(jsonString);
        const decoded = decoder.decode(encoded);

        // В браузере TextDecoder должен корректно декодировать
        assert.strictEqual(
          jsonString.length,
          decoded.length,
          'Длина строки должна сохраняться при кодировании/декодировании'
        );
      } catch (error) {
        assert.fail(`Ошибка при работе с UTF-8: ${error.message}`);
      }

      console.log('✅ Unicode символы корректно обрабатываются');
    });
  });

  // ============================================================
  // ТЕСТ 4: Обработка ошибок
  // ============================================================
  describe('Обработка ошибок', () => {
    it('должен корректно обрабатывать отсутствующие экспорты', () => {
      // Пытаемся получить несуществующий экспорт
      const nonExistent = moduleInstance._non_existent_function;

      assert.strictEqual(nonExistent, undefined, 'Несуществующая функция должна быть undefined');

      // Проверяем что это не вызывает ошибку при вызове
      assert.doesNotThrow(() => {
        // @ts-ignore - намеренно вызываем несуществующую функцию
        if (typeof nonExistent === 'function') {
          nonExistent();
        }
      }, 'Вызов несуществующей функции не должен падать');

      console.log('✅ Отсутствующие экспорты корректно обрабатываются');
    });

    it('должен восстанавливаться после ошибок', () => {
      // Проверяем что модуль работает после "ошибки"
      // (используем несуществующую функцию как симуляцию ошибки)
      try {
        // @ts-ignore
        if (typeof moduleInstance._bad_function === 'function') {
          moduleInstance._bad_function();
        }
      } catch {
        // Игнорируем ошибку
      }

      // После потенциальной ошибки модуль должен продолжать работать
      const ptr = moduleInstance._generate_config_json();
      assert.ok(ptr > 0, 'Модуль должен продолжать работать после ошибки');
      moduleInstance._free_config_string(ptr);

      console.log('✅ Модуль восстанавливается после ошибок');
    });

    it('должен корректно обрабатывать невалидные указатели', () => {
      // Попытка чтения по невалидному указателю не должна вызывать краш
      const invalidPtr = 999999999;

      assert.doesNotThrow(() => {
        const str = moduleInstance.UTF8ToString(invalidPtr);
        // Может вернуть пустую строку или undefined
      }, 'Чтение по невалидному указателю не должно падать');

      // Освобождение невалидного указателя не должно падать
      assert.doesNotThrow(() => {
        moduleInstance._free_config_string(invalidPtr);
      }, 'Освобождение невалидного указателя не должно падать');

      console.log('✅ Невалидные указатели корректно обрабатываются');
    });
  });

  // ============================================================
  // ТЕСТ 5: Одновременное использование
  // ============================================================
  describe('Одновременное использование', () => {
    it('должен обрабатывать последовательные вызовы без проблем', async () => {
      const results = [];
      const iterations = 50;

      console.log(`🔄 Выполнение ${iterations} последовательных вызовов...`);

      for (let i = 0; i < iterations; i++) {
        const ptr = moduleInstance._generate_config_json();
        const json = moduleInstance.UTF8ToString(ptr);
        results.push(JSON.parse(json));
        moduleInstance._free_string(ptr);

        // Небольшая задержка для имитации реального использования
        if (i % 10 === 0) {
          await new Promise(resolve => setTimeout(resolve, 10));
        }
      }

      // Проверяем что все результаты валидны
      for (const result of results) {
        assert.ok(result.version, 'Должна быть версия');
        assert.ok(result.workspace, 'Должен быть workspace');
      }

      // Проверяем что конфиги разные (случайная генерация)
      const uniqueConfigs = new Set(results.map(r => JSON.stringify(r)));
      assert.ok(
        uniqueConfigs.size > 5,
        `Должны генерироваться разные конфиги (получено ${uniqueConfigs.size} уникальных)`
      );

      console.log(`✅ ${iterations} последовательных вызовов успешно выполнены`);
    });

    it('должен обрабатывать чередующиеся вызовы разных форматов', () => {
      const formats = ['json', 'c', 'env'];
      const results = [];

      for (let i = 0; i < 30; i++) {
        const format = formats[i % formats.length];
        let ptr;

        switch (format) {
          case 'json':
            ptr = moduleInstance._generate_config_json();
            break;
          case 'c':
            ptr = moduleInstance._generate_config_c();
            break;
          case 'env':
            ptr = moduleInstance._generate_config_env();
            break;
        }

        const content = moduleInstance.UTF8ToString(ptr);
        results.push({ format, content });
        moduleInstance._free_config_string(ptr);
      }

      // Проверяем что все результаты валидны
      for (const result of results) {
        assert.ok(result.content, `Результат формата ${result.format} не должен быть пустым`);

        if (result.format === 'json') {
          assert.doesNotThrow(() => JSON.parse(result.content), 'JSON должен быть валидным');
        } else if (result.format === 'c') {
          assert.ok(result.content.includes('#ifndef'), 'C header должен быть валидным');
        } else if (result.format === 'env') {
          assert.ok(result.content.includes('='), '.env должен быть валидным');
        }
      }

      console.log(`✅ ${results.length} чередующихся вызовов успешно выполнены`);
    });
  });

  // ============================================================
  // ТЕСТ 6: Производительность интеграции
  // ============================================================
  describe('Производительность интеграции', () => {
    it('должен генерировать и сохранять 100 конфигов за разумное время', async function () {
      this.timeout(30000); // Увеличиваем таймаут до 30 секунд

      const iterations = 100;
      const start = performance.now();

      console.log(`⏱️ Генерация и сохранение ${iterations} конфигов...`);

      for (let i = 0; i < iterations; i++) {
        // Генерируем JSON
        const ptr = moduleInstance._generate_config_json();
        const jsonContent = moduleInstance.UTF8ToString(ptr);
        moduleInstance._free_config_string(ptr);

        // Сохраняем в файл
        const outputPath = join(OUTPUT_DIR, `batch_${i.toString().padStart(3, '0')}.json`);
        await fs.writeFile(outputPath, jsonContent);
      }

      const end = performance.now();
      const totalTime = end - start;
      const avgTime = totalTime / iterations;

      console.log(`📊 Статистика:`);
      console.log(`   Всего: ${totalTime.toFixed(2)}ms`);
      console.log(`   Среднее: ${avgTime.toFixed(2)}ms на конфиг`);
      console.log(`   Скорость: ${(iterations / (totalTime / 1000)).toFixed(1)} конфигов/сек`);

      // Проверяем что все файлы созданы
      const files = await fs.readdir(OUTPUT_DIR);
      const jsonFiles = files.filter(f => f.startsWith('batch_') && f.endsWith('.json'));

      assert.strictEqual(
        jsonFiles.length,
        iterations,
        `Должно быть ${iterations} файлов, создано ${jsonFiles.length}`
      );

      // Проверяем что среднее время разумное (менее 100ms)
      assert.ok(avgTime < 100, `Среднее время (${avgTime.toFixed(2)}ms) должно быть менее 100ms`);

      console.log(`✅ ${iterations} конфигов успешно сгенерированы и сохранены`);
    });
  });

  // ============================================================
  // ТЕСТ 7: Кросс-платформенная совместимость
  // ============================================================
  describe('Кросс-платформенная совместимость', () => {
    it('должен корректно обрабатывать пути в разных ОС', async () => {
      // Проверяем работу с путями в стиле Unix и Windows
      const unixPath = '/home/user/config.json';
      const winPath = 'C:\\Users\\user\\config.json';
      const relativePath = './config.json';

      // Генерируем конфиг
      const ptr = moduleInstance._generate_config_json();
      const jsonContent = moduleInstance.UTF8ToString(ptr);
      moduleInstance._free_config_string(ptr);

      // Пробуем сохранить с разными путями
      const testPaths = [unixPath, winPath, relativePath];

      for (const testPath of testPaths) {
        // Используем path.join для нормализации
        const normalizedPath = join(__dirname, '..', testPath.replace(/^[A-Za-z]:\\/, ''));
        const safePath = join(OUTPUT_DIR, path.basename(testPath));

        await fs.writeFile(safePath, jsonContent);
        const stat = await fs.stat(safePath);
        assert.ok(stat.size > 0, `Файл должен быть создан для пути: ${testPath}`);

        // Очищаем
        await fs.unlink(safePath);
      }

      console.log('✅ Пути разных ОС корректно обрабатываются');
    });

    it('должен генерировать переносимые строки (LF)', () => {
      const ptr = moduleInstance._generate_config_json();
      const jsonContent = moduleInstance.UTF8ToString(ptr);
      moduleInstance._free_config_string(ptr);

      // Проверяем что строки используют LF (Unix) или хотя бы последовательны
      const hasCRLF = jsonContent.includes('\r\n');
      const hasLF = jsonContent.includes('\n') && !jsonContent.includes('\r');

      // В идеале должны быть LF, но допускаем любой вариант
      assert.ok(hasLF || hasCRLF, 'Строки должны иметь переносы (LF или CRLF)');

      console.log('✅ Переносы строк корректны для разных платформ');
    });
  });

  console.log('✅ Все интеграционные тесты завершены');
});

// Экспортируем для использования в других тестах
export { moduleInstance, ConfigGenerator, OUTPUT_DIR };
