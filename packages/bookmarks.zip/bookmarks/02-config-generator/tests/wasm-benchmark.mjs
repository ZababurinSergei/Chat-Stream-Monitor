// tests/wasm-benchmark.mjs - Бенчмарки производительности WASM модуля
// Полный набор тестов производительности с детальной статистикой
// Все описания на русском языке

import { describe, it, before, after, assert } from 'node:test';
import { strict as assert } from 'node:assert';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
import fs from 'node:fs/promises';

const __dirname = dirname(fileURLToPath(import.meta.url));

describe('🚀 Бенчмарки производительности WASM модуля', () => {
  let moduleInstance = null;
  let ConfigGenerator = null;
  const WASM_PATH = join(__dirname, '../web/config_generator.mjs');
  const BENCHMARK_DIR = join(__dirname, 'fixtures/benchmarks');

  // ============================================================
  // ПОДГОТОВКА
  // ============================================================
  before(async () => {
    console.log('\n📦 Загрузка WASM модуля для бенчмарков...');

    try {
      const module = await import(WASM_PATH);
      ConfigGenerator = module.default;

      moduleInstance = await ConfigGenerator({
        print: () => {}, // Отключаем вывод для чистоты измерений
        printErr: () => {}
      });

      // Создаем директорию для результатов
      await fs.mkdir(BENCHMARK_DIR, { recursive: true });

      console.log('✅ WASM модуль загружен');
      console.log('📁 Результаты будут сохранены в:', BENCHMARK_DIR);
    } catch (error) {
      console.error('❌ Ошибка загрузки WASM:', error);
      throw error;
    }
  });

  // ============================================================
  // ОЧИСТКА ПОСЛЕ ТЕСТОВ
  // ============================================================
  after(async () => {
    console.log('\n🧹 Очистка после бенчмарков...');
    // Сохраняем сводку результатов
    await saveBenchmarkSummary();
  });

  // ============================================================
  // ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ
  // ============================================================

  /**
   * Измеряет время выполнения функции
   * @param {Function} fn - Функция для измерения
   * @param {number} iterations - Количество итераций
   * @param {string} name - Название теста
   * @returns {Object} Результаты измерений
   */
  function measure(fn, iterations = 1000, name = 'unknown') {
    // Прогрев
    for (let i = 0; i < 10; i++) {
      fn();
    }

    // Основной замер
    const start = performance.now();
    const results = [];
    const errors = [];

    for (let i = 0; i < iterations; i++) {
      try {
        const result = fn();
        if (result !== undefined && result !== null) {
          results.push(result);
        }
      } catch (error) {
        errors.push({
          iteration: i,
          error: error.message
        });
      }
    }

    const end = performance.now();
    const totalTime = end - start;
    const avgTime = totalTime / iterations;
    const opsPerSecond = iterations / (totalTime / 1000);

    // Статистика
    const sortedResults = [...results].sort((a, b) => a - b);
    const min = sortedResults[0] || 0;
    const max = sortedResults[sortedResults.length - 1] || 0;
    const median = sortedResults[Math.floor(sortedResults.length / 2)] || 0;

    // Вычисляем стандартное отклонение
    const mean = results.reduce((sum, val) => sum + val, 0) / (results.length || 1);
    const variance = results.reduce((sum, val) => sum + Math.pow(val - mean, 2), 0) / (results.length || 1);
    const stdDev = Math.sqrt(variance);

    return {
      name,
      iterations,
      totalTime,
      avgTime,
      opsPerSecond,
      results: {
        count: results.length,
        errors: errors.length,
        min,
        max,
        median,
        mean,
        stdDev
      },
      errors
    };
  }

  /**
   * Форматирует время в человеко-читаемый формат
   */
  function formatTime(ms) {
    if (ms < 1) return `${(ms * 1000).toFixed(2)}μs`;
    if (ms < 1000) return `${ms.toFixed(2)}ms`;
    return `${(ms / 1000).toFixed(2)}s`;
  }

  /**
   * Сохраняет результаты бенчмарка в файл
   */
  async function saveBenchmarkResults(name, results) {
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const filename = `${name}-${timestamp}.json`;
    const filepath = join(BENCHMARK_DIR, filename);

    const data = {
      timestamp: new Date().toISOString(),
      name,
      ...results,
      environment: {
        nodeVersion: process.version,
        platform: process.platform,
        arch: process.arch,
        memory: process.memoryUsage()
      }
    };

    await fs.writeFile(filepath, JSON.stringify(data, null, 2));
    return filepath;
  }

  /**
   * Сохраняет сводку всех бенчмарков
   */
  async function saveBenchmarkSummary() {
    const summary = {
      timestamp: new Date().toISOString(),
      nodeVersion: process.version,
      platform: process.platform,
      arch: process.arch,
      benchmarks: global.__benchmarkResults || {}
    };

    const filepath = join(BENCHMARK_DIR, 'benchmark-summary.json');
    await fs.writeFile(filepath, JSON.stringify(summary, null, 2));
    console.log(`📊 Сводка сохранена: ${filepath}`);
  }

  // Глобальный объект для хранения результатов
  global.__benchmarkResults = global.__benchmarkResults || {};

  // ============================================================
  // 1. БЕНЧМАРК ГЕНЕРАЦИИ JSON
  // ============================================================
  describe('📄 Генерация JSON', () => {
    it('должна генерировать JSON за разумное время (1000 итераций)', async () => {
      const result = measure(() => {
        const ptr = moduleInstance._generate_config_json();
        const json = moduleInstance.UTF8ToString(ptr);
        moduleInstance._free_config_string(ptr);
        return json.length;
      }, 1000, 'json-generation');

      console.log('\n📊 Результаты генерации JSON:');
      console.log(`   🔄 Итераций: ${result.iterations}`);
      console.log(`   ⏱️  Общее время: ${formatTime(result.totalTime)}`);
      console.log(`   ⚡ Среднее время: ${formatTime(result.avgTime)}`);
      console.log(`   🚀 Пропускная способность: ${result.opsPerSecond.toFixed(1)} ops/sec`);
      console.log(`   📏 Средний размер: ${(result.results.mean / 1024).toFixed(2)} KB`);
      console.log(`   📏 Мин. размер: ${(result.results.min / 1024).toFixed(2)} KB`);
      console.log(`   📏 Макс. размер: ${(result.results.max / 1024).toFixed(2)} KB`);
      console.log(`   📊 Стандартное отклонение: ${(result.results.stdDev / 1024).toFixed(2)} KB`);

      // Сохраняем результаты
      const filepath = await saveBenchmarkResults('json-generation', result);
      console.log(`   💾 Результаты сохранены: ${filepath}`);

      global.__benchmarkResults.json = result;

      // Проверяем что среднее время разумное (< 50ms)
      assert.ok(
        result.avgTime < 50,
        `Среднее время ${formatTime(result.avgTime)} должно быть < 50ms`
      );
    });

    it('должна генерировать JSON с разными размерами (10000 итераций)', function(done) {
      // Этот тест может быть медленным, увеличиваем таймаут
      this.timeout(30000);

      const result = measure(() => {
        const ptr = moduleInstance._generate_config_json();
        const json = moduleInstance.UTF8ToString(ptr);
        moduleInstance._free_config_string(ptr);
        return json.length;
      }, 10000, 'json-generation-large');

      console.log(`\n📊 Генерация JSON (10000 итераций):`);
      console.log(`   ⏱️  Общее время: ${formatTime(result.totalTime)}`);
      console.log(`   ⚡ Среднее время: ${formatTime(result.avgTime)}`);
      console.log(`   🚀 Пропускная способность: ${result.opsPerSecond.toFixed(1)} ops/sec`);
      console.log(`   📊 Стандартное отклонение: ${result.results.stdDev.toFixed(2)}`);

      global.__benchmarkResults.jsonLarge = result;

      // Проверяем что нет ошибок
      assert.strictEqual(
        result.results.errors,
        0,
        `Не должно быть ошибок (было ${result.results.errors})`
      );

      done();
    });

    it('должна генерировать валидный JSON без потери данных', () => {
      const result = measure(() => {
        const ptr = moduleInstance._generate_config_json();
        const json = moduleInstance.UTF8ToString(ptr);
        moduleInstance._free_config_string(ptr);

        // Проверяем валидность JSON
        try {
          const parsed = JSON.parse(json);
          return parsed.version || 'unknown';
        } catch {
          return null;
        }
      }, 100, 'json-validity');

      // Проверяем что все результаты валидны
      const invalidResults = result.results.count - (result.results.count - result.results.errors);
      assert.strictEqual(
        invalidResults,
        0,
        'Все сгенерированные JSON должны быть валидными'
      );
    });
  });

  // ============================================================
  // 2. БЕНЧМАРК ГЕНЕРАЦИИ C HEADER
  // ============================================================
  describe('⚡ Генерация C Header', () => {
    it('должна генерировать C header за разумное время (1000 итераций)', () => {
      const result = measure(() => {
        const ptr = moduleInstance._generate_config_c();
        const header = moduleInstance.UTF8ToString(ptr);
        moduleInstance._free_config_string(ptr);
        return header.length;
      }, 1000, 'c-header-generation');

      console.log('\n📊 Результаты генерации C Header:');
      console.log(`   🔄 Итераций: ${result.iterations}`);
      console.log(`   ⏱️  Общее время: ${formatTime(result.totalTime)}`);
      console.log(`   ⚡ Среднее время: ${formatTime(result.avgTime)}`);
      console.log(`   🚀 Пропускная способность: ${result.opsPerSecond.toFixed(1)} ops/sec`);
      console.log(`   📏 Средний размер: ${(result.results.mean / 1024).toFixed(2)} KB`);

      const filepath = await saveBenchmarkResults('c-header-generation', result);
      console.log(`   💾 Результаты сохранены: ${filepath}`);

      global.__benchmarkResults.cHeader = result;

      assert.ok(
        result.avgTime < 30,
        `Среднее время ${formatTime(result.avgTime)} должно быть < 30ms`
      );
    });

    it('должна генерировать корректный C header с include guards', () => {
      const result = measure(() => {
        const ptr = moduleInstance._generate_config_c();
        const header = moduleInstance.UTF8ToString(ptr);
        moduleInstance._free_config_string(ptr);

        // Проверяем наличие ключевых элементов
        const hasIncludeGuard = header.includes('#ifndef CONFIG_H');
        const hasDefine = header.includes('#define CONFIG_H');
        const hasEndif = header.includes('#endif // CONFIG_H');
        const hasStructs = header.includes('typedef struct');

        return {
          valid: hasIncludeGuard && hasDefine && hasEndif && hasStructs,
          length: header.length
        };
      }, 100, 'c-header-validity');

      // Проверяем что все заголовки валидны
      const invalidHeaders = result.results.count - (result.results.count - result.results.errors);
      assert.strictEqual(
        invalidHeaders,
        0,
        'Все сгенерированные C header должны быть валидными'
      );
    });
  });

  // ============================================================
  // 3. БЕНЧМАРК ГЕНЕРАЦИИ ENV
  // ============================================================
  describe('🌍 Генерация ENV', () => {
    it('должна генерировать .env за разумное время (1000 итераций)', () => {
      const result = measure(() => {
        const ptr = moduleInstance._generate_config_env();
        const env = moduleInstance.UTF8ToString(ptr);
        moduleInstance._free_config_string(ptr);
        return env.length;
      }, 1000, 'env-generation');

      console.log('\n📊 Результаты генерации ENV:');
      console.log(`   🔄 Итераций: ${result.iterations}`);
      console.log(`   ⏱️  Общее время: ${formatTime(result.totalTime)}`);
      console.log(`   ⚡ Среднее время: ${formatTime(result.avgTime)}`);
      console.log(`   🚀 Пропускная способность: ${result.opsPerSecond.toFixed(1)} ops/sec`);
      console.log(`   📏 Средний размер: ${(result.results.mean / 1024).toFixed(2)} KB`);

      const filepath = await saveBenchmarkResults('env-generation', result);
      console.log(`   💾 Результаты сохранены: ${filepath}`);

      global.__benchmarkResults.env = result;

      assert.ok(
        result.avgTime < 20,
        `Среднее время ${formatTime(result.avgTime)} должно быть < 20ms`
      );
    });

    it('должна генерировать корректный .env с ключевыми переменными', () => {
      const result = measure(() => {
        const ptr = moduleInstance._generate_config_env();
        const env = moduleInstance.UTF8ToString(ptr);
        moduleInstance._free_config_string(ptr);

        // Проверяем наличие ключевых переменных
        const hasWorkspace = env.includes('WORKSPACE_NAME=');
        const hasBroker = env.includes('BROKER_HOST=');
        const hasNamespace = env.includes('NAMESPACE_BASE=');
        const hasCrypto = env.includes('CRYPTO_TYPE=');

        return {
          valid: hasWorkspace && hasBroker && hasNamespace && hasCrypto,
          length: env.length
        };
      }, 100, 'env-validity');

      assert.strictEqual(
        result.results.errors,
        0,
        'Все сгенерированные .env должны быть валидными'
      );
    });
  });

  // ============================================================
  // 4. БЕНЧМАРК УПРАВЛЕНИЯ ПАМЯТЬЮ
  // ============================================================
  describe('🧠 Управление памятью', () => {
    it('не должна иметь утечек памяти при многократной генерации', function(done) {
      this.timeout(60000);

      const iterations = 10000;
      const initialMemory = process.memoryUsage().heapUsed;

      console.log(`\n🧠 Тест утечек памяти (${iterations} итераций)...`);

      // Запоминаем указатели для проверки
      const pointers = [];

      const start = performance.now();
      for (let i = 0; i < iterations; i++) {
        const ptr = moduleInstance._generate_config_json();
        pointers.push(ptr);

        // Освобождаем каждую 10-ю для проверки
        if (i % 10 === 0) {
          moduleInstance._free_config_string(ptr);
        }
      }

      // Освобождаем оставшиеся
      for (const ptr of pointers) {
        moduleInstance._free_config_string(ptr);
      }

      const end = performance.now();
      const totalTime = end - start;

      // Даем время на GC
      if (global.gc) {
        global.gc();
      }

      const finalMemory = process.memoryUsage().heapUsed;
      const memoryGrowth = finalMemory - initialMemory;

      console.log(`   ⏱️  Время выполнения: ${formatTime(totalTime)}`);
      console.log(`   📊 Рост памяти: ${(memoryGrowth / 1024 / 1024).toFixed(2)} MB`);
      console.log(`   📊 Итераций: ${iterations}`);

      // Сохраняем результат
      const result = {
        name: 'memory-leak-test',
        iterations,
        totalTime,
        memoryGrowth,
        initialMemory,
        finalMemory
      };

      const filepath = await saveBenchmarkResults('memory-leak-test', result);
      console.log(`   💾 Результаты сохранены: ${filepath}`);

      // Допускаем рост памяти до 50MB
      assert.ok(
        memoryGrowth < 50 * 1024 * 1024,
        `Рост памяти (${(memoryGrowth / 1024 / 1024).toFixed(2)}MB) должен быть < 50MB`
      );

      global.__benchmarkResults.memory = result;
      done();
    });

    it('должна эффективно освобождать память', () => {
      // Проверяем что освобождение не блокирует выполнение
      const result = measure(() => {
        const ptr = moduleInstance._generate_config_json();
        const json = moduleInstance.UTF8ToString(ptr);
        moduleInstance._free_config_string(ptr);
        return json.length;
      }, 1000, 'memory-free');

      // Проверяем что скорость не падает со временем
      const first100 = result.results.mean;

      // Сравниваем с предыдущим тестом
      if (global.__benchmarkResults.json) {
        const previous = global.__benchmarkResults.json;
        const diff = Math.abs(result.avgTime - previous.avgTime);
        const diffPercent = (diff / previous.avgTime) * 100;

        console.log(`   📊 Разница с предыдущим тестом: ${diffPercent.toFixed(2)}%`);

        // Допускаем отклонение до 20%
        assert.ok(
          diffPercent < 20,
          `Отклонение времени (${diffPercent.toFixed(2)}%) должно быть < 20%`
        );
      }
    });
  });

  // ============================================================
  // 5. БЕНЧМАРК СТАБИЛЬНОСТИ
  // ============================================================
  describe('🔒 Стабильность', () => {
    it('должна работать стабильно при длительной нагрузке', function(done) {
      this.timeout(120000);

      const iterations = 50000;
      console.log(`\n🔒 Тест стабильности (${iterations} итераций)...`);

      const errors = [];
      const start = performance.now();
      let lastProgress = 0;

      for (let i = 0; i < iterations; i++) {
        try {
          const ptr = moduleInstance._generate_config_json();
          const json = moduleInstance.UTF8ToString(ptr);
          moduleInstance._free_config_string(ptr);

          // Проверяем валидность каждую 100-ю
          if (i % 100 === 0) {
            JSON.parse(json);
          }

          // Прогресс
          const progress = Math.floor((i / iterations) * 100);
          if (progress > lastProgress + 9) {
            lastProgress = progress;
            console.log(`   Прогресс: ${progress}%`);
          }
        } catch (error) {
          errors.push({
            iteration: i,
            error: error.message
          });
        }
      }

      const end = performance.now();
      const totalTime = end - start;

      console.log(`\n📊 Результаты теста стабильности:`);
      console.log(`   ✅ Успешных итераций: ${iterations - errors.length}`);
      console.log(`   ❌ Ошибок: ${errors.length}`);
      console.log(`   ⏱️  Общее время: ${formatTime(totalTime)}`);
      console.log(`   ⚡ Среднее время: ${formatTime(totalTime / iterations)}`);

      if (errors.length > 0) {
        console.log(`   📋 Первые 5 ошибок:`);
        errors.slice(0, 5).forEach(e => {
          console.log(`      - Итерация ${e.iteration}: ${e.error}`);
        });
      }

      // Сохраняем результат
      const result = {
        name: 'stability-test',
        iterations,
        totalTime,
        errors: errors.length,
        errorDetails: errors.slice(0, 100) // Сохраняем первые 100 ошибок
      };

      const filepath = await saveBenchmarkResults('stability-test', result);
      console.log(`   💾 Результаты сохранены: ${filepath}`);

      global.__benchmarkResults.stability = result;

      // Допускаем не более 1% ошибок
      const errorRate = (errors.length / iterations) * 100;
      assert.ok(
        errorRate < 1,
        `Процент ошибок (${errorRate.toFixed(2)}%) должен быть < 1%`
      );

      done();
    });
  });

  // ============================================================
  // 6. СРАВНИТЕЛЬНЫЙ БЕНЧМАРК
  // ============================================================
  describe('📊 Сравнительный анализ', () => {
    it('должна показывать стабильную производительность между запусками', () => {
      console.log('\n📊 Сравнительный анализ производительности:');

      const benchmarks = global.__benchmarkResults;
      const keys = Object.keys(benchmarks);

      if (keys.length < 2) {
        console.log('   ⚠️ Недостаточно данных для сравнения');
        return;
      }

      // Сравниваем JSON генерацию
      if (benchmarks.json && benchmarks.jsonLarge) {
        const small = benchmarks.json;
        const large = benchmarks.jsonLarge;

        console.log(`\n   📄 JSON генерация:`);
        console.log(`      Маленький тест (${small.iterations}): ${formatTime(small.avgTime)}`);
        console.log(`      Большой тест (${large.iterations}): ${formatTime(large.avgTime)}`);
        console.log(`      Разница: ${((large.avgTime / small.avgTime) * 100 - 100).toFixed(1)}%`);
      }

      // Сравниваем разные форматы
      const formats = ['json', 'cHeader', 'env'];
      const formatNames = {
        json: 'JSON',
        cHeader: 'C Header',
        env: 'ENV'
      };

      console.log(`\n   📊 Сравнение форматов:`);
      for (const key of formats) {
        if (benchmarks[key]) {
          const data = benchmarks[key];
          console.log(`      ${formatNames[key]}: ${formatTime(data.avgTime)} (${data.opsPerSecond.toFixed(1)} ops/sec)`);
        }
      }
    });
  });

  // ============================================================
  // 7. ДОПОЛНИТЕЛЬНЫЙ БЕНЧМАРК: ПАРСИНГ JSON
  // ============================================================
  describe('🔍 Парсинг JSON', () => {
    it('должна эффективно парсить сгенерированный JSON', () => {
      // Сначала генерируем JSON
      const ptr = moduleInstance._generate_config_json();
      const jsonString = moduleInstance.UTF8ToString(ptr);
      moduleInstance._free_config_string(ptr);

      const result = measure(() => {
        return JSON.parse(jsonString);
      }, 1000, 'json-parsing');

      console.log('\n📊 Результаты парсинга JSON:');
      console.log(`   🔄 Итераций: ${result.iterations}`);
      console.log(`   ⏱️  Общее время: ${formatTime(result.totalTime)}`);
      console.log(`   ⚡ Среднее время: ${formatTime(result.avgTime)}`);
      console.log(`   🚀 Пропускная способность: ${result.opsPerSecond.toFixed(1)} ops/sec`);

      const filepath = await saveBenchmarkResults('json-parsing', result);
      console.log(`   💾 Результаты сохранены: ${filepath}`);

      global.__benchmarkResults.jsonParsing = result;

      // Парсинг должен быть быстрым
      assert.ok(
        result.avgTime < 5,
        `Среднее время парсинга ${formatTime(result.avgTime)} должно быть < 5ms`
      );
    });
  });

  // ============================================================
  // 8. БЕНЧМАРК: ПАРАЛЛЕЛЬНАЯ ГЕНЕРАЦИЯ (ЭМУЛЯЦИЯ)
  // ============================================================
  describe('🔄 Параллельная генерация', () => {
    it('должна работать с имитацией параллельной нагрузки', function(done) {
      this.timeout(30000);

      const concurrent = 10;
      const iterationsPerThread = 100;
      const totalIterations = concurrent * iterationsPerThread;

      console.log(`\n🔄 Параллельная генерация:`);
      console.log(`   🧵 Потоков: ${concurrent}`);
      console.log(`   📦 Итераций на поток: ${iterationsPerThread}`);
      console.log(`   📊 Всего операций: ${totalIterations}`);

      const start = performance.now();
      const promises = [];

      for (let t = 0; t < concurrent; t++) {
        const threadId = t;
        promises.push(new Promise((resolve) => {
          const results = [];
          for (let i = 0; i < iterationsPerThread; i++) {
            try {
              const ptr = moduleInstance._generate_config_json();
              const json = moduleInstance.UTF8ToString(ptr);
              moduleInstance._free_config_string(ptr);
              results.push(json.length);
            } catch (error) {
              results.push(-1);
            }
          }
          resolve({
            threadId,
            results,
            errors: results.filter(r => r === -1).length
          });
        }));
      }

      const allResults = await Promise.all(promises);
      const end = performance.now();
      const totalTime = end - start;

      const totalErrors = allResults.reduce((sum, r) => sum + r.errors, 0);
      const avgTimePerOp = totalTime / totalIterations;

      console.log(`\n📊 Результаты параллельной генерации:`);
      console.log(`   ⏱️  Общее время: ${formatTime(totalTime)}`);
      console.log(`   ⚡ Среднее время на операцию: ${formatTime(avgTimePerOp)}`);
      console.log(`   ✅ Успешных операций: ${totalIterations - totalErrors}`);
      console.log(`   ❌ Ошибок: ${totalErrors}`);
      console.log(`   🚀 Общая пропускная способность: ${(totalIterations / (totalTime / 1000)).toFixed(1)} ops/sec`);

      // Проверяем ошибки
      assert.strictEqual(
        totalErrors,
        0,
        `Не должно быть ошибок при параллельной генерации (было ${totalErrors})`
      );

      done();
    });
  });

  // ============================================================
  // 9. ФИНАЛЬНАЯ СТАТИСТИКА
  // ============================================================
  console.log('\n' + '═'.repeat(60));
  console.log('📊 ИТОГОВАЯ СТАТИСТИКА БЕНЧМАРКОВ');
  console.log('═'.repeat(60));

  // Выводим сводку всех бенчмарков
  const summary = global.__benchmarkResults;
  const formatNames = {
    json: 'JSON генерация',
    jsonLarge: 'JSON генерация (10k)',
    jsonParsing: 'JSON парсинг',
    cHeader: 'C Header',
    env: 'ENV',
    memory: 'Управление памятью',
    stability: 'Стабильность'
  };

  for (const [key, data] of Object.entries(summary)) {
    if (data.avgTime) {
      console.log(`\n📌 ${formatNames[key] || key}:`);
      console.log(`   ⚡ Среднее время: ${formatTime(data.avgTime)}`);
      console.log(`   🚀 Пропускная способность: ${data.opsPerSecond?.toFixed(1) || 'N/A'} ops/sec`);
      if (data.results) {
        console.log(`   📏 Размер: ${(data.results.mean / 1024).toFixed(2)} KB (средний)`);
      }
    }
  }

  console.log('\n' + '═'.repeat(60));
  console.log('✅ Все бенчмарки завершены!');
  console.log(`📁 Результаты сохранены в: ${BENCHMARK_DIR}`);
  console.log('═'.repeat(60) + '\n');
});

// ============================================================
// ЭКСПОРТ ДЛЯ ИСПОЛЬЗОВАНИЯ В ДРУГИХ ТЕСТАХ
// ============================================================
export { moduleInstance, ConfigGenerator, measure, formatTime, BENCHMARK_DIR };
