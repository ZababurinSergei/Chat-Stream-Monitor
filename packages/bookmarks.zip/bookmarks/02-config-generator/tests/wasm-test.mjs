// tests/wasm-test.mjs
// Основные тесты WASM модуля Config Generator

import { describe, it, before, after } from 'node:test';
import * as assertModule from 'node:assert';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const __dirname = dirname(fileURLToPath(import.meta.url));
const assert = assertModule.strict;

// Конфигурация для загрузки WASM
const WASM_PATH = join(__dirname, '../web/config_generator.mjs');

let ConfigGenerator = null;
let moduleInstance = null;

// Вспомогательные функции
function isJSON(str) {
  try {
    JSON.parse(str);
    return true;
  } catch {
    return false;
  }
}

function isValidCHeader(str) {
  return str.includes('#ifndef') && str.includes('#define') && str.includes('#endif');
}

function isValidEnv(str) {
  return str.includes('=') && str.includes('WORKSPACE_NAME') && str.includes('BROKER_HOST');
}

describe('WASM Config Generator - Основные тесты', () => {
  // Подготовка - загрузка модуля
  before(async () => {
    try {
      // Динамический импорт ESM модуля
      const module = await import(WASM_PATH);
      ConfigGenerator = module.default;

      // Создаем инстанс с дефолтными настройками
      moduleInstance = await ConfigGenerator({
        print: text => console.log(`[WASM stdout] ${text}`),
        printErr: text => console.error(`[WASM stderr] ${text}`),
        onRuntimeInitialized: () => {
          console.log('✅ WASM Runtime инициализирован');
        },
      });

      assert.ok(moduleInstance, 'Модуль должен быть загружен');
      console.log('✅ WASM модуль успешно загружен');
    } catch (error) {
      console.error('❌ Ошибка загрузки WASM модуля:', error);
      throw error;
    }
  });

  // Очистка после тестов
  after(async () => {
    console.log('🧹 Очистка после тестов...');
    if (moduleInstance && moduleInstance._free_config_string) {
      console.log('✅ Ресурсы освобождены');
    }
  });

  // ============================================================
  // ТЕСТ 1: Загрузка модуля и экспорты
  // ============================================================
  describe('Загрузка модуля', () => {
    it('должен иметь все необходимые экспорты', () => {
      const requiredExports = [
        '_generate_config_json',
        '_generate_config_c',
        '_generate_config_env',
        '_free_config_string',
      ];

      for (const exportName of requiredExports) {
        assert.ok(moduleInstance[exportName], `Отсутствует экспорт: ${exportName}`);
      }
      console.log('✅ Все экспорты присутствуют');
    });

    it('должен иметь доступ к памяти', () => {
      assert.ok(moduleInstance.HEAPU8 || moduleInstance.memory, 'Память должна быть доступна');
      console.log('✅ Доступ к памяти есть');
    });
  });

  // ============================================================
  // ТЕСТ 2: Генерация JSON
  // ============================================================
  describe('Генерация JSON', () => {
    it('должен генерировать валидный JSON', () => {
      const ptr = moduleInstance._generate_config_json();
      assert.ok(ptr > 0, 'Должен вернуть валидный указатель');

      const jsonString = moduleInstance.UTF8ToString(ptr);
      assert.ok(jsonString, 'Должен вернуть непустую строку');
      assert.ok(isJSON(jsonString), 'Должен быть валидный JSON');

      // Проверяем структуру JSON
      const config = JSON.parse(jsonString);
      assert.ok(config.version, 'Должна быть версия');
      assert.ok(config.workspace, 'Должен быть workspace');
      assert.ok(config.broker, 'Должна быть конфигурация брокера');
      assert.ok(config.namespace, 'Должен быть namespace');
      assert.ok(Array.isArray(config.nodes), 'Должен быть массив узлов');

      console.log(`✅ JSON сгенерирован, размер: ${jsonString.length} символов`);

      // Освобождаем память
      moduleInstance._free_config_string(ptr);
    });

    it('должен генерировать случайные конфиги при каждом вызове', () => {
      const ptr1 = moduleInstance._generate_config_json();
      const json1 = moduleInstance.UTF8ToString(ptr1);
      moduleInstance._free_config_string(ptr1);

      const ptr2 = moduleInstance._generate_config_json();
      const json2 = moduleInstance.UTF8ToString(ptr2);
      moduleInstance._free_config_string(ptr2);

      // Конфиги должны быть разными (случайная генерация)
      const config1 = JSON.parse(json1);
      const config2 = JSON.parse(json2);

      // Проверяем, что города или узлы разные
      const hasDifferentCities = JSON.stringify(config1.cities) !== JSON.stringify(config2.cities);
      const hasDifferentNodes = JSON.stringify(config1.nodes) !== JSON.stringify(config2.nodes);

      assert.ok(
        hasDifferentCities || hasDifferentNodes,
        'Конфиги должны быть разными (случайная генерация)'
      );

      console.log('✅ Конфиги разные (случайная генерация работает)');
    });

    it('должен генерировать конфиг как минимум с одним городом', () => {
      const ptr = moduleInstance._generate_config_json();
      const jsonString = moduleInstance.UTF8ToString(ptr);
      moduleInstance._free_config_string(ptr);

      const config = JSON.parse(jsonString);
      assert.ok(Object.keys(config.cities || {}).length > 0, 'Должен быть как минимум один город');

      console.log(`✅ Городов: ${Object.keys(config.cities).length}`);
    });

    it('должен генерировать конфиг с настройками брокера', () => {
      const ptr = moduleInstance._generate_config_json();
      const jsonString = moduleInstance.UTF8ToString(ptr);
      moduleInstance._free_config_string(ptr);

      const config = JSON.parse(jsonString);
      assert.ok(config.broker.host, 'Должен быть хост брокера');
      assert.ok(config.broker.port > 0, 'Должен быть порт брокера');
      assert.ok(config.broker.username, 'Должно быть имя пользователя брокера');

      console.log(`✅ Брокер: ${config.broker.host}:${config.broker.port}`);
    });
  });

  // ============================================================
  // ТЕСТ 3: Генерация C Header
  // ============================================================
  describe('Генерация C заголовка', () => {
    it('должен генерировать валидный C заголовок', () => {
      const ptr = moduleInstance._generate_config_c();
      assert.ok(ptr > 0, 'Должен вернуть валидный указатель');

      const header = moduleInstance.UTF8ToString(ptr);
      assert.ok(header, 'Должен вернуть непустой заголовок');
      assert.ok(isValidCHeader(header), 'Должен быть валидный C заголовок');

      // Проверяем наличие ключевых макросов
      assert.ok(header.includes('#define WORKSPACE_NAME'), 'Должен быть макрос WORKSPACE_NAME');
      assert.ok(header.includes('#define BROKER_HOST'), 'Должен быть макрос BROKER_HOST');
      assert.ok(header.includes('#define NAMESPACE_BASE'), 'Должен быть макрос NAMESPACE_BASE');

      console.log(`✅ C заголовок сгенерирован, размер: ${header.length} символов`);
      moduleInstance._free_config_string(ptr);
    });

    it('должен генерировать заголовок с защитой от повторного включения', () => {
      const ptr = moduleInstance._generate_config_c();
      const header = moduleInstance.UTF8ToString(ptr);
      moduleInstance._free_config_string(ptr);

      assert.ok(header.includes('#ifndef CONFIG_H'), 'Должна быть защита от повторного включения');
      assert.ok(header.includes('#define CONFIG_H'), 'Должно быть определение защиты');
      assert.ok(header.includes('#endif // CONFIG_H'), 'Должно быть закрытие защиты');

      console.log('✅ Защита от повторного включения присутствует');
    });

    it('должен генерировать заголовок с определениями структур', () => {
      const ptr = moduleInstance._generate_config_c();
      const header = moduleInstance.UTF8ToString(ptr);
      moduleInstance._free_config_string(ptr);

      const requiredStructs = ['city_t', 'rule_t', 'test_node_t', 'test_node_position_t'];

      for (const structName of requiredStructs) {
        assert.ok(
          header.includes(`typedef struct {`),
          `Должно быть определение структуры ${structName}`
        );
      }

      console.log('✅ Все структуры определены');
    });
  });

  // ============================================================
  // ТЕСТ 4: Генерация ENV
  // ============================================================
  describe('Генерация ENV файла', () => {
    it('должен генерировать валидный .env файл', () => {
      const ptr = moduleInstance._generate_config_env();
      assert.ok(ptr > 0, 'Должен вернуть валидный указатель');

      const envContent = moduleInstance.UTF8ToString(ptr);
      assert.ok(envContent, 'Должен вернуть непустое содержимое');
      assert.ok(isValidEnv(envContent), 'Должен быть валидный .env формат');

      // Проверяем наличие ключевых переменных
      const requiredVars = [
        'WORKSPACE_NAME=',
        'BROKER_HOST=',
        'BROKER_PORT=',
        'NAMESPACE_BASE=',
        'MAX_HOPS=',
      ];

      for (const varName of requiredVars) {
        assert.ok(envContent.includes(varName), `Должна быть переменная ${varName}`);
      }

      console.log(`✅ ENV файл сгенерирован, размер: ${envContent.length} символов`);
      moduleInstance._free_config_string(ptr);
    });

    it('должен генерировать env с настройками криптографии', () => {
      const ptr = moduleInstance._generate_config_env();
      const envContent = moduleInstance.UTF8ToString(ptr);
      moduleInstance._free_config_string(ptr);

      const cryptoVars = [
        'CRYPTO_TYPE=',
        'CRYPTO_KEM=',
        'CRYPTO_SIGNATURE=',
        'ENCRYPTION_ENABLED=',
      ];

      for (const varName of cryptoVars) {
        assert.ok(envContent.includes(varName), `Должна быть переменная ${varName}`);
      }

      console.log('✅ Криптографические настройки присутствуют');
    });

    it('должен генерировать env с комментариями', () => {
      const ptr = moduleInstance._generate_config_env();
      const envContent = moduleInstance.UTF8ToString(ptr);
      moduleInstance._free_config_string(ptr);

      assert.ok(envContent.includes('#'), 'Должны быть комментарии в .env файле');
      assert.ok(envContent.includes('Generated:'), 'Должна быть временная метка генерации');

      console.log('✅ Комментарии присутствуют');
    });
  });

  // ============================================================
  // ТЕСТ 5: Валидация структуры данных
  // ============================================================
  describe('Валидация структуры данных', () => {
    it('должен генерировать конфиг с валидными кодами городов', () => {
      const ptr = moduleInstance._generate_config_json();
      const jsonString = moduleInstance.UTF8ToString(ptr);
      moduleInstance._free_config_string(ptr);

      const config = JSON.parse(jsonString);
      const cities = config.cities || {};

      for (const [code, city] of Object.entries(cities)) {
        assert.ok(code.length === 3, `Код города "${code}" должен быть из 3 символов`);
        assert.ok(/^[A-Z]+$/.test(code), `Код города "${code}" должен быть заглавными буквами`);
        assert.ok(city.name && city.name.length > 0, `Город "${code}" должен иметь название`);
      }

      console.log(`✅ Валидных городов: ${Object.keys(cities).length}`);
    });

    it('должен генерировать конфиг с валидной структурой узлов', () => {
      const ptr = moduleInstance._generate_config_json();
      const jsonString = moduleInstance.UTF8ToString(ptr);
      moduleInstance._free_config_string(ptr);

      const config = JSON.parse(jsonString);
      const nodes = config.nodes || [];

      for (const node of nodes) {
        assert.ok(node.id, 'Узел должен иметь id');
        assert.ok(node.name, 'Узел должен иметь name');
        assert.ok(node.type, 'Узел должен иметь type');
        assert.ok(node.city, 'Узел должен иметь city');
        assert.ok(node.hop_limit > 0, 'Узел должен иметь hop_limit > 0');
        assert.ok(node.topic, 'Узел должен иметь topic');
      }

      console.log(`✅ Валидных узлов: ${nodes.length}`);
    });

    it('должен генерировать конфиг с валидными правилами маршрутизации', () => {
      const ptr = moduleInstance._generate_config_json();
      const jsonString = moduleInstance.UTF8ToString(ptr);
      moduleInstance._free_config_string(ptr);

      const config = JSON.parse(jsonString);
      const rules = config.routing?.rules || [];

      for (const rule of rules) {
        assert.ok(rule.name, 'Правило должно иметь name');
        assert.ok(rule.source, 'Правило должно иметь source');
        assert.ok(rule.target, 'Правило должно иметь target');
        assert.ok(rule.priority >= 0, 'Правило должно иметь priority >= 0');
        assert.ok(rule.qos >= 0 && rule.qos <= 2, 'Правило должно иметь валидный QoS');
      }

      console.log(`✅ Валидных правил: ${rules.length}`);
    });
  });

  // ============================================================
  // ТЕСТ 6: Производительность
  // ============================================================
  describe('Производительность', () => {
    it('должен быстро генерировать JSON (100 итераций)', function (done) {
      this.timeout(10000);

      const start = performance.now();
      const iterations = 100;
      const pointers = [];

      for (let i = 0; i < iterations; i++) {
        const ptr = moduleInstance._generate_config_json();
        pointers.push(ptr);
      }

      // Освобождаем память
      for (const ptr of pointers) {
        moduleInstance._free_config_string(ptr);
      }

      const end = performance.now();
      const timeMs = end - start;
      const avgMs = timeMs / iterations;

      console.log(`⏱️ Генерация JSON: ${iterations} итераций за ${timeMs.toFixed(2)}мс`);
      console.log(`   Среднее: ${avgMs.toFixed(2)}мс на генерацию`);

      assert.ok(
        timeMs < 5000,
        `Должен генерировать ${iterations} конфигов за 5с (заняло ${timeMs.toFixed(2)}мс)`
      );

      done();
    });

    it('должен быстро генерировать C заголовки (100 итераций)', function (done) {
      this.timeout(10000);

      const start = performance.now();
      const iterations = 100;
      const pointers = [];

      for (let i = 0; i < iterations; i++) {
        const ptr = moduleInstance._generate_config_c();
        pointers.push(ptr);
      }

      for (const ptr of pointers) {
        moduleInstance._free_config_string(ptr);
      }

      const end = performance.now();
      const timeMs = end - start;

      console.log(`⏱️ Генерация C заголовков: ${iterations} итераций за ${timeMs.toFixed(2)}мс`);

      assert.ok(
        timeMs < 5000,
        `Должен генерировать ${iterations} заголовков за 5с (заняло ${timeMs.toFixed(2)}мс)`
      );

      done();
    });

    it('должен быстро генерировать ENV файлы (100 итераций)', function (done) {
      this.timeout(10000);

      const start = performance.now();
      const iterations = 100;
      const pointers = [];

      for (let i = 0; i < iterations; i++) {
        const ptr = moduleInstance._generate_config_env();
        pointers.push(ptr);
      }

      for (const ptr of pointers) {
        moduleInstance._free_config_string(ptr);
      }

      const end = performance.now();
      const timeMs = end - start;

      console.log(`⏱️ Генерация ENV: ${iterations} итераций за ${timeMs.toFixed(2)}мс`);

      assert.ok(
        timeMs < 5000,
        `Должен генерировать ${iterations} env файлов за 5с (заняло ${timeMs.toFixed(2)}мс)`
      );

      done();
    });
  });

  // ============================================================
  // ТЕСТ 7: Краевые случаи
  // ============================================================
  describe('Краевые случаи', () => {
    it('должен генерировать конфиг с валидными интервалами', () => {
      const ptr = moduleInstance._generate_config_json();
      const jsonString = moduleInstance.UTF8ToString(ptr);
      moduleInstance._free_config_string(ptr);

      const config = JSON.parse(jsonString);
      const intervals = config.intervals || {};

      assert.ok(intervals.position_interval > 0, 'Интервал позиции должен быть положительным');
      assert.ok(
        intervals.node_info_interval > 0,
        'Интервал информации об узлах должен быть положительным'
      );
      assert.ok(intervals.initial_delay > 0, 'Начальная задержка должна быть положительной');

      console.log('✅ Все интервалы валидны');
    });

    it('должен генерировать конфиг с валидными порогами мониторинга', () => {
      const ptr = moduleInstance._generate_config_json();
      const jsonString = moduleInstance.UTF8ToString(ptr);
      moduleInstance._free_config_string(ptr);

      const config = JSON.parse(jsonString);
      const monitoring = config.monitoring || {};

      assert.ok(monitoring.interval > 0, 'Интервал мониторинга должен быть положительным');
      assert.ok(monitoring.thresholds?.latency_ms > 0, 'Порог задержки должен быть положительным');
      assert.ok(monitoring.thresholds?.error_rate_percent >= 0, 'Порог ошибок должен быть >= 0');

      console.log('✅ Все пороги мониторинга валидны');
    });

    it('должен генерировать конфиг с настройками криптографии', () => {
      const ptr = moduleInstance._generate_config_json();
      const jsonString = moduleInstance.UTF8ToString(ptr);
      moduleInstance._free_config_string(ptr);

      const config = JSON.parse(jsonString);
      const crypto = config.crypto || {};

      assert.ok(crypto.type, 'Должен быть тип криптографии');
      assert.ok(crypto.kem, 'Должен быть KEM алгоритм');
      assert.ok(crypto.signature, 'Должен быть алгоритм подписи');

      console.log(`✅ Криптография: ${crypto.type}, KEM: ${crypto.kem}`);
    });
  });

  // ============================================================
  // ТЕСТ 8: Совместимость с браузером
  // ============================================================
  describe('Совместимость с браузером', () => {
    it('должен генерировать JSON, который работает в браузере', () => {
      const ptr = moduleInstance._generate_config_json();
      const jsonString = moduleInstance.UTF8ToString(ptr);
      moduleInstance._free_config_string(ptr);

      // Эмулируем браузерный парсинг
      const config = JSON.parse(jsonString);

      // Проверяем что все значения сериализуемы в JSON
      const reSerialized = JSON.stringify(config);
      const reParsed = JSON.parse(reSerialized);

      assert.deepStrictEqual(config, reParsed, 'Конфиг должен быть полностью сериализуем в JSON');

      console.log('✅ Конфиг совместим с браузером');
    });

    it('должен обрабатывать большие конфиги в памяти браузера', () => {
      const ptr = moduleInstance._generate_config_json();
      const jsonString = moduleInstance.UTF8ToString(ptr);
      moduleInstance._free_config_string(ptr);

      const config = JSON.parse(jsonString);

      // Имитируем работу в браузере (ограниченная память)
      const sizeInBytes = new Blob([jsonString]).size;
      assert.ok(
        sizeInBytes < 10 * 1024 * 1024,
        `Размер конфига (${(sizeInBytes / 1024).toFixed(2)}KB) должен быть разумным для браузера`
      );

      console.log(`✅ Размер конфига: ${(sizeInBytes / 1024).toFixed(2)} KB`);
    });
  });
});

// Экспорт для использования в других тестах
export { moduleInstance, ConfigGenerator };

console.log('✅ tests/wasm-test.mjs загружен');
console.log('📋 Для запуска: node --test tests/wasm-test.mjs');
