# MTProto MQTT Config Generator

Генератор конфигурации для MTProto MQTT Gateway на C с компиляцией в WASM.

## 📋 Оглавление

- [📦 Возможности](#-возможности)
- [🚀 Полная компиляция и сборка](#-полная-компиляция-и-сборка)
  - [1. Компиляция нативного C приложения](#1-компиляция-нативного-c-приложения)
  - [2. Сборка WASM через Docker (рекомендуется)](#2-сборка-wasm-через-docker-рекомендуется)
  - [3. Сборка WASM через локальный Emscripten](#3-сборка-wasm-через-локальный-emscripten)
  - [4. Сборка WASM вручную через emcc](#4-сборка-wasm-вручную-через-emcc)
  - [5. Сборка через npm](#5-сборка-через-npm)
  - [6. Сборка Docker образа вручную](#6-сборка-docker-образа-вручную)
- [🚀 Генерация конфигурационных файлов](#-генерация-конфигурационных-файлов)
  - [Нативная C программа](#нативная-c-программа)
  - [Через браузер (WASM)](#через-браузер-wasm)
  - [Через Node.js (WASM)](#через-nodejs-wasm)
- [📁 Структура проекта после сборки](#-структура-проекта-после-сборки)
- [🧹 Очистка](#-очистка)
- [🛠️ Полный процесс сборки "с нуля"](#️-полный-процесс-сборки-с-нуля)
- [🧪 Проверка сборки](#-проверка-сборки)
- [📊 Команды для быстрой генерации](#-команды-для-быстрой-генерации)
- [🔧 Проблемы и решения](#-проблемы-и-решения)
- [📝 Лицензия](#-лицензия)
- [👨‍💻 Автор](#-автор)
- [🔗 Ссылки](#-ссылки)

## 📦 Возможности

- Генерация конфигурации в 3 форматах:
  - **JSON** - для веб-интерфейсов и API
  - **C Header (.h)** - для интеграции в C/C++ проекты
  - **Environment (.env)** - для контейнеров и CI/CD
- Поддержка нативных C и WASM (WebAssembly)
- Интерактивный веб-интерфейс с подсветкой синтаксиса
- Экспорт функций для использования в браузере

## 🚀 Полная компиляция и сборка

### 1. Компиляция нативного C приложения

```bash
# Переход в директорию
cd /packages/mtproto-mqtt-gateway/metaflow/02-config-generator

# Компиляция
gcc -o config_test src/config_generator.c -lm

# Проверка
./config_test --help
```

### 2. Сборка WASM через Docker (рекомендуется)

```bash
cd /packages/mtproto-mqtt-gateway/metaflow/02-config-generator

# Сборка WASM через Docker
./build.sh -d

# Или с очисткой кеша
./build.sh -d -D

# Результат в папке web/
ls -la web/
# config_generator.mjs  - ES6 модуль
# config_generator.wasm - WASM бинарник
# config_generator.cjs  - CommonJS обертка
# config_generator.d.ts - TypeScript декларации
# config-generator-esm.js - ES6 обертка
# index.html - Демо страница
# app.mjs - JavaScript приложение
# style.css - Стили
```

### 3. Сборка WASM через локальный Emscripten

```bash
cd /packages/mtproto-mqtt-gateway/metaflow/02-config-generator

# Установка Emscripten (если не установлен)
./build.sh -i

# Активация окружения (после установки)
source ~/emsdk/emsdk_env.sh

# Сборка WASM
./build.sh -l

# Результат в папке web/
```

### 4. Сборка WASM вручную через emcc

```bash
cd /packages/mtproto-mqtt-gateway/metaflow/02-config-generator

# Сборка WASM с ES6 модулем
emcc src/config_generator.c \
    -o web/config_generator.mjs \
    -s WASM=1 \
    -s EXPORTED_FUNCTIONS='["_generate_config_json","_generate_config_c","_generate_config_env","_free_string"]' \
    -s EXPORTED_RUNTIME_METHODS='["ccall","cwrap","UTF8ToString"]' \
    -s ALLOW_MEMORY_GROWTH=1 \
    -s MODULARIZE=1 \
    -s EXPORT_NAME="ConfigGenerator" \
    -s EXPORT_ES6=1 \
    -s USE_ES6_IMPORT_META=1 \
    -s ENVIRONMENT="web,node" \
    -O2 \
    --no-entry

# Результат в папке web/
```

### 5. Сборка через npm

```bash
cd /packages/mtproto-mqtt-gateway/metaflow/02-config-generator

# Установка зависимостей
npm install

# Сборка
npm run build

# Или конкретные варианты
npm run build:wasm   # Через emcc
npm run build:docker # Через Docker
npm run build:clean  # Очистка перед сборкой
```

### 6. Сборка Docker образа вручную

```bash
cd /packages/mtproto-mqtt-gateway/metaflow/02-config-generator

# Сборка образа
docker build --no-cache -t config-generator-wasm .

# Запуск контейнера для сборки
docker run --rm -v "$(pwd)/web:/app/output" config-generator-wasm

# Результат в папке web/
```

## 🚀 Генерация конфигурационных файлов

### Нативная C программа

```bash
cd /packages/mtproto-mqtt-gateway/metaflow/02-config-generator

# Компиляция (если еще не скомпилирована)
gcc -o config_test src/config_generator.c -lm

# === ВЫВОД В STDOUT (по умолчанию) ===

# Генерация JSON в stdout
./config_test --json

# Генерация C header в stdout
./config_test --c

# Генерация .env в stdout
./config_test --env

# Генерация всех форматов в stdout
./config_test --all

# === СОХРАНЕНИЕ В ФАЙЛ ===

# Сохранение JSON в файл
./config_test --json -o config

# Сохранение C header в файл
./config_test --c -o config

# Сохранение .env в файл
./config_test --env -o config

# Сохранение всех форматов
./config_test --all -o config

# === ПЕРЕНАПРАВЛЕНИЕ В ФАЙЛ (альтернативный способ) ===

./config_test --json > myconfig.json
./config_test --c > myconfig.h
./config_test --env > myconfig.env
./config_test --all > all_configs.txt

# === ПОМОЩЬ ===
./config_test --help
```

### Через браузер (WASM)

```bash
cd /packages/mtproto-mqtt-gateway/metaflow/02-config-generator

# Сборка WASM
./build.sh

# Запуск веб-сервера
cd web
python3 -m http.server 8080
# или
npx serve

# Открыть в браузере: http://localhost:8080
# Нажать кнопку "Сгенерировать"
# Скопировать или скачать результат
```

### Через Node.js (WASM)

```bash
cd /packages/mtproto-mqtt-gateway/metaflow/02-config-generator/web

# Создание тестового скрипта
cat > generate.js << 'EOF'
import('./config_generator.mjs').then(module => {
  const config = module.default({
    onRuntimeInitialized: () => {
      console.log('✅ WASM загружен');
      
      // Генерация JSON
      const ptr = config._generate_config_json();
      const json = config.UTF8ToString(ptr);
      config._free_string(ptr);
      
      console.log('📄 JSON:');
      console.log(JSON.parse(json));
      
      // Генерация C header
      const ptr2 = config._generate_config_c();
      const header = config.UTF8ToString(ptr2);
      config._free_string(ptr2);
      
      console.log('🔧 C Header:');
      console.log(header);
      
      // Генерация .env
      const ptr3 = config._generate_config_env();
      const env = config.UTF8ToString(ptr3);
      config._free_string(ptr3);
      
      console.log('📝 .env:');
      console.log(env);
    }
  });
}).catch(console.error);
EOF

# Запуск
node --experimental-modules generate.js

# Или сохранение в файлы
node --experimental-modules generate.js > output.txt
```

## 📁 Структура проекта после сборки

```
02-config-generator/
├── src/
│   ├── config_generator.c      # Исходный код на C
│   └── config_generator.h      # Заголовочный файл
├── web/                        # Создается после сборки WASM
│   ├── index.html              # Веб-интерфейс
│   ├── app.mjs                 # JavaScript приложение
│   ├── style.css               # Стили
│   ├── config_generator.mjs    # WASM ES6 модуль
│   ├── config_generator.wasm   # WASM бинарник
│   ├── config_generator.cjs    # CommonJS обертка
│   ├── config_generator.d.ts   # TypeScript декларации
│   └── config-generator-esm.js # ES6 обертка
├── Dockerfile                  # Docker образ для сборки
├── build.sh                    # Скрипт сборки
├── package.json                # NPM конфигурация
└── README.md                   # Документация
```

## 🧹 Очистка

```bash
cd /packages/mtproto-mqtt-gateway/metaflow/02-config-generator

# Очистка собранных файлов
./build.sh -c

# Полная очистка (включая Docker кеш)
./build.sh -C

# Удаление сгенерированных конфигов
rm -f config.json config.h config.env

# Очистка Docker
docker system prune -f
docker rmi config-generator-wasm
```

## 🛠️ Полный процесс сборки "с нуля"

```bash
#!/bin/bash
# Полный процесс сборки

cd /packages/mtproto-mqtt-gateway/metaflow/02-config-generator

echo "=== 1. Компиляция нативного C приложения ==="
gcc -o config_test src/config_generator.c -lm

echo "=== 2. Сборка WASM через Docker ==="
./build.sh -d

echo "=== 3. Проверка нативного приложения ==="
./config_test --json | head -20

echo "=== 4. Генерация всех файлов ==="
./config_test --all -o config

echo "=== 5. Запуск веб-интерфейса ==="
cd web
python3 -m http.server 8080 &
echo "Откройте http://localhost:8080 в браузере"

echo "=== Готово! ==="
ls -la ../ | grep -E "config\\.|config_test"
ls -la . | grep -E "\\.mjs|\\.wasm|\\.html"
```

## 🧪 Проверка сборки

```bash
# Проверка нативного приложения
./config_test --help
./config_test --json | jq . 2>/dev/null || ./config_test --json

# Проверка WASM модуля
node -e "import('./web/config_generator.mjs').then(m => console.log('✅ WASM OK')).catch(e => console.error('❌', e))"

# Проверка веб-интерфейса
curl -s http://localhost:8080 | grep "Config Generator" > /dev/null && echo "✅ Web OK" || echo "❌ Web FAIL"
```

## 📊 Команды для быстрой генерации

```bash
# Быстрая генерация всех файлов одной командой
cd /packages/mtproto-mqtt-gateway/metaflow/02-config-generator
./config_test --all -o config

# Или с сохранением в другую директорию
mkdir -p ./output
./config_test --all -o ./output/config
ls -la ./output/
```

## 🔧 Проблемы и решения

### Ошибка: "emcc: command not found"
```bash
# Установка Emscripten
./build.sh -i
source ~/emsdk/emsdk_env.sh
```

### Ошибка: "Docker not found"
```bash
# Установка Docker
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh
```

### Ошибка компиляции C
```bash
# Установка gcc
sudo apt-get install gcc build-essential  # Ubuntu/Debian
brew install gcc                           # macOS
```

### Ошибка: "Permission denied" при запуске
```bash
chmod +x config_test
chmod +x build.sh
```

### Ошибка: "Failed to execute 'decode' on 'TextDecoder'"
```bash
# Использовать обновленный app.mjs с корректной обработкой памяти
# См. обновленный файл app.mjs в репозитории
```

### Ошибка: WASM не загружается в браузере
```bash
# Проверить поддержку ES6 модулей в браузере
# Использовать современный браузер: Chrome 80+, Firefox 75+, Edge 80+
# Проверить CORS заголовки при локальной разработке
```

## 📝 Лицензия

MIT License

## 👨‍💻 Автор

Забабурин Сергей <zababurins@vk.com>

## 🔗 Ссылки

- [GitHub](https://github.com/ZababurinSergei/mtproto-mqtt-gateway)
- [Документация MTProto](https://core.telegram.org/mtproto)
- [Emscripten](https://emscripten.org/)
- [MQTT Protocol](https://mqtt.org/)
