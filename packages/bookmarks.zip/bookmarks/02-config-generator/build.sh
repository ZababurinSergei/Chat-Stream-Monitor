#!/bin/bash
# build.sh - Сборка WASM модуля с поддержкой Docker и ES6 модулей

set -e

# ============================================================================
# Активация Emscripten
# ============================================================================

activate_emsdk() {
    local EMSDK_HOME="${HOME}/emsdk"

    # Проверяем наличие emsdk
    if [ -d "$EMSDK_HOME" ]; then
        # Добавляем пути
        export PATH="$EMSDK_HOME/upstream/emscripten:$EMSDK_HOME/upstream/bin:$PATH"

        # Активируем окружение если есть
        if [ -f "$EMSDK_HOME/emsdk_env.sh" ]; then
            source "$EMSDK_HOME/emsdk_env.sh" > /dev/null 2>&1
        fi

        # Проверяем что emcc доступен
        if command -v emcc &> /dev/null; then
            echo "✅ Emscripten активирован: $(emcc --version 2>&1 | head -1)"
            return 0
        fi
    fi

    echo "⚠️ Emscripten не найден в $EMSDK_HOME"
    return 1
}

# Активируем сразу
activate_emsdk || echo "⚠️ Продолжаем без активации Emscripten"

# ============================================================================
# Цвета для вывода
# ============================================================================

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# ============================================================================
# Функции
# ============================================================================

print_header() {
    echo ""
    echo "╔═══════════════════════════════════════════════════════════════╗"
    echo "║  $1"
    echo "╚═══════════════════════════════════════════════════════════════╝"
    echo ""
}

print_step() {
    echo -e "${CYAN}▶ $1${NC}"
}

print_success() {
    echo -e "${GREEN}✅ $1${NC}"
}

print_error() {
    echo -e "${RED}❌ $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}⚠️  $1${NC}"
}

print_info() {
    echo -e "${BLUE}ℹ️  $1${NC}"
}

# ============================================================================
# Получение UID и GID текущего пользователя
# ============================================================================

get_user_ids() {
    USER_UID=$(id -u)
    USER_GID=$(id -g)
    print_info "UID: $USER_UID, GID: $USER_GID"
}

# ============================================================================
# Изменение владельца файлов
# ============================================================================

fix_permissions() {
    print_step "Исправление прав доступа к файлам..."

    local files=(
        "web/config_generator.mjs"
        "web/config_generator.wasm"
    )

    for file in "${files[@]}"; do
        if [ -f "$file" ]; then
            sudo chown "$USER_UID:$USER_GID" "$file" 2>/dev/null || {
                chown "$USER_UID:$USER_GID" "$file" 2>/dev/null || true
            }
            print_success "Права исправлены: $file"
        fi
    done

    if [ -d "web" ]; then
        sudo chown "$USER_UID:$USER_GID" web 2>/dev/null || {
            chown "$USER_UID:$USER_GID" web 2>/dev/null || true
        }
    fi
}

# ============================================================================
# Проверка наличия emcc
# ============================================================================

check_emcc() {
    print_step "Проверка наличия emcc (emscripten)..."

    # Убеждаемся что пути правильные
    export PATH="$HOME/emsdk/upstream/emscripten:$HOME/emsdk/upstream/bin:$PATH"

    if [ -f "$HOME/emsdk/emsdk_env.sh" ]; then
        source "$HOME/emsdk/emsdk_env.sh" > /dev/null 2>&1
    fi

    if command -v emcc &> /dev/null; then
        local version=$(emcc --version 2>&1 | head -1)
        print_success "emcc найден: $version"
        print_info "Путь: $(which emcc)"
        return 0
    else
        print_warning "emcc (emscripten) не найден!"
        print_info "Попробуйте: source ~/emsdk/emsdk_env.sh"
        return 1
    fi
}

# ============================================================================
# Проверка наличия Docker
# ============================================================================

check_docker() {
    print_step "Проверка наличия Docker..."

    if command -v docker &> /dev/null; then
        local version=$(docker --version)
        print_success "Docker найден: $version"
        return 0
    else
        print_error "Docker не найден!"
        print_info "Установите Docker: https://docs.docker.com/get-docker/"
        return 1
    fi
}

# ============================================================================
# Очистка Docker кеша
# ============================================================================

clean_docker() {
    print_step "Очистка Docker кеша..."

    print_info "Остановка контейнеров..."
    docker stop $(docker ps -aq) 2>/dev/null || true

    print_info "Удаление контейнеров..."
    docker rm $(docker ps -aq) 2>/dev/null || true

    print_info "Удаление образов..."
    docker rmi $(docker images -q) 2>/dev/null || true

    print_info "Очистка кеша сборки..."
    docker builder prune -f

    print_info "Очистка системы..."
    docker system prune -f --volumes

    print_success "Docker кеш очищен"
}

# ============================================================================
# Полная очистка проекта
# ============================================================================

full_clean() {
    print_step "Полная очистка проекта..."

    rm -rf web/config_generator.mjs
    rm -rf web/config_generator.wasm
    rm -rf web/config_generator.cjs
    rm -rf web/config_generator.d.ts
    rm -rf web/config-generator-esm.js
    rm -rf web/config_generator.js
    rm -rf Dockerfile
    rm -rf node_modules
    rm -rf package-lock.json

    clean_docker

    print_success "Полная очистка завершена"
}

# ============================================================================
# Создание CommonJS обертки (флаг --cjs)
# ============================================================================

create_cjs_wrapper() {
    print_step "Создание CommonJS обертки..."

    cat > web/config_generator.cjs << 'EOF'
// CommonJS обертка для совместимости с Node.js
async function loadModule() {
    const module = await import('./config_generator.mjs');
    return module.default;
}

module.exports = loadModule;
module.exports.ConfigGenerator = loadModule;
EOF

    print_success "CommonJS обертка создана: web/config_generator.cjs"
}

# ============================================================================
# Создание TypeScript деклараций (флаг --ts)
# ============================================================================

create_typescript_definitions() {
    print_step "Создание TypeScript деклараций..."

    cat > web/config_generator.d.ts << 'EOF'
/**
 * TypeScript декларации для Config Generator WASM модуля
 */

export interface ConfigGeneratorModule {
    _generate_config_json(): number;
    _generate_config_c(): number;
    _generate_config_env(): number;
    _free_config_string(ptr: number): void;
    UTF8ToString(ptr: number): string;
}

export interface ConfigGeneratorOptions {
    onRuntimeInitialized?: () => void;
    print?: (text: string) => void;
    printErr?: (text: string) => void;
}

declare function ConfigGenerator(options?: ConfigGeneratorOptions): Promise<ConfigGeneratorModule>;

export default ConfigGenerator;
EOF

    print_success "TypeScript декларации созданы: web/config_generator.d.ts"
}

# ============================================================================
# Создание ES6 модуль обертки (флаг --esm)
# ============================================================================

create_esm_wrapper() {
    print_step "Создание ES6 модуль обертки..."

    cat > web/config-generator-esm.js << 'EOF'
// config-generator-esm.js - ES6 модуль обертка для WASM
import createConfigGenerator from './config_generator.mjs';

class ConfigGeneratorESM {
    constructor(options = {}) {
        this._module = null;
        this._initialized = false;
        this._options = options;
    }

    async init() {
        if (this._initialized) return this;

        this._module = await createConfigGenerator({
            ...this._options,
            onRuntimeInitialized: () => {
                console.log('[WASM] Runtime initialized');
                if (this._options.onRuntimeInitialized) {
                    this._options.onRuntimeInitialized();
                }
            }
        });

        this._initialized = true;
        return this;
    }

    generateJSON() {
        if (!this._module) throw new Error('Module not initialized');
        const ptr = this._module._generate_config_json();
        const result = this._module.UTF8ToString(ptr);
        this._module._free_config_string(ptr);
        return JSON.parse(result);
    }

    generateCHeader() {
        if (!this._module) throw new Error('Module not initialized');
        const ptr = this._module._generate_config_c();
        const result = this._module.UTF8ToString(ptr);
        this._module._free_config_string(ptr);
        return result;
    }

    generateEnv() {
        if (!this._module) throw new Error('Module not initialized');
        const ptr = this._module._generate_config_env();
        const result = this._module.UTF8ToString(ptr);
        this._module._free_config_string(ptr);
        return result;
    }

    generate(format = 'json') {
        switch(format) {
            case 'json': return this.generateJSON();
            case 'c': return this.generateCHeader();
            case 'env': return this.generateEnv();
            default: throw new Error(`Unknown format: ${format}`);
        }
    }

    static async quickGenerate(format = 'json', options = {}) {
        const instance = new ConfigGeneratorESM(options);
        await instance.init();
        return instance.generate(format);
    }

    isReady() {
        return this._initialized && this._module !== null;
    }

    getStats() {
        return {
            initialized: this._initialized,
            version: '2.0.0',
            env: this._options.environment || 'auto'
        };
    }
}

export default ConfigGeneratorESM;
export { ConfigGeneratorESM };
EOF

    print_success "ES6 модуль обертка создана: web/config-generator-esm.js"
}

# ============================================================================
# Сборка через Docker (только WASM + ESM)
# ============================================================================

build_with_docker() {
    print_step "Сборка через Docker..."

    if ! check_docker; then
        print_error "Docker не установлен!"
        return 1
    fi

    get_user_ids

    print_info "Создание Dockerfile..."

    cat > Dockerfile << 'EOF'
FROM emscripten/emsdk:latest

LABEL maintainer="Zababurin Sergey <zababurins@vk.com>"
LABEL description="MTProto MQTT Config Generator - WASM Build with ES6 Module"

WORKDIR /app

COPY src/ ./src/

RUN mkdir -p /app/web

# Компилируем основной файл
# Используем _ перед именами функций для правильного экспорта
RUN emcc src/config_generator.c \
    -o /app/web/config_generator.mjs \
    -s WASM=1 \
    -s EXPORTED_FUNCTIONS='["_generate_config_json","_generate_config_c","_generate_config_env","_free_config_string"]' \
    -s EXPORTED_RUNTIME_METHODS='["ccall","cwrap","getValue","setValue","UTF8ToString","HEAPU8","HEAP32","HEAP16","HEAP8","wasmMemory"]' \
    -s ALLOW_MEMORY_GROWTH=1 \
    -s MODULARIZE=1 \
    -s EXPORT_NAME="ConfigGenerator" \
    -s EXPORT_ES6=1 \
    -s USE_ES6_IMPORT_META=1 \
    -s ENVIRONMENT='web,node' \
    -O2 \
    --no-entry

RUN ls -la /app/web/

CMD ["cp", "-r", "/app/web/.", "/app/output/"]
EOF

    print_info "Сборка Docker образа..."
    docker build --no-cache -t config-generator-wasm .

    if [ $? -eq 0 ]; then
        print_success "Docker образ собран"
    else
        print_error "Ошибка сборки Docker образа"
        return 1
    fi

    print_info "Запуск контейнера..."
    docker run --rm -v "$(pwd)/web:/app/output" config-generator-wasm

    fix_permissions

    if [ -f "web/config_generator.mjs" ] && [ -f "web/config_generator.wasm" ]; then
        print_success "✅ WASM + ESM собраны через Docker!"
        return 0
    else
        print_error "WASM файлы не найдены!"
        return 1
    fi
}

# ============================================================================
# Сборка через локальный emcc (только WASM + ESM)
# ============================================================================

build_with_local_emcc() {
    print_step "Сборка через локальный emcc..."

    if [ ! -f "src/config_generator.c" ]; then
        print_error "Исходный файл src/config_generator.c не найден!"
        return 1
    fi

    mkdir -p web

    print_info "Компиляция config_generator.c → WASM (ES6 Module)..."

    # Убеждаемся что emcc доступен
    export PATH="$HOME/emsdk/upstream/emscripten:$HOME/emsdk/upstream/bin:$PATH"
    if [ -f "$HOME/emsdk/emsdk_env.sh" ]; then
        source "$HOME/emsdk/emsdk_env.sh" > /dev/null 2>&1
    fi

    # Проверяем что emcc работает
    if ! command -v emcc &> /dev/null; then
        print_error "emcc не найден! Активируйте Emscripten: source ~/emsdk/emsdk_env.sh"
        return 1
    fi

    # Компилируем с правильными именами экспортов (с подчеркиванием)
    emcc src/config_generator.c \
        -o web/config_generator.mjs \
        -s WASM=1 \
        -s EXPORTED_FUNCTIONS='["_generate_config_json","_generate_config_c","_generate_config_env","_free_config_string"]' \
        -s EXPORTED_RUNTIME_METHODS='["ccall","cwrap","getValue","setValue","UTF8ToString","HEAPU8","HEAP32","HEAP16","HEAP8","wasmMemory"]' \
        -s ALLOW_MEMORY_GROWTH=1 \
        -s MODULARIZE=1 \
        -s EXPORT_NAME="ConfigGenerator" \
        -s EXPORT_ES6=1 \
        -s USE_ES6_IMPORT_META=1 \
        -s ENVIRONMENT='web,node' \
        -O2 \
        --no-entry

    if [ $? -eq 0 ]; then
        print_success "✅ WASM + ESM собраны локально!"
        return 0
    else
        print_error "Ошибка компиляции!"
        return 1
    fi
}

# ============================================================================
# Основная функция сборки
# ============================================================================

build() {
    print_header "🔨 Config Generator - WASM Build (ES6 Module)"

    # Всегда делаем полную очистку перед сборкой
    print_step "Полная очистка перед сборкой..."
    full_clean

    # Проверяем наличие emcc
    if check_emcc; then
        if build_with_local_emcc; then
            print_success "✅ Сборка завершена успешно!"
            print_info "📦 Результат:"
            echo "  - web/config_generator.mjs  (ES6 модуль)"
            echo "  - web/config_generator.wasm (WASM бинарник)"
            return 0
        else
            print_warning "Локальная сборка не удалась, пробуем Docker..."
        fi
    fi

    # Пробуем Docker
    print_info "Пытаемся собрать через Docker..."
    if build_with_docker; then
        print_success "✅ Сборка через Docker завершена успешно!"
        print_info "📦 Результат:"
        echo "  - web/config_generator.mjs  (ES6 модуль)"
        echo "  - web/config_generator.wasm (WASM бинарник)"
        return 0
    fi

    print_error "❌ Не удалось собрать WASM!"
    echo ""
    echo "📋 Инструкция по установке emscripten:"
    echo ""
    echo "  git clone https://github.com/emscripten-core/emsdk.git ~/emsdk"
    echo "  cd ~/emsdk"
    echo "  ./emsdk install latest"
    echo "  ./emsdk activate latest"
    echo "  source ~/emsdk/emsdk_env.sh"
    echo "  ./build.sh"
    echo ""
    echo "  # Или используйте Docker:"
    echo "  docker build --no-cache -t config-generator-wasm ."
    echo "  docker run --rm -v \$(pwd)/web:/app/output config-generator-wasm"
    echo ""

    return 1
}

# ============================================================================
# Помощь
# ============================================================================

show_help() {
    echo ""
    echo "Использование: ./build.sh [OPTIONS]"
    echo ""
    echo "По умолчанию: полная очистка + сборка WASM + ESM модуля"
    echo ""
    echo "Опции:"
    echo "  -h, --help          Показать эту справку"
    echo "  -c, --clean         Только очистка (без сборки)"
    echo "  -d, --docker        Принудительно использовать Docker"
    echo "  -l, --local         Принудительно использовать локальный emcc"
    echo "  -i, --install       Установить emscripten локально"
    echo ""
    echo "Дополнительные форматы (генерируются отдельно):"
    echo "  --cjs               Создать CommonJS обертку (config_generator.cjs)"
    echo "  --ts                Создать TypeScript декларации (config_generator.d.ts)"
    echo "  --esm               Создать ES6 обертку (config-generator-esm.js)"
    echo "  --all               Создать все дополнительные форматы"
    echo ""
    echo "Примеры:"
    echo "  ./build.sh              # Полная очистка + сборка WASM + ESM"
    echo "  ./build.sh --cjs        # Сборка WASM + ESM + CommonJS обертка"
    echo "  ./build.sh --all        # Сборка WASM + ESM + все доп. форматы"
    echo "  ./build.sh -d --all     # Docker + все форматы"
    echo "  ./build.sh -c           # Только очистка"
    echo ""
    echo "Результат сборки (по умолчанию):"
    echo "  web/config_generator.mjs  - ES6 модуль"
    echo "  web/config_generator.wasm - WASM бинарник"
    echo ""
}

# ============================================================================
# Парсинг аргументов
# ============================================================================

USE_DOCKER=0
USE_LOCAL=0
DO_INSTALL=0
DO_CLEAN_ONLY=0
DO_CJS=0
DO_TS=0
DO_ESM=0
DO_ALL=0

while [[ $# -gt 0 ]]; do
    case $1 in
        -h|--help)
            show_help
            exit 0
            ;;
        -c|--clean)
            DO_CLEAN_ONLY=1
            shift
            ;;
        -d|--docker)
            USE_DOCKER=1
            shift
            ;;
        -l|--local)
            USE_LOCAL=1
            shift
            ;;
        -i|--install)
            DO_INSTALL=1
            shift
            ;;
        --cjs)
            DO_CJS=1
            shift
            ;;
        --ts)
            DO_TS=1
            shift
            ;;
        --esm)
            DO_ESM=1
            shift
            ;;
        --all)
            DO_ALL=1
            shift
            ;;
        *)
            echo "Неизвестная опция: $1"
            show_help
            exit 1
            ;;
    esac
done

# Если --all, включаем все доп. форматы
if [ $DO_ALL -eq 1 ]; then
    DO_CJS=1
    DO_TS=1
    DO_ESM=1
fi

# ============================================================================
# Запуск
# ============================================================================

if [ $DO_INSTALL -eq 1 ]; then
    print_step "Установка emscripten..."
    git clone https://github.com/emscripten-core/emsdk.git ~/emsdk
    cd ~/emsdk
    ./emsdk install latest
    ./emsdk activate latest
    echo "source ~/emsdk/emsdk_env.sh" >> ~/.bashrc
    print_success "emscripten установлен! Перезапустите терминал или выполните: source ~/emsdk/emsdk_env.sh"
    exit 0
fi

if [ $DO_CLEAN_ONLY -eq 1 ]; then
    full_clean
    exit 0
fi

# Основная сборка
build

# Если сборка успешна и запрошены доп. форматы
if [ $? -eq 0 ]; then
    if [ $DO_CJS -eq 1 ]; then
        create_cjs_wrapper
    fi
    if [ $DO_TS -eq 1 ]; then
        create_typescript_definitions
    fi
    if [ $DO_ESM -eq 1 ]; then
        create_esm_wrapper
    fi

    echo ""
    print_info "📦 Итоговые файлы в web/:"
    ls -la web/ 2>/dev/null | grep -E "\.(mjs|wasm|cjs|ts|js)$" || echo "  Нет файлов"
fi

exit $?
