// ============================================================
// app.mjs — 100% СИМВОЛЫ — полная изоляция и безопасность
// Логика приложения Global Store Admin
// Версия: 4.0.4 (ИСПРАВЛЕНО)
// ============================================================

// ============================================================
// 1. ПРИВАТНЫЕ СИМВОЛЫ (100% изоляция)
// ============================================================

const PRIVATE = {
  // Основные символы приложения
  VERSION: Symbol('app.version'),
  BUILD: Symbol('app.build'),
  NAME: Symbol('app.name'),
  CONFIG: Symbol('app.config'),
  STATE: Symbol('app.state'),
  INITIALIZED: Symbol('app.initialized'),
  DESTROYED: Symbol('app.destroyed'),
  START_TIME: Symbol('app.startTime'),
  LAST_UPDATE: Symbol('app.lastUpdate'),

  // Состояние UI
  SELECTED_TABLE: Symbol('app.selectedTable'),
  SELECTED_ROW: Symbol('app.selectedRow'),
  ACTIVE_TAB: Symbol('app.activeTab'),
  IS_LOG_PAUSED: Symbol('app.isLogPaused'),
  LOG_ENTRIES: Symbol('app.logEntries'),
  MAX_LOG: Symbol('app.maxLog'),

  // Модальное окно
  MODAL_CALLBACK: Symbol('app.modalCallback'),
  MODAL_DATA: Symbol('app.modalData'),
  MODAL_ACTIVE: Symbol('app.modalActive'),

  // Сообщения брокера
  MESSAGES: Symbol('app.messages'),
  SUBSCRIPTIONS: Symbol('app.subscriptions'),
  MESSAGE_COUNT: Symbol('app.messageCount'),

  // DOM референсы
  DOM: Symbol('app.dom'),
  REFS: Symbol('app.refs'),

  // Глобальное хранилище
  GLOBAL_STORE: Symbol('app.globalStore'),
  GLOBAL_STORE_READY: Symbol('app.globalStoreReady'),

  // Методы
  INIT: Symbol('app.init'),
  DESTROY: Symbol('app.destroy'),
  RENDER: Symbol('app.render'),
  RENDER_STATS: Symbol('app.renderStats'),
  RENDER_TABLES: Symbol('app.renderTables'),
  RENDER_DATA: Symbol('app.renderData'),
  RENDER_INSPECTOR: Symbol('app.renderInspector'),
  RENDER_RELATIONS: Symbol('app.renderRelations'),
  RENDER_SUBSCRIPTIONS: Symbol('app.renderSubscriptions'),
  RENDER_MESSAGES: Symbol('app.renderMessages'),
  RENDER_AUDIT: Symbol('app.renderAudit'),
  RENDER_SCHEMAS: Symbol('app.renderSchemas'),
  RENDER_PLUGINS: Symbol('app.renderPlugins'),
  RENDER_SETTINGS: Symbol('app.renderSettings'),
  RENDER_ALL: Symbol('app.renderAll'),
  RENDER_LOG: Symbol('app.renderLog'),

  // Модальное окно
  SHOW_MODAL: Symbol('app.showModal'),
  CLOSE_MODAL: Symbol('app.closeModal'),
  SETUP_MODAL: Symbol('app.setupModal'),

  // Таблицы
  SELECT_TABLE: Symbol('app.selectTable'),
  ADD_ROW: Symbol('app.addRow'),
  CREATE_TABLE: Symbol('app.createTable'),
  LINK_TABLES: Symbol('app.linkTables'),
  UNLINK_TABLES: Symbol('app.unlinkTables'),

  // Брокер
  PUBLISH_MESSAGE: Symbol('app.publishMessage'),
  ADD_SUBSCRIPTION: Symbol('app.addSubscription'),
  CLEAR_MESSAGES: Symbol('app.clearMessages'),

  // Консоль
  EXECUTE_COMMAND: Symbol('app.executeCommand'),
  CLEAR_CONSOLE: Symbol('app.clearConsole'),

  // Экспорт
  EXPORT_DATA: Symbol('app.exportData'),
  EXPORT_AUDIT: Symbol('app.exportAudit'),

  // Демо-данные
  INIT_DEMO: Symbol('app.initDemo'),
  DEMO_LOADED: Symbol('app.demoLoaded'),

  // Утилиты
  ESCAPE_HTML: Symbol('app.escapeHtml'),
  FORMAT_JSON: Symbol('app.formatJson'),
  FORMAT_TIME: Symbol('app.formatTime'),
  GET_DOM: Symbol('app.getDom'),
  IS_FUNCTION: Symbol('app.isFunction'),
  IS_OBJECT: Symbol('app.isObject'),
  SAFE_CALL: Symbol('app.safeCall'),

  // Безопасность
  VALIDATE: Symbol('app.validate'),
  SANITIZE: Symbol('app.sanitize'),
  SECURE: Symbol('app.secure'),
  CHECK_CONTEXT: Symbol('app.checkContext'),

  // Экспорт символов
  EXPORT_SYMBOLS: Symbol('app.exportSymbols'),

  // Логгер
  LOGGER: Symbol('app.logger'),
};

// ============================================================
// 2. ПУБЛИЧНЫЕ СИМВОЛЫ (доступны через Symbol.for)
// ============================================================

const PUBLIC = {
  INSTANCE: Symbol.for('app.instance'),
  STATE: Symbol.for('app.state'),
  CONFIG: Symbol.for('app.config'),
  INIT: Symbol.for('app.init'),
  DESTROY: Symbol.for('app.destroy'),
  RENDER: Symbol.for('app.render'),
  GET_STATE: Symbol.for('app.getState'),
  HEALTH_CHECK: Symbol.for('app.healthCheck'),
  SHOW_MODAL: Symbol.for('app.showModal'),
  CLOSE_MODAL: Symbol.for('app.closeModal'),
  SELECT_TABLE: Symbol.for('app.selectTable'),
  ADD_ROW: Symbol.for('app.addRow'),
  CREATE_TABLE: Symbol.for('app.createTable'),
  EXECUTE_COMMAND: Symbol.for('app.executeCommand'),
  CLEAR_CONSOLE: Symbol.for('app.clearConsole'),
  INIT_DEMO: Symbol.for('app.initDemo'),
  GET_GLOBAL_STORE: Symbol.for('app.getGlobalStore'),
};

// ============================================================
// 3. КОНФИГУРАЦИЯ
// ============================================================

const CONFIG = {
  version: '4.0.4',
  build: '2026-07-28',
  name: 'Global Store Admin',
  debug: true,
  maxLogEntries: 500,
  maxMessages: 100,
  maxAuditEntries: 1000,
  autoRefresh: true,
  refreshInterval: 5000,
  defaultPageSize: 20,
  defaultTable: 'projects',
  globalStoreSymbol: '__GLOBAL_STORE__',
};

// ============================================================
// 4. ЛОГГЕР (100% символы)
// ============================================================

const LOGGER_SYMBOLS = {
  HISTORY: Symbol('logger.history'),
  MAX_HISTORY: Symbol('logger.maxHistory'),
  DEBUG: Symbol('logger.debug'),
  INSTANCE_ID: Symbol('logger.instanceId'),
  LEVEL: Symbol('logger.level'),
  COLORS: Symbol('logger.colors'),
};

function createLogger(debug = true, instanceId = 'App') {
  const logState = {
    [LOGGER_SYMBOLS.HISTORY]: [],
    [LOGGER_SYMBOLS.MAX_HISTORY]: 200,
    [LOGGER_SYMBOLS.DEBUG]: debug,
    [LOGGER_SYMBOLS.INSTANCE_ID]: instanceId,
    [LOGGER_SYMBOLS.LEVEL]: debug ? 3 : 2,
    [LOGGER_SYMBOLS.COLORS]: {
      reset: '\x1b[0m',
      bold: '\x1b[1m',
      red: '\x1b[31m',
      green: '\x1b[32m',
      yellow: '\x1b[33m',
      blue: '\x1b[34m',
      magenta: '\x1b[35m',
      cyan: '\x1b[36m',
      gray: '\x1b[90m',
    },
  };

  const logMethod = function (level, message, data = null) {
    const levels = { error: 0, warn: 1, info: 2, debug: 3, success: 2 };
    const currentLevel = this[LOGGER_SYMBOLS.LEVEL] || 2;
    const msgLevel = levels[level] || 2;

    if (msgLevel > currentLevel) return;

    const timestamp = new Date().toISOString().slice(11, 23);
    const prefix = `[${timestamp}] [${this[LOGGER_SYMBOLS.INSTANCE_ID]}]`;

    this[LOGGER_SYMBOLS.HISTORY].push({
      timestamp,
      level,
      message,
      data,
      id: Date.now() + Math.random(),
    });

    if (this[LOGGER_SYMBOLS.HISTORY].length > this[LOGGER_SYMBOLS.MAX_HISTORY]) {
      this[LOGGER_SYMBOLS.HISTORY].shift();
    }

    const icons = { error: '❌', warn: '⚠️', info: 'ℹ️', debug: '🔍', success: '✅' };
    const icon = icons[level] || '📌';
    const colors = this[LOGGER_SYMBOLS.COLORS];
    const colorMap = {
      error: colors.red,
      warn: colors.yellow,
      info: colors.blue,
      debug: colors.gray,
      success: colors.green,
    };
    const color = colorMap[level] || colors.white;

    if (data !== null && data !== undefined) {
      console.log(`${color}${icon} ${prefix} ${message}${colors.reset}`, data);
    } else {
      console.log(`${color}${icon} ${prefix} ${message}${colors.reset}`);
    }
  };

  const boundLog = logMethod.bind(logState);

  const methods = {
    error: (msg, d) => boundLog('error', msg, d),
    warn: (msg, d) => boundLog('warn', msg, d),
    info: (msg, d) => boundLog('info', msg, d),
    debug: (msg, d) => boundLog('debug', msg, d),
    success: (msg, d) => boundLog('success', msg, d),

    header: (title, color = '#636e72') => {
      const colors = logState[LOGGER_SYMBOLS.COLORS];
      const separator = '═'.repeat(70);
      console.log(`${colors.cyan}${separator}${colors.reset}`);
      console.log(`${colors.bold}${colors.magenta}  🏢 ${title}${colors.reset}`);
      console.log(`${colors.cyan}${separator}${colors.reset}`);
    },

    separator: (color = '#636e72') => {
      const colors = logState[LOGGER_SYMBOLS.COLORS];
      console.log(`${colors.gray}${'─'.repeat(70)}${colors.reset}`);
    },

    getHistory: function () {
      return [...this[LOGGER_SYMBOLS.HISTORY]];
    },

    clearHistory: function () {
      this[LOGGER_SYMBOLS.HISTORY] = [];
      return this;
    },

    setDebug: function (enabled) {
      this[LOGGER_SYMBOLS.DEBUG] = enabled;
      this[LOGGER_SYMBOLS.LEVEL] = enabled ? 3 : 2;
      return this;
    },
  };

  const logger = {};
  for (const [key, fn] of Object.entries(methods)) {
    logger[key] = fn.bind(logState);
  }

  logger[LOGGER_SYMBOLS.HISTORY] = logState[LOGGER_SYMBOLS.HISTORY];
  logger[LOGGER_SYMBOLS.MAX_HISTORY] = logState[LOGGER_SYMBOLS.MAX_HISTORY];
  logger[LOGGER_SYMBOLS.DEBUG] = logState[LOGGER_SYMBOLS.DEBUG];
  logger[LOGGER_SYMBOLS.INSTANCE_ID] = logState[LOGGER_SYMBOLS.INSTANCE_ID];
  logger[LOGGER_SYMBOLS.LEVEL] = logState[LOGGER_SYMBOLS.LEVEL];
  logger[LOGGER_SYMBOLS.COLORS] = logState[LOGGER_SYMBOLS.COLORS];

  return logger;
}

// ============================================================
// 5. ИМПОРТЫ
// ============================================================

import { db, createStore, getStore, GLOBAL_STORE_SYMBOL, DEFAULT_PLUGINS } from './index.js';

// ============================================================
// 6. DOM РЕФЕРЕНСЫ (100% символы)
// ============================================================

const DOM = {
  // Статистика
  tablesCount: document.getElementById('tablesCount'),
  recordsCount: document.getElementById('recordsCount'),
  relationsCount: document.getElementById('relationsCount'),
  subscribersCount: document.getElementById('subscribersCount'),
  undoCount: document.getElementById('undoCount'),
  redoCount: document.getElementById('redoCount'),
  cacheCount: document.getElementById('cacheCount'),
  auditCount: document.getElementById('auditCount'),

  // Табы
  tabs: document.getElementById('tabs'),
  tabContents: document.querySelectorAll('.tab-content'),

  // Таблицы
  tablesList: document.getElementById('tablesList'),
  dataContainer: document.getElementById('dataContainer'),
  currentTableTitle: document.getElementById('currentTableTitle'),
  tablesInfo: document.getElementById('tablesInfo'),

  // Кнопки
  refreshBtn: document.getElementById('refreshBtn'),
  saveBtn: document.getElementById('saveBtn'),
  loadBtn: document.getElementById('loadBtn'),
  clearBtn: document.getElementById('clearBtn'),
  createTableBtn: document.getElementById('createTableBtn'),
  createTableWithSchemaBtn: document.getElementById('createTableWithSchemaBtn'),
  addRowBtn: document.getElementById('addRowBtn'),
  refreshDataBtn: document.getElementById('refreshDataBtn'),
  exportDataBtn: document.getElementById('exportDataBtn'),

  // Инспектор
  inspectorContent: document.getElementById('inspectorContent'),
  inspectorRefresh: document.getElementById('inspectorRefresh'),

  // Связи
  relationsContainer: document.getElementById('relationsContainer'),
  linkTablesBtn: document.getElementById('linkTablesBtn'),
  unlinkTablesBtn: document.getElementById('unlinkTablesBtn'),

  // Брокер
  brokerTopic: document.getElementById('brokerTopic'),
  brokerData: document.getElementById('brokerData'),
  publishBtn: document.getElementById('publishBtn'),
  subscriptionsList: document.getElementById('subscriptionsList'),
  addSubscriptionBtn: document.getElementById('addSubscriptionBtn'),
  messagesContainer: document.getElementById('messagesContainer'),
  messagesCount: document.getElementById('messagesCount'),
  clearMessagesBtn: document.getElementById('clearMessagesBtn'),

  // Аудит
  auditContainer: document.getElementById('auditContainer'),
  clearAuditBtn: document.getElementById('clearAuditBtn'),
  exportAuditBtn: document.getElementById('exportAuditBtn'),

  // Схемы
  schemasContainer: document.getElementById('schemasContainer'),

  // Консоль
  consoleOutput: document.getElementById('consoleOutput'),
  consoleInput: document.getElementById('consoleInput'),
  consoleExecBtn: document.getElementById('consoleExecBtn'),
  clearConsoleBtn: document.getElementById('clearConsoleBtn'),

  // Плагины
  pluginsContainer: document.getElementById('pluginsContainer'),
  pluginManagerBtn: document.getElementById('pluginManagerBtn'),

  // Настройки
  autoCreate: document.getElementById('autoCreate'),
  autoSave: document.getElementById('autoSave'),
  saveInterval: document.getElementById('saveInterval'),
  maxRecords: document.getElementById('maxRecords'),
  maxTables: document.getElementById('maxTables'),
  quotasDisplay: document.getElementById('quotasDisplay'),
  infoDisplay: document.getElementById('infoDisplay'),

  // Модалка
  modalOverlay: document.getElementById('modalOverlay'),
  modalTitle: document.getElementById('modalTitle'),
  modalBody: document.getElementById('modalBody'),
  modalCloseBtn: document.getElementById('modalCloseBtn'),
  modalCancelBtn: document.getElementById('modalCancelBtn'),
  modalConfirmBtn: document.getElementById('modalConfirmBtn'),

  // Badge
  versionBadge: document.getElementById('versionBadge'),
  statusBadge: document.getElementById('statusBadge'),

  // ★★★ ИСПРАВЛЕНО: добавлен logContainer ★★★
  logContainer: document.getElementById('logContainer'),
};

// ============================================================
// 7. СОСТОЯНИЕ ПРИЛОЖЕНИЯ (100% символы)
// ============================================================

const APP_STATE = {
  [PRIVATE.SELECTED_TABLE]: null,
  [PRIVATE.SELECTED_ROW]: null,
  [PRIVATE.ACTIVE_TAB]: 'data',
  [PRIVATE.IS_LOG_PAUSED]: false,
  [PRIVATE.LOG_ENTRIES]: [],
  [PRIVATE.MAX_LOG]: CONFIG.maxLogEntries,
  [PRIVATE.MESSAGES]: [],
  [PRIVATE.SUBSCRIPTIONS]: [],
  [PRIVATE.MESSAGE_COUNT]: 0,
  [PRIVATE.MODAL_CALLBACK]: null,
  [PRIVATE.MODAL_DATA]: null,
  [PRIVATE.MODAL_ACTIVE]: false,
  [PRIVATE.INITIALIZED]: false,
  [PRIVATE.DESTROYED]: false,
  [PRIVATE.START_TIME]: Date.now(),
  [PRIVATE.LAST_UPDATE]: null,
  [PRIVATE.DEMO_LOADED]: false,
  [PRIVATE.GLOBAL_STORE_READY]: false,
};

// ============================================================
// 8. УТИЛИТЫ (100% символы)
// ============================================================

function escapeHtml(text) {
  if (!text) return '';
  return String(text)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/\"/g, '&quot;')
      .replace(/'/g, '&#039;');
}

function formatJson(obj) {
  try {
    return JSON.stringify(obj, null, 2);
  } catch {
    return String(obj);
  }
}

function formatTime(ts) {
  try {
    return new Date(ts).toLocaleTimeString('ru-RU', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      fractionalSecondDigits: 3,
    });
  } catch {
    return '--:--:--';
  }
}

function isFunction(fn) {
  return fn && typeof fn === 'function';
}

function isObject(obj) {
  return obj && typeof obj === 'object' && !Array.isArray(obj);
}

function getDom(id) {
  const element = document.getElementById(id);
  if (!element) {
    console.warn(`⚠️ Элемент не найден: ${id}`);
  }
  return element;
}

function safeCall(fn, ...args) {
  if (isFunction(fn)) {
    try {
      return fn(...args);
    } catch (error) {
      console.error('❌ Ошибка вызова функции:', error);
      return null;
    }
  }
  return null;
}

// ============================================================
// 9. МОДАЛЬНОЕ ОКНО (100% символы)
// ============================================================

function showModal(title, bodyHtml, onConfirm, onCancel = null) {
  const state = APP_STATE;

  state[PRIVATE.MODAL_CALLBACK] = onConfirm;
  state[PRIVATE.MODAL_DATA] = { onCancel };
  state[PRIVATE.MODAL_ACTIVE] = true;

  DOM.modalTitle.textContent = title;
  DOM.modalBody.innerHTML = bodyHtml;
  DOM.modalOverlay.classList.remove('hidden');

  setTimeout(() => {
    const firstInput = DOM.modalBody.querySelector('input, textarea, select');
    if (firstInput) {
      firstInput.focus();
    } else {
      DOM.modalConfirmBtn.focus();
    }
  }, 100);

  addLog(`📋 Модальное окно: ${title}`, 'info');
}

function closeModal(result = null) {
  const state = APP_STATE;

  DOM.modalOverlay.classList.add('hidden');

  if (state[PRIVATE.MODAL_CALLBACK] && result !== null) {
    try {
      state[PRIVATE.MODAL_CALLBACK](result);
    } catch (error) {
      console.error('❌ Ошибка в callback модального окна:', error);
      addLog(`❌ Ошибка в callback: ${error.message}`, 'error');
    }
  }

  state[PRIVATE.MODAL_CALLBACK] = null;
  state[PRIVATE.MODAL_DATA] = null;
  state[PRIVATE.MODAL_ACTIVE] = false;
}

function setupModal() {
  DOM.modalConfirmBtn.addEventListener('click', () => {
    const state = APP_STATE;
    if (state[PRIVATE.MODAL_CALLBACK]) {
      const formData = {};
      const inputs = DOM.modalBody.querySelectorAll('input, textarea, select');
      for (const input of inputs) {
        if (input.id) {
          const value = input.type === 'checkbox' ? input.checked : input.value;
          formData[input.id] = value;
        }
      }
      const result = Object.keys(formData).length > 0 ? formData : true;
      closeModal(result);
    } else {
      closeModal(true);
    }
  });

  DOM.modalCancelBtn.addEventListener('click', () => {
    const state = APP_STATE;
    if (state[PRIVATE.MODAL_DATA] && state[PRIVATE.MODAL_DATA].onCancel) {
      try {
        state[PRIVATE.MODAL_DATA].onCancel();
      } catch (error) {
        console.error('❌ Ошибка в onCancel:', error);
      }
    }
    closeModal(null);
  });

  DOM.modalCloseBtn.addEventListener('click', () => {
    const state = APP_STATE;
    if (state[PRIVATE.MODAL_DATA] && state[PRIVATE.MODAL_DATA].onCancel) {
      try {
        state[PRIVATE.MODAL_DATA].onCancel();
      } catch (error) {
        console.error('❌ Ошибка в onCancel:', error);
      }
    }
    closeModal(null);
  });

  DOM.modalOverlay.addEventListener('click', e => {
    if (e.target === DOM.modalOverlay) {
      const state = APP_STATE;
      if (state[PRIVATE.MODAL_DATA] && state[PRIVATE.MODAL_DATA].onCancel) {
        try {
          state[PRIVATE.MODAL_DATA].onCancel();
        } catch (error) {
          console.error('❌ Ошибка в onCancel:', error);
        }
      }
      closeModal(null);
    }
  });

  document.addEventListener('keydown', e => {
    const state = APP_STATE;
    if (!state[PRIVATE.MODAL_ACTIVE]) return;

    if (e.key === 'Escape') {
      if (state[PRIVATE.MODAL_DATA] && state[PRIVATE.MODAL_DATA].onCancel) {
        try {
          state[PRIVATE.MODAL_DATA].onCancel();
        } catch (error) {
          console.error('❌ Ошибка в onCancel:', error);
        }
      }
      closeModal(null);
    }

    if (e.key === 'Enter') {
      const activeElement = document.activeElement;
      if (activeElement && activeElement.tagName !== 'TEXTAREA') {
        e.preventDefault();
        DOM.modalConfirmBtn.click();
      }
    }
  });
}

// ============================================================
// 10. ЛОГГЕР ПРИЛОЖЕНИЯ
// ============================================================

function addLog(message, type = 'info', detail = null) {
  const state = APP_STATE;

  if (state[PRIVATE.IS_LOG_PAUSED]) return;

  const timestamp = new Date().toLocaleTimeString('ru-RU', {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    fractionalSecondDigits: 3,
  });

  const entry = {
    timestamp,
    message,
    type,
    detail,
    id: Date.now() + Math.random(),
  };

  state[PRIVATE.LOG_ENTRIES].unshift(entry);
  if (state[PRIVATE.LOG_ENTRIES].length > state[PRIVATE.MAX_LOG]) {
    state[PRIVATE.LOG_ENTRIES].pop();
  }

  renderLog();
}

function renderLog() {
  const container = DOM.logContainer;
  const state = APP_STATE;

  // ★★★ ИСПРАВЛЕНО: проверка наличия контейнера ★★★
  if (!container) {
    console.warn('⚠️ logContainer не найден в DOM');
    return;
  }

  const entries = state[PRIVATE.LOG_ENTRIES];

  if (entries.length === 0) {
    container.innerHTML = `<div class="empty-state">Нет событий</div>`;
    return;
  }

  let html = '';
  for (const entry of entries) {
    const detailHtml = entry.detail
        ? `<span class="detail">${escapeHtml(JSON.stringify(entry.detail).substring(0, 80))}</span>`
        : '';
    html += `
            <div class="log-entry">
                <span class="time">[${entry.timestamp}]</span>
                <span class="type ${entry.type}">${entry.type.toUpperCase()}</span>
                <span class="message">${escapeHtml(entry.message)}</span>
                ${detailHtml}
            </div>
        `;
  }

  container.innerHTML = html;
  container.scrollTop = 0;
}

// ============================================================
// 11. РЕНДЕРИНГ (100% символы) С ПРОВЕРКАМИ
// ============================================================

function renderStats() {
  try {
    const state = isFunction(db.getState)
        ? db.getState()
        : { tables: [], relations: [], undoSize: 0, redoSize: 0 };
    const health = isFunction(db.healthCheck) ? db.healthCheck() : { records: 0, listeners: 0 };

    if (DOM.tablesCount) DOM.tablesCount.textContent = state.tables ? state.tables.length : 0;
    if (DOM.recordsCount) DOM.recordsCount.textContent = health.records || 0;
    if (DOM.relationsCount) DOM.relationsCount.textContent = state.relations ? state.relations.length : 0;
    if (DOM.subscribersCount) DOM.subscribersCount.textContent = health.listeners || 0;
    if (DOM.undoCount) DOM.undoCount.textContent = state.undoSize || 0;
    if (DOM.redoCount) DOM.redoCount.textContent = state.redoSize || 0;

    // ★★★ ИСПРАВЛЕНО: проверка существования метода ★★★
    const cacheStats = isFunction(db.getCacheStats) ? db.getCacheStats() : { size: 0 };
    if (DOM.cacheCount) DOM.cacheCount.textContent = cacheStats.size || 0;

    // ★★★ ИСПРАВЛЕНО: проверка существования метода ★★★
    const audit = isFunction(db.getAudit) ? db.getAudit() : [];
    if (DOM.auditCount) DOM.auditCount.textContent = audit.length;

    if (DOM.versionBadge) DOM.versionBadge.textContent = `v${state.version || CONFIG.version}`;
    if (DOM.statusBadge) {
      DOM.statusBadge.textContent = health.ready ? '● Готов' : '● Ошибка';
      DOM.statusBadge.className = `badge ${health.ready ? 'success' : 'error'}`;
    }
  } catch (error) {
    console.warn('⚠️ Ошибка рендеринга статистики:', error);
  }
}

function renderTables() {
  try {
    const tables = isFunction(db.listTables) ? db.listTables() : [];
    const container = DOM.tablesList;
    const state = APP_STATE;
    const selectedTable = state[PRIVATE.SELECTED_TABLE];

    if (!container) return;

    if (tables.length === 0) {
      container.innerHTML = `
                <div class="empty-state">
                    <span class="emoji">📭</span>
                    Нет таблиц
                    <span style="display:block;font-size:11px;color:#3a4a6a;margin-top:4px;">
                        Нажмите «➕» для создания
                    </span>
                </div>
            `;
      if (DOM.tablesInfo) DOM.tablesInfo.textContent = 'Нет таблиц';
      return;
    }

    let html = '';
    for (const name of tables) {
      const table = isFunction(db.getTable) ? db.getTable(name) : null;
      const count = table ? table.data.length : 0;
      const isActive = name === selectedTable;
      const hasSchema = isFunction(db.getSchema) ? !!db.getSchema(name) : false;

      html += `
                <div class="table-item ${isActive ? 'active' : ''}" data-table="${name}">
                    <span class="name">📋 ${escapeHtml(name)} ${hasSchema ? '📐' : ''}</span>
                    <div style="display:flex;align-items:center;gap:6px;">
                        <span class="count">${count}</span>
                        <div class="actions">
                            <button class="danger" data-table="${name}" title="Удалить таблицу">🗑</button>
                        </div>
                    </div>
                </div>
            `;
    }

    container.innerHTML = html;
    if (DOM.tablesInfo) DOM.tablesInfo.textContent = `${tables.length} таблиц`;

    container.querySelectorAll('.table-item').forEach(el => {
      el.addEventListener('click', e => {
        if (e.target.closest('.actions')) return;
        const name = el.dataset.table;
        selectTable(name);
      });
    });

    container.querySelectorAll('.actions .danger').forEach(el => {
      el.addEventListener('click', e => {
        e.stopPropagation();
        const name = el.dataset.table;
        if (confirm(`Удалить таблицу \"${name}\" со всеми данными?`)) {
          if (isFunction(db.dropTable)) db.dropTable(name);
          const state = APP_STATE;
          if (state[PRIVATE.SELECTED_TABLE] === name) {
            state[PRIVATE.SELECTED_TABLE] = null;
            renderData();
          }
          renderAll();
        }
      });
    });
  } catch (error) {
    console.warn('⚠️ Ошибка рендеринга таблиц:', error);
  }
}

function renderData() {
  try {
    const container = DOM.dataContainer;
    const state = APP_STATE;
    const selectedTable = state[PRIVATE.SELECTED_TABLE];

    if (!container) return;

    if (!selectedTable) {
      container.innerHTML = `
                <div class="empty-state">
                    <span class="emoji">📋</span>
                    Выберите таблицу из списка слева
                </div>
            `;
      if (DOM.currentTableTitle) DOM.currentTableTitle.textContent = '📊 Данные';
      if (DOM.addRowBtn) DOM.addRowBtn.disabled = true;
      return;
    }

    const table = isFunction(db.getTable) ? db.getTable(selectedTable) : null;
    if (!table) {
      container.innerHTML = `<div class="empty-state" style="color:#ef4444;">❌ Таблица не найдена</div>`;
      if (DOM.addRowBtn) DOM.addRowBtn.disabled = true;
      return;
    }

    if (DOM.currentTableTitle) {
      DOM.currentTableTitle.textContent = `📊 ${escapeHtml(selectedTable)} (${table.data.length} записей)`;
    }
    if (DOM.addRowBtn) DOM.addRowBtn.disabled = false;

    if (table.data.length === 0) {
      container.innerHTML = `
                <div class="empty-state">
                    <span class="emoji">📭</span>
                    Нет данных в таблице
                </div>
            `;
      return;
    }

    const firstRow = table.data[0];
    const columns = Object.keys(firstRow);
    const selectedId = isFunction(db.getSelection) ? db.getSelection(selectedTable) : null;

    let html = `<table class="data-table"><thead><tr>`;
    html += `<th style="width:30px;">#</th>`;
    for (const col of columns) {
      html += `<th>${escapeHtml(col)}</th>`;
    }
    html += `<th style="width:80px;">Действия</th></tr></thead><tbody>`;

    for (let i = 0; i < table.data.length; i++) {
      const row = table.data[i];
      const isSelected = row.id === selectedId;

      html += `<tr class="${isSelected ? 'selected' : ''}" data-id="${escapeHtml(row.id)}">`;
      html += `<td class="id-col">${i + 1}</td>`;

      for (const col of columns) {
        const value = row[col];
        let display = value;
        if (typeof value === 'object' && value !== null) {
          display = JSON.stringify(value).substring(0, 50);
        }
        if (col === 'id') {
          html += `<td class="id-col" title="${escapeHtml(String(display))}">${escapeHtml(String(display).substring(0, 12))}</td>`;
        } else {
          html += `<td title="${escapeHtml(String(display))}">${escapeHtml(String(display))}</td>`;
        }
      }

      html += `
                <td>
                    <div class="actions-col">
                        <button class="select-btn" data-id="${escapeHtml(row.id)}" title="Выделить">🎯</button>
                        <button class="danger delete-btn" data-id="${escapeHtml(row.id)}" title="Удалить">🗑</button>
                    </div>
                </td>
            </tr>`;
    }

    html += `</tbody></table>`;
    container.innerHTML = html;

    container.querySelectorAll('.select-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const id = btn.dataset.id;
        if (isFunction(db.selectRow)) db.selectRow(selectedTable, id);
        const state = APP_STATE;
        state[PRIVATE.SELECTED_ROW] = id;
        renderData();
        renderInspector();
      });
    });

    container.querySelectorAll('.delete-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const id = btn.dataset.id;
        if (confirm(`Удалить строку с ID: ${id}?`)) {
          if (isFunction(db.delete)) db.delete(selectedTable, { id });
          renderAll();
        }
      });
    });

    container.querySelectorAll('tbody tr').forEach(el => {
      el.addEventListener('click', () => {
        const id = el.dataset.id;
        if (id) {
          if (isFunction(db.selectRow)) db.selectRow(selectedTable, id);
          const state = APP_STATE;
          state[PRIVATE.SELECTED_ROW] = id;
          renderData();
          renderInspector();
        }
      });
    });
  } catch (error) {
    console.warn('⚠️ Ошибка рендеринга данных:', error);
  }
}

function renderInspector() {
  try {
    const container = DOM.inspectorContent;
    const state = APP_STATE;
    const selectedTable = state[PRIVATE.SELECTED_TABLE];
    const selectedRow = state[PRIVATE.SELECTED_ROW];

    if (!container) return;

    if (!selectedRow || !selectedTable) {
      container.innerHTML = `
                <div class="empty-state">
                    <span class="emoji">🔍</span>
                    Выберите строку для просмотра
                </div>
            `;
      return;
    }

    const table = isFunction(db.getTable) ? db.getTable(selectedTable) : null;
    if (!table) return;

    const row = table.data.find(r => r.id === selectedRow);
    if (!row) {
      container.innerHTML = `
                <div class="empty-state">
                    <span class="emoji">🔍</span>
                    Строка не найдена
                </div>
            `;
      return;
    }

    let html = `
            <div style="font-size:11px;color:#4a5a7a;margin-bottom:8px;">
                🆔 ${escapeHtml(row.id)}
                <span style="margin-left:12px;">📊 ${escapeHtml(selectedTable)}</span>
            </div>
            <div style="background:#0b0e14;border-radius:6px;border:1px solid #1e2633;padding:8px;font-family:monospace;font-size:11px;overflow-x:auto;">
                <pre style="color:#8b96b0;margin:0;white-space:pre-wrap;word-break:break-all;">${escapeHtml(formatJson(row))}</pre>
            </div>
        `;

    container.innerHTML = html;
  } catch (error) {
    console.warn('⚠️ Ошибка рендеринга инспектора:', error);
  }
}

function renderRelations() {
  try {
    const container = DOM.relationsContainer;
    if (!container) return;

    let relations = {};
    try {
      const p = db._;
      if (p) {
        relations = p[Symbol('store.relations')] || {};
      }
    } catch (e) {
      relations = {};
    }

    const entries = Object.entries(relations);
    if (entries.length === 0) {
      container.innerHTML = `<div class="empty-state">Нет связей</div>`;
      return;
    }

    let html = '';
    for (const [key, rel] of entries) {
      const detailsCount = rel.details ? rel.details.length : 0;
      const isActive = rel.masterId !== null && rel.masterId !== undefined;
      const masterName = rel.masterData?.name || rel.masterData?.title || rel.masterId || '—';

      html += `
                <div class="relation-item">
                    <div>
                        <span class="master">${escapeHtml(rel.master)}</span>
                        <span class="arrow">→</span>
                        <span class="detail">${escapeHtml(rel.detail)}</span>
                        <span class="key">(ключ: ${escapeHtml(rel.key)})</span>
                        ${isActive ? `<span class="active">● активен</span>` : ''}
                    </div>
                    <div style="font-size:10px;color:#4a5a7a;margin-top:2px;">
                        ${isActive ? `Мастер: ${escapeHtml(masterName)} • Деталей: ${detailsCount}` : 'Не выбран мастер'}
                    </div>
                </div>
            `;
    }

    container.innerHTML = html;
  } catch (error) {
    console.warn('⚠️ Ошибка рендеринга связей:', error);
  }
}

function renderSubscriptions() {
  try {
    const container = DOM.subscriptionsList;
    if (!container) return;

    // ★★★ ИСПРАВЛЕНО: проверка существования метода ★★★
    const subs = isFunction(db.getSubscribers) ? db.getSubscribers('*') : [];

    if (subs.length === 0) {
      container.innerHTML = `<div class="empty-state">Нет подписок</div>`;
      return;
    }

    let html = '';
    for (const sub of subs) {
      html += `
                <div style="display:flex;justify-content:space-between;align-items:center;padding:4px 8px;border-bottom:1px solid #161e2a;font-size:11px;">
                    <span>
                        <span style="color:#60a5fa;">${escapeHtml(sub.topic)}</span>
                        <span style="color:#4a5a7a;font-size:10px;">ID: ${escapeHtml(sub.id)}</span>
                    </span>
                    <button class="btn btn-danger btn-xs unsubscribe-btn" data-id="${escapeHtml(sub.id)}">✕</button>
                </div>
            `;
    }

    container.innerHTML = html;

    container.querySelectorAll('.unsubscribe-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const id = btn.dataset.id;
        if (isFunction(db.unsubscribe)) db.unsubscribe(id);
        renderSubscriptions();
      });
    });
  } catch (error) {
    console.warn('⚠️ Ошибка рендеринга подписок:', error);
  }
}

function renderMessages() {
  try {
    const container = DOM.messagesContainer;
    const state = APP_STATE;
    const messages = state[PRIVATE.MESSAGES];

    if (!container) return;

    if (messages.length === 0) {
      container.innerHTML = `<div class="empty-state">Нет сообщений</div>`;
      if (DOM.messagesCount) DOM.messagesCount.textContent = '0';
      return;
    }

    let html = '';
    const recentMessages = messages.slice(-50);
    for (const msg of recentMessages) {
      html += `
                <div style="padding:4px 8px;border-bottom:1px solid #161e2a;font-size:11px;font-family:monospace;">
                    <span style="color:#4a5a7a;">[${formatTime(msg.timestamp)}]</span>
                    <span style="color:#60a5fa;">${escapeHtml(msg.topic)}</span>
                    <span style="color:#8b96b0;">→</span>
                    <span style="color:#34d399;">${escapeHtml(formatJson(msg.data).substring(0, 100))}</span>
                </div>
            `;
    }

    container.innerHTML = html;
    if (DOM.messagesCount) DOM.messagesCount.textContent = recentMessages.length;
  } catch (error) {
    console.warn('⚠️ Ошибка рендеринга сообщений:', error);
  }
}

function renderAudit() {
  try {
    const container = DOM.auditContainer;
    if (!container) return;

    // ★★★ ИСПРАВЛЕНО: проверка существования метода ★★★
    const audit = isFunction(db.getAudit) ? db.getAudit({}, 100) : [];

    if (audit.length === 0) {
      container.innerHTML = `<div class="empty-state">Нет записей аудита</div>`;
      return;
    }

    let html = '';
    for (const entry of audit) {
      html += `
                <div style="display:flex;justify-content:space-between;align-items:center;padding:4px 8px;border-bottom:1px solid #161e2a;font-size:11px;font-family:monospace;">
                    <span>
                        <span style="color:#4a5a7a;">[${formatTime(entry.timestamp)}]</span>
                        <span style="color:#a78bfa;">${escapeHtml(entry.action)}</span>
                        <span style="color:#8b96b0;">${escapeHtml(formatJson(entry.data).substring(0, 50))}</span>
                    </span>
                    <span style="color:#4a5a7a;font-size:10px;">${escapeHtml(entry.userId || 'anonymous')}</span>
                </div>
            `;
    }

    container.innerHTML = html;
  } catch (error) {
    console.warn('⚠️ Ошибка рендеринга аудита:', error);
  }
}

function renderSchemas() {
  try {
    const container = DOM.schemasContainer;
    if (!container) return;

    const tables = isFunction(db.listTables) ? db.listTables() : [];
    const hasSchemas = tables.some(t => (isFunction(db.getSchema) ? db.getSchema(t) : false));

    if (!hasSchemas) {
      container.innerHTML = `<div class="empty-state">Нет схем</div>`;
      return;
    }

    let html = '';
    for (const name of tables) {
      const schema = isFunction(db.getSchema) ? db.getSchema(name) : null;
      if (!schema) continue;

      html += `
                <div style="background:#0b0e14;border-radius:6px;border:1px solid #1e2633;padding:10px 12px;margin-bottom:6px;">
                    <div style="font-size:13px;font-weight:500;color:#c8d0e0;margin-bottom:6px;">
                        📐 ${escapeHtml(name)}
                    </div>
                    <div style="font-family:monospace;font-size:11px;color:#8b96b0;white-space:pre-wrap;word-break:break-all;">
                        ${escapeHtml(formatJson(schema))}
                    </div>
                </div>
            `;
    }

    container.innerHTML = html;
  } catch (error) {
    console.warn('⚠️ Ошибка рендеринга схем:', error);
  }
}

function renderPlugins() {
  try {
    const container = DOM.pluginsContainer;
    if (!container) return;

    const plugins = isFunction(db.listPlugins) ? db.listPlugins() : [];

    if (plugins.length === 0) {
      container.innerHTML = `<div class="empty-state">Нет плагинов</div>`;
      return;
    }

    let html = '';
    for (const name of plugins) {
      const plugin = isFunction(db.getPlugin) ? db.getPlugin(name) : null;
      html += `
                <div style="display:flex;justify-content:space-between;align-items:center;padding:6px 10px;background:#0b0e14;border-radius:6px;border:1px solid #1e2633;margin-bottom:4px;">
                    <span>
                        <span style="color:#60a5fa;">🔌 ${escapeHtml(name)}</span>
                        <span style="color:#4a5a7a;font-size:10px;margin-left:8px;">
                            ${plugin ? '✅ активен' : '❌ неактивен'}
                        </span>
                    </span>
                </div>
            `;
    }

    container.innerHTML = html;
  } catch (error) {
    console.warn('⚠️ Ошибка рендеринга плагинов:', error);
  }
}

function renderSettings() {
  try {
    const quotas = isFunction(db.getQuotas) ? db.getQuotas() : {};
    const state = isFunction(db.getState) ? db.getState() : {};

    if (DOM.quotasDisplay) {
      DOM.quotasDisplay.innerHTML = `
                <div style="font-size:12px;color:#8b96b0;line-height:2;">
                    <div>📊 Максимум записей: <span style="color:#c8d0e0;">${quotas.maxRecords || 10000}</span></div>
                    <div>📋 Максимум таблиц: <span style="color:#c8d0e0;">${quotas.maxTables || 50}</span></div>
                    <div>💾 Версия: <span style="color:#c8d0e0;">${state.version || CONFIG.version}</span></div>
                    <div>📦 Плагинов: <span style="color:#c8d0e0;">${state.plugins ? state.plugins.length : 0}</span></div>
                </div>
            `;
    }

    if (DOM.infoDisplay) {
      DOM.infoDisplay.innerHTML = `
                <div style="font-size:12px;color:#8b96b0;line-height:2;">
                    <div>🏢 Store: <span style="color:#c8d0e0;">Global Store</span></div>
                    <div>📊 Таблиц: <span style="color:#c8d0e0;">${state.tables ? state.tables.length : 0}</span></div>
                    <div>📝 Записей: <span style="color:#c8d0e0;">${isFunction(db.healthCheck) ? db.healthCheck().records || 0 : 0}</span></div>
                    <div>🔗 Связей: <span style="color:#c8d0e0;">${state.relations ? state.relations.length : 0}</span></div>
                    <div>📡 Подписчиков: <span style="color:#c8d0e0;">${isFunction(db.healthCheck) ? db.healthCheck().listeners || 0 : 0}</span></div>
                    <div>🔑 Символ: <span style="color:#34d399;">__GLOBAL_STORE__</span></div>
                </div>
            `;
    }
  } catch (error) {
    console.warn('⚠️ Ошибка рендеринга настроек:', error);
  }
}

function renderAll() {
  renderStats();
  renderTables();
  renderData();
  renderInspector();
  renderRelations();
  renderSubscriptions();
  renderMessages();
  renderAudit();
  renderSchemas();
  renderPlugins();
  renderSettings();
}

// ============================================================
// 12. УПРАВЛЕНИЕ ТАБЛИЦАМИ
// ============================================================

function selectTable(name) {
  const state = APP_STATE;
  state[PRIVATE.SELECTED_TABLE] = name;
  state[PRIVATE.SELECTED_ROW] = null;
  renderAll();
}

function showAddRowModal() {
  const state = APP_STATE;
  const selectedTable = state[PRIVATE.SELECTED_TABLE];

  if (!selectedTable) {
    alert('⚠️ Сначала выберите таблицу');
    return;
  }

  const table = isFunction(db.getTable) ? db.getTable(selectedTable) : null;
  if (!table) {
    alert(`⚠️ Таблица \"${selectedTable}\" не найдена`);
    return;
  }

  const fields = table.data.length > 0 ? Object.keys(table.data[0]) : ['id', 'name', 'value'];

  let formHtml = '';
  for (const field of fields) {
    const placeholder = field === 'id' ? `auto_${Date.now().toString(36)}` : '';
    const isId = field === 'id';
    formHtml += `
            <div class="form-group">
                <label>${escapeHtml(field)}</label>
                <input type="text" id="field_${escapeHtml(field)}" placeholder="${escapeHtml(placeholder)}" value="${isId ? '' : ''}">
            </div>
        `;
  }

  showModal(
      `➕ Добавить в \"${selectedTable}\"`,
      formHtml,
      data => {
        const row = {};
        let hasData = false;

        for (const field of fields) {
          const inputId = `field_${escapeHtml(field)}`;
          const value = data[inputId] || '';
          if (value) {
            if (field === 'id' && !value) {
              row[field] = `row_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`;
            } else {
              row[field] = value;
            }
            hasData = true;
          } else if (field === 'id') {
            row[field] = `row_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`;
          }
        }

        if (!hasData && Object.keys(row).length === 0) {
          alert('⚠️ Заполните хотя бы одно поле');
          return;
        }

        try {
          if (isFunction(db.insert)) db.insert(selectedTable, row);
          renderAll();
        } catch (error) {
          alert(`❌ Ошибка: ${error.message}`);
        }
      },
      () => {
        console.log('❌ Добавление отменено');
      }
  );
}

function showCreateTableModal(withSchema = false) {
  const formHtml = `
        <div class="form-group">
            <label>Название таблицы *</label>
            <input type="text" id="tableName" placeholder="my_table" value="table_${Date.now().toString(36)}">
        </div>
        ${
      withSchema
          ? `
            <div class="form-group">
                <label>Схема (JSON)</label>
                <textarea id="tableSchema" rows="8" style="width:100%;background:#0b0e14;border:1px solid #1e2633;border-radius:4px;color:#c8d0e0;font-size:12px;font-family:monospace;padding:8px;">{
    "id": { "type": "string", "required": true },
    "name": { "type": "string", "required": true },
    "email": { "type": "email" },
    "age": { "type": "number", "min": 0, "max": 150 },
    "status": { "type": "string", "enum": ["active", "inactive", "pending"] }
}</textarea>
            </div>
            <div class="form-group">
                <label>Индексы (массив полей)</label>
                <input type="text" id="tableIndexes" placeholder='["name", "email"]' value='["name", "email"]'>
            </div>
        `
          : ''
  }
    `;

  showModal(
      withSchema ? '📐 Создать таблицу со схемой' : '📊 Создать таблицу',
      formHtml,
      data => {
        const name = data.tableName || '';
        if (!name) {
          alert('⚠️ Введите название таблицы');
          return;
        }

        if (isFunction(db.getTable) && db.getTable(name)) {
          alert(`⚠️ Таблица \"${name}\" уже существует`);
          return;
        }

        let options = {};

        if (withSchema) {
          try {
            const schemaText = data.tableSchema || '';
            if (schemaText) {
              options.schema = JSON.parse(schemaText);
            }

            const indexesText = data.tableIndexes || '';
            if (indexesText) {
              options.indexes = JSON.parse(indexesText);
            }
          } catch (error) {
            alert(`❌ Ошибка парсинга: ${error.message}`);
            return;
          }
        }

        if (isFunction(db.createTable)) db.createTable(name, options);
        const state = APP_STATE;
        state[PRIVATE.SELECTED_TABLE] = name;
        renderAll();
      },
      () => {
        console.log('❌ Создание таблицы отменено');
      }
  );
}

function showLinkTablesModal() {
  const tables = isFunction(db.listTables) ? db.listTables() : [];

  if (tables.length < 2) {
    alert('⚠️ Нужно минимум 2 таблицы для связывания');
    return;
  }

  const optionsHtml = tables.map(name => `<option value="${name}">${name}</option>`).join('');

  const formHtml = `
        <div class="form-group">
            <label>Мастер-таблица *</label>
            <select id="masterTable">${optionsHtml}</select>
        </div>
        <div class="form-group">
            <label>Детейл-таблица *</label>
            <select id="detailTable">${optionsHtml}</select>
        </div>
        <div class="form-group">
            <label>Ключ связи</label>
            <input type="text" id="relationKey" value="masterId">
        </div>
    `;

  showModal(
      '🔗 Связать таблицы',
      formHtml,
      data => {
        const master = data.masterTable || '';
        const detail = data.detailTable || '';
        const key = data.relationKey || 'masterId';

        if (master === detail) {
          alert('⚠️ Таблицы должны быть разными');
          return;
        }

        if (isFunction(db.link)) db.link(master, detail, key);
        renderAll();
      },
      () => {
        console.log('❌ Связывание отменено');
      }
  );
}

// ============================================================
// 13. УПРАВЛЕНИЕ БРОКЕРОМ
// ============================================================

function publishMessage() {
  const topic = DOM.brokerTopic.value.trim();
  if (!topic) {
    alert('⚠️ Введите топик');
    return;
  }

  let data;
  try {
    data = JSON.parse(DOM.brokerData.value);
  } catch {
    data = { message: DOM.brokerData.value };
  }

  if (isFunction(db.publish)) {
    db.publish(topic, data);
    const state = APP_STATE;
    state[PRIVATE.MESSAGES].push({ topic, data, timestamp: Date.now() });
    renderMessages();
    addLog(`📨 Сообщение опубликовано: ${topic}`, 'success');
  }
}

function addSubscription() {
  const topic = prompt('📨 Введите топик для подписки:', 'test:*');
  if (!topic) return;

  if (isFunction(db.subscribe)) {
    const id = db.subscribe(topic, (data, message) => {
      const state = APP_STATE;
      state[PRIVATE.MESSAGES].push({ topic, data, timestamp: Date.now() });
      renderMessages();
      addLog(`📨 Получено сообщение из ${topic}`, 'info');
    });
    const state = APP_STATE;
    state[PRIVATE.SUBSCRIPTIONS].push(id);
    renderSubscriptions();
    addLog(`📡 Подписка создана: ${topic} (ID: ${id})`, 'success');
  }
}

function clearMessages() {
  const state = APP_STATE;
  state[PRIVATE.MESSAGES] = [];
  renderMessages();
  addLog('🧹 Сообщения очищены', 'info');
}

// ============================================================
// 14. КОНСОЛЬ
// ============================================================

function executeCommand() {
  const input = DOM.consoleInput.value.trim();
  if (!input) return;

  const output = DOM.consoleOutput;

  const cmdEntry = document.createElement('div');
  cmdEntry.style.cssText = 'color:#60a5fa;margin:4px 0;';
  cmdEntry.textContent = `▶ ${input}`;
  output.appendChild(cmdEntry);

  try {
    const result = eval(input);

    const resultEntry = document.createElement('div');
    resultEntry.style.cssText =
        'color:#34d399;margin:2px 0 8px 16px;white-space:pre-wrap;word-break:break-all;';

    if (result === undefined) {
      resultEntry.textContent = '✅ Выполнено (undefined)';
    } else if (typeof result === 'object') {
      resultEntry.textContent = formatJson(result);
    } else {
      resultEntry.textContent = String(result);
    }

    output.appendChild(resultEntry);
    renderAll();
    addLog(`💻 Выполнено: ${input}`, 'success', result);
  } catch (error) {
    const errorEntry = document.createElement('div');
    errorEntry.style.cssText = 'color:#ef4444;margin:2px 0 8px 16px;';
    errorEntry.textContent = `❌ Ошибка: ${error.message}`;
    output.appendChild(errorEntry);
    addLog(`❌ Ошибка: ${error.message}`, 'error');
  }

  DOM.consoleInput.value = '';
  output.scrollTop = output.scrollHeight;
}

function clearConsole() {
  DOM.consoleOutput.innerHTML = `<div style="color:#4a5a7a;">💡 Введите команду ниже...</div>`;
  addLog('🧹 Консоль очищена', 'info');
}

// ============================================================
// 15. ЭКСПОРТ ДАННЫХ
// ============================================================

function exportData() {
  const state = APP_STATE;
  const selectedTable = state[PRIVATE.SELECTED_TABLE];

  if (!selectedTable) {
    alert('⚠️ Сначала выберите таблицу');
    return;
  }

  const table = isFunction(db.getTable) ? db.getTable(selectedTable) : null;
  if (!table) return;

  const data = {
    table: selectedTable,
    data: table.data,
    meta: table.meta,
    exportedAt: Date.now(),
    version: CONFIG.version,
  };

  const json = JSON.stringify(data, null, 2);
  const blob = new Blob([json], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `${selectedTable}_${new Date().toISOString().slice(0, 10)}.json`;
  a.click();
  URL.revokeObjectURL(url);
  addLog(`📤 Данные экспортированы: ${selectedTable}`, 'success');
}

function exportAudit() {
  const audit = isFunction(db.getAudit) ? db.getAudit() : [];
  const json = JSON.stringify(audit, null, 2);
  const blob = new Blob([json], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `audit_${new Date().toISOString().slice(0, 10)}.json`;
  a.click();
  URL.revokeObjectURL(url);
  addLog('📤 Аудит экспортирован', 'success');
}

// ============================================================
// 16. ТАБЫ
// ============================================================

function switchTab(tabName) {
  const state = APP_STATE;
  state[PRIVATE.ACTIVE_TAB] = tabName;

  document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
  document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));

  const tabBtn = document.querySelector(`.tab[data-tab="${tabName}"]`);
  if (tabBtn) tabBtn.classList.add('active');

  const tabContent = document.getElementById(`tab-${tabName}`);
  if (tabContent) tabContent.classList.add('active');

  if (tabName === 'relations') renderRelations();
  if (tabName === 'broker') renderMessages();
  if (tabName === 'audit') renderAudit();
  if (tabName === 'schema') renderSchemas();
  if (tabName === 'plugins') renderPlugins();
  if (tabName === 'settings') renderSettings();
  if (tabName === 'logs') renderLog();
}

// ============================================================
// 17. ИНИЦИАЛИЗАЦИЯ ДЕМО-ДАННЫХ
// ============================================================

function initDemoData() {
  const state = APP_STATE;

  if (state[PRIVATE.DEMO_LOADED]) {
    addLog('📦 Демо-данные уже загружены', 'info');
    return;
  }

  if (!db) {
    addLog('⚠️ Хранилище не доступно, пропускаем загрузку демо-данных', 'warn');
    return;
  }

  if (!isFunction(db.listTables)) {
    addLog('⚠️ Метод listTables не доступен, пропускаем загрузку демо-данных', 'warn');
    return;
  }

  try {
    const tables = db.listTables();
    if (tables && tables.length > 0) {
      addLog('📦 Данные уже загружены', 'info');
      state[PRIVATE.DEMO_LOADED] = true;
      return;
    }
  } catch (error) {
    addLog(`⚠️ Ошибка проверки таблиц: ${error.message}`, 'warn');
    return;
  }

  addLog('📦 Загрузка демо-данных...', 'info');

  try {
    if (isFunction(db.createTable)) {
      db.createTable('projects');
      db.createTable('tasks');
      db.createTable('users');
    } else {
      addLog('⚠️ Метод createTable не доступен', 'warn');
      return;
    }

    if (isFunction(db.insert)) {
      db.insert('projects', [
        { id: 'p1', name: '🚀 Проект Alpha', status: 'active', priority: 1 },
        { id: 'p2', name: '📊 Проект Beta', status: 'active', priority: 2 },
        { id: 'p3', name: '🔧 Проект Gamma', status: 'inactive', priority: 3 },
      ]);

      db.insert('tasks', [
        { id: 't1', projectId: 'p1', title: 'Настройка инфраструктуры', status: 'done' },
        { id: 't2', projectId: 'p1', title: 'Разработка API', status: 'in-progress' },
        { id: 't3', projectId: 'p2', title: 'Дизайн интерфейса', status: 'pending' },
      ]);

      db.insert('users', [
        { id: 'u1', name: 'Иван Иванов', role: 'developer', active: true },
        { id: 'u2', name: 'Петр Петров', role: 'developer', active: true },
        { id: 'u3', name: 'Мария Сидорова', role: 'manager', active: true },
      ]);
    } else {
      addLog('⚠️ Метод insert не доступен', 'warn');
      return;
    }

    if (isFunction(db.link)) {
      db.link('projects', 'tasks', 'projectId');
    }

    if (isFunction(db.select)) {
      db.select('projects', 'p1');
    }

    state[PRIVATE.SELECTED_TABLE] = 'projects';
    state[PRIVATE.DEMO_LOADED] = true;
    addLog('✅ Демо-данные загружены', 'success');
  } catch (error) {
    addLog(`⚠️ Ошибка загрузки демо-данных: ${error.message}`, 'warn');
    console.warn('⚠️ Ошибка загрузки демо-данных:', error);
  }
}

// ============================================================
// 18. ЭКСПОРТ СИМВОЛОВ
// ============================================================

function exportSymbols() {
  if (typeof window !== 'undefined') {
    window.__APP_SYMBOLS = {
      PRIVATE: { ...PRIVATE },
      PUBLIC: { ...PUBLIC },
    };

    window[PUBLIC.INSTANCE] = {
      [PUBLIC.INIT]: init,
      [PUBLIC.DESTROY]: destroy,
      [PUBLIC.RENDER]: renderAll,
      [PUBLIC.GET_STATE]: getState,
      [PUBLIC.HEALTH_CHECK]: healthCheck,
      [PUBLIC.SHOW_MODAL]: showModal,
      [PUBLIC.CLOSE_MODAL]: closeModal,
      [PUBLIC.SELECT_TABLE]: selectTable,
      [PUBLIC.ADD_ROW]: showAddRowModal,
      [PUBLIC.CREATE_TABLE]: showCreateTableModal,
      [PUBLIC.EXECUTE_COMMAND]: executeCommand,
      [PUBLIC.CLEAR_CONSOLE]: clearConsole,
      [PUBLIC.INIT_DEMO]: initDemoData,
      [PUBLIC.GET_GLOBAL_STORE]: getGlobalStore,
    };
  }
}

// ============================================================
// 19. СОСТОЯНИЕ И HEALTH CHECK
// ============================================================

function getState() {
  const state = APP_STATE;
  return {
    selectedTable: state[PRIVATE.SELECTED_TABLE],
    selectedRow: state[PRIVATE.SELECTED_ROW],
    activeTab: state[PRIVATE.ACTIVE_TAB],
    isLogPaused: state[PRIVATE.IS_LOG_PAUSED],
    logCount: state[PRIVATE.LOG_ENTRIES].length,
    messagesCount: state[PRIVATE.MESSAGES].length,
    subscriptionsCount: state[PRIVATE.SUBSCRIPTIONS].length,
    modalActive: state[PRIVATE.MODAL_ACTIVE],
    initialized: state[PRIVATE.INITIALIZED],
    destroyed: state[PRIVATE.DESTROYED],
    startTime: state[PRIVATE.START_TIME],
    lastUpdate: state[PRIVATE.LAST_UPDATE],
    demoLoaded: state[PRIVATE.DEMO_LOADED],
    globalStoreReady: state[PRIVATE.GLOBAL_STORE_READY],
    version: CONFIG.version,
  };
}

function healthCheck() {
  const state = APP_STATE;
  return {
    initialized: state[PRIVATE.INITIALIZED],
    destroyed: state[PRIVATE.DESTROYED],
    ready: state[PRIVATE.INITIALIZED] && !state[PRIVATE.DESTROYED],
    dbReady: !!db,
    logCount: state[PRIVATE.LOG_ENTRIES].length,
    messagesCount: state[PRIVATE.MESSAGES].length,
    modalActive: state[PRIVATE.MODAL_ACTIVE],
    demoLoaded: state[PRIVATE.DEMO_LOADED],
    globalStoreReady: state[PRIVATE.GLOBAL_STORE_READY],
    uptime: Date.now() - state[PRIVATE.START_TIME],
    version: CONFIG.version,
    timestamp: Date.now(),
  };
}

function getGlobalStore() {
  const state = APP_STATE;
  if (typeof window !== 'undefined') {
    const globalStore = window[GLOBAL_STORE_SYMBOL];
    if (globalStore) {
      state[PRIVATE.GLOBAL_STORE_READY] = true;
      return globalStore;
    }
  }
  state[PRIVATE.GLOBAL_STORE_READY] = false;
  return null;
}

// ============================================================
// 20. УНИЧТОЖЕНИЕ
// ============================================================

function destroy() {
  const state = APP_STATE;

  if (state[PRIVATE.DESTROYED]) {
    console.warn('⚠️ Приложение уже уничтожено');
    return;
  }

  state[PRIVATE.DESTROYED] = true;
  state[PRIVATE.INITIALIZED] = false;
  state[PRIVATE.MODAL_ACTIVE] = false;
  state[PRIVATE.LOG_ENTRIES] = [];
  state[PRIVATE.MESSAGES] = [];
  state[PRIVATE.SUBSCRIPTIONS] = [];
  state[PRIVATE.DEMO_LOADED] = false;
  state[PRIVATE.GLOBAL_STORE_READY] = false;

  if (typeof window !== 'undefined') {
    delete window.__APP_SYMBOLS;
    delete window[PUBLIC.INSTANCE];
  }

  addLog('🧹 Приложение уничтожено', 'info');
  console.log('✅ Приложение уничтожено');
}

// ============================================================
// 21. ИНИЦИАЛИЗАЦИЯ
// ============================================================

function init() {
  const state = APP_STATE;

  if (state[PRIVATE.INITIALIZED]) {
    console.warn('⚠️ Приложение уже инициализировано');
    return;
  }

  const logger = createLogger(CONFIG.debug, CONFIG.name);
  logger.header('ИНИЦИАЛИЗАЦИЯ ПРИЛОЖЕНИЯ (100% СИМВОЛЫ)');
  logger.info(`📦 Версия: ${CONFIG.version}`);
  logger.info(`📅 Сборка: ${CONFIG.build}`);
  logger.separator();

  // ★★★ ПРОВЕРКА DB ★★★
  if (!db) {
    logger.error('❌ Хранилище не доступно!');
    alert('❌ Ошибка: Хранилище не доступно. Перезагрузите страницу.');
    return;
  }

  // ★★★ ПРОВЕРКА МЕТОДОВ DB ★★★
  const requiredMethods = ['listTables', 'getTable', 'createTable', 'insert', 'select'];
  const missingMethods = requiredMethods.filter(method => !isFunction(db[method]));

  if (missingMethods.length > 0) {
    logger.warn(`⚠️ Отсутствуют методы: ${missingMethods.join(', ')}`);
    logger.info('🔄 Пытаемся инициализировать хранилище...');

    if (isFunction(createStore)) {
      try {
        const newStore = createStore({
          plugins: DEFAULT_PLUGINS,
          devtools: false,
        });
        Object.assign(db, newStore);
        logger.success('✅ Хранилище создано');
      } catch (error) {
        if (error.message && error.message.includes('Redux devtools')) {
          logger.warn('⚠️ Redux Devtools не установлен, создаем хранилище без него');
          try {
            const newStore = createStore({
              plugins: DEFAULT_PLUGINS,
              devtools: false,
            });
            Object.assign(db, newStore);
            logger.success('✅ Хранилище создано (без Devtools)');
          } catch (innerError) {
            logger.error(`❌ Ошибка создания хранилища: ${innerError.message}`);
            alert('❌ Ошибка инициализации хранилища. Перезагрузите страницу.');
            return;
          }
        } else {
          logger.error(`❌ Ошибка создания хранилища: ${error.message}`);
          alert('❌ Ошибка инициализации хранилища. Перезагрузите страницу.');
          return;
        }
      }
    }
  }

  // ★★★ ПРОВЕРКА ГЛОБАЛЬНОГО ХРАНИЛИЩА ★★★
  if (typeof window !== 'undefined') {
    const globalStore = window[GLOBAL_STORE_SYMBOL];
    if (globalStore) {
      state[PRIVATE.GLOBAL_STORE_READY] = true;
      logger.success('✅ Глобальное хранилище найдено');
    } else {
      state[PRIVATE.GLOBAL_STORE_READY] = false;
      logger.info('ℹ️ Глобальное хранилище не найдено, будет создано');
      window[GLOBAL_STORE_SYMBOL] = db;
      state[PRIVATE.GLOBAL_STORE_READY] = true;
      logger.success('✅ Глобальное хранилище создано');
    }
  }

  // Настраиваем модальное окно
  setupModal();

  // Переключатели табов
  DOM.tabs.addEventListener('click', e => {
    const tab = e.target.closest('.tab');
    if (tab) {
      switchTab(tab.dataset.tab);
    }
  });

  // Кнопки управления
  DOM.refreshBtn.addEventListener('click', () => {
    renderAll();
    addLog('🔄 Данные обновлены', 'info');
  });

  DOM.saveBtn.addEventListener('click', () => {
    if (isFunction(db.save)) {
      db.save();
      addLog('💾 Данные сохранены', 'success');
      alert('💾 Данные сохранены');
    } else {
      alert('⚠️ Плагин Persistence не установлен или не доступен');
    }
  });

  DOM.loadBtn.addEventListener('click', () => {
    if (isFunction(db.load)) {
      db.load();
      renderAll();
      addLog('📂 Данные загружены', 'success');
      alert('📂 Данные загружены');
    } else {
      alert('⚠️ Плагин Persistence не установлен или не доступен');
    }
  });

  DOM.clearBtn.addEventListener('click', () => {
    if (confirm('Очистить ВСЕ данные? Это действие необратимо!')) {
      if (isFunction(db.clear)) {
        db.clear();
      } else if (isFunction(db.listTables)) {
        const tables = db.listTables();
        for (const name of tables) {
          if (isFunction(db.clearTable)) {
            db.clearTable(name);
          }
        }
      }
      state[PRIVATE.SELECTED_TABLE] = null;
      state[PRIVATE.SELECTED_ROW] = null;
      renderAll();
      addLog('🧹 Все данные очищены', 'warn');
    }
  });

  // Создание таблицы
  DOM.createTableBtn.addEventListener('click', () => showCreateTableModal(false));
  DOM.createTableWithSchemaBtn.addEventListener('click', () => showCreateTableModal(true));

  // Добавление строки
  DOM.addRowBtn.addEventListener('click', showAddRowModal);

  // Обновить данные
  DOM.refreshDataBtn.addEventListener('click', () => {
    renderData();
    addLog('🔄 Данные таблицы обновлены', 'info');
  });

  // Экспорт данных
  DOM.exportDataBtn.addEventListener('click', exportData);

  // Инспектор
  DOM.inspectorRefresh.addEventListener('click', renderInspector);

  // Связи
  DOM.linkTablesBtn.addEventListener('click', showLinkTablesModal);
  DOM.unlinkTablesBtn.addEventListener('click', () => {
    alert('ℹ️ Выберите связь для удаления');
  });

  // Брокер
  DOM.publishBtn.addEventListener('click', publishMessage);
  DOM.addSubscriptionBtn.addEventListener('click', addSubscription);
  DOM.clearMessagesBtn.addEventListener('click', clearMessages);

  // Аудит
  DOM.clearAuditBtn.addEventListener('click', () => {
    if (isFunction(db.clearAudit)) {
      db.clearAudit();
      renderAudit();
      addLog('🧹 Аудит очищен', 'info');
    }
  });
  DOM.exportAuditBtn.addEventListener('click', exportAudit);

  // Консоль
  DOM.consoleInput.addEventListener('keydown', e => {
    if (e.key === 'Enter') {
      executeCommand();
    }
  });
  DOM.consoleExecBtn.addEventListener('click', executeCommand);
  DOM.clearConsoleBtn.addEventListener('click', clearConsole);

  // Плагины
  DOM.pluginManagerBtn.addEventListener('click', () => {
    if (isFunction(db.listPlugins)) {
      const plugins = db.listPlugins();
      alert(`🔌 Активные плагины:\n${plugins.join('\n') || 'Нет плагинов'}`);
    } else {
      alert('🔌 Плагины не доступны');
    }
  });

  // Загрузка демо-данных
  initDemoData();
  renderAll();

  // Экспорт символов
  exportSymbols();

  // ★★★ ГЛОБАЛЬНЫЙ ДОСТУП ★★★
  if (typeof window !== 'undefined') {
    // Используем уже существующий db
    window.__globalStore = db;
    window.__db = db;
    window[GLOBAL_STORE_SYMBOL] = db;

    window.app = {
      render: renderAll,
      selectTable: selectTable,
      addRow: showAddRowModal,
      createTable: showCreateTableModal,
      executeCommand: executeCommand,
      clearConsole: clearConsole,
      showModal: showModal,
      closeModal: closeModal,
      getState: getState,
      healthCheck: healthCheck,
      initDemo: initDemoData,
      getGlobalStore: getGlobalStore,
    };

    console.log('✅ app доступен в консоли как window.app');
    console.log('📋 Команды: app.render(), app.selectTable(name), app.addRow()');
    console.log('✅ Глобальное хранилище доступно как window.__globalStore');
    console.log(`✅ Символ: Symbol.for(\"${CONFIG.globalStoreSymbol}\")`);
  }

  // Обновляем состояние
  state[PRIVATE.INITIALIZED] = true;
  state[PRIVATE.DESTROYED] = false;
  state[PRIVATE.START_TIME] = Date.now();
  state[PRIVATE.LAST_UPDATE] = Date.now();

  logger.success('✅ Приложение инициализировано');

  if (isFunction(db.listTables)) {
    const tables = db.listTables();
    logger.info(`📊 Таблиц: ${tables ? tables.length : 0}`);
  }

  logger.header('ГОТОВ');

  // Консольный интерфейс
  console.log('╔═══════════════════════════════════════════════════════════════════════════════╗');
  console.log('║              🏢 GLOBAL STORE ADMIN v4.0.4                                    ║');
  console.log('╠═══════════════════════════════════════════════════════════════════════════════╣');
  console.log('║  🔑 Символ: __GLOBAL_STORE__                                               ║');
  console.log('║  📋 ДОСТУПНЫЕ КОМАНДЫ:                                                      ║');
  console.log('║    window.__globalStore — доступ к хранилищу                                ║');
  console.log('║    window.__db — прокси для доступа к таблицам                              ║');
  console.log('║    window[Symbol.for(\"__GLOBAL_STORE__\")] — доступ через символ             ║');
  console.log('║    window.app.render() — обновить интерфейс                                 ║');
  console.log('║    window.app.selectTable(name) — выбрать таблицу                           ║');
  console.log('║    window.app.addRow() — добавить строку                                    ║');
  console.log('║    window.app.createTable() — создать таблицу                               ║');
  console.log('║    window.app.executeCommand(code) — выполнить код                          ║');
  console.log('║    window.app.showModal(title, html, callback) — показать модалку           ║');
  console.log('║    window.app.closeModal() — закрыть модалку                                ║');
  console.log('║    window.app.initDemo() — загрузить демо-данные                            ║');
  console.log('║    window.app.getGlobalStore() — получить глобальное хранилище              ║');
  console.log('║  ⌨️ Горячие клавиши:                                                         ║');
  console.log('║    Ctrl+Z — Undo                                                            ║');
  console.log('║    Ctrl+Y — Redo                                                            ║');
  console.log('║    Ctrl+N — Новая таблица                                                   ║');
  console.log('║    Ctrl+S — Сохранить                                                       ║');
  console.log('║    Ctrl+L — Загрузить                                                       ║');
  console.log('║    Ctrl+Shift+R — Очистить консоль                                          ║');
  console.log('╠═══════════════════════════════════════════════════════════════════════════════╣');
  console.log('║  📊 СТАТИСТИКА СИМВОЛОВ:                                                   ║');
  console.log(
      `║    🔑 Приватных символов: ${Object.keys(PRIVATE).length.toString().padStart(3, ' ')}                                      ║`
  );
  console.log(
      `║    🔓 Публичных символов: ${Object.keys(PUBLIC).length.toString().padStart(3, ' ')}                                       ║`
  );
  console.log(
      `║    📦 Всего символов: ${(Object.keys(PRIVATE).length + Object.keys(PUBLIC).length).toString().padStart(3, ' ')}                                     ║`
  );
  console.log('╚═══════════════════════════════════════════════════════════════════════════════╝');
}

// ============================================================
// 22. ЗАПУСК
// ============================================================

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => {
    try {
      init();
    } catch (error) {
      console.error('❌ Ошибка инициализации:', error);
      alert(`❌ Ошибка инициализации: ${error.message}`);
    }
  });
} else {
  try {
    init();
  } catch (error) {
    console.error('❌ Ошибка инициализации:', error);
    alert(`❌ Ошибка инициализации: ${error.message}`);
  }
}

// ============================================================
// 23. ЭКСПОРТЫ
// ============================================================

export {
  PRIVATE as APP_PRIVATE,
  PUBLIC as APP_PUBLIC,
  CONFIG as APP_CONFIG,
  init,
  destroy,
  renderAll as render,
  getState,
  healthCheck,
  showModal,
  closeModal,
  selectTable,
  showAddRowModal as addRow,
  showCreateTableModal as createTable,
  executeCommand,
  clearConsole,
  initDemoData as initDemo,
  getGlobalStore,
};

export default {
  init,
  destroy,
  render: renderAll,
  getState,
  healthCheck,
  showModal,
  closeModal,
  selectTable,
  addRow: showAddRowModal,
  createTable: showCreateTableModal,
  executeCommand,
  clearConsole,
  initDemo: initDemoData,
  getGlobalStore,
  PRIVATE,
  PUBLIC,
  CONFIG,
};
