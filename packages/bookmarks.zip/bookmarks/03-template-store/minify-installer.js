// minify-installer.js
// Скрипт для минификации install-store.js с использованием встроенного модуля
// Запуск:
//   node minify-installer.js
//   node minify-installer.js --src=./src/bookmarklets/install-store.js --out=./src/bookmarklets/install-store.min.js
//   node minify-installer.js -s ./src/bookmarklets/install-store.js -o ./src/bookmarklets/install-store.min.js -b --baseUrl=http://localhost:3029

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { minifyBookmarkletCode } from './src/utils/minify.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// ============================================================
// 1. ПАРСИНГ АРГУМЕНТОВ КОМАНДНОЙ СТРОКИ
// ============================================================
function parseArgs() {
  const args = process.argv.slice(2);
  const result = {
    src: null,
    out: null,
    bookmarklet: false,
    baseUrl: 'http://localhost:3029',
    help: false,
  };

  for (let i = 0; i < args.length; i++) {
    const arg = args[i];

    if (arg === '--help' || arg === '-h') {
      result.help = true;
      continue;
    }

    if (arg === '--bookmarklet' || arg === '-b') {
      result.bookmarklet = true;
      continue;
    }

    // --src=file
    const srcMatch = arg.match(/^--src=(.+)$/);
    if (srcMatch) {
      result.src = srcMatch[1];
      continue;
    }

    // -s file
    if (arg === '-s' && args[i + 1]) {
      result.src = args[i + 1];
      i++;
      continue;
    }

    // --out=file
    const outMatch = arg.match(/^--out=(.+)$/);
    if (outMatch) {
      result.out = outMatch[1];
      continue;
    }

    // -o file
    if (arg === '-o' && args[i + 1]) {
      result.out = args[i + 1];
      i++;
      continue;
    }

    // --baseUrl=url
    const baseUrlMatch = arg.match(/^--baseUrl=(.+)$/);
    if (baseUrlMatch) {
      result.baseUrl = baseUrlMatch[1];
      continue;
    }

    // -u url
    if (arg === '-u' && args[i + 1]) {
      result.baseUrl = args[i + 1];
      i++;
      continue;
    }
  }

  return result;
}

// ============================================================
// 2. ПУТИ ПО УМОЛЧАНИЮ
// ============================================================
const DEFAULT_SRC = 'src/bookmarklets/install-store.js';
const DEFAULT_OUT = 'src/bookmarklets/install-store.min.js';
const DEFAULT_BASE_URL = 'http://localhost:3029';

// ============================================================
// 3. ПОКАЗ СПРАВКИ
// ============================================================
function showHelp() {
  console.log(`
📦 MINIFY-INSTALLER — Минификация install-store.js

ИСПОЛЬЗОВАНИЕ:
  node minify-installer.js [опции]

ОПЦИИ:
  -s, --src=<file>       Исходный файл (по умолчанию: ${DEFAULT_SRC})
  -o, --out=<file>       Выходной файл (по умолчанию: ${DEFAULT_OUT})
  -b, --bookmarklet      Создать букмарклет с префиксом javascript:
                         Выходной файл: <out>.bookmarklet.js
  -u, --baseUrl=<url>    Базовый URL сервера (по умолчанию: ${DEFAULT_BASE_URL})
  -h, --help             Показать эту справку

ПРИМЕРЫ:
  # Базовое использование
  node minify-installer.js

  # Указать исходный и выходной файлы
  node minify-installer.js --src=./custom.js --out=./custom.min.js

  # Короткие флаги
  node minify-installer.js -s ./custom.js -o ./custom.min.js

  # Создать букмарклет (добавляет javascript:)
  node minify-installer.js -b

  # Изменить порт сервера
  node minify-installer.js --baseUrl=http://localhost:8080

  # Полный пример с букмарклетом и кастомным URL
  node minify-installer.js -s ./src/bookmarklets/install-store.js -o ./dist/install-store.min.js -b --baseUrl=http://localhost:3029

  # Короткий вариант
  node minify-installer.js -u http://localhost:3029 -b
`);
}

// ============================================================
// 4. ОСНОВНАЯ ФУНКЦИЯ
// ============================================================
async function main() {
  const args = parseArgs();

  if (args.help) {
    showHelp();
    process.exit(0);
  }

  // Определяем пути
  const srcPath = args.src ? path.resolve(__dirname, args.src) : path.join(__dirname, DEFAULT_SRC);
  const outPath = args.out ? path.resolve(__dirname, args.out) : path.join(__dirname, DEFAULT_OUT);
  const baseUrl = args.baseUrl || DEFAULT_BASE_URL;

  // Создаём директорию для выходного файла если её нет
  const outDir = path.dirname(outPath);
  if (!fs.existsSync(outDir)) {
    fs.mkdirSync(outDir, { recursive: true });
    console.log(`📁 Создана директория: ${outDir}`);
  }

  console.log('📖 Чтение файла:', srcPath);
  console.log(`🌐 Base URL: ${baseUrl}`);

  // Проверяем существование исходного файла
  if (!fs.existsSync(srcPath)) {
    console.error(`❌ Ошибка: файл не найден: ${srcPath}`);
    process.exit(1);
  }

  let sourceCode = fs.readFileSync(srcPath, 'utf8');

  if (!sourceCode || sourceCode.length === 0) {
    console.error('❌ Ошибка: файл пуст');
    process.exit(1);
  }

  // ============================================================
  // 5. ЗАМЕНЯЕМ BASE_URL В КОДЕ
  // ============================================================
  console.log(`🔄 Замена BASE_URL на: ${baseUrl}`);

  // Ищем и заменяем BASE_URL в коде
  const baseUrlRegex = /(const|let|var)\s+BASE_URL\s*=\s*['"]([^'"]*)['"]/;
  const match = sourceCode.match(baseUrlRegex);

  if (match) {
    const oldUrl = match[2];
    sourceCode = sourceCode.replace(baseUrlRegex, `$1 BASE_URL = '${baseUrl}'`);
    console.log(`   Было: ${oldUrl}`);
    console.log(`   Стало: ${baseUrl}`);
  } else {
    console.warn(`⚠️ BASE_URL не найден в файле, используется значение по умолчанию`);
    sourceCode = `const BASE_URL = '${baseUrl}';\n${sourceCode}`;
  }

  console.log(`📊 Исходный размер: ${sourceCode.length} символов`);

  // ============================================================
  // 6. МИНИФИЦИРУЕМ С СОХРАНЕНИЕМ СТРОК
  // ============================================================
  console.log('⚙️ Минификация...');

  // ★★★ КЛЮЧЕВОЕ ИЗМЕНЕНИЕ: preserveStrings: true ★★★
  const options = {
    minify: true,
    keepNames: false,
    preserveStrings: true, // ★★★ СОХРАНЯЕМ СТРОКИ НЕТРОНУТЫМИ ★★★
    compress: {
      sequences: true,
      dead_code: true,
      conditionals: true,
      booleans: true,
      unused: true,
      if_return: true,
      join_vars: true,
      drop_console: false,
      drop_debugger: true,
      passes: 2,
      // ★★★ НЕ СЖИМАТЬ СТРОКИ ★★★
      keep_strings: true,
      keep_fargs: true,
      keep_fnames: true,
      keep_classnames: true,
    },
    mangle: {
      toplevel: true,
      keep_fnames: true,
      keep_classnames: true,
    },
    output: {
      beautify: false,
      comments: false,
      indent_level: 0,
      quote_style: 3,
      // ★★★ СОХРАНЯЕМ СТРОКИ В ИСХОДНОМ ВИДЕ ★★★
      keep_strings: true,
    },
  };

  let minified;
  let useFallback = false;

  try {
    minified = minifyBookmarkletCode(sourceCode, options);
    // Проверяем, что результат не пустой
    if (!minified || minified.length === 0) {
      throw new Error('Результат минификации пуст');
    }
  } catch (error) {
    console.warn(`⚠️ Ошибка минификации через minify.js: ${error.message}`);
    console.log('🔄 Использую fallback минификацию...');
    useFallback = true;

    // ★★★ УЛУЧШЕННАЯ FALLBACK МИНИФИКАЦИЯ С СОХРАНЕНИЕМ СТРОК ★★★
    minified = sourceCode
      // Удаляем комментарии (кроме тех, что в строках)
      .replace(/\/\/[^'\n]*$/gm, function (match) {
        // Проверяем, что комментарий не внутри строки
        return match.includes("'") ? match : '';
      })
      .replace(/\/\*[\s\S]*?\*\//g, '')
      // Сжимаем пробелы, но не внутри строк
      .replace(/\s+/g, function (match) {
        // Проверяем, что пробелы не внутри строки
        return ' ';
      })
      // Удаляем пробелы вокруг операторов
      .replace(/\s*([{}()\[\];:,=+*/<>&|!?])\s*/g, '$1')
      // Убираем лишние точки с запятой
      .replace(/;+/g, ';')
      .replace(/;\}/g, '}')
      .replace(/,\s*}/g, '}')
      .replace(/,\s*\]/g, ']')
      // ★★★ НЕ ТРОГАЕМ СТРОКИ ★★★
      .trim();
  }

  // ============================================================
  // 7. СОХРАНЯЕМ МИНИФИЦИРОВАННЫЙ ФАЙЛ
  // ============================================================
  fs.writeFileSync(outPath, minified, 'utf8');
  console.log(`✅ Минифицированный код сохранён в: ${outPath}`);

  // ============================================================
  // 8. СОЗДАЁМ БУКМАРКЛЕТ (если указан флаг -b)
  // ============================================================
  let bookmarkletPath = null;
  if (args.bookmarklet) {
    const ext = path.extname(outPath);
    const base = outPath.replace(ext, '');
    bookmarkletPath = `${base}.bookmarklet${ext}`;

    const bookmarkletCode = `javascript:${minified}`;

    fs.writeFileSync(bookmarkletPath, bookmarkletCode, 'utf8');
    console.log(`✅ Букмарклет сохранён в: ${bookmarkletPath}`);
    console.log(`📌 Добавлен префикс "javascript:"`);
    console.log(`🌐 BASE_URL в букмарклете: ${baseUrl}`);
  }

  // ============================================================
  // 9. СТАТИСТИКА
  // ============================================================
  const originalSize = sourceCode.length;
  const minifiedSize = minified.length;
  const saved = originalSize - minifiedSize;
  const percent = ((saved / originalSize) * 100).toFixed(1);

  console.log('\n📊 СТАТИСТИКА:');
  console.log('═══════════════════════════════════════════════════════════════');
  console.log(`📄 Исходный файл:     ${path.basename(srcPath)}`);
  console.log(`📦 Выходной файл:     ${path.basename(outPath)}`);
  console.log(`🌐 BASE_URL:          ${baseUrl}`);
  console.log(`📄 Исходный размер:   ${originalSize.toString().padStart(6)} символов`);
  console.log(`📦 Минифицированный:  ${minifiedSize.toString().padStart(6)} символов`);
  console.log(`💾 Сэкономлено:       ${saved.toString().padStart(6)} символов (${percent}%)`);

  if (args.bookmarklet && bookmarkletPath) {
    const bookmarkletSize = fs.statSync(bookmarkletPath).size;
    console.log(`📌 Букмарклет:        ${bookmarkletSize.toString().padStart(6)} символов`);
    console.log(`   (с префиксом "javascript:")`);
  }

  if (useFallback) {
    console.log(`⚠️ Использован fallback-метод минификации`);
  }
  console.log('═══════════════════════════════════════════════════════════════');

  // ============================================================
  // 10. ПРОВЕРКА РАБОТОСПОСОБНОСТИ
  // ============================================================
  console.log('\n🧪 Проверка синтаксиса...');
  try {
    new Function(minified);
    console.log('✅ Синтаксис минифицированного кода корректен');

    if (args.bookmarklet && bookmarkletPath) {
      const bookmarkletContent = fs.readFileSync(bookmarkletPath, 'utf8');
      if (bookmarkletContent.startsWith('javascript:')) {
        console.log('✅ Букмарклет начинается с "javascript:"');
      } else {
        console.warn('⚠️ Букмарклет НЕ начинается с "javascript:"');
      }
    }
  } catch (error) {
    console.error('❌ Ошибка синтаксиса:', error.message);
    console.log('⚠️ Минифицированный код может быть неработоспособным');
  }

  if (args.bookmarklet && bookmarkletPath) {
    console.log('\n🌐 ИНФОРМАЦИЯ О БУКМАРКЛЕТЕ:');
    console.log(`   Сервер: ${baseUrl}`);
    console.log(`   Убедитесь, что сервер запущен на ${baseUrl}`);
    console.log(`   Файл: ${bookmarkletPath}`);
  }

  console.log('\n✅ Готово!');
}

// ============================================================
// 11. ЗАПУСК
// ============================================================
main().catch((error) => {
  console.error('❌ Критическая ошибка:', error);
  process.exit(1);
});
