@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion

:: ============================================================
:: 1. ПРИВАТНЫЕ СИМВОЛЫ (100% изоляция)
:: ============================================================

set "PRIVATE_VERSION=1.0.0"
set "PRIVATE_BUILD=2026-07-23"
set "PRIVATE_NAME=Bookmarks Extension Installer"
set "PRIVATE_DEBUG=true"
set "PRIVATE_INITIALIZED=false"
set "PRIVATE_DESTROYED=false"

:: ============================================================
:: 2. ПУБЛИЧНЫЕ СИМВОЛЫ (доступны через переменные окружения)
:: ============================================================

set "PUBLIC_INSTALL=1"
set "PUBLIC_UNINSTALL=2"
set "PUBLIC_REINSTALL=3"
set "PUBLIC_UPDATE=4"
set "PUBLIC_STATUS=5"

:: ============================================================
:: 3. КОНФИГУРАЦИЯ
:: ============================================================

set "CONFIG_EXTENSION_PATH=%~dp0extension"
set "CONFIG_CHROME_PATH=%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe"
set "CONFIG_CHROME_BETA_PATH=%LOCALAPPDATA%\Google\Chrome Beta\Application\chrome.exe"
set "CONFIG_CHROME_DEV_PATH=%LOCALAPPDATA%\Google\Chrome Dev\Application\chrome.exe"
set "CONFIG_EDGE_PATH=%LOCALAPPDATA%\Microsoft\Edge\Application\msedge.exe"
set "CONFIG_BRAVE_PATH=%LOCALAPPDATA%\BraveSoftware\Brave-Browser\Application\brave.exe"
set "CONFIG_OPERA_PATH=%LOCALAPPDATA%\Programs\Opera\launcher.exe"
set "CONFIG_FIREFOX_PATH=%PROGRAMFILES%\Mozilla Firefox\firefox.exe"
set "CONFIG_TIMEOUT=5"
set "CONFIG_MAX_RETRIES=3"
set "CONFIG_TEMP_DIR=%TEMP%\bookmarks-extension-installer"

:: ============================================================
:: 4. ЦВЕТА ДЛЯ ВЫВОДА
:: ============================================================

set "COLOR_RESET=[0m"
set "COLOR_RED=[31m"
set "COLOR_GREEN=[32m"
set "COLOR_YELLOW=[33m"
set "COLOR_BLUE=[34m"
set "COLOR_MAGENTA=[35m"
set "COLOR_CYAN=[36m"
set "COLOR_WHITE=[37m"
set "COLOR_BOLD=[1m"
set "COLOR_DIM=[2m"
set "COLOR_BG_RED=[41m"
set "COLOR_BG_GREEN=[42m"
set "COLOR_BG_YELLOW=[43m"
set "COLOR_BG_BLUE=[44m"

:: ============================================================
:: 5. ЛОГГЕР
:: ============================================================

set "LOG_FILE=%TEMP%\bookmarks-installer.log"
set "LOG_HISTORY="
set "LOG_MAX_HISTORY=1000"

:: Создаем временную директорию
if not exist "%CONFIG_TEMP_DIR%" mkdir "%CONFIG_TEMP_DIR%"

:: ============================================================
:: 6. ВАЛИДАТОР
:: ============================================================

:: ============================================================
:: 7. ОСНОВНЫЕ ФУНКЦИИ
:: ============================================================

:INIT
    set "PRIVATE_INITIALIZED=true"
    set "PRIVATE_DESTROYED=false"
    call :LOG "INFO" "Инициализация Installer v%PRIVATE_VERSION% (%PRIVATE_BUILD%)"
    call :LOG "INFO" "Путь к расширению: %CONFIG_EXTENSION_PATH%"
    call :LOG "INFO" "Временная директория: %CONFIG_TEMP_DIR%"
    call :HEADER
    goto :EOF

:DESTROY
    set "PRIVATE_DESTROYED=true"
    set "PRIVATE_INITIALIZED=false"
    call :LOG "INFO" "Уничтожение Installer"
    call :CLEANUP_TEMP
    goto :EOF

:HEADER
    echo.
    echo %COLOR_CYAN%%COLOR_BOLD%╔═══════════════════════════════════════════════════════════════════════════════╗%COLOR_RESET%
    echo %COLOR_CYAN%%COLOR_BOLD%║              📦 BOOKMARKS EXTENSION INSTALLER v1.0.0                         ║%COLOR_RESET%
    echo %COLOR_CYAN%%COLOR_BOLD%╠═══════════════════════════════════════════════════════════════════════════════╣%COLOR_RESET%
    echo %COLOR_CYAN%%COLOR_BOLD%║  📋 Установка расширения Bookmarks Manager Pro                               ║%COLOR_RESET%
    echo %COLOR_CYAN%%COLOR_BOLD%║  🔑 100%% изоляция через приватные переменные                                ║%COLOR_RESET%
    echo %COLOR_CYAN%%COLOR_BOLD%║  🔓 Публичные символы через переменные окружения                             ║%COLOR_RESET%
    echo %COLOR_CYAN%%COLOR_BOLD%║  🌐 Поддержка всех браузеров (Chrome, Edge, Brave, Opera)                   ║%COLOR_RESET%
    echo %COLOR_CYAN%%COLOR_BOLD%║  ⚠️ Расширенная валидация и обработка ошибок                                 ║%COLOR_RESET%
    echo %COLOR_CYAN%%COLOR_BOLD%║  🛡️ Защита от поврежденных файлов и некорректных путей                      ║%COLOR_RESET%
    echo %COLOR_CYAN%%COLOR_BOLD%║  📊 Полная статистика установки                                              ║%COLOR_RESET%
    echo %COLOR_CYAN%%COLOR_BOLD%╚═══════════════════════════════════════════════════════════════════════════════╝%COLOR_RESET%
    echo.
    goto :EOF

:LOG
    set "LEVEL=%~1"
    set "MESSAGE=%~2"
    set "TIMESTAMP=%DATE% %TIME%"

    set "ICON="
    if "%LEVEL%"=="ERROR" set "ICON=❌"
    if "%LEVEL%"=="WARN" set "ICON=⚠️"
    if "%LEVEL%"=="INFO" set "ICON=ℹ️"
    if "%LEVEL%"=="SUCCESS" set "ICON=✅"
    if "%LEVEL%"=="DEBUG" set "ICON=🔍"

    if "%LEVEL%"=="ERROR" (
        echo %COLOR_RED%%ICON% [%TIMESTAMP%] %MESSAGE%%COLOR_RESET%
    ) else if "%LEVEL%"=="WARN" (
        echo %COLOR_YELLOW%%ICON% [%TIMESTAMP%] %MESSAGE%%COLOR_RESET%
    ) else if "%LEVEL%"=="SUCCESS" (
        echo %COLOR_GREEN%%ICON% [%TIMESTAMP%] %MESSAGE%%COLOR_RESET%
    ) else if "%LEVEL%"=="DEBUG" (
        if "%PRIVATE_DEBUG%"=="true" echo %COLOR_DIM%%ICON% [%TIMESTAMP%] %MESSAGE%%COLOR_RESET%
    ) else (
        echo %COLOR_WHITE%%ICON% [%TIMESTAMP%] %MESSAGE%%COLOR_RESET%
    )

    :: Запись в лог файл
    echo [%TIMESTAMP%] [%LEVEL%] %MESSAGE% >> "%LOG_FILE%"
    goto :EOF

:CLEANUP_TEMP
    if exist "%CONFIG_TEMP_DIR%" (
        call :LOG "DEBUG" "Очистка временной директории: %CONFIG_TEMP_DIR%"
        rmdir /s /q "%CONFIG_TEMP_DIR%" 2>nul
    )
    goto :EOF

:CHECK_EXTENSION_FILES
    call :LOG "INFO" "Проверка файлов расширения..."

    set "MISSING_FILES="
    set "FILE_COUNT=0"

    :: Список обязательных файлов
    set "REQUIRED_FILES=manifest.json bookmarksManager.mjs background.js popup.html popup.js popup.css content.js"

    for %%f in (%REQUIRED_FILES%) do (
        if not exist "%CONFIG_EXTENSION_PATH%\%%f" (
            call :LOG "ERROR" "Отсутствует обязательный файл: %%f"
            set "MISSING_FILES=!MISSING_FILES! %%f"
        ) else (
            set /a FILE_COUNT+=1
            call :LOG "DEBUG" "✅ Файл найден: %%f"
        )
    )

    :: Проверяем папку с иконками
    if not exist "%CONFIG_EXTENSION_PATH%\icon" (
        call :LOG "WARN" "Папка icon не найдена, будут созданы стандартные иконки"
        call :CREATE_DEFAULT_ICONS
    )

    if defined MISSING_FILES (
        call :LOG "ERROR" "Отсутствуют файлы:%MISSING_FILES%"
        call :LOG "ERROR" "Всего найдено файлов: %FILE_COUNT%"
        return 1
    )

    call :LOG "SUCCESS" "Все файлы расширения найдены (%FILE_COUNT% файлов)"
    return 0

:CREATE_DEFAULT_ICONS
    call :LOG "INFO" "Создание стандартных иконок..."

    if not exist "%CONFIG_EXTENSION_PATH%\icon" mkdir "%CONFIG_EXTENSION_PATH%\icon"

    :: Создаем SVG иконку
    echo ^<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128"^> > "%CONFIG_TEMP_DIR%\icon.svg"
    echo   ^<rect width="128" height="128" rx="20" fill="#3b82f6"/^> >> "%CONFIG_TEMP_DIR%\icon.svg"
    echo   ^<path d="M64 30 L30 50 L30 90 L64 110 L98 90 L98 50 Z" fill="#ffffff" opacity="0.9"/^> >> "%CONFIG_TEMP_DIR%\icon.svg"
    echo   ^<path d="M64 30 L30 50 L64 70 L98 50 Z" fill="#60a5fa"/^> >> "%CONFIG_TEMP_DIR%\icon.svg"
    echo   ^<rect x="45" y="55" width="38" height="28" rx="4" fill="#ffffff" opacity="0.8"/^> >> "%CONFIG_TEMP_DIR%\icon.svg"
    echo   ^<text x="64" y="75" font-family="Arial, sans-serif" font-size="20" font-weight="bold" fill="#3b82f6" text-anchor="middle"^>B^</text^> >> "%CONFIG_TEMP_DIR%\icon.svg"
    echo ^</svg^> >> "%CONFIG_TEMP_DIR%\icon.svg"

    :: Создаем пустые PNG иконки с предупреждением
    echo %COLOR_YELLOW%⚠️ Для полноценной работы создайте иконки размером 16x16, 48x48 и 128x128 пикселей%COLOR_RESET%

    :: Копируем SVG как временную замену
    copy "%CONFIG_TEMP_DIR%\icon.svg" "%CONFIG_EXTENSION_PATH%\icon\icon.svg" >nul 2>nul

    call :LOG "WARN" "Созданы стандартные иконки (замените на реальные PNG)"
    goto :EOF

:FIND_BROWSER
    call :LOG "INFO" "Поиск установленных браузеров..."

    set "BROWSER_FOUND="
    set "BROWSER_PATH="

    :: Проверяем Chrome
    if exist "%CONFIG_CHROME_PATH%" (
        set "BROWSER_FOUND=Chrome"
        set "BROWSER_PATH=%CONFIG_CHROME_PATH%"
        call :LOG "SUCCESS" "Найден Chrome: %BROWSER_PATH%"
        goto :EOF
    )

    :: Проверяем Chrome Beta
    if exist "%CONFIG_CHROME_BETA_PATH%" (
        set "BROWSER_FOUND=Chrome Beta"
        set "BROWSER_PATH=%CONFIG_CHROME_BETA_PATH%"
        call :LOG "SUCCESS" "Найден Chrome Beta: %BROWSER_PATH%"
        goto :EOF
    )

    :: Проверяем Chrome Dev
    if exist "%CONFIG_CHROME_DEV_PATH%" (
        set "BROWSER_FOUND=Chrome Dev"
        set "BROWSER_PATH=%CONFIG_CHROME_DEV_PATH%"
        call :LOG "SUCCESS" "Найден Chrome Dev: %BROWSER_PATH%"
        goto :EOF
    )

    :: Проверяем Edge
    if exist "%CONFIG_EDGE_PATH%" (
        set "BROWSER_FOUND=Edge"
        set "BROWSER_PATH=%CONFIG_EDGE_PATH%"
        call :LOG "SUCCESS" "Найден Edge: %BROWSER_PATH%"
        goto :EOF
    )

    :: Проверяем Brave
    if exist "%CONFIG_BRAVE_PATH%" (
        set "BROWSER_FOUND=Brave"
        set "BROWSER_PATH=%CONFIG_BRAVE_PATH%"
        call :LOG "SUCCESS" "Найден Brave: %BROWSER_PATH%"
        goto :EOF
    )

    :: Проверяем Opera
    if exist "%CONFIG_OPERA_PATH%" (
        set "BROWSER_FOUND=Opera"
        set "BROWSER_PATH=%CONFIG_OPERA_PATH%"
        call :LOG "SUCCESS" "Найден Opera: %BROWSER_PATH%"
        goto :EOF
    )

    call :LOG "ERROR" "Не найден ни один поддерживаемый браузер"
    return 1

:INSTALL_EXTENSION
    call :LOG "INFO" "Начало установки расширения..."

    :: Проверяем файлы
    call :CHECK_EXTENSION_FILES
    if errorlevel 1 (
        call :LOG "ERROR" "Проверка файлов не пройдена"
        goto :INSTALL_ERROR
    )

    :: Находим браузер
    call :FIND_BROWSER
    if errorlevel 1 (
        call :LOG "ERROR" "Браузер не найден"
        goto :INSTALL_ERROR
    )

    :: Открываем страницу расширений
    call :LOG "INFO" "Открываем %BROWSER_FOUND%..."

    start "" "%BROWSER_PATH%" "chrome://extensions/"

    if errorlevel 1 (
        call :LOG "ERROR" "Не удалось открыть браузер"
        goto :INSTALL_ERROR
    )

    call :LOG "SUCCESS" "✅ Браузер открыт"
    call :SHOW_INSTRUCTIONS

    :: Сохраняем информацию об установке
    call :SAVE_INSTALL_INFO
    goto :INSTALL_SUCCESS

:SHOW_INSTRUCTIONS
    echo.
    echo %COLOR_CYAN%%COLOR_BOLD%╔═══════════════════════════════════════════════════════════════════════════════╗%COLOR_RESET%
    echo %COLOR_CYAN%%COLOR_BOLD%║                    📋 ИНСТРУКЦИЯ ПО УСТАНОВКЕ                                   ║%COLOR_RESET%
    echo %COLOR_CYAN%%COLOR_BOLD%╠═══════════════════════════════════════════════════════════════════════════════╣%COLOR_RESET%
    echo %COLOR_WHITE%║ 1. Включите %COLOR_YELLOW%"Режим разработчика"%COLOR_WHITE% (переключатель в правом верхнем углу)          ║%COLOR_RESET%
    echo %COLOR_WHITE%║ 2. Нажмите %COLOR_GREEN%"Загрузить распакованное расширение"%COLOR_WHITE%                               ║%COLOR_RESET%
    echo %COLOR_WHITE%║ 3. Выберите папку: %COLOR_CYAN%%CONFIG_EXTENSION_PATH%%COLOR_WHITE%                                  ║%COLOR_RESET%
    echo %COLOR_WHITE%║ 4. Расширение %COLOR_GREEN%Bookmarks Manager Pro%COLOR_WHITE% появится в панели расширений             ║%COLOR_RESET%
    echo %COLOR_WHITE%║                                                                                       ║%COLOR_RESET%
    echo %COLOR_WHITE%║ %COLOR_YELLOW%💡 Совет:%COLOR_WHITE% Закрепите расширение в панели для быстрого доступа              ║%COLOR_RESET%
    echo %COLOR_CYAN%%COLOR_BOLD%╚═══════════════════════════════════════════════════════════════════════════════╝%COLOR_RESET%
    echo.

    :: Пауза с таймером
    call :COUNTDOWN %CONFIG_TIMEOUT%
    goto :EOF

:COUNTDOWN
    set "SECONDS=%~1"
    echo %COLOR_DIM%Ожидание %SECONDS% секунд...%COLOR_RESET%

    :COUNTDOWN_LOOP
    if %SECONDS% equ 0 goto :EOF
    set /a SECONDS-=1
    timeout /t 1 /nobreak >nul 2>nul
    goto :COUNTDOWN_LOOP

:SAVE_INSTALL_INFO
    set "INSTALL_INFO_FILE=%CONFIG_TEMP_DIR%\install-info.txt"
    (
        echo [INSTALL_INFO]
        echo Version=%PRIVATE_VERSION%
        echo Build=%PRIVATE_BUILD%
        echo Browser=%BROWSER_FOUND%
        echo BrowserPath=%BROWSER_PATH%
        echo ExtensionPath=%CONFIG_EXTENSION_PATH%
        echo InstallDate=%DATE%
        echo InstallTime=%TIME%
        echo FileCount=%FILE_COUNT%
        echo Success=true
    ) > "%INSTALL_INFO_FILE%"

    call :LOG "DEBUG" "Информация об установке сохранена: %INSTALL_INFO_FILE%"
    goto :EOF

:INSTALL_SUCCESS
    call :LOG "SUCCESS" "🎉 Установка успешно завершена!"
    echo.
    echo %COLOR_GREEN%%COLOR_BOLD%✅ Расширение готово к использованию!%COLOR_RESET%
    echo.
    echo %COLOR_DIM%📋 Для проверки откройте chrome://extensions/ и найдите "Bookmarks Manager Pro"%COLOR_RESET%
    echo.
    goto :EOF

:INSTALL_ERROR
    call :LOG "ERROR" "❌ Установка не удалась"
    echo.
    echo %COLOR_RED%%COLOR_BOLD%❌ Произошла ошибка при установке%COLOR_RESET%
    echo.
    echo %COLOR_YELLOW%Возможные причины:%COLOR_RESET%
    echo   - Отсутствуют обязательные файлы расширения
    echo   - Браузер не установлен или не найден
    echo   - Нет прав на запись в директорию
    echo.
    echo %COLOR_DIM%Проверьте лог: %LOG_FILE%%COLOR_RESET%
    echo.
    pause
    goto :EOF

:UNINSTALL_EXTENSION
    call :LOG "INFO" "Удаление расширения..."

    :: Открываем страницу расширений
    call :FIND_BROWSER
    if errorlevel 1 goto :UNINSTALL_ERROR

    start "" "%BROWSER_PATH%" "chrome://extensions/"

    echo.
    echo %COLOR_YELLOW%%COLOR_BOLD%╔═══════════════════════════════════════════════════════════════════════════════╗%COLOR_RESET%
    echo %COLOR_YELLOW%%COLOR_BOLD%║                    🗑 ИНСТРУКЦИЯ ПО УДАЛЕНИЮ                                    ║%COLOR_RESET%
    echo %COLOR_YELLOW%%COLOR_BOLD%╠═══════════════════════════════════════════════════════════════════════════════╣%COLOR_RESET%
    echo %COLOR_WHITE%║ 1. Найдите расширение %COLOR_YELLOW%"Bookmarks Manager Pro"%COLOR_WHITE% в списке                    ║%COLOR_RESET%
    echo %COLOR_WHITE%║ 2. Нажмите %COLOR_RED%"Удалить"%COLOR_WHITE%                                                       ║%COLOR_RESET%
    echo %COLOR_WHITE%║ 3. Подтвердите удаление                                                          ║%COLOR_RESET%
    echo %COLOR_YELLOW%%COLOR_BOLD%╚═══════════════════════════════════════════════════════════════════════════════╝%COLOR_RESET%
    echo.

    pause
    call :LOG "SUCCESS" "Расширение удалено"
    goto :EOF

:UNINSTALL_ERROR
    call :LOG "ERROR" "❌ Не удалось открыть браузер для удаления"
    pause
    goto :EOF

:UPDATE_EXTENSION
    call :LOG "INFO" "Обновление расширения..."

    :: Проверяем файлы
    call :CHECK_EXTENSION_FILES
    if errorlevel 1 goto :UPDATE_ERROR

    :: Находим браузер
    call :FIND_BROWSER
    if errorlevel 1 goto :UPDATE_ERROR

    :: Открываем страницу расширений
    start "" "%BROWSER_PATH%" "chrome://extensions/"

    echo.
    echo %COLOR_CYAN%%COLOR_BOLD%╔═══════════════════════════════════════════════════════════════════════════════╗%COLOR_RESET%
    echo %COLOR_CYAN%%COLOR_BOLD%║                    🔄 ИНСТРУКЦИЯ ПО ОБНОВЛЕНИЮ                                  ║%COLOR_RESET%
    echo %COLOR_CYAN%%COLOR_BOLD%╠═══════════════════════════════════════════════════════════════════════════════╣%COLOR_RESET%
    echo %COLOR_WHITE%║ 1. Найдите расширение %COLOR_YELLOW%"Bookmarks Manager Pro"%COLOR_WHITE% в списке                    ║%COLOR_RESET%
    echo %COLOR_WHITE%║ 2. Нажмите %COLOR_CYAN%"Обновить"%COLOR_WHITE% или удалите и установите заново                       ║%COLOR_RESET%
    echo %COLOR_WHITE%║ 3. Или используйте %COLOR_GREEN%"Установить заново"%COLOR_WHITE% в контекстном меню            ║%COLOR_RESET%
    echo %COLOR_CYAN%%COLOR_BOLD%╚═══════════════════════════════════════════════════════════════════════════════╝%COLOR_RESET%
    echo.

    call :LOG "SUCCESS" "Обновление завершено"
    pause
    goto :EOF

:UPDATE_ERROR
    call :LOG "ERROR" "❌ Не удалось обновить расширение"
    pause
    goto :EOF

:SHOW_STATUS
    call :LOG "INFO" "Статус установки:"
    echo.
    echo %COLOR_WHITE%╔═══════════════════════════════════════════════════════════════════════════════╗%COLOR_RESET%
    echo %COLOR_WHITE%║                          📊 СТАТУС УСТАНОВКИ                                ║%COLOR_RESET%
    echo %COLOR_WHITE%╠═══════════════════════════════════════════════════════════════════════════════╣%COLOR_RESET%

    :: Проверяем файлы
    call :CHECK_EXTENSION_FILES >nul 2>nul
    if errorlevel 1 (
        echo %COLOR_RED%║  Статус: ❌ ОШИБКА - отсутствуют файлы                                       ║%COLOR_RESET%
    ) else (
        echo %COLOR_GREEN%║  Статус: ✅ ГОТОВ - все файлы на месте                                       ║%COLOR_RESET%
    )

    :: Проверяем браузер
    call :FIND_BROWSER >nul 2>nul
    if errorlevel 1 (
        echo %COLOR_RED%║  Браузер: ❌ НЕ НАЙДЕН                                                    ║%COLOR_RESET%
    ) else (
        echo %COLOR_GREEN%║  Браузер: ✅ %BROWSER_FOUND%                                               ║%COLOR_RESET%
    )

    echo %COLOR_WHITE%║  Версия: %PRIVATE_VERSION% (%PRIVATE_BUILD%)                                  ║%COLOR_RESET%
    echo %COLOR_WHITE%║  Путь: %CONFIG_EXTENSION_PATH%                                             ║%COLOR_RESET%
    echo %COLOR_WHITE%║  Файлов: %FILE_COUNT%                                                       ║%COLOR_RESET%

    :: Проверяем наличие информации об установке
    if exist "%INSTALL_INFO_FILE%" (
        echo %COLOR_GREEN%║  Установка: ✅ выполнена                                                   ║%COLOR_RESET%
    ) else (
        echo %COLOR_YELLOW%║  Установка: ⚠️ не выполнена                                                ║%COLOR_RESET%
    )

    echo %COLOR_WHITE%╚═══════════════════════════════════════════════════════════════════════════════╝%COLOR_RESET%
    echo.
    pause
    goto :EOF

:CREATE_DESKTOP_SHORTCUT
    call :LOG "INFO" "Создание ярлыка на рабочем столе..."

    set "SHORTCUT_PATH=%USERPROFILE%\Desktop\Bookmarks Manager Pro.url"

    (
        echo [InternetShortcut]
        echo URL=chrome://extensions/
        echo IconFile=%CONFIG_CHROME_PATH%
        echo IconIndex=0
    ) > "%SHORTCUT_PATH%"

    if exist "%SHORTCUT_PATH%" (
        call :LOG "SUCCESS" "Ярлык создан: %SHORTCUT_PATH%"
    ) else (
        call :LOG "ERROR" "Не удалось создать ярлык"
    )
    goto :EOF

:CREATE_UNINSTALL_SHORTCUT
    call :LOG "INFO" "Создание ярлыка для удаления..."

    set "UNINSTALL_PATH=%USERPROFILE%\Desktop\Удалить Bookmarks Manager Pro.bat"

    (
        echo @echo off
        echo echo Удаление Bookmarks Manager Pro...
        echo echo.
        echo echo Открываем chrome://extensions/
        echo start chrome://extensions/
        echo echo.
        echo echo Найдите расширение "Bookmarks Manager Pro" и нажмите "Удалить"
        echo echo.
        echo pause
    ) > "%UNINSTALL_PATH%"

    if exist "%UNINSTALL_PATH%" (
        call :LOG "SUCCESS" "Ярлык удаления создан: %UNINSTALL_PATH%"
    ) else (
        call :LOG "ERROR" "Не удалось создать ярлык удаления"
    )
    goto :EOF

:SHOW_MENU
    call :HEADER
    echo %COLOR_WHITE%Выберите действие:%COLOR_RESET%
    echo.
    echo   %COLOR_CYAN%[1]%COLOR_RESET% Установить расширение
    echo   %COLOR_CYAN%[2]%COLOR_RESET% Удалить расширение
    echo   %COLOR_CYAN%[3]%COLOR_RESET% Обновить расширение
    echo   %COLOR_CYAN%[4]%COLOR_RESET% Проверить статус
    echo   %COLOR_CYAN%[5]%COLOR_RESET% Создать ярлык на рабочем столе
    echo   %COLOR_CYAN%[6]%COLOR_RESET% Создать ярлык для удаления
    echo   %COLOR_CYAN%[7]%COLOR_RESET% Очистить временные файлы
    echo   %COLOR_CYAN%[8]%COLOR_RESET% Показать лог установки
    echo   %COLOR_CYAN%[9]%COLOR_RESET% Выход
    echo.
    echo %COLOR_DIM%Путь к расширению: %CONFIG_EXTENSION_PATH%%COLOR_RESET%
    echo.
    set /p "CHOICE=Введите номер действия: "

    if "%CHOICE%"=="1" call :INSTALL_EXTENSION
    if "%CHOICE%"=="2" call :UNINSTALL_EXTENSION
    if "%CHOICE%"=="3" call :UPDATE_EXTENSION
    if "%CHOICE%"=="4" call :SHOW_STATUS
    if "%CHOICE%"=="5" call :CREATE_DESKTOP_SHORTCUT
    if "%CHOICE%"=="6" call :CREATE_UNINSTALL_SHORTCUT
    if "%CHOICE%"=="7" call :CLEANUP_TEMP
    if "%CHOICE%"=="8" call :SHOW_LOG
    if "%CHOICE%"=="9" goto :EXIT

    if "%CHOICE%"=="" goto :EXIT

    echo %COLOR_YELLOW%⚠️ Неверный выбор. Попробуйте снова.%COLOR_RESET%
    timeout /t 2 /nobreak >nul 2>nul
    goto :SHOW_MENU

:SHOW_LOG
    if exist "%LOG_FILE%" (
        echo.
        echo %COLOR_WHITE%📋 Лог установки:%COLOR_RESET%
        echo %COLOR_DIM%────────────────────────────────────────────────────────%COLOR_RESET%
        type "%LOG_FILE%"
        echo %COLOR_DIM%────────────────────────────────────────────────────────%COLOR_RESET%
        echo.
    ) else (
        echo %COLOR_YELLOW%⚠️ Лог файл не найден%COLOR_RESET%
    )
    pause
    goto :SHOW_MENU

:EXIT
    call :LOG "INFO" "Завершение работы"
    call :DESTROY
    echo.
    echo %COLOR_GREEN%До свидания!%COLOR_RESET%
    echo.
    endlocal
    exit /b 0

:: ============================================================
:: 8. ТОЧКА ВХОДА
:: ============================================================

:MAIN
    :: Инициализация
    call :INIT

    :: Проверяем, есть ли аргументы командной строки
    if not "%~1"=="" (
        if "%~1"=="install" call :INSTALL_EXTENSION & goto :EXIT
        if "%~1"=="uninstall" call :UNINSTALL_EXTENSION & goto :EXIT
        if "%~1"=="update" call :UPDATE_EXTENSION & goto :EXIT
        if "%~1"=="status" call :SHOW_STATUS & goto :EXIT
        if "%~1"=="clean" call :CLEANUP_TEMP & goto :EXIT
        if "%~1"=="help" goto :SHOW_HELP
    )

    :: Показываем меню
    call :SHOW_MENU
    goto :EXIT

:SHOW_HELP
    echo.
    echo %COLOR_CYAN%%COLOR_BOLD%Использование:%COLOR_RESET%
    echo   install-extension.bat [команда]
    echo.
    echo %COLOR_WHITE%Команды:%COLOR_RESET%
    echo   install     - Установить расширение
    echo   uninstall   - Удалить расширение
    echo   update      - Обновить расширение
    echo   status      - Показать статус
    echo   clean       - Очистить временные файлы
    echo   help        - Показать эту справку
    echo.
    echo %COLOR_WHITE%Примеры:%COLOR_RESET%
    echo   install-extension.bat install
    echo   install-extension.bat status
    echo.
    goto :EXIT

:: ============================================================
:: 9. ЗАПУСК
:: ============================================================

call :MAIN %*
