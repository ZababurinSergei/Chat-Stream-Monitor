// ============================================================
// 1. ИМПОРТЫ
// ============================================================

import { BookmarksManager } from './bookmarksManager.mjs';
import './popup-window.js';

// ============================================================
// 2. ПРИВАТНЫЕ СИМВОЛЫ (100% изоляция)
// ============================================================

const PRIVATE = {
  STATE: Symbol('popup.state'),
  CONFIG: Symbol('popup.config'),
  VERSION: Symbol('popup.version'),
  BUILD: Symbol('popup.build'),
  INITIALIZED: Symbol('popup.initialized'),
  DESTROYED: Symbol('popup.destroyed'),
  IS_LOADING: Symbol('popup.isLoading'),
  BOOKMARKS: Symbol('popup.bookmarks'),
  RECENT: Symbol('popup.recent'),
  STATS: Symbol('popup.stats'),
  SEARCH_QUERY: Symbol('popup.searchQuery'),
  CURRENT_TAB: Symbol('popup.currentTab'),
  SELECTED_ID: Symbol('popup.selectedId'),
  ELEMENTS: Symbol('popup.elements'),
  REFS: Symbol('popup.refs'),
  SUBSCRIPTIONS: Symbol('popup.subscriptions'),
  EVENT_LISTENERS: Symbol('popup.eventListeners'),
  INIT: Symbol('popup.init'),
  DESTROY: Symbol('popup.destroy'),
  LOAD_DATA: Symbol('popup.loadData'),
  LOAD_STATS: Symbol('popup.loadStats'),
  LOAD_ALL: Symbol('popup.loadAll'),
  LOAD_RECENT: Symbol('popup.loadRecent'),
  SEARCH: Symbol('popup.search'),
  RENDER: Symbol('popup.render'),
  RENDER_TREE: Symbol('popup.renderTree'),
  RENDER_RECENT: Symbol('popup.renderRecent'),
  RENDER_STATS: Symbol('popup.renderStats'),
  SWITCH_TAB: Symbol('popup.switchTab'),
  SHOW_STATUS: Symbol('popup.showStatus'),
  CLEAR_STATUS: Symbol('popup.clearStatus'),
  HANDLE_CLICK: Symbol('popup.handleClick'),
  HANDLE_SEARCH: Symbol('popup.handleSearch'),
  HANDLE_TAB_SWITCH: Symbol('popup.handleTabSwitch'),
  HANDLE_MESSAGE: Symbol('popup.handleMessage'),
  HANDLE_KEYDOWN: Symbol('popup.handleKeydown'),
  EXPORT_JSON: Symbol('popup.exportJSON'),
  EXPORT_HTML: Symbol('popup.exportHTML'),
  IMPORT_JSON: Symbol('popup.importJSON'),
  IMPORT_HTML: Symbol('popup.importHTML'),
  REMOVE_DUPLICATES: Symbol('popup.removeDuplicates'),
  REFRESH: Symbol('popup.refresh'),
  OPEN_MANAGER: Symbol('popup.openManager'),
  VALIDATE: Symbol('popup.validate'),
  SANITIZE: Symbol('popup.sanitize'),
  ESCAPE: Symbol('popup.escape'),
  SECURE: Symbol('popup.secure'),
  EXPORT_SYMBOLS: Symbol('popup.exportSymbols'),
};

// ============================================================
// 3. ПУБЛИЧНЫЕ СИМВОЛЫ
// ============================================================

const PUBLIC = {
  INSTANCE: Symbol.for('popup.instance'),
  STATE: Symbol.for('popup.state'),
  CONFIG: Symbol.for('popup.config'),
  INIT: Symbol.for('popup.init'),
  DESTROY: Symbol.for('popup.destroy'),
  REFRESH: Symbol.for('popup.refresh'),
  GET_STATE: Symbol.for('popup.getState'),
  GET_STATS: Symbol.for('popup.getStats'),
  SEARCH: Symbol.for('popup.search'),
  EXPORT: Symbol.for('popup.export'),
  IMPORT: Symbol.for('popup.import'),
};

// ============================================================
// 4. КОНФИГУРАЦИЯ
// ============================================================

const CONFIG = {
  version: '1.0.0',
  build: '2026-07-23',
  name: 'Popup Manager',
  debug: true,
  maxRecent: 20,
  maxTreeDepth: 10,
  searchMinLength: 2,
  statusTimeout: 5000,
  debounceDelay: 300,
};

// ============================================================
// 5. СОСТОЯНИЕ
// ============================================================

const STATE = {
  [PRIVATE.BOOKMARKS]: [],
  [PRIVATE.RECENT]: [],
  [PRIVATE.STATS]: { totalBookmarks: 0, totalFolders: 0, totalNodes: 0 },
  [PRIVATE.SEARCH_QUERY]: '',
  [PRIVATE.CURRENT_TAB]: 'all',
  [PRIVATE.SELECTED_ID]: null,
  [PRIVATE.IS_LOADING]: false,
  [PRIVATE.INITIALIZED]: false,
  [PRIVATE.DESTROYED]: false,
  [PRIVATE.SUBSCRIPTIONS]: new Map(),
  [PRIVATE.EVENT_LISTENERS]: new Set(),
};

// ============================================================
// 6. DOM РЕФЕРЕНСЫ
// ============================================================

const REFS = {
  totalBookmarks: null,
  totalFolders: null,
  lastUpdate: null,
  tabs: null,
  panels: { all: null, recent: null, tools: null, api: null },
  searchInput: null,
  bookmarksTree: null,
  recentList: null,
  exportJsonBtn: null,
  exportHtmlBtn: null,
  importJsonBtn: null,
  importJsonFile: null,
  importHtmlBtn: null,
  importHtmlFile: null,
  removeDuplicatesBtn: null,
  refreshBtn: null,
  statusMessage: null,
  footerInfo: null,
  openFullManager: null,
};

// ============================================================
// 7. ЛОГГЕР (ИСПРАВЛЕН)
// ============================================================

const LOGGER_SYMBOLS = {
  HISTORY: Symbol('logger.history'),
  MAX_HISTORY: Symbol('logger.maxHistory'),
  DEBUG: Symbol('logger.debug'),
  INSTANCE_ID: Symbol('logger.instanceId'),
  LEVEL: Symbol('logger.level'),
};

function createLogger(debug = true, instanceId = 'Popup') {
  const logState = {
    [LOGGER_SYMBOLS.HISTORY]: [],
    [LOGGER_SYMBOLS.MAX_HISTORY]: 200,
    [LOGGER_SYMBOLS.DEBUG]: debug,
    [LOGGER_SYMBOLS.INSTANCE_ID]: instanceId,
    [LOGGER_SYMBOLS.LEVEL]: debug ? 3 : 2,
  };

  const logMethod = function (level, message, data = null) {
    const levels = { error: 0, warn: 1, info: 2, debug: 3, success: 2 };
    const currentLevel = this[LOGGER_SYMBOLS.LEVEL] || 2;
    const msgLevel = levels[level] || 2;

    if (msgLevel > currentLevel) return;

    const timestamp = new Date().toISOString().slice(11, 23);
    const prefix = `[${timestamp}] [${this[LOGGER_SYMBOLS.INSTANCE_ID]}]`;

    this[LOGGER_SYMBOLS.HISTORY].push({
      timestamp,
      level,
      message,
      data,
      id: Date.now() + Math.random(),
    });

    if (this[LOGGER_SYMBOLS.HISTORY].length > this[LOGGER_SYMBOLS.MAX_HISTORY]) {
      this[LOGGER_SYMBOLS.HISTORY].shift();
    }

    const icons = { error: '❌', warn: '⚠️', info: 'ℹ️', debug: '🔍', success: '✅' };
    const icon = icons[level] || '📌';

    if (data !== null && data !== undefined) {
      console.log(`${icon} ${prefix} ${message}`, data);
    } else {
      console.log(`${icon} ${prefix} ${message}`);
    }
  };

  const boundLog = logMethod.bind(logState);

  const methods = {
    error: (msg, d) => boundLog('error', msg, d),
    warn: (msg, d) => boundLog('warn', msg, d),
    info: (msg, d) => boundLog('info', msg, d),
    debug: (msg, d) => boundLog('debug', msg, d),
    success: (msg, d) => boundLog('success', msg, d),

    // Добавляем header метод
    header: (title, color = '#636e72') => {
      console.log('%c' + '═'.repeat(60), `color: ${color};`);
      console.log(
        '%c  📦 ' + title,
        'background: #1a1a2e; color: #fff; padding: 4px 12px; border-radius: 4px; font-weight: bold;'
      );
      console.log('%c' + '═'.repeat(60), `color: ${color};`);
    },

    separator: (color = '#636e72') => {
      console.log('%c' + '─'.repeat(60), `color: ${color};`);
    },

    getHistory: function () {
      return [...this[LOGGER_SYMBOLS.HISTORY]];
    },

    clearHistory: function () {
      this[LOGGER_SYMBOLS.HISTORY] = [];
      return this;
    },

    setDebug: function (enabled) {
      this[LOGGER_SYMBOLS.DEBUG] = enabled;
      this[LOGGER_SYMBOLS.LEVEL] = enabled ? 3 : 2;
      return this;
    },
  };

  const logger = {};
  for (const [key, fn] of Object.entries(methods)) {
    logger[key] = fn.bind(logState);
  }

  logger[LOGGER_SYMBOLS.HISTORY] = logState[LOGGER_SYMBOLS.HISTORY];
  logger[LOGGER_SYMBOLS.MAX_HISTORY] = logState[LOGGER_SYMBOLS.MAX_HISTORY];
  logger[LOGGER_SYMBOLS.DEBUG] = logState[LOGGER_SYMBOLS.DEBUG];
  logger[LOGGER_SYMBOLS.INSTANCE_ID] = logState[LOGGER_SYMBOLS.INSTANCE_ID];
  logger[LOGGER_SYMBOLS.LEVEL] = logState[LOGGER_SYMBOLS.LEVEL];

  return logger;
}

// ============================================================
// 8. СОЗДАНИЕ ЛОГГЕРА
// ============================================================

const logger = createLogger(CONFIG.debug, 'Popup');

// ============================================================
// 9. ВАЛИДАТОР
// ============================================================

const VALIDATOR = {
  [PRIVATE.VALIDATE]: {
    isValidId: (id) => {
      return id && typeof id === 'string' && id.length > 0;
    },

    isValidQuery: (query) => {
      return query && typeof query === 'string' && query.trim().length >= CONFIG.searchMinLength;
    },

    isValidTab: (tab) => {
      return ['all', 'recent', 'tools', 'api'].includes(tab);
    },

    isValidBookmark: (bookmark) => {
      return bookmark && typeof bookmark === 'object' && bookmark.id;
    },

    isValidData: (data) => {
      return data && typeof data === 'object';
    },
  },

  [PRIVATE.SANITIZE]: {
    sanitizeQuery: (query) => {
      if (!query || typeof query !== 'string') return '';
      return query.trim().substring(0, 100);
    },

    sanitizeId: (id) => {
      if (!id) return null;
      return String(id).replace(/[^a-zA-Z0-9_-]/g, '');
    },

    sanitizeText: (text) => {
      if (!text) return '';
      return String(text).substring(0, 500);
    },

    sanitizeUrl: (url) => {
      if (!url) return '';
      return String(url).substring(0, 2000);
    },
  },

  [PRIVATE.ESCAPE]: {
    escapeHtml: (text) => {
      if (!text) return '';
      return String(text)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');
    },

    escapeJs: (text) => {
      if (!text) return '';
      return String(text)
        .replace(/\\/g, '\\\\')
        .replace(/"/g, '\\"')
        .replace(/'/g, "\\'")
        .replace(/\n/g, '\\n')
        .replace(/\r/g, '\\r');
    },

    escapeUrl: (url) => {
      if (!url) return '';
      return encodeURIComponent(url);
    },
  },

  [PRIVATE.SECURE]: {
    isSecureContext: () => {
      try {
        return window.isSecureContext || false;
      } catch {
        return false;
      }
    },

    isSafeObject: (obj) => {
      if (!obj || typeof obj !== 'object') return false;
      try {
        if (obj.constructor && obj.constructor.name !== 'Object') return false;
        const keys = Object.keys(obj);
        for (const key of keys) {
          if (typeof obj[key] === 'function') return false;
        }
        return true;
      } catch {
        return false;
      }
    },
  },
};

// ============================================================
// 10. ОСНОВНОЙ ОБЪЕКТ POPUP
// ============================================================

const Popup = {
  [PRIVATE.STATE]: STATE,
  [PRIVATE.CONFIG]: CONFIG,
  [PRIVATE.REFS]: REFS,
  [PRIVATE.LOGGER]: logger,

  // ==========================================
  // 10.1. ИНИЦИАЛИЗАЦИЯ
  // ==========================================

  [PRIVATE.INIT]() {
    const state = this[PRIVATE.STATE];
    const refs = this[PRIVATE.REFS];

    if (state[PRIVATE.INITIALIZED]) {
      logger.warn('⚠️ Popup уже инициализирован');
      return;
    }

    logger.header('ИНИЦИАЛИЗАЦИЯ POPUP (100% СИМВОЛЫ)');
    logger.info(`📦 Версия: ${CONFIG.version}`);
    logger.info(`📅 Сборка: ${CONFIG.build}`);
    logger.info(`📌 Отладка: ${CONFIG.debug ? '✅' : '❌'}`);
    logger.separator();

    try {
      // Получаем DOM элементы
      this[PRIVATE._initElements]();

      // Настраиваем слушатели
      this[PRIVATE._initListeners]();

      // Загружаем данные
      this[PRIVATE.LOAD_DATA]();

      // Настраиваем подписку на события
      this[PRIVATE._initSubscriptions]();

      state[PRIVATE.INITIALIZED] = true;
      state[PRIVATE.DESTROYED] = false;

      // Экспортируем символы
      this[PRIVATE.EXPORT_SYMBOLS]();

      logger.success('✅ Popup инициализирован');
      logger.header('ГОТОВ');

      this[PRIVATE.SHOW_STATUS]('📚 Готово', 'info');
    } catch (error) {
      logger.error('❌ Ошибка инициализации:', error);
      this[PRIVATE.SHOW_STATUS]('❌ Ошибка: ' + error.message, 'error');
    }
  },

  // ==========================================
  // 10.2. ИНИЦИАЛИЗАЦИЯ DOM ЭЛЕМЕНТОВ
  // ==========================================

  [PRIVATE._initElements]() {
    const refs = this[PRIVATE.REFS];

    refs.totalBookmarks = document.getElementById('totalBookmarks');
    refs.totalFolders = document.getElementById('totalFolders');
    refs.lastUpdate = document.getElementById('lastUpdate');

    refs.tabs = document.querySelectorAll('.tab-btn');
    refs.panels.all = document.getElementById('tab-all');
    refs.panels.recent = document.getElementById('tab-recent');
    refs.panels.tools = document.getElementById('tab-tools');
    refs.panels.api = document.getElementById('tab-api');

    refs.searchInput = document.getElementById('searchInput');
    refs.bookmarksTree = document.getElementById('bookmarksTree');
    refs.recentList = document.getElementById('recentList');

    refs.exportJsonBtn = document.getElementById('exportJsonBtn');
    refs.exportHtmlBtn = document.getElementById('exportHtmlBtn');
    refs.importJsonBtn = document.getElementById('importJsonBtn');
    refs.importJsonFile = document.getElementById('importJsonFile');
    refs.importHtmlBtn = document.getElementById('importHtmlBtn');
    refs.importHtmlFile = document.getElementById('importHtmlFile');
    refs.removeDuplicatesBtn = document.getElementById('removeDuplicatesBtn');
    refs.refreshBtn = document.getElementById('refreshBtn');
    refs.statusMessage = document.getElementById('statusMessage');
    refs.footerInfo = document.getElementById('footerInfo');
    refs.openFullManager = document.getElementById('openFullManager');

    const required = [
      'totalBookmarks',
      'totalFolders',
      'lastUpdate',
      'searchInput',
      'bookmarksTree',
      'recentList',
      'exportJsonBtn',
      'refreshBtn',
    ];

    for (const key of required) {
      if (!refs[key]) {
        logger.warn(`⚠️ Элемент не найден: ${key}`);
      }
    }

    return true;
  },

  // ==========================================
  // 10.3. ИНИЦИАЛИЗАЦИЯ СЛУШАТЕЛЕЙ
  // ==========================================

  [PRIVATE._initListeners]() {
    const refs = this[PRIVATE.REFS];
    const state = this[PRIVATE.STATE];
    const listeners = state[PRIVATE.EVENT_LISTENERS];

    // Вкладки
    if (refs.tabs) {
      const handler = this[PRIVATE.HANDLE_TAB_SWITCH].bind(this);
      refs.tabs.forEach((btn) => {
        btn.addEventListener('click', handler);
        listeners.add({ element: btn, event: 'click', handler });
      });
    }

    // Поиск
    if (refs.searchInput) {
      const handler = this[PRIVATE.HANDLE_SEARCH].bind(this);
      refs.searchInput.addEventListener('input', handler);
      listeners.add({ element: refs.searchInput, event: 'input', handler });
    }

    // Кнопки инструментов
    const buttonHandlers = [
      { el: refs.exportJsonBtn, handler: this[PRIVATE.EXPORT_JSON] },
      { el: refs.exportHtmlBtn, handler: this[PRIVATE.EXPORT_HTML] },
      { el: refs.removeDuplicatesBtn, handler: this[PRIVATE.REMOVE_DUPLICATES] },
      { el: refs.refreshBtn, handler: this[PRIVATE.REFRESH] },
      { el: refs.openFullManager, handler: this[PRIVATE.OPEN_MANAGER] },
    ];

    for (const { el, handler } of buttonHandlers) {
      if (el) {
        const boundHandler = handler.bind(this);
        el.addEventListener('click', boundHandler);
        listeners.add({ element: el, event: 'click', handler: boundHandler });
      }
    }

    // Импорт
    if (refs.importJsonBtn && refs.importJsonFile) {
      const clickHandler = () => refs.importJsonFile?.click();
      refs.importJsonBtn.addEventListener('click', clickHandler);
      listeners.add({ element: refs.importJsonBtn, event: 'click', handler: clickHandler });

      const changeHandler = this[PRIVATE.IMPORT_JSON].bind(this);
      refs.importJsonFile.addEventListener('change', changeHandler);
      listeners.add({ element: refs.importJsonFile, event: 'change', handler: changeHandler });
    }

    if (refs.importHtmlBtn && refs.importHtmlFile) {
      const clickHandler = () => refs.importHtmlFile?.click();
      refs.importHtmlBtn.addEventListener('click', clickHandler);
      listeners.add({ element: refs.importHtmlBtn, event: 'click', handler: clickHandler });

      const changeHandler = this[PRIVATE.IMPORT_HTML].bind(this);
      refs.importHtmlFile.addEventListener('change', changeHandler);
      listeners.add({ element: refs.importHtmlFile, event: 'change', handler: changeHandler });
    }

    // Клики по дереву
    if (refs.bookmarksTree) {
      const handler = this[PRIVATE.HANDLE_CLICK].bind(this);
      refs.bookmarksTree.addEventListener('click', handler);
      listeners.add({ element: refs.bookmarksTree, event: 'click', handler });
    }

    // Клики по списку недавних
    if (refs.recentList) {
      const handler = (e) => {
        const item = e.target.closest('.recent-item');
        if (item) {
          const url = item.dataset.url;
          if (url) {
            chrome.tabs.create({ url });
          }
        }
      };
      refs.recentList.addEventListener('click', handler);
      listeners.add({ element: refs.recentList, event: 'click', handler });
    }

    // Горячие клавиши
    const keyHandler = this[PRIVATE.HANDLE_KEYDOWN].bind(this);
    document.addEventListener('keydown', keyHandler);
    listeners.add({ element: document, event: 'keydown', handler: keyHandler });

    logger.debug(`✅ Зарегистрировано слушателей: ${listeners.size}`);
  },

  // ==========================================
  // 10.4. ПОДПИСКА НА СОБЫТИЯ
  // ==========================================

  [PRIVATE._initSubscriptions]() {
    const state = this[PRIVATE.STATE];

    try {
      const onMessage = (message) => {
        if (message?.action === 'broadcastEvent') {
          logger.debug(`📡 Событие: ${message.event}`, message.data);
          if (
            ['bookmark-created', 'bookmark-removed', 'bookmark-changed', 'bookmark-moved'].includes(
              message.event
            )
          ) {
            this[PRIVATE.LOAD_DATA]();
          }
        }
      };

      chrome.runtime.onMessage.addListener(onMessage);
      state[PRIVATE.SUBSCRIPTIONS].set('runtimeMessage', { callback: onMessage });

      logger.debug('✅ Подписка на события настроена');
    } catch (error) {
      logger.warn('⚠️ Не удалось настроить подписку на события:', error);
    }
  },

  // ==========================================
  // 10.5. ЗАГРУЗКА ДАННЫХ
  // ==========================================

  [PRIVATE.LOAD_DATA]() {
    this[PRIVATE.LOAD_STATS]();
    this[PRIVATE.LOAD_ALL]();
    this[PRIVATE.LOAD_RECENT]();
  },

  [PRIVATE.LOAD_STATS]() {
    const refs = this[PRIVATE.REFS];
    const state = this[PRIVATE.STATE];

    try {
      chrome.storage.local.get(['bookmarkStats', 'lastUpdate'], (result) => {
        if (chrome.runtime.lastError) {
          logger.warn('⚠️ Ошибка загрузки статистики:', chrome.runtime.lastError);
          return;
        }

        if (result.bookmarkStats) {
          state[PRIVATE.STATS] = result.bookmarkStats;
          this[PRIVATE.RENDER_STATS]();
        }

        if (result.lastUpdate) {
          const date = new Date(result.lastUpdate);
          if (refs.lastUpdate) {
            refs.lastUpdate.textContent = date.toLocaleTimeString('ru-RU', {
              hour: '2-digit',
              minute: '2-digit',
            });
          }
        }
      });
    } catch (error) {
      logger.error('❌ Ошибка загрузки статистики:', error);
    }
  },

  [PRIVATE.LOAD_ALL]() {
    const refs = this[PRIVATE.REFS];
    const state = this[PRIVATE.STATE];

    state[PRIVATE.IS_LOADING] = true;
    if (refs.bookmarksTree) {
      refs.bookmarksTree.innerHTML = '<div class="loading">⏳ Загрузка...</div>';
    }

    try {
      chrome.runtime.sendMessage({ action: 'getAll' }, (response) => {
        if (chrome.runtime.lastError) {
          logger.error('❌ Ошибка загрузки:', chrome.runtime.lastError);
          this[PRIVATE.SHOW_STATUS]('❌ Ошибка: ' + chrome.runtime.lastError.message, 'error');
          state[PRIVATE.IS_LOADING] = false;
          return;
        }

        if (response?.success) {
          state[PRIVATE.BOOKMARKS] = response.data;
          this[PRIVATE.RENDER_TREE]();
        } else {
          this[PRIVATE.SHOW_STATUS](
            '❌ Ошибка загрузки: ' + (response?.error || 'Unknown'),
            'error'
          );
        }

        state[PRIVATE.IS_LOADING] = false;
      });
    } catch (error) {
      logger.error('❌ Ошибка:', error);
      this[PRIVATE.SHOW_STATUS]('❌ Ошибка: ' + error.message, 'error');
      state[PRIVATE.IS_LOADING] = false;
    }
  },

  [PRIVATE.LOAD_RECENT]() {
    const refs = this[PRIVATE.REFS];
    const state = this[PRIVATE.STATE];

    state[PRIVATE.IS_LOADING] = true;
    if (refs.recentList) {
      refs.recentList.innerHTML = '<div class="loading">⏳ Загрузка...</div>';
    }

    try {
      chrome.runtime.sendMessage(
        { action: 'getRecent', data: { count: CONFIG.maxRecent } },
        (response) => {
          if (chrome.runtime.lastError) {
            logger.error('❌ Ошибка загрузки последних:', chrome.runtime.lastError);
            state[PRIVATE.IS_LOADING] = false;
            return;
          }

          if (response?.success) {
            state[PRIVATE.RECENT] = response.data;
            this[PRIVATE.RENDER_RECENT]();
          } else {
            if (refs.recentList) {
              refs.recentList.innerHTML = '<div class="empty-state">❌ Ошибка загрузки</div>';
            }
          }

          state[PRIVATE.IS_LOADING] = false;
        }
      );
    } catch (error) {
      logger.error('❌ Ошибка:', error);
      if (refs.recentList) {
        refs.recentList.innerHTML =
          '<div class="empty-state">❌ Ошибка: ' + error.message + '</div>';
      }
      state[PRIVATE.IS_LOADING] = false;
    }
  },

  // ==========================================
  // 10.6. ПОИСК
  // ==========================================

  [PRIVATE.SEARCH](query) {
    const refs = this[PRIVATE.REFS];
    const state = this[PRIVATE.STATE];
    const sanitized = VALIDATOR[PRIVATE.SANITIZE].sanitizeQuery(query);

    state[PRIVATE.SEARCH_QUERY] = sanitized;

    if (!sanitized || sanitized.length < CONFIG.searchMinLength) {
      this[PRIVATE.LOAD_ALL]();
      return;
    }

    state[PRIVATE.IS_LOADING] = true;
    if (refs.bookmarksTree) {
      refs.bookmarksTree.innerHTML = '<div class="loading">⏳ Поиск...</div>';
    }

    try {
      chrome.runtime.sendMessage({ action: 'search', data: sanitized }, (response) => {
        if (chrome.runtime.lastError) {
          logger.error('❌ Ошибка поиска:', chrome.runtime.lastError);
          state[PRIVATE.IS_LOADING] = false;
          return;
        }

        if (response?.success) {
          const results = response.data;
          if (results.length === 0) {
            if (refs.bookmarksTree) {
              refs.bookmarksTree.innerHTML =
                '<div class="empty-state"><span class="emoji">🔍</span>Ничего не найдено</div>';
            }
          } else {
            this[PRIVATE.RENDER_TREE](results);
          }
        } else {
          this[PRIVATE.SHOW_STATUS]('❌ Ошибка поиска: ' + (response?.error || 'Unknown'), 'error');
        }

        state[PRIVATE.IS_LOADING] = false;
      });
    } catch (error) {
      logger.error('❌ Ошибка:', error);
      this[PRIVATE.SHOW_STATUS]('❌ Ошибка: ' + error.message, 'error');
      state[PRIVATE.IS_LOADING] = false;
    }
  },

  // ==========================================
  // 10.7. РЕНДЕРИНГ
  // ==========================================

  [PRIVATE.RENDER_STATS]() {
    const refs = this[PRIVATE.REFS];
    const stats = this[PRIVATE.STATE][PRIVATE.STATS];

    if (refs.totalBookmarks) {
      refs.totalBookmarks.textContent = stats.totalBookmarks || 0;
    }
    if (refs.totalFolders) {
      refs.totalFolders.textContent = stats.totalFolders || 0;
    }
  },

  [PRIVATE.RENDER_TREE](data = null) {
    const refs = this[PRIVATE.REFS];
    const state = this[PRIVATE.STATE];

    if (!refs.bookmarksTree) return;

    const bookmarks = data || state[PRIVATE.BOOKMARKS];

    if (!bookmarks || bookmarks.length === 0 || !bookmarks[0]) {
      refs.bookmarksTree.innerHTML =
        '<div class="empty-state"><span class="emoji">📭</span>Нет закладок</div>';
      return;
    }

    const tree = bookmarks[0].children || [];
    const html = this[PRIVATE._buildTreeHTML](tree);
    refs.bookmarksTree.innerHTML =
      html || '<div class="empty-state"><span class="emoji">📭</span>Нет закладок</div>';
  },

  [PRIVATE._buildTreeHTML](nodes, depth = 0) {
    if (!nodes || nodes.length === 0) return '';

    let html = '';
    const escape = VALIDATOR[PRIVATE.ESCAPE].escapeHtml.bind(VALIDATOR);

    for (const node of nodes) {
      const isFolder = !node.url;
      const icon = isFolder ? '📁' : '🔖';
      const className = isFolder ? 'tree-item folder' : 'tree-item bookmark';
      const indent = depth > 0 ? ` style="padding-left:${Math.min(depth * 16, 160)}px;"` : '';
      const id = escape(node.id || '');
      const title = escape(node.title || 'Без названия');
      const url = escape(node.url || '');
      const childCount = node.children ? node.children.length : 0;

      html += `<div class="${className}" data-id="${id}"${indent}>`;
      html += `<span class="icon">${icon}</span>`;
      html += `<span class="title">${title}</span>`;

      if (!isFolder) {
        html += `<span class="url">${url}</span>`;
      } else if (childCount > 0) {
        html += `<span class="badge">${childCount}</span>`;
      }

      html += `<span class="actions">`;
      if (!isFolder) {
        html += `<button class="open-btn" title="Открыть">🔗</button>`;
      }
      html += `<button class="delete-btn danger" title="Удалить">🗑</button>`;
      html += `</span>`;
      html += `</div>`;

      if (isFolder && node.children && node.children.length > 0 && depth < CONFIG.maxTreeDepth) {
        html += `<div class="tree-children">${this[PRIVATE._buildTreeHTML](node.children, depth + 1)}</div>`;
      }
    }

    return html;
  },

  [PRIVATE.RENDER_RECENT]() {
    const refs = this[PRIVATE.REFS];
    const recent = this[PRIVATE.STATE][PRIVATE.RECENT];

    if (!refs.recentList) return;

    if (!recent || recent.length === 0) {
      refs.recentList.innerHTML =
        '<div class="empty-state"><span class="emoji">📭</span>Нет недавних закладок</div>';
      return;
    }

    const escape = VALIDATOR[PRIVATE.ESCAPE].escapeHtml.bind(VALIDATOR);
    let html = '';

    for (const item of recent) {
      const date = new Date(item.dateAdded || Date.now());
      const id = escape(item.id || '');
      const url = escape(item.url || '');
      const title = escape(item.title || 'Без названия');

      html += `
        <div class="recent-item" data-id="${id}" data-url="${url}">
          <span class="favicon">🔖</span>
          <div class="info">
            <span class="title">${title}</span>
            <span class="url">${url}</span>
          </div>
          <span class="date">${date.toLocaleDateString('ru-RU')}</span>
        </div>
      `;
    }

    refs.recentList.innerHTML = html;
  },

  // ==========================================
  // 10.8. ПЕРЕКЛЮЧЕНИЕ ВКЛАДОК
  // ==========================================

  [PRIVATE.SWITCH_TAB](tabId) {
    const refs = this[PRIVATE.REFS];
    const state = this[PRIVATE.STATE];

    if (!VALIDATOR[PRIVATE.VALIDATE].isValidTab(tabId)) {
      logger.warn(`⚠️ Некорректная вкладка: ${tabId}`);
      return;
    }

    state[PRIVATE.CURRENT_TAB] = tabId;

    if (refs.tabs) {
      refs.tabs.forEach((btn) => {
        btn.classList.toggle('active', btn.dataset.tab === tabId);
      });
    }

    Object.keys(refs.panels).forEach((key) => {
      if (refs.panels[key]) {
        refs.panels[key].classList.toggle('active', key === tabId);
      }
    });

    if (tabId === 'all') {
      const query = state[PRIVATE.SEARCH_QUERY];
      if (query && query.length >= CONFIG.searchMinLength) {
        this[PRIVATE.SEARCH](query);
      } else {
        this[PRIVATE.LOAD_ALL]();
      }
    } else if (tabId === 'recent') {
      this[PRIVATE.LOAD_RECENT]();
    }

    logger.debug(`📑 Переключено на вкладку: ${tabId}`);
  },

  // ==========================================
  // 10.9. ПОКАЗ СТАТУСА
  // ==========================================

  [PRIVATE.SHOW_STATUS](message, type = 'info') {
    const refs = this[PRIVATE.REFS];

    if (refs.statusMessage) {
      refs.statusMessage.textContent = message;
      refs.statusMessage.className = 'status-message ' + type;
    }

    if (refs.footerInfo) {
      refs.footerInfo.textContent = message;
    }

    if (type !== 'error') {
      const timeoutId = setTimeout(() => {
        this[PRIVATE.CLEAR_STATUS]();
      }, CONFIG.statusTimeout);

      const state = this[PRIVATE.STATE];
      if (state[PRIVATE._statusTimeout]) {
        clearTimeout(state[PRIVATE._statusTimeout]);
      }
      state[PRIVATE._statusTimeout] = timeoutId;
    }

    logger.debug(`📋 Статус: ${message} (${type})`);
  },

  [PRIVATE.CLEAR_STATUS]() {
    const refs = this[PRIVATE.REFS];

    if (refs.statusMessage) {
      refs.statusMessage.textContent = '';
      refs.statusMessage.className = 'status-message';
    }

    if (refs.footerInfo) {
      refs.footerInfo.textContent = 'Готово';
    }

    const state = this[PRIVATE.STATE];
    if (state[PRIVATE._statusTimeout]) {
      clearTimeout(state[PRIVATE._statusTimeout]);
      delete state[PRIVATE._statusTimeout];
    }
  },

  // ==========================================
  // 10.10. ИНСТРУМЕНТЫ
  // ==========================================

  [PRIVATE.EXPORT_JSON]() {
    try {
      chrome.runtime.sendMessage({ action: 'exportJSON' }, (response) => {
        if (chrome.runtime.lastError) {
          this[PRIVATE.SHOW_STATUS]('❌ Ошибка: ' + chrome.runtime.lastError.message, 'error');
          return;
        }
        this[PRIVATE.SHOW_STATUS]('✅ JSON экспортирован', 'success');
      });
    } catch (error) {
      this[PRIVATE.SHOW_STATUS]('❌ Ошибка: ' + error.message, 'error');
    }
  },

  [PRIVATE.EXPORT_HTML]() {
    try {
      chrome.runtime.sendMessage({ action: 'exportHTML' }, (response) => {
        if (chrome.runtime.lastError) {
          this[PRIVATE.SHOW_STATUS]('❌ Ошибка: ' + chrome.runtime.lastError.message, 'error');
          return;
        }
        this[PRIVATE.SHOW_STATUS]('✅ HTML экспортирован', 'success');
      });
    } catch (error) {
      this[PRIVATE.SHOW_STATUS]('❌ Ошибка: ' + error.message, 'error');
    }
  },

  [PRIVATE.IMPORT_JSON](event) {
    const file = event.target?.files?.[0];
    if (!file) return;

    try {
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const jsonString = e.target?.result;
          if (!jsonString) {
            this[PRIVATE.SHOW_STATUS]('❌ Ошибка чтения файла', 'error');
            return;
          }

          chrome.runtime.sendMessage({ action: 'importJSON', data: { jsonString } }, (response) => {
            if (chrome.runtime.lastError) {
              this[PRIVATE.SHOW_STATUS]('❌ Ошибка: ' + chrome.runtime.lastError.message, 'error');
              return;
            }
            if (response?.success) {
              this[PRIVATE.SHOW_STATUS]('✅ JSON импортирован', 'success');
              this[PRIVATE.LOAD_DATA]();
            } else {
              this[PRIVATE.SHOW_STATUS]('❌ Ошибка: ' + (response?.error || 'Unknown'), 'error');
            }
          });
        } catch (error) {
          this[PRIVATE.SHOW_STATUS]('❌ Ошибка: ' + error.message, 'error');
        }
      };
      reader.onerror = () => {
        this[PRIVATE.SHOW_STATUS]('❌ Ошибка чтения файла', 'error');
      };
      reader.readAsText(file);
    } catch (error) {
      this[PRIVATE.SHOW_STATUS]('❌ Ошибка: ' + error.message, 'error');
    } finally {
      if (event.target) {
        event.target.value = '';
      }
    }
  },

  [PRIVATE.IMPORT_HTML](event) {
    const file = event.target?.files?.[0];
    if (!file) return;

    try {
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const htmlString = e.target?.result;
          if (!htmlString) {
            this[PRIVATE.SHOW_STATUS]('❌ Ошибка чтения файла', 'error');
            return;
          }

          chrome.runtime.sendMessage({ action: 'importHTML', data: { htmlString } }, (response) => {
            if (chrome.runtime.lastError) {
              this[PRIVATE.SHOW_STATUS]('❌ Ошибка: ' + chrome.runtime.lastError.message, 'error');
              return;
            }
            if (response?.success) {
              this[PRIVATE.SHOW_STATUS]('✅ HTML импортирован', 'success');
              this[PRIVATE.LOAD_DATA]();
            } else {
              this[PRIVATE.SHOW_STATUS]('❌ Ошибка: ' + (response?.error || 'Unknown'), 'error');
            }
          });
        } catch (error) {
          this[PRIVATE.SHOW_STATUS]('❌ Ошибка: ' + error.message, 'error');
        }
      };
      reader.onerror = () => {
        this[PRIVATE.SHOW_STATUS]('❌ Ошибка чтения файла', 'error');
      };
      reader.readAsText(file);
    } catch (error) {
      this[PRIVATE.SHOW_STATUS]('❌ Ошибка: ' + error.message, 'error');
    } finally {
      if (event.target) {
        event.target.value = '';
      }
    }
  },

  [PRIVATE.REMOVE_DUPLICATES]() {
    if (!confirm('Удалить все дубликаты закладок?')) return;

    try {
      chrome.runtime.sendMessage({ action: 'removeDuplicates' }, (response) => {
        if (chrome.runtime.lastError) {
          this[PRIVATE.SHOW_STATUS]('❌ Ошибка: ' + chrome.runtime.lastError.message, 'error');
          return;
        }
        if (response?.success) {
          const count = response.data?.length || 0;
          this[PRIVATE.SHOW_STATUS](`✅ Удалено ${count} дубликатов`, 'success');
          this[PRIVATE.LOAD_DATA]();
        } else {
          this[PRIVATE.SHOW_STATUS]('❌ Ошибка: ' + (response?.error || 'Unknown'), 'error');
        }
      });
    } catch (error) {
      this[PRIVATE.SHOW_STATUS]('❌ Ошибка: ' + error.message, 'error');
    }
  },

  [PRIVATE.REFRESH]() {
    this[PRIVATE.LOAD_DATA]();
    this[PRIVATE.SHOW_STATUS]('🔄 Обновлено', 'info');
  },

  [PRIVATE.OPEN_MANAGER]() {
    try {
      chrome.tabs.create({ url: 'chrome://bookmarks/' });
    } catch (error) {
      this[PRIVATE.SHOW_STATUS]('❌ Ошибка: ' + error.message, 'error');
    }
  },

  // ==========================================
  // 10.11. ОБРАБОТЧИКИ СОБЫТИЙ
  // ==========================================

  [PRIVATE.HANDLE_TAB_SWITCH](event) {
    const btn = event.currentTarget;
    const tabId = btn.dataset.tab;
    if (tabId) {
      this[PRIVATE.SWITCH_TAB](tabId);
    }
  },

  [PRIVATE.HANDLE_SEARCH](event) {
    const value = event.target?.value || '';
    const query = VALIDATOR[PRIVATE.SANITIZE].sanitizeQuery(value);

    const state = this[PRIVATE.STATE];
    if (state[PRIVATE._searchTimeout]) {
      clearTimeout(state[PRIVATE._searchTimeout]);
    }

    state[PRIVATE._searchTimeout] = setTimeout(() => {
      this[PRIVATE.SEARCH](query);
    }, CONFIG.debounceDelay);
  },

  [PRIVATE.HANDLE_CLICK](event) {
    const target = event.target;
    const item = target.closest('.tree-item');

    if (!item) return;

    const id = item.dataset.id;
    const isFolder = item.classList.contains('folder');

    if (target.classList.contains('open-btn')) {
      const urlEl = item.querySelector('.url');
      if (urlEl) {
        const url = urlEl.textContent;
        if (url) {
          chrome.tabs.create({ url });
        }
      }
      return;
    }

    if (target.classList.contains('delete-btn')) {
      event.stopPropagation();
      if (!confirm('Удалить эту закладку?')) return;

      try {
        const action = isFolder ? 'removeTree' : 'remove';
        chrome.runtime.sendMessage({ action, data: { id } }, (response) => {
          if (chrome.runtime.lastError) {
            this[PRIVATE.SHOW_STATUS]('❌ Ошибка: ' + chrome.runtime.lastError.message, 'error');
            return;
          }
          if (response?.success) {
            this[PRIVATE.SHOW_STATUS](`✅ ${isFolder ? 'Папка' : 'Закладка'} удалена`, 'success');
            this[PRIVATE.LOAD_DATA]();
          } else {
            this[PRIVATE.SHOW_STATUS]('❌ Ошибка: ' + (response?.error || 'Unknown'), 'error');
          }
        });
      } catch (error) {
        this[PRIVATE.SHOW_STATUS]('❌ Ошибка: ' + error.message, 'error');
      }
      return;
    }

    if (!isFolder) {
      const urlEl = item.querySelector('.url');
      if (urlEl) {
        const url = urlEl.textContent;
        if (url) {
          chrome.tabs.create({ url });
        }
      }
    }
  },

  [PRIVATE.HANDLE_KEYDOWN](event) {
    if (event.ctrlKey && event.key === 'r') {
      event.preventDefault();
      this[PRIVATE.REFRESH]();
    }

    if (event.key === 'Escape') {
      const refs = this[PRIVATE.REFS];
      if (refs.searchInput && document.activeElement === refs.searchInput) {
        refs.searchInput.value = '';
        this[PRIVATE.SEARCH]('');
        refs.searchInput.blur();
      }
    }
  },

  // ==========================================
  // 10.12. УНИЧТОЖЕНИЕ
  // ==========================================

  [PRIVATE.DESTROY]() {
    const state = this[PRIVATE.STATE];

    if (state[PRIVATE.DESTROYED]) {
      logger.warn('⚠️ Popup уже уничтожен');
      return;
    }

    logger.info('🧹 Очистка Popup...');

    const listeners = state[PRIVATE.EVENT_LISTENERS];
    for (const { element, event, handler } of listeners) {
      try {
        element.removeEventListener(event, handler);
      } catch (error) {
        logger.warn(`⚠️ Ошибка удаления слушателя ${event}:`, error);
      }
    }
    listeners.clear();

    const subs = state[PRIVATE.SUBSCRIPTIONS];
    for (const [key, value] of subs) {
      try {
        if (value.callback && typeof value.callback === 'function') {
          chrome.runtime.onMessage.removeListener(value.callback);
        }
      } catch (error) {
        logger.warn(`⚠️ Ошибка отписки ${key}:`, error);
      }
    }
    subs.clear();

    if (state[PRIVATE._searchTimeout]) {
      clearTimeout(state[PRIVATE._searchTimeout]);
    }
    if (state[PRIVATE._statusTimeout]) {
      clearTimeout(state[PRIVATE._statusTimeout]);
    }

    state[PRIVATE.DESTROYED] = true;
    state[PRIVATE.INITIALIZED] = false;

    logger.success('✅ Popup уничтожен');
  },

  // ==========================================
  // 10.13. ЭКСПОРТ СИМВОЛОВ
  // ==========================================

  [PRIVATE.EXPORT_SYMBOLS]() {
    if (typeof window !== 'undefined') {
      window.__POPUP_SYMBOLS = {
        PRIVATE: { ...PRIVATE },
        PUBLIC: { ...PUBLIC },
      };

      window[PUBLIC.INSTANCE] = this;
      window.__popup = this;
    }
  },

  // ==========================================
  // 10.14. ПУБЛИЧНЫЕ МЕТОДЫ
  // ==========================================

  [PUBLIC.GET_STATE]() {
    const state = this[PRIVATE.STATE];
    return {
      bookmarks: state[PRIVATE.BOOKMARKS],
      recent: state[PRIVATE.RECENT],
      stats: state[PRIVATE.STATS],
      currentTab: state[PRIVATE.CURRENT_TAB],
      searchQuery: state[PRIVATE.SEARCH_QUERY],
      isLoading: state[PRIVATE.IS_LOADING],
      initialized: state[PRIVATE.INITIALIZED],
    };
  },

  [PUBLIC.GET_STATS]() {
    return this[PRIVATE.STATE][PRIVATE.STATS];
  },

  [PUBLIC.SEARCH](query) {
    return this[PRIVATE.SEARCH](query);
  },

  [PUBLIC.REFRESH]() {
    return this[PRIVATE.REFRESH]();
  },

  [PUBLIC.DESTROY]() {
    return this[PRIVATE.DESTROY]();
  },

  [PUBLIC.INIT]() {
    return this[PRIVATE.INIT]();
  },

  [PUBLIC.EXPORT](format = 'json') {
    if (format === 'json') {
      return this[PRIVATE.EXPORT_JSON]();
    }
    if (format === 'html') {
      return this[PRIVATE.EXPORT_HTML]();
    }
    throw new Error(`Неизвестный формат: ${format}`);
  },

  [PUBLIC.IMPORT](format = 'json', data) {
    if (format === 'json') {
      return this[PRIVATE.IMPORT_JSON]({
        target: { files: [{ text: () => Promise.resolve(data) }] },
      });
    }
    if (format === 'html') {
      return this[PRIVATE.IMPORT_HTML]({
        target: { files: [{ text: () => Promise.resolve(data) }] },
      });
    }
    throw new Error(`Неизвестный формат: ${format}`);
  },
};

// ============================================================
// 11. ЭКСПОРТЫ
// ============================================================

export { Popup, PRIVATE as POPUP_PRIVATE, PUBLIC as POPUP_PUBLIC, CONFIG as POPUP_CONFIG };
export default Popup;

// ============================================================
// 12. ИНИЦИАЛИЗАЦИЯ
// ============================================================

if (typeof window !== 'undefined' && typeof document !== 'undefined') {
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
      Popup[PRIVATE.INIT]();
    });
  } else {
    Popup[PRIVATE.INIT]();
  }
}

// ============================================================
// 13. КОНСОЛЬНЫЙ ИНТЕРФЕЙС
// ============================================================

if (typeof console !== 'undefined') {
  const privateCount = Object.keys(PRIVATE).length;
  const publicCount = Object.keys(PUBLIC).length;

  console.log('╔═══════════════════════════════════════════════════════════════════════════════╗');
  console.log('║              📦 POPUP (100% СИМВОЛЫ) v1.0.0                                 ║');
  console.log('╠═══════════════════════════════════════════════════════════════════════════════╣');
  console.log('║  📋 Все логи выводятся в консоль с цветовой разметкой                       ║');
  console.log('║  🔑 Полная изоляция через приватные символы                                 ║');
  console.log('║  🔓 Публичные символы через Symbol.for                                      ║');
  console.log('║  📊 Интеграция с BookmarksManager API                                       ║');
  console.log('║  📡 Подписка на события от background                                       ║');
  console.log('║  🔄 Автоматическое обновление при изменении закладок                        ║');
  console.log('║  ⚠️ Расширенная валидация и санитизация                                    ║');
  console.log('║  🛡️ Защита от XSS и инъекций                                               ║');
  console.log('║  🪟 Перемещение и ресайз окна                                              ║');
  console.log('╚═══════════════════════════════════════════════════════════════════════════════╝');

  console.log('📋 ДОСТУПНЫЕ КОМАНДЫ:');
  console.log('  Popup[PUBLIC.GET_STATE]() - получить состояние');
  console.log('  Popup[PUBLIC.GET_STATS]() - получить статистику');
  console.log('  Popup[PUBLIC.SEARCH](query) - поиск');
  console.log('  Popup[PUBLIC.REFRESH]() - обновить');
  console.log('  Popup[PUBLIC.EXPORT](format) - экспорт (json/html)');
  console.log('  Popup[PUBLIC.IMPORT](format, data) - импорт');
  console.log('  Popup[PUBLIC.DESTROY]() - уничтожить');
  console.log('');

  console.log('📊 СТАТИСТИКА СИМВОЛОВ:');
  console.log(`  🔑 Приватных символов: ${privateCount}`);
  console.log(`  🔓 Публичных символов: ${publicCount}`);
  console.log(`  📦 Всего символов: ${privateCount + publicCount}`);
  console.log('');

  console.log('✅ Popup загружен (100% символы)');
}

console.log(
  `📊 Popup: ${Object.keys(PRIVATE).length} приватных, ${Object.keys(PUBLIC).length} публичных символов`
);
console.log(`📦 Всего символов: ${Object.keys(PRIVATE).length + Object.keys(PUBLIC).length}`);
console.log(`📋 Версия: ${CONFIG.version} (${CONFIG.build})`);
