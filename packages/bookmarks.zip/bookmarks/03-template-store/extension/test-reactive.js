// ============================================================
// test-reactive.js
// 100% СИМВОЛЫ — полная изоляция и безопасность
// Версия: 2.4.0
// ============================================================

// ============================================================
// 1. ИМПОРТЫ
// ============================================================

import { createLogger } from './logger.js';

// ============================================================
// 2. ПРИВАТНЫЕ СИМВОЛЫ (100% изоляция)
// ============================================================

const PRIVATE = {
    LOGGER: Symbol('test.logger'),
    VERSION: Symbol('test.version'),
    BUILD: Symbol('test.build'),
    NAME: Symbol('test.name'),
    CONFIG: Symbol('test.config'),
    STATE: Symbol('test.state'),
    INITIALIZED: Symbol('test.initialized'),
    IS_CONNECTED: Symbol('test.isConnected'),
    REQUEST_COUNT: Symbol('test.request.count'),
    REQUEST_MAP: Symbol('test.request.map'),
    PENDING_REQUESTS: Symbol('test.pendingRequests'),
    UPDATE_COUNT: Symbol('test.updateCount'),
    ELEMENTS: Symbol('test.elements'),
    REFS: Symbol('test.refs'),
    STORAGE_KEY: Symbol('test.storageKey'),
    BOOKMARKLETS: Symbol('test.bookmarklets'),
    EDITING_ID: Symbol('test.editingId'),
    CURRENT_TYPE_FILTER: Symbol('test.currentTypeFilter'),
    CURRENT_LABEL_FILTER: Symbol('test.currentLabelFilter'),
    INIT: Symbol('test.init'),
    DESTROY: Symbol('test.destroy'),
    REQUEST: Symbol('test.request'),
    EXECUTE: Symbol('test.execute'),
    SET_STATUS: Symbol('test.setStatus'),
    SHOW_RESULT: Symbol('test.showResult'),
    SHOW_ERROR: Symbol('test.showError'),
    SHOW_INFO: Symbol('test.showInfo'),
    CLEAR_RESULT: Symbol('test.clearResult'),
    CHECK_CONNECTION: Symbol('test.checkConnection'),
    BIND_EVENTS: Symbol('test.bindEvents'),
    EXPORT_SYMBOLS: Symbol('test.exportSymbols'),
    ESCAPE: Symbol('test.escape'),
    SYNTAX_HIGHLIGHT: Symbol('test.syntaxHighlight'),
    GET_STATE: Symbol('test.getState'),
    GET_STATS: Symbol('test.getStats'),
    _INIT_ELEMENTS: Symbol('test._initElements'),
    SAVE_STATE: Symbol('test.saveState'),
    LOAD_STATE: Symbol('test.loadState'),
    CLEAR_STATE: Symbol('test.clearState'),
    ADD_BOOKMARKLET: Symbol('test.addBookmarklet'),
    EDIT_BOOKMARKLET: Symbol('test.editBookmarklet'),
    DELETE_BOOKMARKLET: Symbol('test.deleteBookmarklet'),
    SAVE_BOOKMARKLET: Symbol('test.saveBookmarklet'),
    RENDER_BOOKMARKLETS: Symbol('test.renderBookmarklets'),
    SHOW_ADD_FORM: Symbol('test.showAddForm'),
    HIDE_ADD_FORM: Symbol('test.hideAddForm'),
    COPY_BOOKMARKLET: Symbol('test.copyBookmarklet'),
    ADD_TO_BOOKMARKS: Symbol('test.addToBookmarks'),
    LOAD_FROM_BOOKMARKS: Symbol('test.loadFromBookmarks'),
    EXTRACT_LABEL: Symbol('test.extractLabel'),
    APPLY_TYPE_FILTER: Symbol('test.applyTypeFilter'),
    APPLY_LABEL_FILTER: Symbol('test.applyLabelFilter'),
    _addBookmarkFallback: Symbol('test._addBookmarkFallback'),
    _loadBookmarklets: Symbol('test._loadBookmarklets'),
    _saveBookmarklets: Symbol('test._saveBookmarklets'),
    _lastResultData: Symbol('test._lastResultData'),
    _bookmarkletsLoaded: Symbol('test._bookmarkletsLoaded'),
    TYPE_BOOKMARKLET: Symbol('test.type.bookmarklet'),
    TYPE_LINK: Symbol('test.type.link'),
    TYPE_FOLDER: Symbol('test.type.folder'),
    TYPE_OTHER: Symbol('test.type.other'),
    DETECT_TYPE: Symbol('test.detectType'),
    COLLECT_ALL_NODES: Symbol('test.collectAllNodes'),
};

// ============================================================
// 3. ПУБЛИЧНЫЕ СИМВОЛЫ (доступны через Symbol.for)
// ============================================================

const PUBLIC = {
    INSTANCE: Symbol.for('test.instance'),
    STATE: Symbol.for('test.state'),
    CONFIG: Symbol.for('test.config'),
    INIT: Symbol.for('test.init'),
    DESTROY: Symbol.for('test.destroy'),
    REQUEST: Symbol.for('test.request'),
    GET_STATE: Symbol.for('test.getState'),
    GET_STATS: Symbol.for('test.getStats'),
    CHECK_CONNECTION: Symbol.for('test.checkConnection'),
    SAVE_STATE: Symbol.for('test.saveState'),
    LOAD_STATE: Symbol.for('test.loadState'),
    CLEAR_STATE: Symbol.for('test.clearState'),
    LOAD_BOOKMARKS: Symbol.for('test.loadBookmarks'),
};

// ============================================================
// 4. КОНФИГУРАЦИЯ (с типами)
// ============================================================

const CONFIG = {
    version: '2.4.0',
    build: '2026-07-24',
    name: 'Reactive API Test',
    debug: true,
    timeout: 10000,
    maxRequests: 100,
    checkInterval: 30000,
    extensionId: 'fggmdcnkgmpefgjggdcekcflnijmnned',
    storageKey: 'reactive_test_state',
    bookmarkletsKey: 'bookmarks_data',

    bookmarkTypes: {
        'bookmarklet': { label: '📜 Букмарклет', icon: '📜', color: '#a78bfa' },
        'link': { label: '🔗 Ссылка', icon: '🔗', color: '#60a5fa' },
        'folder': { label: '📁 Папка', icon: '📁', color: '#fbbf24' },
        'other': { label: '📌 Другое', icon: '📌', color: '#8b96b0' },
    },

    typeColors: {
        'bookmarklet': '#a78bfa',
        'link': '#60a5fa',
        'folder': '#fbbf24',
        'other': '#8b96b0',
    },

    typeIcons: {
        'bookmarklet': '📜',
        'link': '🔗',
        'folder': '📁',
        'other': '📌',
    },

    labelColors: {
        'system': '#34d399',
        'default': '#8b96b0',
        'my': '#60a5fa',
        'custom': '#a78bfa',
        'user': '#fbbf24',
    },

    labelIcons: {
        'system': '🟢',
        'default': '⚪',
        'my': '🔵',
        'custom': '🟣',
        'user': '🟡',
    },

    sourceLabels: {
        'created': '➕ Создан',
        'bookmark': '📚 Из закладок',
    },
};

// ============================================================
// 5. СОСТОЯНИЕ
// ============================================================

const STATE = {
    [PRIVATE.INITIALIZED]: false,
    [PRIVATE.IS_CONNECTED]: false,
    [PRIVATE.REQUEST_COUNT]: 0,
    [PRIVATE.REQUEST_MAP]: new Map(),
    [PRIVATE.PENDING_REQUESTS]: 0,
    [PRIVATE.UPDATE_COUNT]: 0,
    [PRIVATE.STORAGE_KEY]: CONFIG.storageKey,
    [PRIVATE.BOOKMARKLETS]: [],
    [PRIVATE.EDITING_ID]: null,
    [PRIVATE._lastResultData]: null,
    [PRIVATE.CURRENT_TYPE_FILTER]: 'all',
    [PRIVATE.CURRENT_LABEL_FILTER]: 'all',
    [PRIVATE._bookmarkletsLoaded]: false,
};

// ============================================================
// 6. DOM РЕФЕРЕНСЫ
// ============================================================

const REFS = {
    statusBadge: null,
    statusText: null,
    statusInfo: null,
    resultBox: null,
    resultContent: null,
    resultTime: null,
    updateCounter: null,
    btnGetAll: null,
    btnGetStats: null,
    btnGetInfo: null,
    btnSearch: null,
    btnGetRecent: null,
    btnSearchExec: null,
    btnCreate: null,
    btnClear: null,
    btnReconnect: null,
    btnLoadBookmarks: null,
    btnLoadBookmarksList: null,
    searchInput: null,
    createTitle: null,
    createUrl: null,
    bookmarkletList: null,
    bookmarkletCount: null,
    bookmarkletAddForm: null,
    bookmarkletName: null,
    bookmarkletUrl: null,
    bookmarkletLabel: null,
    btnAddBookmarklet: null,
    btnSaveBookmarklet: null,
    btnCancelBookmarklet: null,
    bookmarkletFilters: null,
    filterLabelInput: null,
    typeFilterBtns: null,
    labelFilterBtns: null,
};

// ============================================================
// 7. СОЗДАНИЕ ЛОГГЕРА
// ============================================================

const logger = createLogger(CONFIG.debug, 'Test');

// ============================================================
// 8. ОСНОВНОЙ ОБЪЕКТ TEST (100% СИМВОЛЫ)
// ============================================================

const Test = {
    [PRIVATE.STATE]: STATE,
    [PRIVATE.CONFIG]: CONFIG,
    [PRIVATE.REFS]: REFS,
    [PRIVATE.LOGGER]: logger,

    // ============================================================
    // 8.1. ОПРЕДЕЛЕНИЕ ТИПА ЗАКЛАДКИ
    // ============================================================

    [PRIVATE.DETECT_TYPE]: function(node) {
        var isFolder = !node.url;
        var isBookmarklet = node.url && node.url.startsWith('javascript:');
        var isLink = node.url && (
            node.url.startsWith('http://') ||
            node.url.startsWith('https://') ||
            node.url.startsWith('ftp://') ||
            node.url.startsWith('file://')
        );

        if (isFolder) return 'folder';
        if (isBookmarklet) return 'bookmarklet';
        if (isLink) return 'link';
        return 'other';
    },

    // ============================================================
    // 8.2. СОХРАНЕНИЕ СОСТОЯНИЯ
    // ============================================================

    [PRIVATE.SAVE_STATE]: function() {
        var refs = this[PRIVATE.REFS];
        var state = this[PRIVATE.STATE];

        try {
            var data = {
                updateCount: state[PRIVATE.UPDATE_COUNT],
                isConnected: state[PRIVATE.IS_CONNECTED],
                searchValue: refs.searchInput ? refs.searchInput.value : '',
                createTitle: refs.createTitle ? refs.createTitle.value : '',
                createUrl: refs.createUrl ? refs.createUrl.value : '',
                resultHtml: refs.resultContent ? refs.resultContent.innerHTML : '',
                resultTime: refs.resultTime ? refs.resultTime.textContent : '',
                bookmarklets: state[PRIVATE.BOOKMARKLETS],
                typeFilter: state[PRIVATE.CURRENT_TYPE_FILTER],
                labelFilter: state[PRIVATE.CURRENT_LABEL_FILTER],
                timestamp: Date.now(),
            };

            sessionStorage.setItem(CONFIG.storageKey, JSON.stringify(data));
            this[PRIVATE._saveBookmarklets]();

            if (this[PRIVATE.LOGGER]) {
                this[PRIVATE.LOGGER].debug('💾 Состояние сохранено');
            }
            return true;
        } catch (error) {
            if (this[PRIVATE.LOGGER]) {
                this[PRIVATE.LOGGER].warn('⚠️ Ошибка сохранения состояния:', error);
            }
            return false;
        }
    },

    [PRIVATE._saveBookmarklets]: function() {
        var state = this[PRIVATE.STATE];
        try {
            localStorage.setItem(CONFIG.bookmarkletsKey, JSON.stringify(state[PRIVATE.BOOKMARKLETS]));
        } catch (error) {}
    },

    [PRIVATE._loadBookmarklets]: function() {
        try {
            var data = localStorage.getItem(CONFIG.bookmarkletsKey);
            if (data) {
                var parsed = JSON.parse(data);
                if (Array.isArray(parsed)) {
                    this[PRIVATE.STATE][PRIVATE.BOOKMARKLETS] = parsed;
                    return true;
                }
            }
        } catch (error) {}
        return false;
    },

    // ============================================================
    // 8.3. ЗАГРУЗКА СОСТОЯНИЯ
    // ============================================================

    [PRIVATE.LOAD_STATE]: function() {
        var refs = this[PRIVATE.REFS];
        var state = this[PRIVATE.STATE];
        var restored = false;

        this[PRIVATE._loadBookmarklets]();

        try {
            var raw = sessionStorage.getItem(CONFIG.storageKey);
            if (!raw) return false;

            var data = JSON.parse(raw);

            if (data.updateCount !== undefined) {
                state[PRIVATE.UPDATE_COUNT] = data.updateCount;
                if (refs.updateCounter) {
                    refs.updateCounter.textContent = data.updateCount;
                }
            }

            if (data.searchValue !== undefined && refs.searchInput) {
                refs.searchInput.value = data.searchValue;
            }
            if (data.createTitle !== undefined && refs.createTitle) {
                refs.createTitle.value = data.createTitle;
            }
            if (data.createUrl !== undefined && refs.createUrl) {
                refs.createUrl.value = data.createUrl;
            }

            if (data.resultHtml !== undefined && refs.resultContent) {
                refs.resultContent.innerHTML = data.resultHtml;
                restored = true;
            }
            if (data.resultTime !== undefined && refs.resultTime) {
                refs.resultTime.textContent = data.resultTime;
            }

            if (data.bookmarklets && Array.isArray(data.bookmarklets)) {
                state[PRIVATE.BOOKMARKLETS] = data.bookmarklets;
            }

            if (data.typeFilter !== undefined) {
                state[PRIVATE.CURRENT_TYPE_FILTER] = data.typeFilter;
            }
            if (data.labelFilter !== undefined) {
                state[PRIVATE.CURRENT_LABEL_FILTER] = data.labelFilter;
            }

            if (this[PRIVATE.LOGGER]) {
                this[PRIVATE.LOGGER].success('♻️ Состояние восстановлено (обновлений: ' + state[PRIVATE.UPDATE_COUNT] + ')');
            }
            return true;
        } catch (error) {
            if (this[PRIVATE.LOGGER]) {
                this[PRIVATE.LOGGER].warn('⚠️ Ошибка загрузки состояния:', error);
            }
            return false;
        }
    },

    [PRIVATE.CLEAR_STATE]: function() {
        try {
            sessionStorage.removeItem(CONFIG.storageKey);
            localStorage.removeItem(CONFIG.bookmarkletsKey);
            if (this[PRIVATE.LOGGER]) {
                this[PRIVATE.LOGGER].debug('🧹 Состояние очищено');
            }
            return true;
        } catch (error) {
            return false;
        }
    },

    // ============================================================
    // 8.4. ИЗВЛЕЧЕНИЕ ЛЕЙБЛА
    // ============================================================

    [PRIVATE.EXTRACT_LABEL]: function(title, url) {
        if (!title && !url) return 'default';

        if (title) {
            var match = title.match(/\[([^\]]+)\]/);
            if (match) {
                return match[1].toLowerCase().trim();
            }
        }

        if (url) {
            try {
                var urlObj = new URL(url);
                var params = new URLSearchParams(urlObj.search);
                if (params.has('label')) {
                    return params.get('label').toLowerCase().trim();
                }
            } catch (e) {}
        }

        if (url) {
            var codeMatch = url.match(/\/\/\s*@label\s+([^\s]+)/);
            if (codeMatch) {
                return codeMatch[1].toLowerCase().trim();
            }
        }

        return 'default';
    },

    // ============================================================
    // 8.5. ЗАГРУЗКА ИЗ ЗАКЛАДОК — СОБИРАЕМ ВСЕ ТИПЫ
    // ============================================================

    [PRIVATE.LOAD_FROM_BOOKMARKS]: async function() {
        var state = this[PRIVATE.STATE];
        var logger = this[PRIVATE.LOGGER];
        var self = this;

        try {
            logger.info('📚 Загрузка закладок из браузера...');
            this[PRIVATE.SET_STATUS]('checking', '⏳ Загрузка...', 'Поиск закладок');

            var allBookmarks = await this[PRIVATE.REQUEST]('getAll', []);
            var tree = allBookmarks[0]?.children || [];

            var foundNodes = [];

            function collectAllNodes(nodes, path, depth) {
                if (depth === undefined) depth = 0;
                if (path === undefined) path = '';

                for (var i = 0; i < nodes.length; i++) {
                    var node = nodes[i];

                    var type = self[PRIVATE.DETECT_TYPE](node);
                    var label = self[PRIVATE.EXTRACT_LABEL](node.title, node.url);

                    foundNodes.push({
                        id: node.id,
                        name: node.title || (type === 'folder' ? 'Без названия' : 'Без названия'),
                        url: node.url || '',
                        bookmarkId: node.id,
                        type: type,
                        label: label || 'default',
                        source: 'bookmark',
                        path: path || '',
                        dateAdded: node.dateAdded || Date.now(),
                        children: node.children ? node.children.length : 0,
                        depth: depth,
                        isFolder: type === 'folder',
                        dateLastUsed: node.dateLastUsed || null,
                        index: node.index || 0,
                    });

                    if (node.children && node.children.length > 0) {
                        var newPath = path + '/' + (node.title || '');
                        collectAllNodes(node.children, newPath, depth + 1);
                    }
                }
            }

            collectAllNodes(tree);

            var bookmarkletsCount = foundNodes.filter(function(n) { return n.type === 'bookmarklet'; }).length;
            var linksCount = foundNodes.filter(function(n) { return n.type === 'link'; }).length;
            var foldersCount = foundNodes.filter(function(n) { return n.type === 'folder'; }).length;
            var otherCount = foundNodes.filter(function(n) { return n.type === 'other'; }).length;

            logger.info('📚 Найдено ' + foundNodes.length + ' элементов (все типы)');
            logger.info('  📜 Букмарклетов: ' + bookmarkletsCount);
            logger.info('  🔗 Ссылок: ' + linksCount);
            logger.info('  📁 Папок: ' + foldersCount);
            logger.info('  📌 Других: ' + otherCount);

            var existing = state[PRIVATE.BOOKMARKLETS] || [];
            var existingIds = new Set();
            for (var j = 0; j < existing.length; j++) {
                if (existing[j].bookmarkId) {
                    existingIds.add(existing[j].bookmarkId);
                }
            }

            var addedCount = 0;
            for (var k = 0; k < foundNodes.length; k++) {
                var node = foundNodes[k];
                if (!existingIds.has(node.bookmarkId)) {
                    existing.push({
                        id: node.id,
                        name: node.name,
                        url: node.url,
                        bookmarkId: node.bookmarkId,
                        type: node.type,
                        label: node.label || 'default',
                        source: 'bookmark',
                        path: node.path || '',
                        createdAt: node.dateAdded || Date.now(),
                        children: node.children,
                        depth: node.depth,
                        isFolder: node.isFolder,
                        dateLastUsed: node.dateLastUsed,
                        index: node.index,
                    });
                    addedCount++;
                    existingIds.add(node.bookmarkId);
                }
            }

            state[PRIVATE.BOOKMARKLETS] = existing;
            state[PRIVATE._bookmarkletsLoaded] = true;
            this[PRIVATE._saveBookmarklets]();

            logger.success('✅ Добавлено ' + addedCount + ' новых элементов из закладок');
            this[PRIVATE.RENDER_BOOKMARKLETS]();
            this[PRIVATE.SET_STATUS]('connected', '✅ Готово', 'Загружено ' + existing.length + ' элементов');
            return foundNodes.length;

        } catch (error) {
            logger.error('❌ Ошибка загрузки из закладок:', error);
            this[PRIVATE.SHOW_ERROR]('Ошибка загрузки из закладок: ' + error.message);
            this[PRIVATE.SET_STATUS]('disconnected', '❌ Ошибка', error.message);
            return 0;
        }
    },

    // ============================================================
    // 8.6. БУКМАРКЛЕТЫ: CRUD
    // ============================================================

    [PRIVATE.ADD_BOOKMARKLET]: async function(name, url, label) {
        var state = this[PRIVATE.STATE];
        var logger = this[PRIVATE.LOGGER];
        var self = this;

        try {
            var result = await this[PRIVATE.EXECUTE]('create', ['1', name, url]);
            var bookmarkId = result.id;

            var type = this[PRIVATE.DETECT_TYPE]({ url: url });

            var bookmarklet = {
                id: Date.now().toString(36) + '_' + Math.random().toString(36).substr(2, 6),
                name: name || 'Без названия',
                url: url || 'javascript:void(0)',
                bookmarkId: bookmarkId,
                type: type,
                label: label || 'custom',
                source: 'created',
                createdAt: Date.now(),
                children: 0,
                isFolder: type === 'folder',
                depth: 0,
            };

            state[PRIVATE.BOOKMARKLETS].push(bookmarklet);
            this[PRIVATE._saveBookmarklets]();
            this[PRIVATE.RENDER_BOOKMARKLETS]();

            logger.success('✅ Элемент добавлен: ' + bookmarklet.name + ' [' + bookmarklet.type + ':' + bookmarklet.label + ']');
            this[PRIVATE.SHOW_INFO]('✅ Добавлен: ' + bookmarklet.name);
            return bookmarklet;

        } catch (error) {
            logger.error('❌ Ошибка добавления:', error);
            this[PRIVATE.SHOW_ERROR]('❌ Ошибка: ' + error.message);
            return null;
        }
    },

    [PRIVATE.EDIT_BOOKMARKLET]: function(id, name, url, label) {
        var state = this[PRIVATE.STATE];
        var index = state[PRIVATE.BOOKMARKLETS].findIndex(function(b) { return b.id === id; });

        if (index === -1) {
            this[PRIVATE.SHOW_ERROR]('❌ Элемент не найден');
            return false;
        }

        var node = state[PRIVATE.BOOKMARKLETS][index];
        node.name = name || node.name;
        node.url = url || node.url;
        if (label) {
            node.label = label;
        }
        node.type = this[PRIVATE.DETECT_TYPE]({ url: node.url });
        node.updatedAt = Date.now();

        this[PRIVATE._saveBookmarklets]();
        this[PRIVATE.RENDER_BOOKMARKLETS]();
        this[PRIVATE.SHOW_INFO]('✅ Обновлен: ' + node.name);

        return true;
    },

    [PRIVATE.DELETE_BOOKMARKLET]: async function(id) {
        var state = this[PRIVATE.STATE];
        var index = state[PRIVATE.BOOKMARKLETS].findIndex(function(b) { return b.id === id; });

        if (index === -1) {
            this[PRIVATE.SHOW_ERROR]('❌ Элемент не найден');
            return false;
        }

        var node = state[PRIVATE.BOOKMARKLETS][index];
        var name = node.name;

        if (node.bookmarkId) {
            try {
                await this[PRIVATE.EXECUTE]('remove', [node.bookmarkId]);
                this[PRIVATE.SHOW_INFO]('🗑 Закладка удалена из Chrome');
            } catch (error) {
                console.warn('⚠️ Не удалось удалить закладку из Chrome:', error);
            }
        }

        state[PRIVATE.BOOKMARKLETS].splice(index, 1);
        this[PRIVATE._saveBookmarklets]();
        this[PRIVATE.RENDER_BOOKMARKLETS]();
        this[PRIVATE.SHOW_INFO]('🗑 Удален: ' + name);

        return true;
    },

    [PRIVATE.COPY_BOOKMARKLET]: function(id) {
        var state = this[PRIVATE.STATE];
        var node = state[PRIVATE.BOOKMARKLETS].find(function(b) { return b.id === id; });

        if (!node) {
            this[PRIVATE.SHOW_ERROR]('❌ Элемент не найден');
            return false;
        }

        var text = node.url || node.name;

        if (navigator.clipboard) {
            navigator.clipboard.writeText(text).then(function() {
                Test[PRIVATE.SHOW_INFO]('📋 Скопирован: ' + node.name);
                Test[PRIVATE.LOGGER].success('📋 Скопирован: ' + node.name);
            }).catch(function() {
                Test[PRIVATE._copyFallback](text);
            });
        } else {
            Test[PRIVATE._copyFallback](text);
        }
        return true;
    },

    [PRIVATE._copyFallback]: function(text) {
        var textarea = document.createElement('textarea');
        textarea.value = text;
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand('copy');
        document.body.removeChild(textarea);
        this[PRIVATE.SHOW_INFO]('📋 Скопирован (fallback)');
    },

    // ============================================================
    // 8.7. ДОБАВЛЕНИЕ В ЗАКЛАДКИ
    // ============================================================

    [PRIVATE.ADD_TO_BOOKMARKS]: async function(id) {
        var state = this[PRIVATE.STATE];
        var node = state[PRIVATE.BOOKMARKLETS].find(function(b) { return b.id === id; });

        if (!node) {
            this[PRIVATE.SHOW_ERROR]('❌ Элемент не найден');
            return false;
        }

        if (node.bookmarkId) {
            this[PRIVATE.SHOW_INFO]('ℹ️ Уже в закладках');
            return false;
        }

        var url = node.url;
        if (!url.startsWith('javascript:') && !url.startsWith('http://') && !url.startsWith('https://')) {
            url = 'javascript:' + url;
        }

        try {
            var result = await this[PRIVATE.EXECUTE]('create', ['1', node.name, url]);
            node.bookmarkId = result.id;
            node.source = 'created';
            this[PRIVATE._saveBookmarklets]();
            this[PRIVATE.RENDER_BOOKMARKLETS]();
            this[PRIVATE.SHOW_INFO]('✅ Добавлен в закладки: ' + node.name);
            return true;
        } catch (error) {
            this[PRIVATE.SHOW_ERROR]('❌ Ошибка: ' + error.message);
            return false;
        }
    },

    // ============================================================
    // 8.8. РЕНДЕРИНГ С ДВОЙНОЙ ФИЛЬТРАЦИЕЙ
    // ============================================================

    [PRIVATE.APPLY_TYPE_FILTER]: function(filter) {
        var state = this[PRIVATE.STATE];
        state[PRIVATE.CURRENT_TYPE_FILTER] = filter || 'all';
        this[PRIVATE.RENDER_BOOKMARKLETS]();
    },

    [PRIVATE.APPLY_LABEL_FILTER]: function(filter) {
        var state = this[PRIVATE.STATE];
        state[PRIVATE.CURRENT_LABEL_FILTER] = filter || 'all';
        this[PRIVATE.RENDER_BOOKMARKLETS]();
    },

    [PRIVATE.RENDER_BOOKMARKLETS]: function() {
        var refs = this[PRIVATE.REFS];
        var state = this[PRIVATE.STATE];
        var self = this;
        var config = this[PRIVATE.CONFIG];

        if (!refs.bookmarkletList) return;

        var allNodes = state[PRIVATE.BOOKMARKLETS] || [];
        var typeFilter = state[PRIVATE.CURRENT_TYPE_FILTER] || 'all';
        var labelFilter = state[PRIVATE.CURRENT_LABEL_FILTER] || 'all';

        var filtered = allNodes;

        if (typeFilter !== 'all' && typeFilter !== '') {
            filtered = filtered.filter(function(node) {
                return node.type === typeFilter;
            });
        }

        if (labelFilter !== 'all' && labelFilter !== '') {
            filtered = filtered.filter(function(node) {
                return node.label === labelFilter;
            });
        }

        var typeOrder = { 'folder': 0, 'bookmarklet': 1, 'link': 2, 'other': 3 };
        filtered.sort(function(a, b) {
            var orderA = typeOrder[a.type] !== undefined ? typeOrder[a.type] : 4;
            var orderB = typeOrder[b.type] !== undefined ? typeOrder[b.type] : 4;
            if (orderA !== orderB) return orderA - orderB;
            return a.name.localeCompare(b.name);
        });

        if (refs.bookmarkletCount) {
            refs.bookmarkletCount.textContent = '(' + filtered.length + '/' + allNodes.length + ')';
        }

        if (filtered.length === 0) {
            refs.bookmarkletList.innerHTML = `
                <div class="bookmarklet-empty">
                    <span class="emoji">📭</span>
                    ${allNodes.length === 0 ? 'Нет закладок. Нажмите "📚 Загрузить из закладок"' :
                'Нет элементов с таким фильтром'}
                </div>
            `;
            return;
        }

        var html = '';
        var escape = function(text) {
            if (!text) return '';
            return String(text).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
        };

        var typeColors = config.typeColors || {};
        var typeIcons = config.typeIcons || {};
        var labelColors = config.labelColors || {};
        var labelIcons = config.labelIcons || {};
        var sourceLabels = config.sourceLabels || {};

        var typeLabels = {
            'bookmarklet': 'Букмарклет',
            'link': 'Ссылка',
            'folder': 'Папка',
            'other': 'Другое',
        };

        for (var i = 0; i < filtered.length; i++) {
            var node = filtered[i];
            var displayUrl = node.url ? (node.url.length > 60 ? node.url.substring(0, 60) + '...' : node.url) : '—';
            var typeColor = typeColors[node.type] || '#8b96b0';
            var typeIcon = typeIcons[node.type] || '📌';
            var typeLabel = typeLabels[node.type] || 'Другое';
            var isInBookmarks = !!node.bookmarkId;
            var isFolder = node.type === 'folder';
            var labelColor = labelColors[node.label] || '#8b96b0';
            var labelIcon = labelIcons[node.label] || '🏷️';

            html += `
                <div class="bookmarklet-item" data-id="${escape(node.id)}" data-type="${escape(node.type)}" data-label="${escape(node.label)}">
                    <div class="info">
                        <div class="name">
                            ${typeIcon} ${escape(node.name)}
                            <span class="type-badge ${escape(node.type)}">
                                ${typeIcon} ${typeLabel}
                            </span>
                            <span class="label-badge" style="color:${labelColor};background:rgba(255,255,255,0.05);">
                                ${labelIcon} ${escape(node.label || 'default')}
                            </span>
                            <span class="source-badge">${sourceLabels[node.source] || '📚'}</span>
                            ${isInBookmarks ? '' :
                '<span class="source-badge warning">⚠️ не в закладках</span>'
            }
                            ${isFolder ? `<span class="children-count">📂 ${node.children || 0}</span>` : ''}
                            ${node.depth > 0 ? `<span class="depth-indicator">📎 d${node.depth}</span>` : ''}
                        </div>
                        <div class="url">${escape(displayUrl)}</div>
                    </div>
                    <div class="actions">
                        ${!isFolder ? `<button class="btn btn-copy btn-sm bookmarklet-copy" data-id="${escape(node.id)}" title="Копировать URL">📋</button>` : ''}
                        <button class="btn btn-edit btn-sm bookmarklet-edit" data-id="${escape(node.id)}" title="Редактировать">✏️</button>
                        <button class="btn btn-delete btn-sm bookmarklet-delete" data-id="${escape(node.id)}" title="Удалить">🗑</button>
                        ${isInBookmarks ? '' :
                `<button class="btn btn-bookmark btn-sm bookmarklet-add" data-id="${escape(node.id)}" title="Добавить в закладки">⭐</button>`
            }
                    </div>
                </div>
            `;
        }

        refs.bookmarkletList.innerHTML = html;

        refs.bookmarkletList.querySelectorAll('.bookmarklet-copy').forEach(function(btn) {
            btn.addEventListener('click', function(e) {
                e.stopPropagation();
                var id = this.dataset.id;
                self[PRIVATE.COPY_BOOKMARKLET](id);
            });
        });

        refs.bookmarkletList.querySelectorAll('.bookmarklet-edit').forEach(function(btn) {
            btn.addEventListener('click', function(e) {
                e.stopPropagation();
                var id = this.dataset.id;
                var node = state[PRIVATE.BOOKMARKLETS].find(function(b) { return b.id === id; });
                if (node) {
                    self[PRIVATE.SHOW_ADD_FORM](node);
                }
            });
        });

        refs.bookmarkletList.querySelectorAll('.bookmarklet-delete').forEach(function(btn) {
            btn.addEventListener('click', function(e) {
                e.stopPropagation();
                var id = this.dataset.id;
                var node = state[PRIVATE.BOOKMARKLETS].find(function(b) { return b.id === id; });
                if (node) {
                    var msg = 'Удалить "' + node.name + '"';
                    if (node.bookmarkId) {
                        msg += ' и соответствующую закладку из Chrome?';
                    } else {
                        msg += '?';
                    }
                    if (confirm(msg)) {
                        self[PRIVATE.DELETE_BOOKMARKLET](id);
                    }
                }
            });
        });

        refs.bookmarkletList.querySelectorAll('.bookmarklet-add').forEach(function(btn) {
            btn.addEventListener('click', function(e) {
                e.stopPropagation();
                var id = this.dataset.id;
                var node = state[PRIVATE.BOOKMARKLETS].find(function(b) { return b.id === id; });
                if (node) {
                    if (node.bookmarkId) {
                        self[PRIVATE.SHOW_INFO]('ℹ️ Уже в закладках');
                    } else {
                        self[PRIVATE.ADD_TO_BOOKMARKS](id);
                    }
                }
            });
        });
    },

    // ============================================================
    // 8.9. ФОРМА ДОБАВЛЕНИЯ/РЕДАКТИРОВАНИЯ
    // ============================================================

    [PRIVATE.SHOW_ADD_FORM]: function(bookmarklet) {
        var refs = this[PRIVATE.REFS];
        var state = this[PRIVATE.STATE];

        if (!refs.bookmarkletAddForm) return;

        refs.bookmarkletAddForm.style.display = 'flex';

        if (bookmarklet) {
            refs.bookmarkletName.value = bookmarklet.name || '';
            refs.bookmarkletUrl.value = bookmarklet.url || '';
            refs.bookmarkletLabel.value = bookmarklet.label || 'custom';
            state[PRIVATE.EDITING_ID] = bookmarklet.id;
            refs.btnSaveBookmarklet.textContent = '💾 Обновить';
            if (this[PRIVATE.LOGGER]) {
                this[PRIVATE.LOGGER].debug('✏️ Редактирование: ' + bookmarklet.name);
            }
        } else {
            refs.bookmarkletName.value = '';
            refs.bookmarkletUrl.value = 'javascript:';
            refs.bookmarkletLabel.value = 'my';
            state[PRIVATE.EDITING_ID] = null;
            refs.btnSaveBookmarklet.textContent = '💾 Сохранить';
        }

        refs.bookmarkletName.focus();
    },

    [PRIVATE.HIDE_ADD_FORM]: function() {
        var refs = this[PRIVATE.REFS];
        if (!refs.bookmarkletAddForm) return;

        refs.bookmarkletAddForm.style.display = 'none';
        this[PRIVATE.STATE][PRIVATE.EDITING_ID] = null;
        refs.btnSaveBookmarklet.textContent = '💾 Сохранить';
    },

    [PRIVATE.SAVE_BOOKMARKLET]: function() {
        var refs = this[PRIVATE.REFS];
        var state = this[PRIVATE.STATE];

        var name = refs.bookmarkletName.value.trim();
        var url = refs.bookmarkletUrl.value.trim();
        var label = refs.bookmarkletLabel.value.trim() || 'custom';

        if (!name) {
            this[PRIVATE.SHOW_ERROR]('❌ Введите название');
            refs.bookmarkletName.focus();
            return;
        }

        if (!url) {
            this[PRIVATE.SHOW_ERROR]('❌ Введите URL или код');
            refs.bookmarkletUrl.focus();
            return;
        }

        var finalUrl = url;
        if (!url.startsWith('javascript:') && !url.startsWith('http://') && !url.startsWith('https://')) {
            finalUrl = 'javascript:' + url;
        }

        var editingId = state[PRIVATE.EDITING_ID];

        if (editingId) {
            this[PRIVATE.EDIT_BOOKMARKLET](editingId, name, finalUrl, label);
        } else {
            this[PRIVATE.ADD_BOOKMARKLET](name, finalUrl, label);
        }

        this[PRIVATE.HIDE_ADD_FORM]();
    },

    // ============================================================
    // 8.10. ИНИЦИАЛИЗАЦИЯ
    // ============================================================

    [PRIVATE.INIT]: async function() {
        var state = this[PRIVATE.STATE];
        var self = this;

        if (state[PRIVATE.INITIALIZED]) {
            if (this[PRIVATE.LOGGER]) {
                this[PRIVATE.LOGGER].warn('⚠️ Test уже инициализирован');
            }
            return false;
        }

        var logger = this[PRIVATE.LOGGER];

        logger.header('ИНИЦИАЛИЗАЦИЯ REACTIVE TEST (100% СИМВОЛЫ)');
        logger.info('📦 Версия: ' + CONFIG.version);
        logger.info('📅 Сборка: ' + CONFIG.build);
        logger.info('📌 Отладка: ' + (CONFIG.debug ? '✅' : '❌'));
        logger.separator();

        try {
            this[PRIVATE._INIT_ELEMENTS]();

            var hasSavedState = this[PRIVATE.LOAD_STATE]();

            this[PRIVATE.BIND_EVENTS]();
            this[PRIVATE.EXPORT_SYMBOLS]();

            try {
                await this[PRIVATE.LOAD_FROM_BOOKMARKS]();
            } catch (error) {
                logger.warn('⚠️ Не удалось загрузить закладки:', error);
            }

            this[PRIVATE.RENDER_BOOKMARKLETS]();

            state[PRIVATE.INITIALIZED] = true;

            logger.success('✅ Reactive Test инициализирован');
            if (hasSavedState) {
                logger.success('♻️ Состояние восстановлено');
            }
            logger.success('📌 Элементов: ' + state[PRIVATE.BOOKMARKLETS].length);
            logger.header('ГОТОВ');

            this[PRIVATE.CHECK_CONNECTION]();

            setInterval(function() {
                Test[PRIVATE.CHECK_CONNECTION]();
            }, CONFIG.checkInterval);

            var inputs = [REFS.searchInput, REFS.createTitle, REFS.createUrl];
            for (var i = 0; i < inputs.length; i++) {
                var input = inputs[i];
                if (input) {
                    input.addEventListener('input', function() {
                        Test[PRIVATE.SAVE_STATE]();
                    });
                    input.addEventListener('change', function() {
                        Test[PRIVATE.SAVE_STATE]();
                    });
                }
            }

            var origShowResult = this[PRIVATE.SHOW_RESULT];
            this[PRIVATE.SHOW_RESULT] = function(data) {
                origShowResult.call(this, data);
                this[PRIVATE.SAVE_STATE]();
                state[PRIVATE._lastResultData] = data;
            };

            return true;
        } catch (error) {
            logger.error('❌ Ошибка инициализации:', error);
            return false;
        }
    },

    // ============================================================
    // 8.11. ИНИЦИАЛИЗАЦИЯ DOM ЭЛЕМЕНТОВ
    // ============================================================

    [PRIVATE._INIT_ELEMENTS]: function() {
        var refs = this[PRIVATE.REFS];

        refs.statusBadge = document.getElementById('statusBadge');
        refs.statusText = document.getElementById('statusText');
        refs.statusInfo = document.getElementById('statusInfo');
        refs.resultBox = document.getElementById('resultBox');
        refs.resultContent = document.getElementById('resultContent');
        refs.resultTime = document.getElementById('resultTime');
        refs.updateCounter = document.getElementById('updateCounter');

        refs.btnGetAll = document.getElementById('btnGetAll');
        refs.btnGetStats = document.getElementById('btnGetStats');
        refs.btnGetInfo = document.getElementById('btnGetInfo');
        refs.btnSearch = document.getElementById('btnSearch');
        refs.btnGetRecent = document.getElementById('btnGetRecent');
        refs.btnSearchExec = document.getElementById('btnSearchExec');
        refs.btnCreate = document.getElementById('btnCreate');
        refs.btnClear = document.getElementById('btnClear');
        refs.btnReconnect = document.getElementById('btnReconnect');
        refs.btnLoadBookmarks = document.getElementById('btnLoadBookmarks');
        refs.btnLoadBookmarksList = document.getElementById('btnLoadBookmarksList');

        refs.searchInput = document.getElementById('searchInput');
        refs.createTitle = document.getElementById('createTitle');
        refs.createUrl = document.getElementById('createUrl');

        refs.bookmarkletList = document.getElementById('bookmarkletList');
        refs.bookmarkletCount = document.getElementById('bookmarkletCount');
        refs.bookmarkletAddForm = document.getElementById('bookmarkletAddForm');
        refs.bookmarkletName = document.getElementById('bookmarkletName');
        refs.bookmarkletUrl = document.getElementById('bookmarkletUrl');
        refs.bookmarkletLabel = document.getElementById('bookmarkletLabel');
        refs.btnAddBookmarklet = document.getElementById('btnAddBookmarklet');
        refs.btnSaveBookmarklet = document.getElementById('btnSaveBookmarklet');
        refs.btnCancelBookmarklet = document.getElementById('btnCancelBookmarklet');
        refs.bookmarkletFilters = document.getElementById('bookmarkletFilters');
        refs.filterLabelInput = document.getElementById('filterLabelInput');

        refs.typeFilterBtns = document.querySelectorAll('.type-filter');
        refs.labelFilterBtns = document.querySelectorAll('.label-filter');

        var required = [
            'statusBadge', 'statusText', 'statusInfo',
            'resultBox', 'resultContent', 'resultTime',
            'updateCounter',
            'btnGetAll', 'btnGetStats', 'btnGetInfo',
            'btnSearch', 'btnGetRecent', 'btnSearchExec',
            'btnCreate', 'btnClear', 'btnReconnect',
            'searchInput', 'createTitle', 'createUrl',
            'bookmarkletList', 'bookmarkletCount',
            'bookmarkletAddForm', 'bookmarkletName', 'bookmarkletUrl', 'bookmarkletLabel',
            'btnAddBookmarklet', 'btnSaveBookmarklet', 'btnCancelBookmarklet',
            'bookmarkletFilters', 'filterLabelInput',
            'typeFilterBtns', 'labelFilterBtns'
        ];

        for (var i = 0; i < required.length; i++) {
            var key = required[i];
            if (!refs[key]) {
                logger.warn('⚠️ Элемент не найден: ' + key);
            }
        }

        return true;
    },

    // ============================================================
    // 8.12. ПРИВЯЗКА СОБЫТИЙ
    // ============================================================

    [PRIVATE.BIND_EVENTS]: function() {
        var refs = this[PRIVATE.REFS];
        var self = this;

        if (refs.btnGetAll) {
            refs.btnGetAll.addEventListener('click', function() {
                self[PRIVATE.EXECUTE]('getAll', [], 'getAll');
            });
        }

        if (refs.btnGetStats) {
            refs.btnGetStats.addEventListener('click', function() {
                self[PRIVATE.EXECUTE]('getStats', [], 'getStats');
            });
        }

        if (refs.btnGetInfo) {
            refs.btnGetInfo.addEventListener('click', function() {
                self[PRIVATE.EXECUTE]('getInfo', [], 'getInfo');
            });
        }

        if (refs.btnGetRecent) {
            refs.btnGetRecent.addEventListener('click', function() {
                self[PRIVATE.EXECUTE]('getRecent', [10], 'Последние 10');
            });
        }

        if (refs.btnSearch) {
            refs.btnSearch.addEventListener('click', function() {
                if (refs.btnSearchExec) {
                    refs.btnSearchExec.click();
                }
            });
        }

        if (refs.btnSearchExec) {
            refs.btnSearchExec.addEventListener('click', function() {
                var query = refs.searchInput?.value?.trim() || '';
                if (!query) {
                    self[PRIVATE.SHOW_ERROR]('Введите поисковый запрос');
                    return;
                }
                self[PRIVATE.EXECUTE]('search', [query], 'Поиск: "' + query + '"');
            });
        }

        if (refs.btnCreate) {
            refs.btnCreate.addEventListener('click', function() {
                var title = refs.createTitle?.value?.trim() || '';
                var url = refs.createUrl?.value?.trim() || '';
                if (!title) {
                    self[PRIVATE.SHOW_ERROR]('Введите название');
                    return;
                }
                if (!url) {
                    self[PRIVATE.SHOW_ERROR]('Введите URL');
                    return;
                }
                self[PRIVATE.EXECUTE]('create', ['1', title, url], 'Создано: "' + title + '"');
            });
        }

        if (refs.btnClear) {
            refs.btnClear.addEventListener('click', function() {
                self[PRIVATE.CLEAR_RESULT]();
                self[PRIVATE.CLEAR_STATE]();
            });
        }

        if (refs.btnReconnect) {
            refs.btnReconnect.addEventListener('click', function() {
                self[PRIVATE.CHECK_CONNECTION]();
            });
        }

        if (refs.btnLoadBookmarks || refs.btnLoadBookmarksList) {
            var loadHandler = function() {
                self[PRIVATE.LOAD_FROM_BOOKMARKS]();
            };
            if (refs.btnLoadBookmarks) {
                refs.btnLoadBookmarks.addEventListener('click', loadHandler);
            }
            if (refs.btnLoadBookmarksList) {
                refs.btnLoadBookmarksList.addEventListener('click', loadHandler);
            }
        }

        if (refs.btnAddBookmarklet) {
            refs.btnAddBookmarklet.addEventListener('click', function() {
                self[PRIVATE.SHOW_ADD_FORM](null);
            });
        }

        if (refs.btnSaveBookmarklet) {
            refs.btnSaveBookmarklet.addEventListener('click', function() {
                self[PRIVATE.SAVE_BOOKMARKLET]();
            });
        }

        if (refs.btnCancelBookmarklet) {
            refs.btnCancelBookmarklet.addEventListener('click', function() {
                self[PRIVATE.HIDE_ADD_FORM]();
            });
        }

        if (refs.bookmarkletName) {
            refs.bookmarkletName.addEventListener('keydown', function(e) {
                if (e.key === 'Enter') {
                    e.preventDefault();
                    refs.bookmarkletUrl.focus();
                }
            });
        }

        if (refs.bookmarkletUrl) {
            refs.bookmarkletUrl.addEventListener('keydown', function(e) {
                if (e.key === 'Enter') {
                    e.preventDefault();
                    refs.bookmarkletLabel.focus();
                }
            });
        }

        if (refs.bookmarkletLabel) {
            refs.bookmarkletLabel.addEventListener('keydown', function(e) {
                if (e.key === 'Enter') {
                    e.preventDefault();
                    self[PRIVATE.SAVE_BOOKMARKLET]();
                }
            });
        }

        if (refs.typeFilterBtns) {
            refs.typeFilterBtns.forEach(function(btn) {
                btn.addEventListener('click', function() {
                    refs.typeFilterBtns.forEach(function(b) {
                        b.classList.remove('active');
                    });
                    this.classList.add('active');
                    var filter = this.dataset.filter;
                    self[PRIVATE.APPLY_TYPE_FILTER](filter);
                });
            });
        }

        if (refs.labelFilterBtns) {
            refs.labelFilterBtns.forEach(function(btn) {
                btn.addEventListener('click', function() {
                    refs.labelFilterBtns.forEach(function(b) {
                        b.classList.remove('active');
                    });
                    this.classList.add('active');
                    var filter = this.dataset.filter;
                    self[PRIVATE.APPLY_LABEL_FILTER](filter);
                    if (refs.filterLabelInput) {
                        refs.filterLabelInput.value = '';
                    }
                });
            });
        }

        if (refs.filterLabelInput) {
            refs.filterLabelInput.addEventListener('input', function() {
                var value = this.value.trim().toLowerCase();
                if (refs.labelFilterBtns) {
                    refs.labelFilterBtns.forEach(function(b) {
                        b.classList.remove('active');
                    });
                }
                if (value) {
                    self[PRIVATE.APPLY_LABEL_FILTER](value);
                } else {
                    self[PRIVATE.APPLY_LABEL_FILTER]('all');
                    if (refs.labelFilterBtns) {
                        refs.labelFilterBtns.forEach(function(b) {
                            if (b.dataset.filter === 'all') {
                                b.classList.add('active');
                            }
                        });
                    }
                }
            });
        }

        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') {
                if (refs.bookmarkletAddForm && refs.bookmarkletAddForm.style.display !== 'none') {
                    self[PRIVATE.HIDE_ADD_FORM]();
                } else {
                    self[PRIVATE.CLEAR_RESULT]();
                }
            }
            if (e.ctrlKey && e.key === 'r') {
                e.preventDefault();
                self[PRIVATE.CHECK_CONNECTION]();
            }
            if (e.ctrlKey && e.key === 'n') {
                e.preventDefault();
                if (refs.btnAddBookmarklet) {
                    refs.btnAddBookmarklet.click();
                }
            }
            if (e.ctrlKey && e.key === 'l') {
                e.preventDefault();
                if (refs.btnLoadBookmarksList) {
                    refs.btnLoadBookmarksList.click();
                }
            }
        });

        window.addEventListener('beforeunload', function() {
            self[PRIVATE.SAVE_STATE]();
        });

        this[PRIVATE.LOGGER].debug('✅ События привязаны');
    },

    // ============================================================
    // 8.13. ЭКСПОРТ СИМВОЛОВ
    // ============================================================

    [PRIVATE.EXPORT_SYMBOLS]: function() {
        try {
            if (typeof window !== 'undefined') {
                window.__TEST_SYMBOLS = {
                    PRIVATE: { ...PRIVATE },
                    PUBLIC: { ...PUBLIC },
                    CONFIG: { ...CONFIG },
                };

                window.__TEST_SYMBOLS_INFO = {
                    privateCount: Object.keys(PRIVATE).length,
                    publicCount: Object.keys(PUBLIC).length,
                    totalCount: Object.keys(PRIVATE).length + Object.keys(PUBLIC).length,
                    version: CONFIG.version,
                    build: CONFIG.build,
                };

                window[PUBLIC.INSTANCE] = this;

                window.bmRequest = function(action, args) {
                    return Test[PRIVATE.REQUEST](action, args);
                };

                window.__debugTest = {
                    getState: function() { return Test[PUBLIC.GET_STATE](); },
                    getStats: function() { return Test[PUBLIC.GET_STATS](); },
                    checkConnection: function() { Test[PRIVATE.CHECK_CONNECTION](); },
                    clearResult: function() { Test[PRIVATE.CLEAR_RESULT](); },
                    saveState: function() { Test[PRIVATE.SAVE_STATE](); },
                    loadState: function() { Test[PRIVATE.LOAD_STATE](); },
                    clearState: function() { Test[PRIVATE.CLEAR_STATE](); },
                    getSymbols: function() {
                        return {
                            PRIVATE: { ...PRIVATE },
                            PUBLIC: { ...PUBLIC },
                        };
                    },
                    getConfig: function() { return { ...CONFIG }; },
                    request: function(action, args) { return Test[PRIVATE.REQUEST](action, args); },
                    getBookmarklets: function() { return Test[PRIVATE.STATE][PRIVATE.BOOKMARKLETS]; },
                    addBookmarklet: function(name, url, label) { return Test[PRIVATE.ADD_BOOKMARKLET](name, url, label); },
                    deleteBookmarklet: function(id) { return Test[PRIVATE.DELETE_BOOKMARKLET](id); },
                    loadFromBookmarks: function() { return Test[PRIVATE.LOAD_FROM_BOOKMARKS](); },
                    applyTypeFilter: function(filter) { return Test[PRIVATE.APPLY_TYPE_FILTER](filter); },
                    applyLabelFilter: function(filter) { return Test[PRIVATE.APPLY_LABEL_FILTER](filter); },
                };
            }

            this[PRIVATE.LOGGER].debug('✅ Символы экспортированы');
        } catch (error) {
            this[PRIVATE.LOGGER].error('❌ Ошибка экспорта символов:', error);
        }
    },

    // ============================================================
    // 8.14. ЗАПРОС К API
    // ============================================================

    [PRIVATE.REQUEST]: function(action, args) {
        var state = this[PRIVATE.STATE];
        var logger = this[PRIVATE.LOGGER];

        if (args === undefined) args = [];

        return new Promise(function(resolve, reject) {
            var id = Date.now() + '_' + Math.random().toString(36).substr(2, 9);

            state[PRIVATE.REQUEST_COUNT]++;
            state[PRIVATE.REQUEST_MAP].set(id, {
                action: action,
                args: args,
                timestamp: Date.now(),
                count: state[PRIVATE.REQUEST_COUNT],
            });

            var handler = function(event) {
                if (event.data?.action === 'response' && event.data?.id === id) {
                    window.removeEventListener('message', handler);
                    state[PRIVATE.REQUEST_MAP].delete(id);
                    state[PRIVATE.PENDING_REQUESTS]--;

                    if (event.data.success) {
                        resolve(event.data.result);
                    } else {
                        reject(new Error(event.data.error || 'Unknown error'));
                    }
                }
            };

            window.addEventListener('message', handler);
            state[PRIVATE.PENDING_REQUESTS]++;

            window.postMessage({
                action: 'apiCall',
                id: id,
                method: action,
                args: args,
                timestamp: Date.now(),
            }, '*');

            setTimeout(function() {
                window.removeEventListener('message', handler);
                state[PRIVATE.REQUEST_MAP].delete(id);
                state[PRIVATE.PENDING_REQUESTS]--;
                reject(new Error('Timeout: ' + action));
            }, CONFIG.timeout);

            if (logger) {
                logger.debug('📨 Запрос #' + state[PRIVATE.REQUEST_COUNT] + ': ' + action, args);
            }
        });
    },

    // ============================================================
    // 8.15. ВЫПОЛНЕНИЕ ЗАПРОСА
    // ============================================================

    [PRIVATE.EXECUTE]: function(action, args, label) {
        var self = this;
        var refs = this[PRIVATE.REFS];

        this[PRIVATE.SET_STATUS]('checking', '⏳ Выполняется...', 'Запрос: ' + (label || action));

        var btns = [
            refs.btnGetAll, refs.btnGetStats, refs.btnGetInfo,
            refs.btnSearch, refs.btnGetRecent, refs.btnSearchExec, refs.btnCreate
        ];
        for (var i = 0; i < btns.length; i++) {
            if (btns[i]) btns[i].disabled = true;
        }

        return this[PRIVATE.REQUEST](action, args)
            .then(function(result) {
                self[PRIVATE.SET_STATUS]('connected', '✅ Готово', 'Успешно');
                self[PRIVATE.SHOW_RESULT](result);
                self[PRIVATE.SAVE_STATE]();
                for (var j = 0; j < btns.length; j++) {
                    if (btns[j] && self[PRIVATE.STATE][PRIVATE.IS_CONNECTED]) {
                        btns[j].disabled = false;
                    }
                }
                return result;
            })
            .catch(function(error) {
                self[PRIVATE.SET_STATUS]('disconnected', '❌ Ошибка', error.message);
                self[PRIVATE.SHOW_ERROR](error.message);
                for (var k = 0; k < btns.length; k++) {
                    if (btns[k]) btns[k].disabled = false;
                }
                throw error;
            });
    },

    // ============================================================
    // 8.16. УСТАНОВКА СТАТУСА
    // ============================================================

    [PRIVATE.SET_STATUS]: function(status, message, info) {
        var refs = this[PRIVATE.REFS];
        var state = this[PRIVATE.STATE];

        if (refs.statusBadge) {
            refs.statusBadge.className = 'status-badge ' + status;
        }

        if (refs.statusText) {
            refs.statusText.textContent = message;
        }

        if (refs.statusInfo) {
            refs.statusInfo.textContent = info || '—';
        }

        state[PRIVATE.IS_CONNECTED] = (status === 'connected');

        var isConnected = state[PRIVATE.IS_CONNECTED];
        var buttons = [
            refs.btnGetAll, refs.btnGetStats, refs.btnGetInfo,
            refs.btnSearch, refs.btnGetRecent, refs.btnSearchExec, refs.btnCreate
        ];
        var inputs = [refs.searchInput, refs.createTitle, refs.createUrl];

        for (var i = 0; i < buttons.length; i++) {
            var btn = buttons[i];
            if (btn && !btn._isExecuting) {
                btn.disabled = !isConnected;
            }
        }
        for (var j = 0; j < inputs.length; j++) {
            var input = inputs[j];
            if (input) input.disabled = !isConnected;
        }

        if (this[PRIVATE.LOGGER]) {
            this[PRIVATE.LOGGER].debug('📋 Статус: ' + status + ' — ' + message);
        }
    },

    // ============================================================
    // 8.17. ПОКАЗ РЕЗУЛЬТАТА
    // ============================================================

    [PRIVATE.SHOW_RESULT]: function(data) {
        var refs = this[PRIVATE.REFS];
        var state = this[PRIVATE.STATE];
        var now = new Date();

        var currentData = state[PRIVATE._lastResultData];
        var dataChanged = true;

        if (currentData !== null && currentData !== undefined) {
            try {
                var currentStr = JSON.stringify(currentData);
                var newStr = JSON.stringify(data);
                if (currentStr === newStr) {
                    dataChanged = false;
                }
            } catch (e) {}
        }

        if (!dataChanged) {
            return;
        }

        state[PRIVATE._lastResultData] = data;

        if (refs.resultTime) {
            refs.resultTime.textContent = '🕐 ' + now.toLocaleTimeString('ru-RU', {
                hour: '2-digit',
                minute: '2-digit',
                second: '2-digit'
            });
        }

        if (!refs.resultContent) return;

        var html = '';

        try {
            if (data === undefined || data === null) {
                html = '<span class="json-null">null</span>';
            } else if (typeof data === 'string') {
                html = '<span class="json-string">"' + this[PRIVATE.ESCAPE](data) + '"</span>';
            } else if (typeof data === 'number') {
                html = '<span class="json-number">' + data + '</span>';
            } else if (typeof data === 'boolean') {
                html = '<span class="json-boolean">' + data + '</span>';
            } else if (Array.isArray(data)) {
                if (data.length === 0) {
                    html = '<span class="warn">[] (пустой массив)</span>';
                } else {
                    html = '<span class="success">📊 Массив (' + data.length + ' элементов)</span>\n';
                    html += this[PRIVATE.SYNTAX_HIGHLIGHT](JSON.stringify(data, null, 2));
                }
            } else if (typeof data === 'object') {
                if (Object.keys(data).length === 0) {
                    html = '<span class="warn">{}</span>';
                } else {
                    html = '<span class="info">📦 Объект (' + Object.keys(data).length + ' полей)</span>\n';
                    html += this[PRIVATE.SYNTAX_HIGHLIGHT](JSON.stringify(data, null, 2));
                }
            } else {
                html = String(data);
            }
        } catch (error) {
            html = '<span class="error">Ошибка отображения: ' + this[PRIVATE.ESCAPE](error.message) + '</span>';
        }

        refs.resultContent.innerHTML = html;

        state[PRIVATE.UPDATE_COUNT]++;
        if (refs.updateCounter) {
            refs.updateCounter.textContent = state[PRIVATE.UPDATE_COUNT];
        }
    },

    [PRIVATE.SHOW_ERROR]: function(error) {
        var refs = this[PRIVATE.REFS];
        var state = this[PRIVATE.STATE];
        var now = new Date();

        state[PRIVATE._lastResultData] = null;

        if (refs.resultTime) {
            refs.resultTime.textContent = '🕐 ' + now.toLocaleTimeString('ru-RU', {
                hour: '2-digit',
                minute: '2-digit',
                second: '2-digit'
            });
        }

        if (refs.resultContent) {
            refs.resultContent.innerHTML = '<span class="error">❌ Ошибка: ' + this[PRIVATE.ESCAPE](error) + '</span>';
        }

        state[PRIVATE.UPDATE_COUNT]++;
        if (refs.updateCounter) {
            refs.updateCounter.textContent = state[PRIVATE.UPDATE_COUNT];
        }
    },

    [PRIVATE.SHOW_INFO]: function(message) {
        var refs = this[PRIVATE.REFS];
        var state = this[PRIVATE.STATE];

        if (refs.resultContent) {
            var currentHtml = refs.resultContent.innerHTML;
            if (!currentHtml || currentHtml.includes('Нажмите кнопку') || currentHtml.includes('Результат очищен')) {
                refs.resultContent.innerHTML = '<span class="info">ℹ️ ' + this[PRIVATE.ESCAPE](message) + '</span>';
            }
        }
    },

    [PRIVATE.CLEAR_RESULT]: function() {
        var refs = this[PRIVATE.REFS];
        var state = this[PRIVATE.STATE];

        if (refs.resultContent) {
            refs.resultContent.innerHTML = '<span class="info">ℹ️ Результат очищен</span>';
        }

        if (refs.resultTime) {
            refs.resultTime.textContent = '—';
        }

        state[PRIVATE._lastResultData] = null;
        state[PRIVATE.UPDATE_COUNT]++;
        if (refs.updateCounter) {
            refs.updateCounter.textContent = state[PRIVATE.UPDATE_COUNT];
        }
    },

    // ============================================================
    // 8.18. ПРОВЕРКА ПОДКЛЮЧЕНИЯ
    // ============================================================

    [PRIVATE.CHECK_CONNECTION]: function() {
        var self = this;

        this[PRIVATE.SET_STATUS]('checking', '⏳ Проверка...', 'Подключение к расширению');

        this[PRIVATE.REQUEST]('getInfo', [])
            .then(function(info) {
                self[PRIVATE.SET_STATUS]('connected', '✅ Подключено', '');
                self[PRIVATE.SHOW_INFO]('Подключено к: ' + (info.name || 'Extension') + ' v' + (info.version || '?'));
                if (self[PRIVATE.LOGGER]) {
                    self[PRIVATE.LOGGER].success('✅ Подключено к расширению: ' + (info.name || 'Extension') + ' v' + (info.version || '?'));
                }
                self[PRIVATE.SAVE_STATE]();
            })
            .catch(function(error) {
                self[PRIVATE.SET_STATUS]('disconnected', '❌ Нет подключения', error.message);
                self[PRIVATE.SHOW_ERROR]('Нет подключения к расширению. Убедитесь, что расширение установлено и активно.');
                if (self[PRIVATE.LOGGER]) {
                    self[PRIVATE.LOGGER].error('❌ Нет подключения к расширению:', error.message);
                }
            });
    },

    // ============================================================
    // 8.19. ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ
    // ============================================================

    [PRIVATE.ESCAPE]: function(text) {
        if (!text) return '';
        return String(text)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#039;');
    },

    [PRIVATE.SYNTAX_HIGHLIGHT]: function(json) {
        json = json.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
        return json.replace(
            /(\"(?:[^\"\\]|\\.)*\"):?|(\b\d+\.?\d*\b)|(true|false|null)|(\"[^\"]*\")/g,
            function(match, key, number, bool, string) {
                if (key) return '<span class="json-key">' + key + '</span>';
                if (number) return '<span class="json-number">' + number + '</span>';
                if (bool) return '<span class="json-boolean">' + bool + '</span>';
                if (string) return '<span class="json-string">' + string + '</span>';
                return match;
            }
        );
    },

    // ============================================================
    // 8.20. ПУБЛИЧНЫЕ МЕТОДЫ
    // ============================================================

    [PUBLIC.GET_STATE]: function() {
        var state = this[PRIVATE.STATE];
        return {
            initialized: state[PRIVATE.INITIALIZED],
            isConnected: state[PRIVATE.IS_CONNECTED],
            requestCount: state[PRIVATE.REQUEST_COUNT],
            pendingRequests: state[PRIVATE.PENDING_REQUESTS],
            updateCount: state[PRIVATE.UPDATE_COUNT],
            requestMapSize: state[PRIVATE.REQUEST_MAP].size,
            bookmarklets: state[PRIVATE.BOOKMARKLETS],
            typeFilter: state[PRIVATE.CURRENT_TYPE_FILTER],
            labelFilter: state[PRIVATE.CURRENT_LABEL_FILTER],
            version: CONFIG.version,
            build: CONFIG.build,
        };
    },

    [PUBLIC.GET_STATS]: function() {
        var state = this[PRIVATE.STATE];
        return {
            totalRequests: state[PRIVATE.REQUEST_COUNT],
            pendingRequests: state[PRIVATE.PENDING_REQUESTS],
            isConnected: state[PRIVATE.IS_CONNECTED],
            updateCount: state[PRIVATE.UPDATE_COUNT],
            bookmarkletsCount: state[PRIVATE.BOOKMARKLETS].length,
            uptime: state[PRIVATE.INIT_TIME] ? Date.now() - state[PRIVATE.INIT_TIME] : 0,
        };
    },

    [PUBLIC.REQUEST]: function(action, args) {
        return this[PRIVATE.REQUEST](action, args);
    },

    [PUBLIC.CHECK_CONNECTION]: function() {
        return this[PRIVATE.CHECK_CONNECTION]();
    },

    [PUBLIC.SAVE_STATE]: function() {
        return this[PRIVATE.SAVE_STATE]();
    },

    [PUBLIC.LOAD_STATE]: function() {
        return this[PRIVATE.LOAD_STATE]();
    },

    [PUBLIC.CLEAR_STATE]: function() {
        return this[PRIVATE.CLEAR_STATE]();
    },

    [PUBLIC.LOAD_BOOKMARKS]: function() {
        return this[PRIVATE.LOAD_FROM_BOOKMARKS]();
    },

    [PUBLIC.INIT]: function() {
        return this[PRIVATE.INIT]();
    },

    [PUBLIC.DESTROY]: function() {
        return this[PRIVATE.DESTROY]();
    },

    // ============================================================
    // 8.21. УНИЧТОЖЕНИЕ
    // ============================================================

    [PRIVATE.DESTROY]: function() {
        var state = this[PRIVATE.STATE];
        var log = this[PRIVATE.LOGGER];

        if (!state[PRIVATE.INITIALIZED]) {
            if (log) log.warn('⚠️ Test не инициализирован');
            return;
        }

        if (log) log.info('🧹 Очистка Reactive Test...');

        this[PRIVATE.SAVE_STATE]();

        state[PRIVATE.REQUEST_MAP].clear();

        state[PRIVATE.INITIALIZED] = false;
        state[PRIVATE.IS_CONNECTED] = false;

        try {
            delete window.__TEST_SYMBOLS;
            delete window.__debugTest;
            delete window.bmRequest;
            delete window[PUBLIC.INSTANCE];
        } catch (error) {}

        if (log) log.success('✅ Reactive Test уничтожен');
    },
};

// ============================================================
// 9. ЭКСПОРТЫ
// ============================================================

export {
    Test,
    PRIVATE as TEST_PRIVATE,
    PUBLIC as TEST_PUBLIC,
    CONFIG as TEST_CONFIG,
    STATE as TEST_STATE,
    REFS as TEST_REFS,
};

export default Test;

// ============================================================
// 10. СТАТИСТИКА СИМВОЛОВ
// ============================================================

if (typeof console !== 'undefined') {
    var privateCount = Object.keys(PRIVATE).length;
    var publicCount = Object.keys(PUBLIC).length;

    console.log('📊 Test: ' + privateCount + ' приватных, ' + publicCount + ' публичных символов');
    console.log('📦 Всего символов: ' + (privateCount + publicCount));
    console.log('📋 Версия: ' + CONFIG.version + ' (' + CONFIG.build + ')');
}