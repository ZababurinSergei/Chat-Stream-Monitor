// ============================================================
// 100% СИМВОЛЫ — полная изоляция и безопасность
// Версия: 3.2.0
// ============================================================

// ============================================================
// 1. ПРИВАТНЫЕ СИМВОЛЫ (100% изоляция)
// ============================================================

const PRIVATE = {
  VERSION: Symbol('navigator.version'),
  BUILD: Symbol('navigator.build'),
  NAME: Symbol('navigator.name'),
  CONFIG: Symbol('navigator.config'),
  STATE: Symbol('navigator.state'),
  INITIALIZED: Symbol('navigator.initialized'),
  DESTROYED: Symbol('navigator.destroyed'),
  IS_EXECUTING: Symbol('navigator.isExecuting'),
  METHODS: Symbol('navigator.methods'),
  CURRENT_METHOD: Symbol('navigator.currentMethod'),
  CURRENT_URL: Symbol('navigator.currentUrl'),
  SELECTED_ID: Symbol('navigator.selectedId'),
  PARAM_VALUES: Symbol('navigator.paramValues'),
  LAST_RESULT: Symbol('navigator.lastResult'),
  ROOT_FOLDERS: Symbol('navigator.rootFolders'),
  ROOT_FOLDERS_CACHE: Symbol('navigator.rootFoldersCache'),
  ROOT_FOLDERS_CACHE_TIME: Symbol('navigator.rootFoldersCacheTime'),
  REFS: Symbol('navigator.refs'),
  INIT: Symbol('navigator.init'),
  DESTROY: Symbol('navigator.destroy'),
  RENDER_METHODS: Symbol('navigator.renderMethods'),
  RENDER_CATALOGS: Symbol('navigator.renderCatalogs'),
  RENDER_PARAMS: Symbol('navigator.renderParams'),
  UPDATE_URL: Symbol('navigator.updateUrl'),
  UPDATE_URL_PREVIEW: Symbol('navigator.updateUrlPreview'),
  SELECT_METHOD: Symbol('navigator.selectMethod'),
  EXECUTE: Symbol('navigator.execute'),
  GET_ROOT_FOLDERS: Symbol('navigator.getRootFolders'),
  GET_DEFAULT_PARENT_ID: Symbol('navigator.getDefaultParentId'),
  PROCESS_URL_PARAMS: Symbol('navigator.processUrlParams'),
  SETUP_NAVIGATOR: Symbol('navigator.setupNavigator'),
  ON_URL_CHANGE: Symbol('navigator.onUrlChange'),
  COPY_TO_CLIPBOARD: Symbol('navigator.copyToClipboard'),
  SYNTAX_HIGHLIGHT: Symbol('navigator.syntaxHighlight'),
  EXPORT_NETSCAPE: Symbol('navigator.exportNetscape'),
  EXPORT_JSON: Symbol('navigator.exportJSON'),
  EXPORT_TREE: Symbol('navigator.exportTree'),
  GENERATE_NETSCAPE: Symbol('navigator.generateNetscape'),
  HANDLE_EXPORT_NETSCAPE: Symbol('navigator.handleExportNetscape'),
  HANDLE_EXPORT_JSON: Symbol('navigator.handleExportJSON'),
  HANDLE_EXPORT_TREE: Symbol('navigator.handleExportTree'),
  SHOW_RESULT: Symbol('navigator.showResult'),
  SHOW_ERROR: Symbol('navigator.showError'),
  SHOW_INFO: Symbol('navigator.showInfo'),
  CLEAR_RESULT: Symbol('navigator.clearResult'),
  UPDATE_STATUS: Symbol('navigator.updateStatus'),
};

// ============================================================
// 2. ПУБЛИЧНЫЕ СИМВОЛЫ (доступны через Symbol.for)
// ============================================================

const PUBLIC = {
  INSTANCE: Symbol.for('navigator.instance'),
  STATE: Symbol.for('navigator.state'),
  CONFIG: Symbol.for('navigator.config'),
  INIT: Symbol.for('navigator.init'),
  DESTROY: Symbol.for('navigator.destroy'),
  GET_STATE: Symbol.for('navigator.getState'),
  EXECUTE: Symbol.for('navigator.execute'),
  SELECT_METHOD: Symbol.for('navigator.selectMethod'),
  REFRESH_CATALOGS: Symbol.for('navigator.refreshCatalogs'),
};

// ============================================================
// 3. КОНФИГУРАЦИЯ
// ============================================================

const CONFIG = {
  version: '3.2.0',
  build: '2026-07-24',
  name: 'Bookmarks API Navigator',
  debug: true,
  cacheTTL: 30000,
};

// ============================================================
// 4. API МЕТОДЫ
// ============================================================

const API_METHODS = [
  { id: 'getAll', method: 'GET', name: 'getAll', description: 'Всё дерево закладок', params: [] },
  { id: 'getStats', method: 'GET', name: 'getStats', description: 'Статистика закладок', params: [] },
  { id: 'getInfo', method: 'GET', name: 'getInfo', description: 'Информация о расширении', params: [] },
  { id: 'getStatus', method: 'GET', name: 'getStatus', description: 'Статус API', params: [] },
  { id: 'getRootFolders', method: 'GET', name: 'getRootFolders', description: '📁 Корневые папки', params: [] },
  { id: 'getRecent', method: 'GET', name: 'getRecent', description: 'Последние закладки', params: [
      { name: 'count', type: 'number', default: 10, description: 'Количество (1-50)' }
    ] },
  { id: 'search', method: 'POST', name: 'search', description: 'Поиск закладок', params: [
      { name: 'q', type: 'string', required: true, default: '', description: 'Поисковый запрос' }
    ] },
  { id: 'create', method: 'POST', name: 'create', description: '➕ Создать закладку', params: [
      { name: 'title', type: 'string', required: true, default: '', description: 'Название закладки' },
      { name: 'url', type: 'string', required: true, default: '', description: 'URL (https://...)' },
      { name: 'parentId', type: 'string', default: 'auto', description: 'ID папки (auto — верхний уровень)' }
    ] },
  { id: 'remove', method: 'DELETE', name: 'remove', description: 'Удалить закладку', params: [
      { name: 'id', type: 'string', required: true, default: '', description: 'ID закладки' }
    ] },
  { id: 'removeTree', method: 'DELETE', name: 'removeTree', description: 'Удалить папку с содержимым', params: [
      { name: 'id', type: 'string', required: true, default: '', description: 'ID папки' }
    ] },
  { id: 'existsByUrl', method: 'GET', name: 'existsByUrl', description: 'Проверить существование по URL', params: [
      { name: 'url', type: 'string', required: true, default: '', description: 'URL для проверки' }
    ] },
  { id: 'exportNetscape', method: 'EXPORT', name: 'exportNetscape', description: '📄 Экспорт в Netscape HTML', params: [
      { name: 'download', type: 'boolean', default: true, description: 'Скачать файл' }
    ] },
  { id: 'exportJSON', method: 'EXPORT', name: 'exportJSON', description: '📊 Экспорт в JSON', params: [
      { name: 'download', type: 'boolean', default: true, description: 'Скачать файл' }
    ] },
  { id: 'exportTree', method: 'EXPORT', name: 'exportTree', description: '🌳 Дерево для вставки на страницу', params: [
      { name: 'format', type: 'string', default: 'html', description: 'html | json | text' }
    ] },
];

// ============================================================
// 5. ФУНКЦИЯ ЗАПРОСА
// ============================================================

function bmRequest(action, args) {
  if (args === undefined) args = [];
  return new Promise(function(resolve, reject) {
    var id = Date.now() + '_' + Math.random().toString(36).substr(2, 9);
    var handler = function(event) {
      if (event.data && event.data.action === 'response' && event.data.id === id) {
        window.removeEventListener('message', handler);
        if (event.data.success) {
          resolve(event.data.result);
        } else {
          reject(new Error(event.data.error || 'Unknown error'));
        }
      }
    };
    window.addEventListener('message', handler);
    window.postMessage({
      action: 'apiCall',
      id: id,
      method: action,
      args: args
    }, '*');
    setTimeout(function() {
      window.removeEventListener('message', handler);
      reject(new Error('Timeout: ответ не получен'));
    }, 30000);
  });
}

window.bmRequest = bmRequest;

// ============================================================
// 6. ПОЛУЧЕНИЕ КОРНЕВЫХ ПАПОК
// ============================================================

var rootFoldersCache = null;
var rootFoldersCacheTime = 0;
var CACHE_TTL = 30000;

async function getRootFoldersFromTree(forceRefresh) {
  if (forceRefresh === undefined) forceRefresh = false;
  var now = Date.now();
  if (!forceRefresh && rootFoldersCache && (now - rootFoldersCacheTime) < CACHE_TTL) {
    return rootFoldersCache;
  }

  try {
    var tree = await bmRequest('getAll', []);
    var rootNodes = tree && tree[0] && tree[0].children ? tree[0].children : [];
    var folders = rootNodes.filter(function(node) {
      return !node.url;
    }).map(function(node) {
      return {
        id: node.id,
        title: node.title || 'Без названия',
        children: node.children || [],
        childrenCount: node.children ? node.children.length : 0
      };
    });

    rootFoldersCache = folders;
    rootFoldersCacheTime = now;

    console.log('📁 Найдены корневые папки:', folders.map(function(f) {
      return f.title + ' (' + f.id + ')';
    }).join(', '));
    return folders;
  } catch (error) {
    console.warn('⚠️ Ошибка получения корневых папок:', error);
    return [
      { id: '1', title: 'Панель закладок', children: [], childrenCount: 0 },
      { id: '2', title: 'Другие закладки', children: [], childrenCount: 0 }
    ];
  }
}

async function getDefaultParentId() {
  try {
    var folders = await getRootFoldersFromTree();
    if (folders && folders.length > 0) {
      return folders[0].id;
    }
  } catch (error) {}
  return '1';
}

// ============================================================
// 7. ГЕНЕРАЦИЯ NETSCAPE HTML
// ============================================================

function generateNetscapeHTML(tree) {
  var html = '<!DOCTYPE NETSCAPE-Bookmark-file-1>\n';
  html += '<!-- This is an automatically generated file. -->\n';
  html += '<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">\n';
  html += '<TITLE>Bookmarks</TITLE>\n';
  html += '<H1>Bookmarks</H1>\n';
  html += '<DL><p>\n';

  function escapeHTML(str) {
    if (!str) return '';
    return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  function renderNode(node, depth) {
    var indent = '    '.repeat(depth);
    var title = escapeHTML(node.title || 'Без названия');
    var addDate = node.dateAdded ? Math.floor(node.dateAdded / 1000) : '';

    if (node.url) {
      var url = escapeHTML(node.url);
      html += indent + '<DT><A HREF="' + url + '" ADD_DATE="' + addDate + '">' + title + '</A>\n';
    } else {
      html += indent + '<DT><H3 ADD_DATE="' + addDate + '">' + title + '</H3>\n';
      html += indent + '<DL><p>\n';
      if (node.children) {
        for (var i = 0; i < node.children.length; i++) {
          renderNode(node.children[i], depth + 1);
        }
      }
      html += indent + '</DL><p>\n';
    }
  }

  var rootNodes = tree && tree[0] && tree[0].children ? tree[0].children : (Array.isArray(tree) ? tree : [tree]);

  for (var i = 0; i < rootNodes.length; i++) {
    renderNode(rootNodes[i], 1);
  }

  html += '</DL><p>\n';
  return html;
}

// ============================================================
// 8. ЭКСПОРТНЫЕ ФУНКЦИИ
// ============================================================

async function exportNetscape(download) {
  if (download === undefined) download = true;
  try {
    var tree = await bmRequest('getAll', []);
    var html = generateNetscapeHTML(tree);
    if (download) {
      var blob = new Blob([html], { type: 'text/html; charset=UTF-8' });
      var url = URL.createObjectURL(blob);
      var a = document.createElement('a');
      a.href = url;
      a.download = 'bookmarks_' + new Date().toISOString().slice(0,10) + '.html';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      return { success: true, message: 'Скачан файл bookmarks.html', data: html };
    }
    return { success: true, data: html };
  } catch (error) {
    throw new Error('Ошибка экспорта Netscape: ' + error.message);
  }
}

async function exportJSON(download) {
  if (download === undefined) download = true;
  try {
    var tree = await bmRequest('getAll', []);
    var json = JSON.stringify(tree, null, 2);
    if (download) {
      var blob = new Blob([json], { type: 'application/json; charset=UTF-8' });
      var url = URL.createObjectURL(blob);
      var a = document.createElement('a');
      a.href = url;
      a.download = 'bookmarks_' + new Date().toISOString().slice(0,10) + '.json';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      return { success: true, message: 'Скачан файл bookmarks.json', data: json };
    }
    return { success: true, data: json };
  } catch (error) {
    throw new Error('Ошибка экспорта JSON: ' + error.message);
  }
}

async function exportTree(format) {
  if (format === undefined) format = 'html';
  try {
    var tree = await bmRequest('getAll', []);
    if (format === 'html') {
      var html = generateNetscapeHTML(tree);
      return { success: true, data: html, format: 'html' };
    } else if (format === 'json') {
      return { success: true, data: JSON.stringify(tree, null, 2), format: 'json' };
    } else {
      var text = '📚 Дерево закладок\n';
      text += '═'.repeat(50) + '\n\n';
      function renderText(node, depth) {
        var indent = '  '.repeat(depth);
        if (node.url) {
          text += indent + '🔖 ' + (node.title || 'Без названия') + '\n';
          text += indent + '   📎 ' + node.url + '\n\n';
        } else {
          text += indent + '📁 ' + (node.title || 'Без названия') + '\n';
          if (node.children) {
            for (var i = 0; i < node.children.length; i++) {
              renderText(node.children[i], depth + 1);
            }
          }
        }
      }
      var rootNodes = tree[0] && tree[0].children ? tree[0].children : tree;
      for (var i = 0; i < rootNodes.length; i++) {
        renderText(rootNodes[i], 0);
      }
      return { success: true, data: text, format: 'text' };
    }
  } catch (error) {
    throw new Error('Ошибка экспорта дерева: ' + error.message);
  }
}

// ============================================================
// 9. DOM ЭЛЕМЕНТЫ
// ============================================================

var REFS = {
  methodsList: document.getElementById('methodsList'),
  methodSearch: document.getElementById('methodSearch'),
  methodCount: document.getElementById('methodCount'),
  statusDot: document.getElementById('statusDot'),
  statusText: document.getElementById('statusText'),
  methodTag: document.getElementById('methodTag'),
  requestUrl: document.getElementById('requestUrl'),
  paramCount: document.getElementById('paramCount'),
  responseContent: document.getElementById('responseContent'),
  urlPreview: document.getElementById('urlPreview'),
  paramsContainer: document.getElementById('paramsContainer'),
  paramsCount: document.getElementById('paramsCount'),
  catalogContainer: document.getElementById('catalogContainer'),
  catalogList: document.getElementById('catalogList'),
  clearBtn: document.getElementById('clearBtn'),
  executeBtn: document.getElementById('executeBtn'),
  exportBtn: document.getElementById('exportBtn'),
  copyFullUrlBtn: document.getElementById('copyFullUrlBtn'),
  catalogRefreshBtn: document.getElementById('catalogRefreshBtn'),
  navDot: document.getElementById('navDot'),
  navStatusText: document.getElementById('navStatusText'),
  navParamsInfo: document.getElementById('navParamsInfo'),
};

// ============================================================
// 10. СОСТОЯНИЕ
// ============================================================

var STATE = {
  currentMethod: null,
  currentUrl: '',
  selectedId: null,
  paramValues: {},
  lastResult: null,
  rootFolders: [],
  isExecuting: false,
  initialized: false,
};

// ============================================================
// 11. ФУНКЦИИ РЕНДЕРИНГА
// ============================================================

function renderMethods(filter) {
  if (filter === undefined) filter = '';
  var filtered = API_METHODS.filter(function(m) {
    return m.name.toLowerCase().includes(filter.toLowerCase()) ||
      m.description.toLowerCase().includes(filter.toLowerCase());
  });

  REFS.methodCount.textContent = filtered.length;

  if (filtered.length === 0) {
    REFS.methodsList.innerHTML = '\n      <div style="text-align:center;padding:30px 20px;color:#4a5a7a;font-size:13px;">\n        🔍 Ничего не найдено\n      </div>\n    ';
    return;
  }

  var html = '';
  for (var i = 0; i < filtered.length; i++) {
    var method = filtered[i];
    var active = method.id === STATE.selectedId ? 'active' : '';
    var badgeClass = method.method.toLowerCase();
    html += '\n      <div class="method-item ' + active + '" data-id="' + method.id + '" onclick="window.selectMethod(\'' + method.id + '\')">\n        <span class="method-badge ' + badgeClass + '">' + method.method + '</span>\n        <span class="method-name">' + method.name + '</span>\n        <span class="method-desc">' + method.description + '</span>\n      </div>\n    ';
  }
  REFS.methodsList.innerHTML = html;
}

async function renderCatalogs() {
  try {
    STATE.rootFolders = await getRootFoldersFromTree();
    REFS.catalogContainer.style.display = 'block';

    if (!STATE.rootFolders || STATE.rootFolders.length === 0) {
      REFS.catalogList.innerHTML = '<div class="catalog-empty">📭 Нет доступных каталогов</div>';
      return;
    }

    var html = '';
    for (var i = 0; i < STATE.rootFolders.length; i++) {
      var folder = STATE.rootFolders[i];
      var icon = folder.title && folder.title.toLowerCase().includes('панель') ? '📁' :
        folder.title && folder.title.toLowerCase().includes('другие') ? '📂' : '📁';
      html += '\n        <div class="catalog-item">\n          <span class="cicon">' + icon + '</span>\n          <span class="cname">' + folder.title + '</span>\n          <span class="cid">ID: ' + folder.id + '</span>\n          <span class="cuse" onclick="window.useFolderId(\'' + folder.id + '\')">📌 Использовать</span>\n        </div>\n      ';
    }
    REFS.catalogList.innerHTML = html;
  } catch (error) {
    REFS.catalogContainer.style.display = 'block';
    REFS.catalogList.innerHTML = '<div class="catalog-empty">❌ Ошибка загрузки: ' + error.message + '</div>';
  }
}

async function renderParams(method) {
  if (!method || !method.params || method.params.length === 0) {
    REFS.paramsContainer.innerHTML = '<div class="no-params">📭 Нет параметров для этого метода</div>';
    REFS.paramsCount.textContent = '0';
    REFS.catalogContainer.style.display = 'none';
    return;
  }

  if (method.id === 'create') {
    REFS.catalogContainer.style.display = 'block';
    await renderCatalogs();
  } else {
    REFS.catalogContainer.style.display = 'none';
  }

  var html = '';
  for (var i = 0; i < method.params.length; i++) {
    var param = method.params[i];
    var required = param.required ? '<span class="required">*</span>' : '';
    var defaultVal = param.default !== undefined ? param.default : '';
    var currentVal = STATE.paramValues[param.name] !== undefined ? STATE.paramValues[param.name] : defaultVal;

    var inputHtml = '';

    if (method.id === 'create' && param.name === 'parentId') {
      var optionsHtml = '<option value="auto" ' + (currentVal === 'auto' || currentVal === '' ? 'selected' : '') + '>📌 Верхний уровень (auto)</option>';
      if (STATE.rootFolders && STATE.rootFolders.length > 0) {
        for (var j = 0; j < STATE.rootFolders.length; j++) {
          var folder = STATE.rootFolders[j];
          var selected = currentVal === folder.id ? 'selected' : '';
          var icon = folder.title && folder.title.toLowerCase().includes('панель') ? '📁' :
            folder.title && folder.title.toLowerCase().includes('другие') ? '📂' : '📁';
          optionsHtml += '<option value="' + folder.id + '" ' + selected + '>' + icon + ' ' + folder.title + ' (' + folder.id + ')</option>';
        }
      }
      inputHtml = '\n        <select id="param_parentId" data-param="parentId" onchange="window.onParamChange(\'parentId\', this.value)">\n          ' + optionsHtml + '\n        </select>\n      ';
    } else if (param.type === 'boolean') {
      inputHtml = '\n        <select id="param_' + param.name + '" data-param="' + param.name + '" onchange="window.onParamChange(\'' + param.name + '\', this.value)">\n          <option value="true" ' + (currentVal === true || currentVal === 'true' ? 'selected' : '') + '>true</option>\n          <option value="false" ' + (currentVal === false || currentVal === 'false' ? 'selected' : '') + '>false</option>\n        </select>\n      ';
    } else {
      inputHtml = '\n        <input\n          type="' + (param.type === 'number' ? 'number' : 'text') + '"\n          id="param_' + param.name + '"\n          value="' + currentVal + '"\n          placeholder="' + (param.default || '') + '"\n          data-param="' + param.name + '"\n          oninput="window.onParamChange(\'' + param.name + '\', this.value)"\n        />\n      ';
    }

    html += '\n      <div class="param-group" data-param="' + param.name + '">\n        <span class="param-label">\n          ' + param.name + ' ' + required + '\n        </span>\n        <span class="param-type">' + (param.type || 'string') + '</span>\n        ' + inputHtml + '\n        <span class="param-default">' + (param.default !== undefined && param.default !== 'auto' ? '= ' + param.default : '') + '</span>\n        <span class="param-desc" title="' + (param.description || '') + '">' + (param.description || '') + '</span>\n      </div>\n    ';
  }

  REFS.paramsContainer.innerHTML = html;
  REFS.paramsCount.textContent = method.params.length;
  updateUrlFromParams(method);
}

// ============================================================
// 12. ОБРАБОТКА ПАРАМЕТРОВ
// ============================================================

function onParamChange(name, value) {
  STATE.paramValues[name] = value;
  if (STATE.currentMethod) {
    updateUrlFromParams(STATE.currentMethod);
  }
}

window.onParamChange = onParamChange;

function updateUrlFromParams(method) {
  if (!method) return;
  var url = '?bm=' + method.name;
  for (var i = 0; i < method.params.length; i++) {
    var param = method.params[i];
    var val = STATE.paramValues[param.name] !== undefined ? STATE.paramValues[param.name] : (param.default || '');
    if (param.name === 'parentId' && (val === 'auto' || val === '')) continue;
    if (val !== '' || param.required) {
      url += '&' + param.name + '=' + encodeURIComponent(val);
    }
  }
  STATE.currentUrl = url;
  REFS.requestUrl.textContent = url;
  REFS.paramCount.textContent = method.params.length ? method.params.length + ' параметра' : '—';
  updateUrlPreview();
}

function updateUrlPreview() {
  var fullUrl = window.location.origin + window.location.pathname + (STATE.currentUrl || '');
  REFS.urlPreview.textContent = 'URL: ' + fullUrl;
}

// ============================================================
// 13. ВЫБОР МЕТОДА
// ============================================================

function selectMethod(id) {
  var method = null;
  for (var i = 0; i < API_METHODS.length; i++) {
    if (API_METHODS[i].id === id) {
      method = API_METHODS[i];
      break;
    }
  }
  if (!method) return;

  STATE.selectedId = id;
  STATE.currentMethod = method;

  STATE.paramValues = {};
  for (var j = 0; j < method.params.length; j++) {
    var p = method.params[j];
    STATE.paramValues[p.name] = p.default !== undefined ? p.default : '';
  }

  renderMethods(REFS.methodSearch.value);

  // Используем then для обработки асинхронности
  renderParams(method).then(function() {
    REFS.methodTag.textContent = method.method;
    REFS.methodTag.className = 'method-tag ' + method.method.toLowerCase();

    updateUrlFromParams(method);

    REFS.responseContent.innerHTML = '<span class="info">ℹ️ ' + method.method + ' ' + method.name + ' — ' + method.description + '</span>';
    REFS.statusDot.className = 'status-dot idle';
    REFS.statusText.textContent = 'Готов к выполнению';
    REFS.statusText.className = 'status-text idle';

    REFS.navParamsInfo.textContent = method.name + '(' + method.params.length + ')';
    REFS.navDot.className = 'dot active';
    REFS.navStatusText.textContent = 'Выбран: ' + method.name;

    STATE.lastResult = null;
  });
}

window.selectMethod = selectMethod;

// ============================================================
// 14. ВЫПОЛНЕНИЕ ЗАПРОСА
// ============================================================

async function executeCurrentRequest() {
  if (!STATE.currentMethod) {
    REFS.responseContent.innerHTML = '<span class="error">❌ Выберите метод</span>';
    return;
  }

  if (STATE.currentMethod.id === 'exportNetscape') {
    await handleExportNetscape();
    return;
  }
  if (STATE.currentMethod.id === 'exportJSON') {
    await handleExportJSON();
    return;
  }
  if (STATE.currentMethod.id === 'exportTree') {
    await handleExportTree();
    return;
  }

  if (STATE.isExecuting) return;
  STATE.isExecuting = true;

  REFS.statusDot.className = 'status-dot loading';
  REFS.statusText.textContent = 'Выполняется...';
  REFS.statusText.className = 'status-text loading';
  REFS.responseContent.innerHTML = '<span class="warn">⏳ Выполнение ' + STATE.currentMethod.method + ' ' + STATE.currentMethod.name + '...</span>';

  try {
    var args = [];
    for (var i = 0; i < STATE.currentMethod.params.length; i++) {
      var param = STATE.currentMethod.params[i];
      var value = STATE.paramValues[param.name];
      if (param.name === 'parentId' && (value === 'auto' || value === '')) {
        value = await getDefaultParentId();
        console.log('🔍 Автоматически определён parentId: ' + value);
      }
      if (value === undefined || value === '') {
        value = param.default || '';
      }
      if (param.type === 'number') {
        value = parseFloat(value) || 0;
      }
      args.push(value);
    }

    var result = await bmRequest(STATE.currentMethod.name, args);
    STATE.lastResult = result;

    REFS.statusDot.className = 'status-dot success';
    REFS.statusText.textContent = '✅ Успешно';
    REFS.statusText.className = 'status-text success';
    REFS.responseContent.innerHTML = syntaxHighlight(JSON.stringify(result, null, 2));

  } catch (error) {
    REFS.statusDot.className = 'status-dot error';
    REFS.statusText.textContent = '❌ Ошибка';
    REFS.statusText.className = 'status-text error';
    REFS.responseContent.innerHTML = '<span class="error">❌ Ошибка: ' + error.message + '</span>';
  }

  STATE.isExecuting = false;
}

// ============================================================
// 15. ЭКСПОРТНЫЕ ОБРАБОТЧИКИ
// ============================================================

async function handleExportNetscape() {
  var download = STATE.paramValues.download !== 'false';
  REFS.statusDot.className = 'status-dot loading';
  REFS.statusText.textContent = 'Экспорт...';
  REFS.statusText.className = 'status-text loading';
  REFS.responseContent.innerHTML = '<span class="warn">⏳ Генерация Netscape HTML...</span>';

  try {
    var result = await exportNetscape(download);
    REFS.statusDot.className = 'status-dot success';
    REFS.statusText.textContent = '✅ Экспортирован';
    REFS.statusText.className = 'status-text success';
    if (download) {
      REFS.responseContent.innerHTML = '<span class="success">✅ ' + result.message + '</span>';
    } else {
      REFS.responseContent.innerHTML = syntaxHighlight(JSON.stringify(result.data, null, 2));
    }
  } catch (error) {
    REFS.statusDot.className = 'status-dot error';
    REFS.statusText.textContent = '❌ Ошибка';
    REFS.statusText.className = 'status-text error';
    REFS.responseContent.innerHTML = '<span class="error">❌ ' + error.message + '</span>';
  }
}

async function handleExportJSON() {
  var download = STATE.paramValues.download !== 'false';
  REFS.statusDot.className = 'status-dot loading';
  REFS.statusText.textContent = 'Экспорт...';
  REFS.statusText.className = 'status-text loading';
  REFS.responseContent.innerHTML = '<span class="warn">⏳ Генерация JSON...</span>';

  try {
    var result = await exportJSON(download);
    REFS.statusDot.className = 'status-dot success';
    REFS.statusText.textContent = '✅ Экспортирован';
    REFS.statusText.className = 'status-text success';
    if (download) {
      REFS.responseContent.innerHTML = '<span class="success">✅ ' + result.message + '</span>';
    } else {
      REFS.responseContent.innerHTML = syntaxHighlight(JSON.stringify(result.data, null, 2));
    }
  } catch (error) {
    REFS.statusDot.className = 'status-dot error';
    REFS.statusText.textContent = '❌ Ошибка';
    REFS.statusText.className = 'status-text error';
    REFS.responseContent.innerHTML = '<span class="error">❌ ' + error.message + '</span>';
  }
}

async function handleExportTree() {
  var format = STATE.paramValues.format || 'html';
  REFS.statusDot.className = 'status-dot loading';
  REFS.statusText.textContent = 'Генерация...';
  REFS.statusText.className = 'status-text loading';
  REFS.responseContent.innerHTML = '<span class="warn">⏳ Генерация дерева (' + format + ')...</span>';

  try {
    var result = await exportTree(format);
    STATE.lastResult = result;
    REFS.statusDot.className = 'status-dot success';
    REFS.statusText.textContent = '✅ Готово';
    REFS.statusText.className = 'status-text success';
    if (format === 'html') {
      REFS.responseContent.innerHTML = result.data;
    } else if (format === 'json') {
      REFS.responseContent.innerHTML = syntaxHighlight(result.data);
    } else {
      REFS.responseContent.innerHTML = result.data.replace(/\n/g, '<br>');
    }
  } catch (error) {
    REFS.statusDot.className = 'status-dot error';
    REFS.statusText.textContent = '❌ Ошибка';
    REFS.statusText.className = 'status-text error';
    REFS.responseContent.innerHTML = '<span class="error">❌ ' + error.message + '</span>';
  }
}

// ============================================================
// 16. ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ
// ============================================================

function syntaxHighlight(json) {
  json = json.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  return json.replace(
    /(\\\"(?:[^\\\"\\\\]|\\\\.)*\\\"):?|(\\b\\d+\\.?\\d*\\b)|(true|false|null)|(\\\"[^\\\"]*\\\")/g,
    function(match, key, number, bool, string) {
      if (key) return '<span class="json-key">' + key + '</span>';
      if (number) return '<span class="json-number">' + number + '</span>';
      if (bool) return '<span class="json-boolean">' + bool + '</span>';
      if (string) return '<span class="json-string">' + string + '</span>';
      return match;
    }
  );
}

function copyToClipboard(text) {
  if (navigator.clipboard) {
    navigator.clipboard.writeText(text).then(function() {
      var original = REFS.copyFullUrlBtn.textContent;
      REFS.copyFullUrlBtn.textContent = '✅ Скопировано!';
      setTimeout(function() { REFS.copyFullUrlBtn.textContent = original; }, 2000);
    }).catch(function() { fallbackCopy(text); });
  } else {
    fallbackCopy(text);
  }
}

function fallbackCopy(text) {
  var textarea = document.createElement('textarea');
  textarea.value = text;
  document.body.appendChild(textarea);
  textarea.select();
  document.execCommand('copy');
  document.body.removeChild(textarea);
  var original = REFS.copyFullUrlBtn.textContent;
  REFS.copyFullUrlBtn.textContent = '✅ Скопировано!';
  setTimeout(function() { REFS.copyFullUrlBtn.textContent = original; }, 2000);
}

// ============================================================
// 17. ОБРАБОТКА URL ПАРАМЕТРОВ
// ============================================================

async function processUrlParams() {
  var params = new URLSearchParams(window.location.search);
  var bmParam = params.get('bm');

  if (bmParam) {
    var method = null;
    for (var i = 0; i < API_METHODS.length; i++) {
      if (API_METHODS[i].name === bmParam) {
        method = API_METHODS[i];
        break;
      }
    }
    if (method) {
      for (var j = 0; j < method.params.length; j++) {
        var p = method.params[j];
        var val = params.get(p.name);
        if (val !== null) {
          STATE.paramValues[p.name] = val;
        } else if (p.default !== undefined) {
          STATE.paramValues[p.name] = p.default;
        }
      }
      STATE.selectedId = method.id;
      STATE.currentMethod = method;
      renderMethods(REFS.methodSearch.value);
      await renderParams(method);
      REFS.methodTag.textContent = method.method;
      REFS.methodTag.className = 'method-tag ' + method.method.toLowerCase();
      updateUrlFromParams(method);
      REFS.navDot.className = 'dot active';
      REFS.navStatusText.textContent = '🎯 ' + method.name;
      REFS.navParamsInfo.textContent = 'параметры: ' + method.params.map(function(p) { return p.name; }).join(', ');
      setTimeout(function() { executeCurrentRequest(); }, 300);
      return true;
    } else {
      REFS.navDot.className = 'dot error';
      REFS.navStatusText.textContent = '❌ Неизвестный метод: ' + bmParam;
      REFS.navParamsInfo.textContent = '—';
    }
  } else {
    REFS.navDot.className = 'dot inactive';
    REFS.navStatusText.textContent = '⏳ Ожидание команды...';
    REFS.navParamsInfo.textContent = '—';
  }
  return false;
}

// ============================================================
// 18. НАВИГАТОР
// ============================================================

function setupNavigatorListener() {
  var originalPushState = history.pushState;
  var originalReplaceState = history.replaceState;

  history.pushState = function() {
    var args = Array.prototype.slice.call(arguments);
    originalPushState.apply(this, args);
    onUrlChange();
  };

  history.replaceState = function() {
    var args = Array.prototype.slice.call(arguments);
    originalReplaceState.apply(this, args);
    onUrlChange();
  };

  window.addEventListener('popstate', onUrlChange);
  window.addEventListener('hashchange', onUrlChange);
  onUrlChange();
  console.log('✅ Navigator listener установлен');
}

function onUrlChange() {
  updateUrlPreview();
  processUrlParams();
  renderMethods(REFS.methodSearch.value);
}

// ============================================================
// 19. ОБРАБОТЧИКИ СОБЫТИЙ
// ============================================================

function refreshCatalogs() {
  rootFoldersCache = null;
  rootFoldersCacheTime = 0;
  renderCatalogs().then(function() {
    REFS.responseContent.innerHTML = '<span class="success">✅ Список каталогов обновлён</span>';
  });
}

window.refreshCatalogs = refreshCatalogs;

function useFolderId(id) {
  STATE.paramValues['parentId'] = id;
  if (STATE.currentMethod) {
    updateUrlFromParams(STATE.currentMethod);
    var select = document.querySelector('#param_parentId');
    if (select) {
      select.value = id;
    }
    REFS.responseContent.innerHTML = '<span class="success">✅ Выбран каталог ID: ' + id + '</span>';
  }
}

window.useFolderId = useFolderId;

// ============================================================
// 20. ЗАПУСК
// ============================================================

async function init() {
  renderMethods();

  try {
    STATE.rootFolders = await getRootFoldersFromTree();
    console.log('📁 Загружено ' + STATE.rootFolders.length + ' корневых папок:',
      STATE.rootFolders.map(function(f) { return f.title + ' (' + f.id + ')'; }).join(', '));
  } catch (error) {
    console.warn('⚠️ Не удалось загрузить корневые папки:', error);
  }

  if (API_METHODS.length > 0) {
    var firstMethod = null;
    for (var i = 0; i < API_METHODS.length; i++) {
      if (API_METHODS[i].method !== 'EXPORT') {
        firstMethod = API_METHODS[i];
        break;
      }
    }
    if (!firstMethod) firstMethod = API_METHODS[0];
    await selectMethod(firstMethod.id);
  }

  setupNavigatorListener();
  updateUrlPreview();
  await processUrlParams();

  console.log('╔═══════════════════════════════════════════════════════════════════════════════╗');
  console.log('║              📚 BOOKMARKS API NAVIGATOR v3.2.0                              ║');
  console.log('╠═══════════════════════════════════════════════════════════════════════════════╣');
  console.log('║  🔧 Исправлено: правильное получение корневых папок через getAll            ║');
  console.log('║  📁 Отображаются реальные папки: Панель закладок, Другие закладки           ║');
  console.log('║  📌 Нажмите "📌 Использовать" на нужной папке                               ║');
  console.log('║  📌 Пример: ?bm=create&title=Test&url=https://example.com                    ║');
  console.log('║  ⚡ Ctrl+Enter - выполнить запрос                                           ║');
  console.log('╚═══════════════════════════════════════════════════════════════════════════════╝');
}

// ============================================================
// 21. ЭКСПОРТЫ
// ============================================================

export {
  PRIVATE,
  PUBLIC,
  CONFIG,
  API_METHODS,
  bmRequest,
  getRootFoldersFromTree,
  getDefaultParentId,
  generateNetscapeHTML,
  exportNetscape,
  exportJSON,
  exportTree,
  renderMethods,
  renderCatalogs,
  renderParams,
  updateUrlFromParams,
  updateUrlPreview,
  selectMethod,
  executeCurrentRequest,
  processUrlParams,
  setupNavigatorListener,
  onUrlChange,
  syntaxHighlight,
  copyToClipboard,
  init,
  REFS,
  STATE,
};

export default {
  PRIVATE: PRIVATE,
  PUBLIC: PUBLIC,
  CONFIG: CONFIG,
  API_METHODS: API_METHODS,
  bmRequest: bmRequest,
  getRootFoldersFromTree: getRootFoldersFromTree,
  getDefaultParentId: getDefaultParentId,
  generateNetscapeHTML: generateNetscapeHTML,
  exportNetscape: exportNetscape,
  exportJSON: exportJSON,
  exportTree: exportTree,
  renderMethods: renderMethods,
  renderCatalogs: renderCatalogs,
  renderParams: renderParams,
  updateUrlFromParams: updateUrlFromParams,
  updateUrlPreview: updateUrlPreview,
  selectMethod: selectMethod,
  executeCurrentRequest: executeCurrentRequest,
  processUrlParams: processUrlParams,
  setupNavigatorListener: setupNavigatorListener,
  onUrlChange: onUrlChange,
  syntaxHighlight: syntaxHighlight,
  copyToClipboard: copyToClipboard,
  init: init,
  REFS: REFS,
  STATE: STATE,
};