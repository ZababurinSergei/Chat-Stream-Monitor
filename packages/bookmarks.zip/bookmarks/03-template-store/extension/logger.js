// ============================================================
// logger.js - 100% СИМВОЛЫ
// Версия: 1.0.0
// Универсальный логгер для всех модулей
// ============================================================

// ============================================================
// 1. ПРИВАТНЫЕ СИМВОЛЫ
// ============================================================

const LOGGER_PRIVATE = {
  HISTORY: Symbol('logger.history'),
  MAX_HISTORY: Symbol('logger.maxHistory'),
  DEBUG: Symbol('logger.debug'),
  INSTANCE_ID: Symbol('logger.instanceId'),
  LEVEL: Symbol('logger.level'),
  COLORS: Symbol('logger.colors'),
};

// ============================================================
// 2. ПУБЛИЧНЫЕ СИМВОЛЫ
// ============================================================

export const LOGGER_PUBLIC = {
  INSTANCE: Symbol.for('logger.instance'),
  HISTORY: Symbol.for('logger.history'),
  DEBUG: Symbol.for('logger.debug'),
};

// ============================================================
// 3. КОНФИГУРАЦИЯ
// ============================================================

export const LOGGER_CONFIG = {
  version: '1.0.0',
  build: '2026-07-24',
  name: 'Universal Logger',
  maxHistory: 500,
};

// ============================================================
// 4. СОЗДАНИЕ ЛОГГЕРА
// ============================================================

export function createLogger(debug = true, instanceId = 'App') {
  const logState = {
    [LOGGER_PRIVATE.HISTORY]: [],
    [LOGGER_PRIVATE.MAX_HISTORY]: LOGGER_CONFIG.maxHistory,
    [LOGGER_PRIVATE.DEBUG]: debug,
    [LOGGER_PRIVATE.INSTANCE_ID]: instanceId,
    [LOGGER_PRIVATE.LEVEL]: debug ? 3 : 2,
    [LOGGER_PRIVATE.COLORS]: {
      reset: '\x1b[0m',
      bold: '\x1b[1m',
      red: '\x1b[31m',
      green: '\x1b[32m',
      yellow: '\x1b[33m',
      blue: '\x1b[34m',
      magenta: '\x1b[35m',
      cyan: '\x1b[36m',
      gray: '\x1b[90m',
    },
  };

  const logMethod = function(level, message, data) {
    const levels = { error: 0, warn: 1, info: 2, debug: 3, success: 2 };
    const currentLevel = this[LOGGER_PRIVATE.LEVEL] || 2;
    const msgLevel = levels[level] || 2;

    if (msgLevel > currentLevel) return;

    const timestamp = new Date().toISOString().slice(11, 23);
    const prefix = `[${timestamp}] [${this[LOGGER_PRIVATE.INSTANCE_ID]}]`;

    this[LOGGER_PRIVATE.HISTORY].push({
      timestamp,
      level,
      message,
      data: data || null,
      id: Date.now() + Math.random(),
    });

    if (this[LOGGER_PRIVATE.HISTORY].length > this[LOGGER_PRIVATE.MAX_HISTORY]) {
      this[LOGGER_PRIVATE.HISTORY].shift();
    }

    const colors = this[LOGGER_PRIVATE.COLORS];
    const icons = { error: '❌', warn: '⚠️', info: 'ℹ️', debug: '🔍', success: '✅' };
    const icon = icons[level] || '📌';
    const colorMap = {
      error: colors.red,
      warn: colors.yellow,
      info: colors.blue,
      debug: colors.gray,
      success: colors.green,
    };
    const color = colorMap[level] || colors.white;

    if (data !== null && data !== undefined) {
      console.log(`${color}${icon} ${prefix} ${message}${colors.reset}`, data);
    } else {
      console.log(`${color}${icon} ${prefix} ${message}${colors.reset}`);
    }
  };

  const boundLog = logMethod.bind(logState);

  const methods = {
    error: (msg, d) => boundLog('error', msg, d),
    warn: (msg, d) => boundLog('warn', msg, d),
    info: (msg, d) => boundLog('info', msg, d),
    debug: (msg, d) => boundLog('debug', msg, d),
    success: (msg, d) => boundLog('success', msg, d),

    // ★★★ ЗАГОЛОВОК ★★★
    header: (title, color = '#636e72') => {
      const colors = logState[LOGGER_PRIVATE.COLORS];
      const separator = '═'.repeat(70);
      console.log(`${colors.cyan}${separator}${colors.reset}`);
      console.log(
        `${colors.bold}${colors.magenta}  📦 ${title}${colors.reset}`
      );
      console.log(`${colors.cyan}${separator}${colors.reset}`);
    },

    // ★★★ РАЗДЕЛИТЕЛЬ ★★★
    separator: (color = '#636e72') => {
      const colors = logState[LOGGER_PRIVATE.COLORS];
      console.log(`${colors.gray}${'─'.repeat(70)}${colors.reset}`);
    },

    // ★★★ СЕКЦИЯ ★★★
    section: (title, color = '#636e72') => {
      const colors = logState[LOGGER_PRIVATE.COLORS];
      console.log(`${colors.gray}─── ${title} ───${colors.reset}`);
    },

    // ★★★ ПОДЗАГОЛОВОК ★★★
    subheader: (title, color = '#636e72') => {
      const colors = logState[LOGGER_PRIVATE.COLORS];
      console.log(`${colors.bold}${colors.blue}▶ ${title}${colors.reset}`);
    },

    getHistory: function() {
      return [...this[LOGGER_PRIVATE.HISTORY]];
    },

    clearHistory: function() {
      this[LOGGER_PRIVATE.HISTORY] = [];
      return this;
    },

    setDebug: function(enabled) {
      this[LOGGER_PRIVATE.DEBUG] = enabled;
      this[LOGGER_PRIVATE.LEVEL] = enabled ? 3 : 2;
      return this;
    },

    getState: function() {
      return {
        instanceId: this[LOGGER_PRIVATE.INSTANCE_ID],
        debug: this[LOGGER_PRIVATE.DEBUG],
        level: this[LOGGER_PRIVATE.LEVEL],
        historySize: this[LOGGER_PRIVATE.HISTORY].length,
        maxHistory: this[LOGGER_PRIVATE.MAX_HISTORY],
      };
    },
  };

  const logger = {};
  for (const [key, fn] of Object.entries(methods)) {
    logger[key] = fn.bind(logState);
  }

  // Добавляем приватные свойства для доступа
  logger[LOGGER_PRIVATE.HISTORY] = logState[LOGGER_PRIVATE.HISTORY];
  logger[LOGGER_PRIVATE.MAX_HISTORY] = logState[LOGGER_PRIVATE.MAX_HISTORY];
  logger[LOGGER_PRIVATE.DEBUG] = logState[LOGGER_PRIVATE.DEBUG];
  logger[LOGGER_PRIVATE.INSTANCE_ID] = logState[LOGGER_PRIVATE.INSTANCE_ID];
  logger[LOGGER_PRIVATE.LEVEL] = logState[LOGGER_PRIVATE.LEVEL];
  logger[LOGGER_PRIVATE.COLORS] = logState[LOGGER_PRIVATE.COLORS];

  return logger;
}

// ============================================================
// 5. ПРЕДУСТАНОВЛЕННЫЕ ЛОГГЕРЫ
// ============================================================

export const defaultLogger = createLogger(true, 'Default');

// ============================================================
// 6. СИНГЛТОН ДЛЯ ГЛОБАЛЬНОГО ИСПОЛЬЗОВАНИЯ
// ============================================================

let globalLogger = null;

export function getGlobalLogger(instanceId = 'App') {
  if (!globalLogger) {
    globalLogger = createLogger(true, instanceId);
  }
  return globalLogger;
}

export function setGlobalLogger(logger) {
  globalLogger = logger;
}

// ============================================================
// 7. ЭКСПОРТ ПО УМОЛЧАНИЮ
// ============================================================

export default createLogger;

// ============================================================
// 8. ГЛОБАЛЬНАЯ РЕГИСТРАЦИЯ (для браузера)
// ============================================================

if (typeof window !== 'undefined') {
  window.__logger = {
    create: createLogger,
    default: defaultLogger,
    getGlobal: getGlobalLogger,
    setGlobal: setGlobalLogger,
    symbols: {
      PRIVATE: { ...LOGGER_PRIVATE },
      PUBLIC: { ...LOGGER_PUBLIC },
    },
    config: { ...LOGGER_CONFIG },
  };

  console.log('✅ Logger: Глобальная регистрация выполнена');
  console.log('📋 ДОСТУПНЫЕ КОМАНДЫ:');
  console.log('  window.__logger.create(debug, instanceId) - создать логгер');
  console.log('  window.__logger.default - логгер по умолчанию');
  console.log('  window.__logger.getGlobal(id) - получить глобальный логгер');
  console.log('  window.__logger.setGlobal(logger) - установить глобальный логгер');
}