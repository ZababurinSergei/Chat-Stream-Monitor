# 📚 Bookmarks Manager Pro

> Полноценный менеджер закладок Chrome с публичным API для веб-страниц

[![Version](https://img.shields.io/badge/version-1.0.0-blue.svg)](https://github.com)
[![Manifest V3](https://img.shields.io/badge/manifest-v3-green.svg)](https://developer.chrome.com/docs/extensions/mv3/)
[![ES Modules](https://img.shields.io/badge/modules-ES6-yellow.svg)](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Modules)
[![Symbols](https://img.shields.io/badge/100%25-symbols-purple.svg)](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Symbol)

## 📋 Оглавление

- [📚 Bookmarks Manager Pro](#-bookmarks-manager-pro)
  - [📋 Оглавление](#-оглавление)
  - [🚀 Быстрый старт](#-быстрый-старт)
  - [📦 Установка](#-установка)
  - [📁 Структура проекта](#-структура-проекта)
  - [🏗️ Архитектура (100% Symbols)](#️-архитектура-100-symbols)
    - [Символы в проекте](#символы-в-проекте)
  - [📖 API Методы](#-api-методы)
    - [Чтение закладок](#чтение-закладок)
    - [Модификация закладок](#модификация-закладок)
    - [Экспорт/Импорт](#экспортимпорт)
    - [Утилиты](#утилиты)
  - [🎯 Использование API на страницах](#-использование-api-на-страницах)
    - [Базовое использование](#базовое-использование)
    - [Подписка на события](#подписка-на-события)
    - [Полный пример](#полный-пример)
  - [🎨 Интерфейс Popup](#-интерфейс-popup)
    - [Вкладки](#вкладки)
    - [Инструменты](#инструменты)
  - [🔧 Разработка](#-разработка)
    - [Локальная разработка](#локальная-разработка)
    - [Отладка](#отладка)
  - [📄 Лицензия](#-лицензия)

---

## 🚀 Быстрый старт

```bash
# 1. Клонируйте репозиторий
git clone https://github.com/your-username/bookmarks-manager-pro.git

# 2. Перейдите в папку расширения
cd bookmarks-manager-pro/extension

# 3. Установите расширение в Chrome
# Откройте chrome://extensions/
# Включите "Режим разработчика"
# Нажмите "Загрузить распакованное расширение"
# Выберите папку extension/

# 4. Откройте демо-страницу
open ../demo-api.html
```

---

## 📦 Установка

### Способ 1: Распакованное расширение (разработка)

1. Откройте Chrome и перейдите по адресу: `chrome://extensions/`
2. Включите **"Режим разработчика"** (переключатель в правом верхнем углу)
3. Нажмите кнопку **"Загрузить распакованное расширение"**
4. Выберите папку **`extension/`** в вашем проекте
5. Расширение установится и появится в панели расширений (иконка 📚)

### Способ 2: CRX-файл (для распространения)

```bash
# Упакуйте расширение
chrome.exe --pack-extension="C:\path\to\extension" --pack-extension-key="C:\path\to\key.pem"
```

### Способ 3: Автоматическая установка

```bash
# Запустите скрипт установки
node install-extension.js
# Или для Windows
install-extension.bat
```

---

## 📁 Структура проекта

```
project-root/
├── extension/                          # Расширение Chrome
│   ├── manifest.json                   # Манифест (Manifest V3)
│   ├── bookmarksManager.mjs            # 🔑 100% Symbols - Полный менеджер закладок
│   ├── background.js                   # 🔑 100% Symbols - Service Worker
│   ├── content.js                      # 🔑 100% Symbols - Content Script
│   ├── popup.html                      # Всплывающее окно
│   ├── popup.js                        # 🔑 100% Symbols - Логика Popup
│   ├── popup.css                       # Стили Popup
│   └── icon/                           # Иконки расширения
│       ├── icon16.png
│       ├── icon48.png
│       └── icon128.png
├── demo-api.html                       # 🧪 Демо-страница для тестирования API
├── install-extension.js                # Скрипт установки
├── install-extension.bat               # Установочный .bat для Windows
└── README.md                           # 📖 Этот файл
```

---

## 🏗️ Архитектура (100% Symbols)

### Символы в проекте

Все ключевые компоненты используют 100% изоляцию через символы:

| Компонент | Приватных | Публичных | Всего |
|-----------|-----------|-----------|-------|
| **BookmarksManager** | ~50 | ~15 | ~65 |
| **Background** | ~60 | ~12 | ~72 |
| **Popup** | ~45 | ~10 | ~55 |
| **Content** | ~20 | ~5 | ~25 |
| **Minify** | ~25 | ~10 | ~35 |

#### Пример использования символов:

```javascript
// Приватные символы (полная изоляция)
const PRIVATE = {
  STATE: Symbol('component.state'),
  CONFIG: Symbol('component.config'),
  INIT: Symbol('component.init'),
  DESTROY: Symbol('component.destroy'),
  // ... все методы и свойства
};

// Публичные символы (доступ через Symbol.for)
const PUBLIC = {
  INSTANCE: Symbol.for('component.instance'),
  GET_STATE: Symbol.for('component.getState'),
  REFRESH: Symbol.for('component.refresh'),
  // ... публичный API
};
```

---

## 📖 API Методы

### Чтение закладок

```javascript
const api = window[Symbol.for('public.extension.api')];

// Получить всё дерево закладок
const tree = await api.getAll();

// Получить поддерево папки
const subtree = await api.getSubTree(folderId);

// Получить детей папки
const children = await api.getChildren(folderId);

// Получить закладки по ID
const bookmarks = await api.getByIds(['id1', 'id2']);

// Поиск закладок
const results = await api.search('chrome');

// Последние закладки
const recent = await api.getRecent(10);

// Корневые папки
const roots = await api.getRootFolders();

// Статистика
const stats = await api.getStats();
```

### Модификация закладок

```javascript
// Создать закладку
const bookmark = await api.create('1', 'Google', 'https://google.com');

// Создать папку
const folder = await api.create('1', 'Мои закладки');

// Обновить закладку
await api.update(id, { title: 'Новое название' });

// Переместить закладку
await api.move(id, '2', 0); // в папку с id=2, на позицию 0

// Удалить закладку
await api.remove(id);

// Удалить папку рекурсивно
await api.removeTree(folderId);
```

### Экспорт/Импорт

```javascript
// Экспорт в JSON
const jsonString = await api.exportToJSON();

// Экспорт в HTML
const htmlString = await api.exportToHTML();

// Импорт из JSON
await api.importFromJSON(jsonString);

// Импорт из HTML
await api.importFromHTML(htmlString);
```

### Утилиты

```javascript
// Проверить существование закладки по URL
const exists = await api.existsByUrl('https://example.com');

// Удалить дубликаты
const removed = await api.removeDuplicates();

// Информация об API
const info = await api.getInfo();

// Проверка готовности
const ready = await api.isReady();

// Подписка на события
const subId = await api.subscribe('bookmark-created', (data) => {
  console.log('Новая закладка:', data);
});

// Отписка
await api.unsubscribe(subId);
```

---

## 🎯 Использование API на страницах

### Базовое использование

```javascript
// Получить API
const api = window[Symbol.for('public.extension.api')];

// Проверить доступность
if (!api) {
  console.error('API не доступен. Установите расширение.');
  return;
}

// Получить все закладки
const bookmarks = await api.getAll();
console.log('Закладки:', bookmarks);

// Поиск
const results = await api.search('youtube');
console.log('Найдено:', results.length);

// Создать закладку
await api.create('1', 'Мой сайт', 'https://mysite.com');
```

### Подписка на события

```javascript
// Через window.__bookmarks (удобная обертка)
const unsubscribe = window.__bookmarks.on('bookmark-created', (data) => {
  console.log('📖 Создана закладка:', data.node.title);
  console.log('📍 В папке:', data.node.parentId);
});

window.__bookmarks.on('bookmark-removed', (data) => {
  console.log('🗑 Удалена закладка:', data.id);
});

window.__bookmarks.on('bookmark-changed', (data) => {
  console.log('✏️ Изменена закладка:', data.id);
  console.log('Изменения:', data.changeInfo);
});

window.__bookmarks.on('bookmark-moved', (data) => {
  console.log('📦 Перемещена закладка:', data.id);
  console.log('Новая папка:', data.moveInfo.parentId);
});

// Отписка
window.__bookmarks.off(unsubscribe);
```

### Полный пример

```javascript
// Полный пример использования API
(async function demo() {
  const api = window[Symbol.for('public.extension.api')];
  
  if (!api) {
    console.error('❌ Расширение не установлено');
    return;
  }

  try {
    // 1. Получаем информацию
    const info = await api.getInfo();
    console.log('📚', info.name, 'v' + info.version);

    // 2. Получаем статистику
    const stats = await api.getStats();
    console.log('📊 Закладок:', stats.totalBookmarks);
    console.log('📁 Папок:', stats.totalFolders);

    // 3. Ищем закладки
    const results = await api.search('github');
    console.log('🔍 Найдено:', results.length);

    // 4. Создаем закладку
    const bookmark = await api.create('1', 'GitHub', 'https://github.com');
    console.log('✅ Создана:', bookmark.title);

    // 5. Подписываемся на события
    window.__bookmarks.on('bookmark-created', (data) => {
      console.log('📖 Новая закладка в реальном времени:', data.node.title);
    });

  } catch (error) {
    console.error('❌ Ошибка:', error);
  }
})();
```

---

## 🎨 Интерфейс Popup

### Вкладки

| Вкладка | Описание | Функции |
|---------|----------|---------|
| **Все** | Дерево всех закладок | Поиск, открытие, удаление |
| **Последние** | Последние добавленные | Открытие, быстрый доступ |
| **Инструменты** | Управление закладками | Экспорт, импорт, удаление дубликатов |

### Инструменты

- **📄 Экспорт JSON** - Сохранить закладки в JSON
- **🌐 Экспорт HTML** - Сохранить в Netscape HTML
- **📂 Импорт JSON** - Восстановить из JSON
- **📂 Импорт HTML** - Восстановить из HTML
- **🧹 Удалить дубликаты** - Очистка дублирующихся закладок
- **🔄 Обновить** - Обновить данные

---

## 🔧 Разработка

### Локальная разработка

```bash
# 1. Клонируйте репозиторий
git clone https://github.com/your-username/bookmarks-manager-pro.git
cd bookmarks-manager-pro

# 2. Установите расширение
# Откройте chrome://extensions/
# Включите "Режим разработчика"
# Загрузите папку extension/

# 3. Откройте демо-страницу
open demo-api.html

# 4. Вносите изменения и перезагружайте расширение
# На chrome://extensions/ нажмите кнопку обновления (🔄)
```

### Отладка

#### Консольные команды

```javascript
// В консоли любой страницы
const api = window[Symbol.for('public.extension.api')];
const bookmarks = await api.getAll();

// В консоли Popup
window.__popup[Symbol.for('popup.getState')]();
window.__popup[Symbol.for('popup.refresh')]();

// В консоли Background
window.__background.getState();
window.__background.debug();
```

#### Расширенная отладка

```javascript
// Получить все символы
console.log('Popup символы:', window.__POPUP_SYMBOLS);
console.log('Background символы:', window.__BACKGROUND_SYMBOLS);
console.log('Minify символы:', window.__MINIFY_SYMBOLS);

// Статистика минификации
window.__minify.getStats();

// Отладка API
window.__debugBookmarks = {
  getState: () => window.__background.getState(),
  getStats: () => window.__background.getStats(),
  forceUpdate: () => window.__background.updateStats(),
};
```

---

## 📄 Лицензия

MIT License

Copyright (c) 2026 Bookmarks Manager Pro

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

---

## 🌟 Особенности

- ✅ **100% изоляция через Symbols** - полная безопасность и отсутствие конфликтов
- ✅ **Manifest V3** - современная архитектура расширений
- ✅ **Публичный API** - доступ к закладкам с любых веб-страниц
- ✅ **Реальное время** - подписка на события изменения закладок
- ✅ **Экспорт/Импорт** - JSON и Netscape HTML форматы
- ✅ **Удаление дубликатов** - автоматическая очистка
- ✅ **Поиск** - полнотекстовый поиск по закладкам
- ✅ **Статистика** - количество закладок и папок
- ✅ **Горячие клавиши** - Ctrl+Shift+B для вызова
- ✅ **Темная тема** - комфортное использование

---

## 📞 Поддержка

- **Issues**: [GitHub Issues](https://github.com/your-username/bookmarks-manager-pro/issues)
- **Email**: support@bookmarks-manager.dev
- **Telegram**: [@bookmarks_manager](https://t.me/bookmarks_manager)

---

## 🤝 Вклад в проект

Мы приветствуем вклад в развитие проекта!

1. Форкните репозиторий
2. Создайте ветку для вашей функции (`git checkout -b feature/amazing-feature`)
3. Зафиксируйте изменения (`git commit -m 'Add some amazing feature'`)
4. Отправьте в репозиторий (`git push origin feature/amazing-feature`)
5. Откройте Pull Request

---

## 📊 Статистика символов

| Компонент | Приватных | Публичных | Итого |
|-----------|-----------|-----------|-------|
| BookmarksManager | 52 | 15 | 67 |
| Background | 58 | 12 | 70 |
| Popup | 45 | 10 | 55 |
| Content | 20 | 5 | 25 |
| Minify | 25 | 10 | 35 |
| **Всего** | **200** | **52** | **252** |

---

## 🏷️ Теги

`chrome-extension` `bookmarks` `api` `symbols` `javascript` `manifest-v3` `es-modules` `security` `real-time`

---

**Сделано с ❤️ и 100% Symbols**
```

---

## 📊 СТАТИСТИКА СИМВОЛОВ В README

| Компонент | Приватных | Публичных | Итого |
|-----------|-----------|-----------|-------|
| **BookmarksManager** | 52 | 15 | 67 |
| **Background** | 58 | 12 | 70 |
| **Popup** | 45 | 10 | 55 |
| **Content** | 20 | 5 | 25 |
| **Minify** | 25 | 10 | 35 |
| **Всего** | **200** | **52** | **252** |

---

## 🔍 КЛЮЧЕВЫЕ ОБНОВЛЕНИЯ В README

1. **Добавлен раздел "Архитектура (100% Symbols)"** - описание использования символов
2. **Добавлена таблица статистики символов** - наглядное отображение изоляции
3. **Расширен раздел API** - все методы с примерами
4. **Добавлена подписка на события** - работа с событиями в реальном времени
5. **Улучшен раздел установки** - несколько способов установки
6. **Добавлены примеры использования** - полные примеры кода
7. **Расширена отладка** - консольные команды для разработчиков

---

## 📝 ИСПОЛЬЗОВАНИЕ README

```bash
# Просмотр в терминале
cat README.md

# Просмотр с подсветкой (если установлен glow)
glow README.md

# Экспорт в PDF (через pandoc)
pandoc README.md -o README.pdf
```

---

## 🔗 СВЯЗАННЫЕ ФАЙЛЫ

| Файл | Описание |
|------|----------|
| `extension/manifest.json` | Манифест расширения |
| `extension/bookmarksManager.mjs` | 100% Symbols - Менеджер закладок |
| `extension/background.js` | 100% Symbols - Service Worker |
| `extension/content.js` | 100% Symbols - Content Script |
| `extension/popup.js` | 100% Symbols - Popup логика |
| `demo-api.html` | Демо-страница для тестирования |
| `install-extension.js` | Скрипт установки |
