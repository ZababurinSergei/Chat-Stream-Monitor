// ============================================================
// content.js - 100% СИМВОЛЫ
// Версия: 5.0.1 — ИСПРАВЛЕННАЯ
// ============================================================

(function () {
  'use strict';

  // ============================================================
  // 1. ПРОВЕРКА КОНТЕКСТА
  // ============================================================

  if (typeof window === 'undefined' || typeof document === 'undefined') {
    return;
  }

  if (typeof chrome === 'undefined' || typeof chrome.runtime === 'undefined') {
    console.warn('⚠️ Content Script: chrome.runtime не доступен');
    return;
  }

  if (typeof ServiceWorkerGlobalScope !== 'undefined' && self instanceof ServiceWorkerGlobalScope) {
    console.warn('⚠️ Content Script: Запуск в Service Worker, пропускаем');
    return;
  }

  try {
    var top = window.top;
    if (top !== window && !top.location) {
      console.log('ℹ️ Content Script: Запуск в изолированном iframe');
    }
  } catch (error) {
    console.log('ℹ️ Content Script: Ограниченный контекст, продолжаем работу');
  }

  // ============================================================
  // 2. ПРИВАТНЫЕ СИМВОЛЫ (100% изоляция)
  // ============================================================

  var PRIVATE = {
    VERSION: Symbol('content.version'),
    BUILD: Symbol('content.build'),
    NAME: Symbol('content.name'),
    CONFIG: Symbol('content.config'),
    STATE: Symbol('content.state'),
    INITIALIZED: Symbol('content.initialized'),
    DESTROYED: Symbol('content.destroyed'),
    IS_REGISTERED: Symbol('content.isRegistered'),
    TAB_ID: Symbol('content.tab.id'),
    INIT_TIME: Symbol('content.init.time'),
    REQUEST_COUNT: Symbol('content.request.count'),
    REQUEST_MAP: Symbol('content.request.map'),
    INIT: Symbol('content.init'),
    DESTROY: Symbol('content.destroy'),
    REGISTER: Symbol('content.register'),
    UNREGISTER: Symbol('content.unregister'),
    SETUP_HANDLERS: Symbol('content.setupHandlers'),
    SAFE_EXECUTE: Symbol('content.safeExecute'),
    HANDLE_MESSAGE: Symbol('content.handleMessage'),
    SEND_RESPONSE: Symbol('content.sendResponse'),
    SEND_ERROR: Symbol('content.sendError'),
    FORWARD_TO_BACKGROUND: Symbol('content.forwardToBackground'),
    GET_STATE: Symbol('content.getState'),
    CLEANUP: Symbol('content.cleanup'),
    BEFORE_UNLOAD: Symbol('content.beforeUnload'),
    CHECK_CONTEXT: Symbol('content.checkContext'),
    VALIDATE_REQUEST: Symbol('content.validateRequest'),
    SANITIZE_ARGS: Symbol('content.sanitizeArgs'),
    GENERATE_ID: Symbol('content.generateId'),
    EXPORT_SYMBOLS: Symbol('content.exportSymbols'),
    GET_SYMBOLS: Symbol('content.getSymbols'),
    LOG: Symbol('content.log'),
    DEBUG: Symbol('content.debug'),
    ERROR: Symbol('content.error'),
    WARN: Symbol('content.warn'),
    SUCCESS: Symbol('content.success'),
    MESSAGE_HANDLER: Symbol('content.messageHandler'),
    CONTEXT: Symbol('content.context'),
    INJECT_DEBUG: Symbol('content.injectDebug'),
  };

  // ============================================================
  // 3. ПУБЛИЧНЫЕ СИМВОЛЫ (доступны через Symbol.for)
  // ============================================================

  var PUBLIC = {
    INSTANCE: Symbol.for('content.instance'),
    STATE: Symbol.for('content.state'),
    CONFIG: Symbol.for('content.config'),
    INIT: Symbol.for('content.init'),
    DESTROY: Symbol.for('content.destroy'),
    GET_STATE: Symbol.for('content.getState'),
    GET_STATS: Symbol.for('content.getStats'),
    CONTEXT: Symbol.for('content.context'),
  };

  // ============================================================
  // 4. КОНФИГУРАЦИЯ
  // ============================================================

  var CONFIG = {
    version: '5.0.1',
    build: '2026-07-24',
    name: 'Bookmarks Content Script',
    debug: true,
    timeout: 30000,
    maxRequests: 1000,
  };

  // ============================================================
  // 5. СОСТОЯНИЕ
  // ============================================================

  var STATE = {};
  STATE[PRIVATE.INITIALIZED] = false;
  STATE[PRIVATE.DESTROYED] = false;
  STATE[PRIVATE.IS_REGISTERED] = false;
  STATE[PRIVATE.TAB_ID] = null;
  STATE[PRIVATE.INIT_TIME] = null;
  STATE[PRIVATE.REQUEST_COUNT] = 0;
  STATE[PRIVATE.REQUEST_MAP] = new Map();
  STATE[PRIVATE.MESSAGE_HANDLER] = null;
  STATE[PRIVATE.CONTEXT] = null;

  // ============================================================
  // 6. ЛОГГЕР (ПРОСТОЙ, БЕЗ header)
  // ============================================================

  function createLogger() {
    return {
      error: function(msg, data) {
        console.error('❌ [Content] ' + msg, data || '');
      },
      warn: function(msg, data) {
        console.warn('⚠️ [Content] ' + msg, data || '');
      },
      info: function(msg, data) {
        console.info('ℹ️ [Content] ' + msg, data || '');
      },
      debug: function(msg, data) {
        if (CONFIG.debug) {
          console.debug('🔍 [Content] ' + msg, data || '');
        }
      },
      success: function(msg, data) {
        console.log('✅ [Content] ' + msg, data || '');
      }
    };
  }

  var logger = createLogger();

  // ============================================================
  // 7. ВАЛИДАТОР
  // ============================================================

  var VALIDATOR = {};

  VALIDATOR[PRIVATE.CHECK_CONTEXT] = {
    isBrowser: function() {
      return typeof window !== 'undefined' && typeof document !== 'undefined';
    },
    isExtension: function() {
      return typeof chrome !== 'undefined' && typeof chrome.runtime !== 'undefined';
    },
    isSecure: function() {
      return window.isSecureContext || false;
    },
    isTopFrame: function() {
      try {
        return window === window.top;
      } catch (e) {
        return false;
      }
    },
    getContextInfo: function() {
      return {
        isBrowser: typeof window !== 'undefined',
        isExtension: typeof chrome !== 'undefined',
        isSecure: window.isSecureContext || false,
        isTopFrame: this.isTopFrame(),
        origin: window.location ? window.location.origin : 'unknown',
        url: window.location ? window.location.href : 'unknown',
        timestamp: Date.now()
      };
    }
  };

  VALIDATOR[PRIVATE.VALIDATE_REQUEST] = {
    isValid: function(data) {
      if (!data || typeof data !== 'object') return false;
      if (!data.action || typeof data.action !== 'string') return false;
      if (!data.id || typeof data.id !== 'string') return false;
      if (data.args !== undefined && !Array.isArray(data.args)) return false;
      return true;
    },
    isKnownAction: function(action) {
      var knownActions = [
        'getAll', 'getSubTree', 'getChildren', 'getByIds',
        'search', 'getRecent', 'getRootFolders', 'getStats',
        'create', 'update', 'move', 'remove', 'removeTree',
        'exportToJSON', 'exportToHTML', 'importFromJSON',
        'importFromHTML', 'existsByUrl', 'removeDuplicates',
        'getInfo', 'isReady', 'getStatus', 'registerTab', 'unregisterTab'
      ];
      return knownActions.indexOf(action) !== -1;
    },
    isArgsValid: function(args) {
      if (!Array.isArray(args)) return false;
      if (args.length > 10) return false;
      for (var i = 0; i < args.length; i++) {
        var arg = args[i];
        if (arg === undefined || arg === null) continue;
        if (typeof arg === 'function') return false;
        if (typeof arg === 'object' && arg !== null) {
          try {
            JSON.stringify(arg);
          } catch (e) {
            return false;
          }
        }
      }
      return true;
    }
  };

  VALIDATOR[PRIVATE.SANITIZE_ARGS] = {
    sanitize: function(args) {
      if (!Array.isArray(args)) return [];
      var result = [];
      for (var i = 0; i < args.length && i < 10; i++) {
        var arg = args[i];
        if (arg === undefined || arg === null) {
          result.push(null);
        } else if (typeof arg === 'function') {
          result.push(null);
        } else if (typeof arg === 'object') {
          try {
            result.push(JSON.parse(JSON.stringify(arg)));
          } catch (e) {
            result.push(null);
          }
        } else {
          result.push(arg);
        }
      }
      return result;
    }
  };

  VALIDATOR[PRIVATE.GENERATE_ID] = {
    generate: function() {
      return Date.now().toString(36) + '_' + Math.random().toString(36).substr(2, 9);
    }
  };

  // ============================================================
  // 8. ОСНОВНОЙ ОБЪЕКТ CONTENT
  // ============================================================

  var Content = {};

  // ============================================================
  // 8.1. ИНИЦИАЛИЗАЦИЯ
  // ============================================================

  Content[PRIVATE.INIT] = function() {
    var state = STATE;
    var log = logger;

    if (state[PRIVATE.INITIALIZED]) {
      log.warn('⚠️ Content Script уже инициализирован');
      return false;
    }

    var context = VALIDATOR[PRIVATE.CHECK_CONTEXT].getContextInfo();

    if (!context.isBrowser) {
      log.warn('⚠️ Не браузерный контекст, пропускаем');
      return false;
    }

    if (!context.isExtension) {
      log.warn('⚠️ Расширение не доступно, пропускаем');
      return false;
    }

    if (typeof ServiceWorkerGlobalScope !== 'undefined' && self instanceof ServiceWorkerGlobalScope) {
      log.warn('⚠️ Запуск в Service Worker, пропускаем');
      return false;
    }

    state[PRIVATE.CONTEXT] = context;

    log.info('📦 Версия: ' + CONFIG.version);
    log.info('📅 Сборка: ' + CONFIG.build);
    log.info('🌐 Контекст:', context);

    try {
      Content[PRIVATE.REGISTER]();
      Content[PRIVATE.SETUP_HANDLERS]();
      Content[PRIVATE.INJECT_DEBUG]();
      Content[PRIVATE.EXPORT_SYMBOLS]();

      state[PRIVATE.INITIALIZED] = true;
      state[PRIVATE.INIT_TIME] = Date.now();

      log.success('✅ Content Script инициализирован');
      return true;
    } catch (error) {
      log.error('❌ Ошибка инициализации:', error);
      return false;
    }
  };

  // ============================================================
  // 8.2. ВНЕДРЕНИЕ ОТЛАДОЧНЫХ КОМАНД
  // ============================================================

  Content[PRIVATE.INJECT_DEBUG] = function() {
    try {
      var state = STATE;
      var log = logger;

      window.__debugContent = {
        getState: function() {
          return Content[PUBLIC.GET_STATE]();
        },
        getStats: function() {
          return Content[PUBLIC.GET_STATS]();
        },
        getContext: function() {
          return state[PRIVATE.CONTEXT];
        },
        getPendingRequests: function() {
          return Array.from(state[PRIVATE.REQUEST_MAP].entries());
        },
        getSymbols: function() {
          return {
            PRIVATE: PRIVATE,
            PUBLIC: PUBLIC
          };
        },
        getConfig: function() {
          return CONFIG;
        },
        destroy: function() {
          Content[PRIVATE.DESTROY]();
        },
        cleanup: function() {
          Content[PRIVATE.CLEANUP]();
        }
      };

      log.debug('✅ Отладочные команды внедрены');
    } catch (error) {
      logger.error('⚠️ Ошибка внедрения отладочных команд:', error);
    }
  };

  // ============================================================
  // 8.3. РЕГИСТРАЦИЯ В BACKGROUND
  // ============================================================

  Content[PRIVATE.REGISTER] = function() {
    var state = STATE;
    var log = logger;

    if (state[PRIVATE.IS_REGISTERED]) {
      log.debug('ℹ️ Уже зарегистрирован');
      return;
    }

    log.info('📡 Регистрация вкладки в background...');

    try {
      chrome.runtime.sendMessage({ action: 'registerTab' }, function(response) {
        if (chrome.runtime.lastError) {
          log.error('❌ Ошибка регистрации:', chrome.runtime.lastError.message);
          return;
        }

        if (response && response.success) {
          state[PRIVATE.IS_REGISTERED] = true;
          log.success('✅ Вкладка зарегистрирована');
        } else {
          log.warn('⚠️ Не удалось зарегистрировать вкладку:', response ? response.error : 'unknown');
        }
      });
    } catch (error) {
      log.error('❌ Ошибка регистрации:', error);
    }
  };

  // ============================================================
  // 8.4. НАСТРОЙКА ОБРАБОТЧИКОВ
  // ============================================================

  Content[PRIVATE.SETUP_HANDLERS] = function() {
    var state = STATE;
    var log = logger;

    log.info('🔧 Настройка обработчиков...');

    var handler = function(event) {
      if (event.source !== window) return;
      if (!event.data || typeof event.data !== 'object') return;
      if (event.data.action !== 'apiCall') return;

      Content[PRIVATE.HANDLE_MESSAGE](event.data);
    };

    state[PRIVATE.MESSAGE_HANDLER] = handler;
    window.addEventListener('message', handler);

    window.addEventListener('beforeunload', function() {
      Content[PRIVATE.BEFORE_UNLOAD]();
    });

    log.success('✅ Обработчики настроены');
  };

  // ============================================================
  // 8.5. ОБРАБОТКА СООБЩЕНИЙ
  // ============================================================

  Content[PRIVATE.HANDLE_MESSAGE] = function(data) {
    var log = logger;
    var state = STATE;

    if (!VALIDATOR[PRIVATE.VALIDATE_REQUEST].isValid(data)) {
      log.warn('⚠️ Некорректный запрос:', data);
      return;
    }

    var id = data.id;
    var method = data.method || data.action;
    var args = data.args || [];

    if (method === 'apiCall') {
      log.warn('⚠️ Не указан метод в запросе', data);
      Content[PRIVATE.SEND_ERROR](id, 'Не указан метод');
      return;
    }

    if (!VALIDATOR[PRIVATE.VALIDATE_REQUEST].isKnownAction(method)) {
      log.warn('⚠️ Неизвестное действие: ' + method);
      Content[PRIVATE.SEND_ERROR](id, 'Неизвестное действие: ' + method);
      return;
    }

    if (!VALIDATOR[PRIVATE.VALIDATE_REQUEST].isArgsValid(args)) {
      log.warn('⚠️ Некорректные аргументы для ' + method);
      Content[PRIVATE.SEND_ERROR](id, 'Некорректные аргументы');
      return;
    }

    var sanitizedArgs = VALIDATOR[PRIVATE.SANITIZE_ARGS].sanitize(args);

    state[PRIVATE.REQUEST_COUNT] = state[PRIVATE.REQUEST_COUNT] + 1;
    log.debug('📨 Запрос #' + state[PRIVATE.REQUEST_COUNT] + ': ' + method, sanitizedArgs);

    state[PRIVATE.REQUEST_MAP].set(id, {
      method: method,
      args: sanitizedArgs,
      timestamp: Date.now(),
      count: state[PRIVATE.REQUEST_COUNT]
    });

    Content[PRIVATE.CLEANUP]();
    Content[PRIVATE.FORWARD_TO_BACKGROUND](id, method, sanitizedArgs);
  };

  // ============================================================
  // 8.6. ПЕРЕСЫЛКА В BACKGROUND
  // ============================================================

  Content[PRIVATE.FORWARD_TO_BACKGROUND] = function(id, method, args) {
    var log = logger;

    try {
      chrome.runtime.sendMessage(
        {
          action: method,
          args: args
        },
        function(response) {
          if (chrome.runtime.lastError) {
            log.error('❌ Ошибка chrome.runtime:', chrome.runtime.lastError.message);
            Content[PRIVATE.SEND_ERROR](id, chrome.runtime.lastError.message);
            return;
          }

          if (response && response.success !== false) {
            Content[PRIVATE.SEND_RESPONSE](id, response.data);
          } else {
            Content[PRIVATE.SEND_ERROR](id, response ? response.error : 'Неизвестная ошибка');
          }
        }
      );
    } catch (error) {
      log.error('❌ Ошибка отправки в background:', error);
      Content[PRIVATE.SEND_ERROR](id, error.message);
    }
  };

  // ============================================================
  // 8.7. ОТПРАВКА ОТВЕТОВ
  // ============================================================

  Content[PRIVATE.SEND_RESPONSE] = function(id, result) {
    var state = STATE;

    try {
      window.postMessage(
        {
          action: 'response',
          id: id,
          success: true,
          result: result,
          timestamp: Date.now()
        },
        '*'
      );

      state[PRIVATE.REQUEST_MAP].delete(id);
      logger.debug('✅ Ответ отправлен для #' + id);
    } catch (error) {
      logger.error('❌ Ошибка отправки ответа:', error);
    }
  };

  Content[PRIVATE.SEND_ERROR] = function(id, error) {
    var state = STATE;

    try {
      window.postMessage(
        {
          action: 'response',
          id: id,
          success: false,
          error: error,
          timestamp: Date.now()
        },
        '*'
      );

      state[PRIVATE.REQUEST_MAP].delete(id);
      logger.warn('⚠️ Ошибка для #' + id + ': ' + error);
    } catch (err) {
      logger.error('❌ Ошибка отправки ошибки:', err);
    }
  };

  // ============================================================
  // 8.8. ОЧИСТКА
  // ============================================================

  Content[PRIVATE.CLEANUP] = function() {
    var state = STATE;
    var now = Date.now();
    var timeout = CONFIG.timeout;

    for (var entry of state[PRIVATE.REQUEST_MAP]) {
      var id = entry[0];
      var data = entry[1];
      if (now - data.timestamp > timeout) {
        state[PRIVATE.REQUEST_MAP].delete(id);
        logger.debug('🧹 Старый запрос удалён: ' + id);
      }
    }

    if (state[PRIVATE.REQUEST_MAP].size > CONFIG.maxRequests) {
      var entries = Array.from(state[PRIVATE.REQUEST_MAP].entries());
      var toRemove = entries.slice(0, state[PRIVATE.REQUEST_MAP].size - CONFIG.maxRequests);
      for (var i = 0; i < toRemove.length; i++) {
        var id = toRemove[i][0];
        state[PRIVATE.REQUEST_MAP].delete(id);
      }
      logger.debug('🧹 Очищено ' + toRemove.length + ' старых запросов');
    }
  };

  // ============================================================
  // 8.9. ПЕРЕД ЗАКРЫТИЕМ
  // ============================================================

  Content[PRIVATE.BEFORE_UNLOAD] = function() {
    logger.info('🧹 Очистка перед закрытием...');
    Content[PRIVATE.UNREGISTER]();
    Content[PRIVATE.DESTROY]();
  };

  // ============================================================
  // 8.10. ОТПИСКА
  // ============================================================

  Content[PRIVATE.UNREGISTER] = function() {
    var state = STATE;

    if (!state[PRIVATE.IS_REGISTERED]) {
      return;
    }

    try {
      chrome.runtime.sendMessage({ action: 'unregisterTab' }, function() {
        // Игнорируем ошибки при отписке
      });
      state[PRIVATE.IS_REGISTERED] = false;
      logger.success('✅ Вкладка отписана');
    } catch (error) {
      logger.warn('⚠️ Ошибка отписки:', error);
    }
  };

  // ============================================================
  // 8.11. УНИЧТОЖЕНИЕ
  // ============================================================

  Content[PRIVATE.DESTROY] = function() {
    var state = STATE;

    if (state[PRIVATE.DESTROYED]) {
      return;
    }

    logger.info('🧹 Уничтожение Content Script...');

    if (state[PRIVATE.MESSAGE_HANDLER]) {
      window.removeEventListener('message', state[PRIVATE.MESSAGE_HANDLER]);
      state[PRIVATE.MESSAGE_HANDLER] = null;
    }

    state[PRIVATE.REQUEST_MAP].clear();
    state[PRIVATE.DESTROYED] = true;
    state[PRIVATE.INITIALIZED] = false;

    try {
      delete window.__CONTENT_SYMBOLS;
      delete window.__debugContent;
      delete window[PUBLIC.INSTANCE];
    } catch (error) {}

    logger.success('✅ Content Script уничтожен');
  };

  // ============================================================
  // 8.12. ПОЛУЧЕНИЕ СОСТОЯНИЯ
  // ============================================================

  Content[PRIVATE.GET_STATE] = function() {
    var state = STATE;
    return {
      initialized: state[PRIVATE.INITIALIZED],
      destroyed: state[PRIVATE.DESTROYED],
      isRegistered: state[PRIVATE.IS_REGISTERED],
      initTime: state[PRIVATE.INIT_TIME],
      requestCount: state[PRIVATE.REQUEST_COUNT],
      pendingRequests: state[PRIVATE.REQUEST_MAP].size,
      version: CONFIG.version,
      build: CONFIG.build,
      context: state[PRIVATE.CONTEXT]
    };
  };

  // ============================================================
  // 8.13. ЭКСПОРТ СИМВОЛОВ
  // ============================================================

  Content[PRIVATE.EXPORT_SYMBOLS] = function() {
    try {
      window.__CONTENT_SYMBOLS = {
        PRIVATE: PRIVATE,
        PUBLIC: PUBLIC,
        CONFIG: CONFIG
      };

      window.__CONTENT_SYMBOLS_INFO = {
        privateCount: Object.keys(PRIVATE).length,
        publicCount: Object.keys(PUBLIC).length,
        totalCount: Object.keys(PRIVATE).length + Object.keys(PUBLIC).length,
        version: CONFIG.version,
        build: CONFIG.build
      };

      window[PUBLIC.INSTANCE] = Content;
    } catch (error) {
      logger.error('❌ Ошибка экспорта символов:', error);
    }
  };

  // ============================================================
  // 8.14. ПУБЛИЧНЫЕ МЕТОДЫ
  // ============================================================

  Content[PUBLIC.GET_STATE] = function() {
    return Content[PRIVATE.GET_STATE]();
  };

  Content[PUBLIC.GET_STATS] = function() {
    var state = STATE;
    return {
      totalRequests: state[PRIVATE.REQUEST_COUNT],
      pendingRequests: state[PRIVATE.REQUEST_MAP].size,
      uptime: state[PRIVATE.INIT_TIME] ? Date.now() - state[PRIVATE.INIT_TIME] : 0,
      isReady: state[PRIVATE.INITIALIZED] && !state[PRIVATE.DESTROYED]
    };
  };

  Content[PUBLIC.GET_CONTEXT] = function() {
    return STATE[PRIVATE.CONTEXT];
  };

  Content[PUBLIC.INIT] = function() {
    return Content[PRIVATE.INIT]();
  };

  Content[PUBLIC.DESTROY] = function() {
    return Content[PRIVATE.DESTROY]();
  };

  // ============================================================
  // 9. ЗАПУСК
  // ============================================================

  var isBrowser = typeof window !== 'undefined' && typeof document !== 'undefined';
  var isExtension = typeof chrome !== 'undefined' && typeof chrome.runtime !== 'undefined';

  if (isBrowser && isExtension) {
    var isServiceWorker = typeof ServiceWorkerGlobalScope !== 'undefined' && self instanceof ServiceWorkerGlobalScope;

    if (!isServiceWorker) {
      try {
        var success = Content[PRIVATE.INIT]();

        if (success !== false) {
          console.log('✅ Content Script успешно загружен (100% символы)');
          console.log('📋 Используйте window.__debugContent для отладки');
          console.log('📋 Используйте postMessage для запросов');
        }
      } catch (error) {
        console.error('❌ Ошибка инициализации Content Script:', error);
      }
    } else {
      console.log('ℹ️ Content Script: Запуск в Service Worker, пропускаем');
    }
  } else {
    console.log('ℹ️ Content Script: Не браузерный контекст, пропускаем');
  }

  // ============================================================
  // 10. КОНСОЛЬНЫЙ ИНТЕРФЕЙС
  // ============================================================

  if (isBrowser && isExtension) {
    var privateCount = Object.keys(PRIVATE).length;
    var publicCount = Object.keys(PUBLIC).length;

    console.log('╔═══════════════════════════════════════════════════════════════════════════════╗');
    console.log('║              📦 CONTENT SCRIPT (100% СИМВОЛЫ) v5.0.1                        ║');
    console.log('╠═══════════════════════════════════════════════════════════════════════════════╣');
    console.log('║  📋 postMessage → chrome.runtime → postMessage                               ║');
    console.log('║  🔑 Полная изоляция через приватные символы                                 ║');
    console.log('║  🔓 Публичные символы через Symbol.for                                      ║');
    console.log('║  🛡️ БЕЗ EVAL — БЕЗ INLINE-СКРИПТОВ — CSP-безопасно                         ║');
    console.log('║  📨 Запросы: { action: "apiCall", id, method, args }                       ║');
    console.log('║  📡 Ответы: { action: "response", id, success, result }                     ║');
    console.log('╚═══════════════════════════════════════════════════════════════════════════════╝');

    console.log('📊 СТАТИСТИКА СИМВОЛОВ:');
    console.log('  🔑 Приватных символов: ' + privateCount);
    console.log('  🔓 Публичных символов: ' + publicCount);
    console.log('  📦 Всего символов: ' + (privateCount + publicCount));
    console.log('');

    console.log('📨 ФУНКЦИЯ ДЛЯ СТРАНИЦЫ (скопируйте в консоль):');
    console.log('');
    console.log('  function bmRequest(action, args) {');
    console.log('    return new Promise(function(resolve, reject) {');
    console.log('      var id = Date.now() + "_" + Math.random().toString(36).substr(2, 9);');
    console.log('      var handler = function(e) {');
    console.log('        if (e.data && e.data.action === "response" && e.data.id === id) {');
    console.log('          window.removeEventListener("message", handler);');
    console.log('          e.data.success ? resolve(e.data.result) : reject(new Error(e.data.error));');
    console.log('        }');
    console.log('      };');
    console.log('      window.addEventListener("message", handler);');
    console.log('      window.postMessage({ action: "apiCall", id: id, method: action, args: args }, "*");');
    console.log('      setTimeout(function() {');
    console.log('        window.removeEventListener("message", handler);');
    console.log('        reject(new Error("Timeout"));');
    console.log('      }, 30000);');
    console.log('    });');
    console.log('  }');
    console.log('');
    console.log('📨 ПРИМЕРЫ:');
    console.log('  var bookmarks = await bmRequest("getAll");');
    console.log('  var stats = await bmRequest("getStats");');
    console.log('  var found = await bmRequest("search", ["test"]);');
    console.log('');

    console.log('✅ Content Script загружен (100% символы)');
  }

})();