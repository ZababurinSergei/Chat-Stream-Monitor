// ============================================================
// background.js - 100% СИМВОЛЫ
// Версия: 3.0.3 — ИСПРАВЛЕНА ОШИБКА bookmarks.create
// ============================================================

(function() {
  'use strict';

  // ============================================================
  // 1. ПРОВЕРКА КОНТЕКСТА
  // ============================================================

  if (typeof chrome === 'undefined' || typeof chrome.runtime === 'undefined') {
    console.warn('⚠️ Background: chrome.runtime не доступен');
    return;
  }

  // ============================================================
  // 2. ПРИВАТНЫЕ СИМВОЛЫ (100% изоляция)
  // ============================================================

  var PRIVATE = {
    VERSION: Symbol('background.version'),
    BUILD: Symbol('background.build'),
    NAME: Symbol('background.name'),
    CONFIG: Symbol('background.config'),
    STATE: Symbol('background.state'),
    INITIALIZED: Symbol('background.initialized'),
    DESTROYED: Symbol('background.destroyed'),
    IS_READY: Symbol('background.isReady'),
    START_TIME: Symbol('background.startTime'),
    REQUEST_COUNT: Symbol('background.request.count'),
    REQUEST_MAP: Symbol('background.request.map'),
    INIT: Symbol('background.init'),
    DESTROY: Symbol('background.destroy'),
    SETUP_LISTENERS: Symbol('background.setupListeners'),
    SAFE_EXECUTE: Symbol('background.safeExecute'),
    HANDLE_MESSAGE: Symbol('background.handleMessage'),
    HANDLE_REQUEST: Symbol('background.handleRequest'),
    SEND_RESPONSE: Symbol('background.sendResponse'),
    SEND_ERROR: Symbol('background.sendError'),
    CALL_BOOKMARKS_API: Symbol('background.callBookmarksAPI'),
    COUNT_NODES: Symbol('background.countNodes'),
    GET_STATE: Symbol('background.getState'),
    EXPORT_SYMBOLS: Symbol('background.exportSymbols'),
    EXTENSION_ID: Symbol('background.extensionId'),
    MANIFEST: Symbol('background.manifest'),
    CHECK_CONTEXT: Symbol('background.checkContext'),
    VALIDATE_REQUEST: Symbol('background.validateRequest'),
    SANITIZE_ARGS: Symbol('background.sanitizeArgs'),
  };

  // ============================================================
  // 3. ПУБЛИЧНЫЕ СИМВОЛЫ (доступны через Symbol.for)
  // ============================================================

  var PUBLIC = {
    INSTANCE: Symbol.for('background.instance'),
    STATE: Symbol.for('background.state'),
    CONFIG: Symbol.for('background.config'),
    INIT: Symbol.for('background.init'),
    DESTROY: Symbol.for('background.destroy'),
    GET_STATE: Symbol.for('background.getState'),
    GET_STATS: Symbol.for('background.getStats'),
    GET_INFO: Symbol.for('background.getInfo'),
    IS_READY: Symbol.for('background.isReady'),
  };

  // ============================================================
  // 4. КОНФИГУРАЦИЯ
  // ============================================================

  var CONFIG = {
    version: '3.0.3',
    build: '2026-07-24',
    name: 'Bookmarks Background',
    debug: true,
    timeout: 30000,
    maxRequests: 1000,
  };

  // ============================================================
  // 5. СОСТОЯНИЕ
  // ============================================================

  var STATE = {};
  STATE[PRIVATE.INITIALIZED] = false;
  STATE[PRIVATE.DESTROYED] = false;
  STATE[PRIVATE.IS_READY] = false;
  STATE[PRIVATE.START_TIME] = null;
  STATE[PRIVATE.REQUEST_COUNT] = 0;
  STATE[PRIVATE.REQUEST_MAP] = new Map();
  STATE[PRIVATE.EXTENSION_ID] = null;
  STATE[PRIVATE.MANIFEST] = null;

  // ============================================================
  // 6. ЛОГГЕР
  // ============================================================

  function createLogger() {
    return {
      error: function(msg, data) {
        console.error('❌ [Background] ' + msg, data || '');
      },
      warn: function(msg, data) {
        console.warn('⚠️ [Background] ' + msg, data || '');
      },
      info: function(msg, data) {
        console.info('ℹ️ [Background] ' + msg, data || '');
      },
      debug: function(msg, data) {
        if (CONFIG.debug) {
          console.debug('🔍 [Background] ' + msg, data || '');
        }
      },
      success: function(msg, data) {
        console.log('✅ [Background] ' + msg, data || '');
      },
      header: function(title) {
        console.log('═'.repeat(60));
        console.log('  📦 ' + title);
        console.log('═'.repeat(60));
      },
      separator: function() {
        console.log('─'.repeat(60));
      }
    };
  }

  var logger = createLogger();

  // ============================================================
  // 7. ВАЛИДАТОР
  // ============================================================

  var VALIDATOR = {};

  VALIDATOR[PRIVATE.CHECK_CONTEXT] = {
    isExtension: function() {
      return typeof chrome !== 'undefined' && typeof chrome.runtime !== 'undefined';
    },
    hasBookmarks: function() {
      return typeof chrome !== 'undefined' && typeof chrome.bookmarks !== 'undefined';
    },
    getContextInfo: function() {
      return {
        isExtension: this.isExtension(),
        hasBookmarks: this.hasBookmarks(),
        extensionId: chrome.runtime ? chrome.runtime.id : null,
        timestamp: Date.now()
      };
    }
  };

  VALIDATOR[PRIVATE.VALIDATE_REQUEST] = {
    isValid: function(message) {
      if (!message || typeof message !== 'object') return false;
      if (!message.action || typeof message.action !== 'string') return false;
      if (message.args !== undefined && !Array.isArray(message.args)) return false;
      return true;
    },
    isKnownAction: function(action) {
      var knownActions = [
        'getAll', 'getSubTree', 'getChildren', 'getByIds',
        'search', 'getRecent', 'getRootFolders', 'getStats',
        'create', 'update', 'move', 'remove', 'removeTree',
        'exportToJSON', 'exportToHTML', 'importFromJSON',
        'importFromHTML', 'existsByUrl', 'removeDuplicates',
        'getInfo', 'isReady', 'getStatus', 'registerTab', 'unregisterTab'
      ];
      return knownActions.indexOf(action) !== -1;
    },
    isArgsValid: function(args) {
      if (!Array.isArray(args)) return false;
      if (args.length > 10) return false;
      for (var i = 0; i < args.length; i++) {
        var arg = args[i];
        if (arg === undefined || arg === null) continue;
        if (typeof arg === 'function') return false;
        if (typeof arg === 'object' && arg !== null) {
          try {
            JSON.stringify(arg);
          } catch (e) {
            return false;
          }
        }
      }
      return true;
    }
  };

  VALIDATOR[PRIVATE.SANITIZE_ARGS] = {
    sanitize: function(args) {
      if (!Array.isArray(args)) return [];
      var result = [];
      for (var i = 0; i < args.length && i < 10; i++) {
        var arg = args[i];
        if (arg === undefined || arg === null) {
          result.push(null);
        } else if (typeof arg === 'function') {
          result.push(null);
        } else if (typeof arg === 'object') {
          try {
            result.push(JSON.parse(JSON.stringify(arg)));
          } catch (e) {
            result.push(null);
          }
        } else {
          result.push(arg);
        }
      }
      return result;
    }
  };

  // ============================================================
  // 8. ОСНОВНОЙ ОБЪЕКТ BACKGROUND
  // ============================================================

  var Background = {};

  // ============================================================
  // 8.1. ИНИЦИАЛИЗАЦИЯ
  // ============================================================

  Background[PRIVATE.INIT] = function() {
    var state = STATE;
    var log = logger;

    if (state[PRIVATE.INITIALIZED]) {
      log.warn('⚠️ Background уже инициализирован');
      return false;
    }

    var context = VALIDATOR[PRIVATE.CHECK_CONTEXT].getContextInfo();

    if (!context.isExtension) {
      log.error('❌ Не расширение Chrome');
      return false;
    }

    if (!context.hasBookmarks) {
      log.error('❌ chrome.bookmarks не доступен');
      return false;
    }

    if (chrome.runtime) {
      state[PRIVATE.EXTENSION_ID] = chrome.runtime.id;
      try {
        state[PRIVATE.MANIFEST] = chrome.runtime.getManifest();
      } catch (error) {
        log.warn('⚠️ Не удалось получить манифест:', error);
      }
    }

    log.header('ИНИЦИАЛИЗАЦИЯ BACKGROUND (100% СИМВОЛЫ)');
    log.info('📦 Версия: ' + CONFIG.version);
    log.info('📅 Сборка: ' + CONFIG.build);
    log.separator();
    log.info('🆔 ID расширения:', state[PRIVATE.EXTENSION_ID]);
    log.separator();

    try {
      Background[PRIVATE.SETUP_LISTENERS]();
      Background[PRIVATE.EXPORT_SYMBOLS]();

      state[PRIVATE.INITIALIZED] = true;
      state[PRIVATE.IS_READY] = true;
      state[PRIVATE.START_TIME] = Date.now();

      log.success('✅ Background инициализирован');
      log.header('ГОТОВ');

      return true;
    } catch (error) {
      log.error('❌ Ошибка инициализации:', error);
      return false;
    }
  };

  // ============================================================
  // 8.2. НАСТРОЙКА ОБРАБОТЧИКОВ
  // ============================================================

  Background[PRIVATE.SETUP_LISTENERS] = function() {
    var log = logger;

    log.info('🔧 Настройка обработчиков...');

    chrome.runtime.onMessage.addListener(function(message, sender, sendResponse) {
      return Background[PRIVATE.HANDLE_MESSAGE](message, sender, sendResponse);
    });

    chrome.runtime.onInstalled.addListener(function(details) {
      log.info('📦 Расширение установлено/обновлено:', details);
    });

    log.success('✅ Обработчики настроены');
  };

  // ============================================================
  // 8.3. ОБРАБОТКА СООБЩЕНИЙ
  // ============================================================

  Background[PRIVATE.HANDLE_MESSAGE] = function(message, sender, sendResponse) {
    var log = logger;
    var state = STATE;

    if (!VALIDATOR[PRIVATE.VALIDATE_REQUEST].isValid(message)) {
      log.warn('⚠️ Некорректное сообщение:', message);
      sendResponse({ success: false, error: 'Invalid message' });
      return false;
    }

    var action = message.action;
    var args = message.args || [];

    log.debug('📨 Сообщение от ' + (sender.tab ? 'вкладки' : 'фона') + ': ' + action, { args: args });

    if (!VALIDATOR[PRIVATE.VALIDATE_REQUEST].isKnownAction(action)) {
      log.warn('⚠️ Неизвестное действие: ' + action);
      sendResponse({ success: false, error: 'Unknown action: ' + action });
      return false;
    }

    if (!VALIDATOR[PRIVATE.VALIDATE_REQUEST].isArgsValid(args)) {
      log.warn('⚠️ Некорректные аргументы для ' + action);
      sendResponse({ success: false, error: 'Invalid arguments' });
      return false;
    }

    var sanitizedArgs = VALIDATOR[PRIVATE.SANITIZE_ARGS].sanitize(args);
    state[PRIVATE.REQUEST_COUNT] = state[PRIVATE.REQUEST_COUNT] + 1;

    Background[PRIVATE.HANDLE_REQUEST](action, sanitizedArgs, sender)
      .then(function(result) {
        Background[PRIVATE.SEND_RESPONSE](sendResponse, true, result);
      })
      .catch(function(error) {
        Background[PRIVATE.SEND_ERROR](sendResponse, error);
      });

    return true;
  };

  // ============================================================
  // 8.4. ОБРАБОТКА ЗАПРОСА
  // ============================================================

  Background[PRIVATE.HANDLE_REQUEST] = function(action, args, sender) {
    var log = logger;

    return new Promise(function(resolve, reject) {
      if (action === 'registerTab') {
        log.success('✅ Вкладка зарегистрирована:', sender.tab ? sender.tab.id : 'unknown');
        resolve({ registered: true, tabId: sender.tab ? sender.tab.id : null });
        return;
      }

      if (action === 'unregisterTab') {
        log.success('✅ Вкладка отписана:', sender.tab ? sender.tab.id : 'unknown');
        resolve({ unregistered: true, tabId: sender.tab ? sender.tab.id : null });
        return;
      }

      if (action === 'getInfo') {
        var state = STATE;
        resolve({
          name: CONFIG.name,
          version: CONFIG.version,
          extensionId: state[PRIVATE.EXTENSION_ID],
          isReady: state[PRIVATE.IS_READY],
          initialized: state[PRIVATE.INITIALIZED],
          startTime: state[PRIVATE.START_TIME],
          requestCount: state[PRIVATE.REQUEST_COUNT]
        });
        return;
      }

      if (action === 'getStatus') {
        var state = STATE;
        resolve({
          status: 'ok',
          isReady: state[PRIVATE.IS_READY],
          initialized: state[PRIVATE.INITIALIZED],
          extensionId: state[PRIVATE.EXTENSION_ID],
          hasBookmarks: !!chrome.bookmarks,
          timestamp: Date.now()
        });
        return;
      }

      if (action === 'isReady') {
        resolve(STATE[PRIVATE.IS_READY]);
        return;
      }

      if (!chrome.bookmarks) {
        reject(new Error('chrome.bookmarks не доступен'));
        return;
      }

      Background[PRIVATE.CALL_BOOKMARKS_API](action, args)
        .then(resolve)
        .catch(reject);
    });
  };

  // ============================================================
  // 8.5. ВЫЗОВ CHROME.BOOKMARKS API ★★★ ИСПРАВЛЕН ★★★
  // ============================================================

  Background[PRIVATE.CALL_BOOKMARKS_API] = function(method, args) {
    var log = logger;

    return new Promise(function(resolve, reject) {
      var methodMap = {
        'getAll': 'getTree',
        'getSubTree': 'getSubTree',
        'getChildren': 'getChildren',
        'getByIds': 'get',
        'search': 'search',
        'getRecent': 'getRecent',
        'getRootFolders': 'getTree',
        'create': 'create',
        'update': 'update',
        'move': 'move',
        'remove': 'remove',
        'removeTree': 'removeTree',
        'existsByUrl': 'search',
        'getStats': 'getTree'
      };

      var bookmarkMethod = methodMap[method] || method;

      if (!chrome.bookmarks[bookmarkMethod]) {
        reject(new Error('Метод ' + bookmarkMethod + ' не найден в chrome.bookmarks'));
        return;
      }

      // ★★★ СПЕЦИАЛЬНАЯ ОБРАБОТКА ДЛЯ create ★★★
      var callArgs = args;
      if (method === 'create') {
        // args = [parentId, title, url] → преобразуем в объект
        var createData = {
          parentId: args[0] || '1',
          title: args[1] || 'Без названия'
        };
        if (args[2]) {
          createData.url = args[2];
        }
        callArgs = [createData];
      }

      log.debug('📤 Вызов chrome.bookmarks.' + bookmarkMethod, callArgs);

      chrome.bookmarks[bookmarkMethod](...callArgs, function(result) {
        if (chrome.runtime.lastError) {
          log.error('❌ Ошибка chrome.bookmarks.' + bookmarkMethod + ':', chrome.runtime.lastError);
          reject(new Error(chrome.runtime.lastError.message));
          return;
        }

        var processedResult = result;

        if (method === 'getStats') {
          if (result && result[0]) {
            processedResult = Background[PRIVATE.COUNT_NODES](result[0]);
          } else {
            processedResult = { totalBookmarks: 0, totalFolders: 0, totalNodes: 0 };
          }
        }

        if (method === 'existsByUrl') {
          var url = args[0];
          var found = false;
          for (var i = 0; i < result.length; i++) {
            if (result[i].url === url) {
              found = true;
              break;
            }
          }
          processedResult = found;
        }

        log.debug('✅ chrome.bookmarks.' + bookmarkMethod + ' выполнен');
        resolve(processedResult);
      });
    });
  };

  // ============================================================
  // 8.6. ПОДСЧЁТ УЗЛОВ
  // ============================================================

  Background[PRIVATE.COUNT_NODES] = function(node) {
    var bookmarks = 0;
    var folders = 0;

    if (node.url) {
      bookmarks = bookmarks + 1;
    } else {
      folders = folders + 1;
    }

    if (node.children) {
      for (var i = 0; i < node.children.length; i++) {
        var child = node.children[i];
        var counts = Background[PRIVATE.COUNT_NODES](child);
        bookmarks = bookmarks + counts.bookmarks;
        folders = folders + counts.folders;
      }
    }

    return {
      totalBookmarks: bookmarks,
      totalFolders: folders,
      totalNodes: bookmarks + folders
    };
  };

  // ============================================================
  // 8.7. ОТПРАВКА ОТВЕТОВ
  // ============================================================

  Background[PRIVATE.SEND_RESPONSE] = function(sendResponse, success, data) {
    try {
      sendResponse({
        success: success,
        data: data,
        timestamp: Date.now()
      });
    } catch (error) {
      logger.error('❌ Ошибка отправки ответа:', error);
    }
  };

  Background[PRIVATE.SEND_ERROR] = function(sendResponse, error) {
    try {
      sendResponse({
        success: false,
        error: error.message || String(error),
        timestamp: Date.now()
      });
    } catch (err) {
      logger.error('❌ Ошибка отправки ошибки:', err);
    }
  };

  // ============================================================
  // 8.8. ПОЛУЧЕНИЕ СОСТОЯНИЯ
  // ============================================================

  Background[PRIVATE.GET_STATE] = function() {
    var state = STATE;
    return {
      initialized: state[PRIVATE.INITIALIZED],
      destroyed: state[PRIVATE.DESTROYED],
      isReady: state[PRIVATE.IS_READY],
      startTime: state[PRIVATE.START_TIME],
      requestCount: state[PRIVATE.REQUEST_COUNT],
      extensionId: state[PRIVATE.EXTENSION_ID],
      manifest: state[PRIVATE.MANIFEST],
      version: CONFIG.version,
      build: CONFIG.build
    };
  };

  // ============================================================
  // 8.9. ЭКСПОРТ СИМВОЛОВ
  // ============================================================

  Background[PRIVATE.EXPORT_SYMBOLS] = function() {
    try {
      if (typeof self !== 'undefined') {
        self.__BACKGROUND_SYMBOLS = {
          PRIVATE: PRIVATE,
          PUBLIC: PUBLIC,
          CONFIG: CONFIG
        };

        self.__BACKGROUND_SYMBOLS_INFO = {
          privateCount: Object.keys(PRIVATE).length,
          publicCount: Object.keys(PUBLIC).length,
          totalCount: Object.keys(PRIVATE).length + Object.keys(PUBLIC).length,
          version: CONFIG.version,
          build: CONFIG.build
        };

        self[PUBLIC.INSTANCE] = Background;

        // ============================================================
        // ★★★ ГЛОБАЛЬНЫЕ ФУНКЦИИ ДЛЯ КОНСОЛИ ★★★
        // ============================================================

        self.getBackgroundState = function() {
          return Background[PRIVATE.GET_STATE]();
        };

        self.getBackgroundStats = function() {
          var state = STATE;
          return {
            requestCount: state[PRIVATE.REQUEST_COUNT],
            uptime: state[PRIVATE.START_TIME] ? Date.now() - state[PRIVATE.START_TIME] : 0,
            isReady: state[PRIVATE.IS_READY] && !state[PRIVATE.DESTROYED],
            extensionId: state[PRIVATE.EXTENSION_ID]
          };
        };

        self.getBackgroundInfo = function() {
          var state = STATE;
          return {
            name: CONFIG.name,
            version: CONFIG.version,
            extensionId: state[PRIVATE.EXTENSION_ID],
            isReady: state[PRIVATE.IS_READY],
            initialized: state[PRIVATE.INITIALIZED]
          };
        };

        self.isBackgroundReady = function() {
          return STATE[PRIVATE.IS_READY] && !STATE[PRIVATE.DESTROYED];
        };

        self.getBackgroundMethods = function() {
          return {
            getState: self.getBackgroundState,
            getStats: self.getBackgroundStats,
            getInfo: self.getBackgroundInfo,
            isReady: self.isBackgroundReady,
            destroy: function() {
              return Background[PRIVATE.DESTROY]();
            }
          };
        };

        console.log('✅ Глобальные функции зарегистрированы:');
        console.log('  📋 getBackgroundState()  - состояние');
        console.log('  📋 getBackgroundStats()   - статистика');
        console.log('  📋 getBackgroundInfo()    - информация');
        console.log('  📋 isBackgroundReady()    - готовность');
        console.log('  📋 getBackgroundMethods() - все методы');
      }
    } catch (error) {
      logger.error('❌ Ошибка экспорта символов:', error);
    }
  };

  // ============================================================
  // 8.10. УНИЧТОЖЕНИЕ
  // ============================================================

  Background[PRIVATE.DESTROY] = function() {
    var state = STATE;
    var log = logger;

    if (state[PRIVATE.DESTROYED]) {
      log.warn('⚠️ Background уже уничтожен');
      return;
    }

    log.info('🧹 Уничтожение Background...');

    state[PRIVATE.REQUEST_MAP].clear();
    state[PRIVATE.DESTROYED] = true;
    state[PRIVATE.INITIALIZED] = false;
    state[PRIVATE.IS_READY] = false;

    try {
      if (typeof self !== 'undefined') {
        delete self.__BACKGROUND_SYMBOLS;
        delete self[PUBLIC.INSTANCE];
        delete self.getBackgroundState;
        delete self.getBackgroundStats;
        delete self.getBackgroundInfo;
        delete self.isBackgroundReady;
        delete self.getBackgroundMethods;
      }
    } catch (error) {}

    log.success('✅ Background уничтожен');
  };

  // ============================================================
  // 8.11. ПУБЛИЧНЫЕ МЕТОДЫ
  // ============================================================

  Background[PUBLIC.GET_STATE] = function() {
    return Background[PRIVATE.GET_STATE]();
  };

  Background[PUBLIC.GET_STATS] = function() {
    var state = STATE;
    return {
      requestCount: state[PRIVATE.REQUEST_COUNT],
      uptime: state[PRIVATE.START_TIME] ? Date.now() - state[PRIVATE.START_TIME] : 0,
      isReady: state[PRIVATE.IS_READY] && !state[PRIVATE.DESTROYED],
      extensionId: state[PRIVATE.EXTENSION_ID]
    };
  };

  Background[PUBLIC.GET_INFO] = function() {
    var state = STATE;
    return {
      name: CONFIG.name,
      version: CONFIG.version,
      extensionId: state[PRIVATE.EXTENSION_ID],
      isReady: state[PRIVATE.IS_READY],
      initialized: state[PRIVATE.INITIALIZED]
    };
  };

  Background[PUBLIC.IS_READY] = function() {
    return STATE[PRIVATE.IS_READY] && !STATE[PRIVATE.DESTROYED];
  };

  Background[PUBLIC.INIT] = function() {
    return Background[PRIVATE.INIT]();
  };

  Background[PUBLIC.DESTROY] = function() {
    return Background[PRIVATE.DESTROY]();
  };

  // ============================================================
  // 9. ЗАПУСК
  // ============================================================

  try {
    var success = Background[PRIVATE.INIT]();
    if (success !== false) {
      console.log('✅ Background успешно загружен (100% символы)');
    }
  } catch (error) {
    console.error('❌ Ошибка инициализации Background:', error);
  }

  // ============================================================
  // 10. КОНСОЛЬНЫЙ ИНТЕРФЕЙС
  // ============================================================

  if (typeof self !== 'undefined') {
    var privateCount = Object.keys(PRIVATE).length;
    var publicCount = Object.keys(PUBLIC).length;

    console.log('╔═══════════════════════════════════════════════════════════════════════════════╗');
    console.log('║              📦 BACKGROUND SERVICE WORKER (100% СИМВОЛЫ) v3.0.3              ║');
    console.log('╠═══════════════════════════════════════════════════════════════════════════════╣');
    console.log('║  📋 Обработка запросов от Content Script → chrome.bookmarks API              ║');
    console.log('║  🔑 Полная изоляция через приватные символы                                 ║');
    console.log('║  🔓 Публичные символы через Symbol.for                                      ║');
    console.log('║  📨 Поддерживаемые методы: getAll, getStats, search, create, remove и др.  ║');
    console.log('║  🛡️ Валидация всех запросов и аргументов                                    ║');
    console.log('║  📊 Статистика запросов и состояния                                         ║');
    console.log('║  ✅ ИСПРАВЛЕНА ОШИБКА bookmarks.create (сигнатура)                          ║');
    console.log('║  ✅ Правильный вызов: create({parentId, title, url}, callback)              ║');
    console.log('╚═══════════════════════════════════════════════════════════════════════════════╝');

    console.log('📊 СТАТИСТИКА СИМВОЛОВ:');
    console.log('  🔑 Приватных символов: ' + privateCount);
    console.log('  🔓 Публичных символов: ' + publicCount);
    console.log('  📦 Всего символов: ' + (privateCount + publicCount));
    console.log('');

    console.log('📋 ДОСТУПНЫЕ КОМАНДЫ:');
    console.log('  getBackgroundState()  - состояние');
    console.log('  getBackgroundStats()   - статистика');
    console.log('  getBackgroundInfo()    - информация');
    console.log('  isBackgroundReady()    - готовность');
    console.log('  getBackgroundMethods() - все методы');
    console.log('  self.__BACKGROUND_SYMBOLS - все символы');
    console.log('');

    console.log('✅ Background загружен (100% символы)');
  }

})();