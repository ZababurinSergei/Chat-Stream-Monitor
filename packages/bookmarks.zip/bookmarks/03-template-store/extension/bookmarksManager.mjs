// ============================================================
// bookmarksManager.mjs
// 100% СИМВОЛЫ — полная изоляция и безопасность
// Абсолютно полный менеджер закладок Chrome
// Версия: 2.0.0 — Расширенная поддержка API
// ============================================================

// ============================================================
// 1. ПРИВАТНЫЕ СИМВОЛЫ (100% изоляция)
// ============================================================

const PRIVATE = {
  // Основные символы
  VERSION: Symbol('bookmarks.manager.version'),
  BUILD: Symbol('bookmarks.manager.build'),
  NAME: Symbol('bookmarks.manager.name'),
  CONFIG: Symbol('bookmarks.manager.config'),
  STATE: Symbol('bookmarks.manager.state'),
  INITIALIZED: Symbol('bookmarks.manager.initialized'),
  IS_DESTROYED: Symbol('bookmarks.manager.isDestroyed'),
  INSTANCE: Symbol('bookmarks.manager.instance'),

  // Данные
  CACHE: Symbol('bookmarks.manager.cache'),
  STATS: Symbol('bookmarks.manager.stats'),
  SUBSCRIPTIONS: Symbol('bookmarks.manager.subscriptions'),

  // Безопасность
  VALIDATE: Symbol('bookmarks.manager.validate'),
  SANITIZE: Symbol('bookmarks.manager.sanitize'),
  SECURE: Symbol('bookmarks.manager.secure'),
  ESCAPE: Symbol('bookmarks.manager.escape'),

  // Методы
  INIT: Symbol('bookmarks.manager.init'),
  DESTROY: Symbol('bookmarks.manager.destroy'),
  NOTIFY: Symbol('bookmarks.manager.notify'),
  GET_STATE: Symbol('bookmarks.manager.getState'),
  SET_STATE: Symbol('bookmarks.manager.setState'),
  UPDATE_STATS: Symbol('bookmarks.manager.updateStats'),
  EXPORT_SYMBOLS: Symbol('bookmarks.manager.exportSymbols'),

  // Внутренние методы
  NODE_TO_HTML: Symbol('bookmarks.manager.nodeToHTML'),
  PARSE_HTML_DL: Symbol('bookmarks.manager.parseHtmlDl'),
  RECURSIVE_IMPORT: Symbol('bookmarks.manager.recursiveImport'),
  DOWNLOAD_FILE: Symbol('bookmarks.manager.downloadFile'),
  DELAY: Symbol('bookmarks.manager.delay'),
  ESCAPE_HTML: Symbol('bookmarks.manager.escapeHtml'),
  GET_ROOT_NODES: Symbol('bookmarks.manager.getRootNodes'),
  COUNT_NODES: Symbol('bookmarks.manager.countNodes'),
  FIND_DUPLICATES: Symbol('bookmarks.manager.findDuplicates'),
  GENERATE_HTML: Symbol('bookmarks.manager.generateHTML'),

  // API методы
  API_GET_ALL: Symbol('bookmarks.manager.api.getAll'),
  API_GET_SUB_TREE: Symbol('bookmarks.manager.api.getSubTree'),
  API_GET_CHILDREN: Symbol('bookmarks.manager.api.getChildren'),
  API_GET_BY_IDS: Symbol('bookmarks.manager.api.getByIds'),
  API_SEARCH: Symbol('bookmarks.manager.api.search'),
  API_GET_RECENT: Symbol('bookmarks.manager.api.getRecent'),
  API_GET_ROOT_FOLDERS: Symbol('bookmarks.manager.api.getRootFolders'),
  API_GET_STATS: Symbol('bookmarks.manager.api.getStats'),
  API_CREATE: Symbol('bookmarks.manager.api.create'),
  API_UPDATE: Symbol('bookmarks.manager.api.update'),
  API_MOVE: Symbol('bookmarks.manager.api.move'),
  API_REMOVE: Symbol('bookmarks.manager.api.remove'),
  API_REMOVE_TREE: Symbol('bookmarks.manager.api.removeTree'),
  API_EXPORT_JSON: Symbol('bookmarks.manager.api.exportJSON'),
  API_EXPORT_HTML: Symbol('bookmarks.manager.api.exportHTML'),
  API_IMPORT_JSON: Symbol('bookmarks.manager.api.importJSON'),
  API_IMPORT_HTML: Symbol('bookmarks.manager.api.importHTML'),
  API_EXISTS_BY_URL: Symbol('bookmarks.manager.api.existsByUrl'),
  API_REMOVE_DUPLICATES: Symbol('bookmarks.manager.api.removeDuplicates'),
  API_GET_INFO: Symbol('bookmarks.manager.api.getInfo'),
  API_IS_READY: Symbol('bookmarks.manager.api.isReady'),
  API_SUBSCRIBE: Symbol('bookmarks.manager.api.subscribe'),
  API_UNSUBSCRIBE: Symbol('bookmarks.manager.api.unsubscribe'),

  // События
  ON_CREATED: Symbol('bookmarks.manager.onCreated'),
  ON_REMOVED: Symbol('bookmarks.manager.onRemoved'),
  ON_CHANGED: Symbol('bookmarks.manager.onChanged'),
  ON_MOVED: Symbol('bookmarks.manager.onMoved'),
  ON_CHILDREN_REORDERED: Symbol('bookmarks.manager.onChildrenReordered'),
  ON_IMPORT_BEGAN: Symbol('bookmarks.manager.onImportBegan'),
  ON_IMPORT_ENDED: Symbol('bookmarks.manager.onImportEnded'),

  // Логгер
  LOGGER: Symbol('bookmarks.manager.logger'),
  LOG: Symbol('bookmarks.manager.log'),
  DEBUG: Symbol('bookmarks.manager.debug'),
};

// ============================================================
// 2. ПУБЛИЧНЫЕ СИМВОЛЫ (доступны через Symbol.for)
// ============================================================

const PUBLIC = {
  INSTANCE: Symbol.for('bookmarks.manager.instance'),
  STATE: Symbol.for('bookmarks.manager.state'),
  CONFIG: Symbol.for('bookmarks.manager.config'),
  VERSION: Symbol.for('bookmarks.manager.version'),
  API: Symbol.for('bookmarks.manager.api'),
  GET_ALL: Symbol.for('bookmarks.manager.getAll'),
  SEARCH: Symbol.for('bookmarks.manager.search'),
  CREATE: Symbol.for('bookmarks.manager.create'),
  UPDATE: Symbol.for('bookmarks.manager.update'),
  REMOVE: Symbol.for('bookmarks.manager.remove'),
  GET_STATS: Symbol.for('bookmarks.manager.getStats'),
  EXPORT: Symbol.for('bookmarks.manager.export'),
  IMPORT: Symbol.for('bookmarks.manager.import'),
  SUBSCRIBE: Symbol.for('bookmarks.manager.subscribe'),
  UNSUBSCRIBE: Symbol.for('bookmarks.manager.unsubscribe'),
  HEALTH_CHECK: Symbol.for('bookmarks.manager.healthCheck'),
  DESTROY: Symbol.for('bookmarks.manager.destroy'),
};

// ============================================================
// 3. КОНФИГУРАЦИЯ
// ============================================================

const CONFIG = {
  version: '2.0.0',
  build: '2026-07-23',
  name: 'Bookmarks Manager',
  debug: true,
  apiVersion: '2.0.0',
  maxCacheSize: 100,
  cacheTTL: 3600000, // 1 час
  maxImportSize: 10 * 1024 * 1024, // 10MB
  delayBetweenOperations: 30, // ms
};

// ============================================================
// 4. ЛОГГЕР (100% символы)
// ============================================================

const LOGGER_SYMBOLS = {
  HISTORY: Symbol('logger.history'),
  MAX_HISTORY: Symbol('logger.maxHistory'),
  DEBUG: Symbol('logger.debug'),
  INSTANCE_ID: Symbol('logger.instanceId'),
  LEVEL: Symbol('logger.level'),
};

function createLogger(debug = true, instanceId = 'BookmarksManager') {
  const state = {
    [LOGGER_SYMBOLS.HISTORY]: [],
    [LOGGER_SYMBOLS.MAX_HISTORY]: 200,
    [LOGGER_SYMBOLS.DEBUG]: debug,
    [LOGGER_SYMBOLS.INSTANCE_ID]: instanceId,
    [LOGGER_SYMBOLS.LEVEL]: debug ? 3 : 2,
  };

  const logMethod = function (level, message, data = null) {
    const levels = { error: 0, warn: 1, info: 2, debug: 3, success: 2 };
    const currentLevel = this[LOGGER_SYMBOLS.LEVEL] || 2;
    const msgLevel = levels[level] || 2;

    if (msgLevel > currentLevel) return;

    const timestamp = new Date().toISOString().slice(11, 23);
    const prefix = `[${timestamp}] [${this[LOGGER_SYMBOLS.INSTANCE_ID]}]`;

    this[LOGGER_SYMBOLS.HISTORY].push({
      timestamp,
      level,
      message,
      data,
      id: Date.now() + Math.random(),
    });

    if (this[LOGGER_SYMBOLS.HISTORY].length > this[LOGGER_SYMBOLS.MAX_HISTORY]) {
      this[LOGGER_SYMBOLS.HISTORY].shift();
    }

    const icons = { error: '❌', warn: '⚠️', info: 'ℹ️', debug: '🔍', success: '✅' };
    const icon = icons[level] || '📌';

    if (data !== null && data !== undefined) {
      console.log(`${icon} ${prefix} ${message}`, data);
    } else {
      console.log(`${icon} ${prefix} ${message}`);
    }
  };

  const boundLog = logMethod.bind(state);

  const methods = {
    error: (msg, d) => boundLog('error', msg, d),
    warn: (msg, d) => boundLog('warn', msg, d),
    info: (msg, d) => boundLog('info', msg, d),
    debug: (msg, d) => boundLog('debug', msg, d),
    success: (msg, d) => boundLog('success', msg, d),

    header: (title, color = '#636e72') => {
      console.log('%c' + '═'.repeat(70), `color: ${color};`);
      console.log(
        '%c  📚 ' + title,
        'background: #1a1a2e; color: #fff; padding: 4px 12px; border-radius: 4px; font-weight: bold;'
      );
      console.log('%c' + '═'.repeat(70), `color: ${color};`);
    },

    separator: (color = '#636e72') => {
      console.log('%c' + '─'.repeat(70), `color: ${color};`);
    },

    getHistory: function () {
      return [...this[LOGGER_SYMBOLS.HISTORY]];
    },

    clearHistory: function () {
      this[LOGGER_SYMBOLS.HISTORY] = [];
      return this;
    },

    setDebug: function (enabled) {
      this[LOGGER_SYMBOLS.DEBUG] = enabled;
      this[LOGGER_SYMBOLS.LEVEL] = enabled ? 3 : 2;
      return this;
    },
  };

  const logger = {};
  for (const [key, fn] of Object.entries(methods)) {
    logger[key] = fn.bind(state);
  }

  logger[LOGGER_SYMBOLS.HISTORY] = state[LOGGER_SYMBOLS.HISTORY];
  logger[LOGGER_SYMBOLS.MAX_HISTORY] = state[LOGGER_SYMBOLS.MAX_HISTORY];
  logger[LOGGER_SYMBOLS.DEBUG] = state[LOGGER_SYMBOLS.DEBUG];
  logger[LOGGER_SYMBOLS.INSTANCE_ID] = state[LOGGER_SYMBOLS.INSTANCE_ID];
  logger[LOGGER_SYMBOLS.LEVEL] = state[LOGGER_SYMBOLS.LEVEL];

  return logger;
}

// ============================================================
// 5. ВАЛИДАТОР (100% символы)
// ============================================================

const VALIDATOR = {
  [PRIVATE.VALIDATE]: {
    isValidId: (id) => {
      return typeof id === 'string' && id.length > 0;
    },

    isValidTitle: (title) => {
      return typeof title === 'string' && title.length > 0 && title.length <= 1000;
    },

    isValidUrl: (url) => {
      if (!url) return true;
      try {
        new URL(url);
        return true;
      } catch {
        return false;
      }
    },

    isValidChanges: (changes) => {
      if (!changes || typeof changes !== 'object') return false;
      if (changes.title && !VALIDATOR[PRIVATE.VALIDATE].isValidTitle(changes.title)) return false;
      if (changes.url && !VALIDATOR[PRIVATE.VALIDATE].isValidUrl(changes.url)) return false;
      return true;
    },

    isValidQuery: (query) => {
      return typeof query === 'string' && query.length > 0;
    },

    isValidIndex: (index) => {
      return index === null || (typeof index === 'number' && index >= 0);
    },

    isValidFile: (file) => {
      if (!file || typeof file !== 'object') return false;
      if (!file.text || typeof file.text !== 'function') return false;
      if (file.size > CONFIG.maxImportSize) return false;
      return true;
    },

    isValidJSON: (json) => {
      try {
        JSON.parse(json);
        return true;
      } catch {
        return false;
      }
    },

    isValidHTML: (html) => {
      return typeof html === 'string' && html.includes('<DL>');
    },

    isValidCallback: (callback) => {
      return typeof callback === 'function';
    },
  },

  [PRIVATE.SANITIZE]: {
    sanitizeTitle: (title) => {
      if (!title) return 'Без названия';
      return String(title).substring(0, 1000).trim() || 'Без названия';
    },

    sanitizeUrl: (url) => {
      if (!url) return null;
      try {
        const parsed = new URL(url);
        return parsed.toString();
      } catch {
        return null;
      }
    },

    sanitizeId: (id) => {
      return String(id).trim();
    },

    sanitizeChanges: (changes) => {
      const sanitized = {};
      if (changes.title !== undefined) {
        sanitized.title = VALIDATOR[PRIVATE.SANITIZE].sanitizeTitle(changes.title);
      }
      if (changes.url !== undefined) {
        const url = VALIDATOR[PRIVATE.SANITIZE].sanitizeUrl(changes.url);
        if (url) sanitized.url = url;
      }
      return sanitized;
    },
  },

  [PRIVATE.SECURE]: {
    isSafeObject: (obj) => {
      if (!obj || typeof obj !== 'object') return false;
      try {
        if (obj.constructor && obj.constructor.name !== 'Object') return false;
        if (Object.getPrototypeOf(obj) !== Object.prototype && Object.getPrototypeOf(obj) !== null)
          return false;
        return true;
      } catch {
        return false;
      }
    },

    isSafeString: (str) => {
      if (typeof str !== 'string') return false;
      const dangerous = ['<script', 'javascript:', 'onerror=', 'onload=', 'onclick='];
      for (const pattern of dangerous) {
        if (str.toLowerCase().includes(pattern)) return false;
      }
      return true;
    },
  },

  [PRIVATE.ESCAPE]: {
    escapeHtml: (str) => {
      if (!str) return '';
      return String(str)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');
    },

    escapeJs: (str) => {
      if (!str) return '';
      return String(str)
        .replace(/\\/g, '\\\\')
        .replace(/"/g, '\\"')
        .replace(/\n/g, '\\n')
        .replace(/\r/g, '\\r')
        .replace(/\t/g, '\\t');
    },
  },
};

// ============================================================
// 6. ОСНОВНОЙ КЛАСС (100% символы)
// ============================================================

export class BookmarksManager {
  constructor() {
    // Приватное состояние через WeakMap
    const _private = new WeakMap();

    const privateData = {
      [PRIVATE.VERSION]: CONFIG.version,
      [PRIVATE.BUILD]: CONFIG.build,
      [PRIVATE.NAME]: CONFIG.name,
      [PRIVATE.CONFIG]: { ...CONFIG },
      [PRIVATE.STATE]: {
        initialized: false,
        destroyed: false,
        ready: false,
      },
      [PRIVATE.CACHE]: new Map(),
      [PRIVATE.STATS]: {
        totalBookmarks: 0,
        totalFolders: 0,
        totalNodes: 0,
        operationsCount: 0,
        cacheHits: 0,
        cacheMisses: 0,
        lastUpdate: null,
      },
      [PRIVATE.SUBSCRIPTIONS]: new Map(),
      [PRIVATE.INITIALIZED]: false,
      [PRIVATE.IS_DESTROYED]: false,
    };

    _private.set(this, privateData);
    this._private = _private;

    // Создаем логгер
    this._logger = createLogger(CONFIG.debug, CONFIG.name);

    // Инициализация
    this[PRIVATE.INIT]();
  }

  // ============================================================
  // 7. ГЕТТЕРЫ ДЛЯ ПРИВАТНЫХ ДАННЫХ
  // ============================================================

  get [PRIVATE.STATE]() {
    return this._private.get(this)[PRIVATE.STATE];
  }

  get [PRIVATE.CONFIG]() {
    return this._private.get(this)[PRIVATE.CONFIG];
  }

  get [PRIVATE.CACHE]() {
    return this._private.get(this)[PRIVATE.CACHE];
  }

  get [PRIVATE.STATS]() {
    return this._private.get(this)[PRIVATE.STATS];
  }

  get [PRIVATE.SUBSCRIPTIONS]() {
    return this._private.get(this)[PRIVATE.SUBSCRIPTIONS];
  }

  // ============================================================
  // 8. ИНИЦИАЛИЗАЦИЯ
  // ============================================================

  [PRIVATE.INIT]() {
    const logger = this._logger;
    const privateData = this._private.get(this);

    logger.header('ИНИЦИАЛИЗАЦИЯ BOOKMARKS MANAGER (100% СИМВОЛЫ)');
    logger.info(`📦 Версия: ${CONFIG.version}`);
    logger.info(`📅 Сборка: ${CONFIG.build}`);
    logger.info(`📌 Отладка: ${CONFIG.debug ? '✅' : '❌'}`);
    logger.separator();
    logger.info(`🔑 Приватных символов: ${Object.keys(PRIVATE).length}`);
    logger.info(`🔓 Публичных символов: ${Object.keys(PUBLIC).length}`);
    logger.separator();

    // Проверка окружения
    this[PRIVATE.SECURE_CHECK]();

    // Экспорт символов
    this[PRIVATE.EXPORT_SYMBOLS]();

    privateData[PRIVATE.INITIALIZED] = true;
    privateData[PRIVATE.STATE].initialized = true;
    privateData[PRIVATE.STATE].ready = true;

    logger.success('✅ Bookmarks Manager инициализирован');
    logger.header('ГОТОВ');
  }

  [PRIVATE.SECURE_CHECK]() {
    const logger = this._logger;

    // Проверка, что Chrome API доступен
    if (typeof chrome === 'undefined' || !chrome.bookmarks) {
      logger.warn('⚠️ Chrome Bookmarks API не доступен');
      return false;
    }

    // Проверка разрешений
    try {
      chrome.bookmarks.getTree(() => {
        if (chrome.runtime.lastError) {
          logger.warn('⚠️ Нет разрешения на доступ к закладкам');
        }
      });
    } catch (error) {
      logger.warn('⚠️ Ошибка проверки разрешений:', error);
      return false;
    }

    return true;
  }

  [PRIVATE.EXPORT_SYMBOLS]() {
    if (typeof window !== 'undefined') {
      window[PUBLIC.INSTANCE] = this;
      window.__bookmarksManager = this;
      window.__bookmarksManagerSymbols = {
        PRIVATE: { ...PRIVATE },
        PUBLIC: { ...PUBLIC },
      };
    }
  }

  // ============================================================
  // 9. ВНУТРЕННИЕ МЕТОДЫ
  // ============================================================

  [PRIVATE.DELAY](ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  [PRIVATE.ESCAPE_HTML](str) {
    return VALIDATOR[PRIVATE.ESCAPE].escapeHtml(str);
  }

  [PRIVATE.COUNT_NODES](node) {
    let bookmarks = 0;
    let folders = 0;

    if (node.url) {
      bookmarks++;
    } else {
      folders++;
    }

    if (node.children) {
      for (const child of node.children) {
        const counts = this[PRIVATE.COUNT_NODES](child);
        bookmarks += counts.bookmarks;
        folders += counts.folders;
      }
    }

    return { bookmarks, folders };
  }

  [PRIVATE.GET_ROOT_NODES](tree) {
    if (tree && tree[0] && tree[0].children) {
      return tree[0].children;
    }
    return [];
  }

  [PRIVATE.FIND_DUPLICATES](nodes, urlMap = new Map(), duplicates = [], path = '') {
    for (const node of nodes) {
      if (node.url) {
        const key = node.url;
        if (urlMap.has(key)) {
          duplicates.push({
            id: node.id,
            title: node.title || 'Без названия',
            url: node.url,
            existing: urlMap.get(key),
            path: path,
          });
        } else {
          urlMap.set(key, { id: node.id, title: node.title || 'Без названия' });
        }
      }

      if (node.children) {
        const newPath = path + '/' + (node.title || '');
        this[PRIVATE.FIND_DUPLICATES](node.children, urlMap, duplicates, newPath);
      }
    }

    return duplicates;
  }

  [PRIVATE.NODE_TO_HTML](node, depth) {
    const indent = '    '.repeat(depth);
    let result = '';
    const date = node.dateAdded ? Math.floor(node.dateAdded / 1000) : '';
    const title = this[PRIVATE.ESCAPE_HTML](node.title || 'Без названия');

    if (node.url) {
      const url = this[PRIVATE.ESCAPE_HTML](node.url);
      result += `${indent}<DT><A HREF="${url}" ADD_DATE="${date}">${title}</A>\n`;
    } else {
      result += `${indent}<DT><H3 ADD_DATE="${date}">${title}</H3>\n`;
      result += `${indent}<DL><p>\n`;
      if (node.children) {
        for (const child of node.children) {
          result += this[PRIVATE.NODE_TO_HTML](child, depth + 1);
        }
      }
      result += `${indent}</DL><p>\n`;
    }

    return result;
  }

  [PRIVATE.GENERATE_HTML](tree) {
    let html = `<!DOCTYPE NETSCAPE-Bookmark-file-1>
<!-- This is an automatically generated file. -->
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">
<TITLE>Bookmarks</TITLE>
<H1>Bookmarks</H1>
<DL><p>
`;

    const rootNodes = this[PRIVATE.GET_ROOT_NODES](tree);
    for (const node of rootNodes) {
      html += this[PRIVATE.NODE_TO_HTML](node, 1);
    }

    html += `</DL><p>\n`;
    return html;
  }

  [PRIVATE.DOWNLOAD_FILE](content, mimeType, filename) {
    const blob = new Blob([content], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  }

  [PRIVATE.PARSE_HTML_DL](dlElement, parentId) {
    const dtElements = Array.from(dlElement.children).filter((el) => el.tagName === 'DT');

    for (const dt of dtElements) {
      const h3 = dt.querySelector(':scope > h3');
      const a = dt.querySelector(':scope > a');

      if (a) {
        const title = a.textContent || 'Без названия';
        const url = a.href || '';
        this.create(parentId, title, url);
        this[PRIVATE.DELAY](CONFIG.delayBetweenOperations);
      } else if (h3) {
        const title = h3.textContent || 'Без названия';
        const newFolder = this.create(parentId, title);
        this[PRIVATE.DELAY](CONFIG.delayBetweenOperations);
        const subDl = dt.querySelector('dl');
        if (subDl) {
          this[PRIVATE.PARSE_HTML_DL](subDl, newFolder.id);
        }
      }
    }
  }

  [PRIVATE.RECURSIVE_IMPORT](node, parentId) {
    const isSystemFolder =
      ['1', '2', '3', 'root________'].includes(node.id) ||
      [
        'панель закладок',
        'другие закладки',
        'bookmarks bar',
        'other bookmarks',
        'mobile bookmarks',
      ].includes(node.title?.toLowerCase());

    let currentParentId = parentId;

    if (!isSystemFolder && node.title && node.title.length > 0) {
      const created = this.create(parentId, node.title, node.url);
      currentParentId = created.id;
      this[PRIVATE.DELAY](CONFIG.delayBetweenOperations);
    }

    if (node.children && node.children.length > 0) {
      for (const child of node.children) {
        this[PRIVATE.RECURSIVE_IMPORT](child, currentParentId);
      }
    }
  }

  [PRIVATE.NOTIFY](event, data) {
    const subscriptions = this[PRIVATE.SUBSCRIPTIONS];
    for (const [id, sub] of subscriptions) {
      if (sub.event === event || sub.event === '*') {
        try {
          sub.callback(data);
        } catch (error) {
          this._logger.error(`Ошибка в подписке ${id}:`, error);
        }
      }
    }
  }

  [PRIVATE.UPDATE_STATS]() {
    const logger = this._logger;
    try {
      chrome.bookmarks.getTree((tree) => {
        if (chrome.runtime.lastError) {
          logger.error('Ошибка получения дерева для статистики:', chrome.runtime.lastError);
          return;
        }

        const rootNodes = this[PRIVATE.GET_ROOT_NODES](tree);
        let totalBookmarks = 0;
        let totalFolders = 0;

        for (const node of rootNodes) {
          const counts = this[PRIVATE.COUNT_NODES](node);
          totalBookmarks += counts.bookmarks;
          totalFolders += counts.folders;
        }

        const stats = this[PRIVATE.STATS];
        stats.totalBookmarks = totalBookmarks;
        stats.totalFolders = totalFolders;
        stats.totalNodes = totalBookmarks + totalFolders;
        stats.lastUpdate = Date.now();
        stats.operationsCount++;

        // Сохраняем в storage
        if (typeof chrome !== 'undefined' && chrome.storage) {
          try {
            chrome.storage.local.set({
              bookmarkStats: {
                totalBookmarks,
                totalFolders,
                totalNodes: totalBookmarks + totalFolders,
                lastUpdate: Date.now(),
              },
            });
          } catch (error) {
            logger.debug('Не удалось сохранить статистику в storage:', error);
          }
        }

        logger.debug(`📊 Статистика обновлена: ${totalBookmarks} закладок, ${totalFolders} папок`);
      });
    } catch (error) {
      logger.error('Ошибка обновления статистики:', error);
    }
  }

  // ============================================================
  // 10. ПУБЛИЧНЫЕ МЕТОДЫ (CRUD)
  // ============================================================

  /** Получить всё дерево закладок */
  [PRIVATE.API_GET_ALL]() {
    return new Promise((resolve, reject) => {
      try {
        chrome.bookmarks.getTree((tree) => {
          if (chrome.runtime.lastError) {
            reject(new Error(chrome.runtime.lastError.message));
          } else {
            resolve(tree);
          }
        });
      } catch (error) {
        reject(error);
      }
    });
  }

  /** Получить поддерево */
  [PRIVATE.API_GET_SUB_TREE](folderId) {
    return new Promise((resolve, reject) => {
      try {
        if (!VALIDATOR[PRIVATE.VALIDATE].isValidId(folderId)) {
          reject(new Error('Некорректный ID папки'));
          return;
        }
        chrome.bookmarks.getSubTree(folderId, (result) => {
          if (chrome.runtime.lastError) {
            reject(new Error(chrome.runtime.lastError.message));
          } else {
            resolve(result);
          }
        });
      } catch (error) {
        reject(error);
      }
    });
  }

  /** Получить детей папки */
  [PRIVATE.API_GET_CHILDREN](folderId) {
    return new Promise((resolve, reject) => {
      try {
        if (!VALIDATOR[PRIVATE.VALIDATE].isValidId(folderId)) {
          reject(new Error('Некорректный ID папки'));
          return;
        }
        chrome.bookmarks.getChildren(folderId, (result) => {
          if (chrome.runtime.lastError) {
            reject(new Error(chrome.runtime.lastError.message));
          } else {
            resolve(result);
          }
        });
      } catch (error) {
        reject(error);
      }
    });
  }

  /** Получить по ID */
  [PRIVATE.API_GET_BY_IDS](ids) {
    return new Promise((resolve, reject) => {
      try {
        const idArray = Array.isArray(ids) ? ids : [ids];
        for (const id of idArray) {
          if (!VALIDATOR[PRIVATE.VALIDATE].isValidId(id)) {
            reject(new Error(`Некорректный ID: ${id}`));
            return;
          }
        }
        chrome.bookmarks.get(idArray, (result) => {
          if (chrome.runtime.lastError) {
            reject(new Error(chrome.runtime.lastError.message));
          } else {
            resolve(result);
          }
        });
      } catch (error) {
        reject(error);
      }
    });
  }

  /** Поиск закладок */
  [PRIVATE.API_SEARCH](query) {
    return new Promise((resolve, reject) => {
      try {
        if (!VALIDATOR[PRIVATE.VALIDATE].isValidQuery(query)) {
          reject(new Error('Некорректный запрос'));
          return;
        }
        chrome.bookmarks.search(query, (result) => {
          if (chrome.runtime.lastError) {
            reject(new Error(chrome.runtime.lastError.message));
          } else {
            resolve(result);
          }
        });
      } catch (error) {
        reject(error);
      }
    });
  }

  /** Получить последние закладки */
  [PRIVATE.API_GET_RECENT](count = 10) {
    return new Promise((resolve, reject) => {
      try {
        const num = Math.min(Math.max(1, count), 100);
        chrome.bookmarks.getRecent(num, (result) => {
          if (chrome.runtime.lastError) {
            reject(new Error(chrome.runtime.lastError.message));
          } else {
            resolve(result);
          }
        });
      } catch (error) {
        reject(error);
      }
    });
  }

  /** Получить корневые папки */
  [PRIVATE.API_GET_ROOT_FOLDERS]() {
    return new Promise((resolve, reject) => {
      try {
        chrome.bookmarks.getTree((tree) => {
          if (chrome.runtime.lastError) {
            reject(new Error(chrome.runtime.lastError.message));
          } else {
            resolve(this[PRIVATE.GET_ROOT_NODES](tree));
          }
        });
      } catch (error) {
        reject(error);
      }
    });
  }

  /** Получить статистику */
  [PRIVATE.API_GET_STATS]() {
    return new Promise((resolve) => {
      const stats = this[PRIVATE.STATS];
      resolve({
        totalBookmarks: stats.totalBookmarks,
        totalFolders: stats.totalFolders,
        totalNodes: stats.totalNodes,
        operationsCount: stats.operationsCount,
        cacheHits: stats.cacheHits,
        cacheMisses: stats.cacheMisses,
        lastUpdate: stats.lastUpdate,
        version: CONFIG.version,
        apiVersion: CONFIG.apiVersion,
        timestamp: Date.now(),
      });
    });
  }

  /** Создать закладку или папку */
  [PRIVATE.API_CREATE](parentId, title, url = null, index = null) {
    return new Promise((resolve, reject) => {
      try {
        if (!VALIDATOR[PRIVATE.VALIDATE].isValidId(parentId)) {
          reject(new Error('Некорректный ID родительской папки'));
          return;
        }

        const sanitizedTitle = VALIDATOR[PRIVATE.SANITIZE].sanitizeTitle(title);
        if (!VALIDATOR[PRIVATE.VALIDATE].isValidTitle(sanitizedTitle)) {
          reject(new Error('Некорректное название'));
          return;
        }

        const data = { parentId, title: sanitizedTitle };

        if (url !== null && url !== undefined) {
          const sanitizedUrl = VALIDATOR[PRIVATE.SANITIZE].sanitizeUrl(url);
          if (!sanitizedUrl) {
            reject(new Error('Некорректный URL'));
            return;
          }
          data.url = sanitizedUrl;
        }

        if (index !== null && VALIDATOR[PRIVATE.VALIDATE].isValidIndex(index)) {
          data.index = index;
        }

        chrome.bookmarks.create(data, (result) => {
          if (chrome.runtime.lastError) {
            reject(new Error(chrome.runtime.lastError.message));
          } else {
            this[PRIVATE.UPDATE_STATS]();
            this[PRIVATE.NOTIFY]('created', { id: result.id, node: result });
            resolve(result);
          }
        });
      } catch (error) {
        reject(error);
      }
    });
  }

  /** Обновить закладку */
  [PRIVATE.API_UPDATE](id, changes) {
    return new Promise((resolve, reject) => {
      try {
        if (!VALIDATOR[PRIVATE.VALIDATE].isValidId(id)) {
          reject(new Error('Некорректный ID'));
          return;
        }

        const sanitizedChanges = VALIDATOR[PRIVATE.SANITIZE].sanitizeChanges(changes);
        if (!VALIDATOR[PRIVATE.VALIDATE].isValidChanges(sanitizedChanges)) {
          reject(new Error('Некорректные изменения'));
          return;
        }

        chrome.bookmarks.update(id, sanitizedChanges, (result) => {
          if (chrome.runtime.lastError) {
            reject(new Error(chrome.runtime.lastError.message));
          } else {
            this[PRIVATE.UPDATE_STATS]();
            this[PRIVATE.NOTIFY]('changed', { id, changeInfo: sanitizedChanges });
            resolve(result);
          }
        });
      } catch (error) {
        reject(error);
      }
    });
  }

  /** Переместить закладку */
  [PRIVATE.API_MOVE](id, destinationParentId, index = null) {
    return new Promise((resolve, reject) => {
      try {
        if (!VALIDATOR[PRIVATE.VALIDATE].isValidId(id)) {
          reject(new Error('Некорректный ID закладки'));
          return;
        }
        if (!VALIDATOR[PRIVATE.VALIDATE].isValidId(destinationParentId)) {
          reject(new Error('Некорректный ID папки назначения'));
          return;
        }

        const dest = { parentId: destinationParentId };
        if (index !== null && VALIDATOR[PRIVATE.VALIDATE].isValidIndex(index)) {
          dest.index = index;
        }

        chrome.bookmarks.move(id, dest, (result) => {
          if (chrome.runtime.lastError) {
            reject(new Error(chrome.runtime.lastError.message));
          } else {
            this[PRIVATE.UPDATE_STATS]();
            this[PRIVATE.NOTIFY]('moved', { id, moveInfo: dest });
            resolve(result);
          }
        });
      } catch (error) {
        reject(error);
      }
    });
  }

  /** Удалить закладку */
  [PRIVATE.API_REMOVE](id) {
    return new Promise((resolve, reject) => {
      try {
        if (!VALIDATOR[PRIVATE.VALIDATE].isValidId(id)) {
          reject(new Error('Некорректный ID'));
          return;
        }

        chrome.bookmarks.remove(id, () => {
          if (chrome.runtime.lastError) {
            reject(new Error(chrome.runtime.lastError.message));
          } else {
            this[PRIVATE.UPDATE_STATS]();
            this[PRIVATE.NOTIFY]('removed', { id });
            resolve({ success: true, id });
          }
        });
      } catch (error) {
        reject(error);
      }
    });
  }

  /** Удалить папку рекурсивно */
  [PRIVATE.API_REMOVE_TREE](folderId) {
    return new Promise((resolve, reject) => {
      try {
        if (!VALIDATOR[PRIVATE.VALIDATE].isValidId(folderId)) {
          reject(new Error('Некорректный ID папки'));
          return;
        }

        chrome.bookmarks.removeTree(folderId, () => {
          if (chrome.runtime.lastError) {
            reject(new Error(chrome.runtime.lastError.message));
          } else {
            this[PRIVATE.UPDATE_STATS]();
            this[PRIVATE.NOTIFY]('removed', { id: folderId, tree: true });
            resolve({ success: true, id: folderId });
          }
        });
      } catch (error) {
        reject(error);
      }
    });
  }

  // ============================================================
  // 11. ЭКСПОРТ/ИМПОРТ
  // ============================================================

  /** Экспорт в JSON */
  [PRIVATE.API_EXPORT_JSON]() {
    return new Promise((resolve, reject) => {
      try {
        chrome.bookmarks.getTree((tree) => {
          if (chrome.runtime.lastError) {
            reject(new Error(chrome.runtime.lastError.message));
          } else {
            const json = JSON.stringify(tree, null, 2);
            if (typeof window !== 'undefined') {
              this[PRIVATE.DOWNLOAD_FILE](json, 'application/json', 'bookmarks.json');
            }
            resolve(json);
          }
        });
      } catch (error) {
        reject(error);
      }
    });
  }

  /** Экспорт в HTML */
  [PRIVATE.API_EXPORT_HTML]() {
    return new Promise((resolve, reject) => {
      try {
        chrome.bookmarks.getTree((tree) => {
          if (chrome.runtime.lastError) {
            reject(new Error(chrome.runtime.lastError.message));
          } else {
            const html = this[PRIVATE.GENERATE_HTML](tree);
            if (typeof window !== 'undefined') {
              this[PRIVATE.DOWNLOAD_FILE](html, 'text/html', 'bookmarks.html');
            }
            resolve(html);
          }
        });
      } catch (error) {
        reject(error);
      }
    });
  }

  /** Импорт из JSON */
  [PRIVATE.API_IMPORT_JSON](jsonString, targetParentId = '1') {
    return new Promise((resolve, reject) => {
      try {
        if (!VALIDATOR[PRIVATE.VALIDATE].isValidJSON(jsonString)) {
          reject(new Error('Некорректный JSON'));
          return;
        }

        const parsedData = JSON.parse(jsonString);
        const rootNodes = Array.isArray(parsedData) ? parsedData : [parsedData];
        const nodesToImport =
          rootNodes[0] && rootNodes[0].id === '0' ? rootNodes[0].children : rootNodes;

        const results = [];
        for (const node of nodesToImport) {
          const result = this[PRIVATE.RECURSIVE_IMPORT](node, targetParentId);
          results.push(result);
        }

        this[PRIVATE.UPDATE_STATS]();
        this[PRIVATE.NOTIFY]('imported', { type: 'json', count: results.length });
        resolve(results);
      } catch (error) {
        reject(error);
      }
    });
  }

  /** Импорт из HTML */
  [PRIVATE.API_IMPORT_HTML](htmlString, targetParentId = '1') {
    return new Promise((resolve, reject) => {
      try {
        if (!VALIDATOR[PRIVATE.VALIDATE].isValidHTML(htmlString)) {
          reject(new Error('Некорректный HTML формат'));
          return;
        }

        const parser = new DOMParser();
        const doc = parser.parseFromString(htmlString, 'text/html');
        const mainDl = doc.querySelector('dl');

        if (!mainDl) {
          reject(new Error('Неверный формат Netscape HTML'));
          return;
        }

        this[PRIVATE.NOTIFY]('import-began', { type: 'html' });
        this[PRIVATE.PARSE_HTML_DL](mainDl, targetParentId);
        this[PRIVATE.UPDATE_STATS]();
        this[PRIVATE.NOTIFY]('import-ended', { type: 'html' });

        resolve({ success: true, message: 'HTML импортирован' });
      } catch (error) {
        reject(error);
      }
    });
  }

  // ============================================================
  // 12. УТИЛИТЫ
  // ============================================================

  /** Проверить существование закладки по URL */
  [PRIVATE.API_EXISTS_BY_URL](url) {
    return new Promise((resolve, reject) => {
      try {
        const sanitizedUrl = VALIDATOR[PRIVATE.SANITIZE].sanitizeUrl(url);
        if (!sanitizedUrl) {
          reject(new Error('Некорректный URL'));
          return;
        }

        chrome.bookmarks.search(sanitizedUrl, (results) => {
          if (chrome.runtime.lastError) {
            reject(new Error(chrome.runtime.lastError.message));
          } else {
            resolve(results.some((b) => b.url === sanitizedUrl));
          }
        });
      } catch (error) {
        reject(error);
      }
    });
  }

  /** Удалить дубликаты */
  [PRIVATE.API_REMOVE_DUPLICATES]() {
    return new Promise((resolve, reject) => {
      try {
        chrome.bookmarks.getTree((tree) => {
          if (chrome.runtime.lastError) {
            reject(new Error(chrome.runtime.lastError.message));
            return;
          }

          const rootNodes = this[PRIVATE.GET_ROOT_NODES](tree);
          const duplicates = this[PRIVATE.FIND_DUPLICATES](rootNodes);
          const removed = [];

          for (const dup of duplicates) {
            try {
              chrome.bookmarks.remove(dup.id, () => {
                if (!chrome.runtime.lastError) {
                  removed.push(dup);
                }
              });
            } catch (error) {
              this._logger.warn(`Не удалось удалить дубликат ${dup.id}:`, error);
            }
          }

          this[PRIVATE.UPDATE_STATS]();
          this[PRIVATE.NOTIFY]('duplicates-removed', { count: removed.length });
          resolve(removed);
        });
      } catch (error) {
        reject(error);
      }
    });
  }

  /** Получить информацию об API */
  [PRIVATE.API_GET_INFO]() {
    return {
      name: CONFIG.name,
      version: CONFIG.version,
      apiVersion: CONFIG.apiVersion,
      build: CONFIG.build,
      permissions: ['bookmarks', 'storage', 'tabs'],
      connected: true,
      timestamp: Date.now(),
    };
  }

  /** Проверить готовность */
  [PRIVATE.API_IS_READY]() {
    const state = this[PRIVATE.STATE];
    return state.initialized && state.ready && !state.destroyed;
  }

  /** Подписка на события */
  [PRIVATE.API_SUBSCRIBE](event, callback) {
    if (!VALIDATOR[PRIVATE.VALIDATE].isValidCallback(callback)) {
      throw new Error('Некорректный callback');
    }

    const id = `sub_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    const subscriptions = this[PRIVATE.SUBSCRIPTIONS];
    subscriptions.set(id, { event, callback });

    this._logger.debug(`📌 Подписка создана: ${id} (${event})`);
    return id;
  }

  /** Отписка от событий */
  [PRIVATE.API_UNSUBSCRIBE](subscriptionId) {
    const subscriptions = this[PRIVATE.SUBSCRIPTIONS];
    const deleted = subscriptions.delete(subscriptionId);
    if (deleted) {
      this._logger.debug(`📌 Подписка удалена: ${subscriptionId}`);
    }
    return deleted;
  }

  // ============================================================
  // 13. ПУБЛИЧНЫЕ ОБЕРТКИ (для внешнего использования)
  // ============================================================

  getAll() {
    return this[PRIVATE.API_GET_ALL]();
  }
  getSubTree(folderId) {
    return this[PRIVATE.API_GET_SUB_TREE](folderId);
  }
  getChildren(folderId) {
    return this[PRIVATE.API_GET_CHILDREN](folderId);
  }
  getByIds(ids) {
    return this[PRIVATE.API_GET_BY_IDS](ids);
  }
  search(query) {
    return this[PRIVATE.API_SEARCH](query);
  }
  getRecent(count = 10) {
    return this[PRIVATE.API_GET_RECENT](count);
  }
  getRootFolders() {
    return this[PRIVATE.API_GET_ROOT_FOLDERS]();
  }
  getStats() {
    return this[PRIVATE.API_GET_STATS]();
  }

  create(parentId, title, url = null, index = null) {
    return this[PRIVATE.API_CREATE](parentId, title, url, index);
  }
  update(id, changes) {
    return this[PRIVATE.API_UPDATE](id, changes);
  }
  move(id, destinationParentId, index = null) {
    return this[PRIVATE.API_MOVE](id, destinationParentId, index);
  }
  remove(id) {
    return this[PRIVATE.API_REMOVE](id);
  }
  removeTree(folderId) {
    return this[PRIVATE.API_REMOVE_TREE](folderId);
  }

  exportToJSON() {
    return this[PRIVATE.API_EXPORT_JSON]();
  }
  exportToHTML() {
    return this[PRIVATE.API_EXPORT_HTML]();
  }
  importFromJSON(jsonString, targetParentId = '1') {
    return this[PRIVATE.API_IMPORT_JSON](jsonString, targetParentId);
  }
  importFromHTML(htmlString, targetParentId = '1') {
    return this[PRIVATE.API_IMPORT_HTML](htmlString, targetParentId);
  }

  existsByUrl(url) {
    return this[PRIVATE.API_EXISTS_BY_URL](url);
  }
  removeDuplicates() {
    return this[PRIVATE.API_REMOVE_DUPLICATES]();
  }
  getInfo() {
    return this[PRIVATE.API_GET_INFO]();
  }
  isReady() {
    return this[PRIVATE.API_IS_READY]();
  }
  subscribe(event, callback) {
    return this[PRIVATE.API_SUBSCRIBE](event, callback);
  }
  unsubscribe(subscriptionId) {
    return this[PRIVATE.API_UNSUBSCRIBE](subscriptionId);
  }

  // ============================================================
  // 14. ЗДОРОВЬЕ И УНИЧТОЖЕНИЕ
  // ============================================================

  healthCheck() {
    const state = this[PRIVATE.STATE];
    const stats = this[PRIVATE.STATS];
    const cache = this[PRIVATE.CACHE];

    return {
      initialized: state.initialized,
      ready: state.ready,
      destroyed: state.destroyed,
      version: CONFIG.version,
      apiVersion: CONFIG.apiVersion,
      stats: {
        totalBookmarks: stats.totalBookmarks,
        totalFolders: stats.totalFolders,
        totalNodes: stats.totalNodes,
        operationsCount: stats.operationsCount,
        cacheSize: cache.size,
        cacheHits: stats.cacheHits,
        cacheMisses: stats.cacheMisses,
        subscriptionsCount: this[PRIVATE.SUBSCRIPTIONS].size,
      },
      timestamp: Date.now(),
      isValid: true,
    };
  }

  destroy() {
    const logger = this._logger;
    const privateData = this._private.get(this);

    if (privateData[PRIVATE.IS_DESTROYED]) {
      logger.warn('⚠️ Менеджер уже уничтожен');
      return;
    }

    logger.info('🧹 Начинаем очистку Bookmarks Manager...');

    // Очищаем кэш
    privateData[PRIVATE.CACHE].clear();

    // Очищаем подписки
    privateData[PRIVATE.SUBSCRIPTIONS].clear();

    // Обновляем состояние
    privateData[PRIVATE.IS_DESTROYED] = true;
    privateData[PRIVATE.STATE].destroyed = true;
    privateData[PRIVATE.STATE].ready = false;

    // Удаляем глобальные ссылки
    if (typeof window !== 'undefined') {
      delete window[PUBLIC.INSTANCE];
      delete window.__bookmarksManager;
      delete window.__bookmarksManagerSymbols;
    }

    logger.success('🧹 Bookmarks Manager полностью очищен');
  }

  // ============================================================
  // 15. СТАТИЧЕСКИЕ МЕТОДЫ ДЛЯ УДОБСТВА
  // ============================================================

  static createInstance() {
    return new BookmarksManager();
  }

  static getInstance() {
    if (typeof window !== 'undefined' && window[PUBLIC.INSTANCE]) {
      return window[PUBLIC.INSTANCE];
    }
    const instance = new BookmarksManager();
    return instance;
  }
}

// ============================================================
// 16. ЭКСПОРТЫ
// ============================================================

// Экспорт класса
export default BookmarksManager;

// Экспорт символов
export {
  PRIVATE as BOOKMARKS_MANAGER_PRIVATE,
  PUBLIC as BOOKMARKS_MANAGER_PUBLIC,
  CONFIG as BOOKMARKS_MANAGER_CONFIG,
};

// ============================================================
// 17. ГЛОБАЛЬНАЯ РЕГИСТРАЦИЯ (только в браузере)
// ============================================================

if (typeof window !== 'undefined' && typeof document !== 'undefined') {
  // Создаем и регистрируем синглтон
  const instance = new BookmarksManager();

  // Регистрируем API в глобальном объекте с символом
  const API_SYMBOL = Symbol.for('bookmarks.manager.api');
  window[API_SYMBOL] = instance;

  // Удобные алиасы
  window.__bookmarksManager = instance;
  window.__bookmarksAPI = instance;

  console.log('╔═══════════════════════════════════════════════════════════════════════════════╗');
  console.log('║              📚 BOOKMARKS MANAGER (100% СИМВОЛЫ) v2.0.0                    ║');
  console.log('╠═══════════════════════════════════════════════════════════════════════════════╣');
  console.log('║  📋 Все методы доступны через:                                              ║');
  console.log('║    window[Symbol.for("bookmarks.manager.api")]                              ║');
  console.log('║    window.__bookmarksManager                                               ║');
  console.log('║    window.__bookmarksAPI                                                   ║');
  console.log('╠═══════════════════════════════════════════════════════════════════════════════╣');
  console.log('║  📊 СТАТИСТИКА СИМВОЛОВ:                                                     ║');
  console.log(
    `║    🔑 Приватных символов: ${Object.keys(PRIVATE).length}                                   ║`
  );
  console.log(
    `║    🔓 Публичных символов: ${Object.keys(PUBLIC).length}                                   ║`
  );
  console.log(
    `║    📦 Всего символов: ${Object.keys(PRIVATE).length + Object.keys(PUBLIC).length}                                 ║`
  );
  console.log('╠═══════════════════════════════════════════════════════════════════════════════╣');
  console.log('║  📋 ОСНОВНЫЕ МЕТОДЫ:                                                         ║');
  console.log('║    getAll() - получить всё дерево                                           ║');
  console.log('║    search(query) - поиск закладок                                           ║');
  console.log('║    create(parentId, title, url) - создать закладку                          ║');
  console.log('║    update(id, changes) - обновить закладку                                  ║');
  console.log('║    remove(id) - удалить закладку                                            ║');
  console.log('║    getStats() - статистика                                                  ║');
  console.log('║    exportToJSON() / exportToHTML() - экспорт                                ║');
  console.log('║    importFromJSON() / importFromHTML() - импорт                             ║');
  console.log('║    removeDuplicates() - удалить дубликаты                                   ║');
  console.log('║    subscribe(event, callback) - подписка на события                         ║');
  console.log('╚═══════════════════════════════════════════════════════════════════════════════╝');

  console.log('📋 ПРИМЕРЫ ИСПОЛЬЗОВАНИЯ:');
  console.log('  const api = window.__bookmarksAPI;');
  console.log('  await api.getAll();');
  console.log('  await api.search("github");');
  console.log('  await api.create("1", "My Site", "https://example.com");');
  console.log('  await api.getStats();');
  console.log('  const sub = await api.subscribe("created", (data) => console.log(data));');
  console.log('  await api.unsubscribe(sub);');
  console.log('  await api.healthCheck();');
  console.log('  await api.destroy();');
}

// ============================================================
// 18. СТАТИСТИКА СИМВОЛОВ (для консоли)
// ============================================================

if (typeof console !== 'undefined') {
  const privateCount = Object.keys(PRIVATE).length;
  const publicCount = Object.keys(PUBLIC).length;

  console.log(`📊 Bookmarks Manager: ${privateCount} приватных, ${publicCount} публичных символов`);
  console.log(`📦 Всего символов: ${privateCount + publicCount}`);
  console.log(`📋 Версия: ${CONFIG.version} (${CONFIG.build})`);
}
