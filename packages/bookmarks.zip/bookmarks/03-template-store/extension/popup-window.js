// ============================================================
// popup-window.js - Управление окном расширения
// 100% ИЗОЛЯЦИЯ
// Версия: 2.3.0
// ============================================================

(function () {
  'use strict';

  // ============================================================
  // 1. ПРИВАТНЫЕ СИМВОЛЫ (100% изоляция)
  // ============================================================

  const PRIVATE = {
    VERSION: Symbol('window.version'),
    BUILD: Symbol('window.build'),
    NAME: Symbol('window.name'),
    CONFIG: Symbol('window.config'),
    STATE: Symbol('window.state'),
    INITIALIZED: Symbol('window.initialized'),
    DESTROYED: Symbol('window.destroyed'),
    CONTAINER: Symbol('window.container'),
    IS_DRAGGING: Symbol('window.isDragging'),
    IS_RESIZING: Symbol('window.isResizing'),
    IS_MAXIMIZED: Symbol('window.isMaximized'),
    PREV_SIZE: Symbol('window.prevSize'),
    PREV_POS: Symbol('window.prevPos'),
    INIT: Symbol('window.init'),
    DESTROY: Symbol('window.destroy'),
    SETUP_DRAG: Symbol('window.setupDrag'),
    SETUP_RESIZE: Symbol('window.setupResize'),
    SETUP_CONTROLS: Symbol('window.setupControls'),
    UPDATE_SIZE_INFO: Symbol('window.updateSizeInfo'),
    SYNC_CONTAINER: Symbol('window.syncContainer'),
    LOGGER: Symbol('window.logger'),
  };

  // ============================================================
  // 2. ПУБЛИЧНЫЕ СИМВОЛЫ
  // ============================================================

  const PUBLIC = {
    INSTANCE: Symbol.for('window.instance'),
    STATE: Symbol.for('window.state'),
    CONFIG: Symbol.for('window.config'),
    INIT: Symbol.for('window.init'),
    DESTROY: Symbol.for('window.destroy'),
    GET_STATE: Symbol.for('window.getState'),
    TOGGLE_MAXIMIZE: Symbol.for('window.toggleMaximize'),
  };

  // ============================================================
  // 3. КОНФИГУРАЦИЯ
  // ============================================================

  const CONFIG = {
    version: '2.3.0',
    build: '2026-07-24',
    name: 'Window Manager',
    debug: true,
    minWidth: 320,
    minHeight: 200,
    maxWidth: 800,
    maxHeight: 600,
    defaultWidth: 480,
    defaultHeight: 270,
  };

  // ============================================================
  // 4. СОСТОЯНИЕ
  // ============================================================

  const STATE = {
    [PRIVATE.INITIALIZED]: false,
    [PRIVATE.DESTROYED]: false,
    [PRIVATE.IS_DRAGGING]: false,
    [PRIVATE.IS_RESIZING]: false,
    [PRIVATE.IS_MAXIMIZED]: false,
    [PRIVATE.PREV_SIZE]: { width: CONFIG.defaultWidth, height: CONFIG.defaultHeight },
    [PRIVATE.PREV_POS]: { left: 0, top: 0 },
  };

  // ============================================================
  // 5. ЛОГГЕР
  // ============================================================

  const LOGGER_SYMBOLS = {
    HISTORY: Symbol('logger.history'),
    MAX_HISTORY: Symbol('logger.maxHistory'),
    DEBUG: Symbol('logger.debug'),
    INSTANCE_ID: Symbol('logger.instanceId'),
    LEVEL: Symbol('logger.level'),
  };

  function createLogger(debug, instanceId) {
    if (debug === undefined) debug = true;
    if (instanceId === undefined) instanceId = 'WindowManager';

    const logState = {
      [LOGGER_SYMBOLS.HISTORY]: [],
      [LOGGER_SYMBOLS.MAX_HISTORY]: 200,
      [LOGGER_SYMBOLS.DEBUG]: debug,
      [LOGGER_SYMBOLS.INSTANCE_ID]: instanceId,
      [LOGGER_SYMBOLS.LEVEL]: debug ? 3 : 2,
    };

    const logMethod = function (level, message, data) {
      const levels = { error: 0, warn: 1, info: 2, debug: 3, success: 2 };
      const currentLevel = this[LOGGER_SYMBOLS.LEVEL] || 2;
      const msgLevel = levels[level] || 2;

      if (msgLevel > currentLevel) return;

      const timestamp = new Date().toISOString().slice(11, 23);
      const prefix = '[' + timestamp + '] [' + this[LOGGER_SYMBOLS.INSTANCE_ID] + ']';

      this[LOGGER_SYMBOLS.HISTORY].push({
        timestamp: timestamp,
        level: level,
        message: message,
        data: data || null,
        id: Date.now() + Math.random(),
      });

      if (this[LOGGER_SYMBOLS.HISTORY].length > this[LOGGER_SYMBOLS.MAX_HISTORY]) {
        this[LOGGER_SYMBOLS.HISTORY].shift();
      }

      var icons = { error: '❌', warn: '⚠️', info: 'ℹ️', debug: '🔍', success: '✅' };
      var icon = icons[level] || '📌';

      if (data !== null && data !== undefined) {
        console.log(icon + ' ' + prefix + ' ' + message, data);
      } else {
        console.log(icon + ' ' + prefix + ' ' + message);
      }
    };

    var boundLog = logMethod.bind(logState);

    var methods = {
      error: function (msg, d) {
        return boundLog('error', msg, d);
      },
      warn: function (msg, d) {
        return boundLog('warn', msg, d);
      },
      info: function (msg, d) {
        return boundLog('info', msg, d);
      },
      debug: function (msg, d) {
        return boundLog('debug', msg, d);
      },
      success: function (msg, d) {
        return boundLog('success', msg, d);
      },

      header: function (title, color) {
        if (color === undefined) color = '#636e72';
        var separator = '═'.repeat(70);
        console.log('%c' + separator, 'color: ' + color + ';');
        console.log(
          '%c  📦 ' + title,
          'background: #1a1a2e; color: #fff; padding: 4px 12px; border-radius: 4px; font-weight: bold;'
        );
        console.log('%c' + separator, 'color: ' + color + ';');
      },

      separator: function (color) {
        if (color === undefined) color = '#636e72';
        console.log('%c' + '─'.repeat(70), 'color: ' + color + ';');
      },

      getHistory: function () {
        return [...this[LOGGER_SYMBOLS.HISTORY]];
      },

      clearHistory: function () {
        this[LOGGER_SYMBOLS.HISTORY] = [];
        return this;
      },

      setDebug: function (enabled) {
        this[LOGGER_SYMBOLS.DEBUG] = enabled;
        this[LOGGER_SYMBOLS.LEVEL] = enabled ? 3 : 2;
        return this;
      },
    };

    var logger = {};
    var keys = Object.keys(methods);
    for (var i = 0; i < keys.length; i++) {
      var key = keys[i];
      logger[key] = methods[key].bind(logState);
    }

    logger[LOGGER_SYMBOLS.HISTORY] = logState[LOGGER_SYMBOLS.HISTORY];
    logger[LOGGER_SYMBOLS.MAX_HISTORY] = logState[LOGGER_SYMBOLS.MAX_HISTORY];
    logger[LOGGER_SYMBOLS.DEBUG] = logState[LOGGER_SYMBOLS.DEBUG];
    logger[LOGGER_SYMBOLS.INSTANCE_ID] = logState[LOGGER_SYMBOLS.INSTANCE_ID];
    logger[LOGGER_SYMBOLS.LEVEL] = logState[LOGGER_SYMBOLS.LEVEL];

    return logger;
  }

  // ============================================================
  // 6. СОЗДАНИЕ ЛОГГЕРА
  // ============================================================

  var logger = createLogger(CONFIG.debug, 'WindowManager');

  // ============================================================
  // 7. ОСНОВНОЙ ОБЪЕКТ WINDOW_MANAGER
  // ============================================================

  var WindowManager = {
    [PRIVATE.STATE]: STATE,
    [PRIVATE.CONFIG]: CONFIG,
    [PRIVATE.LOGGER]: logger,

    // ============================================================
    // 7.1. ИНИЦИАЛИЗАЦИЯ
    // ============================================================

    [PRIVATE.INIT]: function () {
      var state = this[PRIVATE.STATE];

      if (state[PRIVATE.INITIALIZED]) {
        logger.warn('⚠️ Window Manager уже инициализирован');
        return;
      }

      logger.header('ИНИЦИАЛИЗАЦИЯ WINDOW MANAGER (100% СИМВОЛЫ)');
      logger.info('📦 Версия: ' + CONFIG.version);
      logger.info('📅 Сборка: ' + CONFIG.build);
      logger.info('📌 Отладка: ' + (CONFIG.debug ? '✅' : '❌'));
      logger.separator();

      try {
        var container = document.getElementById('app');
        if (!container) {
          throw new Error('Контейнер #app не найден');
        }

        // ✅ КОНТЕЙНЕР ВСЕГДА РАЗМЕРОМ С ОКНО
        container.style.position = 'relative';
        container.style.width = '100%';
        container.style.height = '100%';
        container.style.overflow = 'hidden';
        container.style.margin = '0';
        container.style.padding = '0';

        // ✅ Устанавливаем размер ОКНА (body)
        document.body.style.width = CONFIG.defaultWidth + 'px';
        document.body.style.height = CONFIG.defaultHeight + 'px';
        document.body.style.minWidth = CONFIG.defaultWidth + 'px';
        document.body.style.minHeight = CONFIG.defaultHeight + 'px';
        document.body.style.maxWidth = CONFIG.maxWidth + 'px';
        document.body.style.maxHeight = CONFIG.maxHeight + 'px';
        document.body.style.overflow = 'hidden';
        document.body.style.margin = '0';
        document.body.style.padding = '0';

        // Сохраняем состояние
        state[PRIVATE.CONTAINER] = container;
        state[PRIVATE.PREV_POS] = { left: 0, top: 0 };

        // Настраиваем функции
        this[PRIVATE.SETUP_DRAG]();
        this[PRIVATE.SETUP_RESIZE]();
        this[PRIVATE.SETUP_CONTROLS]();

        state[PRIVATE.INITIALIZED] = true;
        state[PRIVATE.DESTROYED] = false;

        this[PRIVATE.UPDATE_SIZE_INFO]();

        logger.success('✅ Window Manager инициализирован');
        logger.header('ГОТОВ');

        console.log(
          '📐 Размер окна: ' + document.body.offsetWidth + '×' + document.body.offsetHeight
        );
        console.log('📌 Перетащите за заголовок для перемещения ОКНА');
        console.log('📌 Тяните за правый нижний угол для ресайза ОКНА');
      } catch (error) {
        logger.error('❌ Ошибка инициализации:', error);
        throw error;
      }
    },

    // ============================================================
    // 7.2. СИНХРОНИЗАЦИЯ КОНТЕЙНЕРА С ОКНОМ
    // ============================================================

    [PRIVATE.SYNC_CONTAINER]: function () {
      var state = this[PRIVATE.STATE];
      var container = state[PRIVATE.CONTAINER];

      if (!container) return;

      // ✅ Контейнер всегда 100% от окна
      container.style.width = '100%';
      container.style.height = '100%';
    },

    // ============================================================
    // 7.3. НАСТРОЙКА ПЕРЕМЕЩЕНИЯ (ПЕРЕМЕЩАЕТСЯ ОКНО)
    // ============================================================

    [PRIVATE.SETUP_DRAG]: function () {
      var state = this[PRIVATE.STATE];
      var container = state[PRIVATE.CONTAINER];
      var dragHandle = document.getElementById('dragHandle');

      if (!dragHandle) {
        logger.warn('⚠️ dragHandle не найден');
        return;
      }

      var dragData = {
        isDragging: false,
        offsetX: 0,
        offsetY: 0,
        startLeft: 0,
        startTop: 0,
      };

      dragHandle.addEventListener('mousedown', function (e) {
        if (e.target.closest('.window-controls') || e.target.closest('.window-btn')) {
          return;
        }

        dragData.isDragging = true;

        // ✅ Получаем текущую позицию ОКНА (body)
        var rect = document.body.getBoundingClientRect();
        dragData.startLeft = rect.left;
        dragData.startTop = rect.top;
        dragData.offsetX = e.clientX - rect.left;
        dragData.offsetY = e.clientY - rect.top;

        document.body.style.cursor = 'grabbing';
        document.body.style.userSelect = 'none';
        e.preventDefault();
      });

      document.addEventListener('mousemove', function (e) {
        if (!dragData.isDragging) return;

        // ✅ Перемещаем ВСЕ ОКНО через body
        var newLeft = e.clientX - dragData.offsetX;
        var newTop = e.clientY - dragData.offsetY;

        document.body.style.position = 'fixed';
        document.body.style.left = newLeft + 'px';
        document.body.style.top = newTop + 'px';
        document.body.style.right = 'auto';
        document.body.style.bottom = 'auto';

        // Контейнер следует за окном
        container.style.position = 'relative';
        container.style.width = '100%';
        container.style.height = '100%';

        state[PRIVATE.PREV_POS] = { left: newLeft, top: newTop };
      });

      document.addEventListener('mouseup', function () {
        if (dragData.isDragging) {
          dragData.isDragging = false;
          document.body.style.cursor = 'default';
          document.body.style.userSelect = '';
        }
      });

      logger.debug('✅ Drag настроен (перемещается ОКНО)');
    },

    // ============================================================
    // 7.4. НАСТРОЙКА РЕСАЙЗА (РЕСАЙЗИТСЯ ОКНО)
    // ============================================================

    [PRIVATE.SETUP_RESIZE]: function () {
      var state = this[PRIVATE.STATE];
      var container = state[PRIVATE.CONTAINER];
      var resizeHandle = document.getElementById('resizeHandle');

      if (!resizeHandle) {
        logger.warn('⚠️ resizeHandle не найден');
        return;
      }

      var resizeData = {
        isResizing: false,
        startX: 0,
        startY: 0,
        startWidth: 0,
        startHeight: 0,
        startLeft: 0,
        startTop: 0,
      };

      var self = this;

      resizeHandle.addEventListener('mousedown', function (e) {
        var rect = document.body.getBoundingClientRect();

        resizeData.isResizing = true;
        resizeData.startX = e.clientX;
        resizeData.startY = e.clientY;
        resizeData.startWidth = document.body.offsetWidth;
        resizeData.startHeight = document.body.offsetHeight;
        resizeData.startLeft = rect.left;
        resizeData.startTop = rect.top;

        document.body.style.cursor = 'nw-resize';
        document.body.style.userSelect = 'none';
        e.preventDefault();
        e.stopPropagation();
      });

      document.addEventListener('mousemove', function (e) {
        if (!resizeData.isResizing) return;

        // Вычисляем новый размер ОКНА
        var deltaX = e.clientX - resizeData.startX;
        var deltaY = e.clientY - resizeData.startY;

        var newWidth = Math.min(
          Math.max(resizeData.startWidth + deltaX, CONFIG.minWidth),
          CONFIG.maxWidth
        );
        var newHeight = Math.min(
          Math.max(resizeData.startHeight + deltaY, CONFIG.minHeight),
          CONFIG.maxHeight
        );

        // ✅ Меняем размер ВСЕГО ОКНА через body
        document.body.style.width = newWidth + 'px';
        document.body.style.height = newHeight + 'px';
        document.body.style.minWidth = newWidth + 'px';
        document.body.style.minHeight = newHeight + 'px';
        document.body.style.maxWidth = newWidth + 'px';
        document.body.style.maxHeight = newHeight + 'px';

        // ✅ Контейнер автоматически подстраивается (100% x 100%)
        container.style.width = '100%';
        container.style.height = '100%';

        // Обновляем информацию
        self[PRIVATE.UPDATE_SIZE_INFO]();

        // Сохраняем размер
        state[PRIVATE.PREV_SIZE] = { width: newWidth, height: newHeight };
      });

      document.addEventListener('mouseup', function () {
        if (resizeData.isResizing) {
          resizeData.isResizing = false;
          document.body.style.cursor = 'default';
          document.body.style.userSelect = '';
        }
      });

      logger.debug('✅ Resize настроен (изменяет размер ОКНА)');
    },

    // ============================================================
    // 7.5. НАСТРОЙКА КНОПОК УПРАВЛЕНИЯ
    // ============================================================

    [PRIVATE.SETUP_CONTROLS]: function () {
      var state = this[PRIVATE.STATE];
      var container = state[PRIVATE.CONTAINER];
      var self = this;

      // Кнопка закрытия
      var closeBtn = document.getElementById('closeBtn');
      if (closeBtn) {
        var newCloseBtn = closeBtn.cloneNode(true);
        closeBtn.parentNode.replaceChild(newCloseBtn, closeBtn);

        newCloseBtn.addEventListener('click', function (e) {
          e.preventDefault();
          e.stopPropagation();
          window.close();
        });
        logger.debug('✅ Close кнопка настроена');
      }

      // Кнопка максимизации
      var maximizeBtn = document.getElementById('maximizeBtn');
      if (maximizeBtn) {
        var newMaximizeBtn = maximizeBtn.cloneNode(true);
        maximizeBtn.parentNode.replaceChild(newMaximizeBtn, maximizeBtn);

        newMaximizeBtn.addEventListener('click', function (e) {
          e.preventDefault();
          e.stopPropagation();
          self[PUBLIC.TOGGLE_MAXIMIZE]();
        });
        logger.debug('✅ Maximize кнопка настроена');
      }

      // Кнопка минимизации
      var minimizeBtn = document.getElementById('minimizeBtn');
      if (minimizeBtn) {
        var newMinimizeBtn = minimizeBtn.cloneNode(true);
        minimizeBtn.parentNode.replaceChild(newMinimizeBtn, minimizeBtn);

        newMinimizeBtn.addEventListener('click', function (e) {
          e.preventDefault();
          e.stopPropagation();
          var status = document.getElementById('footerInfo');
          if (status) {
            status.textContent = '📌 Используйте системные кнопки окна';
            setTimeout(function () {
              status.textContent = '📚 Готово';
            }, 2000);
          }
        });
        logger.debug('✅ Minimize кнопка настроена');
      }
    },

    // ============================================================
    // 7.6. ОБНОВЛЕНИЕ ИНФОРМАЦИИ О РАЗМЕРЕ
    // ============================================================

    [PRIVATE.UPDATE_SIZE_INFO]: function () {
      var container = this[PRIVATE.STATE][PRIVATE.CONTAINER];
      var footerInfo = document.getElementById('footerInfo');

      if (!footerInfo || !container) return;

      var w = document.body.offsetWidth;
      var h = document.body.offsetHeight;
      footerInfo.textContent = '📐 ' + w + '×' + h;
    },

    // ============================================================
    // 7.7. ПУБЛИЧНЫЙ МЕТОД - РАЗВЕРНУТЬ/СВЕРНУТЬ
    // ============================================================

    [PUBLIC.TOGGLE_MAXIMIZE]: function () {
      var state = this[PRIVATE.STATE];
      var container = state[PRIVATE.CONTAINER];
      var maximizeBtn = document.getElementById('maximizeBtn');

      if (!container || !maximizeBtn) return;

      var isMaximized = state[PRIVATE.IS_MAXIMIZED];

      if (!isMaximized) {
        // Сохраняем текущий размер
        state[PRIVATE.PREV_SIZE] = {
          width: document.body.offsetWidth,
          height: document.body.offsetHeight,
        };
        state[PRIVATE.PREV_POS] = {
          left: document.body.style.left || '0px',
          top: document.body.style.top || '0px',
        };

        // ✅ Разворачиваем ОКНО
        var maxW = CONFIG.maxWidth;
        var maxH = CONFIG.maxHeight;

        document.body.style.width = maxW + 'px';
        document.body.style.height = maxH + 'px';
        document.body.style.minWidth = maxW + 'px';
        document.body.style.minHeight = maxH + 'px';
        document.body.style.maxWidth = maxW + 'px';
        document.body.style.maxHeight = maxH + 'px';
        document.body.style.position = 'fixed';
        document.body.style.left = '50%';
        document.body.style.top = '50%';
        document.body.style.transform = 'translate(-50%, -50%)';

        // Контейнер автоматически 100%
        container.style.width = '100%';
        container.style.height = '100%';

        state[PRIVATE.IS_MAXIMIZED] = true;
        maximizeBtn.textContent = '⤢';
        logger.debug('✅ Окно развернуто');
      } else {
        // ✅ Восстанавливаем размер ОКНА
        var prevSize = state[PRIVATE.PREV_SIZE];
        var prevPos = state[PRIVATE.PREV_POS];

        var w = prevSize.width;
        var h = prevSize.height;

        document.body.style.width = w + 'px';
        document.body.style.height = h + 'px';
        document.body.style.minWidth = w + 'px';
        document.body.style.minHeight = h + 'px';
        document.body.style.maxWidth = w + 'px';
        document.body.style.maxHeight = h + 'px';
        document.body.style.transform = 'none';
        document.body.style.left = prevPos.left;
        document.body.style.top = prevPos.top;

        container.style.width = '100%';
        container.style.height = '100%';

        state[PRIVATE.IS_MAXIMIZED] = false;
        maximizeBtn.textContent = '⬜';
        logger.debug('✅ Окно восстановлено');
      }

      this[PRIVATE.UPDATE_SIZE_INFO]();
    },

    // ============================================================
    // 7.8. УНИЧТОЖЕНИЕ
    // ============================================================

    [PRIVATE.DESTROY]: function () {
      var state = this[PRIVATE.STATE];

      if (state[PRIVATE.DESTROYED]) {
        logger.warn('⚠️ Window Manager уже уничтожен');
        return;
      }

      logger.info('🧹 Очистка Window Manager...');

      state[PRIVATE.DESTROYED] = true;
      state[PRIVATE.INITIALIZED] = false;

      if (typeof window !== 'undefined') {
        delete window.__windowManager;
        delete window[PUBLIC.INSTANCE];
      }

      logger.success('✅ Window Manager уничтожен');
    },

    // ============================================================
    // 7.9. ПУБЛИЧНЫЙ МЕТОД - ПОЛУЧИТЬ СОСТОЯНИЕ
    // ============================================================

    [PUBLIC.GET_STATE]: function () {
      var state = this[PRIVATE.STATE];
      var container = state[PRIVATE.CONTAINER];

      return {
        initialized: state[PRIVATE.INITIALIZED],
        destroyed: state[PRIVATE.DESTROYED],
        isDragging: state[PRIVATE.IS_DRAGGING],
        isResizing: state[PRIVATE.IS_RESIZING],
        isMaximized: state[PRIVATE.IS_MAXIMIZED],
        width: document.body ? document.body.offsetWidth : 0,
        height: document.body ? document.body.offsetHeight : 0,
        minWidth: CONFIG.minWidth,
        minHeight: CONFIG.minHeight,
        maxWidth: CONFIG.maxWidth,
        maxHeight: CONFIG.maxHeight,
        defaultWidth: CONFIG.defaultWidth,
        defaultHeight: CONFIG.defaultHeight,
        position: document.body
          ? {
              left: document.body.style.left || '0px',
              top: document.body.style.top || '0px',
            }
          : null,
      };
    },

    [PUBLIC.INIT]: function () {
      return this[PRIVATE.INIT]();
    },

    [PUBLIC.DESTROY]: function () {
      return this[PRIVATE.DESTROY]();
    },
  };

  // ============================================================
  // 8. ГЛОБАЛЬНАЯ РЕГИСТРАЦИЯ
  // ============================================================

  if (typeof window !== 'undefined') {
    window.__windowManager = WindowManager;
    window[PUBLIC.INSTANCE] = WindowManager;
    window.__WINDOW_SYMBOLS = {
      PRIVATE: { ...PRIVATE },
      PUBLIC: { ...PUBLIC },
    };
  }

  // ============================================================
  // 9. АВТОЗАПУСК
  // ============================================================

  if (typeof document !== 'undefined') {
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', function () {
        try {
          WindowManager[PRIVATE.INIT]();
        } catch (error) {
          console.error('❌ Ошибка автозапуска Window Manager:', error);
        }
      });
    } else {
      try {
        WindowManager[PRIVATE.INIT]();
      } catch (error) {
        console.error('❌ Ошибка автозапуска Window Manager:', error);
      }
    }
  }

  // ============================================================
  // 10. КОНСОЛЬНЫЙ ИНТЕРФЕЙС
  // ============================================================

  if (typeof console !== 'undefined') {
    var privateCount = Object.keys(PRIVATE).length;
    var publicCount = Object.keys(PUBLIC).length;

    console.log(
      '╔═══════════════════════════════════════════════════════════════════════════════╗'
    );
    console.log('║              🪟 WINDOW MANAGER (100% СИМВОЛЫ) v2.3.0                        ║');
    console.log(
      '╠═══════════════════════════════════════════════════════════════════════════════╣'
    );
    console.log('║  📋 Все логи выводятся в консоль с цветовой разметкой                       ║');
    console.log('║  🔑 Полная изоляция через приватные символы                                 ║');
    console.log('║  🔓 Публичные символы через Symbol.for                                      ║');
    console.log('║  🪟 Перемещается ВНЕШНЕЕ окно расширения                                    ║');
    console.log('║  📐 Ресайзится ВНЕШНЕЕ окно расширения                                      ║');
    console.log('║  📦 Контейнер всегда 100% от размера окна                                   ║');
    console.log('║  ⬜ Развернуть на максимальный размер                                       ║');
    console.log('║  ✕ Закрыть окно                                                            ║');
    console.log(
      '╚═══════════════════════════════════════════════════════════════════════════════╝'
    );

    console.log('📋 ДОСТУПНЫЕ КОМАНДЫ:');
    console.log('  window.__windowManager[PUBLIC.GET_STATE]() - получить состояние');
    console.log('  window.__windowManager[PUBLIC.TOGGLE_MAXIMIZE]() - развернуть/свернуть');
    console.log('  window.__windowManager[PUBLIC.DESTROY]() - уничтожить');
    console.log('  window.__WINDOW_SYMBOLS - все символы');
    console.log('');

    console.log('📊 СТАТИСТИКА СИМВОЛОВ:');
    console.log('  🔑 Приватных символов: ' + privateCount);
    console.log('  🔓 Публичных символов: ' + publicCount);
    console.log('  📦 Всего символов: ' + (privateCount + publicCount));
    console.log('');

    console.log('✅ Window Manager загружен (100% символы)');
  }
})();
