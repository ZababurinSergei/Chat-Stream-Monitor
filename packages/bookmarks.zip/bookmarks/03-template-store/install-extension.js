// ============================================================
// install-extension.js
// УСТАНОВЩИК РАСШИРЕНИЯ CHROME (100% СИМВОЛЫ)
// Версия: 2.0.0
// ============================================================

// ============================================================
// 1. ПРИВАТНЫЕ СИМВОЛЫ (100% изоляция)
// ============================================================

const PRIVATE = {
  // Основные символы
  VERSION: Symbol('installer.version'),
  BUILD: Symbol('installer.build'),
  NAME: Symbol('installer.name'),
  CONFIG: Symbol('installer.config'),
  STATE: Symbol('installer.state'),
  LOGGER: Symbol('installer.logger'),

  // Конфигурация
  EXTENSION_PATH: Symbol('installer.extensionPath'),
  REQUIRED_FILES: Symbol('installer.requiredFiles'),
  OPTIONAL_FILES: Symbol('installer.optionalFiles'),

  // Состояние
  INITIALIZED: Symbol('installer.initialized'),
  IS_DESTROYED: Symbol('installer.isDestroyed'),
  CHECK_RESULTS: Symbol('installer.checkResults'),
  PLATFORM: Symbol('installer.platform'),

  // Методы
  INIT: Symbol('installer.init'),
  DESTROY: Symbol('installer.destroy'),
  CHECK_FILES: Symbol('installer.checkFiles'),
  CHECK_DIRECTORIES: Symbol('installer.checkDirectories'),
  CHECK_MANIFEST: Symbol('installer.checkManifest'),
  CHECK_ICONS: Symbol('installer.checkIcons'),
  CREATE_BAT: Symbol('installer.createBat'),
  CREATE_SH: Symbol('installer.createSh'),
  CREATE_PS1: Symbol('installer.createPs1'),
  PRINT_INSTRUCTIONS: Symbol('installer.printInstructions'),
  PRINT_HEADER: Symbol('installer.printHeader'),
  PRINT_FOOTER: Symbol('installer.printFooter'),
  PRINT_STATUS: Symbol('installer.printStatus'),
  GET_PLATFORM: Symbol('installer.getPlatform'),
  VALIDATE: Symbol('installer.validate'),
  EXPORT_SYMBOLS: Symbol('installer.exportSymbols'),
  LOG: Symbol('installer.log'),
};

// ============================================================
// 2. ПУБЛИЧНЫЕ СИМВОЛЫ (доступны через Symbol.for)
// ============================================================

const PUBLIC = {
  INSTANCE: Symbol.for('installer.instance'),
  STATE: Symbol.for('installer.state'),
  CONFIG: Symbol.for('installer.config'),
  INIT: Symbol.for('installer.init'),
  DESTROY: Symbol.for('installer.destroy'),
  CHECK: Symbol.for('installer.check'),
  INSTALL: Symbol.for('installer.install'),
  GET_STATE: Symbol.for('installer.getState'),
  GET_REPORT: Symbol.for('installer.getReport'),
};

// ============================================================
// 3. КОНФИГУРАЦИЯ
// ============================================================

const CONFIG = {
  version: '2.0.0',
  build: '2026-07-23',
  name: 'Extension Installer',
  debug: true,
  extensionDir: 'extension',
  batFilename: 'install-extension.bat',
  shFilename: 'install-extension.sh',
  ps1Filename: 'install-extension.ps1',

  // Обязательные файлы
  requiredFiles: [
    'manifest.json',
    'bookmarksManager.mjs',
    'background.js',
    'content.js',
    'popup.html',
    'popup.js',
    'popup.css',
  ],

  // Опциональные файлы
  optionalFiles: [
    'icon/icon16.png',
    'icon/icon48.png',
    'icon/icon128.png',
  ],

  // Обязательные директории
  requiredDirs: [
    'icon',
  ],

  // Проверки манифеста
  manifestChecks: {
    requiredFields: [
      'manifest_version',
      'name',
      'version',
      'description',
      'permissions',
      'background',
      'action',
      'icons',
    ],
    permissions: [
      'bookmarks',
      'storage',
      'tabs',
      'scripting',
    ],
    hostPermissions: ['<all_urls>'],
  },
};

// ============================================================
// 4. СОСТОЯНИЕ
// ============================================================

const STATE = {
  [PRIVATE.INITIALIZED]: false,
  [PRIVATE.IS_DESTROYED]: false,
  [PRIVATE.CHECK_RESULTS]: {
    passed: false,
    errors: [],
    warnings: [],
    info: [],
    files: {},
    manifest: {},
    icons: {},
    directories: {},
    summary: {},
  },
  [PRIVATE.PLATFORM]: null,
  [PRIVATE.EXTENSION_PATH]: null,
};

// ============================================================
// 5. ЛОГГЕР (100% СИМВОЛЫ)
// ============================================================

const LOGGER_SYMBOLS = {
  HISTORY: Symbol('logger.history'),
  MAX_HISTORY: Symbol('logger.maxHistory'),
  DEBUG: Symbol('logger.debug'),
  INSTANCE_ID: Symbol('logger.instanceId'),
  LEVEL: Symbol('logger.level'),
  COLORS: Symbol('logger.colors'),
};

function createLogger(debug = true, instanceId = 'Installer') {
  const logState = {
    [LOGGER_SYMBOLS.HISTORY]: [],
    [LOGGER_SYMBOLS.MAX_HISTORY]: 500,
    [LOGGER_SYMBOLS.DEBUG]: debug,
    [LOGGER_SYMBOLS.INSTANCE_ID]: instanceId,
    [LOGGER_SYMBOLS.LEVEL]: debug ? 3 : 2,
    [LOGGER_SYMBOLS.COLORS]: {
      reset: '\x1b[0m',
      bold: '\x1b[1m',
      red: '\x1b[31m',
      green: '\x1b[32m',
      yellow: '\x1b[33m',
      blue: '\x1b[34m',
      magenta: '\x1b[35m',
      cyan: '\x1b[36m',
      white: '\x1b[37m',
      gray: '\x1b[90m',
    },
  };

  const logMethod = function (level, message, data = null) {
    const levels = { error: 0, warn: 1, info: 2, debug: 3, success: 2 };
    const currentLevel = this[LOGGER_SYMBOLS.LEVEL] || 2;
    const msgLevel = levels[level] || 2;

    if (msgLevel > currentLevel) return;

    const timestamp = new Date().toISOString().slice(11, 23);
    const prefix = `[${timestamp}] [${this[LOGGER_SYMBOLS.INSTANCE_ID]}]`;

    this[LOGGER_SYMBOLS.HISTORY].push({
      timestamp,
      level,
      message,
      data,
      id: Date.now() + Math.random(),
    });

    if (this[LOGGER_SYMBOLS.HISTORY].length > this[LOGGER_SYMBOLS.MAX_HISTORY]) {
      this[LOGGER_SYMBOLS.HISTORY].shift();
    }

    const colors = this[LOGGER_SYMBOLS.COLORS];
    const colorMap = {
      error: colors.red,
      warn: colors.yellow,
      info: colors.blue,
      debug: colors.gray,
      success: colors.green,
    };

    const icons = {
      error: '❌',
      warn: '⚠️',
      info: 'ℹ️',
      debug: '🔍',
      success: '✅',
    };

    const icon = icons[level] || '📌';
    const color = colorMap[level] || colors.white;

    if (data !== null && data !== undefined) {
      console.log(`${color}${icon} ${prefix} ${message}${colors.reset}`, data);
    } else {
      console.log(`${color}${icon} ${prefix} ${message}${colors.reset}`);
    }
  };

  const boundLog = logMethod.bind(logState);

  const methods = {
    error: (msg, d) => boundLog('error', msg, d),
    warn: (msg, d) => boundLog('warn', msg, d),
    info: (msg, d) => boundLog('info', msg, d),
    debug: (msg, d) => boundLog('debug', msg, d),
    success: (msg, d) => boundLog('success', msg, d),

    header: (title, color = '#636e72') => {
      const colors = logState[LOGGER_SYMBOLS.COLORS];
      const separator = '═'.repeat(70);
      console.log(`${colors.cyan}${separator}${colors.reset}`);
      console.log(
        `${colors.bold}${colors.magenta}  📦 ${title}${colors.reset}`
      );
      console.log(`${colors.cyan}${separator}${colors.reset}`);
    },

    separator: (color = '#636e72') => {
      const colors = logState[LOGGER_SYMBOLS.COLORS];
      console.log(`${colors.gray}${'─'.repeat(70)}${colors.reset}`);
    },

    getHistory: function () {
      return [...this[LOGGER_SYMBOLS.HISTORY]];
    },

    clearHistory: function () {
      this[LOGGER_SYMBOLS.HISTORY] = [];
      return this;
    },

    setDebug: function (enabled) {
      this[LOGGER_SYMBOLS.DEBUG] = enabled;
      this[LOGGER_SYMBOLS.LEVEL] = enabled ? 3 : 2;
      return this;
    },
  };

  const logger = {};
  for (const [key, fn] of Object.entries(methods)) {
    logger[key] = fn.bind(logState);
  }

  logger[LOGGER_SYMBOLS.HISTORY] = logState[LOGGER_SYMBOLS.HISTORY];
  logger[LOGGER_SYMBOLS.MAX_HISTORY] = logState[LOGGER_SYMBOLS.MAX_HISTORY];
  logger[LOGGER_SYMBOLS.DEBUG] = logState[LOGGER_SYMBOLS.DEBUG];
  logger[LOGGER_SYMBOLS.INSTANCE_ID] = logState[LOGGER_SYMBOLS.INSTANCE_ID];
  logger[LOGGER_SYMBOLS.LEVEL] = logState[LOGGER_SYMBOLS.LEVEL];
  logger[LOGGER_SYMBOLS.COLORS] = logState[LOGGER_SYMBOLS.COLORS];

  return logger;
}

// ============================================================
// 6. ОСНОВНОЙ КЛАСС INSTALLER
// ============================================================

class Installer {
  constructor() {
    const logger = createLogger(CONFIG.debug, 'Installer');

    // Сохраняем состояние
    this[PRIVATE.LOGGER] = logger;
    this[PRIVATE.CONFIG] = { ...CONFIG };
    this[PRIVATE.STATE] = { ...STATE };
    this[PRIVATE.EXTENSION_PATH] = null;
    this[PRIVATE.PLATFORM] = null;

    // Инициализируем
    this[PRIVATE.INIT]();
  }

  // ============================================================
  // 6.1. ИНИЦИАЛИЗАЦИЯ
  // ============================================================

  [PRIVATE.INIT]() {
    const logger = this[PRIVATE.LOGGER];
    const state = this[PRIVATE.STATE];
    const config = this[PRIVATE.CONFIG];

    if (state[PRIVATE.INITIALIZED]) {
      logger.warn('⚠️ Инсталлер уже инициализирован');
      return;
    }

    this[PRIVATE.PRINT_HEADER]();

    try {
      // Определяем платформу
      this[PRIVATE.PLATFORM] = this[PRIVATE.GET_PLATFORM]();

      // Определяем путь к расширению
      const extensionPath = this[PRIVATE._getExtensionPath]();
      this[PRIVATE.EXTENSION_PATH] = extensionPath;

      logger.info(`📂 Путь к расширению: ${extensionPath}`);
      logger.info(`🖥️ Платформа: ${this[PRIVATE.PLATFORM]}`);

      // Проверяем файлы
      const checkResults = this[PRIVATE.CHECK_FILES]();
      state[PRIVATE.CHECK_RESULTS] = checkResults;

      // Создаем установочные скрипты
      this[PRIVATE._createInstallScripts]();

      // Выводим инструкции
      this[PRIVATE.PRINT_INSTRUCTIONS]();

      state[PRIVATE.INITIALIZED] = true;
      state[PRIVATE.IS_DESTROYED] = false;

      // Экспортируем символы
      this[PRIVATE.EXPORT_SYMBOLS]();

      logger.success('✅ Инсталлер инициализирован');
      this[PRIVATE.PRINT_FOOTER]();
    } catch (error) {
      logger.error('❌ Ошибка инициализации:', error);
      throw error;
    }
  }

  // ============================================================
  // 6.2. ПОЛУЧЕНИЕ ПУТИ К РАСШИРЕНИЮ
  // ============================================================

  [PRIVATE._getExtensionPath]() {
    const config = this[PRIVATE.CONFIG];
    const { dirname } = require('path');

    try {
      // Пробуем получить путь из __dirname
      let basePath = __dirname;

      // Проверяем, существует ли папка расширения
      const fs = require('fs');
      const extensionPath = require('path').join(basePath, config.extensionDir);

      if (fs.existsSync(extensionPath)) {
        return extensionPath;
      }

      // Если нет, пробуем найти в родительской директории
      const parentPath = require('path').join(basePath, '..', config.extensionDir);
      if (fs.existsSync(parentPath)) {
        return parentPath;
      }

      // Возвращаем путь по умолчанию
      return extensionPath;
    } catch (error) {
      this[PRIVATE.LOGGER].warn('⚠️ Не удалось определить путь:', error);
      return require('path').join(process.cwd(), config.extensionDir);
    }
  }

  // ============================================================
  // 6.3. ПРОВЕРКА ФАЙЛОВ
  // ============================================================

  [PRIVATE.CHECK_FILES]() {
    const logger = this[PRIVATE.LOGGER];
    const config = this[PRIVATE.CONFIG];
    const fs = require('fs');
    const path = require('path');

    const results = {
      passed: true,
      errors: [],
      warnings: [],
      info: [],
      files: {},
      manifest: {},
      icons: {},
      directories: {},
      summary: {
        totalFiles: 0,
        presentFiles: 0,
        missingFiles: 0,
        totalDirs: 0,
        presentDirs: 0,
        missingDirs: 0,
      },
    };

    const extensionPath = this[PRIVATE.EXTENSION_PATH];

    logger.info('🔍 Проверка файлов расширения...');
    logger.separator();

    // Проверяем директории
    const dirResults = this[PRIVATE.CHECK_DIRECTORIES]();
    results.directories = dirResults;
    results.summary.totalDirs = dirResults.totalDirs || 0;
    results.summary.presentDirs = dirResults.presentDirs || 0;
    results.summary.missingDirs = dirResults.missingDirs || 0;

    if (dirResults.errors && dirResults.errors.length > 0) {
      results.errors.push(...dirResults.errors);
      results.passed = false;
    }

    // Проверяем файлы
    const requiredFiles = config.requiredFiles || [];
    const optionalFiles = config.optionalFiles || [];

    results.summary.totalFiles = requiredFiles.length + optionalFiles.length;

    for (const file of requiredFiles) {
      const filePath = path.join(extensionPath, file);
      const exists = fs.existsSync(filePath);

      results.files[file] = {
        path: filePath,
        exists,
        required: true,
        size: exists ? fs.statSync(filePath).size : 0,
      };

      if (exists) {
        results.summary.presentFiles++;
        logger.success(`✅ ${file} - найден (${(results.files[file].size / 1024).toFixed(1)} KB)`);
      } else {
        results.summary.missingFiles++;
        results.errors.push(`Отсутствует обязательный файл: ${file}`);
        results.passed = false;
        logger.error(`❌ ${file} - ОТСУТСТВУЕТ!`);
      }
    }

    // Проверяем опциональные файлы
    for (const file of optionalFiles) {
      const filePath = path.join(extensionPath, file);
      const exists = fs.existsSync(filePath);

      results.files[file] = {
        path: filePath,
        exists,
        required: false,
        size: exists ? fs.statSync(filePath).size : 0,
      };

      if (exists) {
        results.summary.presentFiles++;
        logger.info(`✅ ${file} - найден (опциональный)`);
      } else {
        results.warnings.push(`Опциональный файл отсутствует: ${file}`);
        logger.warn(`⚠️ ${file} - не найден (опциональный)`);
      }
    }

    // Проверяем манифест
    if (results.files['manifest.json']?.exists) {
      const manifestResult = this[PRIVATE.CHECK_MANIFEST]();
      results.manifest = manifestResult;

      if (!manifestResult.valid) {
        results.errors.push(...(manifestResult.errors || []));
        results.passed = false;
      }
    }

    // Проверяем иконки
    const iconResult = this[PRIVATE.CHECK_ICONS]();
    results.icons = iconResult;

    // Итог
    logger.separator();
    logger.info(`📊 ИТОГИ ПРОВЕРКИ:`);
    logger.info(`  📁 Обязательные файлы: ${results.summary.presentFiles}/${results.summary.totalFiles}`);
    logger.info(`  📂 Директории: ${results.summary.presentDirs}/${results.summary.totalDirs}`);
    logger.info(`  ❌ Ошибок: ${results.errors.length}`);
    logger.info(`  ⚠️ Предупреждений: ${results.warnings.length}`);

    if (results.passed) {
      logger.success('✅ Все проверки пройдены успешно!');
    } else {
      logger.error('❌ Обнаружены ошибки. Установка невозможна.');
    }

    return results;
  }

  // ============================================================
  // 6.4. ПРОВЕРКА ДИРЕКТОРИЙ
  // ============================================================

  [PRIVATE.CHECK_DIRECTORIES]() {
    const logger = this[PRIVATE.LOGGER];
    const config = this[PRIVATE.CONFIG];
    const fs = require('fs');
    const path = require('path');

    const results = {
      directories: {},
      totalDirs: 0,
      presentDirs: 0,
      missingDirs: 0,
      errors: [],
      warnings: [],
    };

    const extensionPath = this[PRIVATE.EXTENSION_PATH];
    const requiredDirs = config.requiredDirs || [];

    for (const dir of requiredDirs) {
      const dirPath = path.join(extensionPath, dir);
      const exists = fs.existsSync(dirPath) && fs.statSync(dirPath).isDirectory();

      results.directories[dir] = {
        path: dirPath,
        exists,
      };
      results.totalDirs++;

      if (exists) {
        results.presentDirs++;
        logger.success(`✅ ${dir}/ - существует`);
      } else {
        results.missingDirs++;
        results.errors.push(`Отсутствует директория: ${dir}/`);
        logger.error(`❌ ${dir}/ - ОТСУТСТВУЕТ!`);
      }
    }

    return results;
  }

  // ============================================================
  // 6.5. ПРОВЕРКА МАНИФЕСТА
  // ============================================================

  [PRIVATE.CHECK_MANIFEST]() {
    const logger = this[PRIVATE.LOGGER];
    const fs = require('fs');
    const path = require('path');

    const results = {
      valid: false,
      errors: [],
      warnings: [],
      fields: {},
      version: null,
      permissions: [],
    };

    try {
      const manifestPath = path.join(this[PRIVATE.EXTENSION_PATH], 'manifest.json');
      const content = fs.readFileSync(manifestPath, 'utf8');
      const manifest = JSON.parse(content);

      // Проверяем обязательные поля
      const requiredFields = CONFIG.manifestChecks.requiredFields || [];

      for (const field of requiredFields) {
        const hasField = field in manifest;
        results.fields[field] = hasField;

        if (hasField) {
          logger.success(`✅ ${field}: ${manifest[field]}`);
        } else {
          results.errors.push(`Отсутствует поле манифеста: ${field}`);
          logger.error(`❌ ${field} - ОТСУТСТВУЕТ!`);
        }
      }

      // Проверяем версию манифеста
      if (manifest.manifest_version) {
        if (manifest.manifest_version === 3) {
          results.valid = true;
        } else {
          results.errors.push(`Неверная версия манифеста: ${manifest.manifest_version} (нужно 3)`);
        }
      }

      // Проверяем разрешения
      if (manifest.permissions) {
        results.permissions = manifest.permissions;
        const requiredPermissions = CONFIG.manifestChecks.permissions || [];

        for (const perm of requiredPermissions) {
          if (!manifest.permissions.includes(perm)) {
            results.warnings.push(`Отсутствует разрешение: ${perm}`);
            logger.warn(`⚠️ Разрешение отсутствует: ${perm}`);
          }
        }
      }

      // Сохраняем версию
      results.version = manifest.version || 'unknown';

      results.valid = results.valid && results.errors.length === 0;

      if (results.valid) {
        logger.success(`✅ Манифест валиден (версия ${results.version})`);
      }

      return results;
    } catch (error) {
      results.errors.push(`Ошибка проверки манифеста: ${error.message}`);
      logger.error(`❌ Ошибка манифеста: ${error.message}`);
      return results;
    }
  }

  // ============================================================
  // 6.6. ПРОВЕРКА ИКОНОК
  // ============================================================

  [PRIVATE.CHECK_ICONS]() {
    const logger = this[PRIVATE.LOGGER];
    const fs = require('fs');
    const path = require('path');

    const results = {
      icons: {},
      present: 0,
      total: 0,
      errors: [],
      warnings: [],
    };

    const iconSizes = [
      { size: 16, path: 'icon/icon16.png' },
      { size: 48, path: 'icon/icon48.png' },
      { size: 128, path: 'icon/icon128.png' },
    ];

    const extensionPath = this[PRIVATE.EXTENSION_PATH];

    for (const icon of iconSizes) {
      const iconPath = path.join(extensionPath, icon.path);
      const exists = fs.existsSync(iconPath);

      results.total++;
      results.icons[icon.size] = {
        path: icon.path,
        exists,
        size: exists ? fs.statSync(iconPath).size : 0,
      };

      if (exists) {
        results.present++;
        logger.success(`✅ ${icon.path} - найден (${(results.icons[icon.size].size / 1024).toFixed(1)} KB)`);
      } else {
        results.errors.push(`Отсутствует иконка: ${icon.path}`);
        logger.warn(`⚠️ ${icon.path} - не найден`);
      }
    }

    return results;
  }

  // ============================================================
  // 6.7. СОЗДАНИЕ УСТАНОВОЧНЫХ СКРИПТОВ
  // ============================================================

  [PRIVATE._createInstallScripts]() {
    const logger = this[PRIVATE.LOGGER];
    const fs = require('fs');
    const path = require('path');

    const extensionPath = this[PRIVATE.EXTENSION_PATH];

    logger.info('📝 Создание установочных скриптов...');

    // Создаем .bat для Windows
    this[PRIVATE.CREATE_BAT]();

    // Создаем .sh для Linux/Mac
    this[PRIVATE.CREATE_SH]();

    // Создаем .ps1 для PowerShell
    this[PRIVATE.CREATE_PS1]();

    logger.success('✅ Установочные скрипты созданы');
  }

  // ============================================================
  // 6.8. СОЗДАНИЕ .BAT (WINDOWS)
  // ============================================================

  [PRIVATE.CREATE_BAT]() {
    const logger = this[PRIVATE.LOGGER];
    const fs = require('fs');
    const path = require('path');

    try {
      const extensionPath = this[PRIVATE.EXTENSION_PATH];
      const batPath = path.join(process.cwd(), CONFIG.batFilename);

      const content = `@echo off
chcp 65001 > nul
title Установка расширения Bookmarks Manager Pro

echo ╔══════════════════════════════════════════════════════════════╗
echo ║         📚 УСТАНОВКА РАСШИРЕНИЯ CHROME                     ║
echo ╚══════════════════════════════════════════════════════════════╝
echo.
echo 📂 Путь к расширению: ${extensionPath}
echo.
echo ═══════════════════════════════════════════════════════════════
echo.
echo 📋 ИНСТРУКЦИЯ ПО УСТАНОВКЕ:
echo.
echo 1. Откройте Chrome и перейдите по адресу: chrome://extensions/
echo 2. Включите "Режим разработчика" (переключатель в правом верхнем углу)
echo 3. Нажмите кнопку "Загрузить распакованное расширение"
echo 4. Выберите папку:
echo    ${extensionPath}
echo.
echo ═══════════════════════════════════════════════════════════════
echo.
echo Открываем chrome://extensions/...
start chrome://extensions/
echo.
echo ✅ Страница расширений открыта
echo.
echo ⚠️ После установки расширение появится в панели расширений
echo 📌 Горячая клавиша: Ctrl+Shift+B для открытия менеджера
echo.
echo ═══════════════════════════════════════════════════════════════
echo.
pause
`;

      fs.writeFileSync(batPath, content, 'utf8');
      logger.success(`✅ Создан файл: ${CONFIG.batFilename}`);
    } catch (error) {
      logger.error(`❌ Ошибка создания .bat: ${error.message}`);
    }
  }

  // ============================================================
  // 6.9. СОЗДАНИЕ .SH (LINUX/MAC)
  // ============================================================

  [PRIVATE.CREATE_SH]() {
    const logger = this[PRIVATE.LOGGER];
    const fs = require('fs');
    const path = require('path');

    try {
      const extensionPath = this[PRIVATE.EXTENSION_PATH];
      const shPath = path.join(process.cwd(), CONFIG.shFilename);

      const content = `#!/bin/bash
# Установка расширения Bookmarks Manager Pro

echo "╔══════════════════════════════════════════════════════════════╗"
echo "║         📚 УСТАНОВКА РАСШИРЕНИЯ CHROME                     ║"
echo "╚══════════════════════════════════════════════════════════════╝"
echo ""
echo "📂 Путь к расширению: ${extensionPath}"
echo ""
echo "═══════════════════════════════════════════════════════════════"
echo ""
echo "📋 ИНСТРУКЦИЯ ПО УСТАНОВКЕ:"
echo ""
echo "1. Откройте Chrome и перейдите по адресу: chrome://extensions/"
echo "2. Включите \"Режим разработчика\" (переключатель в правом верхнем углу)"
echo "3. Нажмите кнопку \"Загрузить распакованное расширение\""
echo "4. Выберите папку:"
echo "   ${extensionPath}"
echo ""
echo "═══════════════════════════════════════════════════════════════"
echo ""
echo "Открываем chrome://extensions/..."

# Открываем в зависимости от ОС
if [[ "$OSTYPE" == "darwin"* ]]; then
  open "chrome://extensions/"
elif [[ "$OSTYPE" == "linux-gnu"* ]]; then
  if command -v google-chrome &> /dev/null; then
    google-chrome "chrome://extensions/"
  elif command -v chromium-browser &> /dev/null; then
    chromium-browser "chrome://extensions/"
  else
    echo "⚠️ Не удалось открыть браузер. Откройте вручную: chrome://extensions/"
  fi
fi

echo ""
echo "✅ Страница расширений открыта"
echo ""
echo "⚠️ После установки расширение появится в панели расширений"
echo "📌 Горячая клавиша: Ctrl+Shift+B для открытия менеджера"
echo ""
echo "═══════════════════════════════════════════════════════════════"
echo ""

read -p "Нажмите Enter для выхода..."
`;

      fs.writeFileSync(shPath, content, 'utf8');

      // Делаем исполняемым на Unix системах
      if (process.platform !== 'win32') {
        fs.chmodSync(shPath, 0o755);
      }

      logger.success(`✅ Создан файл: ${CONFIG.shFilename}`);
    } catch (error) {
      logger.error(`❌ Ошибка создания .sh: ${error.message}`);
    }
  }

  // ============================================================
  // 6.10. СОЗДАНИЕ .PS1 (POWERSHELL)
  // ============================================================

  [PRIVATE.CREATE_PS1]() {
    const logger = this[PRIVATE.LOGGER];
    const fs = require('fs');
    const path = require('path');

    try {
      const extensionPath = this[PRIVATE.EXTENSION_PATH];
      const ps1Path = path.join(process.cwd(), CONFIG.ps1Filename);

      const content = `# Установка расширения Bookmarks Manager Pro
Write-Host "╔══════════════════════════════════════════════════════════════╗" -ForegroundColor Cyan
Write-Host "║         📚 УСТАНОВКА РАСШИРЕНИЯ CHROME                     ║" -ForegroundColor Cyan
Write-Host "╚══════════════════════════════════════════════════════════════╝" -ForegroundColor Cyan
Write-Host ""
Write-Host "📂 Путь к расширению: ${extensionPath}" -ForegroundColor Yellow
Write-Host ""
Write-Host "═══════════════════════════════════════════════════════════════" -ForegroundColor Gray
Write-Host ""
Write-Host "📋 ИНСТРУКЦИЯ ПО УСТАНОВКЕ:" -ForegroundColor Green
Write-Host ""
Write-Host "1. Откройте Chrome и перейдите по адресу: chrome://extensions/"
Write-Host "2. Включите ""Режим разработчика"" (переключатель в правом верхнем углу)"
Write-Host "3. Нажмите кнопку ""Загрузить распакованное расширение"""
Write-Host "4. Выберите папку:"
Write-Host "   ${extensionPath}"
Write-Host ""
Write-Host "═══════════════════════════════════════════════════════════════" -ForegroundColor Gray
Write-Host ""
Write-Host "Открываем chrome://extensions/..." -ForegroundColor Yellow
Start-Process "chrome://extensions/"
Write-Host ""
Write-Host "✅ Страница расширений открыта" -ForegroundColor Green
Write-Host ""
Write-Host "⚠️ После установки расширение появится в панели расширений" -ForegroundColor Yellow
Write-Host "📌 Горячая клавиша: Ctrl+Shift+B для открытия менеджера" -ForegroundColor Yellow
Write-Host ""
Write-Host "═══════════════════════════════════════════════════════════════" -ForegroundColor Gray
Write-Host ""
Read-Host "Нажмите Enter для выхода"
`;

      fs.writeFileSync(ps1Path, content, 'utf8');
      logger.success(`✅ Создан файл: ${CONFIG.ps1Filename}`);
    } catch (error) {
      logger.error(`❌ Ошибка создания .ps1: ${error.message}`);
    }
  }

  // ============================================================
  // 6.11. ОПРЕДЕЛЕНИЕ ПЛАТФОРМЫ
  // ============================================================

  [PRIVATE.GET_PLATFORM]() {
    const platform = process.platform;

    if (platform === 'win32') {
      return 'windows';
    } else if (platform === 'darwin') {
      return 'macos';
    } else if (platform === 'linux') {
      return 'linux';
    } else {
      return 'unknown';
    }
  }

  // ============================================================
  // 6.12. ПЕЧАТЬ ЗАГОЛОВКА
  // ============================================================

  [PRIVATE.PRINT_HEADER]() {
    const logger = this[PRIVATE.LOGGER];
    const config = this[PRIVATE.CONFIG];

    logger.header(`ИНСТАЛЛЕР РАСШИРЕНИЯ v${config.version}`);
    console.log('╔═══════════════════════════════════════════════════════════════════════════════╗');
    console.log('║              📦 EXTENSION INSTALLER (100% СИМВОЛЫ)                          ║');
    console.log('╠═══════════════════════════════════════════════════════════════════════════════╣');
    console.log('║  📋 Автоматическая проверка всех файлов расширения                          ║');
    console.log('║  🔑 Полная изоляция через приватные символы                                 ║');
    console.log('║  🔓 Публичные символы через Symbol.for                                      ║');
    console.log('║  📊 Проверка манифеста и всех разрешений                                    ║');
    console.log('║  🖼️  Проверка иконок и ресурсов                                            ║');
    console.log('║  📝 Создание установочных скриптов (.bat, .sh, .ps1)                       ║');
    console.log('║  🚀 Готов к установке в браузере                                           ║');
    console.log('╚═══════════════════════════════════════════════════════════════════════════════╝');
    console.log();
  }

  // ============================================================
  // 6.13. ПЕЧАТЬ ИНСТРУКЦИЙ
  // ============================================================

  [PRIVATE.PRINT_INSTRUCTIONS]() {
    const logger = this[PRIVATE.LOGGER];
    const state = this[PRIVATE.STATE];
    const checkResults = state[PRIVATE.CHECK_RESULTS];

    logger.header('ИНСТРУКЦИЯ ПО УСТАНОВКЕ');

    if (!checkResults.passed) {
      console.log('❌ ${colors.red}ОБНАРУЖЕНЫ ОШИБКИ!${colors.reset}');
      console.log();
      console.log('Исправьте следующие проблемы:');
      for (const error of checkResults.errors) {
        console.log(`  ❌ ${error}`);
      }
      console.log();
      console.log('После исправления запустите скрипт снова.');
      return;
    }

    const extensionPath = this[PRIVATE.EXTENSION_PATH];
    const platform = this[PRIVATE.PLATFORM];

    console.log('📋 ${colors.bold}ШАГ 1:${colors.reset} Откройте страницу расширений Chrome');
    console.log('   ${colors.blue}chrome://extensions/${colors.reset}');
    console.log();

    console.log('📋 ${colors.bold}ШАГ 2:${colors.reset} Включите "Режим разработчика"');
    console.log('   Переключатель в правом верхнем углу страницы');
    console.log();

    console.log('📋 ${colors.bold}ШАГ 3:${colors.reset} Нажмите "Загрузить распакованное расширение"');
    console.log('   Кнопка в левом верхнем углу страницы');
    console.log();

    console.log('📋 ${colors.bold}ШАГ 4:${colors.reset} Выберите папку расширения');
    console.log(`   📂 ${extensionPath}`);
    console.log();

    console.log('📋 ${colors.bold}ШАГ 5:${colors.reset} Проверьте установку`);
    console.log('   Расширение появится в панели расширений (иконка 📚)');
    console.log('   📌 Горячая клавиша: ${colors.yellow}Ctrl+Shift+B${colors.reset}');
    console.log();

    if (platform === 'windows') {
      console.log('🚀 ${colors.green}БЫСТРЫЙ СТАРТ:${colors.reset}');
      console.log(`   Запустите ${CONFIG.batFilename} для открытия страницы расширений`);
      console.log();
    } else if (platform === 'macos' || platform === 'linux') {
      console.log('🚀 ${colors.green}БЫСТРЫЙ СТАРТ:${colors.reset}');
      console.log(`   Запустите ${CONFIG.shFilename} для открытия страницы расширений`);
      console.log();
    }

    console.log('⚡ ${colors.green}Проверка пройдена успешно!${colors.reset}');
    console.log(`   ✅ Обязательных файлов: ${checkResults.summary.presentFiles}/${checkResults.summary.totalFiles}`);
    console.log(`   📂 Директорий: ${checkResults.summary.presentDirs}/${checkResults.summary.totalDirs}`);
    console.log(`   📊 Всего файлов: ${Object.keys(checkResults.files).length}`);
  }

  // ============================================================
  // 6.14. ПЕЧАТЬ ФУТЕРА
  // ============================================================

  [PRIVATE.PRINT_FOOTER]() {
    const logger = this[PRIVATE.LOGGER];
    const config = this[PRIVATE.CONFIG];
    const state = this[PRIVATE.STATE];
    const checkResults = state[PRIVATE.CHECK_RESULTS];

    logger.separator();

    if (checkResults.passed) {
      console.log('✅ ${colors.green}УСТАНОВКА ГОТОВА!${colors.reset}');
    } else {
      console.log('❌ ${colors.red}ОБНАРУЖЕНЫ ОШИБКИ!${colors.reset}');
    }

    console.log();
    console.log('📊 ${colors.bold}СТАТИСТИКА:${colors.reset}');
    console.log(`   📁 Файлов: ${checkResults.summary.presentFiles}/${checkResults.summary.totalFiles}`);
    console.log(`   📂 Директорий: ${checkResults.summary.presentDirs}/${checkResults.summary.totalDirs}`);
    console.log(`   ❌ Ошибок: ${checkResults.errors.length}`);
    console.log(`   ⚠️ Предупреждений: ${checkResults.warnings.length}`);

    if (checkResults.manifest && checkResults.manifest.version) {
      console.log(`   📦 Версия расширения: ${checkResults.manifest.version}`);
    }

    console.log();
    console.log(`📌 ${config.name} v${config.version} (${config.build})`);
    console.log('🔑 100% СИМВОЛЫ - Полная изоляция');
    console.log();
  }

  // ============================================================
  // 6.15. ПЕЧАТЬ СТАТУСА
  // ============================================================

  [PRIVATE.PRINT_STATUS](message, type = 'info') {
    const logger = this[PRIVATE.LOGGER];
    logger[type](message);
  }

  // ============================================================
  // 6.16. ВАЛИДАЦИЯ
  // ============================================================

  [PRIVATE.VALIDATE]() {
    const state = this[PRIVATE.STATE];
    const checkResults = state[PRIVATE.CHECK_RESULTS];

    return {
      valid: checkResults.passed,
      errors: checkResults.errors,
      warnings: checkResults.warnings,
    };
  }

  // ============================================================
  // 6.17. ЭКСПОРТ СИМВОЛОВ
  // ============================================================

  [PRIVATE.EXPORT_SYMBOLS]() {
    if (typeof global !== 'undefined') {
      global.__INSTALLER_SYMBOLS = {
        PRIVATE: { ...PRIVATE },
        PUBLIC: { ...PUBLIC },
      };

      global[PUBLIC.INSTANCE] = this;
      global.__installer = this;
    }
  }

  // ============================================================
  // 6.18. ПУБЛИЧНЫЕ МЕТОДЫ
  // ============================================================

  [PUBLIC.GET_STATE]() {
    const state = this[PRIVATE.STATE];
    return {
      initialized: state[PRIVATE.INITIALIZED],
      destroyed: state[PRIVATE.IS_DESTROYED],
      platform: this[PRIVATE.PLATFORM],
      extensionPath: this[PRIVATE.EXTENSION_PATH],
      checkResults: state[PRIVATE.CHECK_RESULTS],
    };
  }

  [PUBLIC.GET_REPORT]() {
    const state = this[PRIVATE.STATE];
    const checkResults = state[PRIVATE.CHECK_RESULTS];

    return {
      passed: checkResults.passed,
      errors: checkResults.errors,
      warnings: checkResults.warnings,
      summary: checkResults.summary,
      files: checkResults.files,
      manifest: checkResults.manifest,
      icons: checkResults.icons,
      directories: checkResults.directories,
      platform: this[PRIVATE.PLATFORM],
      extensionPath: this[PRIVATE.EXTENSION_PATH],
      timestamp: Date.now(),
    };
  }

  [PUBLIC.CHECK]() {
    return this[PRIVATE.CHECK_FILES]();
  }

  [PUBLIC.INSTALL]() {
    const state = this[PRIVATE.STATE];
    const checkResults = state[PRIVATE.CHECK_RESULTS];

    if (!checkResults.passed) {
      this[PRIVATE.LOGGER].error('❌ Проверка не пройдена. Установка невозможна.');
      return {
        success: false,
        error: 'Проверка не пройдена',
        details: checkResults.errors,
      };
    }

    this[PRIVATE._createInstallScripts]();

    return {
      success: true,
      extensionPath: this[PRIVATE.EXTENSION_PATH],
      platform: this[PRIVATE.PLATFORM],
      scripts: {
        bat: CONFIG.batFilename,
        sh: CONFIG.shFilename,
        ps1: CONFIG.ps1Filename,
      },
    };
  }

  [PUBLIC.DESTROY]() {
    const state = this[PRIVATE.STATE];
    const logger = this[PRIVATE.LOGGER];

    if (state[PRIVATE.IS_DESTROYED]) {
      logger.warn('⚠️ Инсталлер уже уничтожен');
      return;
    }

    logger.info('🧹 Очистка инсталлера...');

    state[PRIVATE.IS_DESTROYED] = true;
    state[PRIVATE.INITIALIZED] = false;

    // Очищаем глобальные ссылки
    if (typeof global !== 'undefined') {
      delete global[PUBLIC.INSTANCE];
      delete global.__installer;
      delete global.__INSTALLER_SYMBOLS;
    }

    logger.success('✅ Инсталлер уничтожен');
  }

  [PUBLIC.INIT]() {
    return this[PRIVATE.INIT]();
  }
}

// ============================================================
// 7. СОЗДАНИЕ ИНСТАНСА
// ============================================================

const installer = new Installer();

// ============================================================
// 8. ЭКСПОРТЫ
// ============================================================

export {
  Installer,
  installer,
  PRIVATE as INSTALLER_PRIVATE,
  PUBLIC as INSTALLER_PUBLIC,
  CONFIG as INSTALLER_CONFIG,
};

export default installer;

// ============================================================
// 9. АВТОМАТИЧЕСКИЙ ЗАПУСК
// ============================================================

if (typeof require !== 'undefined' && require.main === module) {
  // Запускаем автоматически при запуске через Node.js
  console.log('🚀 Запуск инсталлера...');
}

// ============================================================
// 10. СТАТИСТИКА СИМВОЛОВ
// ============================================================

if (typeof console !== 'undefined') {
  const privateCount = Object.keys(PRIVATE).length;
  const publicCount = Object.keys(PUBLIC).length;

  console.log(`📊 Installer: ${privateCount} приватных, ${publicCount} публичных символов`);
  console.log(`📦 Всего символов: ${privateCount + publicCount}`);
  console.log(`📋 Версия: ${CONFIG.version} (${CONFIG.build})`);
  console.log('');
  console.log('📌 ИСПОЛЬЗОВАНИЕ:');
  console.log('  node install-extension.js - запустить автоматически');
  console.log('  installer[PUBLIC.CHECK]() - проверить файлы');
  console.log('  installer[PUBLIC.INSTALL]() - создать скрипты установки');
  console.log('  installer[PUBLIC.GET_REPORT]() - получить отчет');
  console.log('');
}

// ============================================================
// 11. ОБРАБОТКА ОШИБОК
// ============================================================

process.on('uncaughtException', (error) => {
  console.error('❌ Необработанная ошибка:', error);
  process.exit(1);
});

process.on('unhandledRejection', (reason, promise) => {
  console.error('❌ Необработанный rejection:', reason);
  process.exit(1);
});

// ============================================================
// 12. ЗАВЕРШЕНИЕ
// ============================================================

console.log('✅ Installer готов к использованию');
console.log(`📂 Путь к расширению: ${installer[PUBLIC.GET_STATE]().extensionPath}`);
console.log('📌 Запустите: node install-extension.js для автоматической установки');
