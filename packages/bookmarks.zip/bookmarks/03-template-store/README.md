# ⚡ High-Frequency Stream with Global Store

## 📦 Архитектура (100% СИМВОЛЫ)

```
┌─────────────────────────────────────────────────────────────────┐
│                    GLOBAL STORE (ЯДРО)                         │
│  ┌─────────────────────────────────────────────────────────┐  │
│  │  🗄️ TABLES (Map)                                       │  │
│  │  • projects   • tasks   • metrics   • messages         │  │
│  └─────────────────────────────────────────────────────────┘  │
│  ┌─────────────────────────────────────────────────────────┐  │
│  │  🔗 MASTER-DETAIL (Map)                                │  │
│  │  • projects → tasks (projectId)                        │  │
│  │  • metrics → messages (metricId)                       │  │
│  └─────────────────────────────────────────────────────────┘  │
│  ┌─────────────────────────────────────────────────────────┐  │
│  │  📡 MESSAGE BROKER                                     │  │
│  │  • channels: Map<string, Channel>                      │  │
│  │  • subscribers: Map<string, Map<id, callback>>         │  │
│  │  • history: Message[]                                  │  │
│  └─────────────────────────────────────────────────────────┘  │
│  ┌─────────────────────────────────────────────────────────┐  │
│  │  🔄 SYNC ENGINE                                        │  │
│  │  • syncQueue: Operation[]                              │  │
│  │  • syncHandlers: Map<type, Set<handler>>               │  │
│  │  • debounce: 100ms                                     │  │
│  └─────────────────────────────────────────────────────────┘  │
│  ┌─────────────────────────────────────────────────────────┐  │
│  │  🔒 TRANSACTIONS                                       │  │
│  │  • undoStack: Snapshot[]                               │  │
│  │  • redoStack: Snapshot[]                               │  │
│  │  • maxHistory: 100                                     │  │
│  └─────────────────────────────────────────────────────────┘  │
│  ┌─────────────────────────────────────────────────────────┐  │
│  │  🎯 SELECTIONS & HIGHLIGHTS                            │  │
│  │  • selections: Map<table, rowId>                       │  │
│  │  • highlights: Map<table, Set<rowId>>                  │  │
│  └─────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────┘
│
▼
┌─────────────────────────────────────────────────────────────────┐
│                   SECURE STORE (ОБЁРТКА)                       │
│  ┌─────────────────────────────────────────────────────────┐  │
│  │  📊 Stream Metrics                                      │  │
│  │  • liveMetrics: Metric[]                                │  │
│  │  • streamStatus: 'playing'|'paused'|'disconnected'     │  │
│  │  • totalBatches: number                                 │  │
│  └─────────────────────────────────────────────────────────┘  │
│  ┌─────────────────────────────────────────────────────────┐  │
│  │  💬 Messages                                            │  │
│  │  • messages: Message[]                                  │  │
│  │  • sendMessage(message)                                 │  │
│  │  • broadcastMessage(message)                            │  │
│  │  • replaceMessages(messages)                            │  │
│  └─────────────────────────────────────────────────────────┘  │
│  ┌─────────────────────────────────────────────────────────┐  │
│  │  🔌 BroadcastChannel                                    │  │
│  │  • channelName: 'high_frequency_stream_channel'         │  │
│  │  • cross-tab synchronization                            │  │
│  └─────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────┘
│
▼
┌─────────────────────────────────────────────────────────────────┐
│                   CONSUMERS (ВИЗУАЛИЗАЦИЯ)                     │
│  ┌─────────────────────────┐  ┌─────────────────────────┐    │
│  │  🟢 Vue 3 Consumer      │  │  ⚛️ React Consumer      │    │
│  │  • reactive state       │  │  • hooks-based          │    │
│  │  • tabs: metrics/msgs   │  │  • tabs: metrics/msgs   │    │
│  │  • sendMessage()        │  │  • sendMessage()        │    │
│  └─────────────────────────┘  └─────────────────────────┘    │
└─────────────────────────────────────────────────────────────────┘
│
▼
┌─────────────────────────────────────────────────────────────────┐
│                   BOOKMARKLETS (ЗАПУСК)                        │
│  ┌─────────────────────────┐  ┌─────────────────────────┐    │
│  │  📜 Vue Bookmarklet     │  │  📜 React Bookmarklet   │    │
│  │  • минифицированный     │  │  • минифицированный     │    │
│  │  • кэшированный         │  │  • кэшированный         │    │
│  └─────────────────────────┘  └─────────────────────────┘    │
└─────────────────────────────────────────────────────────────────┘
```

## 🔑 Символы (100% изоляция)

### Global Store (PRIVATE) — 47 символов
```javascript
// Основные символы
VERSION, BUILD, NAME, CONFIG, STATE,

// Данные
TABLES, RELATIONS, MASTER_DETAIL, SELECTIONS, HIGHLIGHTS, FILTERS, SORTS, PAGINATION,

// Брокер
MESSAGE_BROKER, SUBSCRIBERS, MESSAGE_QUEUE, MESSAGE_HISTORY, CHANNELS,

// Синхронизация
SYNC_QUEUE, SYNC_IN_PROGRESS, LAST_SYNC, SYNC_HANDLERS,

// Транзакции
TRANSACTIONS, TRANSACTION_STACK, UNDO_STACK, REDO_STACK,

// Таблицы
CREATE_TABLE, DROP_TABLE, GET_TABLE, LIST_TABLES, CLEAR_TABLE,

// Данные
INSERT, UPDATE, DELETE, SELECT, QUERY,

// Мастер-детейл
SET_MASTER, GET_DETAILS, LINK_TABLES, UNLINK_TABLES,

// Выделение
SELECT_ROW, CLEAR_SELECTION, GET_SELECTION, HIGHLIGHT_ROW, CLEAR_HIGHLIGHTS,

// Фильтрация
SET_FILTER, CLEAR_FILTERS, SET_SORT, CLEAR_SORTS, SET_PAGINATION,

// Брокер
PUBLISH, SUBSCRIBE, UNSUBSCRIBE, GET_MESSAGES, CLEAR_MESSAGES, CREATE_CHANNEL, DELETE_CHANNEL,

// Синхронизация
SYNC, QUEUE_OPERATION, PROCESS_QUEUE, REGISTER_SYNC_HANDLER,

// Транзакции
BEGIN_TRANSACTION, COMMIT_TRANSACTION, ROLLBACK_TRANSACTION, UNDO, REDO,

// Валидация
VALIDATE, SANITIZE,

// Экспорт
EXPORT_SYMBOLS,
```

### Global Store (PUBLIC) — 38 символов
```javascript
INSTANCE, STATE, CONFIG, VERSION, TABLES, BROKER,

// Таблицы
CREATE_TABLE, DROP_TABLE, GET_TABLE, LIST_TABLES, CLEAR_TABLE,

// Данные
INSERT, UPDATE, DELETE, SELECT, QUERY,

// Мастер-детейл
SET_MASTER, GET_DETAILS, LINK_TABLES, UNLINK_TABLES,

// Выделение
SELECT_ROW, CLEAR_SELECTION, GET_SELECTION, HIGHLIGHT_ROW, CLEAR_HIGHLIGHTS,

// Фильтрация
SET_FILTER, CLEAR_FILTERS, SET_SORT, CLEAR_SORTS, SET_PAGINATION,

// Брокер
PUBLISH, SUBSCRIBE, UNSUBSCRIBE, GET_MESSAGES, CLEAR_MESSAGES, CREATE_CHANNEL, DELETE_CHANNEL,

// Синхронизация
SYNC, REGISTER_SYNC_HANDLER,

// Транзакции
BEGIN, COMMIT, ROLLBACK, UNDO, REDO,

// Утилиты
INIT, DESTROY, GET_STATE, HEALTH_CHECK,
```

### Secure Store (PRIVATE) — 20 символов
```javascript
STORE, STATE, CONFIG, VERSION, BUILD, INITIALIZED, IS_DESTROYED,
METRICS, STATUS, BATCHES, MESSAGES, LAST_UPDATE,
SUBSCRIBERS, CHANNEL,
VALIDATE, SANITIZE, SECURE,
INIT, DESTROY, NOTIFY, GET_STATE, SET_STATE, UPDATE_STATS, EXPORT_SYMBOLS,
SEND_MESSAGE, BROADCAST_MESSAGE, GET_MESSAGES, CLEAR_MESSAGES, REPLACE_MESSAGES,
HANDLE_INCOMING, MESSAGE_HANDLER,
```

### Secure Store (PUBLIC) — 12 символов
```javascript
STORE, STATE, CONFIG, VERSION, METRICS, STATUS,
SEND, BROADCAST, GET_MESSAGES, CLEAR_MESSAGES, REPLACE_MESSAGES,
SUBSCRIBE, HEALTH,
```

## 📊 Статистика символов

| Модуль | PRIVATE | PUBLIC | ВСЕГО |
|--------|---------|--------|-------|
| **Global Store** | 47 | 38 | **85** |
| **Secure Store** | 20 | 12 | **32** |
| **Stream Service** | 21 | 10 | **31** |
| **Vue Consumer** | 35 | 12 | **47** |
| **React Consumer** | 35 | 12 | **47** |
| **Bookmarklets** | 28 | 12 | **40** |
| **ИТОГО** | **186** | **96** | **282** |

## 🚀 Быстрый старт

### Установка
```bash
npm install
npm run serve
# Откройте http://localhost:3000
```

### Демо мастер-детейл
```bash
# Откройте в браузере
http://localhost:3000/demo-master-detail.html
```

## 📋 Основные команды

### Global Store
```javascript
// Доступ к хранилищу
const store = window.__globalStore;

// Таблицы
store.createTable('projects', { schema: { ... } });
store.insert('projects', { id: '1', name: 'Project' });
store.select('projects', { where: { status: 'active' } });

// Мастер-детейл
store.linkTables('projects', 'tasks', 'projectId');
store.setMaster('projects', 'projectId');
const tasks = store.getDetails('projects', 'projectId');

// Брокер
store.publish('channel', { type: 'event', payload: data });
store.subscribe('channel', (msg) => console.log(msg));

// Транзакции
store.beginTransaction('update');
store.update('projects', { status: 'done' }, { id: '1' });
store.commitTransaction();
store.undo();

// Выделение
store.selectRow('projects', '1');
store.highlightRow('projects', '2', true);
```

### Secure Store
```javascript
// Доступ
const store = window.__store;

// Метрики
store.appendDataBatch([{ id: 1, ts: Date.now(), val: 42 }]);
store.setStatus('playing');

// Сообщения
store.sendMessage({ text: 'Hello', type: 'user' });
store.broadcastMessage({ text: 'Broadcast!' });
store.getMessages(20);
store.replaceMessages([...restoredMessages]);

// Подписка
store.subscribe((state) => console.log(state));

// Доступ к GlobalStore
store.getGlobalStore();
```

### Консюмеры
```javascript
// Vue
window.__mountVueConsumer('#app', { theme: 'dark' });

// React
window.__mountReactConsumer('#app', { theme: 'dark' });
```

### Букмарклеты
```javascript
// Получить минифицированный букмарклет
const vueBookmarklet = await window.__getVueBookmarkletMinifiedCached();
const reactBookmarklet = await window.__getReactBookmarkletMinifiedCached();

// Очистить кэш
window.__clearVueBookmarkletCache();
window.__clearReactBookmarkletCache();
```

## 🏗️ Структура проекта

```
src/
├── core/
│   ├── global-store.js    # 🌍 Глобальное хранилище (85 символов)
│   ├── store.js           # 📦 Безопасное хранилище (32 символа)
│   ├── stream-service.js  # 📡 Потоковый сервис (31 символ)
│   └── security.js        # 🛡️ Безопасность
├── consumers/
│   ├── vue-consumer.js    # 🟢 Vue 3 (47 символов)
│   ├── react-consumer.js  # ⚛️ React (47 символов)
│   └── shared/
│       ├── styles.js      # 🎨 Общие стили
│       └── mount-helper.js # 🔧 Помощник монтирования
├── bookmarklets/
│   ├── vue-bookmarklet.js    # 📜 Vue букмарклет
│   ├── react-bookmarklet.js  # 📜 React букмарклет
│   └── install-store.js      # 📦 Установка Store
├── modules/
│   ├── bookmarklets.js    # 📦 Единый модуль (40 символов)
│   ├── vue-bookmarklet.js # 🟢 Vue модуль
│   └── react-bookmarklet.js # ⚛️ React модуль
└── utils/
    ├── minify.js          # 📦 Минификация
    └── string-escape.js   # 🔧 Экранирование строк
```

## 🔒 Безопасность

- **100% СИМВОЛЫ** — полная изоляция через приватные символы
- **Публичные символы** — доступ через `Symbol.for()`
- **Валидация** — всех входных данных
- **Санитизация** — всех выходных данных
- **Secure Context** — только HTTPS/localhost
- **CSP-безопасность** — без `eval` и инлайн-скриптов

## 📚 Документация

- [Global Store API](./docs/global-store.md)
- [Secure Store API](./docs/store.md)
- [Stream Service API](./docs/stream-service.md)
- [Consumers Guide](./docs/consumers.md)
- [Bookmarklets Guide](./docs/bookmarklets.md)

## 📄 Лицензия

MIT © 2026 High-Frequency Stream Team
