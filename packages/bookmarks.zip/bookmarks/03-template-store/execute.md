```js
// Проверяем все источники дублирования
console.log('🔍 Проверка дублирования getStreamService:');

// 1. Проверяем bookmarklets.js
const bmModule = await import('./src/modules/bookmarklets.js');
console.log('📦 bookmarklets.js:', Object.keys(bmModule.default));

// 2. Проверяем vue-bookmarklet.js
const vueModule = await import('./src/modules/vue-bookmarklet.js');
console.log('📦 vue-bookmarklet.js:', Object.keys(vueModule));

// 3. Проверяем react-bookmarklet.js
const reactModule = await import('./src/modules/react-bookmarklet.js');
console.log('📦 react-bookmarklet.js:', Object.keys(reactModule));
```
