// src/core/global-store.js
// 100% СИМВОЛЫ — полная изоляция и безопасность
// Версия: 1.0.2 — Исправлен сеттер для SYNC_QUEUE

// ============================================================
// 1. ПРИВАТНЫЕ СИМВОЛЫ (100% изоляция)
// ============================================================

const PRIVATE = {
  // Основные символы
  VERSION: Symbol('global-store.version'),
  BUILD: Symbol('global-store.build'),
  NAME: Symbol('global-store.name'),
  CONFIG: Symbol('global-store.config'),
  STATE: Symbol('global-store.state'),
  INITIALIZED: Symbol('global-store.initialized'),
  DESTROYED: Symbol('global-store.destroyed'),
  READY: Symbol('global-store.ready'),

  // Данные
  TABLES: Symbol('global-store.tables'),
  RELATIONS: Symbol('global-store.relations'),
  MASTER_DETAIL: Symbol('global-store.master-detail'),
  SELECTIONS: Symbol('global-store.selections'),
  HIGHLIGHTS: Symbol('global-store.highlights'),
  FILTERS: Symbol('global-store.filters'),
  SORTS: Symbol('global-store.sorts'),
  PAGINATION: Symbol('global-store.pagination'),

  // Брокер сообщений
  MESSAGE_BROKER: Symbol('global-store.message-broker'),
  SUBSCRIBERS: Symbol('global-store.subscribers'),
  MESSAGE_QUEUE: Symbol('global-store.message-queue'),
  MESSAGE_HISTORY: Symbol('global-store.message-history'),
  CHANNELS: Symbol('global-store.channels'),

  // Синхронизация
  SYNC_QUEUE: Symbol('global-store.sync-queue'),
  SYNC_IN_PROGRESS: Symbol('global-store.sync-in-progress'),
  LAST_SYNC: Symbol('global-store.last-sync'),
  SYNC_HANDLERS: Symbol('global-store.sync-handlers'),
  SYNC_TIMEOUT: Symbol('global-store.sync-timeout'),

  // Транзакции
  TRANSACTIONS: Symbol('global-store.transactions'),
  TRANSACTION_STACK: Symbol('global-store.transaction-stack'),
  UNDO_STACK: Symbol('global-store.undo-stack'),
  REDO_STACK: Symbol('global-store.redo-stack'),

  // Методы
  INIT: Symbol('global-store.init'),
  DESTROY: Symbol('global-store.destroy'),
  NOTIFY: Symbol('global-store.notify'),
  GET_STATE: Symbol('global-store.get-state'),

  // Таблицы
  CREATE_TABLE: Symbol('global-store.create-table'),
  DROP_TABLE: Symbol('global-store.drop-table'),
  GET_TABLE: Symbol('global-store.get-table'),
  LIST_TABLES: Symbol('global-store.list-tables'),
  CLEAR_TABLE: Symbol('global-store.clear-table'),

  // Данные
  INSERT: Symbol('global-store.insert'),
  UPDATE: Symbol('global-store.update'),
  DELETE: Symbol('global-store.delete'),
  SELECT: Symbol('global-store.select'),
  QUERY: Symbol('global-store.query'),

  // Мастер-детейл
  SET_MASTER: Symbol('global-store.set-master'),
  GET_DETAILS: Symbol('global-store.get-details'),
  LINK_TABLES: Symbol('global-store.link-tables'),
  UNLINK_TABLES: Symbol('global-store.unlink-tables'),

  // Выделение
  SELECT_ROW: Symbol('global-store.select-row'),
  CLEAR_SELECTION: Symbol('global-store.clear-selection'),
  GET_SELECTION: Symbol('global-store.get-selection'),
  HIGHLIGHT_ROW: Symbol('global-store.highlight-row'),
  CLEAR_HIGHLIGHTS: Symbol('global-store.clear-highlights'),

  // Фильтрация и сортировка
  SET_FILTER: Symbol('global-store.set-filter'),
  CLEAR_FILTERS: Symbol('global-store.clear-filters'),
  SET_SORT: Symbol('global-store.set-sort'),
  CLEAR_SORTS: Symbol('global-store.clear-sorts'),
  SET_PAGINATION: Symbol('global-store.set-pagination'),

  // Брокер сообщений
  PUBLISH: Symbol('global-store.publish'),
  SUBSCRIBE: Symbol('global-store.subscribe'),
  UNSUBSCRIBE: Symbol('global-store.unsubscribe'),
  GET_MESSAGES: Symbol('global-store.get-messages'),
  CLEAR_MESSAGES: Symbol('global-store.clear-messages'),
  CREATE_CHANNEL: Symbol('global-store.create-channel'),
  DELETE_CHANNEL: Symbol('global-store.delete-channel'),

  // Синхронизация
  SYNC: Symbol('global-store.sync'),
  QUEUE_OPERATION: Symbol('global-store.queue-operation'),
  PROCESS_QUEUE: Symbol('global-store.process-queue'),
  REGISTER_SYNC_HANDLER: Symbol('global-store.register-sync-handler'),

  // Транзакции
  BEGIN_TRANSACTION: Symbol('global-store.begin-transaction'),
  COMMIT_TRANSACTION: Symbol('global-store.commit-transaction'),
  ROLLBACK_TRANSACTION: Symbol('global-store.rollback-transaction'),
  UNDO: Symbol('global-store.undo'),
  REDO: Symbol('global-store.redo'),
  RESTORE_SNAPSHOT: Symbol('global-store.restore-snapshot'),

  // Статус
  SET_STATUS: Symbol('global-store.set-status'),
  GET_STATUS: Symbol('global-store.get-status'),

  // Валидация
  VALIDATE: Symbol('global-store.validate'),
  SANITIZE: Symbol('global-store.sanitize'),

  // Экспорт
  EXPORT_SYMBOLS: Symbol('global-store.export-symbols'),
};

// ============================================================
// 2. ПУБЛИЧНЫЕ СИМВОЛЫ (доступны через Symbol.for)
// ============================================================

const PUBLIC = {
  INSTANCE: Symbol.for('global-store.instance'),
  STATE: Symbol.for('global-store.state'),
  CONFIG: Symbol.for('global-store.config'),
  VERSION: Symbol.for('global-store.version'),
  TABLES: Symbol.for('global-store.tables'),
  BROKER: Symbol.for('global-store.broker'),

  // Таблицы
  CREATE_TABLE: Symbol.for('global-store.create-table'),
  DROP_TABLE: Symbol.for('global-store.drop-table'),
  GET_TABLE: Symbol.for('global-store.get-table'),
  LIST_TABLES: Symbol.for('global-store.list-tables'),
  CLEAR_TABLE: Symbol.for('global-store.clear-table'),

  // Данные
  INSERT: Symbol.for('global-store.insert'),
  UPDATE: Symbol.for('global-store.update'),
  DELETE: Symbol.for('global-store.delete'),
  SELECT: Symbol.for('global-store.select'),
  QUERY: Symbol.for('global-store.query'),

  // Мастер-детейл
  SET_MASTER: Symbol.for('global-store.set-master'),
  GET_DETAILS: Symbol.for('global-store.get-details'),
  LINK_TABLES: Symbol.for('global-store.link-tables'),
  UNLINK_TABLES: Symbol.for('global-store.unlink-tables'),

  // Выделение
  SELECT_ROW: Symbol.for('global-store.select-row'),
  CLEAR_SELECTION: Symbol.for('global-store.clear-selection'),
  GET_SELECTION: Symbol.for('global-store.get-selection'),
  HIGHLIGHT_ROW: Symbol.for('global-store.highlight-row'),
  CLEAR_HIGHLIGHTS: Symbol.for('global-store.clear-highlights'),

  // Фильтрация
  SET_FILTER: Symbol.for('global-store.set-filter'),
  CLEAR_FILTERS: Symbol.for('global-store.clear-filters'),
  SET_SORT: Symbol.for('global-store.set-sort'),
  CLEAR_SORTS: Symbol.for('global-store.clear-sorts'),
  SET_PAGINATION: Symbol.for('global-store.set-pagination'),

  // Брокер
  PUBLISH: Symbol.for('global-store.publish'),
  SUBSCRIBE: Symbol.for('global-store.subscribe'),
  UNSUBSCRIBE: Symbol.for('global-store.unsubscribe'),
  GET_MESSAGES: Symbol.for('global-store.get-messages'),
  CLEAR_MESSAGES: Symbol.for('global-store.clear-messages'),
  CREATE_CHANNEL: Symbol.for('global-store.create-channel'),
  DELETE_CHANNEL: Symbol.for('global-store.delete-channel'),

  // Синхронизация
  SYNC: Symbol.for('global-store.sync'),
  REGISTER_SYNC_HANDLER: Symbol.for('global-store.register-sync-handler'),

  // Транзакции
  BEGIN: Symbol.for('global-store.begin'),
  COMMIT: Symbol.for('global-store.commit'),
  ROLLBACK: Symbol.for('global-store.rollback'),
  UNDO: Symbol.for('global-store.undo'),
  REDO: Symbol.for('global-store.redo'),

  // Статус
  SET_STATUS: Symbol.for('global-store.set-status'),
  GET_STATUS: Symbol.for('global-store.get-status'),

  // Утилиты
  INIT: Symbol.for('global-store.init'),
  DESTROY: Symbol.for('global-store.destroy'),
  GET_STATE: Symbol.for('global-store.get-state'),
  HEALTH_CHECK: Symbol.for('global-store.health-check'),
};

// ============================================================
// 3. КОНФИГУРАЦИЯ
// ============================================================

const CONFIG = {
  version: '1.0.2',
  build: '2026-07-26',
  name: 'Global Store',
  debug: true,
  maxHistory: 100,
  maxMessages: 500,
  syncDebounce: 100,
  defaultPageSize: 20,
};

// ============================================================
// 4. ЛОГГЕР
// ============================================================

const LOGGER_SYMBOLS = {
  HISTORY: Symbol('logger.history'),
  MAX_HISTORY: Symbol('logger.maxHistory'),
  DEBUG: Symbol('logger.debug'),
  INSTANCE_ID: Symbol('logger.instanceId'),
  LEVEL: Symbol('logger.level'),
};

function createLogger(debug = true, instanceId = 'Global Store') {
  const logState = {
    [LOGGER_SYMBOLS.HISTORY]: [],
    [LOGGER_SYMBOLS.MAX_HISTORY]: 200,
    [LOGGER_SYMBOLS.DEBUG]: debug,
    [LOGGER_SYMBOLS.INSTANCE_ID]: instanceId,
    [LOGGER_SYMBOLS.LEVEL]: debug ? 3 : 2,
  };

  const logMethod = function(level, message, data = null) {
    const levels = { error: 0, warn: 1, info: 2, debug: 3, success: 2 };
    const currentLevel = this[LOGGER_SYMBOLS.LEVEL] || 2;
    const msgLevel = levels[level] || 2;

    if (msgLevel > currentLevel) return;

    const timestamp = new Date().toISOString().slice(11, 23);
    const prefix = `[${timestamp}] [${this[LOGGER_SYMBOLS.INSTANCE_ID]}]`;

    this[LOGGER_SYMBOLS.HISTORY].push({
      timestamp,
      level,
      message,
      data,
      id: Date.now() + Math.random(),
    });

    if (this[LOGGER_SYMBOLS.HISTORY].length > this[LOGGER_SYMBOLS.MAX_HISTORY]) {
      this[LOGGER_SYMBOLS.HISTORY].shift();
    }

    const icons = { error: '❌', warn: '⚠️', info: 'ℹ️', debug: '🔍', success: '✅' };
    const icon = icons[level] || '📌';

    if (data !== null && data !== undefined) {
      console.log(`${icon} ${prefix} ${message}`, data);
    } else {
      console.log(`${icon} ${prefix} ${message}`);
    }
  };

  const boundLog = logMethod.bind(logState);

  const methods = {
    error: (msg, d) => boundLog('error', msg, d),
    warn: (msg, d) => boundLog('warn', msg, d),
    info: (msg, d) => boundLog('info', msg, d),
    debug: (msg, d) => boundLog('debug', msg, d),
    success: (msg, d) => boundLog('success', msg, d),

    header: (title, color = '#636e72') => {
      console.log('%c' + '═'.repeat(70), `color: ${color};`);
      console.log(
        '%c  📦 ' + title,
        'background: #1a1a2e; color: #fff; padding: 4px 12px; border-radius: 4px; font-weight: bold;'
      );
      console.log('%c' + '═'.repeat(70), `color: ${color};`);
    },

    separator: (color = '#636e72') => {
      console.log('%c' + '─'.repeat(70), `color: ${color};`);
    },

    getHistory: function() {
      return [...this[LOGGER_SYMBOLS.HISTORY]];
    },

    clearHistory: function() {
      this[LOGGER_SYMBOLS.HISTORY] = [];
      return this;
    },

    setDebug: function(enabled) {
      this[LOGGER_SYMBOLS.DEBUG] = enabled;
      this[LOGGER_SYMBOLS.LEVEL] = enabled ? 3 : 2;
      return this;
    },
  };

  const logger = {};
  for (const [key, fn] of Object.entries(methods)) {
    logger[key] = fn.bind(logState);
  }

  logger[LOGGER_SYMBOLS.HISTORY] = logState[LOGGER_SYMBOLS.HISTORY];
  logger[LOGGER_SYMBOLS.MAX_HISTORY] = logState[LOGGER_SYMBOLS.MAX_HISTORY];
  logger[LOGGER_SYMBOLS.DEBUG] = logState[LOGGER_SYMBOLS.DEBUG];
  logger[LOGGER_SYMBOLS.INSTANCE_ID] = logState[LOGGER_SYMBOLS.INSTANCE_ID];
  logger[LOGGER_SYMBOLS.LEVEL] = logState[LOGGER_SYMBOLS.LEVEL];

  return logger;
}

// ============================================================
// 5. ВАЛИДАТОР
// ============================================================

const VALIDATOR = {
  [PRIVATE.VALIDATE]: {
    isValidTableName: (name) => {
      return typeof name === 'string' && name.length > 0 && /^[a-zA-Z_][a-zA-Z0-9_]*$/.test(name);
    },

    isValidRow: (row) => {
      if (!row || typeof row !== 'object') return false;
      if (row.constructor && row.constructor.name !== 'Object') return false;
      return true;
    },

    isValidMessage: (message) => {
      if (!message || typeof message !== 'object') return false;
      if (!message.type || typeof message.type !== 'string') return false;
      return true;
    },

    isValidChannel: (channel) => {
      return typeof channel === 'string' && channel.length > 0;
    },
  },

  [PRIVATE.SANITIZE]: {
    sanitizeRow: (row) => {
      if (!row || typeof row !== 'object') return null;
      try {
        const sanitized = {};
        for (const [key, value] of Object.entries(row)) {
          if (typeof value === 'function') continue;
          if (typeof value === 'object' && value !== null) {
            try {
              sanitized[key] = JSON.parse(JSON.stringify(value));
            } catch {
              sanitized[key] = null;
            }
          } else {
            sanitized[key] = value;
          }
        }
        return sanitized;
      } catch {
        return null;
      }
    },

    sanitizeMessage: (message) => {
      if (!message || typeof message !== 'object') return null;
      try {
        return {
          id: message.id || `${Date.now()}_${Math.random().toString(36).substr(2, 6)}`,
          type: String(message.type || 'unknown'),
          payload: message.payload !== undefined ? JSON.parse(JSON.stringify(message.payload)) : null,
          timestamp: message.timestamp || Date.now(),
          source: message.source || 'unknown',
        };
      } catch {
        return null;
      }
    },
  },
};

// ============================================================
// 6. ОСНОВНОЙ КЛАСС GLOBAL_STORE
// ============================================================

class GlobalStore {
  constructor() {
    const _private = new WeakMap();

    const privateData = {
      [PRIVATE.VERSION]: CONFIG.version,
      [PRIVATE.BUILD]: CONFIG.build,
      [PRIVATE.NAME]: CONFIG.name,
      [PRIVATE.CONFIG]: { ...CONFIG },
      [PRIVATE.STATE]: {
        initialized: false,
        destroyed: false,
        ready: false,
        streamStatus: 'disconnected',
        lastUpdate: null,
        _batches: 0,
        _subscribersCount: 0,
        version: CONFIG.version,
      },

      [PRIVATE.TABLES]: new Map(),
      [PRIVATE.RELATIONS]: new Map(),
      [PRIVATE.MASTER_DETAIL]: new Map(),
      [PRIVATE.SELECTIONS]: new Map(),
      [PRIVATE.HIGHLIGHTS]: new Map(),
      [PRIVATE.FILTERS]: new Map(),
      [PRIVATE.SORTS]: new Map(),
      [PRIVATE.PAGINATION]: new Map(),

      [PRIVATE.MESSAGE_BROKER]: {
        channels: new Map(),
        subscribers: new Map(),
        history: [],
        queue: [],
        active: false,
      },
      [PRIVATE.SUBSCRIBERS]: new Map(),
      [PRIVATE.MESSAGE_QUEUE]: [],
      [PRIVATE.MESSAGE_HISTORY]: [],
      [PRIVATE.CHANNELS]: new Map(),

      // ★★★ ИСПРАВЛЕНО: SYNC_QUEUE — МАССИВ ★★★
      [PRIVATE.SYNC_QUEUE]: [],
      [PRIVATE.SYNC_IN_PROGRESS]: false,
      [PRIVATE.LAST_SYNC]: null,
      [PRIVATE.SYNC_HANDLERS]: new Map(),
      [PRIVATE.SYNC_TIMEOUT]: null,

      [PRIVATE.TRANSACTIONS]: new Map(),
      [PRIVATE.TRANSACTION_STACK]: [],
      [PRIVATE.UNDO_STACK]: [],
      [PRIVATE.REDO_STACK]: [],
    };

    _private.set(this, privateData);
    this._private = _private;

    this._logger = createLogger(CONFIG.debug, CONFIG.name);

    this[PRIVATE.INIT]();
  }

  // ============================================================
  // 7. ГЕТТЕРЫ И СЕТТЕРЫ ДЛЯ ПРИВАТНЫХ ДАННЫХ
  // ============================================================

  get [PRIVATE.STATE]() {
    return this._private.get(this)[PRIVATE.STATE];
  }

  get [PRIVATE.CONFIG]() {
    return this._private.get(this)[PRIVATE.CONFIG];
  }

  get [PRIVATE.TABLES]() {
    return this._private.get(this)[PRIVATE.TABLES];
  }

  get [PRIVATE.RELATIONS]() {
    return this._private.get(this)[PRIVATE.RELATIONS];
  }

  get [PRIVATE.MASTER_DETAIL]() {
    return this._private.get(this)[PRIVATE.MASTER_DETAIL];
  }

  get [PRIVATE.SELECTIONS]() {
    return this._private.get(this)[PRIVATE.SELECTIONS];
  }

  get [PRIVATE.HIGHLIGHTS]() {
    return this._private.get(this)[PRIVATE.HIGHLIGHTS];
  }

  get [PRIVATE.FILTERS]() {
    return this._private.get(this)[PRIVATE.FILTERS];
  }

  get [PRIVATE.SORTS]() {
    return this._private.get(this)[PRIVATE.SORTS];
  }

  get [PRIVATE.PAGINATION]() {
    return this._private.get(this)[PRIVATE.PAGINATION];
  }

  get [PRIVATE.MESSAGE_BROKER]() {
    return this._private.get(this)[PRIVATE.MESSAGE_BROKER];
  }

  // ★★★ ИСПРАВЛЕНО: getter и setter для SYNC_QUEUE ★★★
  get [PRIVATE.SYNC_QUEUE]() {
    return this._private.get(this)[PRIVATE.SYNC_QUEUE];
  }

  set [PRIVATE.SYNC_QUEUE](value) {
    this._private.get(this)[PRIVATE.SYNC_QUEUE] = value;
  }

  get [PRIVATE.SYNC_HANDLERS]() {
    return this._private.get(this)[PRIVATE.SYNC_HANDLERS];
  }

  get [PRIVATE.TRANSACTIONS]() {
    return this._private.get(this)[PRIVATE.TRANSACTIONS];
  }

  get [PRIVATE.TRANSACTION_STACK]() {
    return this._private.get(this)[PRIVATE.TRANSACTION_STACK];
  }

  get [PRIVATE.UNDO_STACK]() {
    return this._private.get(this)[PRIVATE.UNDO_STACK];
  }

  get [PRIVATE.REDO_STACK]() {
    return this._private.get(this)[PRIVATE.REDO_STACK];
  }

  // ============================================================
  // 8. ИНИЦИАЛИЗАЦИЯ
  // ============================================================

  [PRIVATE.INIT]() {
    const logger = this._logger;

    logger.header('ИНИЦИАЛИЗАЦИЯ GLOBAL STORE (100% СИМВОЛЫ)');
    logger.info(`📦 Версия: ${CONFIG.version}`);
    logger.info(`📅 Сборка: ${CONFIG.build}`);
    logger.separator();

    this[PRIVATE.STATE].initialized = true;
    this[PRIVATE.STATE].ready = true;

    this[PRIVATE.CREATE_CHANNEL]('default');
    this[PRIVATE.MESSAGE_BROKER].active = true;

    this[PRIVATE.EXPORT_SYMBOLS]();

    logger.success('✅ Global Store инициализирован');
    logger.header('ГОТОВ');
  }

  // ============================================================
  // 9. СТАТУС
  // ============================================================

  [PRIVATE.SET_STATUS](status) {
    const logger = this._logger;
    const validStatuses = ['playing', 'paused', 'disconnected', 'connecting'];

    if (!validStatuses.includes(status)) {
      logger.warn(`⚠️ Некорректный статус: ${status}`);
      return false;
    }

    this[PRIVATE.STATE].streamStatus = status;
    this[PRIVATE.STATE].lastUpdate = Date.now();

    this[PRIVATE.PUBLISH]('store-status', {
      type: 'status-change',
      payload: { status, timestamp: Date.now() },
    });

    this[PRIVATE.NOTIFY]('status-changed', { status });
    logger.debug(`📊 Статус обновлен: ${status}`);
    return true;
  }

  [PRIVATE.GET_STATUS]() {
    return this[PRIVATE.STATE].streamStatus || 'disconnected';
  }

  // ============================================================
  // 10. ТАБЛИЦЫ
  // ============================================================

  [PRIVATE.CREATE_TABLE](name, options = {}) {
    const logger = this._logger;

    if (!VALIDATOR[PRIVATE.VALIDATE].isValidTableName(name)) {
      logger.error(`❌ Некорректное имя таблицы: ${name}`);
      return null;
    }

    if (this[PRIVATE.TABLES].has(name)) {
      logger.warn(`⚠️ Таблица уже существует: ${name}`);
      return this[PRIVATE.TABLES].get(name);
    }

    const table = {
      name,
      schema: options.schema || {},
      data: [],
      indexes: new Map(),
      metadata: {
        created: Date.now(),
        updated: Date.now(),
        version: 1,
        ...options.metadata,
      },
    };

    this[PRIVATE.TABLES].set(name, table);
    logger.success(`✅ Таблица создана: ${name}`);
    this[PRIVATE.NOTIFY]('table-created', { name, table });
    return table;
  }

  [PRIVATE.DROP_TABLE](name) {
    const logger = this._logger;

    if (!this[PRIVATE.TABLES].has(name)) {
      logger.warn(`⚠️ Таблица не найдена: ${name}`);
      return false;
    }

    this[PRIVATE.TABLES].delete(name);
    this[PRIVATE.RELATIONS].delete(name);
    this[PRIVATE.MASTER_DETAIL].delete(name);
    this[PRIVATE.SELECTIONS].delete(name);
    this[PRIVATE.HIGHLIGHTS].delete(name);
    this[PRIVATE.FILTERS].delete(name);
    this[PRIVATE.SORTS].delete(name);
    this[PRIVATE.PAGINATION].delete(name);

    logger.success(`🗑 Таблица удалена: ${name}`);
    this[PRIVATE.NOTIFY]('table-dropped', { name });
    return true;
  }

  [PRIVATE.GET_TABLE](name) {
    if (!this[PRIVATE.TABLES].has(name)) {
      return null;
    }
    return this[PRIVATE.TABLES].get(name);
  }

  [PRIVATE.LIST_TABLES]() {
    return Array.from(this[PRIVATE.TABLES].keys());
  }

  [PRIVATE.CLEAR_TABLE](name) {
    const logger = this._logger;

    const table = this[PRIVATE.GET_TABLE](name);
    if (!table) {
      logger.warn(`⚠️ Таблица не найдена: ${name}`);
      return false;
    }

    table.data = [];
    table.metadata.updated = Date.now();

    logger.success(`🧹 Таблица очищена: ${name}`);
    this[PRIVATE.NOTIFY]('table-cleared', { name });
    return true;
  }

  // ============================================================
  // 11. ДАННЫЕ
  // ============================================================

  [PRIVATE.INSERT](tableName, rows) {
    const logger = this._logger;

    const table = this[PRIVATE.GET_TABLE](tableName);
    if (!table) {
      logger.error(`❌ Таблица не найдена: ${tableName}`);
      return null;
    }

    const rowsArray = Array.isArray(rows) ? rows : [rows];
    const inserted = [];

    for (const row of rowsArray) {
      const sanitized = VALIDATOR[PRIVATE.SANITIZE].sanitizeRow(row);
      if (!sanitized) {
        logger.warn(`⚠️ Некорректная строка пропущена`);
        continue;
      }

      if (!sanitized.id && sanitized.id !== 0) {
        sanitized.id = `${Date.now()}_${Math.random().toString(36).substr(2, 6)}`;
      }

      const exists = table.data.some(r => r.id === sanitized.id);
      if (exists) {
        logger.warn(`⚠️ Строка с ID ${sanitized.id} уже существует`);
        continue;
      }

      table.data.push(sanitized);
      inserted.push(sanitized);
    }

    table.metadata.updated = Date.now();
    table.metadata.version++;

    logger.success(`✅ Вставлено ${inserted.length} строк в ${tableName}`);
    this[PRIVATE.NOTIFY]('data-inserted', { table: tableName, rows: inserted });

    this[PRIVATE.QUEUE_OPERATION]({
      type: 'insert',
      table: tableName,
      rows: inserted,
      timestamp: Date.now(),
    });

    return inserted;
  }

  [PRIVATE.UPDATE](tableName, updates, where) {
    const logger = this._logger;

    const table = this[PRIVATE.GET_TABLE](tableName);
    if (!table) {
      logger.error(`❌ Таблица не найдена: ${tableName}`);
      return null;
    }

    const updated = [];
    const rows = where ? this[PRIVATE.QUERY](tableName, { where }) : table.data;

    for (const row of rows) {
      let shouldUpdate = true;

      if (where && typeof where === 'function') {
        shouldUpdate = where(row);
      } else if (where && typeof where === 'object') {
        for (const [key, value] of Object.entries(where)) {
          if (row[key] !== value) {
            shouldUpdate = false;
            break;
          }
        }
      }

      if (shouldUpdate) {
        const oldRow = { ...row };
        const sanitizedUpdates = VALIDATOR[PRIVATE.SANITIZE].sanitizeRow(updates);
        if (sanitizedUpdates) {
          Object.assign(row, sanitizedUpdates);
          row._updated = Date.now();
          updated.push({ old: oldRow, new: row });
        }
      }
    }

    table.metadata.updated = Date.now();
    table.metadata.version++;

    logger.success(`✅ Обновлено ${updated.length} строк в ${tableName}`);
    this[PRIVATE.NOTIFY]('data-updated', { table: tableName, updates: updated });

    this[PRIVATE.QUEUE_OPERATION]({
      type: 'update',
      table: tableName,
      updates: updated,
      timestamp: Date.now(),
    });

    return updated;
  }

  [PRIVATE.DELETE](tableName, where) {
    const logger = this._logger;

    const table = this[PRIVATE.GET_TABLE](tableName);
    if (!table) {
      logger.error(`❌ Таблица не найдена: ${tableName}`);
      return null;
    }

    const deleted = [];

    for (let i = table.data.length - 1; i >= 0; i--) {
      const row = table.data[i];
      let shouldDelete = true;

      if (where && typeof where === 'function') {
        shouldDelete = where(row);
      } else if (where && typeof where === 'object') {
        for (const [key, value] of Object.entries(where)) {
          if (row[key] !== value) {
            shouldDelete = false;
            break;
          }
        }
      }

      if (shouldDelete) {
        deleted.push(table.data.splice(i, 1)[0]);
      }
    }

    table.metadata.updated = Date.now();
    table.metadata.version++;

    logger.success(`✅ Удалено ${deleted.length} строк из ${tableName}`);
    this[PRIVATE.NOTIFY]('data-deleted', { table: tableName, rows: deleted });

    this[PRIVATE.QUEUE_OPERATION]({
      type: 'delete',
      table: tableName,
      rows: deleted,
      timestamp: Date.now(),
    });

    return deleted;
  }

  [PRIVATE.SELECT](tableName, options = {}) {
    const table = this[PRIVATE.GET_TABLE](tableName);
    if (!table) {
      return null;
    }

    let results = [...table.data];

    if (options.where) {
      if (typeof options.where === 'function') {
        results = results.filter(options.where);
      } else if (typeof options.where === 'object') {
        results = results.filter(row => {
          for (const [key, value] of Object.entries(options.where)) {
            if (row[key] !== value) return false;
          }
          return true;
        });
      }
    }

    if (options.sort) {
      const sortFields = Array.isArray(options.sort) ? options.sort : [options.sort];
      for (const sort of sortFields) {
        const [field, direction = 'asc'] = typeof sort === 'string' ?
          [sort, 'asc'] :
          [sort.field, sort.direction || 'asc'];

        results.sort((a, b) => {
          const aVal = a[field] ?? '';
          const bVal = b[field] ?? '';
          const compare = aVal < bVal ? -1 : aVal > bVal ? 1 : 0;
          return direction === 'desc' ? -compare : compare;
        });
      }
    }

    if (options.limit !== undefined) {
      const offset = options.offset || 0;
      results = results.slice(offset, offset + options.limit);
    }

    return results;
  }

  [PRIVATE.QUERY](tableName, query) {
    const logger = this._logger;

    if (!query || typeof query !== 'object') {
      logger.error('❌ Некорректный запрос');
      return null;
    }

    return this[PRIVATE.SELECT](tableName, query);
  }

  // ============================================================
  // 12. МАСТЕР-ДЕТЕЙЛ
  // ============================================================

  [PRIVATE.LINK_TABLES](masterTable, detailTable, relationKey) {
    const logger = this._logger;

    if (!this[PRIVATE.TABLES].has(masterTable) || !this[PRIVATE.TABLES].has(detailTable)) {
      logger.error('❌ Одна из таблиц не найдена');
      return false;
    }

    const key = `${masterTable}:${detailTable}`;
    if (this[PRIVATE.MASTER_DETAIL].has(key)) {
      logger.warn(`⚠️ Связь уже существует: ${key}`);
      return false;
    }

    this[PRIVATE.MASTER_DETAIL].set(key, {
      masterTable,
      detailTable,
      relationKey: relationKey || `${masterTable}Id`,
      master: null,
      details: [],
    });

    logger.success(`✅ Таблицы связаны: ${masterTable} → ${detailTable}`);
    this[PRIVATE.NOTIFY]('tables-linked', { masterTable, detailTable, relationKey });
    return true;
  }

  [PRIVATE.UNLINK_TABLES](masterTable, detailTable) {
    const logger = this._logger;

    const key = `${masterTable}:${detailTable}`;
    if (!this[PRIVATE.MASTER_DETAIL].has(key)) {
      logger.warn(`⚠️ Связь не найдена: ${key}`);
      return false;
    }

    this[PRIVATE.MASTER_DETAIL].delete(key);
    logger.success(`🗑 Таблицы развязаны: ${masterTable} → ${detailTable}`);
    this[PRIVATE.NOTIFY]('tables-unlinked', { masterTable, detailTable });
    return true;
  }

  [PRIVATE.SET_MASTER](masterTable, masterId) {
    const logger = this._logger;

    let found = false;
    for (const [key, relation] of this[PRIVATE.MASTER_DETAIL]) {
      if (relation.masterTable === masterTable) {
        const masterData = this[PRIVATE.SELECT](masterTable, { where: { id: masterId } });
        if (!masterData || masterData.length === 0) {
          logger.warn(`⚠️ Мастер-запись не найдена: ${masterId}`);
          continue;
        }

        relation.master = masterData[0];

        const relationKey = relation.relationKey;
        const details = this[PRIVATE.SELECT](relation.detailTable, {
          where: { [relationKey]: masterId }
        });
        relation.details = details || [];

        found = true;
        logger.success(`✅ Мастер установлен: ${masterTable} (${masterId}) → ${details.length} деталей`);
        this[PRIVATE.NOTIFY]('master-set', {
          masterTable,
          masterId,
          detailTable: relation.detailTable,
          details: details,
        });
      }
    }

    return found;
  }

  [PRIVATE.GET_DETAILS](masterTable, masterId) {
    const results = [];

    for (const [key, relation] of this[PRIVATE.MASTER_DETAIL]) {
      if (relation.masterTable === masterTable) {
        if (relation.master && relation.master.id === masterId) {
          results.push({
            detailTable: relation.detailTable,
            details: relation.details,
            relationKey: relation.relationKey,
          });
        } else {
          const relationKey = relation.relationKey;
          const details = this[PRIVATE.SELECT](relation.detailTable, {
            where: { [relationKey]: masterId }
          });
          results.push({
            detailTable: relation.detailTable,
            details: details || [],
            relationKey: relation.relationKey,
          });
        }
      }
    }

    return results;
  }

  // ============================================================
  // 13. ВЫДЕЛЕНИЕ
  // ============================================================

  [PRIVATE.SELECT_ROW](tableName, rowId) {
    const logger = this._logger;

    if (!this[PRIVATE.TABLES].has(tableName)) {
      logger.error(`❌ Таблица не найдена: ${tableName}`);
      return false;
    }

    this[PRIVATE.SELECTIONS].set(tableName, rowId);
    this[PRIVATE.NOTIFY]('row-selected', { table: tableName, id: rowId });
    logger.debug(`🎯 Выделена строка: ${tableName}[${rowId}]`);
    return true;
  }

  [PRIVATE.CLEAR_SELECTION](tableName) {
    this[PRIVATE.SELECTIONS].delete(tableName);
    this[PRIVATE.NOTIFY]('selection-cleared', { table: tableName });
    return true;
  }

  [PRIVATE.GET_SELECTION](tableName) {
    return this[PRIVATE.SELECTIONS].get(tableName) || null;
  }

  [PRIVATE.HIGHLIGHT_ROW](tableName, rowId, highlight = true) {
    if (!this[PRIVATE.TABLES].has(tableName)) {
      return false;
    }

    if (!this[PRIVATE.HIGHLIGHTS].has(tableName)) {
      this[PRIVATE.HIGHLIGHTS].set(tableName, new Set());
    }

    const highlights = this[PRIVATE.HIGHLIGHTS].get(tableName);
    if (highlight) {
      highlights.add(rowId);
    } else {
      highlights.delete(rowId);
    }

    this[PRIVATE.NOTIFY]('row-highlighted', {
      table: tableName,
      id: rowId,
      highlighted: highlight,
    });

    return true;
  }

  [PRIVATE.CLEAR_HIGHLIGHTS](tableName) {
    this[PRIVATE.HIGHLIGHTS].delete(tableName);
    this[PRIVATE.NOTIFY]('highlights-cleared', { table: tableName });
    return true;
  }

  // ============================================================
  // 14. ФИЛЬТРАЦИЯ И СОРТИРОВКА
  // ============================================================

  [PRIVATE.SET_FILTER](tableName, filter) {
    if (!this[PRIVATE.TABLES].has(tableName)) {
      return false;
    }

    this[PRIVATE.FILTERS].set(tableName, filter);
    this[PRIVATE.NOTIFY]('filter-set', { table: tableName, filter });
    return true;
  }

  [PRIVATE.CLEAR_FILTERS](tableName) {
    this[PRIVATE.FILTERS].delete(tableName);
    this[PRIVATE.NOTIFY]('filters-cleared', { table: tableName });
    return true;
  }

  [PRIVATE.SET_SORT](tableName, sort) {
    if (!this[PRIVATE.TABLES].has(tableName)) {
      return false;
    }

    this[PRIVATE.SORTS].set(tableName, sort);
    this[PRIVATE.NOTIFY]('sort-set', { table: tableName, sort });
    return true;
  }

  [PRIVATE.CLEAR_SORTS](tableName) {
    this[PRIVATE.SORTS].delete(tableName);
    this[PRIVATE.NOTIFY]('sorts-cleared', { table: tableName });
    return true;
  }

  [PRIVATE.SET_PAGINATION](tableName, page, pageSize) {
    if (!this[PRIVATE.TABLES].has(tableName)) {
      return false;
    }

    const pagination = {
      page: page || 0,
      pageSize: pageSize || CONFIG.defaultPageSize,
      total: this[PRIVATE.SELECT](tableName).length,
    };

    this[PRIVATE.PAGINATION].set(tableName, pagination);
    this[PRIVATE.NOTIFY]('pagination-set', { table: tableName, pagination });
    return true;
  }

  // ============================================================
  // 15. БРОКЕР СООБЩЕНИЙ
  // ============================================================

  [PRIVATE.PUBLISH](channel, message) {
    const logger = this._logger;
    const broker = this[PRIVATE.MESSAGE_BROKER];

    if (!broker.active) {
      logger.warn('⚠️ Брокер не активен');
      return false;
    }

    const sanitized = VALIDATOR[PRIVATE.SANITIZE].sanitizeMessage(message);
    if (!sanitized) {
      logger.error('❌ Некорректное сообщение');
      return false;
    }

    broker.history.push({ channel, message: sanitized });
    if (broker.history.length > CONFIG.maxMessages) {
      broker.history = broker.history.slice(-CONFIG.maxMessages);
    }

    broker.queue.push({ channel, message: sanitized });

    if (broker.subscribers.has(channel)) {
      const subscribers = broker.subscribers.get(channel);
      for (const [id, callback] of subscribers) {
        try {
          callback(sanitized);
        } catch (error) {
          logger.error(`❌ Ошибка в подписчике ${id}:`, error);
        }
      }
    }

    if (broker.subscribers.has('*')) {
      const subscribers = broker.subscribers.get('*');
      for (const [id, callback] of subscribers) {
        try {
          callback(channel, sanitized);
        } catch (error) {
          logger.error(`❌ Ошибка в глобальном подписчике ${id}:`, error);
        }
      }
    }

    logger.debug(`📨 Сообщение опубликовано в ${channel}: ${sanitized.type}`);
    return true;
  }

  [PRIVATE.SUBSCRIBE](channel, callback) {
    const logger = this._logger;
    const broker = this[PRIVATE.MESSAGE_BROKER];

    if (typeof callback !== 'function') {
      logger.error('❌ Callback должен быть функцией');
      return null;
    }

    if (!broker.subscribers.has(channel)) {
      broker.subscribers.set(channel, new Map());
    }

    const id = `sub_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`;
    const subscribers = broker.subscribers.get(channel);
    subscribers.set(id, callback);

    this[PRIVATE.STATE]._subscribersCount = (this[PRIVATE.STATE]._subscribersCount || 0) + 1;

    logger.debug(`✅ Подписка создана: ${id} на ${channel}`);
    return id;
  }

  [PRIVATE.UNSUBSCRIBE](channel, id) {
    const logger = this._logger;
    const broker = this[PRIVATE.MESSAGE_BROKER];

    if (!broker.subscribers.has(channel)) {
      return false;
    }

    const subscribers = broker.subscribers.get(channel);
    const deleted = subscribers.delete(id);

    if (deleted) {
      this[PRIVATE.STATE]._subscribersCount = Math.max(0, (this[PRIVATE.STATE]._subscribersCount || 0) - 1);
      logger.debug(`🗑 Подписка удалена: ${id} на ${channel}`);
    }

    return deleted;
  }

  [PRIVATE.GET_MESSAGES](channel, limit = 50) {
    const broker = this[PRIVATE.MESSAGE_BROKER];

    if (channel) {
      return broker.history
        .filter(entry => entry.channel === channel)
        .slice(-limit);
    }

    return broker.history.slice(-limit);
  }

  [PRIVATE.CLEAR_MESSAGES](channel) {
    const broker = this[PRIVATE.MESSAGE_BROKER];

    if (channel) {
      broker.history = broker.history.filter(entry => entry.channel !== channel);
    } else {
      broker.history = [];
    }

    return true;
  }

  [PRIVATE.CREATE_CHANNEL](channel) {
    const broker = this[PRIVATE.MESSAGE_BROKER];

    if (broker.channels.has(channel)) {
      return false;
    }

    broker.channels.set(channel, {
      created: Date.now(),
      messages: 0,
      subscribers: 0,
    });

    if (!broker.subscribers.has(channel)) {
      broker.subscribers.set(channel, new Map());
    }

    this._logger.success(`✅ Канал создан: ${channel}`);
    return true;
  }

  [PRIVATE.DELETE_CHANNEL](channel) {
    const broker = this[PRIVATE.MESSAGE_BROKER];

    if (!broker.channels.has(channel)) {
      return false;
    }

    broker.channels.delete(channel);
    broker.subscribers.delete(channel);

    this._logger.success(`🗑 Канал удалён: ${channel}`);
    return true;
  }

  // ============================================================
  // 16. СИНХРОНИЗАЦИЯ (ИСПРАВЛЕННАЯ)
  // ============================================================

  [PRIVATE.QUEUE_OPERATION](operation) {
    // ★★★ ИСПРАВЛЕНО: используем getter и setter ★★★
    const queue = this[PRIVATE.SYNC_QUEUE];
    queue.push(operation);

    if (this[PRIVATE.SYNC_TIMEOUT]) {
      clearTimeout(this[PRIVATE.SYNC_TIMEOUT]);
      this[PRIVATE.SYNC_TIMEOUT] = null;
    }

    this[PRIVATE.SYNC_TIMEOUT] = setTimeout(() => {
      this[PRIVATE.PROCESS_QUEUE]();
    }, CONFIG.syncDebounce);
  }

  [PRIVATE.PROCESS_QUEUE]() {
    const logger = this._logger;

    if (this[PRIVATE.SYNC_IN_PROGRESS]) {
      logger.debug('⏳ Синхронизация уже выполняется, пропускаем');
      return;
    }

    // ★★★ ИСПРАВЛЕНО: получаем очередь через getter ★★★
    const queue = this[PRIVATE.SYNC_QUEUE];
    if (queue.length === 0) {
      logger.debug('ℹ️ Очередь синхронизации пуста');
      return;
    }

    this[PRIVATE.SYNC_IN_PROGRESS] = true;

    try {
      // ★★★ ИСПРАВЛЕНО: копируем и очищаем через setter ★★★
      const operations = [...queue];
      this[PRIVATE.SYNC_QUEUE] = [];

      logger.debug(`🔄 Обработка ${operations.length} операций синхронизации`);

      for (const op of operations) {
        const handlers = this[PRIVATE.SYNC_HANDLERS].get(op.type);
        if (handlers) {
          for (const handler of handlers) {
            try {
              handler(op);
            } catch (error) {
              logger.error(`❌ Ошибка в синхронизации ${op.type}:`, error);
            }
          }
        }
      }

      this[PRIVATE.LAST_SYNC] = Date.now();

      this[PRIVATE.NOTIFY]('sync-completed', {
        timestamp: this[PRIVATE.LAST_SYNC],
        operations: operations.length,
      });

      logger.debug(`✅ Синхронизация завершена (${operations.length} операций)`);

    } catch (error) {
      logger.error('❌ Ошибка синхронизации:', error);
    } finally {
      this[PRIVATE.SYNC_IN_PROGRESS] = false;
      this[PRIVATE.SYNC_TIMEOUT] = null;
    }
  }

  [PRIVATE.REGISTER_SYNC_HANDLER](type, handler) {
    if (!this[PRIVATE.SYNC_HANDLERS].has(type)) {
      this[PRIVATE.SYNC_HANDLERS].set(type, new Set());
    }

    this[PRIVATE.SYNC_HANDLERS].get(type).add(handler);

    return () => {
      this[PRIVATE.SYNC_HANDLERS].get(type)?.delete(handler);
    };
  }

  [PRIVATE.SYNC]() {
    return new Promise((resolve) => {
      const queue = this[PRIVATE.SYNC_QUEUE];
      if (queue.length === 0) {
        resolve();
        return;
      }

      if (this[PRIVATE.SYNC_TIMEOUT]) {
        clearTimeout(this[PRIVATE.SYNC_TIMEOUT]);
        this[PRIVATE.SYNC_TIMEOUT] = null;
      }
      this[PRIVATE.PROCESS_QUEUE]();

      const checkSync = () => {
        if (!this[PRIVATE.SYNC_IN_PROGRESS]) {
          resolve();
        } else {
          setTimeout(checkSync, 50);
        }
      };

      setTimeout(checkSync, 50);
    });
  }

  // ============================================================
  // 17. ТРАНЗАКЦИИ
  // ============================================================

  [PRIVATE.BEGIN_TRANSACTION](name) {
    const logger = this._logger;
    const id = `tx_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`;

    const transaction = {
      id,
      name: name || 'Transaction',
      started: Date.now(),
      operations: [],
      snapshot: this[PRIVATE.GET_STATE](),
    };

    this[PRIVATE.TRANSACTIONS].set(id, transaction);
    this[PRIVATE.TRANSACTION_STACK].push(id);

    logger.info(`🔒 Транзакция начата: ${transaction.name} (${id})`);
    return id;
  }

  [PRIVATE.COMMIT_TRANSACTION]() {
    const logger = this._logger;
    const id = this[PRIVATE.TRANSACTION_STACK].pop();

    if (!id) {
      logger.error('❌ Нет активной транзакции');
      return false;
    }

    const transaction = this[PRIVATE.TRANSACTIONS].get(id);
    if (!transaction) {
      logger.error(`❌ Транзакция не найдена: ${id}`);
      return false;
    }

    this[PRIVATE.UNDO_STACK].push({
      id: transaction.id,
      name: transaction.name,
      snapshot: transaction.snapshot,
      timestamp: Date.now(),
    });

    if (this[PRIVATE.UNDO_STACK].length > CONFIG.maxHistory) {
      this[PRIVATE.UNDO_STACK].shift();
    }

    this[PRIVATE.REDO_STACK] = [];

    logger.success(`✅ Транзакция зафиксирована: ${transaction.name} (${id})`);
    this[PRIVATE.NOTIFY]('transaction-committed', { id, name: transaction.name });

    this[PRIVATE.TRANSACTIONS].delete(id);
    return true;
  }

  [PRIVATE.ROLLBACK_TRANSACTION]() {
    const logger = this._logger;
    const id = this[PRIVATE.TRANSACTION_STACK].pop();

    if (!id) {
      logger.error('❌ Нет активной транзакции');
      return false;
    }

    const transaction = this[PRIVATE.TRANSACTIONS].get(id);
    if (!transaction) {
      logger.error(`❌ Транзакция не найдена: ${id}`);
      return false;
    }

    this[PRIVATE.RESTORE_SNAPSHOT](transaction.snapshot);

    logger.warn(`⏪ Транзакция откачена: ${transaction.name} (${id})`);
    this[PRIVATE.NOTIFY]('transaction-rolled-back', { id, name: transaction.name });

    this[PRIVATE.TRANSACTIONS].delete(id);
    return true;
  }

  [PRIVATE.UNDO]() {
    const logger = this._logger;

    if (this[PRIVATE.UNDO_STACK].length === 0) {
      logger.warn('⚠️ Нет действий для отмены');
      return false;
    }

    const state = this[PRIVATE.UNDO_STACK].pop();

    this[PRIVATE.REDO_STACK].push({
      snapshot: this[PRIVATE.GET_STATE](),
      timestamp: Date.now(),
    });

    this[PRIVATE.RESTORE_SNAPSHOT](state.snapshot);

    logger.success(`↩️ Отмена: ${state.name}`);
    this[PRIVATE.NOTIFY]('undo', { name: state.name });
    return true;
  }

  [PRIVATE.REDO]() {
    const logger = this._logger;

    if (this[PRIVATE.REDO_STACK].length === 0) {
      logger.warn('⚠️ Нет действий для повторения');
      return false;
    }

    const state = this[PRIVATE.REDO_STACK].pop();

    this[PRIVATE.UNDO_STACK].push({
      snapshot: this[PRIVATE.GET_STATE](),
      timestamp: Date.now(),
    });

    this[PRIVATE.RESTORE_SNAPSHOT](state.snapshot);

    logger.success(`↪️ Повтор: ${state.name}`);
    this[PRIVATE.NOTIFY]('redo', { name: state.name });
    return true;
  }

  [PRIVATE.RESTORE_SNAPSHOT](snapshot) {
    const logger = this._logger;

    try {
      if (snapshot.tables) {
        for (const [name, table] of Object.entries(snapshot.tables)) {
          if (this[PRIVATE.TABLES].has(name)) {
            this[PRIVATE.TABLES].set(name, table);
          } else {
            this[PRIVATE.TABLES].set(name, table);
          }
        }
      }

      if (snapshot.selections) {
        this[PRIVATE.SELECTIONS] = new Map(Object.entries(snapshot.selections));
      }
      if (snapshot.highlights) {
        this[PRIVATE.HIGHLIGHTS] = new Map(Object.entries(snapshot.highlights));
      }
      if (snapshot.filters) {
        this[PRIVATE.FILTERS] = new Map(Object.entries(snapshot.filters));
      }
      if (snapshot.sorts) {
        this[PRIVATE.SORTS] = new Map(Object.entries(snapshot.sorts));
      }
      if (snapshot.pagination) {
        this[PRIVATE.PAGINATION] = new Map(Object.entries(snapshot.pagination));
      }

      this[PRIVATE.NOTIFY]('snapshot-restored', { timestamp: Date.now() });
      logger.success('✅ Снапшот восстановлен');
    } catch (error) {
      logger.error('❌ Ошибка восстановления снапшота:', error);
    }
  }

  // ============================================================
  // 18. ПОЛУЧЕНИЕ СОСТОЯНИЯ
  // ============================================================

  [PRIVATE.GET_STATE]() {
    const state = {
      initialized: this[PRIVATE.STATE].initialized,
      destroyed: this[PRIVATE.STATE].destroyed,
      ready: this[PRIVATE.STATE].ready,
      streamStatus: this[PRIVATE.STATE].streamStatus || 'disconnected',
      lastUpdate: this[PRIVATE.STATE].lastUpdate,
      _batches: this[PRIVATE.STATE]._batches || 0,
      _subscribersCount: this[PRIVATE.STATE]._subscribersCount || 0,
      version: CONFIG.version,
      liveMetrics: [],
      messages: [],
      tables: {},
      selections: {},
      highlights: {},
      filters: {},
      sorts: {},
      pagination: {},
      messageBroker: {
        channels: Array.from(this[PRIVATE.MESSAGE_BROKER].channels.keys()),
        subscribers: {},
        historyLength: this[PRIVATE.MESSAGE_BROKER].history.length,
        queueLength: this[PRIVATE.MESSAGE_BROKER].queue.length,
        active: this[PRIVATE.MESSAGE_BROKER].active,
      },
      syncQueueLength: this[PRIVATE.SYNC_QUEUE].length,
      lastSync: this[PRIVATE.LAST_SYNC],
      undoStackLength: this[PRIVATE.UNDO_STACK].length,
      redoStackLength: this[PRIVATE.REDO_STACK].length,
      timestamp: Date.now(),
    };

    for (const [name, table] of this[PRIVATE.TABLES]) {
      state.tables[name] = {
        rowCount: table.data.length,
        metadata: table.metadata,
      };
      if (name === 'metrics') {
        state.liveMetrics = table.data.slice(-50);
      }
      if (name === 'messages') {
        state.messages = table.data.slice(-30);
      }
    }

    for (const [name, id] of this[PRIVATE.SELECTIONS]) {
      state.selections[name] = id;
    }

    for (const [channel, subscribers] of this[PRIVATE.MESSAGE_BROKER].subscribers) {
      state.messageBroker.subscribers[channel] = subscribers.size;
    }

    return state;
  }

  // ============================================================
  // 19. УВЕДОМЛЕНИЯ
  // ============================================================

  [PRIVATE.NOTIFY](event, data) {
    this[PRIVATE.PUBLISH]('store-events', {
      type: 'store-event',
      payload: { event, data, timestamp: Date.now() },
    });

    if (this._logger) {
      this._logger.debug(`📡 Событие: ${event}`, data);
    }
  }

  // ============================================================
  // 20. ЭКСПОРТ СИМВОЛОВ
  // ============================================================

  [PRIVATE.EXPORT_SYMBOLS]() {
    if (typeof window !== 'undefined') {
      window.__GLOBAL_STORE_SYMBOLS = {
        PRIVATE: { ...PRIVATE },
        PUBLIC: { ...PUBLIC },
      };
      window[PUBLIC.INSTANCE] = this;
      window.__globalStore = this;
    }
  }

  // ============================================================
  // 21. ПУБЛИЧНЫЕ МЕТОДЫ
  // ============================================================

  createTable(name, options) { return this[PRIVATE.CREATE_TABLE](name, options); }
  dropTable(name) { return this[PRIVATE.DROP_TABLE](name); }
  getTable(name) { return this[PRIVATE.GET_TABLE](name); }
  listTables() { return this[PRIVATE.LIST_TABLES](); }
  clearTable(name) { return this[PRIVATE.CLEAR_TABLE](name); }

  insert(tableName, rows) { return this[PRIVATE.INSERT](tableName, rows); }
  update(tableName, updates, where) { return this[PRIVATE.UPDATE](tableName, updates, where); }
  delete(tableName, where) { return this[PRIVATE.DELETE](tableName, where); }
  select(tableName, options) { return this[PRIVATE.SELECT](tableName, options); }
  query(tableName, query) { return this[PRIVATE.QUERY](tableName, query); }

  linkTables(masterTable, detailTable, relationKey) {
    return this[PRIVATE.LINK_TABLES](masterTable, detailTable, relationKey);
  }
  unlinkTables(masterTable, detailTable) {
    return this[PRIVATE.UNLINK_TABLES](masterTable, detailTable);
  }
  setMaster(masterTable, masterId) {
    return this[PRIVATE.SET_MASTER](masterTable, masterId);
  }
  getDetails(masterTable, masterId) {
    return this[PRIVATE.GET_DETAILS](masterTable, masterId);
  }

  selectRow(tableName, rowId) { return this[PRIVATE.SELECT_ROW](tableName, rowId); }
  clearSelection(tableName) { return this[PRIVATE.CLEAR_SELECTION](tableName); }
  getSelection(tableName) { return this[PRIVATE.GET_SELECTION](tableName); }
  highlightRow(tableName, rowId, highlight) {
    return this[PRIVATE.HIGHLIGHT_ROW](tableName, rowId, highlight);
  }
  clearHighlights(tableName) { return this[PRIVATE.CLEAR_HIGHLIGHTS](tableName); }

  setFilter(tableName, filter) { return this[PRIVATE.SET_FILTER](tableName, filter); }
  clearFilters(tableName) { return this[PRIVATE.CLEAR_FILTERS](tableName); }
  setSort(tableName, sort) { return this[PRIVATE.SET_SORT](tableName, sort); }
  clearSorts(tableName) { return this[PRIVATE.CLEAR_SORTS](tableName); }
  setPagination(tableName, page, pageSize) {
    return this[PRIVATE.SET_PAGINATION](tableName, page, pageSize);
  }

  setStatus(status) { return this[PRIVATE.SET_STATUS](status); }
  getStatus() { return this[PRIVATE.GET_STATUS](); }

  publish(channel, message) { return this[PRIVATE.PUBLISH](channel, message); }
  subscribe(channel, callback) { return this[PRIVATE.SUBSCRIBE](channel, callback); }
  unsubscribe(channel, id) { return this[PRIVATE.UNSUBSCRIBE](channel, id); }
  getMessages(channel, limit) { return this[PRIVATE.GET_MESSAGES](channel, limit); }
  clearMessages(channel) { return this[PRIVATE.CLEAR_MESSAGES](channel); }
  createChannel(channel) { return this[PRIVATE.CREATE_CHANNEL](channel); }
  deleteChannel(channel) { return this[PRIVATE.DELETE_CHANNEL](channel); }

  sync() { return this[PRIVATE.SYNC](); }
  registerSyncHandler(type, handler) {
    return this[PRIVATE.REGISTER_SYNC_HANDLER](type, handler);
  }

  beginTransaction(name) { return this[PRIVATE.BEGIN_TRANSACTION](name); }
  commitTransaction() { return this[PRIVATE.COMMIT_TRANSACTION](); }
  rollbackTransaction() { return this[PRIVATE.ROLLBACK_TRANSACTION](); }
  undo() { return this[PRIVATE.UNDO](); }
  redo() { return this[PRIVATE.REDO](); }

  init() { return this[PRIVATE.INIT](); }
  destroy() { return this[PRIVATE.DESTROY](); }
  getState() { return this[PRIVATE.GET_STATE](); }

  healthCheck() {
    return {
      version: CONFIG.version,
      initialized: this[PRIVATE.STATE].initialized,
      ready: this[PRIVATE.STATE].ready,
      destroyed: this[PRIVATE.STATE].destroyed,
      status: this[PRIVATE.STATE].streamStatus || 'disconnected',
      tables: this[PRIVATE.TABLES].size,
      subscribers: this[PRIVATE.MESSAGE_BROKER].subscribers.size,
      messages: this[PRIVATE.MESSAGE_BROKER].history.length,
      syncQueue: this[PRIVATE.SYNC_QUEUE].length,
      undoStack: this[PRIVATE.UNDO_STACK].length,
      redoStack: this[PRIVATE.REDO_STACK].length,
      timestamp: Date.now(),
    };
  }

  // ============================================================
  // 22. УНИЧТОЖЕНИЕ
  // ============================================================

  [PRIVATE.DESTROY]() {
    const logger = this._logger;

    if (this[PRIVATE.STATE].destroyed) {
      logger.warn('⚠️ Хранилище уже уничтожено');
      return;
    }

    logger.info('🧹 Очистка Global Store...');

    this[PRIVATE.MESSAGE_BROKER].active = false;

    this[PRIVATE.TABLES].clear();
    this[PRIVATE.RELATIONS].clear();
    this[PRIVATE.MASTER_DETAIL].clear();
    this[PRIVATE.SELECTIONS].clear();
    this[PRIVATE.HIGHLIGHTS].clear();
    this[PRIVATE.FILTERS].clear();
    this[PRIVATE.SORTS].clear();
    this[PRIVATE.PAGINATION].clear();

    this[PRIVATE.MESSAGE_BROKER].channels.clear();
    this[PRIVATE.MESSAGE_BROKER].subscribers.clear();
    this[PRIVATE.MESSAGE_BROKER].history = [];
    this[PRIVATE.MESSAGE_BROKER].queue = [];

    this[PRIVATE.SYNC_QUEUE] = [];
    this[PRIVATE.SYNC_HANDLERS].clear();

    this[PRIVATE.TRANSACTIONS].clear();
    this[PRIVATE.TRANSACTION_STACK] = [];
    this[PRIVATE.UNDO_STACK] = [];
    this[PRIVATE.REDO_STACK] = [];

    this[PRIVATE.STATE].destroyed = true;
    this[PRIVATE.STATE].ready = false;

    if (typeof window !== 'undefined') {
      delete window.__GLOBAL_STORE_SYMBOLS;
      delete window[PUBLIC.INSTANCE];
      delete window.__globalStore;
    }

    logger.success('✅ Global Store уничтожен');
  }
}

// ============================================================
// 23. ГЛОБАЛЬНЫЙ СИМВОЛ
// ============================================================

export const GLOBAL_STORE_SYMBOL = Symbol.for('__GLOBAL_STORE__');

// ============================================================
// 24. СОЗДАНИЕ И ЭКСПОРТ СИНГЛТОНА
// ============================================================

let globalStoreInstance = null;

export function getGlobalStore() {
  if (!globalStoreInstance) {
    if (typeof window !== 'undefined' && window[GLOBAL_STORE_SYMBOL]) {
      globalStoreInstance = window[GLOBAL_STORE_SYMBOL];
    } else {
      globalStoreInstance = new GlobalStore();
      if (typeof window !== 'undefined') {
        window[GLOBAL_STORE_SYMBOL] = globalStoreInstance;
      }
    }
  }
  return globalStoreInstance;
}

export const globalStore = getGlobalStore();

// ============================================================
// 25. ЭКСПОРТЫ
// ============================================================

export {
  GlobalStore,
  PRIVATE as GLOBAL_STORE_PRIVATE,
  PUBLIC as GLOBAL_STORE_PUBLIC,
  CONFIG as GLOBAL_STORE_CONFIG,
};

export default globalStore;

// ============================================================
// 26. КОНСОЛЬНЫЙ ИНТЕРФЕЙС
// ============================================================

if (typeof console !== 'undefined') {
  const privateCount = Object.keys(PRIVATE).length;
  const publicCount = Object.keys(PUBLIC).length;

  console.log('╔═══════════════════════════════════════════════════════════════════════════════╗');
  console.log('║              📦 GLOBAL STORE (100% СИМВОЛЫ) v1.0.2                         ║');
  console.log('╠═══════════════════════════════════════════════════════════════════════════════╣');
  console.log('║  🔧 Исправлен сеттер для SYNC_QUEUE                                        ║');
  console.log('║  🔑 Полная изоляция через приватные символы                                 ║');
  console.log('║  🔓 Публичные символы через Symbol.for                                      ║');
  console.log('║  📊 Система таблиц с мастер-детейл                                        ║');
  console.log('║  📡 Брокер сообщений с каналами                                           ║');
  console.log('║  🔄 Синхронизация данных                                                  ║');
  console.log('║  🔒 Транзакции с Undo/Redo                                                ║');
  console.log('╚═══════════════════════════════════════════════════════════════════════════════╝');

  console.log('📋 ДОСТУПНЫЕ КОМАНДЫ:');
  console.log('  window.__globalStore.createTable(name, options)');
  console.log('  window.__globalStore.insert(tableName, rows)');
  console.log('  window.__globalStore.select(tableName, options)');
  console.log('  window.__globalStore.linkTables(master, detail, key)');
  console.log('  window.__globalStore.setMaster(masterTable, masterId)');
  console.log('  window.__globalStore.getDetails(masterTable, masterId)');
  console.log('  window.__globalStore.publish(channel, message)');
  console.log('  window.__globalStore.subscribe(channel, callback)');
  console.log('  window.__globalStore.beginTransaction(name)');
  console.log('  window.__globalStore.undo()');
  console.log('  window.__globalStore.redo()');
  console.log('  window.__globalStore.getState()');
  console.log('  window.__globalStore.healthCheck()');
  console.log('');

  console.log('📊 СТАТИСТИКА СИМВОЛОВ:');
  console.log(`  🔑 Приватных символов: ${privateCount}`);
  console.log(`  🔓 Публичных символов: ${publicCount}`);
  console.log(`  📦 Всего символов: ${privateCount + publicCount}`);
  console.log('');

  console.log('✅ Global Store загружен (100% символы)');
}
