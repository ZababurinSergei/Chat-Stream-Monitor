// src/core/stream-service.js
// 100% СИМВОЛЫ — полная изоляция и безопасность
// Версия: 2.5.1 — ИСПРАВЛЕНА ЗАЩИТА ОТ ЦИКЛИЧЕСКИХ СООБЩЕНИЙ
// Добавлена проверка _processed и _restored флагов

import { globalStore, checkStoreAccess } from './store.js';
import { Subject } from 'rxjs';
import { bufferTime, filter, map, catchError, tap } from 'rxjs/operators';

// ============================================================
// 1. ПРИВАТНЫЕ СИМВОЛЫ (100% изоляция)
// ============================================================

const PRIVATE = {
  // Основные символы
  STORE: Symbol('stream.store'),
  STATE: Symbol('stream.state'),
  CONFIG: Symbol('stream.config'),
  VERSION: Symbol('stream.version'),
  BUILD: Symbol('stream.build'),
  INITIALIZED: Symbol('stream.initialized'),
  IS_DESTROYED: Symbol('stream.isDestroyed'),
  IS_ACTIVE: Symbol('stream.isActive'),
  FALLBACK_MODE: Symbol('stream.fallbackMode'),

  // Каналы и потоки
  CHANNEL: Symbol('stream.channel'),
  CHANNEL_NAME: Symbol('stream.channelName'),
  SOURCE: Symbol('stream.source'),
  SUBSCRIPTION: Symbol('stream.subscription'),
  SOURCES: Symbol('stream.sources'),

  // Данные
  BATCH_COUNTER: Symbol('stream.batchCounter'),
  LAST_BATCH_TIME: Symbol('stream.lastBatchTime'),
  START_TIME: Symbol('stream.startTime'),

  // Безопасность
  MESSAGE_HANDLER: Symbol('stream.messageHandler'),
  RATE_LIMIT_WINDOW: Symbol('stream.rateLimitWindow'),
  EVENT_COUNT: Symbol('stream.eventCount'),

  // Методы
  INIT: Symbol('stream.init'),
  DESTROY: Symbol('stream.destroy'),
  SECURITY_CHECK: Symbol('stream.securityCheck'),
  INIT_CHANNEL: Symbol('stream.initChannel'),
  IS_CIRCULAR: Symbol('stream.isCircular'),
  IS_RATE_LIMITED: Symbol('stream.isRateLimited'),
  HANDLE_MESSAGE: Symbol('stream.handleMessage'),
  NOTIFY: Symbol('stream.notify'),
  EXPORT_SYMBOLS: Symbol('stream.exportSymbols'),
};

// ============================================================
// 2. ПУБЛИЧНЫЕ СИМВОЛЫ (доступны через Symbol.for)
// ============================================================

const PUBLIC = {
  INSTANCE: Symbol.for('stream.instance'),
  STATE: Symbol.for('stream.state'),
  CONFIG: Symbol.for('stream.config'),
  START: Symbol.for('stream.start'),
  STOP: Symbol.for('stream.stop'),
  EMIT: Symbol.for('stream.emit'),
  GET_STATUS: Symbol.for('stream.getStatus'),
  GET_STATS: Symbol.for('stream.getStats'),
  DESTROY: Symbol.for('stream.destroy'),
  RECONNECT: Symbol.for('stream.reconnect'),
  DEBUG: Symbol.for('stream.debug'),
};

// ============================================================
// 3. КОНФИГУРАЦИЯ
// ============================================================

const CONFIG = {
  version: '2.5.1',
  build: '2026-07-26',
  name: 'Stream Service',
  debug: true,
  channelName: 'high_frequency_stream_channel',
  bufferTime: 30,
  maxItems: 500,
  maxEventsPerSecond: 10000,
  retryAttempts: 3,
  retryDelay: 1000,
};

// ============================================================
// 4. ВАЛИДАТОР
// ============================================================

const VALIDATOR = {
  validateSource(source) {
    if (!source || typeof source !== 'object') return false;
    return typeof source.emit === 'function';
  },

  validateBatch(batch) {
    if (!Array.isArray(batch)) return false;
    if (batch.length === 0) return false;

    return batch.every(
      (item) =>
        item &&
        typeof item === 'object' &&
        typeof item.id === 'number' &&
        typeof item.ts === 'number' &&
        typeof item.val === 'number' &&
        !isNaN(item.val) &&
        isFinite(item.val)
    );
  },

  validateItem(item) {
    if (!item || typeof item !== 'object') return false;
    if (typeof item.id !== 'number') return false;
    if (typeof item.ts !== 'number') return false;
    if (typeof item.val !== 'number') return false;
    if (isNaN(item.val) || !isFinite(item.val)) return false;
    return true;
  },
};

// ============================================================
// 5. ЛОГГЕР
// ============================================================

const LOGGER_SYMBOLS = {
  HISTORY: Symbol('logger.history'),
  MAX_HISTORY: Symbol('logger.maxHistory'),
  DEBUG: Symbol('logger.debug'),
  INSTANCE_ID: Symbol('logger.instanceId'),
  LEVEL: Symbol('logger.level'),
};

function createLogger(debug = true, instanceId = 'Stream') {
  const state = {
    [LOGGER_SYMBOLS.HISTORY]: [],
    [LOGGER_SYMBOLS.MAX_HISTORY]: 200,
    [LOGGER_SYMBOLS.DEBUG]: debug,
    [LOGGER_SYMBOLS.INSTANCE_ID]: instanceId,
    [LOGGER_SYMBOLS.LEVEL]: debug ? 3 : 2,
  };

  const logMethod = function (level, message, data = null) {
    const levels = { error: 0, warn: 1, info: 2, debug: 3, success: 2 };
    const currentLevel = this[LOGGER_SYMBOLS.LEVEL] || 2;
    const msgLevel = levels[level] || 2;

    if (msgLevel > currentLevel) return;

    const timestamp = new Date().toISOString().slice(11, 23);
    const prefix = `[${timestamp}] [${this[LOGGER_SYMBOLS.INSTANCE_ID]}]`;

    this[LOGGER_SYMBOLS.HISTORY].push({
      timestamp,
      level,
      message,
      data,
      id: Date.now() + Math.random(),
    });

    if (this[LOGGER_SYMBOLS.HISTORY].length > this[LOGGER_SYMBOLS.MAX_HISTORY]) {
      this[LOGGER_SYMBOLS.HISTORY].shift();
    }

    const icons = { error: '❌', warn: '⚠️', info: 'ℹ️', debug: '🔍', success: '✅' };
    const icon = icons[level] || '📌';

    if (data !== null && data !== undefined) {
      console.log(`${icon} ${prefix} ${message}`, data);
    } else {
      console.log(`${icon} ${prefix} ${message}`);
    }
  };

  const boundLog = logMethod.bind(state);

  const methods = {
    error: (msg, d) => boundLog('error', msg, d),
    warn: (msg, d) => boundLog('warn', msg, d),
    info: (msg, d) => boundLog('info', msg, d),
    debug: (msg, d) => boundLog('debug', msg, d),
    success: (msg, d) => boundLog('success', msg, d),

    header: (title, color = '#636e72') => {
      console.log('%c' + '═'.repeat(70), `color: ${color};`);
      console.log(
        '%c  📦 ' + title,
        'background: #1a1a2e; color: #fff; padding: 4px 12px; border-radius: 4px; font-weight: bold;'
      );
      console.log('%c' + '═'.repeat(70), `color: ${color};`);
    },

    separator: (color = '#636e72') => {
      console.log('%c' + '─'.repeat(70), `color: ${color};`);
    },

    getHistory: function () {
      return [...this[LOGGER_SYMBOLS.HISTORY]];
    },

    clearHistory: function () {
      this[LOGGER_SYMBOLS.HISTORY] = [];
      return this;
    },

    setDebug: function (enabled) {
      this[LOGGER_SYMBOLS.DEBUG] = enabled;
      this[LOGGER_SYMBOLS.LEVEL] = enabled ? 3 : 2;
      return this;
    },
  };

  const logger = {};
  for (const [key, fn] of Object.entries(methods)) {
    logger[key] = fn.bind(state);
  }

  logger[LOGGER_SYMBOLS.HISTORY] = state[LOGGER_SYMBOLS.HISTORY];
  logger[LOGGER_SYMBOLS.MAX_HISTORY] = state[LOGGER_SYMBOLS.MAX_HISTORY];
  logger[LOGGER_SYMBOLS.DEBUG] = state[LOGGER_SYMBOLS.DEBUG];
  logger[LOGGER_SYMBOLS.INSTANCE_ID] = state[LOGGER_SYMBOLS.INSTANCE_ID];
  logger[LOGGER_SYMBOLS.LEVEL] = state[LOGGER_SYMBOLS.LEVEL];

  return logger;
}

// ============================================================
// 6. ОСНОВНОЙ КЛАСС STREAM SERVICE
// ============================================================

class StreamService {
  constructor() {
    // ============================================================
    // 6.1. ПРИВАТНОЕ СОСТОЯНИЕ (через WeakMap для изоляции)
    // ============================================================

    // Используем WeakMap для хранения приватных данных
    const _private = new WeakMap();

    // Инициализируем приватные данные
    const privateData = {
      // Основные свойства
      [PRIVATE.STORE]: null,
      [PRIVATE.STATE]: {
        isActive: false,
        isDestroyed: false,
        initialized: false,
        fallbackMode: false,
      },
      [PRIVATE.CONFIG]: { ...CONFIG },
      [PRIVATE.VERSION]: CONFIG.version,
      [PRIVATE.BUILD]: CONFIG.build,
      [PRIVATE.INITIALIZED]: false,
      [PRIVATE.IS_DESTROYED]: false,
      [PRIVATE.IS_ACTIVE]: false,
      [PRIVATE.FALLBACK_MODE]: false,

      // Каналы и потоки
      [PRIVATE.CHANNEL]: null,
      [PRIVATE.CHANNEL_NAME]: CONFIG.channelName,
      [PRIVATE.SOURCE]: null,
      [PRIVATE.SUBSCRIPTION]: null,
      [PRIVATE.SOURCES]: new Set(),

      // Данные
      [PRIVATE.BATCH_COUNTER]: 0,
      [PRIVATE.LAST_BATCH_TIME]: null,
      [PRIVATE.START_TIME]: null,

      // Безопасность
      [PRIVATE.MESSAGE_HANDLER]: null,
      [PRIVATE.RATE_LIMIT_WINDOW]: null,
      [PRIVATE.EVENT_COUNT]: 0,
    };

    _private.set(this, privateData);

    // Сохраняем ссылку на приватные данные в экземпляре
    this._private = _private;

    // Создаем логгер
    this._logger = createLogger(CONFIG.debug, 'Stream');
    const logger = this._logger;

    // Проверяем доступ к хранилищу
    const storeCheck = checkStoreAccess(globalStore);
    if (!storeCheck.valid) {
      throw new Error(`❌ Ошибка доступа к хранилищу: ${storeCheck.error}`);
    }

    privateData[PRIVATE.STORE] = globalStore;

    // Инициализация
    this[PRIVATE.INIT]();

    logger.success('✅ Stream Service создан (100% символы)');
  }

  // ============================================================
  // 6.2. ГЕТТЕРЫ ДЛЯ ПРИВАТНЫХ ДАННЫХ
  // ============================================================

  get [PRIVATE.STORE]() {
    return this._private.get(this)[PRIVATE.STORE];
  }

  get [PRIVATE.STATE]() {
    return this._private.get(this)[PRIVATE.STATE];
  }

  get [PRIVATE.CONFIG]() {
    return this._private.get(this)[PRIVATE.CONFIG];
  }

  get [PRIVATE.CHANNEL]() {
    return this._private.get(this)[PRIVATE.CHANNEL];
  }

  set [PRIVATE.CHANNEL](value) {
    this._private.get(this)[PRIVATE.CHANNEL] = value;
  }

  get [PRIVATE.SUBSCRIPTION]() {
    return this._private.get(this)[PRIVATE.SUBSCRIPTION];
  }

  set [PRIVATE.SUBSCRIPTION](value) {
    this._private.get(this)[PRIVATE.SUBSCRIPTION] = value;
  }

  get [PRIVATE.SOURCES]() {
    return this._private.get(this)[PRIVATE.SOURCES];
  }

  get [PRIVATE.MESSAGE_HANDLER]() {
    return this._private.get(this)[PRIVATE.MESSAGE_HANDLER];
  }

  set [PRIVATE.MESSAGE_HANDLER](value) {
    this._private.get(this)[PRIVATE.MESSAGE_HANDLER] = value;
  }

  get [PRIVATE.IS_ACTIVE]() {
    return this._private.get(this)[PRIVATE.IS_ACTIVE];
  }

  set [PRIVATE.IS_ACTIVE](value) {
    this._private.get(this)[PRIVATE.IS_ACTIVE] = value;
  }

  get [PRIVATE.FALLBACK_MODE]() {
    return this._private.get(this)[PRIVATE.FALLBACK_MODE];
  }

  set [PRIVATE.FALLBACK_MODE](value) {
    this._private.get(this)[PRIVATE.FALLBACK_MODE] = value;
  }

  get [PRIVATE.BATCH_COUNTER]() {
    return this._private.get(this)[PRIVATE.BATCH_COUNTER];
  }

  set [PRIVATE.BATCH_COUNTER](value) {
    this._private.get(this)[PRIVATE.BATCH_COUNTER] = value;
  }

  get [PRIVATE.LAST_BATCH_TIME]() {
    return this._private.get(this)[PRIVATE.LAST_BATCH_TIME];
  }

  set [PRIVATE.LAST_BATCH_TIME](value) {
    this._private.get(this)[PRIVATE.LAST_BATCH_TIME] = value;
  }

  get [PRIVATE.START_TIME]() {
    return this._private.get(this)[PRIVATE.START_TIME];
  }

  set [PRIVATE.START_TIME](value) {
    this._private.get(this)[PRIVATE.START_TIME] = value;
  }

  get [PRIVATE.RATE_LIMIT_WINDOW]() {
    return this._private.get(this)[PRIVATE.RATE_LIMIT_WINDOW];
  }

  set [PRIVATE.RATE_LIMIT_WINDOW](value) {
    this._private.get(this)[PRIVATE.RATE_LIMIT_WINDOW] = value;
  }

  get [PRIVATE.EVENT_COUNT]() {
    return this._private.get(this)[PRIVATE.EVENT_COUNT];
  }

  set [PRIVATE.EVENT_COUNT](value) {
    this._private.get(this)[PRIVATE.EVENT_COUNT] = value;
  }

  // ============================================================
  // 6.3. МЕТОДЫ
  // ============================================================

  [PRIVATE.INIT]() {
    const logger = this._logger;
    const privateData = this._private.get(this);

    logger.header('ИНИЦИАЛИЗАЦИЯ STREAM SERVICE (100% СИМВОЛЫ)');
    logger.info(`📦 Версия: ${CONFIG.version}`);
    logger.info(`📅 Сборка: ${CONFIG.build}`);
    logger.info(`📌 Отладка: ${CONFIG.debug ? '✅' : '❌'}`);
    logger.separator();
    logger.info(`🔑 Приватных символов: ${Object.keys(PRIVATE).length}`);
    logger.info(`🔓 Публичных символов: ${Object.keys(PUBLIC).length}`);
    logger.separator();

    // Проверка безопасности
    this[PRIVATE.SECURITY_CHECK]();

    // Инициализация канала
    this[PRIVATE.INIT_CHANNEL]();

    // Экспорт символов
    this[PRIVATE.EXPORT_SYMBOLS]();

    privateData[PRIVATE.INITIALIZED] = true;

    logger.success('✅ Stream Service инициализирован');
    logger.header('ГОТОВ');
  }

  [PRIVATE.SECURITY_CHECK]() {
    const logger = this._logger;
    const privateData = this._private.get(this);

    // Проверяем, что BroadcastChannel доступен
    if (typeof BroadcastChannel === 'undefined') {
      logger.warn('⚠️ BroadcastChannel не поддерживается. Используем fallback.');
      privateData[PRIVATE.FALLBACK_MODE] = true;
    }

    // Проверяем, что окружение безопасно
    if (typeof window !== 'undefined' && !window.isSecureContext) {
      logger.warn('⚠️ Небезопасный контекст. Некоторые функции могут быть ограничены.');
    }
  }

  [PRIVATE.INIT_CHANNEL]() {
    const logger = this._logger;
    const privateData = this._private.get(this);

    if (privateData[PRIVATE.CHANNEL]) return;

    if (privateData[PRIVATE.FALLBACK_MODE]) {
      logger.warn('⚠️ Fallback режим: BroadcastChannel не используется');
      return;
    }

    try {
      const channel = new BroadcastChannel(privateData[PRIVATE.CHANNEL_NAME]);

      // Удаляем старый обработчик если есть
      if (privateData[PRIVATE.MESSAGE_HANDLER]) {
        channel.removeEventListener('message', privateData[PRIVATE.MESSAGE_HANDLER]);
      }

      // Создаем новый обработчик
      const handler = (event) => {
        if (event.target !== channel) return;
        this[PRIVATE.HANDLE_MESSAGE](event.data);
      };

      channel.addEventListener('message', handler);

      privateData[PRIVATE.CHANNEL] = channel;
      privateData[PRIVATE.MESSAGE_HANDLER] = handler;

      logger.success(`✅ BroadcastChannel инициализирован: ${privateData[PRIVATE.CHANNEL_NAME]}`);
    } catch (error) {
      logger.error('❌ Ошибка инициализации BroadcastChannel:', error);
      privateData[PRIVATE.FALLBACK_MODE] = true;
      privateData[PRIVATE.CHANNEL] = null;
    }
  }

  // ============================================================
  // ★★★ 6.3.1. ИСПРАВЛЕННЫЙ ОБРАБОТЧИК СООБЩЕНИЙ ★★★
  // ============================================================

  [PRIVATE.HANDLE_MESSAGE](data) {
    const logger = this._logger;
    const store = this[PRIVATE.STORE];

    if (!data) return;

    // ★★★ ЗАЩИТА ОТ ЦИКЛОВ ★★★
    // 1. Проверяем, не обработано ли уже это сообщение
    if (data._processed) {
      logger.debug('⏭️ Сообщение уже обработано, пропускаем');
      return;
    }

    // 2. Проверяем, не является ли это сообщение от нас самих
    if (data._fromChannel && data._source === 'stream-service') {
      logger.debug('⏭️ Сообщение от нас самих, пропускаем');
      return;
    }

    // ★★★ НЕ ОТПРАВЛЯЕМ ВОССТАНОВЛЕННЫЕ СООБЩЕНИЯ ОБРАТНО ★★★
    if (data._restored) {
      logger.debug('⏭️ Восстановленное сообщение, не отправляем обратно');
      return;
    }

    // Обработка сообщений от BroadcastChannel
    if (data._type === 'broadcast' || data._type === 'message') {
      if (store && typeof store.sendMessage === 'function') {
        // Добавляем флаг, что сообщение из канала и уже обработано
        const msg = {
          ...data,
          _fromChannel: true,
          _receivedAt: Date.now(),
          _processed: true, // ★★★ МЕТКА ОБРАБОТКИ ★★★
          _source: 'stream-service',
        };

        // ★★★ ПРОВЕРЯЕМ ТЕКСТ СООБЩЕНИЯ ★★★
        if (!msg.text || msg.text === 'undefined' || msg.text === '') {
          logger.warn('⚠️ Попытка отправить пустое сообщение из канала, пропускаем');
          return;
        }

        // Сохраняем в хранилище
        store.sendMessage(msg);
        logger.debug(`📨 Получено сообщение из канала: "${data.text}"`);
      }
    }
  }

  [PRIVATE.IS_CIRCULAR](source) {
    const privateData = this._private.get(this);

    if (source === this) return true;

    const store = this[PRIVATE.STORE];
    if (!store) return false;

    const storeState = store.getState();
    const sourceId = source.id || source.name || 'unknown';

    if (storeState.liveMetrics && storeState.liveMetrics.some((m) => m.sourceId === sourceId)) {
      this._logger.warn(
        `⚠️ Обнаружена потенциальная циклическая зависимость для источника: ${sourceId}`
      );
      return true;
    }

    return false;
  }

  [PRIVATE.IS_RATE_LIMITED]() {
    const privateData = this._private.get(this);
    const MAX_EVENTS_PER_SECOND = CONFIG.maxEventsPerSecond;
    const now = Date.now();

    if (!privateData[PRIVATE.RATE_LIMIT_WINDOW]) {
      privateData[PRIVATE.RATE_LIMIT_WINDOW] = now;
      privateData[PRIVATE.EVENT_COUNT] = 0;
      return false;
    }

    privateData[PRIVATE.EVENT_COUNT]++;

    if (now - privateData[PRIVATE.RATE_LIMIT_WINDOW] > 1000) {
      privateData[PRIVATE.RATE_LIMIT_WINDOW] = now;
      privateData[PRIVATE.EVENT_COUNT] = 0;
      return false;
    }

    if (privateData[PRIVATE.EVENT_COUNT] > MAX_EVENTS_PER_SECOND) {
      this._logger.warn(`⚠️ Превышен лимит: ${privateData[PRIVATE.EVENT_COUNT]} событий/сек`);
      return true;
    }

    return false;
  }

  // ============================================================
  // 6.4. ПУБЛИЧНЫЕ МЕТОДЫ
  // ============================================================

  start(source) {
    const logger = this._logger;
    const privateData = this._private.get(this);
    const store = this[PRIVATE.STORE];

    // Проверка состояния
    if (privateData[PRIVATE.IS_ACTIVE]) {
      logger.warn('⚠️ Стриминг уже активен');
      return false;
    }

    // Проверка источника
    if (!VALIDATOR.validateSource(source)) {
      logger.error('❌ Некорректный источник данных');
      return false;
    }

    // Проверка хранилища
    if (!store) {
      logger.error('❌ Хранилище не доступно');
      return false;
    }

    // Проверка на циклические зависимости
    if (this[PRIVATE.IS_CIRCULAR](source)) {
      logger.error('❌ Обнаружена циклическая зависимость');
      return false;
    }

    // Инициализируем канал
    this[PRIVATE.INIT_CHANNEL]();

    // Создаем поток
    const source$ = new Subject();

    try {
      // Настраиваем конвейер
      const subscription = source$
        .pipe(
          bufferTime(CONFIG.bufferTime),
          filter((batch) => batch && batch.length > 0),
          map((batch) => {
            const validItems = batch.filter((item) => VALIDATOR.validateItem(item));
            if (validItems.length < batch.length) {
              logger.warn(
                `⚠️ Отфильтровано ${batch.length - validItems.length} некорректных элементов`
              );
            }
            return validItems;
          }),
          filter((batch) => batch.length > 0),
          catchError((error) => {
            logger.error('❌ Ошибка в стриме:', error);
            return [];
          }),
          tap((batch) => {
            try {
              // Проверка на дубликаты
              const currentState = store.getState();
              const existingIds = new Set(currentState.liveMetrics.map((m) => m.id));
              const newItems = batch.filter((item) => !existingIds.has(item.id));

              if (newItems.length === 0) {
                logger.warn('⚠️ Все элементы уже существуют, пропускаем');
                return;
              }

              // Отправляем в другие вкладки
              const channel = privateData[PRIVATE.CHANNEL];
              if (!privateData[PRIVATE.FALLBACK_MODE] && channel) {
                try {
                  channel.postMessage({
                    _type: 'broadcast',
                    ...newItems,
                  });
                  privateData[PRIVATE.BATCH_COUNTER]++;
                  privateData[PRIVATE.LAST_BATCH_TIME] = Date.now();
                } catch (postError) {
                  logger.error('❌ Ошибка отправки в канал:', postError);
                  privateData[PRIVATE.FALLBACK_MODE] = true;
                }
              }

              // Сохраняем локально
              const result = store.appendDataBatch(newItems);
              if (result) {
                store.setStatus('playing');
              }
            } catch (error) {
              logger.error('❌ Ошибка отправки данных:', error);
            }
          })
        )
        .subscribe({
          error: (error) => {
            logger.error('❌ Фатальная ошибка в стриме:', error);
            this.stop();
          },
          complete: () => {
            logger.info('📊 Стрим завершен');
          },
        });

      // Сохраняем подписку
      privateData[PRIVATE.SUBSCRIPTION] = subscription;

      // Сохраняем источник
      privateData[PRIVATE.SOURCES].add(source);
      privateData[PRIVATE.SOURCE] = source;
      privateData[PRIVATE.IS_ACTIVE] = true;
      privateData[PRIVATE.START_TIME] = Date.now();

      // Сохраняем метод emit в источнике
      source.emit = (item) => {
        if (!privateData[PRIVATE.IS_ACTIVE]) {
          logger.warn('⚠️ Стриминг не активен');
          return false;
        }

        if (this[PRIVATE.IS_RATE_LIMITED]()) {
          logger.warn('⚠️ Превышен лимит частоты отправки');
          return false;
        }

        if (!VALIDATOR.validateItem(item)) {
          logger.warn('⚠️ Некорректный элемент данных');
          return false;
        }

        try {
          source$.next(item);
          return true;
        } catch (error) {
          logger.error('❌ Ошибка отправки элемента:', error);
          return false;
        }
      };

      store.setStatus('playing');

      logger.success('✅ Стриминг запущен');
      logger.info(
        `📊 Настройки: буферизация ${CONFIG.bufferTime}мс, канал: ${privateData[PRIVATE.CHANNEL_NAME]}`
      );
      return true;
    } catch (error) {
      logger.error('❌ Ошибка запуска стриминга:', error);
      privateData[PRIVATE.IS_ACTIVE] = false;
      return false;
    }
  }

  stop() {
    const logger = this._logger;
    const privateData = this._private.get(this);
    const store = this[PRIVATE.STORE];

    if (!privateData[PRIVATE.IS_ACTIVE]) {
      logger.warn('⚠️ Стриминг уже остановлен');
      return false;
    }

    try {
      // Отписываемся от потока
      if (privateData[PRIVATE.SUBSCRIPTION]) {
        privateData[PRIVATE.SUBSCRIPTION].unsubscribe();
        privateData[PRIVATE.SUBSCRIPTION] = null;
      }

      // Очищаем источники
      privateData[PRIVATE.SOURCES].clear();
      privateData[PRIVATE.SOURCE] = null;
      privateData[PRIVATE.IS_ACTIVE] = false;

      // Обновляем статус
      if (store) {
        store.setStatus('disconnected');
      }

      logger.success('⏹ Стриминг остановлен');
      logger.info(`📊 Всего отправлено батчей: ${privateData[PRIVATE.BATCH_COUNTER]}`);
      return true;
    } catch (error) {
      logger.error('❌ Ошибка остановки стриминга:', error);
      return false;
    }
  }

  emit(item) {
    const privateData = this._private.get(this);

    if (!privateData[PRIVATE.IS_ACTIVE]) {
      this._logger.warn('⚠️ Стриминг не активен');
      return false;
    }

    if (this[PRIVATE.IS_RATE_LIMITED]()) {
      this._logger.warn('⚠️ Превышен лимит частоты отправки');
      return false;
    }

    if (!VALIDATOR.validateItem(item)) {
      this._logger.warn('⚠️ Некорректный элемент данных');
      return false;
    }

    const source = privateData[PRIVATE.SOURCE];
    if (source && typeof source.emit === 'function') {
      try {
        return source.emit(item);
      } catch (error) {
        this._logger.error('❌ Ошибка отправки элемента:', error);
        return false;
      }
    }

    return false;
  }

  getStatus() {
    const privateData = this._private.get(this);
    const store = this[PRIVATE.STORE];

    return {
      isActive: privateData[PRIVATE.IS_ACTIVE],
      storeStatus: store ? store.getStatus() : 'unknown',
      sourcesCount: privateData[PRIVATE.SOURCES].size,
      channelActive: !!privateData[PRIVATE.CHANNEL] && !privateData[PRIVATE.FALLBACK_MODE],
      fallbackMode: privateData[PRIVATE.FALLBACK_MODE] || false,
      batchesSent: privateData[PRIVATE.BATCH_COUNTER],
      lastBatchTime: privateData[PRIVATE.LAST_BATCH_TIME],
      metricsCount: store ? store.getMetrics().length : 0,
    };
  }

  getStats() {
    const privateData = this._private.get(this);
    const store = this[PRIVATE.STORE];
    const state = store ? store.getState() : null;

    return {
      totalBatches: privateData[PRIVATE.BATCH_COUNTER],
      lastBatchTime: privateData[PRIVATE.LAST_BATCH_TIME],
      activeSources: privateData[PRIVATE.SOURCES].size,
      isActive: privateData[PRIVATE.IS_ACTIVE],
      metricsCount: state ? state.liveMetrics.length : 0,
      status: state ? state.streamStatus : 'unknown',
      uptime: privateData[PRIVATE.START_TIME] ? Date.now() - privateData[PRIVATE.START_TIME] : 0,
    };
  }

  reconnect() {
    const logger = this._logger;
    const privateData = this._private.get(this);

    logger.info('🔄 Попытка переподключения...');

    const wasActive = privateData[PRIVATE.IS_ACTIVE];
    const sources = Array.from(privateData[PRIVATE.SOURCES]);

    // Останавливаем
    this.stop();

    // Очищаем канал
    if (privateData[PRIVATE.CHANNEL]) {
      try {
        if (privateData[PRIVATE.MESSAGE_HANDLER]) {
          privateData[PRIVATE.CHANNEL].removeEventListener(
            'message',
            privateData[PRIVATE.MESSAGE_HANDLER]
          );
        }
        privateData[PRIVATE.CHANNEL].close();
      } catch (error) {
        logger.error('❌ Ошибка закрытия канала:', error);
      }
      privateData[PRIVATE.CHANNEL] = null;
      privateData[PRIVATE.MESSAGE_HANDLER] = null;
    }

    // Сбрасываем состояние
    privateData[PRIVATE.BATCH_COUNTER] = 0;
    privateData[PRIVATE.LAST_BATCH_TIME] = null;
    privateData[PRIVATE.START_TIME] = null;
    privateData[PRIVATE.RATE_LIMIT_WINDOW] = null;
    privateData[PRIVATE.EVENT_COUNT] = 0;

    // Инициализируем заново
    this[PRIVATE.INIT_CHANNEL]();

    // Если был активен - перезапускаем
    if (wasActive && sources.length > 0) {
      logger.info('🔄 Восстанавливаем стриминг...');
      return this.start(sources[0]);
    }

    logger.success('✅ Переподключение успешно');
    return true;
  }

  destroy() {
    const logger = this._logger;
    const privateData = this._private.get(this);

    if (privateData[PRIVATE.IS_DESTROYED]) {
      logger.warn('⚠️ Сервис уже уничтожен');
      return;
    }

    logger.info('🧹 Начинаем очистку Stream Service...');

    // Останавливаем стриминг
    this.stop();

    // Закрываем канал
    if (privateData[PRIVATE.CHANNEL]) {
      try {
        if (privateData[PRIVATE.MESSAGE_HANDLER]) {
          privateData[PRIVATE.CHANNEL].removeEventListener(
            'message',
            privateData[PRIVATE.MESSAGE_HANDLER]
          );
        }
        privateData[PRIVATE.CHANNEL].close();
        logger.success('✅ BroadcastChannel закрыт');
      } catch (error) {
        logger.error('❌ Ошибка закрытия канала:', error);
      }
      privateData[PRIVATE.CHANNEL] = null;
      privateData[PRIVATE.MESSAGE_HANDLER] = null;
    }

    // Очищаем состояние
    privateData[PRIVATE.SOURCES].clear();
    privateData[PRIVATE.SOURCE] = null;
    privateData[PRIVATE.SUBSCRIPTION] = null;
    privateData[PRIVATE.IS_ACTIVE] = false;
    privateData[PRIVATE.IS_DESTROYED] = true;
    privateData[PRIVATE.INITIALIZED] = false;
    privateData[PRIVATE.FALLBACK_MODE] = false;
    privateData[PRIVATE.BATCH_COUNTER] = 0;
    privateData[PRIVATE.LAST_BATCH_TIME] = null;
    privateData[PRIVATE.START_TIME] = null;
    privateData[PRIVATE.RATE_LIMIT_WINDOW] = null;
    privateData[PRIVATE.EVENT_COUNT] = 0;

    // Удаляем глобальные ссылки
    if (typeof window !== 'undefined') {
      delete window[PUBLIC.INSTANCE];
      delete window.__streamService;
    }

    logger.success('🧹 Stream Service полностью очищен');
  }

  debug() {
    const status = this.getStatus();
    const stats = this.getStats();
    const privateData = this._private.get(this);

    console.group('🔍 Stream Service Debug');
    console.log('Статус:', status);
    console.log('Статистика:', stats);
    console.log('Хранилище:', this[PRIVATE.STORE] ? 'доступно' : 'недоступно');
    console.log('Канал:', privateData[PRIVATE.CHANNEL] ? 'активен' : 'неактивен');
    console.log('Режим fallback:', privateData[PRIVATE.FALLBACK_MODE] || false);
    console.log('Источники:', privateData[PRIVATE.SOURCES].size);
    console.log('Приватные символы:', Object.keys(PRIVATE).length);
    console.log('Публичные символы:', Object.keys(PUBLIC).length);
    console.groupEnd();

    return { status, stats };
  }

  [PRIVATE.EXPORT_SYMBOLS]() {
    if (typeof window !== 'undefined') {
      window[PUBLIC.INSTANCE] = this;
      window.__streamService = this;

      window.__streamServiceSymbols = {
        PRIVATE: { ...PRIVATE },
        PUBLIC: { ...PUBLIC },
      };
    }
  }
}

// ============================================================
// 7. СИНГЛТОН
// ============================================================

let streamServiceInstance = null;
let streamServiceLock = false;

export function getStreamService() {
  if (streamServiceLock) {
    console.warn('⚠️ Создание сервиса заблокировано');
    return null;
  }

  if (!streamServiceInstance) {
    try {
      streamServiceLock = true;
      streamServiceInstance = new StreamService();
      streamServiceLock = false;
    } catch (error) {
      console.error('❌ Ошибка создания стрим-сервиса:', error);
      streamServiceLock = false;
      return null;
    }
  }
  return streamServiceInstance;
}

export const streamService = getStreamService();

export { StreamService };

// ============================================================
// 8. ЭКСПОРТЫ
// ============================================================

export { PRIVATE as STREAM_PRIVATE, PUBLIC as STREAM_PUBLIC, CONFIG as STREAM_CONFIG };

export function resetStreamService() {
  if (streamServiceInstance) {
    try {
      streamServiceInstance.destroy();
    } catch (error) {
      console.error('❌ Ошибка при уничтожении сервиса:', error);
    }
    streamServiceInstance = null;
  }
  streamServiceLock = false;
  console.log('🔄 Stream Service сброшен');
}

// ============================================================
// 9. КОНСОЛЬНЫЙ ИНТЕРФЕЙС
// ============================================================

if (typeof window !== 'undefined') {
  console.log('╔═══════════════════════════════════════════════════════════════════════════════╗');
  console.log('║              📦 STREAM SERVICE (100% СИМВОЛЫ) v2.5.1                       ║');
  console.log('╠═══════════════════════════════════════════════════════════════════════════════╣');
  console.log('║  📋 Все логи выводятся в консоль с цветовой разметкой                       ║');
  console.log('║  🔑 Полная изоляция через приватные символы                                 ║');
  console.log('║  🔓 Публичные символы через Symbol.for                                      ║');
  console.log('║  📡 Потоковая передача данных с буферизацией                                ║');
  console.log('║  🔄 Синхронизация между вкладками через BroadcastChannel                    ║');
  console.log('║  📨 Поддержка сообщений через глобальный стор                               ║');
  console.log('║  ⚠️ Защита от циклических зависимостей                                     ║');
  console.log('║  🛡️ Rate limiting для защиты от DoS                                        ║');
  console.log('║  ✅ Обработка ошибок и автоматическое восстановление                        ║');
  console.log('║  🔒 ЗАЩИТА ОТ БЕСКОНЕЧНЫХ ЦИКЛОВ СООБЩЕНИЙ                                  ║');
  console.log('╚═══════════════════════════════════════════════════════════════════════════════╝');

  console.log('📋 ДОСТУПНЫЕ КОМАНДЫ:');
  console.log('  window.__streamService.start(source)  - запустить стриминг');
  console.log('  window.__streamService.stop()         - остановить стриминг');
  console.log('  window.__streamService.emit(item)     - отправить данные');
  console.log('  window.__streamService.getStatus()    - получить статус');
  console.log('  window.__streamService.getStats()     - получить статистику');
  console.log('  window.__streamService.reconnect()    - переподключиться');
  console.log('  window.__streamService.destroy()      - уничтожить сервис');
  console.log('  window.__streamService.debug()        - отладка');
  console.log('');

  console.log('📊 СТАТИСТИКА СИМВОЛОВ:');
  console.log(`  🔑 Приватных символов: ${Object.keys(PRIVATE).length}`);
  console.log(`  🔓 Публичных символов: ${Object.keys(PUBLIC).length}`);
  console.log(`  📦 Всего символов: ${Object.keys(PRIVATE).length + Object.keys(PUBLIC).length}`);
  console.log('');

  console.log('✅ Stream Service загружен (100% символы)');
}
