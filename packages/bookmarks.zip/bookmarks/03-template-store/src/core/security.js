// src/core/security.js

/**
 * Модуль безопасности и валидации
 * Предоставляет функции для проверки окружения, санитайзинга данных и генерации ID
 */

// ============================================================
// КОНСТАНТЫ
// ============================================================

const ALLOWED_FIELDS = ['id', 'ts', 'val', 'trend'];
const MAX_SAFE_ID = Number.MAX_SAFE_INTEGER;

// ============================================================
// ПРОВЕРКА ОКРУЖЕНИЯ
// ============================================================

export function checkEnvironment() {
  const checks = {
    hasGlobalThis: typeof globalThis !== 'undefined',
    hasBroadcastChannel: typeof BroadcastChannel !== 'undefined',
    hasSymbol: typeof Symbol !== 'undefined',
    hasCrypto: typeof crypto !== 'undefined' && typeof crypto.subtle !== 'undefined',
    isSecureContext: globalThis.isSecureContext || false,
    origin: globalThis.location?.origin || 'unknown',
    userAgent: navigator?.userAgent || 'unknown',
    timestamp: Date.now()
  };

  // Проверка на XSS через URL параметры
  let isSafe = true;
  try {
    const urlParams = new URLSearchParams(globalThis.location?.search || '');
    const suspiciousPatterns = ['<script', 'javascript:', 'onerror=', 'onload=', 'onclick=', 'alert('];

    for (const [key, value] of urlParams) {
      for (const pattern of suspiciousPatterns) {
        if (value.toLowerCase().includes(pattern)) {
          console.warn(`⚠️ Обнаружен подозрительный параметр: ${key}=${value}`);
          isSafe = false;
          break;
        }
      }
    }
  } catch (error) {
    console.warn('⚠️ Ошибка проверки URL параметров:', error);
  }

  // Проверка на наличие опасных глобальных объектов
  const dangerousGlobals = ['eval', 'Function', 'setTimeout', 'setInterval'];
  for (const name of dangerousGlobals) {
    if (typeof window[name] !== 'undefined' && window[name]) {
      // Это нормально, просто проверяем что они есть
    }
  }

  return {
    ...checks,
    isSafe,
    // Дополнительная информация
    isSecure: checks.isSecureContext && checks.hasCrypto,
    environment: checks.isSecureContext ? 'secure' : 'insecure'
  };
}

// ============================================================
// ПРОВЕРКА ДОСТУПА К ХРАНИЛИЩУ
// ============================================================

export function verifyStoreAccess(storeSymbol) {
  if (!storeSymbol || typeof storeSymbol !== 'symbol') {
    return {
      valid: false,
      error: 'Некорректный Symbol'
    };
  }

  try {
    const store = globalThis[storeSymbol];

    if (!store) {
      return {
        valid: false,
        error: 'Хранилище не найдено'
      };
    }

    // Проверяем структуру
    const requiredProps = ['__version', 'getState', 'setStatus', 'appendDataBatch'];
    const missingProps = requiredProps.filter(prop => !(prop in store));

    if (missingProps.length > 0) {
      return {
        valid: false,
        error: `Отсутствуют свойства: ${missingProps.join(', ')}`
      };
    }

    // Проверяем типы методов
    if (typeof store.getState !== 'function') {
      return {
        valid: false,
        error: 'getState не является функцией'
      };
    }

    if (typeof store.setStatus !== 'function') {
      return {
        valid: false,
        error: 'setStatus не является функцией'
      };
    }

    if (typeof store.appendDataBatch !== 'function') {
      return {
        valid: false,
        error: 'appendDataBatch не является функцией'
      };
    }

    // Проверяем версию
    if (!store.__version || typeof store.__version !== 'string') {
      return {
        valid: false,
        error: 'Некорректная версия хранилища'
      };
    }

    return {
      valid: true,
      store: store,
      version: store.__version
    };

  } catch (error) {
    return {
      valid: false,
      error: `Ошибка проверки хранилища: ${error.message}`
    };
  }
}

// ============================================================
// САНИТАЙЗЕР ДАННЫХ
// ============================================================

export function sanitizeData(data) {
  if (!data || typeof data !== 'object') {
    return null;
  }

  // Проверяем, что это не опасный объект
  if (data.constructor && data.constructor.name !== 'Object') {
    console.warn('⚠️ Обнаружен небезопасный объект:', data.constructor.name);
    return null;
  }

  const sanitized = {};
  let hasRequired = false;

  // Проверяем разрешенные поля
  for (const field of ALLOWED_FIELDS) {
    if (field in data) {
      const value = data[field];

      try {
        // Валидация по типам полей
        if (field === 'id') {
          if (typeof value === 'number' && value > 0 && value < MAX_SAFE_ID) {
            sanitized[field] = Math.floor(value);
            hasRequired = true;
          }
        } else if (field === 'ts') {
          if (typeof value === 'number' && value > 0 && value < Date.now() + 60000) {
            sanitized[field] = Math.floor(value);
            hasRequired = true;
          } else {
            // Если ts невалидный, генерируем новый
            sanitized[field] = Date.now();
          }
        } else if (field === 'val') {
          if (typeof value === 'number' && isFinite(value) && !isNaN(value)) {
            sanitized[field] = Math.round(value * 100) / 100;
            hasRequired = true;
          }
        } else if (field === 'trend') {
          if (typeof value === 'number' && isFinite(value) && !isNaN(value)) {
            sanitized[field] = Math.round(value * 100) / 100;
          }
        }
      } catch (error) {
        console.warn('⚠️ Ошибка валидации поля:', field, error);
        // Пропускаем это поле
      }
    }
  }

  // Проверяем наличие обязательных полей
  if (!sanitized.id || !sanitized.ts || sanitized.val === undefined) {
    console.warn('⚠️ Отсутствуют обязательные поля:', {
      hasId: !!sanitized.id,
      hasTs: !!sanitized.ts,
      hasVal: sanitized.val !== undefined
    });
    return null;
  }

  // Убеждаемся, что все поля числовые
  for (const key of ['id', 'ts', 'val']) {
    if (typeof sanitized[key] !== 'number' || isNaN(sanitized[key])) {
      console.warn(`⚠️ Некорректное значение поля ${key}:`, sanitized[key]);
      return null;
    }
  }

  return sanitized;
}

// ============================================================
// ВАЛИДАЦИЯ БАТЧА
// ============================================================

export function validateBatch(batch) {
  if (!Array.isArray(batch)) {
    console.warn('⚠️ Батч не является массивом');
    return false;
  }

  if (batch.length === 0) {
    return false; // Пустой батч не валиден
  }

  if (batch.length > 1000) {
    console.warn(`⚠️ Батч слишком большой: ${batch.length} элементов`);
    return false;
  }

  // Проверяем каждый элемент
  let validCount = 0;
  for (let i = 0; i < batch.length; i++) {
    const item = batch[i];

    // Базовые проверки
    if (!item || typeof item !== 'object') {
      console.warn(`⚠️ Элемент ${i} не является объектом`);
      continue;
    }

    // Проверяем constructor
    if (item.constructor && item.constructor.name !== 'Object') {
      console.warn(`⚠️ Элемент ${i} имеет небезопасный конструктор: ${item.constructor.name}`);
      continue;
    }

    // Проверяем наличие полей
    if (typeof item.id !== 'number' || typeof item.ts !== 'number' || typeof item.val !== 'number') {
      console.warn(`⚠️ Элемент ${i} имеет некорректные поля`);
      continue;
    }

    // Проверяем значения
    if (isNaN(item.id) || isNaN(item.ts) || isNaN(item.val)) {
      console.warn(`⚠️ Элемент ${i} содержит NaN`);
      continue;
    }

    if (!isFinite(item.id) || !isFinite(item.ts) || !isFinite(item.val)) {
      console.warn(`⚠️ Элемент ${i} содержит бесконечное значение`);
      continue;
    }

    validCount++;
  }

  // Батч валиден если более 80% элементов прошли проверку
  const isValid = validCount / batch.length >= 0.8;
  if (!isValid) {
    console.warn(`⚠️ Батч не прошел валидацию: ${validCount}/${batch.length} элементов валидны`);
  }

  return isValid;
}

// ============================================================
// ГЕНЕРАЦИЯ ID
// ============================================================

export function generateConsumerId() {
  try {
    // Используем crypto если доступен
    if (typeof crypto !== 'undefined' && crypto.randomUUID) {
      return `consumer_${crypto.randomUUID()}`;
    }

    // Fallback на таймстамп + случайные числа
    const timestamp = Date.now().toString(36);
    const random = Math.random().toString(36).substring(2, 8);
    const counter = performance.now().toString(36);
    return `consumer_${timestamp}_${random}_${counter}`;
  } catch (error) {
    // Абсолютный fallback
    const timestamp = Date.now().toString(36);
    const random = Math.floor(Math.random() * 1e9).toString(36);
    return `consumer_${timestamp}_${random}`;
  }
}

// ============================================================
// ПРОВЕРКА БЕЗОПАСНОСТИ ОБЪЕКТА
// ============================================================

export function isSafeObject(obj) {
  if (!obj || typeof obj !== 'object') {
    return false;
  }

  try {
    // Проверяем конструктор
    if (obj.constructor && obj.constructor.name !== 'Object') {
      console.warn('⚠️ Объект имеет нестандартный конструктор:', obj.constructor.name);
      return false;
    }

    // Проверяем прототип
    if (Object.getPrototypeOf(obj) !== Object.prototype &&
      Object.getPrototypeOf(obj) !== null) {
      console.warn('⚠️ Объект имеет нестандартный прототип');
      return false;
    }

    // Проверяем на наличие функций в объекте
    const keys = Object.keys(obj);
    for (const key of keys) {
      if (typeof obj[key] === 'function') {
        console.warn(`⚠️ Объект содержит функцию: ${key}`);
        return false;
      }
    }

    // Проверяем на наличие скрытых свойств
    const allKeys = Reflect.ownKeys(obj);
    const symbolKeys = allKeys.filter(key => typeof key === 'symbol');
    if (symbolKeys.length > 0) {
      // Символы допустимы, но проверяем их
      for (const key of symbolKeys) {
        if (typeof obj[key] === 'function') {
          console.warn(`⚠️ Объект содержит функцию через Symbol`);
          return false;
        }
      }
    }

    return true;

  } catch (error) {
    console.warn('⚠️ Ошибка проверки безопасности объекта:', error);
    return false;
  }
}

// ============================================================
// ЭКСПОРТ ПО УМОЛЧАНИЮ
// ============================================================

export default {
  checkEnvironment,
  verifyStoreAccess,
  sanitizeData,
  validateBatch,
  generateConsumerId,
  isSafeObject,
  ALLOWED_FIELDS,
  MAX_SAFE_ID
};