// src/core/store.js
// 100% СИМВОЛЫ — полная изоляция и безопасность
// Версия: 3.0.0 — Интеграция с GlobalStore
// ============================================================

// ============================================================
// 1. ИМПОРТЫ
// ============================================================

import { getGlobalStore, GLOBAL_STORE_SYMBOL } from './global-store.js';

// ============================================================
// 2. ПРИВАТНЫЕ СИМВОЛЫ (100% изоляция)
// ============================================================

const PRIVATE = {
  // Основные символы
  STORE: Symbol('store.instance'),
  STATE: Symbol('store.state'),
  CONFIG: Symbol('store.config'),
  VERSION: Symbol('store.version'),
  BUILD: Symbol('store.build'),
  INITIALIZED: Symbol('store.initialized'),
  IS_DESTROYED: Symbol('store.isDestroyed'),

  // Данные
  METRICS: Symbol('store.metrics'),
  STATUS: Symbol('store.status'),
  BATCHES: Symbol('store.batches'),
  MESSAGES: Symbol('store.messages'),
  LAST_UPDATE: Symbol('store.lastUpdate'),

  // Подписчики
  SUBSCRIBERS: Symbol('store.subscribers'),
  CHANNEL: Symbol('store.channel'),

  // Безопасность
  VALIDATE: Symbol('store.validate'),
  SANITIZE: Symbol('store.sanitize'),
  SECURE: Symbol('store.secure'),

  // Методы
  INIT: Symbol('store.init'),
  DESTROY: Symbol('store.destroy'),
  NOTIFY: Symbol('store.notify'),
  GET_STATE: Symbol('store.getState'),
  SET_STATE: Symbol('store.setState'),
  UPDATE_STATS: Symbol('store.updateStats'),
  EXPORT_SYMBOLS: Symbol('store.exportSymbols'),

  // Сообщения
  SEND_MESSAGE: Symbol('store.sendMessage'),
  BROADCAST_MESSAGE: Symbol('store.broadcastMessage'),
  GET_MESSAGES: Symbol('store.getMessages'),
  CLEAR_MESSAGES: Symbol('store.clearMessages'),
  REPLACE_MESSAGES: Symbol('store.replaceMessages'),
  HANDLE_INCOMING: Symbol('store.handleIncoming'),
  MESSAGE_HANDLER: Symbol('store.messageHandler'),

  // GlobalStore
  GLOBAL_STORE: Symbol('store.globalStore'),
  GLOBAL_SUB_ID: Symbol('store.globalSubId'),
  TABLES_INITIALIZED: Symbol('store.tablesInitialized'),
};

// ============================================================
// 3. ПУБЛИЧНЫЕ СИМВОЛЫ (доступны через Symbol.for)
// ============================================================

const PUBLIC = {
  STORE: Symbol.for('store.instance'),
  STATE: Symbol.for('store.state'),
  CONFIG: Symbol.for('store.config'),
  VERSION: Symbol.for('store.version'),
  METRICS: Symbol.for('store.metrics'),
  STATUS: Symbol.for('store.status'),
  SEND: Symbol.for('store.send'),
  BROADCAST: Symbol.for('store.broadcast'),
  GET_MESSAGES: Symbol.for('store.getMessages'),
  CLEAR_MESSAGES: Symbol.for('store.clearMessages'),
  REPLACE_MESSAGES: Symbol.for('store.replaceMessages'),
  SUBSCRIBE: Symbol.for('store.subscribe'),
  HEALTH: Symbol.for('store.health'),
  GET_GLOBAL_STORE: Symbol.for('store.getGlobalStore'),
};

// ============================================================
// 4. КОНФИГУРАЦИЯ
// ============================================================

const CONFIG = {
  version: '3.0.0',
  build: '2026-07-26',
  name: 'Secure Store',
  debug: true,
  maxMetrics: 500,
  maxMessages: 100,
  channelName: 'high_frequency_stream_channel',
  apiVersion: '3.0.0',
  globalTables: {
    metrics: 'metrics',
    messages: 'messages',
  },
};

// ============================================================
// 5. УНИКАЛЬНЫЙ SYMBOL ДЛЯ ДОСТУПА К ГЛОБАЛЬНОМУ ХРАНИЛИЩУ
// ============================================================

export const STORE_SYMBOL = Symbol.for('__HIGH_FREQ_STREAM_STORE__');
export const VERSION_SYMBOL = Symbol.for('__HIGH_FREQ_STREAM_VERSION__');
export const MESSAGES_SYMBOL = Symbol.for('__HIGH_FREQ_STREAM_MESSAGES__');

// ============================================================
// 6. ЛОГГЕР (внутренний)
// ============================================================

const LOGGER_SYMBOLS = {
  HISTORY: Symbol('logger.history'),
  MAX_HISTORY: Symbol('logger.maxHistory'),
  DEBUG: Symbol('logger.debug'),
  INSTANCE_ID: Symbol('logger.instanceId'),
  LEVEL: Symbol('logger.level'),
};

function createLogger(debug = true, instanceId = 'Store') {
  const state = {
    [LOGGER_SYMBOLS.HISTORY]: [],
    [LOGGER_SYMBOLS.MAX_HISTORY]: 200,
    [LOGGER_SYMBOLS.DEBUG]: debug,
    [LOGGER_SYMBOLS.INSTANCE_ID]: instanceId,
    [LOGGER_SYMBOLS.LEVEL]: debug ? 3 : 2,
  };

  const logMethod = function (level, message, data = null) {
    const levels = { error: 0, warn: 1, info: 2, debug: 3, success: 2 };
    const currentLevel = this[LOGGER_SYMBOLS.LEVEL] || 2;
    const msgLevel = levels[level] || 2;

    if (msgLevel > currentLevel) return;

    const timestamp = new Date().toISOString().slice(11, 23);
    const prefix = `[${timestamp}] [${this[LOGGER_SYMBOLS.INSTANCE_ID]}]`;

    this[LOGGER_SYMBOLS.HISTORY].push({
      timestamp,
      level,
      message,
      data,
      id: Date.now() + Math.random(),
    });

    if (this[LOGGER_SYMBOLS.HISTORY].length > this[LOGGER_SYMBOLS.MAX_HISTORY]) {
      this[LOGGER_SYMBOLS.HISTORY].shift();
    }

    const icons = { error: '❌', warn: '⚠️', info: 'ℹ️', debug: '🔍', success: '✅' };
    const icon = icons[level] || '📌';

    if (data !== null && data !== undefined) {
      console.log(`${icon} ${prefix} ${message}`, data);
    } else {
      console.log(`${icon} ${prefix} ${message}`);
    }
  };

  const boundLog = logMethod.bind(state);

  const methods = {
    error: (msg, d) => boundLog('error', msg, d),
    warn: (msg, d) => boundLog('warn', msg, d),
    info: (msg, d) => boundLog('info', msg, d),
    debug: (msg, d) => boundLog('debug', msg, d),
    success: (msg, d) => boundLog('success', msg, d),

    header: (title, color = '#636e72') => {
      console.log('%c' + '═'.repeat(70), `color: ${color};`);
      console.log(
        '%c  📦 ' + title,
        'background: #1a1a2e; color: #fff; padding: 4px 12px; border-radius: 4px; font-weight: bold;'
      );
      console.log('%c' + '═'.repeat(70), `color: ${color};`);
    },

    separator: (color = '#636e72') => {
      console.log('%c' + '─'.repeat(70), `color: ${color};`);
    },

    getHistory: function () {
      return [...this[LOGGER_SYMBOLS.HISTORY]];
    },

    clearHistory: function () {
      this[LOGGER_SYMBOLS.HISTORY] = [];
      return this;
    },

    setDebug: function (enabled) {
      this[LOGGER_SYMBOLS.DEBUG] = enabled;
      this[LOGGER_SYMBOLS.LEVEL] = enabled ? 3 : 2;
      return this;
    },
  };

  const logger = {};
  for (const [key, fn] of Object.entries(methods)) {
    logger[key] = fn.bind(state);
  }

  logger[LOGGER_SYMBOLS.HISTORY] = state[LOGGER_SYMBOLS.HISTORY];
  logger[LOGGER_SYMBOLS.MAX_HISTORY] = state[LOGGER_SYMBOLS.MAX_HISTORY];
  logger[LOGGER_SYMBOLS.DEBUG] = state[LOGGER_SYMBOLS.DEBUG];
  logger[LOGGER_SYMBOLS.INSTANCE_ID] = state[LOGGER_SYMBOLS.INSTANCE_ID];
  logger[LOGGER_SYMBOLS.LEVEL] = state[LOGGER_SYMBOLS.LEVEL];

  return logger;
}

// ============================================================
// 7. ВАЛИДАТОР
// ============================================================

const VALIDATOR = {
  [PRIVATE.VALIDATE]: {
    isValidBatch: (batch) => {
      if (!Array.isArray(batch)) return false;
      if (batch.length === 0) return false;
      if (batch.length > 1000) return false;

      return batch.every(
        (item) =>
          item &&
          typeof item === 'object' &&
          typeof item.id === 'number' &&
          typeof item.ts === 'number' &&
          typeof item.val === 'number' &&
          !isNaN(item.val) &&
          isFinite(item.val)
      );
    },

    isValidMessage: (message) => {
      if (!message || typeof message !== 'object') return false;
      if (!message.text || typeof message.text !== 'string') return false;
      if (message.text.length === 0) return false;
      if (message.text.length > 10000) return false;
      if (message.text === 'undefined' || message.text.trim() === '') {
        return false;
      }
      return true;
    },

    isValidStatus: (status) => {
      const validStatuses = ['playing', 'paused', 'disconnected', 'connecting'];
      return validStatuses.includes(status);
    },

    isValidSubscriber: (callback) => {
      return typeof callback === 'function';
    },
  },

  [PRIVATE.SANITIZE]: {
    sanitizeMessage: (message) => {
      if (!message) return null;

      let text = String(message.text || '');
      if (text === 'undefined' || text.trim() === '') {
        return null;
      }

      const sanitized = {
        id: message.id || Date.now() + Math.random(),
        ts: message.ts || Date.now(),
        type: message.type || 'user',
        text: text.substring(0, 10000),
        source: message.source || 'unknown',
        consumerId: message.consumerId || null,
      };

      sanitized.text = sanitized.text
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/\"/g, '&quot;')
        .replace(/'/g, '&#039;');

      return sanitized;
    },

    sanitizeMetric: (metric) => {
      if (!metric) return null;

      return {
        id: typeof metric.id === 'number' ? Math.floor(metric.id) : Date.now() + Math.random(),
        ts: typeof metric.ts === 'number' ? Math.floor(metric.ts) : Date.now(),
        val: typeof metric.val === 'number' ? Math.round(metric.val * 100) / 100 : 0,
        trend: typeof metric.trend === 'number' ? Math.round(metric.trend * 100) / 100 : 50,
      };
    },
  },

  [PRIVATE.SECURE]: {
    escapeHtml: (text) => {
      if (!text) return '';
      return String(text)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/\"/g, '&quot;')
        .replace(/'/g, '&#039;');
    },

    isSafeObject: (obj) => {
      if (!obj || typeof obj !== 'object') return false;

      try {
        if (obj.constructor && obj.constructor.name !== 'Object') {
          return false;
        }

        if (
          Object.getPrototypeOf(obj) !== Object.prototype &&
          Object.getPrototypeOf(obj) !== null
        ) {
          return false;
        }

        const keys = Object.keys(obj);
        for (const key of keys) {
          if (typeof obj[key] === 'function') {
            return false;
          }
        }

        return true;
      } catch {
        return false;
      }
    },
  },
};

// ============================================================
// 8. СОЗДАНИЕ ЗАЩИЩЕННОГО ХРАНИЛИЩА
// ============================================================

function createSecureStore() {
  // Проверяем, не существует ли уже хранилище
  if (globalThis[STORE_SYMBOL]) {
    const existing = globalThis[STORE_SYMBOL];
    if (existing.__version === CONFIG.apiVersion) {
      return existing;
    }
    console.warn('⚠️ Обнаружена старая версия хранилища. Создаем новое.');
  }

  // Получаем глобальное хранилище
  const globalStore = getGlobalStore();

  // Состояние хранилища (приватное)
  const state = {
    [PRIVATE.METRICS]: [],
    [PRIVATE.STATUS]: 'disconnected',
    [PRIVATE.BATCHES]: 0,
    [PRIVATE.MESSAGES]: [],
    [PRIVATE.LAST_UPDATE]: null,
    [PRIVATE.SUBSCRIBERS]: new Set(),
    [PRIVATE.CHANNEL]: null,
    [PRIVATE.MESSAGE_HANDLER]: null,
    [PRIVATE.GLOBAL_STORE]: globalStore,
    [PRIVATE.GLOBAL_SUB_ID]: null,
    [PRIVATE.TABLES_INITIALIZED]: false,
  };

  const logger = createLogger(CONFIG.debug, 'Store');

  // ============================================================
  // 9. ИНИЦИАЛИЗАЦИЯ ТАБЛИЦ В GLOBALSTORE
  // ============================================================

  function initGlobalTables() {
    if (state[PRIVATE.TABLES_INITIALIZED]) return;

    try {
      const gs = state[PRIVATE.GLOBAL_STORE];

      // Создаём таблицу для метрик
      if (!gs.getTable(CONFIG.globalTables.metrics)) {
        gs.createTable(CONFIG.globalTables.metrics, {
          schema: {
            id: { type: 'string', required: true },
            timestamp: { type: 'number', required: true },
            value: { type: 'number', required: true },
            trend: { type: 'number', default: 0 },
            _store: { type: 'string' },
          },
          indexes: ['timestamp', '_store'],
          metadata: {
            description: 'Метрики высокой частоты',
          },
        });
        logger.success('✅ Таблица metrics создана в GlobalStore');
      }

      // Создаём таблицу для сообщений
      if (!gs.getTable(CONFIG.globalTables.messages)) {
        gs.createTable(CONFIG.globalTables.messages, {
          schema: {
            id: { type: 'string', required: true },
            timestamp: { type: 'number', required: true },
            text: { type: 'string', required: true },
            type: { type: 'string', default: 'user' },
            source: { type: 'string', default: 'unknown' },
            consumerId: { type: 'string', nullable: true },
            _store: { type: 'string' },
            _restored: { type: 'boolean', default: false },
          },
          indexes: ['timestamp', 'type', 'source', '_store'],
          metadata: {
            description: 'Сообщения между консюмерами',
          },
        });
        logger.success('✅ Таблица messages создана в GlobalStore');
      }

      // Настраиваем мастер-детейл связи
      if (!gs._detailLinked) {
        gs.linkTables(CONFIG.globalTables.metrics, CONFIG.globalTables.messages, 'metricId');
        gs.linkTables(CONFIG.globalTables.metrics, CONFIG.globalTables.metrics, 'parentId');
        gs._detailLinked = true;
        logger.success('✅ Мастер-детейл связи настроены');
      }

      state[PRIVATE.TABLES_INITIALIZED] = true;
    } catch (error) {
      logger.warn('⚠️ Ошибка инициализации GlobalStore таблиц:', error);
    }
  }

  // ============================================================
  // 10. МЕТОДЫ ХРАНИЛИЩА
  // ============================================================

  const store = {
    __version: CONFIG.apiVersion,
    __created: Date.now(),
    __symbols: { PRIVATE, PUBLIC },

    // ============================================================
    // 10.1. ГЕТТЕРЫ С ВАЛИДАЦИЕЙ
    // ============================================================

    [PRIVATE.GET_STATE]() {
      return {
        liveMetrics: [...state[PRIVATE.METRICS]],
        streamStatus: state[PRIVATE.STATUS],
        totalBatches: state[PRIVATE.BATCHES],
        lastUpdate: state[PRIVATE.LAST_UPDATE],
        messages: [...state[PRIVATE.MESSAGES]],
        messagesCount: state[PRIVATE.MESSAGES].length,
        globalStoreAvailable: !!state[PRIVATE.GLOBAL_STORE],
      };
    },

    getState() {
      return this[PRIVATE.GET_STATE]();
    },

    getMetrics() {
      return [...state[PRIVATE.METRICS]];
    },

    getStatus() {
      return state[PRIVATE.STATUS];
    },

    // ============================================================
    // 10.2. СЕТТЕРЫ С ПРОВЕРКАМИ БЕЗОПАСНОСТИ
    // ============================================================

    setStatus(status) {
      if (!VALIDATOR[PRIVATE.VALIDATE].isValidStatus(status)) {
        logger.warn(`⚠️ Некорректный статус: ${status}`);
        return false;
      }

      state[PRIVATE.STATUS] = status;
      state[PRIVATE.LAST_UPDATE] = Date.now();

      // Обновляем статус в глобальном хранилище
      try {
        const gs = state[PRIVATE.GLOBAL_STORE];
        if (gs) {
          gs.publish('store-status', {
            type: 'status-change',
            payload: { status, timestamp: Date.now() },
          });
        }
      } catch (error) {
        logger.warn('⚠️ Не удалось обновить статус в GlobalStore:', error);
      }

      this[PRIVATE.NOTIFY]();
      logger.debug(`📊 Статус обновлен: ${status}`);
      return true;
    },

    appendDataBatch(batch) {
      if (!VALIDATOR[PRIVATE.VALIDATE].isValidBatch(batch)) {
        logger.warn('⚠️ Некорректный батч данных');
        return false;
      }

      const sanitizedBatch = batch
        .map((item) => VALIDATOR[PRIVATE.SANITIZE].sanitizeMetric(item))
        .filter(Boolean);

      if (sanitizedBatch.length === 0) {
        logger.warn('⚠️ Батч не прошел санитизацию');
        return false;
      }

      const MAX_ITEMS = CONFIG.maxMetrics;
      const updatedList = [...state[PRIVATE.METRICS], ...sanitizedBatch];

      state[PRIVATE.METRICS] =
        updatedList.length > MAX_ITEMS ? updatedList.slice(-MAX_ITEMS) : updatedList;

      state[PRIVATE.BATCHES] += 1;
      state[PRIVATE.LAST_UPDATE] = Date.now();

      // Сохраняем данные в глобальное хранилище
      try {
        const gs = state[PRIVATE.GLOBAL_STORE];
        if (gs) {
          const rows = sanitizedBatch.map((item) => ({
            id: item.id,
            timestamp: item.ts,
            value: item.val,
            trend: item.trend || 0,
            _store: 'high-frequency-stream',
          }));
          gs.insert(CONFIG.globalTables.metrics, rows);
        }
      } catch (error) {
        logger.warn('⚠️ Не удалось сохранить метрики в GlobalStore:', error);
      }

      this[PRIVATE.NOTIFY]();
      logger.debug(
        `📦 Добавлено ${sanitizedBatch.length} записей (всего: ${state[PRIVATE.METRICS].length})`
      );
      return true;
    },

    clearStore() {
      state[PRIVATE.METRICS] = [];
      state[PRIVATE.BATCHES] = 0;
      state[PRIVATE.LAST_UPDATE] = null;

      // Очищаем данные в глобальном хранилище
      try {
        const gs = state[PRIVATE.GLOBAL_STORE];
        if (gs) {
          gs.clearTable(CONFIG.globalTables.metrics);
        }
      } catch (error) {
        logger.warn('⚠️ Не удалось очистить метрики в GlobalStore:', error);
      }

      this[PRIVATE.NOTIFY]();
      logger.success('🗑 Хранилище очищено');
      return true;
    },

    // ============================================================
    // 10.3. МЕТОДЫ ДЛЯ СООБЩЕНИЙ
    // ============================================================

    [PRIVATE.SEND_MESSAGE](message) {
      // Проверки
      if (!message || typeof message !== 'object') {
        logger.warn('⚠️ Некорректное сообщение');
        return false;
      }

      if (message._fromChannel && message._processed) {
        logger.debug('⏭️ Сообщение уже обработано, пропускаем');
        return false;
      }

      if (message.text === 'undefined' || message.text === null || message.text === '') {
        logger.warn('⚠️ Попытка отправить пустое сообщение');
        return false;
      }

      if (!VALIDATOR[PRIVATE.VALIDATE].isValidMessage(message)) {
        logger.warn('⚠️ Некорректное сообщение');
        return false;
      }

      const sanitized = VALIDATOR[PRIVATE.SANITIZE].sanitizeMessage(message);
      if (!sanitized) {
        logger.warn('⚠️ Сообщение не прошло санитизацию');
        return false;
      }

      const msg = {
        ...sanitized,
        _type: 'message',
        _fromChannel: false,
        _receivedAt: Date.now(),
        _processed: false,
      };

      state[PRIVATE.MESSAGES].push(msg);
      if (state[PRIVATE.MESSAGES].length > CONFIG.maxMessages) {
        state[PRIVATE.MESSAGES] = state[PRIVATE.MESSAGES].slice(-CONFIG.maxMessages);
      }

      // Отправляем сообщение через глобальный брокер
      try {
        const gs = state[PRIVATE.GLOBAL_STORE];
        if (gs) {
          gs.publish('messages', {
            type: 'message',
            payload: msg,
          });
        }
      } catch (error) {
        logger.warn('⚠️ Не удалось отправить сообщение через GlobalStore:', error);
      }

      this[PRIVATE.NOTIFY]();
      this[PRIVATE.BROADCAST_MESSAGE](msg);

      logger.debug(`📨 Сообщение отправлено: "${msg.text}"`);
      return true;
    },

    [PRIVATE.BROADCAST_MESSAGE](message) {
      if (!message || typeof message !== 'object') {
        return false;
      }

      const channel = state[PRIVATE.CHANNEL];
      if (channel && typeof channel.postMessage === 'function') {
        try {
          const broadcastMsg = {
            ...message,
            _type: 'broadcast',
            _broadcastAt: Date.now(),
            _processed: true,
          };
          channel.postMessage(broadcastMsg);

          // Публикуем в глобальном брокере
          try {
            const gs = state[PRIVATE.GLOBAL_STORE];
            if (gs) {
              gs.publish('broadcast', {
                type: 'broadcast',
                payload: broadcastMsg,
              });
            }
          } catch (error) {
            logger.warn('⚠️ Не удалось опубликовать broadcast в GlobalStore:', error);
          }

          logger.debug(`📡 Широковещательное сообщение: "${message.text}"`);
          return true;
        } catch (error) {
          logger.error('❌ Ошибка широковещательной отправки:', error);
          return false;
        }
      }
      return false;
    },

    [PRIVATE.HANDLE_INCOMING](message) {
      if (!message || typeof message !== 'object') {
        return false;
      }

      if (message._processed) {
        logger.debug('⏭️ Сообщение уже обработано, пропускаем');
        return false;
      }

      if (message._fromChannel) {
        logger.debug('⏭️ Сообщение из канала, пропускаем');
        return false;
      }

      if (message._restored) {
        logger.debug('⏭️ Восстановленное сообщение, пропускаем');
        return false;
      }

      const sanitized = VALIDATOR[PRIVATE.SANITIZE].sanitizeMessage(message);
      if (!sanitized) return false;

      const msg = {
        ...sanitized,
        _type: message._type || 'message',
        _fromChannel: true,
        _receivedAt: Date.now(),
        _processed: true,
      };

      state[PRIVATE.MESSAGES].push(msg);
      if (state[PRIVATE.MESSAGES].length > CONFIG.maxMessages) {
        state[PRIVATE.MESSAGES] = state[PRIVATE.MESSAGES].slice(-CONFIG.maxMessages);
      }

      // Сохраняем в глобальное хранилище
      try {
        const gs = state[PRIVATE.GLOBAL_STORE];
        if (gs) {
          gs.insert(CONFIG.globalTables.messages, {
            id: msg.id,
            timestamp: msg.ts,
            text: msg.text,
            type: msg.type,
            source: msg.source,
            consumerId: msg.consumerId || null,
            _store: 'high-frequency-stream',
          });
        }
      } catch (error) {
        logger.warn('⚠️ Не удалось сохранить сообщение в GlobalStore:', error);
      }

      this[PRIVATE.NOTIFY]();
      logger.debug(`📨 Входящее сообщение от ${msg.source || 'unknown'}: "${msg.text}"`);
      return true;
    },

    sendMessage(message) {
      return this[PRIVATE.SEND_MESSAGE](message);
    },

    broadcastMessage(message) {
      return this[PRIVATE.BROADCAST_MESSAGE](message);
    },

    getMessages(limit = 50) {
      const messages = state[PRIVATE.MESSAGES];
      if (!messages || messages.length === 0) {
        // Пытаемся получить из GlobalStore
        try {
          const gs = state[PRIVATE.GLOBAL_STORE];
          if (gs) {
            const table = gs.getTable(CONFIG.globalTables.messages);
            if (table && table.data.length > 0) {
              const globalMessages = table.data
                .filter((row) => row._store === 'high-frequency-stream')
                .map((row) => ({
                  id: row.id,
                  ts: row.timestamp,
                  text: row.text,
                  type: row.type || 'user',
                  source: row.source || 'unknown',
                  consumerId: row.consumerId || null,
                }));
              // Сортируем по времени
              globalMessages.sort((a, b) => (a.ts || 0) - (b.ts || 0));
              return globalMessages.slice(-Math.min(limit, globalMessages.length));
            }
          }
        } catch (error) {
          logger.warn('⚠️ Не удалось получить сообщения из GlobalStore:', error);
        }
        return [];
      }

      return messages.slice(-Math.min(limit, messages.length));
    },

    clearMessages() {
      state[PRIVATE.MESSAGES] = [];

      // Очищаем в глобальном хранилище
      try {
        const gs = state[PRIVATE.GLOBAL_STORE];
        if (gs) {
          gs.clearTable(CONFIG.globalTables.messages);
        }
      } catch (error) {
        logger.warn('⚠️ Не удалось очистить сообщения в GlobalStore:', error);
      }

      this[PRIVATE.NOTIFY]();
      logger.success('🧹 История сообщений очищена');
      return true;
    },

    // ============================================================
    // 10.4. REPLACE MESSAGES
    // ============================================================

    [PRIVATE.REPLACE_MESSAGES](messages) {
      if (!Array.isArray(messages)) {
        logger.warn('⚠️ replaceMessages: ожидается массив');
        return false;
      }

      if (messages.length === 0) {
        logger.warn('⚠️ replaceMessages: пустой массив');
        return false;
      }

      const sanitizedMessages = messages
        .map((msg) => {
          try {
            return VALIDATOR[PRIVATE.SANITIZE].sanitizeMessage(msg);
          } catch (error) {
            logger.warn('⚠️ Ошибка санитизации сообщения:', error);
            return null;
          }
        })
        .filter(Boolean);

      if (sanitizedMessages.length === 0) {
        logger.warn('⚠️ replaceMessages: нет валидных сообщений');
        return false;
      }

      const markedMessages = sanitizedMessages.map((msg) => ({
        ...msg,
        _restored: true,
        _fromChannel: false,
        _processed: true,
        _type: 'restored',
        _restoredAt: Date.now(),
      }));

      if (markedMessages.length > CONFIG.maxMessages) {
        state[PRIVATE.MESSAGES] = markedMessages.slice(-CONFIG.maxMessages);
      } else {
        state[PRIVATE.MESSAGES] = markedMessages;
      }

      // Сохраняем в глобальное хранилище
      try {
        const gs = state[PRIVATE.GLOBAL_STORE];
        if (gs) {
          const rows = markedMessages.map((msg) => ({
            id: msg.id,
            timestamp: msg.ts,
            text: msg.text,
            type: msg.type || 'restored',
            source: msg.source || 'restored',
            consumerId: msg.consumerId || null,
            _store: 'high-frequency-stream',
            _restored: true,
          }));
          gs.insert(CONFIG.globalTables.messages, rows);
        }
      } catch (error) {
        logger.warn('⚠️ Не удалось сохранить восстановленные сообщения в GlobalStore:', error);
      }

      this[PRIVATE.NOTIFY]();
      logger.success(`📨 Восстановлено ${state[PRIVATE.MESSAGES].length} сообщений (без отправки)`);
      return true;
    },

    replaceMessages(messages) {
      return this[PRIVATE.REPLACE_MESSAGES](messages);
    },

    // ============================================================
    // 10.5. ПОДПИСКА
    // ============================================================

    subscribe(callback) {
      if (!VALIDATOR[PRIVATE.VALIDATE].isValidSubscriber(callback)) {
        logger.warn('⚠️ Подписка требует функцию');
        return () => {};
      }

      state[PRIVATE.SUBSCRIBERS].add(callback);

      // Также подписываемся на глобальные события
      try {
        const gs = state[PRIVATE.GLOBAL_STORE];
        if (gs) {
          const globalSubId = gs.subscribe('*', (channel, message) => {
            if (message.type === 'store-event') {
              try {
                callback(this[PRIVATE.GET_STATE]());
              } catch (error) {
                logger.error('❌ Ошибка в глобальном подписчике:', error);
              }
            }
          });
          state[PRIVATE.GLOBAL_SUB_ID] = globalSubId;
        }
      } catch (error) {
        logger.warn('⚠️ Не удалось подписаться на глобальные события:', error);
      }

      return () => {
        state[PRIVATE.SUBSCRIBERS].delete(callback);
        if (state[PRIVATE.GLOBAL_SUB_ID]) {
          try {
            const gs = state[PRIVATE.GLOBAL_STORE];
            if (gs) {
              gs.unsubscribe('*', state[PRIVATE.GLOBAL_SUB_ID]);
            }
          } catch (error) {
            logger.warn('⚠️ Не удалось отписаться от глобальных событий:', error);
          }
          state[PRIVATE.GLOBAL_SUB_ID] = null;
        }
      };
    },

    [PRIVATE.NOTIFY]() {
      const snapshot = this[PRIVATE.GET_STATE]();
      const subscribers = [...state[PRIVATE.SUBSCRIBERS]];
      for (const callback of subscribers) {
        try {
          callback(snapshot);
        } catch (error) {
          logger.error('❌ Ошибка в подписчике:', error);
        }
      }
    },

    // ============================================================
    // 10.6. ДОСТУП К GLOBALSTORE
    // ============================================================

    getGlobalStore() {
      return state[PRIVATE.GLOBAL_STORE];
    },

    // ============================================================
    // 10.7. ИНИЦИАЛИЗАЦИЯ
    // ============================================================

    [PRIVATE.INIT]() {
      logger.header('ИНИЦИАЛИЗАЦИЯ ХРАНИЛИЩА (100% СИМВОЛЫ)');
      logger.info(`📦 Версия: ${CONFIG.version}`);
      logger.info(`📅 Сборка: ${CONFIG.build}`);
      logger.info(`📌 Отладка: ${CONFIG.debug ? '✅' : '❌'}`);
      logger.separator();

      // Инициализируем таблицы в GlobalStore
      initGlobalTables();

      // Проверяем доступность GlobalStore
      const gs = state[PRIVATE.GLOBAL_STORE];
      if (gs) {
        logger.success('✅ GlobalStore доступен');
        try {
          const health = gs.healthCheck();
          logger.info(`  📊 Таблиц: ${health.tables}`);
          logger.info(`  💬 Сообщений: ${health.messages}`);
          logger.info(`  🔒 Подписчиков: ${health.subscribers}`);
        } catch (error) {
          logger.warn('⚠️ Ошибка проверки GlobalStore:', error);
        }
      } else {
        logger.warn('⚠️ GlobalStore не доступен');
      }

      // BroadcastChannel
      if (typeof BroadcastChannel !== 'undefined') {
        try {
          const channel = new BroadcastChannel(CONFIG.channelName);

          const handler = (event) => {
            if (event.target !== channel) return;
            const data = event.data;

            if (data && data._type === 'broadcast') {
              this[PRIVATE.HANDLE_INCOMING](data);
            }
          };

          channel.addEventListener('message', handler);

          state[PRIVATE.CHANNEL] = channel;
          state[PRIVATE.MESSAGE_HANDLER] = handler;

          logger.success(`✅ BroadcastChannel инициализирован: ${CONFIG.channelName}`);
        } catch (error) {
          logger.warn(`⚠️ Ошибка инициализации BroadcastChannel: ${error.message}`);
        }
      } else {
        logger.warn('⚠️ BroadcastChannel не поддерживается');
      }

      // Экспортируем символы
      this[PRIVATE.EXPORT_SYMBOLS]();

      state[PRIVATE.INITIALIZED] = true;
      logger.success('✅ Хранилище инициализировано (с поддержкой GlobalStore)');
      logger.header('ГОТОВ');
    },

    // ============================================================
    // 10.8. ЭКСПОРТ СИМВОЛОВ
    // ============================================================

    [PRIVATE.EXPORT_SYMBOLS]() {
      if (typeof window !== 'undefined') {
        window[STORE_SYMBOL] = this;
        window[VERSION_SYMBOL] = CONFIG.version;
        window[MESSAGES_SYMBOL] = {
          send: this.sendMessage.bind(this),
          broadcast: this.broadcastMessage.bind(this),
          get: this.getMessages.bind(this),
          clear: this.clearMessages.bind(this),
          replace: this.replaceMessages.bind(this),
        };

        window.__store = this;
        window.__storeSymbols = {
          PRIVATE: { ...PRIVATE },
          PUBLIC: { ...PUBLIC },
        };

        // Ссылка на глобальное хранилище
        const gs = state[PRIVATE.GLOBAL_STORE];
        if (gs) {
          window.__globalStore = gs;
          window[GLOBAL_STORE_SYMBOL] = gs;
        }
      }
    },

    // ============================================================
    // 10.9. ПРОВЕРКА ЦЕЛОСТНОСТИ
    // ============================================================

    healthCheck() {
      const gs = state[PRIVATE.GLOBAL_STORE];
      const gsHealth = gs ? gs.healthCheck() : null;

      return {
        version: this.__version,
        created: this.__created,
        metricsCount: state[PRIVATE.METRICS].length,
        status: state[PRIVATE.STATUS],
        subscribers: state[PRIVATE.SUBSCRIBERS].size,
        messagesCount: state[PRIVATE.MESSAGES].length,
        batches: state[PRIVATE.BATCHES],
        channelActive: !!state[PRIVATE.CHANNEL],
        lastUpdate: state[PRIVATE.LAST_UPDATE],
        isValid: true,
        globalStoreAvailable: !!gs,
        globalStoreHealth: gsHealth,
        tablesInitialized: state[PRIVATE.TABLES_INITIALIZED],
      };
    },

    // ============================================================
    // 10.10. УНИЧТОЖЕНИЕ
    // ============================================================

    [PRIVATE.DESTROY]() {
      if (state[PRIVATE.IS_DESTROYED]) {
        logger.warn('⚠️ Хранилище уже уничтожено');
        return;
      }

      logger.warn('🗑️ Уничтожение хранилища...');

      const channel = state[PRIVATE.CHANNEL];
      if (channel) {
        try {
          const handler = state[PRIVATE.MESSAGE_HANDLER];
          if (handler) {
            channel.removeEventListener('message', handler);
          }
          channel.close();
        } catch (error) {
          logger.error('❌ Ошибка закрытия канала:', error);
        }
        state[PRIVATE.CHANNEL] = null;
        state[PRIVATE.MESSAGE_HANDLER] = null;
      }

      // Отписываемся от глобальных событий
      if (state[PRIVATE.GLOBAL_SUB_ID]) {
        try {
          const gs = state[PRIVATE.GLOBAL_STORE];
          if (gs) {
            gs.unsubscribe('*', state[PRIVATE.GLOBAL_SUB_ID]);
          }
        } catch (error) {
          logger.warn('⚠️ Ошибка отписки от GlobalStore:', error);
        }
        state[PRIVATE.GLOBAL_SUB_ID] = null;
      }

      state[PRIVATE.METRICS] = [];
      state[PRIVATE.MESSAGES] = [];
      state[PRIVATE.SUBSCRIBERS].clear();
      state[PRIVATE.IS_DESTROYED] = true;
      state[PRIVATE.INITIALIZED] = false;

      if (typeof window !== 'undefined') {
        delete window[STORE_SYMBOL];
        delete window[VERSION_SYMBOL];
        delete window[MESSAGES_SYMBOL];
        delete window.__store;
        delete window.__storeSymbols;
      }

      logger.success('✅ Хранилище уничтожено');
    },

    destroy() {
      this[PRIVATE.DESTROY]();
    },
  };

  // ============================================================
  // 11. ИНИЦИАЛИЗАЦИЯ
  // ============================================================

  store[PRIVATE.INIT]();

  globalThis[STORE_SYMBOL] = store;

  return store;
}

// ============================================================
// 12. ЭКСПОРТ СИНГЛТОНА
// ============================================================

export const globalStore = createSecureStore();

// ============================================================
// 13. ФУНКЦИЯ ПРОВЕРКИ ДОСТУПА
// ============================================================

export function checkStoreAccess(store) {
  if (!store || typeof store !== 'object') {
    return { valid: false, error: 'Store не является объектом' };
  }

  if (!store.__version || store.__version !== CONFIG.apiVersion) {
    return { valid: false, error: `Несовместимая версия: ${store.__version}` };
  }

  const requiredMethods = [
    'getState',
    'getMetrics',
    'getStatus',
    'setStatus',
    'appendDataBatch',
    'clearStore',
    'sendMessage',
    'broadcastMessage',
    'getMessages',
    'clearMessages',
    'replaceMessages',
    'subscribe',
    'healthCheck',
    'getGlobalStore',
  ];

  for (const method of requiredMethods) {
    if (typeof store[method] !== 'function') {
      return { valid: false, error: `Отсутствует метод: ${method}` };
    }
  }

  return { valid: true, store };
}

// ============================================================
// 14. ДОПОЛНИТЕЛЬНЫЕ ЭКСПОРТЫ
// ============================================================

export const STORE_KEY = STORE_SYMBOL;
export const MESSAGES_KEY = MESSAGES_SYMBOL;
export const STORE_CONFIG = CONFIG;

// ============================================================
// 15. ЭКСПОРТ СИМВОЛОВ
// ============================================================

export { PRIVATE as STORE_PRIVATE, PUBLIC as STORE_PUBLIC };

// ============================================================
// 16. ЭКСПОРТ ПО УМОЛЧАНИЮ
// ============================================================

export default globalStore;

// ============================================================
// 17. СТАТИСТИКА СИМВОЛОВ
// ============================================================

if (typeof console !== 'undefined') {
  const privateCount = Object.keys(PRIVATE).length;
  const publicCount = Object.keys(PUBLIC).length;

  console.log('╔═══════════════════════════════════════════════════════════════════════════════╗');
  console.log('║              📦 SECURE STORE v3.0.0 (100% СИМВОЛЫ)                          ║');
  console.log('╠═══════════════════════════════════════════════════════════════════════════════╣');
  console.log(
    `║  🔑 Приватных символов: ${privateCount.toString().padStart(2, ' ')}                                           ║`
  );
  console.log(
    `║  🔓 Публичных символов: ${publicCount.toString().padStart(2, ' ')}                                            ║`
  );
  console.log(
    `║  📦 Всего символов: ${(privateCount + publicCount).toString().padStart(2, ' ')}                                          ║`
  );
  console.log('╠═══════════════════════════════════════════════════════════════════════════════╣');
  console.log('║  📋 Интеграция с GlobalStore                                                ║');
  console.log('║  📊 Данные синхронизируются в глобальных таблицах                           ║');
  console.log('║  📡 Сообщения передаются через глобальный брокер                            ║');
  console.log('║  🔄 Мастер-детейл связи между таблицами                                     ║');
  console.log('║  💾 Автоматическое сохранение в GlobalStore                                 ║');
  console.log('║  🛡️ Полная изоляция через приватные символы                                ║');
  console.log('║  🔓 Публичные символы через Symbol.for                                      ║');
  console.log('║  📨 Отправка и получение сообщений через глобальный стор                    ║');
  console.log('║  📡 Широковещательные сообщения через BroadcastChannel                      ║');
  console.log('║  ⚠️ Расширенная валидация и санитизация                                    ║');
  console.log('║  🛡️ Защита от циклических зависимостей                                     ║');
  console.log('║  💾 replaceMessages - безопасное восстановление сообщений                   ║');
  console.log('╚═══════════════════════════════════════════════════════════════════════════════╝');

  console.log('📋 ДОСТУПНЫЕ КОМАНДЫ:');
  console.log('  window.__store.getState()              - получить состояние');
  console.log('  window.__store.getMetrics()            - получить метрики');
  console.log('  window.__store.setStatus(status)       - установить статус');
  console.log('  window.__store.appendDataBatch(batch)  - добавить данные');
  console.log('  window.__store.clearStore()            - очистить хранилище');
  console.log('  window.__store.sendMessage(message)    - отправить сообщение');
  console.log('  window.__store.broadcastMessage(msg)   - широковещательная отправка');
  console.log('  window.__store.getMessages(limit)      - получить историю сообщений');
  console.log('  window.__store.clearMessages()         - очистить историю');
  console.log('  window.__store.replaceMessages(msg)    - восстановить сообщения');
  console.log('  window.__store.subscribe(callback)     - подписаться на изменения');
  console.log('  window.__store.healthCheck()           - проверка целостности');
  console.log('  window.__store.getGlobalStore()        - доступ к GlobalStore');
  console.log('  window.__store.destroy()               - уничтожить хранилище');
  console.log('');

  console.log('📨 КОМАНДЫ ДЛЯ СООБЩЕНИЙ:');
  console.log('  window.__store.sendMessage({ text: "Hello", type: "user" })');
  console.log('  window.__store.broadcastMessage({ text: "Broadcast!" })');
  console.log('  window.__store.getMessages(20)         - последние 20 сообщений');
  console.log('  window.__store.replaceMessages([...])  - восстановить сообщения');
  console.log('');

  console.log('📊 СТАТИСТИКА СИМВОЛОВ:');
  console.log(`  🔑 Приватных символов: ${privateCount}`);
  console.log(`  🔓 Публичных символов: ${publicCount}`);
  console.log(`  📦 Всего символов: ${privateCount + publicCount}`);
  console.log('');

  console.log('📋 КОМАНДЫ ОТЛАДКИ:');
  console.log('  window.__storeSymbols         - все символы');
  console.log('  window.__store.healthCheck()  - проверка целостности');
  console.log('  window.__store.getMessages()  - история сообщений');
  console.log('  window.__store.getGlobalStore() - доступ к GlobalStore');
  console.log('');

  console.log('✅ Secure Store v3.0.0 загружен (100% символы)');
}
