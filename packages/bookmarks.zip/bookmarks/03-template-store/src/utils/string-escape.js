// src/utils/string-escape.js
// УНИВЕРСАЛЬНОЕ ЭКРАНИРОВАНИЕ СТРОК ДЛЯ БУКМАРКЛЕТОВ
// Версия: 4.0.0 - Автоматический выбор метода

// ============================================================
// 1. УНИВЕРСАЛЬНАЯ ФУНКЦИЯ ЭКРАНИРОВАНИЯ
// ============================================================

/**
 * Универсальное экранирование строки для безопасной вставки в букмарклет
 * Автоматически выбирает оптимальный метод на основе контекста
 *
 * @param {string} str - Строка для экранирования
 * @param {string} context - Контекст вставки: 'single', 'double', 'template', 'auto'
 * @returns {string} - Экранированная строка
 *
 * @example
 * escapeString('Hello "world"', 'single')  // => 'Hello \\"world\\"'
 * escapeString("Hello 'world'", 'double')  // => "Hello \\'world\\'"
 * escapeString('Hello ${world}', 'template') // => 'Hello \\${world}'
 * escapeString('Hello "world"', 'auto')    // => 'Hello \\"world\\"'
 */
function escapeString(str, context = 'auto') {
    // Приводим к строке
    if (typeof str !== 'string') {
        str = String(str);
    }

    // Если строка пустая - возвращаем как есть
    if (str.length === 0) {
        return str;
    }

    // Анализируем строку для автоматического выбора
    if (context === 'auto') {
        // Проверяем наличие спецсимволов
        const hasSpecialChars = /[\\"'`\n\r\t\f\b\v\u2028\u2029\0<>]/.test(str);

        if (!hasSpecialChars) {
            return str; // Безопасно без экранирования
        }

        // Проверяем наличие кавычек
        const hasSingleQuote = str.includes("'");
        const hasDoubleQuote = str.includes('"');
        const hasTemplate = str.includes('`') || str.includes('${');

        // Выбираем метод на основе содержимого
        if (hasTemplate && !hasDoubleQuote && !hasSingleQuote) {
            context = 'template';
        } else if (hasDoubleQuote && !hasSingleQuote) {
            context = 'single';
        } else if (hasSingleQuote && !hasDoubleQuote) {
            context = 'double';
        } else {
            // Если есть все виды кавычек - используем самый безопасный метод
            context = 'full';
        }
    }

    // Применяем выбранный метод
    switch (context) {
        case 'single':
            return escapeForSingleQuotes(str);
        case 'double':
            return escapeForDoubleQuotes(str);
        case 'template':
            return escapeForTemplate(str);
        case 'full':
            return escapeFull(str);
        case 'html':
            return escapeForHtml(str);
        case 'url':
            return escapeForUrl(str);
        case 'none':
            return str;
        default:
            // Если метод не распознан - используем полное экранирование
            return escapeFull(str);
    }
}

// ============================================================
// 2. МЕТОДЫ ЭКРАНИРОВАНИЯ ДЛЯ РАЗНЫХ КОНТЕКСТОВ
// ============================================================

/**
 * Экранирование для вставки в одинарные кавычки ('')
 */
function escapeForSingleQuotes(str) {
    return str
        .replace(/\\/g, '\\\\')
        .replace(/'/g, "\\'")
        .replace(/\n/g, '\\n')
        .replace(/\r/g, '\\r')
        .replace(/\t/g, '\\t')
        .replace(/\f/g, '\\f')
        .replace(/\b/g, '\\b')
        .replace(/\v/g, '\\v')
        .replace(/\u2028/g, '\\u2028')
        .replace(/\u2029/g, '\\u2029')
        .replace(/\0/g, '\\0');
}

/**
 * Экранирование для вставки в двойные кавычки ("")
 */
function escapeForDoubleQuotes(str) {
    return str
        .replace(/\\/g, '\\\\')
        .replace(/"/g, '\\"')
        .replace(/\n/g, '\\n')
        .replace(/\r/g, '\\r')
        .replace(/\t/g, '\\t')
        .replace(/\f/g, '\\f')
        .replace(/\b/g, '\\b')
        .replace(/\v/g, '\\v')
        .replace(/\u2028/g, '\\u2028')
        .replace(/\u2029/g, '\\u2029')
        .replace(/\0/g, '\\0');
}

/**
 * Экранирование для вставки в шаблонные строки (``)
 */
function escapeForTemplate(str) {
    return str
        .replace(/\\/g, '\\\\')
        .replace(/`/g, '\\`')
        .replace(/\${/g, '\\${')
        .replace(/\n/g, '\\n')
        .replace(/\r/g, '\\r')
        .replace(/\t/g, '\\t')
        .replace(/\f/g, '\\f')
        .replace(/\b/g, '\\b')
        .replace(/\v/g, '\\v')
        .replace(/\u2028/g, '\\u2028')
        .replace(/\u2029/g, '\\u2029')
        .replace(/\0/g, '\\0');
}

/**
 * ПОЛНОЕ экранирование (самый безопасный метод)
 * Экранирует ВСЕ возможные опасные символы
 */
function escapeFull(str) {
    return str
        // Обратный слеш (должен быть первым!)
        .replace(/\\/g, '\\\\')

        // Все виды кавычек
        .replace(/"/g, '\\"')
        .replace(/'/g, "\\'")
        .replace(/`/g, '\\`')
        .replace(/\${/g, '\\${')

        // Управляющие символы
        .replace(/\n/g, '\\n')
        .replace(/\r/g, '\\r')
        .replace(/\t/g, '\\t')
        .replace(/\f/g, '\\f')
        .replace(/\b/g, '\\b')
        .replace(/\v/g, '\\v')

        // Специальные Unicode символы
        .replace(/\u2028/g, '\\u2028')
        .replace(/\u2029/g, '\\u2029')

        // Нулевой символ
        .replace(/\0/g, '\\0')

        // HTML символы
        .replace(/</g, '\\x3C')
        .replace(/>/g, '\\x3E')
        .replace(/&/g, '\\x26')

        // URL символы
        .replace(/ /g, '%20')
        .replace(/#/g, '%23')
        .replace(/%/g, '%25');
}

/**
 * Экранирование для HTML
 */
function escapeForHtml(str) {
    return str
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;')
        .replace(/`/g, '&#96;');
}

/**
 * Экранирование для URL
 */
function escapeForUrl(str) {
    return encodeURIComponent(str);
}

// ============================================================
// 3. ОБРАТНОЕ РАСКОДИРОВАНИЕ
// ============================================================

/**
 * Универсальное раскодирование экранированной строки
 */
function unescapeString(str, context = 'auto') {
    if (typeof str !== 'string') return '';

    // Автоматически определяем метод
    if (context === 'auto') {
        if (str.includes('%20') || str.includes('%23')) {
            return unescapeUrl(str);
        }
        if (str.includes('&amp;') || str.includes('&lt;')) {
            return unescapeHtml(str);
        }
        return unescapeFull(str);
    }

    switch (context) {
        case 'single':
        case 'double':
        case 'template':
        case 'full':
            return unescapeFull(str);
        case 'html':
            return unescapeHtml(str);
        case 'url':
            return unescapeUrl(str);
        default:
            return unescapeFull(str);
    }
}

function unescapeFull(str) {
    return str
        .replace(/\\n/g, '\n')
        .replace(/\\r/g, '\r')
        .replace(/\\t/g, '\t')
        .replace(/\\f/g, '\f')
        .replace(/\\b/g, '\b')
        .replace(/\\v/g, '\v')
        .replace(/\\0/g, '\0')
        .replace(/\\'/g, "'")
        .replace(/\\"/g, '"')
        .replace(/\\`/g, '`')
        .replace(/\\\${/g, '${')
        .replace(/\\\\/g, '\\')
        .replace(/\\u2028/g, '\u2028')
        .replace(/\\u2029/g, '\u2029')
        .replace(/\\x3C/g, '<')
        .replace(/\\x3E/g, '>')
        .replace(/\\x26/g, '&')
        .replace(/%20/g, ' ')
        .replace(/%23/g, '#')
        .replace(/%25/g, '%');
}

function unescapeHtml(str) {
    return str
        .replace(/&amp;/g, '&')
        .replace(/&lt;/g, '<')
        .replace(/&gt;/g, '>')
        .replace(/&quot;/g, '"')
        .replace(/&#039;/g, "'")
        .replace(/&#96;/g, '`');
}

function unescapeUrl(str) {
    return decodeURIComponent(str);
}

// ============================================================
// 4. УНИВЕРСАЛЬНОЕ СОЗДАНИЕ БУКМАРКЛЕТА
// ============================================================

/**
 * Универсальное создание букмарклета с автоматическим экранированием
 *
 * @param {string} scriptCode - Код для букмарклета
 * @param {string} baseUrl - Базовый URL
 * @param {Object} options - Опции
 * @param {string} options.escapeContext - 'single', 'double', 'template', 'full', 'auto'
 * @param {boolean} options.useFunctionConstructor - Использовать Function constructor
 * @param {boolean} options.minify - Минифицировать результат
 * @returns {string} - Готовый букмарклет
 */
function createBookmarklet(scriptCode, baseUrl, options = {}) {
    const {
        escapeContext = 'auto',
        useFunctionConstructor = true,
        minify = false,
    } = options;

    // Подготавливаем код
    let cleanCode = scriptCode;
    if (cleanCode.startsWith('javascript:')) {
        cleanCode = cleanCode.substring(11);
    }

    // Удаляем IIFE обертки
    cleanCode = cleanCode
        .replace(/^\(\s*async\s*function\s*\(\)\s*\{/, '')
        .replace(/\}\s*\)\s*\(\s*\)\s*;?\s*$/, '')
        .replace(/^\(\s*function\s*\(\)\s*\{/, '')
        .replace(/\}\s*\)\s*\(\s*\)\s*;?\s*$/, '')
        .trim();

    // Экранируем
    const escapedCode = escapeString(cleanCode, escapeContext);
    const escapedBaseUrl = escapeString(baseUrl, escapeContext);

    // Создаем букмарклет
    let bookmarklet;

    if (useFunctionConstructor) {
        bookmarklet = `javascript: (async function() {
            try {
                const code = '${escapedCode}';
                const baseUrl = '${escapedBaseUrl}';
                const fn = new Function('baseUrl', code);
                await fn(baseUrl);
            } catch (error) {
                console.error('❌ Bookmarklet error:', error);
                alert('❌ Ошибка: ' + error.message);
            }
        })();`;
    } else {
        bookmarklet = `javascript: (async function() {
            try {
                const code = '${escapedCode}';
                const baseUrl = '${escapedBaseUrl}';
                eval(code);
            } catch (error) {
                console.error('❌ Bookmarklet error:', error);
                alert('❌ Ошибка: ' + error.message);
            }
        })();`;
    }

    // Минифицируем если нужно
    if (minify) {
        bookmarklet = minifyBookmarklet(bookmarklet);
    }

    return bookmarklet;
}

// ============================================================
// 5. МИНИФИКАЦИЯ БУКМАРКЛЕТА
// ============================================================

function minifyBookmarklet(code) {
    return code
        .replace(/\/\/.*$/gm, '')
        .replace(/\/\*[\s\S]*?\*\//g, '')
        .replace(/\s+/g, ' ')
        .replace(/\s*([{}()\[\];:,=+*/<>&|!?])\s*/g, '$1')
        .replace(/;+/g, ';')
        .trim();
}

// ============================================================
// 6. ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ
// ============================================================

/**
 * Анализирует строку и рекомендует оптимальный метод экранирования
 */
function analyzeString(str) {
    if (typeof str !== 'string') str = String(str);

    const result = {
        length: str.length,
        hasBackslash: str.includes('\\'),
        hasSingleQuote: str.includes("'"),
        hasDoubleQuote: str.includes('"'),
        hasTemplate: str.includes('`') || str.includes('${'),
        hasNewline: str.includes('\n'),
        hasTab: str.includes('\t'),
        hasUnicode: /[\u2028\u2029]/.test(str),
        hasHtml: /[<>&]/.test(str),
        recommended: 'none',
        reason: '',
    };

    // Рекомендуем метод
    if (result.hasTemplate && !result.hasDoubleQuote && !result.hasSingleQuote) {
        result.recommended = 'template';
        result.reason = 'Содержит шаблонные строки, но нет кавычек';
    } else if (result.hasDoubleQuote && !result.hasSingleQuote) {
        result.recommended = 'single';
        result.reason = 'Содержит двойные кавычки, но нет одинарных';
    } else if (result.hasSingleQuote && !result.hasDoubleQuote) {
        result.recommended = 'double';
        result.reason = 'Содержит одинарные кавычки, но нет двойных';
    } else if (result.hasHtml) {
        result.recommended = 'full';
        result.reason = 'Содержит HTML символы';
    } else if (result.hasBackslash || result.hasNewline || result.hasTab || result.hasUnicode) {
        result.recommended = 'full';
        result.reason = 'Содержит спецсимволы';
    } else {
        result.recommended = 'none';
        result.reason = 'Строка безопасна без экранирования';
    }

    return result;
}

/**
 * Тестирует экранирование на всех проблемных строках
 */
function testEscape() {
    const tests = [
        { str: "Hello 'world'", expected: "Hello \\'world\\'" },
        { str: 'Hello "world"', expected: 'Hello \\"world\\"' },
        { str: "Hello \\ world", expected: "Hello \\\\ world" },
        { str: "Line1\nLine2", expected: "Line1\\nLine2" },
        { str: "Tab\tseparated", expected: "Tab\\tseparated" },
        { str: "Carriage\rreturn", expected: "Carriage\\rreturn" },
        { str: "Привет мир", expected: "Привет мир" },
        { str: "Hello 🌍", expected: "Hello 🌍" },
        { str: "Mixed: 'single' \"double\" \\backslash\nnewline\t tab", expected: "Mixed: \\'single\\' \\\"double\\\" \\\\backslash\\nnewline\\ttab" },
        { str: "Template: ${variable}", expected: "Template: \\${variable}" },
        { str: "Backtick: `test`", expected: "Backtick: \\`test\\`" },
        { str: "Special: < > &", expected: "Special: \\x3C \\x3E \\x26" },
    ];

    console.log('🧪 Тестирование экранирования:');
    console.log('═'.repeat(60));

    let passed = 0;
    let failed = 0;

    for (const test of tests) {
        const result = escapeString(test.str, 'full');
        if (result === test.expected) {
            console.log(`✅ PASS: "${test.str.substring(0, 30)}${test.str.length > 30 ? '...' : ''}"`);
            passed++;
        } else {
            console.log(`❌ FAIL: "${test.str}"`);
            console.log(`   Expected: ${test.expected}`);
            console.log(`   Got:      ${result}`);
            failed++;
        }
    }

    console.log('═'.repeat(60));
    console.log(`📊 Результат: ${passed} passed, ${failed} failed`);
    return { passed, failed };
}

// ============================================================
// 7. ЭКСПОРТЫ
// ============================================================

export {
    // Основная функция
    escapeString,
    unescapeString,
    createBookmarklet,

    // Специализированные методы
    escapeForSingleQuotes,
    escapeForDoubleQuotes,
    escapeForTemplate,
    escapeFull,
    escapeForHtml,
    escapeForUrl,

    // Вспомогательные
    analyzeString,
    testEscape,
    minifyBookmarklet,
};

// Экспорт по умолчанию
export default {
    escapeString,
    unescapeString,
    createBookmarklet,
    escapeForSingleQuotes,
    escapeForDoubleQuotes,
    escapeForTemplate,
    escapeFull,
    escapeForHtml,
    escapeForUrl,
    analyzeString,
    testEscape,
    minifyBookmarklet,
};