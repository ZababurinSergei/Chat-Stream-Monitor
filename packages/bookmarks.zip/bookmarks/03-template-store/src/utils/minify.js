// src/utils/minify.js
// 100% СИМВОЛЫ — полная изоляция и безопасность
// Версия: 4.0.1 — ИСПРАВЛЕН ВОЗВРАТ СТРОКИ ДЛЯ БУКМАРКЛЕТОВ
// Для букмарклетов используем простую минификацию, для JS — SWC

// ============================================================
// 1. ИМПОРТЫ
// ============================================================

import initSwc, { minifySync, transformSync } from '@swc/wasm-web';

// ============================================================
// 2. ПРИВАТНЫЕ СИМВОЛЫ (100% изоляция)
// ============================================================

const PRIVATE_SYMBOLS = {
  VERSION: Symbol('minify.version'),
  BUILD: Symbol('minify.build'),
  NAME: Symbol('minify.name'),
  CONFIG: Symbol('minify.config'),
  CACHE: Symbol('minify.cache'),
  STATE: Symbol('minify.state'),
  STATS: Symbol('minify.stats'),
  INIT: Symbol('minify.init'),
  RESET: Symbol('minify.reset'),
  DESTROY: Symbol('minify.destroy'),
  GET_STATE: Symbol('minify.getState'),
  GET_STATS: Symbol('minify.getStats'),
  VALIDATE_INPUT: Symbol('minify.validateInput'),
  CACHE_KEY: Symbol('minify.cacheKey'),
  IS_CACHED: Symbol('minify.isCached'),
  UPDATE_STATS: Symbol('minify.updateStats'),
  LOG: Symbol('minify.log'),
  DEBUG: Symbol('minify.debug'),
  SWC_INSTANCE: Symbol('minify.swcInstance'),
  SWC_READY: Symbol('minify.swcReady'),
};

// ============================================================
// 3. ПУБЛИЧНЫЕ СИМВОЛЫ
// ============================================================

const PUBLIC_SYMBOLS = {
  MINIFY: Symbol.for('minify.js'),
  MINIFY_JS: Symbol.for('minify.js.code'),
  MINIFY_BOOKMARKLET: Symbol.for('minify.bookmarklet'),
  MINIFY_WITH_CACHE: Symbol.for('minify.withCache'),
  GET_STATE: Symbol.for('minify.getState'),
  GET_STATS: Symbol.for('minify.getStats'),
  CONFIG: Symbol.for('minify.config'),
  RESET: Symbol.for('minify.reset'),
  DESTROY: Symbol.for('minify.destroy'),
  INSTANCE: Symbol.for('minify.instance'),
};

// ============================================================
// 4. КОНФИГУРАЦИЯ
// ============================================================

const CONFIG = {
  version: '4.0.1',
  build: '2026-07-26',
  name: 'Minify Utils',
  debug: true,

  cache: {
    maxSize: 50,
    ttl: 3600000,
    enabled: true,
  },

  limits: {
    maxInputSize: 10 * 1024 * 1024,
    maxOutputSize: 10 * 1024 * 1024,
  },
};

// ============================================================
// 5. СОСТОЯНИЕ
// ============================================================

const STATE = {
  initialized: false,
  destroyed: false,
  ready: false,
  swcReady: false,
  totalProcessed: 0,
  errors: 0,
};

// ============================================================
// 6. КЭШ И СТАТИСТИКА
// ============================================================

const CACHE = new Map();

const STATS = {
  processedCount: 0,
  cachedCount: 0,
  totalTime: 0,
  averageTime: 0,
  savedBytes: 0,
  compressionRatio: 0,
  fallbackCalls: 0,
};

// ============================================================
// 7. ЛОГГЕР
// ============================================================

function log(message, level = 'info') {
  if (!CONFIG.debug && level === 'debug') return;

  const prefix = '[Minify]';
  const icons = {
    error: '❌',
    warn: '⚠️',
    info: 'ℹ️',
    debug: '🔍',
    success: '✅',
  };

  const icon = icons[level] || '📌';
  const fullMessage = `${icon} ${prefix} ${message}`;

  if (level === 'error') {
    console.error(fullMessage);
  } else if (level === 'warn') {
    console.warn(fullMessage);
  } else if (level === 'debug') {
    console.debug(fullMessage);
  } else {
    console.log(fullMessage);
  }
}

// ============================================================
// 8. ВАЛИДАЦИЯ
// ============================================================

function validateInput(code) {
  if (typeof code !== 'string') {
    throw new Error('Код должен быть строкой');
  }

  if (code.length === 0) {
    return { valid: false, error: 'Код пуст' };
  }

  if (code.length > CONFIG.limits.maxInputSize) {
    throw new Error(
      `Код слишком большой: ${code.length} символов (макс: ${CONFIG.limits.maxInputSize})`
    );
  }

  return { valid: true };
}

// ============================================================
// 9. ИНИЦИАЛИЗАЦИЯ SWC (для JS минификации)
// ============================================================

let _swcReady = false;
let _swcInitPromise = null;

async function initSWC() {
  if (_swcReady) {
    return true;
  }

  if (_swcInitPromise) {
    return await _swcInitPromise;
  }

  _swcInitPromise = (async () => {
    try {
      log('⏳ Инициализация @swc/wasm-web...', 'info');
      await initSwc();
      _swcReady = true;
      STATE.swcReady = true;
      log('✅ @swc/wasm-web готов к работе', 'success');
      return true;
    } catch (error) {
      _swcReady = false;
      STATE.swcReady = false;
      log(`❌ Ошибка инициализации SWC: ${error.message}`, 'error');
      throw error;
    }
  })();

  return await _swcInitPromise;
}

// ============================================================
// 10. ПРОСТАЯ МИНИФИКАЦИЯ ДЛЯ БУКМАРКЛЕТОВ (ВОЗВРАЩАЕТ СТРОКУ)
// ============================================================

function minifyBookmarkletCode(code, options = {}) {
  const startTime = Date.now();

  try {
    const validation = validateInput(code);
    if (!validation.valid) {
      throw new Error(validation.error);
    }

    const originalLength = code.length;

    // Проверяем префикс
    let codeToMinify = code;
    let hasPrefix = false;
    if (codeToMinify.startsWith('javascript:')) {
      codeToMinify = codeToMinify.substring(11);
      hasPrefix = true;
    }

    // ★★★ ПРОСТАЯ МИНИФИКАЦИЯ ★★★
    let result = codeToMinify;

    // 1. Удаляем однострочные комментарии
    result = result.replace(/\/\/.*$/gm, '');

    // 2. Удаляем многострочные комментарии
    result = result.replace(/\/\*[\s\S]*?\*\//g, '');

    // 3. Удаляем лишние пробелы и переносы строк
    result = result.replace(/\s+/g, ' ');

    // 4. Удаляем пробелы вокруг операторов
    result = result.replace(/\s*([\(\)\{\}\[\],;=+*\/<>&|!?])\s*/g, '$1');

    // 5. Удаляем лишние точки с запятой
    result = result.replace(/;;+/g, ';');
    result = result.replace(/;}/g, '}');
    result = result.replace(/;\]/g, ']');

    // 6. Удаляем лишние запятые
    result = result.replace(/,\s*}/g, '}');
    result = result.replace(/,\s*\]/g, ']');

    // 7. Удаляем пустые блоки
    result = result.replace(/\{\s*\}/g, '{}');
    result = result.replace(/\[\s*\]/g, '[]');

    // 8. Обрезаем пробелы
    result = result.trim();

    // 9. Если результат пустой - возвращаем заглушку
    if (!result || result.length === 0) {
      result = 'void(0)';
    }

    // 10. Добавляем префикс если был
    if (hasPrefix && !result.startsWith('javascript:')) {
      result = 'javascript:' + result;
    }

    updateStats(startTime, originalLength, result);

    const compression = Math.round((result.length / originalLength) * 100);

    log(`✅ Минификация: ${originalLength} → ${result.length} символов (${compression}%)`, 'debug');

    // ★★★ ВОЗВРАЩАЕМ СТРОКУ, А НЕ ОБЪЕКТ ★★★
    return result;
  } catch (error) {
    STATE.errors++;
    log(`❌ Ошибка минификации: ${error.message || error}`, 'error');

    // Возвращаем оригинальный код с префиксом
    let result = code;
    if (!result.startsWith('javascript:')) {
      result = 'javascript:' + result;
    }

    return result;
  }
}

// ============================================================
// 11. МИНИФИКАЦИЯ JS С ИСПОЛЬЗОВАНИЕМ SWC (ВОЗВРАЩАЕТ СТРОКУ)
// ============================================================

async function minifyJS(code, options = {}) {
  const startTime = Date.now();

  try {
    const validation = validateInput(code);
    if (!validation.valid) {
      throw new Error(validation.error);
    }

    const originalLength = code.length;

    // Пробуем инициализировать SWC
    let swcInitialized = false;
    try {
      swcInitialized = await initSWC();
    } catch (error) {
      log(`⚠️ SWC не инициализирован: ${error.message}`, 'warn');
      return minifyBookmarkletCode(code, options);
    }

    if (!swcInitialized) {
      log('⚠️ SWC не инициализирован', 'warn');
      return minifyBookmarkletCode(code, options);
    }

    const minifyConfig = {
      compress: {
        unused: true,
        dead_code: true,
        conditionals: true,
        sequences: true,
        keep_fnames: true,
        keep_classnames: true,
        drop_console: false,
        drop_debugger: false,
      },
      mangle: {
        keep_fnames: true,
        keep_classnames: true,
      },
      format: {
        beautify: false,
        comments: false,
        ascii_only: false,
      },
    };

    let minified = null;

    // Пробуем transformSync
    if (typeof transformSync === 'function') {
      try {
        const result = transformSync(code, {
          jsc: {
            parser: {
              syntax: 'ecmascript',
              jsx: false,
            },
            minify: minifyConfig,
          },
        });
        if (result && result.code) {
          minified = result.code;
        }
      } catch (error) {
        log(`⚠️ transformSync ошибка: ${error.message || error}`, 'warn');
      }
    }

    // Пробуем minifySync
    if (!minified && typeof minifySync === 'function') {
      try {
        const result = minifySync(code, minifyConfig);
        if (result && result.code) {
          minified = result.code;
        }
      } catch (error) {
        log(`⚠️ minifySync ошибка: ${error.message || error}`, 'warn');
      }
    }

    // Если SWC не сработал - используем простую минификацию
    if (!minified) {
      log('⚠️ SWC не сработал, используем простую минификацию', 'warn');
      return minifyBookmarkletCode(code, options);
    }

    updateStats(startTime, originalLength, minified);

    const compression = Math.round((minified.length / originalLength) * 100);

    log(
      `✅ SWC минификация: ${originalLength} → ${minified.length} символов (${compression}%)`,
      'debug'
    );

    // ★★★ ВОЗВРАЩАЕМ СТРОКУ ★★★
    return minified;
  } catch (error) {
    STATE.errors++;
    log(`❌ Ошибка SWC минификации: ${error.message || error}`, 'error');
    return minifyBookmarkletCode(code, options);
  }
}

// ============================================================
// 12. МИНИФИКАЦИЯ С КЭШЕМ (ВОЗВРАЩАЕТ СТРОКУ)
// ============================================================

function minifyWithCache(code, options = {}) {
  if (!CONFIG.cache.enabled) {
    return minifyBookmarkletCode(code, options);
  }

  const cacheKey = `${code.length}:${JSON.stringify(options)}`;

  if (CACHE.has(cacheKey)) {
    const cached = CACHE.get(cacheKey);
    if (Date.now() - cached.timestamp < CONFIG.cache.ttl) {
      STATS.cachedCount++;
      return cached.result;
    }
    CACHE.delete(cacheKey);
  }

  const result = minifyBookmarkletCode(code, options);

  if (CACHE.size < CONFIG.cache.maxSize) {
    CACHE.set(cacheKey, {
      result,
      timestamp: Date.now(),
    });
  }

  return result;
}

// ============================================================
// 13. ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ
// ============================================================

function updateStats(startTime, originalLength, minified) {
  const endTime = Date.now();
  const processingTime = endTime - startTime;
  const savedBytes = originalLength - minified.length;
  const compressionRatio = originalLength > 0 ? (minified.length / originalLength) * 100 : 100;

  STATS.processedCount++;
  STATS.totalTime += processingTime;
  STATS.averageTime = STATS.totalTime / STATS.processedCount;
  STATS.savedBytes += savedBytes;
  STATS.compressionRatio = compressionRatio;

  STATE.totalProcessed++;
}

// ============================================================
// 14. ПОЛУЧЕНИЕ СОСТОЯНИЯ
// ============================================================

function getMinifyState() {
  return {
    version: CONFIG.version,
    build: CONFIG.build,
    name: CONFIG.name,
    initialized: STATE.initialized,
    destroyed: STATE.destroyed,
    ready: STATE.ready,
    swcReady: STATE.swcReady,
    totalProcessed: STATE.totalProcessed,
    totalSaved: STATS.savedBytes,
    errors: STATE.errors,
    cacheSize: CACHE.size,
    cacheMaxSize: CONFIG.cache.maxSize,
    processedCount: STATS.processedCount,
    cachedCount: STATS.cachedCount,
    averageTime: Math.round(STATS.averageTime),
    compressionRatio: Math.round(STATS.compressionRatio * 100) / 100,
    fallbackCalls: STATS.fallbackCalls,
  };
}

// ============================================================
// 15. СТАТИСТИКА
// ============================================================

function getMinifyStats() {
  return {
    ...STATS,
    averageTime: Math.round(STATS.averageTime),
    compressionRatio: Math.round(STATS.compressionRatio * 100) / 100,
    cacheHitRate:
      STATS.processedCount > 0 ? Math.round((STATS.cachedCount / STATS.processedCount) * 100) : 0,
    savedMB: Math.round((STATS.savedBytes / (1024 * 1024)) * 100) / 100,
    fallbackCalls: STATS.fallbackCalls,
  };
}

// ============================================================
// 16. СБРОС И УНИЧТОЖЕНИЕ
// ============================================================

function resetMinify() {
  CACHE.clear();
  STATE.totalProcessed = 0;
  STATE.errors = 0;
  STATS.processedCount = 0;
  STATS.cachedCount = 0;
  STATS.totalTime = 0;
  STATS.averageTime = 0;
  STATS.savedBytes = 0;
  STATS.compressionRatio = 0;
  STATS.fallbackCalls = 0;
  log('Состояние сброшено', 'success');
}

function destroyMinify() {
  if (STATE.destroyed) return;
  CACHE.clear();
  _swcReady = false;
  STATE.swcReady = false;
  _swcInitPromise = null;
  STATE.destroyed = true;
  STATE.initialized = false;
  STATE.ready = false;
  log('Модуль уничтожен', 'success');
}

// ============================================================
// 17. ИНИЦИАЛИЗАЦИЯ
// ============================================================

function initMinify() {
  if (STATE.initialized) {
    log('Модуль уже инициализирован', 'warn');
    return;
  }

  log('Инициализация Minify Utils...', 'info');

  STATE.initialized = true;
  STATE.ready = true;
  STATE.destroyed = false;

  // Пробуем инициализировать SWC для JS минификации
  initSWC()
    .then(() => {
      log('✅ @swc/wasm-web готов к работе', 'success');
    })
    .catch((error) => {
      log(`⚠️ SWC не инициализирован: ${error.message}`, 'warn');
      log('ℹ️ JS минификация будет использовать простой метод', 'info');
    });

  log(`✅ Minify Utils v${CONFIG.version} готов`, 'success');
}

// ============================================================
// 18. ЭКСПОРТЫ
// ============================================================

export {
  minifyBookmarkletCode,
  minifyJS,
  minifyWithCache,
  getMinifyState,
  getMinifyStats,
  resetMinify,
  destroyMinify,
  initMinify,
  CONFIG,
  PRIVATE_SYMBOLS,
  PUBLIC_SYMBOLS,
};

export default {
  minifyJS,
  minifyBookmarkletCode,
  minifyWithCache,
  getMinifyState,
  getMinifyStats,
  resetMinify,
  destroyMinify,
  initMinify,
  CONFIG,
  PRIVATE_SYMBOLS,
  PUBLIC_SYMBOLS,
};

// ============================================================
// 19. ГЛОБАЛЬНАЯ РЕГИСТРАЦИЯ
// ============================================================

if (typeof window !== 'undefined') {
  window.__MINIFY_SYMBOLS = {
    PRIVATE: { ...PRIVATE_SYMBOLS },
    PUBLIC: { ...PUBLIC_SYMBOLS },
  };

  window.__minify = {
    js: minifyJS,
    bookmarklet: minifyBookmarkletCode,
    withCache: minifyWithCache,
    getState: getMinifyState,
    getStats: getMinifyStats,
    reset: resetMinify,
    destroy: destroyMinify,
    init: initMinify,
    config: CONFIG,
  };

  initMinify();

  console.log('✅ Minify Utils: Глобальная регистрация выполнена');
  console.log('📋 ДОСТУПНЫЕ КОМАНДЫ:');
  console.log('  window.__minify.bookmarklet(code) - простая минификация букмарклета');
  console.log('  window.__minify.js(code) - SWC минификация JS кода');
  console.log('  window.__minify.getState() - состояние');
  console.log('  window.__minify.getStats() - статистика');
  console.log('  window.__minify.reset() - сброс');
  console.log('  window.__minify.destroy() - уничтожение');
  console.log('  window.__minify.init() - инициализация');
}

// ============================================================
// 20. СТАТИСТИКА СИМВОЛОВ
// ============================================================

if (typeof console !== 'undefined') {
  const privateCount = Object.keys(PRIVATE_SYMBOLS).length;
  const publicCount = Object.keys(PUBLIC_SYMBOLS).length;

  console.log(`📊 Minify Utils: ${privateCount} приватных, ${publicCount} публичных символов`);
  console.log(`📦 Всего символов: ${privateCount + publicCount}`);
  console.log(`📋 Версия: ${CONFIG.version} (${CONFIG.build})`);
  console.log('⚡ Режим: Простая минификация для букмарклетов, SWC для JS');
}

// ============================================================
// 21. ОТЛАДКА
// ============================================================

if (typeof window !== 'undefined' && CONFIG.debug) {
  window.__debugMinify = {
    getState: getMinifyState,
    getStats: getMinifyStats,
    getCache: () => {
      const cache = [];
      for (const [key, value] of CACHE) {
        cache.push({
          key,
          size: value.result?.length || 0,
          timestamp: new Date(value.timestamp).toISOString(),
        });
      }
      return cache;
    },
    clearCache: resetMinify,
    getSwcStatus: () => ({
      loaded: STATE.swcReady,
      initPromise: !!_swcInitPromise,
    }),
    testMinify: (code) => {
      const result = minifyBookmarkletCode(code);
      return {
        originalLength: code.length,
        resultLength: result.length,
        compression: Math.round((result.length / code.length) * 100) + '%',
        code: result.substring(0, 200) + '...',
      };
    },
  };

  console.log('📋 КОМАНДЫ ОТЛАДКИ (__debugMinify):');
  console.log('  __debugMinify.getState() - состояние');
  console.log('  __debugMinify.getStats() - статистика');
  console.log('  __debugMinify.getCache() - содержимое кэша');
  console.log('  __debugMinify.clearCache() - очистить кэш');
  console.log('  __debugMinify.getSwcStatus() - статус SWC');
  console.log('  __debugMinify.testMinify(code) - тест минификации');
}
