// src/consumers/vue-consumer.js
// 100% СИМВОЛЫ — полная изоляция и безопасность
// Версия: 2.5.3 — Исправлена работа с импортированным Vue

import * as Vue from 'vue';

// ============================================================
// 1. ПРИВАТНЫЕ СИМВОЛЫ (100% изоляция)
// ============================================================

const PRIVATE = {
  // Основные символы
  VERSION: Symbol('vue.consumer.version'),
  BUILD: Symbol('vue.consumer.build'),
  NAME: Symbol('vue.consumer.name'),
  CONFIG: Symbol('vue.consumer.config'),
  STATE: Symbol('vue.consumer.state'),

  // Компонент
  COMPONENT: Symbol('vue.consumer.component'),
  APP: Symbol('vue.consumer.app'),
  INSTANCE: Symbol('vue.consumer.instance'),
  CONTAINER: Symbol('vue.consumer.container'),

  // Данные
  METRICS: Symbol('vue.consumer.metrics'),
  STATUS: Symbol('vue.consumer.status'),
  COUNT: Symbol('vue.consumer.count'),
  LAST_UPDATE: Symbol('vue.consumer.lastUpdate'),
  ERROR: Symbol('vue.consumer.error'),
  IS_LOADING: Symbol('vue.consumer.isLoading'),
  MESSAGES: Symbol('vue.consumer.messages'),
  ACTIVE_TAB: Symbol('vue.consumer.activeTab'),

  // Подписка
  UNSUBSCRIBE: Symbol('vue.consumer.unsubscribe'),
  IS_MOUNTED: Symbol('vue.consumer.isMounted'),
  UPDATE_COUNTER: Symbol('vue.consumer.updateCounter'),

  // Методы
  INIT: Symbol('vue.consumer.init'),
  MOUNT: Symbol('vue.consumer.mount'),
  UNMOUNT: Symbol('vue.consumer.unmount'),
  DESTROY: Symbol('vue.consumer.destroy'),
  UPDATE_DATA: Symbol('vue.consumer.updateData'),
  FORCE_UPDATE: Symbol('vue.consumer.forceUpdate'),
  INJECT_STYLES: Symbol('vue.consumer.injectStyles'),
  EXPORT_SYMBOLS: Symbol('vue.consumer.exportSymbols'),
  GET_STATE: Symbol('vue.consumer.getState'),
  SET_STATE: Symbol('vue.consumer.setState'),
  HANDLE_ERROR: Symbol('vue.consumer.handleError'),
  HANDLE_SUCCESS: Symbol('vue.consumer.handleSuccess'),

  // Сообщения
  SEND_MESSAGE: Symbol('vue.consumer.sendMessage'),
  BROADCAST_MESSAGE: Symbol('vue.consumer.broadcastMessage'),

  // Табы
  SWITCH_TAB: Symbol('vue.consumer.switchTab'),
  RENDER_METRICS: Symbol('vue.consumer.renderMetrics'),
  RENDER_MESSAGES: Symbol('vue.consumer.renderMessages'),
  RENDER_HEADER: Symbol('vue.consumer.renderHeader'),
  RENDER_FOOTER: Symbol('vue.consumer.renderFooter'),
  RENDER_TABS: Symbol('vue.consumer.renderTabs'),
  RENDER_CONTENT: Symbol('vue.consumer.renderContent'),

  // Форматирование
  FORMAT_TIME: Symbol('vue.consumer.formatTime'),
  GET_VALUE_CLASS: Symbol('vue.consumer.getValueClass'),
  GET_STATUS_ICON: Symbol('vue.consumer.getStatusIcon'),
  GET_STATUS_LABEL: Symbol('vue.consumer.getStatusLabel'),
  FORMAT_COUNT: Symbol('vue.consumer.formatCount'),
};

// ============================================================
// 2. ПУБЛИЧНЫЕ СИМВОЛЫ (доступны через Symbol.for)
// ============================================================

const PUBLIC = {
  INSTANCE: Symbol.for('vue.consumer.instance'),
  STATE: Symbol.for('vue.consumer.state'),
  CONFIG: Symbol.for('vue.consumer.config'),
  MOUNT: Symbol.for('vue.consumer.mount'),
  UNMOUNT: Symbol.for('vue.consumer.unmount'),
  DESTROY: Symbol.for('vue.consumer.destroy'),
  GET_STATE: Symbol.for('vue.consumer.getState'),
  FORCE_UPDATE: Symbol.for('vue.consumer.forceUpdate'),
  SEND_MESSAGE: Symbol.for('vue.consumer.sendMessage'),
  BROADCAST_MESSAGE: Symbol.for('vue.consumer.broadcastMessage'),
  GET_MESSAGES: Symbol.for('vue.consumer.getMessages'),
  CLEAR_MESSAGES: Symbol.for('vue.consumer.clearMessages'),
  SWITCH_TAB: Symbol.for('vue.consumer.switchTab'),
  HEALTH_CHECK: Symbol.for('vue.consumer.healthCheck'),
};

// ============================================================
// 3. КОНФИГУРАЦИЯ
// ============================================================

const CONFIG = {
  version: '2.5.3',
  build: '2026-07-22',
  name: 'Vue Consumer',
  debug: true,
  theme: 'dark',
  showStats: true,
  maxItems: 500,
  maxMessages: 100,
  tabs: ['metrics', 'messages'],
  defaultTab: 'metrics',
};

// ============================================================
// 4. CSS СТИЛИ (100% ИЗОЛЯЦИЯ)
// ============================================================

const VUE_CONSUMER_STYLES = `
    /* ============================================================
       ВСЕ СТИЛИ ИЗОЛИРОВАНЫ В .vue-consumer-wrapper
       ============================================================ */
    
    .vue-consumer-wrapper {
        display: flex;
        flex-direction: column;
        height: 100%;
        width: 100%;
        font-family: system-ui, -apple-system, sans-serif;
        background: #0b0e14;
        border-radius: 8px;
        border: 1px solid #1e2633;
        overflow: hidden;
        box-sizing: border-box;
    }
    
    .vue-consumer-wrapper * {
        box-sizing: border-box;
    }
    
    /* ===== КОНТЕЙНЕР ===== */
    .vue-consumer-wrapper .consumer-container {
        display: flex;
        flex-direction: column;
        height: 100%;
        width: 100%;
        padding: 0;
        margin: 0;
        background: transparent;
        overflow: hidden;
    }
    
    /* ===== ЗАГОЛОВОК ===== */
    .vue-consumer-wrapper .consumer-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 8px 12px;
        background: #131a24;
        border-bottom: 1px solid #1e2633;
        flex-shrink: 0;
        min-height: 36px;
        gap: 8px;
        flex-wrap: wrap;
    }
    
    .vue-consumer-wrapper .consumer-title {
        font-size: 13px;
        font-weight: 600;
        color: #c8d0e0;
        display: flex;
        align-items: center;
        gap: 6px;
        flex-wrap: wrap;
    }
    
    .vue-consumer-wrapper .consumer-title .icon {
        font-size: 16px;
    }
    
    .vue-consumer-wrapper .consumer-title .badge {
        font-size: 9px;
        background: #1e293b;
        padding: 1px 8px;
        border-radius: 10px;
        color: #8b96b0;
        border: 1px solid #2a3444;
        font-weight: 400;
        white-space: nowrap;
    }
    
    .vue-consumer-wrapper .consumer-title .badge.version {
        color: #4ec9b0;
        border-color: rgba(78, 201, 176, 0.2);
    }
    
    .vue-consumer-wrapper .consumer-title .badge.id {
        color: #4a5a7a;
        border-color: #1e2633;
    }
    
    /* ===== СТАТУС ===== */
    .vue-consumer-wrapper .consumer-status {
        font-size: 11px;
        padding: 2px 10px;
        border-radius: 12px;
        background: #1e293b;
        font-weight: 500;
        display: flex;
        align-items: center;
        gap: 4px;
        border: 1px solid transparent;
        transition: all 0.3s ease;
        white-space: nowrap;
        flex-shrink: 0;
    }
    
    .vue-consumer-wrapper .consumer-status .dot {
        display: inline-block;
        width: 6px;
        height: 6px;
        border-radius: 50%;
        transition: background 0.3s ease;
    }
    
    .vue-consumer-wrapper .consumer-status .count {
        font-weight: 400;
        color: #8b96b0;
        font-size: 10px;
        margin-left: 2px;
    }
    
    .vue-consumer-wrapper .consumer-status.playing {
        color: #34d399;
        border-color: rgba(52, 211, 153, 0.2);
    }
    .vue-consumer-wrapper .consumer-status.playing .dot {
        background: #34d399;
        animation: pulse-dot 1.5s infinite;
    }
    
    .vue-consumer-wrapper .consumer-status.paused {
        color: #fbbf24;
        border-color: rgba(251, 191, 36, 0.2);
    }
    .vue-consumer-wrapper .consumer-status.paused .dot {
        background: #fbbf24;
    }
    
    .vue-consumer-wrapper .consumer-status.disconnected {
        color: #ef4444;
        border-color: rgba(239, 68, 68, 0.2);
    }
    .vue-consumer-wrapper .consumer-status.disconnected .dot {
        background: #ef4444;
    }
    
    .vue-consumer-wrapper .consumer-status.connecting {
        color: #60a5fa;
        border-color: rgba(96, 165, 250, 0.2);
    }
    .vue-consumer-wrapper .consumer-status.connecting .dot {
        background: #60a5fa;
        animation: pulse-dot 0.8s infinite;
    }
    
    @keyframes pulse-dot {
        0%, 100% { opacity: 1; transform: scale(1); }
        50% { opacity: 0.5; transform: scale(0.8); }
    }
    
    @keyframes slide-in {
        from { opacity: 0; transform: translateX(-10px); }
        to { opacity: 1; transform: translateX(0); }
    }
    
    /* ===== СКРОЛЛБОКС ===== */
    .vue-consumer-wrapper .consumer-scroll-box {
        flex: 1;
        min-height: 0;
        min-width: 0;
        overflow-y: auto;
        overflow-x: hidden;
        background: #0b0e14;
        padding: 4px;
    }
    
    .vue-consumer-wrapper .consumer-scroll-box::-webkit-scrollbar {
        width: 4px;
        height: 4px;
    }
    .vue-consumer-wrapper .consumer-scroll-box::-webkit-scrollbar-track {
        background: #0b0e14;
    }
    .vue-consumer-wrapper .consumer-scroll-box::-webkit-scrollbar-thumb {
        background: #2a3444;
        border-radius: 10px;
    }
    .vue-consumer-wrapper .consumer-scroll-box::-webkit-scrollbar-thumb:hover {
        background: #3a4454;
    }
    
    /* ===== ПУСТОЕ СОСТОЯНИЕ ===== */
    .vue-consumer-wrapper .empty-state {
        text-align: center;
        padding: 40px 20px;
        color: #4a5a7a;
        font-size: 13px;
        line-height: 1.8;
        animation: slide-in 0.3s ease;
    }
    
    .vue-consumer-wrapper .empty-state .emoji {
        font-size: 28px;
        display: block;
        margin-bottom: 8px;
    }
    
    .vue-consumer-wrapper .empty-state .hint {
        font-size: 11px;
        color: #3a4a6a;
        display: block;
        margin-top: 4px;
    }
    
    /* ===== СТРОКА МЕТРИКИ ===== */
    .vue-consumer-wrapper .consumer-metric-row {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 5px 10px;
        border-bottom: 1px solid #161e2a;
        font-size: 12px;
        font-variant-numeric: tabular-nums;
        transition: background 0.15s;
        animation: slide-in 0.2s ease;
        cursor: default;
        min-height: 28px;
    }
    
    .vue-consumer-wrapper .consumer-metric-row:hover {
        background: #131a24;
        border-left: 3px solid #3b82f6;
        padding-left: 7px;
    }
    
    .vue-consumer-wrapper .consumer-metric-row:last-child {
        border-bottom: none;
    }
    
    .vue-consumer-wrapper .consumer-metric-row .time {
        color: #6b7b96;
        font-size: 11px;
        display: flex;
        align-items: center;
        gap: 4px;
        flex-shrink: 0;
    }
    
    .vue-consumer-wrapper .consumer-metric-row .time .id {
        color: #4a5a7a;
        font-size: 9px;
        background: #161e2a;
        padding: 0 4px;
        border-radius: 8px;
    }
    
    .vue-consumer-wrapper .consumer-metric-row .value {
        font-weight: 600;
        font-size: 13px;
        transition: color 0.3s ease;
        flex-shrink: 0;
    }
    
    .vue-consumer-wrapper .consumer-metric-row .value.high {
        color: #f472b6;
    }
    .vue-consumer-wrapper .consumer-metric-row .value.medium {
        color: #fbbf24;
    }
    .vue-consumer-wrapper .consumer-metric-row .value.low {
        color: #34d399;
    }
    .vue-consumer-wrapper .consumer-metric-row .value.critical {
        color: #ef4444;
        animation: pulse-value 1s infinite;
    }
    
    .vue-consumer-wrapper .consumer-metric-row .value .unit {
        font-weight: 400;
        font-size: 10px;
        color: #6b7b96;
        margin-left: 2px;
    }
    
    @keyframes pulse-value {
        0%, 100% { opacity: 1; }
        50% { opacity: 0.6; }
    }
    
    /* ===== СООБЩЕНИЯ ===== */
    .vue-consumer-wrapper .consumer-message-row {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 5px 10px;
        border-bottom: 1px solid #161e2a;
        font-size: 12px;
        transition: background 0.15s;
        animation: slide-in 0.2s ease;
        min-height: 28px;
    }
    
    .vue-consumer-wrapper .consumer-message-row:hover {
        background: #131a24;
    }
    
    .vue-consumer-wrapper .consumer-message-row:last-child {
        border-bottom: none;
    }
    
    .vue-consumer-wrapper .consumer-message-row .time {
        color: #6b7b96;
        font-size: 11px;
        flex-shrink: 0;
    }
    
    .vue-consumer-wrapper .consumer-message-row .source {
        color: #4a5a7a;
        font-size: 10px;
        background: #161e2a;
        padding: 0 4px;
        border-radius: 8px;
    }
    
    .vue-consumer-wrapper .consumer-message-row .text {
        font-size: 12px;
        word-break: break-word;
        flex: 1;
        margin: 0 8px;
    }
    
    .vue-consumer-wrapper .consumer-message-row .type-badge {
        font-size: 9px;
        padding: 1px 6px;
        border-radius: 8px;
        flex-shrink: 0;
    }
    
    .vue-consumer-wrapper .consumer-message-row .type-badge.user {
        background: rgba(78, 201, 176, 0.15);
        color: #4ec9b0;
    }
    .vue-consumer-wrapper .consumer-message-row .type-badge.broadcast {
        background: rgba(96, 165, 250, 0.15);
        color: #60a5fa;
    }
    .vue-consumer-wrapper .consumer-message-row .type-badge.system {
        background: rgba(251, 191, 36, 0.15);
        color: #fbbf24;
    }
    
    /* ===== ФУТЕР ===== */
    .vue-consumer-wrapper .consumer-footer {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 6px 12px;
        border-top: 1px solid #161e2a;
        font-size: 10px;
        color: #4a5a7a;
        flex-shrink: 0;
        background: #0b0e14;
        flex-wrap: wrap;
        gap: 4px;
        min-height: 28px;
    }
    
    .vue-consumer-wrapper .consumer-footer .info-item {
        display: flex;
        align-items: center;
        gap: 4px;
    }
    
    .vue-consumer-wrapper .consumer-footer .info-item .label {
        color: #3a4a6a;
    }
    .vue-consumer-wrapper .consumer-footer .info-item .value {
        color: #8b96b0;
        font-weight: 500;
    }
    
    .vue-consumer-wrapper .consumer-footer .timestamp {
        color: #3a4a6a;
        font-size: 9px;
    }
    
    /* ===== ОШИБКИ ===== */
    .vue-consumer-wrapper .consumer-error {
        padding: 20px;
        text-align: center;
        color: #ef4444;
        background: #450a0a;
        border-radius: 8px;
        border: 1px solid #7f1d1d;
        margin: 10px;
    }
    
    .vue-consumer-wrapper .consumer-error .error-icon {
        font-size: 28px;
        margin-bottom: 8px;
        display: block;
    }
    
    .vue-consumer-wrapper .consumer-error .error-details {
        font-size: 11px;
        color: #fca5a5;
        margin-top: 4px;
        word-break: break-word;
    }
    
    .vue-consumer-wrapper .consumer-error .error-button {
        margin-top: 12px;
        padding: 4px 16px;
        background: #3b82f6;
        color: white;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        font-size: 12px;
        transition: background 0.2s;
    }
    
    .vue-consumer-wrapper .consumer-error .error-button:hover {
        background: #2563eb;
    }
    
    /* ===== ТАБЫ ===== */
    .vue-consumer-wrapper .pane-tabs {
        display: flex;
        background: #131a24;
        border-bottom: 1px solid #1e2633;
        padding: 0 8px;
        flex-shrink: 0;
        gap: 0;
        min-height: 28px;
    }
    
    .vue-consumer-wrapper .pane-tab {
        padding: 4px 10px;
        color: #808080;
        cursor: pointer;
        border-bottom: 2px solid transparent;
        font-size: 11px;
        background: none;
        border-top: none;
        border-left: none;
        border-right: none;
        font-family: inherit;
        transition: all 0.2s;
        white-space: nowrap;
    }
    
    .vue-consumer-wrapper .pane-tab:hover {
        color: #cccccc;
    }
    
    .vue-consumer-wrapper .pane-tab.active {
        color: #e6e6e6;
        border-bottom-color: #007acc;
    }
    
    .vue-consumer-wrapper .pane-tab .badge-count {
        font-size: 9px;
        background: #1e293b;
        padding: 0 6px;
        border-radius: 8px;
        margin-left: 4px;
        color: #4a5a7a;
    }
    
    .vue-consumer-wrapper .pane-tab.active .badge-count {
        color: #8b96b0;
    }
    
    /* ===== КОНТЕНТ ===== */
    .vue-consumer-wrapper .pane-content {
        flex: 1;
        overflow: hidden;
        position: relative;
        min-height: 0;
    }
    
    .vue-consumer-wrapper .pane-content > div {
        display: none;
        width: 100%;
        height: 100%;
        overflow: hidden;
        flex-direction: column;
    }
    
    .vue-consumer-wrapper .pane-content > div.active {
        display: flex;
        flex-direction: column;
    }
    
    /* ===== АДАПТИВНОСТЬ ===== */
    @media (max-width: 480px) {
        .vue-consumer-wrapper .consumer-header {
            padding: 6px 10px;
            flex-direction: column;
            align-items: stretch;
            gap: 4px;
        }
        
        .vue-consumer-wrapper .consumer-title {
            font-size: 12px;
            justify-content: center;
        }
        
        .vue-consumer-wrapper .consumer-status {
            font-size: 10px;
            padding: 2px 8px;
            justify-content: center;
        }
        
        .vue-consumer-wrapper .consumer-metric-row {
            padding: 4px 8px;
            font-size: 11px;
            flex-wrap: wrap;
            gap: 4px;
        }
        
        .vue-consumer-wrapper .consumer-metric-row .value {
            font-size: 12px;
        }
        
        .vue-consumer-wrapper .consumer-footer {
            flex-direction: column;
            align-items: stretch;
            text-align: center;
            gap: 2px;
            padding: 4px 10px;
        }
        
        .vue-consumer-wrapper .pane-tabs {
            justify-content: center;
        }
        
        .vue-consumer-wrapper .pane-tab {
            padding: 3px 8px;
            font-size: 10px;
        }
    }
    
    /* ===== REDUCED MOTION ===== */
    @media (prefers-reduced-motion: reduce) {
        .vue-consumer-wrapper * {
            animation-duration: 0.01ms !important;
            animation-iteration-count: 1 !important;
            transition-duration: 0.01ms !important;
        }
    }
    
    /* ===== HIGH CONTRAST ===== */
    @media (prefers-contrast: high) {
        .vue-consumer-wrapper .consumer-status {
            border-width: 2px;
        }
        .vue-consumer-wrapper .consumer-metric-row {
            border-bottom-width: 2px;
        }
        .vue-consumer-wrapper .consumer-error {
            border-width: 2px;
        }
    }
`;

// ============================================================
// 5. ФУНКЦИЯ ИНЪЕКЦИИ СТИЛЕЙ
// ============================================================

function injectVueStyles() {
  if (typeof document === 'undefined') return;
  if (document.getElementById('vue-consumer-styles')) return;

  const style = document.createElement('style');
  style.id = 'vue-consumer-styles';
  style.textContent = VUE_CONSUMER_STYLES;
  document.head.appendChild(style);
}

// ============================================================
// 6. VUE КОМПОНЕНТ (РЕНДЕР-ФУНКЦИЯ)
// ============================================================

function createVueConsumerComponent() {
  const { ref, shallowRef, computed, onMounted, onBeforeUnmount, triggerRef, h } = Vue;

  return {
    name: 'VueConsumer',
    props: {
      store: { type: Object, required: true },
      consumerId: { type: String, required: true },
      options: { type: Object, default: () => ({}) },
    },
    setup(props) {
      // ============================================================
      // 6.1. РЕАКТИВНОЕ СОСТОЯНИЕ
      // ============================================================

      const metrics = shallowRef([]);
      const status = ref('disconnected');
      const count = ref(0);
      const lastUpdate = ref(null);
      const error = ref(null);
      const isLoading = ref(true);
      const messages = shallowRef([]);
      const activeTab = ref(CONFIG.defaultTab);

      let unsubscribe = null;
      let isMounted = false;
      let updateCounter = 0;

      // ============================================================
      // 6.2. ФУНКЦИЯ ОБНОВЛЕНИЯ
      // ============================================================

      function updateData(trigger = 'manual') {
        try {
          if (!props.store) {
            error.value = 'Store не найден';
            isLoading.value = false;
            return false;
          }

          const state = props.store.getState();
          const newMetrics = state.liveMetrics || [];
          const newCount = newMetrics.length;

          metrics.value = newMetrics;
          triggerRef(metrics);

          status.value = state.streamStatus || 'disconnected';
          count.value = newCount;
          lastUpdate.value = state.lastUpdate || null;
          error.value = null;
          isLoading.value = false;

          // Обновляем сообщения
          if (state.messages) {
            messages.value = state.messages.slice(-CONFIG.maxMessages);
            triggerRef(messages);
          }

          return true;
        } catch (err) {
          error.value = err.message;
          isLoading.value = false;
          return false;
        }
      }

      // ============================================================
      // 6.3. ФУНКЦИЯ ПРИНУДИТЕЛЬНОГО ОБНОВЛЕНИЯ
      // ============================================================

      function forceUpdate() {
        triggerRef(metrics);
        if (props.store && typeof props.store.getMessages === 'function') {
          messages.value = props.store.getMessages(CONFIG.maxMessages);
          triggerRef(messages);
        }
        return metrics.value.length;
      }

      // ============================================================
      // 6.4. ФУНКЦИИ ОТПРАВКИ СООБЩЕНИЙ
      // ============================================================

      function sendMessage(text, type = 'user') {
        try {
          if (!props.store || typeof props.store.sendMessage !== 'function') {
            console.warn('⚠️ Vue Consumer: store.sendMessage не доступен');
            return false;
          }

          const result = props.store.sendMessage({
            id: Date.now() + Math.random(),
            ts: Date.now(),
            type: type,
            text: text,
            source: 'vue-consumer',
            consumerId: props.consumerId
          });

          if (result) {
            console.log(`✅ Vue Consumer: Сообщение отправлено: "${text}"`);
            if (props.store.getMessages) {
              messages.value = props.store.getMessages(CONFIG.maxMessages);
              triggerRef(messages);
            }
          }
          return result;
        } catch (error) {
          console.error('❌ Vue Consumer: Ошибка отправки сообщения:', error);
          return false;
        }
      }

      function broadcastMessage(text, type = 'broadcast') {
        try {
          if (!props.store || typeof props.store.broadcastMessage !== 'function') {
            console.warn('⚠️ Vue Consumer: store.broadcastMessage не доступен');
            return false;
          }

          const result = props.store.broadcastMessage({
            id: Date.now() + Math.random(),
            ts: Date.now(),
            type: type,
            text: text,
            source: 'vue-consumer',
            consumerId: props.consumerId
          });

          if (result) {
            console.log(`📡 Vue Consumer: Широковещательное сообщение: "${text}"`);
            if (props.store.getMessages) {
              messages.value = props.store.getMessages(CONFIG.maxMessages);
              triggerRef(messages);
            }
          }
          return result;
        } catch (error) {
          console.error('❌ Vue Consumer: Ошибка широковещательной отправки:', error);
          return false;
        }
      }

      function getMessages(limit = 20) {
        if (props.store && typeof props.store.getMessages === 'function') {
          return props.store.getMessages(limit);
        }
        return [];
      }

      function clearMessages() {
        if (props.store && typeof props.store.clearMessages === 'function') {
          const result = props.store.clearMessages();
          if (result) {
            messages.value = [];
            triggerRef(messages);
          }
          return result;
        }
        return false;
      }

      // ============================================================
      // 6.5. LIFECYCLE
      // ============================================================

      onMounted(() => {
        try {
          isMounted = true;

          if (props.store && typeof props.store.subscribe === 'function') {
            unsubscribe = props.store.subscribe((state) => {
              updateCounter++;
              if (!isMounted) return;

              const newMetrics = state.liveMetrics || [];
              metrics.value = newMetrics;
              triggerRef(metrics);

              status.value = state.streamStatus || 'disconnected';
              count.value = newMetrics.length;
              lastUpdate.value = state.lastUpdate || null;
              error.value = null;
              isLoading.value = false;

              if (state.messages) {
                messages.value = state.messages.slice(-CONFIG.maxMessages);
                triggerRef(messages);
              }
            });
          }

          updateData('onMounted');

          console.log(`✅ Vue Consumer ${props.consumerId}: Монтирован`);
        } catch (err) {
          error.value = err.message;
          isLoading.value = false;
          console.error('❌ Vue Consumer: Ошибка монтирования:', err);
        }
      });

      onBeforeUnmount(() => {
        isMounted = false;
        if (unsubscribe && typeof unsubscribe === 'function') {
          unsubscribe();
          console.log(`🧹 Vue Consumer ${props.consumerId}: Отписан`);
        }
      });

      // ============================================================
      // 6.6. ВЫЧИСЛЯЕМЫЕ СВОЙСТВА
      // ============================================================

      const reversedMetrics = computed(() => metrics.value.slice().reverse());
      const reversedMessages = computed(() => messages.value.slice().reverse());
      const statusClass = computed(() => `consumer-status ${status.value}`);
      const formattedCount = computed(() => {
        const c = count.value;
        if (c === 0) return '0 записей';
        if (c === 1) return '1 запись';
        if (c < 5) return `${c} записи`;
        return `${c} записей`;
      });
      const hasData = computed(() => count.value > 0);
      const showError = computed(() => error.value !== null);
      const hasMessages = computed(() => messages.value.length > 0);
      const messagesCount = computed(() => messages.value.length);

      // ============================================================
      // 6.7. ВСПОМОГАТЕЛЬНЫЕ МЕТОДЫ
      // ============================================================

      function formatTime(ts) {
        try {
          return new Date(ts).toLocaleTimeString('ru-RU', {
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit',
            fractionalSecondDigits: 3
          });
        } catch {
          return '--:--:--';
        }
      }

      function getValueClass(val) {
        if (val > 150) return 'value critical';
        if (val > 100) return 'value high';
        if (val > 70) return 'value medium';
        return 'value low';
      }

      function getStatusIcon() {
        const icons = { playing: '▶', paused: '⏸', disconnected: '⏹', connecting: '⟳' };
        return icons[status.value] || '●';
      }

      function getStatusLabel() {
        const labels = {
          playing: 'Играет',
          paused: 'Пауза',
          disconnected: 'Отключён',
          connecting: 'Подключение...'
        };
        return labels[status.value] || status.value;
      }

      function switchTab(tab) {
        if (CONFIG.tabs.includes(tab)) {
          activeTab.value = tab;
        }
      }

      function healthCheck() {
        return {
          consumerId: props.consumerId,
          isMounted: isMounted,
          hasData: hasData.value,
          metricsCount: count.value,
          messagesCount: messages.value.length,
          status: status.value,
          error: error.value,
          lastUpdate: lastUpdate.value,
          storeVersion: props.store ? props.store.__version : null,
        };
      }

      // ============================================================
      // 6.8. ЭКСПОРТ
      // ============================================================

      return {
        // Данные
        metrics,
        status,
        count,
        lastUpdate,
        error,
        isLoading,
        messages,
        activeTab,
        consumerId: props.consumerId,

        // Вычисляемые
        reversedMetrics,
        reversedMessages,
        statusClass,
        formattedCount,
        hasData,
        showError,
        hasMessages,
        messagesCount,

        // Методы
        formatTime,
        getValueClass,
        getStatusIcon,
        getStatusLabel,
        updateData,
        forceUpdate,
        sendMessage,
        broadcastMessage,
        getMessages,
        clearMessages,
        switchTab,
        healthCheck,
      };
    },

    // ============================================================
    // 6.9. РЕНДЕР-ФУНКЦИЯ
    // ============================================================

    render() {
      const { h } = Vue;

      const {
        consumerId,
        statusClass,
        formattedCount,
        hasData,
        showError,
        isLoading,
        error,
        messages,
        hasMessages,
        messagesCount,
        activeTab,
        reversedMetrics,
        reversedMessages,
        formatTime,
        getValueClass,
        getStatusIcon,
        getStatusLabel,
        lastUpdate,
        updateData,
        forceUpdate,
        switchTab,
      } = this;

      // ============================================================
      // 6.9.1. РЕНДЕРИНГ СПИСКА МЕТРИК
      // ============================================================

      const renderMetrics = () => {
        if (isLoading) {
          return h('div', { class: 'empty-state' }, [
            h('span', { class: 'emoji' }, '⏳'),
            ' Загрузка...',
            h('span', { class: 'hint' }, 'Подключение к хранилищу...')
          ]);
        }

        if (showError) {
          return h('div', { class: 'consumer-error' }, [
            h('span', { class: 'error-icon' }, '❌'),
            h('div', 'Ошибка загрузки данных'),
            h('div', { class: 'error-details' }, error),
            h('button', {
              class: 'error-button',
              onClick: () => updateData('manual')
            }, '🔄 Обновить'),
            h('button', {
              class: 'error-button',
              style: 'margin-left:8px;background:#fbbf24;color:#1e1e1e;',
              onClick: forceUpdate
            }, '💥 Force')
          ]);
        }

        if (!hasData) {
          return h('div', { class: 'empty-state' }, [
            h('span', { class: 'emoji' }, '⏳'),
            ' Ожидание данных...',
            h('span', { class: 'hint' }, 'Запустите источник данных нажав "Старт"')
          ]);
        }

        return reversedMetrics.map(metric => {
          return h('div', {
            class: 'consumer-metric-row',
            key: metric.id
          }, [
            h('span', { class: 'time' }, [
              `[${formatTime(metric.ts)}]`,
              h('span', { class: 'id' }, `#${metric.id}`)
            ]),
            h('span', { class: getValueClass(metric.val) }, [
              `${metric.val.toFixed(1)}`,
              h('span', { class: 'unit' }, ' kW/h')
            ])
          ]);
        });
      };

      // ============================================================
      // 6.9.2. РЕНДЕРИНГ СООБЩЕНИЙ
      // ============================================================

      const renderMessages = () => {
        if (!hasMessages) {
          return h('div', { class: 'empty-state', style: 'padding:20px;' }, [
            h('span', { class: 'emoji' }, '💬'),
            ' Нет сообщений',
            h('span', { class: 'hint' }, 'Отправьте сообщение используя sendMessage() или broadcastMessage()')
          ]);
        }

        return reversedMessages.map(msg => {
          const typeClass = msg.type === 'broadcast' ? 'broadcast' : (msg.type === 'system' ? 'system' : 'user');
          const icon = msg.type === 'broadcast' ? '📡' : '💬';

          return h('div', {
            class: 'consumer-message-row',
            key: msg.id,
            style: `border-left:3px solid ${msg.type === 'broadcast' ? '#60a5fa' : '#4ec9b0'};`
          }, [
            h('span', { class: 'time' }, formatTime(msg.ts)),
            h('span', { class: 'source' }, msg.source || 'unknown'),
            h('span', { class: 'text' }, `${icon} ${msg.text}`),
            h('span', { class: `type-badge ${typeClass}` }, msg.type || 'user')
          ]);
        });
      };

      // ============================================================
      // 6.9.3. ОСНОВНОЙ VNODE
      // ============================================================

      return h('div', { class: 'vue-consumer-wrapper' }, [
        h('div', { class: 'consumer-container' }, [
          // Заголовок
          h('div', { class: 'consumer-header' }, [
            h('div', { class: 'consumer-title' }, [
              h('span', { class: 'icon' }, '🟢'),
              ' Vue Consumer',
              h('span', { class: 'badge version' }, `v${CONFIG.version}`),
              h('span', {
                class: 'badge id'
              }, `${consumerId.substring(0, 8)}...`)
            ]),
            h('div', { class: statusClass.value }, [
              h('span', { class: 'dot' }),
              ` ${getStatusIcon()} ${getStatusLabel()}`,
              h('span', { class: 'count' }, `(${formattedCount})`)
            ])
          ]),

          // Табы
          h('div', { class: 'pane-tabs' }, [
            h('button', {
              class: ['pane-tab', activeTab === 'metrics' ? 'active' : ''],
              onClick: () => switchTab('metrics')
            }, '📊 Данные'),
            h('button', {
              class: ['pane-tab', activeTab === 'messages' ? 'active' : ''],
              onClick: () => switchTab('messages')
            }, [
              '💬 Сообщения',
              h('span', { class: 'badge-count' }, messagesCount)
            ])
          ]),

          // Контент
          h('div', { class: 'pane-content' }, [
            // Вкладка метрик
            h('div', {
              class: activeTab === 'metrics' ? 'active' : '',
              style: activeTab === 'metrics' ? 'display:flex;flex-direction:column;' : 'display:none;'
            }, [
              h('div', { class: 'consumer-scroll-box' }, renderMetrics())
            ]),
            // Вкладка сообщений
            h('div', {
              class: activeTab === 'messages' ? 'active' : '',
              style: activeTab === 'messages' ? 'display:flex;flex-direction:column;' : 'display:none;'
            }, [
              h('div', { class: 'consumer-scroll-box' }, renderMessages())
            ])
          ]),

          // Футер
          h('div', { class: 'consumer-footer' }, [
            h('span', { class: 'info-item' }, [
              h('span', { class: 'label' }, '🆔'),
              h('span', { class: 'value' }, `${consumerId.substring(0, 12)}...`)
            ]),
            h('span', { class: 'info-item' }, [
              h('span', { class: 'label' }, '📊'),
              h('span', { class: 'value' }, formattedCount)
            ]),
            h('span', { class: 'info-item' }, [
              h('span', { class: 'label' }, '💬'),
              h('span', { class: 'value' }, messagesCount)
            ]),
            h('span', { class: 'timestamp' },
              lastUpdate ? `Обновлено: ${new Date(lastUpdate).toLocaleTimeString()}` : '⏳ ожидание...'
            )
          ])
        ])
      ]);
    }
  };
}

// ============================================================
// 7. ФУНКЦИЯ МОНТИРОВАНИЯ
// ============================================================

function mountVueConsumer(targetElement, options = {}) {
  console.log('🔌 mountVueConsumer()');
  console.log('✅ Vue версия:', Vue.version || 'unknown');

  // Проверяем Vue
  if (!Vue || typeof Vue.createApp !== 'function') {
    console.error('❌ Vue.createApp не доступен');
    console.log('Доступные методы Vue:', Object.keys(Vue || {}));

    if (typeof targetElement === 'string' || targetElement instanceof HTMLElement) {
      const container = typeof targetElement === 'string'
        ? document.querySelector(targetElement)
        : targetElement;

      if (container) {
        container.innerHTML = `
          <div class="vue-consumer-wrapper">
            <div class="consumer-container">
              <div class="consumer-error">
                <span class="error-icon">❌</span>
                <div>Vue не инициализирован</div>
                <div class="error-details">
                  Vue.createApp не доступен. Проверьте импорт Vue.
                </div>
              </div>
            </div>
          </div>
        `;
      }
    }

    return null;
  }

  // Получаем хранилище
  let store = options.store;
  if (!store && typeof window !== 'undefined') {
    const STORE_SYMBOL = Symbol.for('__HIGH_FREQ_STREAM_STORE__');
    store = window[STORE_SYMBOL];
  }

  if (!store) {
    console.error('❌ Хранилище не найдено');
    return null;
  }

  // Генерируем ID
  const consumerId = options.consumerId ||
    `consumer_${Date.now().toString(36)}_${Math.random().toString(36).substring(2, 8)}`;

  // Получаем контейнер
  let container;
  if (typeof targetElement === 'string') {
    container = document.querySelector(targetElement);
    if (!container) {
      console.error(`❌ Элемент не найден: ${targetElement}`);
      return null;
    }
  } else if (targetElement instanceof HTMLElement) {
    container = targetElement;
  } else {
    console.error('❌ Некорректный целевой элемент');
    return null;
  }

  // Очищаем контейнер
  container.innerHTML = '';

  // Инжектируем стили
  injectVueStyles();

  let app = null;
  let instance = null;

  try {
    // Создаем компонент
    const component = createVueConsumerComponent();

    // Создаем приложение
    app = Vue.createApp(component, {
      store: store,
      consumerId: consumerId,
      options: options,
    });

    // Монтируем
    instance = app.mount(container);

    console.log(`✅ Vue Consumer ${consumerId}: Успешно смонтирован`);

    // Добавляем методы к экземпляру
    if (instance) {
      instance.sendMessage = instance.sendMessage || function(text, type) {
        return this.sendMessage(text, type);
      };
      instance.broadcastMessage = instance.broadcastMessage || function(text, type) {
        return this.broadcastMessage(text, type);
      };
      instance.forceUpdate = instance.forceUpdate || function() {
        return this.forceUpdate();
      };
      instance.healthCheck = instance.healthCheck || function() {
        return this.healthCheck();
      };
    }

    if (options.onMount && typeof options.onMount === 'function') {
      options.onMount(instance);
    }

    // Сохраняем в глобальный объект
    if (typeof window !== 'undefined') {
      if (!window.__vueConsumers) {
        window.__vueConsumers = new Map();
      }
      window.__vueConsumers.set(consumerId, {
        instance,
        app,
        container,
        unmount: () => {
          if (app) {
            app.unmount();
            app = null;
          }
          if (container) {
            container.innerHTML = '';
          }
          if (window.__vueConsumers) {
            window.__vueConsumers.delete(consumerId);
          }
          console.log(`🧹 Vue Consumer ${consumerId}: Размонтирован`);
        }
      });
    }

    return instance;

  } catch (error) {
    console.error(`❌ Ошибка монтирования Vue Consumer:`, error);
    container.innerHTML = `
      <div class="vue-consumer-wrapper">
        <div class="consumer-container">
          <div class="consumer-error">
            <span class="error-icon">❌</span>
            <div>Ошибка монтирования Vue Consumer</div>
            <div class="error-details">${(error.message || 'Неизвестная ошибка').replace(/</g, '&lt;')}</div>
          </div>
        </div>
      </div>
    `;
    return null;
  }
}

// ============================================================
// 8. ГЛОБАЛЬНАЯ РЕГИСТРАЦИЯ
// ============================================================

if (typeof window !== 'undefined' && typeof document !== 'undefined') {
  window.__mountVueConsumer = mountVueConsumer;
  window[PUBLIC.INSTANCE] = mountVueConsumer;

  window.__vueConsumerSymbols = {
    PRIVATE: { ...PRIVATE },
    PUBLIC: { ...PUBLIC },
  };

  console.log('✅ Vue Consumer: Глобальная регистрация выполнена');
  console.log('📌 Команды отладки:');
  console.log('  window.__mountVueConsumer(element, options) - монтирование');
  console.log('  window.__vueConsumers - список активных консюмеров');
  console.log('  window.__vueConsumerSymbols - символы');
}

// ============================================================
// 9. ЭКСПОРТЫ (ПРАВИЛЬНЫЕ)
// ============================================================

// Именованный экспорт (для импорта из index.html)
export {
  mountVueConsumer,
  injectVueStyles,
  createVueConsumerComponent,
  VUE_CONSUMER_STYLES,
  PRIVATE as VUE_CONSUMER_PRIVATE,
  PUBLIC as VUE_CONSUMER_PUBLIC,
  CONFIG as VUE_CONSUMER_CONFIG,
};

// Экспорт по умолчанию (для обратной совместимости)
export default mountVueConsumer;