// src/consumers/react-consumer.js
// 100% СИМВОЛЫ — полная изоляция и безопасность
// Версия: 2.2.0 — Добавлена пересылка сообщений через глобальный стор

import React from 'react';
import ReactDOM from 'react-dom/client';
import { STORE_SYMBOL } from '../core/store.js';
import { verifyStoreAccess, checkEnvironment, generateConsumerId } from '../core/security.js';
import {
  CONSUMER_STYLES,
  injectStyles,
  getStatusClasses,
  getValueClass,
  formatCount,
  getStatusIcon,
} from './shared/styles.js';

// ============================================================
// 1. ПРИВАТНЫЕ СИМВОЛЫ (100% изоляция)
// ============================================================

const PRIVATE_SYMBOLS = {
  // Основные символы
  INSTANCE: Symbol('react.consumer.instance'),
  STATE: Symbol('react.consumer.state'),
  CONFIG: Symbol('react.consumer.config'),
  STORE: Symbol('react.consumer.store'),
  CONSUMER_ID: Symbol('react.consumer.id'),

  // Методы
  INIT: Symbol('react.consumer.init'),
  MOUNT: Symbol('react.consumer.mount'),
  UNMOUNT: Symbol('react.consumer.unmount'),
  DESTROY: Symbol('react.consumer.destroy'),
  UPDATE: Symbol('react.consumer.update'),
  FORCE_UPDATE: Symbol('react.consumer.forceUpdate'),
  GET_STATE: Symbol('react.consumer.getState'),
  SET_STATE: Symbol('react.consumer.setState'),

  // Сообщения
  SEND_MESSAGE: Symbol('react.consumer.sendMessage'),
  BROADCAST_MESSAGE: Symbol('react.consumer.broadcastMessage'),
  GET_MESSAGES: Symbol('react.consumer.getMessages'),
  CLEAR_MESSAGES: Symbol('react.consumer.clearMessages'),
  ON_MESSAGE: Symbol('react.consumer.onMessage'),
  OFF_MESSAGE: Symbol('react.consumer.offMessage'),
  MESSAGE_HANDLERS: Symbol('react.consumer.messageHandlers'),

  // Безопасность
  VALIDATE: Symbol('react.consumer.validate'),
  SANITIZE: Symbol('react.consumer.sanitize'),
  ESCAPE: Symbol('react.consumer.escape'),
  CHECK_STORE: Symbol('react.consumer.checkStore'),

  // Обработчики
  HANDLERS: Symbol('react.consumer.handlers'),
  CLEANUP: Symbol('react.consumer.cleanup'),
  SUBSCRIPTION: Symbol('react.consumer.subscription'),

  // Статистика
  STATS: Symbol('react.consumer.stats'),
  METRICS: Symbol('react.consumer.metrics'),
  MESSAGES: Symbol('react.consumer.messages'),

  // Рендеринг
  RENDER: Symbol('react.consumer.render'),
  RENDER_METRICS: Symbol('react.consumer.renderMetrics'),
  RENDER_MESSAGES: Symbol('react.consumer.renderMessages'),
  RENDER_HEADER: Symbol('react.consumer.renderHeader'),
  RENDER_FOOTER: Symbol('react.consumer.renderFooter'),

  // Экспорт
  EXPORT_SYMBOLS: Symbol('react.consumer.exportSymbols'),
};

// ============================================================
// 2. ПУБЛИЧНЫЕ СИМВОЛЫ (доступны через Symbol.for)
// ============================================================

const PUBLIC_SYMBOLS = {
  INSTANCE: Symbol.for('react.consumer.instance'),
  STATE: Symbol.for('react.consumer.state'),
  CONFIG: Symbol.for('react.consumer.config'),
  MOUNT: Symbol.for('react.consumer.mount'),
  UNMOUNT: Symbol.for('react.consumer.unmount'),
  DESTROY: Symbol.for('react.consumer.destroy'),
  GET_STATE: Symbol.for('react.consumer.getState'),
  SEND_MESSAGE: Symbol.for('react.consumer.sendMessage'),
  BROADCAST_MESSAGE: Symbol.for('react.consumer.broadcastMessage'),
  GET_MESSAGES: Symbol.for('react.consumer.getMessages'),
  CLEAR_MESSAGES: Symbol.for('react.consumer.clearMessages'),
};

// ============================================================
// 3. КОНФИГУРАЦИЯ
// ============================================================

const CONFIG = {
  version: '2.2.0',
  build: '2026-07-22',
  name: 'React Consumer',
  debug: true,
  maxMessages: 100,
  maxMetrics: 500,
};

// ============================================================
// 4. CSS СТИЛИ ДЛЯ REACT КОНСЮМЕРА
// ============================================================

const REACT_CONSUMER_STYLES = `
    /* ★★★ ГЛАВНОЕ ИСПРАВЛЕНИЕ: растяжение на всю ширину ★★★ */
    .react-consumer-wrapper {
        display: flex;
        flex-direction: column;
        height: 100%;
        width: 100%;
        min-height: 0;
        min-width: 0;
        font-family: system-ui, -apple-system, sans-serif;
        background: #0b0e14;
        border-radius: 8px;
        border: 1px solid #1e2633;
        overflow: hidden;
    }
    
    .react-consumer-wrapper .consumer-container {
        display: flex;
        flex-direction: column;
        height: 100%;
        width: 100%;
        min-height: 0;
        min-width: 0;
        padding: 0;
        margin: 0;
        background: transparent;
    }
    
    .react-consumer-wrapper .consumer-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 8px 12px;
        background: #131a24;
        border-bottom: 1px solid #1e2633;
        flex-shrink: 0;
        flex-wrap: wrap;
        gap: 4px;
    }
    
    .react-consumer-wrapper .consumer-title {
        font-size: 13px;
        font-weight: 600;
        color: #c8d0e0;
        display: flex;
        align-items: center;
        gap: 6px;
    }
    
    .react-consumer-wrapper .consumer-title .icon { font-size: 16px; }
    .react-consumer-wrapper .consumer-title .badge {
        font-size: 9px;
        background: #1e293b;
        padding: 1px 8px;
        border-radius: 10px;
        color: #8b96b0;
        border: 1px solid #2a3444;
    }
    
    .react-consumer-wrapper .consumer-status {
        font-size: 11px;
        padding: 2px 10px;
        border-radius: 12px;
        background: #1e293b;
        font-weight: 500;
        display: flex;
        align-items: center;
        gap: 4px;
        border: 1px solid transparent;
        transition: all 0.3s ease;
        flex-shrink: 0;
    }
    
    .react-consumer-wrapper .consumer-status .dot {
        display: inline-block;
        width: 6px;
        height: 6px;
        border-radius: 50%;
        transition: background 0.3s ease;
    }
    
    .react-consumer-wrapper .consumer-status .count {
        font-weight: 400;
        color: #8b96b0;
        font-size: 10px;
        margin-left: 2px;
    }
    
    .react-consumer-wrapper .consumer-status.playing {
        color: #34d399;
        border-color: rgba(52, 211, 153, 0.2);
    }
    .react-consumer-wrapper .consumer-status.playing .dot {
        background: #34d399;
        animation: pulse-dot 1.5s infinite;
    }
    
    .react-consumer-wrapper .consumer-status.disconnected {
        color: #ef4444;
        border-color: rgba(239, 68, 68, 0.2);
    }
    .react-consumer-wrapper .consumer-status.disconnected .dot {
        background: #ef4444;
    }
    
    .react-consumer-wrapper .consumer-status.connecting {
        color: #60a5fa;
        border-color: rgba(96, 165, 250, 0.2);
    }
    .react-consumer-wrapper .consumer-status.connecting .dot {
        background: #60a5fa;
        animation: pulse-dot 0.8s infinite;
    }
    
    @keyframes pulse-dot {
        0%, 100% { opacity: 1; transform: scale(1); }
        50% { opacity: 0.5; transform: scale(0.8); }
    }
    
    @keyframes slide-in {
        from { opacity: 0; transform: translateX(-10px); }
        to { opacity: 1; transform: translateX(0); }
    }
    
    /* ★★★ СКРОЛЛБОКС РАСТЯГИВАЕТСЯ ★★★ */
    .react-consumer-wrapper .consumer-scroll-box {
        flex: 1;
        min-height: 0;
        min-width: 0;
        overflow-y: auto;
        overflow-x: hidden;
        background: #0b0e14;
        padding: 4px;
        width: 100%;
    }
    
    .react-consumer-wrapper .consumer-scroll-box::-webkit-scrollbar {
        width: 4px;
    }
    .react-consumer-wrapper .consumer-scroll-box::-webkit-scrollbar-track {
        background: #0b0e14;
    }
    .react-consumer-wrapper .consumer-scroll-box::-webkit-scrollbar-thumb {
        background: #2a3444;
        border-radius: 10px;
    }
    
    .react-consumer-wrapper .empty-state {
        text-align: center;
        padding: 40px 20px;
        color: #4a5a7a;
        font-size: 13px;
        line-height: 1.8;
    }
    .react-consumer-wrapper .empty-state .emoji {
        font-size: 28px;
        display: block;
        margin-bottom: 8px;
    }
    .react-consumer-wrapper .empty-state .hint {
        font-size: 11px;
        color: #3a4a6a;
        display: block;
        margin-top: 4px;
    }
    
    .react-consumer-wrapper .consumer-metric-row {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 5px 10px;
        border-bottom: 1px solid #161e2a;
        font-size: 12px;
        font-variant-numeric: tabular-nums;
        transition: background 0.15s;
        animation: slide-in 0.2s ease;
        width: 100%;
        box-sizing: border-box;
    }
    
    .react-consumer-wrapper .consumer-metric-row:hover {
        background: #131a24;
        border-left: 3px solid #3b82f6;
        padding-left: 7px;
    }
    
    .react-consumer-wrapper .consumer-metric-row:last-child {
        border-bottom: none;
    }
    
    .react-consumer-wrapper .consumer-metric-row .time {
        color: #6b7b96;
        font-size: 11px;
        display: flex;
        align-items: center;
        gap: 4px;
        flex-shrink: 0;
    }
    
    .react-consumer-wrapper .consumer-metric-row .time .id {
        color: #4a5a7a;
        font-size: 9px;
        background: #161e2a;
        padding: 0 4px;
        border-radius: 8px;
    }
    
    .react-consumer-wrapper .consumer-metric-row .value {
        font-weight: 600;
        font-size: 13px;
        transition: color 0.3s ease;
        flex-shrink: 0;
    }
    
    .react-consumer-wrapper .consumer-metric-row .value.high { color: #f472b6; }
    .react-consumer-wrapper .consumer-metric-row .value.medium { color: #fbbf24; }
    .react-consumer-wrapper .consumer-metric-row .value.low { color: #34d399; }
    
    .react-consumer-wrapper .consumer-metric-row .value .unit {
        font-weight: 400;
        font-size: 10px;
        color: #6b7b96;
        margin-left: 2px;
    }
    
    /* ★★★ СТИЛИ ДЛЯ СООБЩЕНИЙ ★★★ */
    .react-consumer-wrapper .consumer-message-row {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 4px 10px;
        border-bottom: 1px solid #161e2a;
        font-size: 12px;
        transition: background 0.15s;
        animation: slide-in 0.2s ease;
        width: 100%;
        box-sizing: border-box;
    }
    
    .react-consumer-wrapper .consumer-message-row:hover {
        background: #131a24;
        border-left: 3px solid #8b5cf6;
        padding-left: 7px;
    }
    
    .react-consumer-wrapper .consumer-message-row .msg-time {
        color: #6b7b96;
        font-size: 10px;
        flex-shrink: 0;
        margin-right: 8px;
    }
    
    .react-consumer-wrapper .consumer-message-row .msg-type {
        font-size: 9px;
        padding: 1px 6px;
        border-radius: 8px;
        flex-shrink: 0;
        margin-right: 8px;
        font-weight: 500;
    }
    
    .react-consumer-wrapper .consumer-message-row .msg-type.user {
        background: rgba(59, 130, 246, 0.2);
        color: #60a5fa;
    }
    
    .react-consumer-wrapper .consumer-message-row .msg-type.broadcast {
        background: rgba(139, 92, 246, 0.2);
        color: #a78bfa;
    }
    
    .react-consumer-wrapper .consumer-message-row .msg-type.system {
        background: rgba(251, 191, 36, 0.2);
        color: #fbbf24;
    }
    
    .react-consumer-wrapper .consumer-message-row .msg-text {
        flex: 1;
        color: #c8d0e0;
        word-break: break-word;
    }
    
    .react-consumer-wrapper .consumer-message-row .msg-source {
        font-size: 9px;
        color: #4a5a7a;
        flex-shrink: 0;
        margin-left: 8px;
    }
    
    /* ★★★ СТИЛИ ДЛЯ ОТПРАВКИ СООБЩЕНИЙ ★★★ */
    .react-consumer-wrapper .consumer-message-input {
        display: flex;
        gap: 6px;
        padding: 6px 10px;
        background: #131a24;
        border-top: 1px solid #1e2633;
        flex-shrink: 0;
    }
    
    .react-consumer-wrapper .consumer-message-input input {
        flex: 1;
        background: #0b0e14;
        border: 1px solid #1e2633;
        border-radius: 4px;
        color: #c8d0e0;
        padding: 4px 10px;
        font-size: 12px;
        font-family: inherit;
        outline: none;
        transition: border-color 0.2s;
        min-width: 0;
    }
    
    .react-consumer-wrapper .consumer-message-input input:focus {
        border-color: #3b82f6;
    }
    
    .react-consumer-wrapper .consumer-message-input input::placeholder {
        color: #4a5a7a;
    }
    
    .react-consumer-wrapper .consumer-message-input .msg-send-btn {
        background: #3b82f6;
        border: none;
        border-radius: 4px;
        color: white;
        padding: 4px 12px;
        font-size: 12px;
        cursor: pointer;
        transition: all 0.2s;
        white-space: nowrap;
        font-family: inherit;
    }
    
    .react-consumer-wrapper .consumer-message-input .msg-send-btn:hover {
        background: #2563eb;
    }
    
    .react-consumer-wrapper .consumer-message-input .msg-broadcast-btn {
        background: #8b5cf6;
        border: none;
        border-radius: 4px;
        color: white;
        padding: 4px 12px;
        font-size: 12px;
        cursor: pointer;
        transition: all 0.2s;
        white-space: nowrap;
        font-family: inherit;
    }
    
    .react-consumer-wrapper .consumer-message-input .msg-broadcast-btn:hover {
        background: #7c3aed;
    }
    
    /* ★★★ ТАБЫ ★★★ */
    .react-consumer-wrapper .consumer-tabs {
        display: flex;
        background: #131a24;
        border-bottom: 1px solid #1e2633;
        flex-shrink: 0;
        padding: 0 8px;
        gap: 0;
    }
    
    .react-consumer-wrapper .consumer-tab {
        padding: 4px 10px;
        color: #4a5a7a;
        cursor: pointer;
        border-bottom: 2px solid transparent;
        font-size: 11px;
        background: none;
        border-top: none;
        border-left: none;
        border-right: none;
        font-family: inherit;
        transition: all 0.2s;
    }
    
    .react-consumer-wrapper .consumer-tab:hover {
        color: #8b96b0;
    }
    
    .react-consumer-wrapper .consumer-tab.active {
        color: #c8d0e0;
        border-bottom-color: #3b82f6;
    }
    
    .react-consumer-wrapper .consumer-tab .tab-count {
        font-size: 9px;
        background: #1e293b;
        padding: 0 4px;
        border-radius: 8px;
        margin-left: 4px;
    }
    
    .react-consumer-wrapper .consumer-footer {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 6px 12px;
        border-top: 1px solid #161e2a;
        font-size: 10px;
        color: #4a5a7a;
        flex-shrink: 0;
        background: #0b0e14;
        flex-wrap: wrap;
        gap: 4px;
        width: 100%;
        box-sizing: border-box;
    }
    
    .react-consumer-wrapper .consumer-footer .info-item {
        display: flex;
        align-items: center;
        gap: 4px;
    }
    
    .react-consumer-wrapper .consumer-footer .info-item .label { color: #3a4a6a; }
    .react-consumer-wrapper .consumer-footer .info-item .value { color: #8b96b0; font-weight: 500; }
    .react-consumer-wrapper .consumer-footer .timestamp {
        color: #3a4a6a;
        font-size: 9px;
    }
    
    .react-consumer-wrapper .consumer-error {
        padding: 20px;
        text-align: center;
        color: #ef4444;
        background: #450a0a;
        border-radius: 8px;
        border: 1px solid #7f1d1d;
        margin: 10px;
    }
    .react-consumer-wrapper .consumer-error .error-icon {
        font-size: 28px;
        margin-bottom: 8px;
        display: block;
    }
    .react-consumer-wrapper .consumer-error .error-details {
        font-size: 11px;
        color: #fca5a5;
        margin-top: 4px;
    }
`;

// ============================================================
// 5. REACT КОМПОНЕНТ (С ИСПРАВЛЕННЫМИ СТИЛЯМИ И СООБЩЕНИЯМИ)
// ============================================================

function ReactConsumerComponent({ store, consumerId, onMount, onError }) {
  // ============================================================
  // 5.1. СОСТОЯНИЕ
  // ============================================================

  const [metrics, setMetrics] = React.useState(() => {
    try {
      return store.getMetrics ? store.getMetrics() : [];
    } catch (error) {
      console.error('❌ Ошибка получения метрик:', error);
      return [];
    }
  });

  const [status, setStatus] = React.useState(() => {
    try {
      return store.getStatus ? store.getStatus() : 'disconnected';
    } catch (error) {
      console.error('❌ Ошибка получения статуса:', error);
      return 'disconnected';
    }
  });

  const [count, setCount] = React.useState(() => {
    try {
      const m = store.getMetrics ? store.getMetrics() : [];
      return m.length;
    } catch (error) {
      console.error('❌ Ошибка получения количества:', error);
      return 0;
    }
  });

  const [lastUpdate, setLastUpdate] = React.useState(null);

  // Сообщения
  const [messages, setMessages] = React.useState(() => {
    try {
      if (typeof store.getMessages === 'function') {
        return store.getMessages(CONFIG.maxMessages);
      }
      return [];
    } catch (error) {
      console.error('❌ Ошибка получения сообщений:', error);
      return [];
    }
  });

  const [messageCount, setMessageCount] = React.useState(() => messages.length);
  const [activeTab, setActiveTab] = React.useState('metrics');
  const [inputMessage, setInputMessage] = React.useState('');

  // ============================================================
  // 5.2. ФУНКЦИИ ОТПРАВКИ СООБЩЕНИЙ ЧЕРЕЗ ГЛОБАЛЬНЫЙ СТОР
  // ============================================================

  const sendMessage = React.useCallback(
    (text, type = 'user') => {
      try {
        if (!store || typeof store.sendMessage !== 'function') {
          console.warn('⚠️ React Consumer: store.sendMessage не доступен');
          return false;
        }

        if (!text || typeof text !== 'string' || text.trim().length === 0) {
          console.warn('⚠️ React Consumer: Сообщение не может быть пустым');
          return false;
        }

        const result = store.sendMessage({
          id: Date.now() + Math.random(),
          ts: Date.now(),
          type: type,
          text: text.trim(),
          source: 'react-consumer',
          consumerId: consumerId,
        });

        if (result) {
          console.log(`✅ React Consumer: Сообщение отправлено: "${text.trim()}"`);
          setInputMessage('');
          // Обновляем список сообщений
          updateMessages();
        }
        return result;
      } catch (error) {
        console.error('❌ React Consumer: Ошибка отправки сообщения:', error);
        return false;
      }
    },
    [store, consumerId]
  );

  const broadcastMessage = React.useCallback(
    (text, type = 'broadcast') => {
      try {
        if (!store || typeof store.broadcastMessage !== 'function') {
          console.warn('⚠️ React Consumer: store.broadcastMessage не доступен');
          return false;
        }

        if (!text || typeof text !== 'string' || text.trim().length === 0) {
          console.warn('⚠️ React Consumer: Сообщение не может быть пустым');
          return false;
        }

        const result = store.broadcastMessage({
          id: Date.now() + Math.random(),
          ts: Date.now(),
          type: type,
          text: text.trim(),
          source: 'react-consumer',
          consumerId: consumerId,
        });

        if (result) {
          console.log(`📡 React Consumer: Широковещательное сообщение: "${text.trim()}"`);
          setInputMessage('');
          updateMessages();
        }
        return result;
      } catch (error) {
        console.error('❌ React Consumer: Ошибка широковещательной отправки:', error);
        return false;
      }
    },
    [store, consumerId]
  );

  const updateMessages = React.useCallback(() => {
    try {
      if (typeof store.getMessages === 'function') {
        const msgs = store.getMessages(CONFIG.maxMessages);
        setMessages(msgs);
        setMessageCount(msgs.length);
      }
    } catch (error) {
      console.error('❌ Ошибка обновления сообщений:', error);
    }
  }, [store]);

  const clearMessages = React.useCallback(() => {
    try {
      if (typeof store.clearMessages === 'function') {
        store.clearMessages();
        setMessages([]);
        setMessageCount(0);
        console.log('🧹 React Consumer: Сообщения очищены');
        return true;
      }
      return false;
    } catch (error) {
      console.error('❌ Ошибка очистки сообщений:', error);
      return false;
    }
  }, [store]);

  // ============================================================
  // 5.3. ОБРАБОТКА КЛАВИШ
  // ============================================================

  const handleKeyDown = React.useCallback(
    (e) => {
      if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        if (inputMessage.trim()) {
          sendMessage(inputMessage);
        }
      }
    },
    [inputMessage, sendMessage]
  );

  // ============================================================
  // 5.4. ПОДПИСКА НА ИЗМЕНЕНИЯ
  // ============================================================

  React.useEffect(() => {
    let unsubscribe = null;

    try {
      unsubscribe = store.subscribe((state) => {
        try {
          setMetrics(state.liveMetrics || []);
          setStatus(state.streamStatus || 'disconnected');
          setCount(state.liveMetrics ? state.liveMetrics.length : 0);
          setLastUpdate(Date.now());

          // Обновляем сообщения при изменении
          if (state._messages) {
            setMessages(state._messages.slice(-CONFIG.maxMessages));
            setMessageCount(state._messages.length);
          }
        } catch (error) {
          console.error('❌ Ошибка обновления состояния:', error);
        }
      });

      // Начальная загрузка сообщений
      updateMessages();

      if (onMount && typeof onMount === 'function') {
        onMount();
      }

      console.log(`✅ React Consumer ${consumerId} подписан на обновления`);
    } catch (error) {
      console.error('❌ Ошибка подписки React Consumer:', error);
      if (onError && typeof onError === 'function') {
        onError(error);
      }
    }

    return () => {
      if (unsubscribe && typeof unsubscribe === 'function') {
        try {
          unsubscribe();
          console.log(`🧹 React Consumer ${consumerId} отписан`);
        } catch (error) {
          console.warn('⚠️ Ошибка отписки React Consumer:', error);
        }
      }
    };
  }, [store, consumerId, onMount, onError, updateMessages]);

  // ============================================================
  // 5.5. ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ
  // ============================================================

  const formatTime = React.useCallback((ts) => {
    try {
      return new Date(ts).toLocaleTimeString('ru-RU', {
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
      });
    } catch (error) {
      return '--:--:--';
    }
  }, []);

  const formatFullTime = React.useCallback((ts) => {
    try {
      return new Date(ts).toLocaleString('ru-RU', {
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        fractionalSecondDigits: 3,
      });
    } catch (error) {
      return '--:--:--.---';
    }
  }, []);

  const getValueClassLocal = React.useCallback((val) => {
    if (val > 150) return 'value critical';
    if (val > 100) return 'value high';
    if (val > 70) return 'value medium';
    return 'value low';
  }, []);

  const getMessageTypeClass = React.useCallback((type) => {
    const map = {
      user: 'user',
      broadcast: 'broadcast',
      system: 'system',
    };
    return map[type] || 'user';
  }, []);

  const getMessageTypeLabel = React.useCallback((type) => {
    const map = {
      user: '👤',
      broadcast: '📡',
      system: '⚙️',
    };
    return map[type] || '💬';
  }, []);

  // ============================================================
  // 5.6. ОБРАБОТКА ОШИБОК РЕНДЕРИНГА
  // ============================================================

  const [renderError, setRenderError] = React.useState(null);

  React.useEffect(() => {
    if (renderError) {
      console.error('❌ Ошибка рендеринга React Consumer:', renderError);
    }
  }, [renderError]);

  if (renderError) {
    return React.createElement(
      'div',
      {
        className: 'consumer-error',
        style: {
          padding: '20px',
          textAlign: 'center',
          color: '#ef4444',
          background: '#450a0a',
          borderRadius: '8px',
          border: '1px solid #7f1d1d',
        },
      },
      React.createElement('div', { style: { fontSize: '32px', marginBottom: '12px' } }, '❌'),
      React.createElement('div', null, 'Ошибка рендеринга React Consumer'),
      React.createElement(
        'div',
        { style: { fontSize: '12px', color: '#4a5a7a', marginTop: '8px' } },
        renderError.message || 'Неизвестная ошибка'
      ),
      React.createElement(
        'button',
        {
          onClick: () => setRenderError(null),
          style: {
            marginTop: '16px',
            padding: '6px 20px',
            background: '#3b82f6',
            color: 'white',
            border: 'none',
            borderRadius: '6px',
            cursor: 'pointer',
            fontSize: '13px',
          },
        },
        '🔄 Попробовать снова'
      )
    );
  }

  // ============================================================
  // 5.7. РЕНДЕРИНГ
  // ============================================================

  try {
    // Рендеринг метрик
    const renderMetricsList = () => {
      if (metrics.length === 0) {
        return React.createElement(
          'div',
          { className: 'empty-state' },
          React.createElement('span', { className: 'emoji' }, '⏳'),
          'Ожидание данных...',
          React.createElement(
            'span',
            { className: 'hint' },
            'Запустите источник данных нажав "Старт"'
          )
        );
      }

      return metrics
        .slice()
        .reverse()
        .map((metric) => {
          try {
            return React.createElement(
              'div',
              {
                className: 'consumer-metric-row',
                key: metric.id || metric.ts,
              },
              React.createElement(
                'span',
                { className: 'time' },
                `[${formatTime(metric.ts)}]`,
                React.createElement('span', { className: 'id' }, `#${metric.id}`)
              ),
              React.createElement(
                'span',
                { className: getValueClassLocal(metric.val) },
                `${metric.val.toFixed(1)}`,
                React.createElement('span', { className: 'unit' }, ' kW/h')
              )
            );
          } catch (error) {
            console.warn('⚠️ Ошибка рендеринга метрики:', error);
            return null;
          }
        })
        .filter(Boolean);
    };

    // Рендеринг сообщений
    const renderMessagesList = () => {
      if (messages.length === 0) {
        return React.createElement(
          'div',
          { className: 'empty-state' },
          React.createElement('span', { className: 'emoji' }, '💬'),
          'Нет сообщений',
          React.createElement('span', { className: 'hint' }, 'Напишите сообщение в поле ниже')
        );
      }

      return messages
        .slice()
        .reverse()
        .map((msg) => {
          try {
            return React.createElement(
              'div',
              {
                className: 'consumer-message-row',
                key: msg.id || msg.ts,
              },
              React.createElement('span', { className: 'msg-time' }, formatFullTime(msg.ts)),
              React.createElement(
                'span',
                {
                  className: `msg-type ${getMessageTypeClass(msg.type)}`,
                },
                getMessageTypeLabel(msg.type)
              ),
              React.createElement('span', { className: 'msg-text' }, msg.text),
              React.createElement(
                'span',
                { className: 'msg-source' },
                `from: ${msg.source || 'unknown'}`
              )
            );
          } catch (error) {
            console.warn('⚠️ Ошибка рендеринга сообщения:', error);
            return null;
          }
        })
        .filter(Boolean);
    };

    // Рендеринг вкладок
    const renderTabs = () => {
      return React.createElement(
        'div',
        { className: 'consumer-tabs' },
        React.createElement(
          'button',
          {
            className: `consumer-tab ${activeTab === 'metrics' ? 'active' : ''}`,
            onClick: () => setActiveTab('metrics'),
          },
          '📊 Данные',
          React.createElement('span', { className: 'tab-count' }, count)
        ),
        React.createElement(
          'button',
          {
            className: `consumer-tab ${activeTab === 'messages' ? 'active' : ''}`,
            onClick: () => setActiveTab('messages'),
          },
          '💬 Сообщения',
          React.createElement('span', { className: 'tab-count' }, messageCount)
        )
      );
    };

    // Рендеринг содержимого вкладок
    const renderTabContent = () => {
      if (activeTab === 'metrics') {
        return React.createElement(
          'div',
          { className: 'consumer-scroll-box' },
          renderMetricsList()
        );
      }
      return React.createElement('div', { className: 'consumer-scroll-box' }, renderMessagesList());
    };

    // Рендеринг поля ввода сообщений
    const renderMessageInput = () => {
      return React.createElement(
        'div',
        { className: 'consumer-message-input' },
        React.createElement('input', {
          type: 'text',
          value: inputMessage,
          onChange: (e) => setInputMessage(e.target.value),
          onKeyDown: handleKeyDown,
          placeholder: 'Введите сообщение...',
          maxLength: 500,
        }),
        React.createElement(
          'button',
          {
            className: 'msg-send-btn',
            onClick: () => sendMessage(inputMessage),
            disabled: !inputMessage.trim(),
          },
          '📨 Отправить'
        ),
        React.createElement(
          'button',
          {
            className: 'msg-broadcast-btn',
            onClick: () => broadcastMessage(inputMessage),
            disabled: !inputMessage.trim(),
          },
          '📡 Всем'
        )
      );
    };

    return React.createElement(
      'div',
      { className: 'react-consumer-wrapper' },
      React.createElement(
        'div',
        { className: 'consumer-container' },
        // Заголовок
        React.createElement(
          'div',
          { className: 'consumer-header' },
          React.createElement(
            'div',
            { className: 'consumer-title' },
            React.createElement('span', { className: 'icon' }, '⚛️'),
            'React Consumer',
            React.createElement('span', { className: 'badge' }, `v${CONFIG.version}`)
          ),
          React.createElement(
            'div',
            { className: `consumer-status ${status}` },
            React.createElement('span', { className: 'dot' }),
            getStatusIcon(status),
            ' ',
            status.charAt(0).toUpperCase() + status.slice(1),
            React.createElement('span', { className: 'count' }, `(${formatCount(count)})`)
          )
        ),

        // Вкладки
        renderTabs(),

        // Содержимое
        renderTabContent(),

        // Поле ввода сообщений (только на вкладке сообщений)
        activeTab === 'messages' ? renderMessageInput() : null,

        // Футер
        React.createElement(
          'div',
          { className: 'consumer-footer' },
          React.createElement(
            'span',
            { className: 'info-item' },
            React.createElement('span', { className: 'label' }, '🆔'),
            React.createElement('span', { className: 'value' }, consumerId.substring(0, 12) + '...')
          ),
          React.createElement(
            'span',
            { className: 'info-item' },
            React.createElement('span', { className: 'label' }, '📊'),
            React.createElement('span', { className: 'value' }, `${count} записей`)
          ),
          React.createElement(
            'span',
            { className: 'info-item' },
            React.createElement('span', { className: 'label' }, '💬'),
            React.createElement('span', { className: 'value' }, `${messageCount} сообщений`)
          ),
          React.createElement(
            'span',
            { className: 'timestamp' },
            lastUpdate
              ? `Обновлено: ${new Date(lastUpdate).toLocaleTimeString()}`
              : '⏳ ожидание...'
          )
        )
      )
    );
  } catch (error) {
    console.error('❌ Ошибка рендеринга React Consumer:', error);
    setRenderError(error);
    return null;
  }
}

// ============================================================
// 6. ФУНКЦИЯ МОНТИРОВАНИЯ REACT КОНСЮМЕРА
// ============================================================

export function mountReactConsumer(targetElement, options = {}) {
  // Проверка безопасности
  const env = checkEnvironment();
  if (!env.isSafe) {
    console.error('❌ Окружение небезопасно');
    return null;
  }

  // Если передан store в опциях, используем его
  let store = options.store;
  if (!store) {
    // Проверка доступа к хранилищу через Symbol
    const storeCheck = verifyStoreAccess(STORE_SYMBOL);
    if (!storeCheck.valid) {
      console.error(`❌ ${storeCheck.error}`);
      return null;
    }
    store = storeCheck.store;
  }

  const consumerId = generateConsumerId();

  console.log(`🔌 Монтирование React консюмера (ID: ${consumerId})`);

  // Инжектируем общие стили
  try {
    injectStyles('react-consumer-styles');
  } catch (error) {
    console.warn('⚠️ Ошибка инжекции стилей:', error);
  }

  // Добавляем специфичные стили для React
  try {
    const reactStyleElement = document.createElement('style');
    reactStyleElement.id = 'react-consumer-specific-styles';
    reactStyleElement.textContent = REACT_CONSUMER_STYLES;
    if (!document.getElementById('react-consumer-specific-styles')) {
      document.head.appendChild(reactStyleElement);
    }
  } catch (error) {
    console.warn('⚠️ Ошибка добавления специфичных стилей React:', error);
  }

  // Создаем React root
  let root = null;
  let isMounted = false;
  let unmountCalled = false;

  // Если targetElement - строка, находим элемент
  let container;
  if (typeof targetElement === 'string') {
    container = document.querySelector(targetElement);
    if (!container) {
      console.error(`❌ Элемент не найден: ${targetElement}`);
      return null;
    }
  } else if (targetElement instanceof HTMLElement) {
    container = targetElement;
  } else {
    console.error('❌ Некорректный целевой элемент');
    return null;
  }

  // ★★★ ОЧИЩАЕМ КОНТЕЙНЕР ★★★
  container.innerHTML = '';

  // Добавляем обработчик для очистки при закрытии
  const cleanup = () => {
    if (unmountCalled) return;
    try {
      if (root && isMounted) {
        root.unmount();
        isMounted = false;
        unmountCalled = true;

        const styleElement = document.getElementById('react-consumer-specific-styles');
        if (styleElement && styleElement.parentNode) {
          styleElement.parentNode.removeChild(styleElement);
        }

        console.log(`🧹 React консюмер ${consumerId} размонтирован`);
      }
    } catch (error) {
      console.error(`❌ Ошибка размонтирования React Consumer ${consumerId}:`, error);
    }
  };

  try {
    root = ReactDOM.createRoot(container);

    // Рендерим компонент
    root.render(
      React.createElement(ReactConsumerComponent, {
        store: store,
        consumerId: consumerId,
        onMount: () => {
          isMounted = true;
          console.log(`✅ React Consumer ${consumerId} смонтирован`);
          if (options.onMount && typeof options.onMount === 'function') {
            try {
              options.onMount();
            } catch (error) {
              console.warn('⚠️ Ошибка в onMount callback:', error);
            }
          }
        },
        onError: (error) => {
          console.error(`❌ React Consumer ${consumerId} ошибка:`, error);
          if (options.onError && typeof options.onError === 'function') {
            try {
              options.onError(error);
            } catch (callbackError) {
              console.warn('⚠️ Ошибка в onError callback:', callbackError);
            }
          }
        },
      })
    );

    console.log(`✅ React консюмер ${consumerId} успешно смонтирован`);
  } catch (error) {
    console.error('❌ Ошибка монтирования React консюмера:', error);
    if (options.onError && typeof options.onError === 'function') {
      try {
        options.onError(error);
      } catch (callbackError) {
        console.warn('⚠️ Ошибка в onError callback:', callbackError);
      }
    }
    return null;
  }

  // Возвращаем объект с методами управления
  return {
    consumerId,
    isMounted: () => isMounted && !unmountCalled,
    getStore: () => store,
    getRoot: () => root,

    // Методы для сообщений
    sendMessage: (text, type = 'user') => {
      try {
        if (!store || typeof store.sendMessage !== 'function') {
          console.warn('⚠️ store.sendMessage не доступен');
          return false;
        }
        return store.sendMessage({
          id: Date.now() + Math.random(),
          ts: Date.now(),
          type: type,
          text: text,
          source: 'react-consumer',
          consumerId: consumerId,
        });
      } catch (error) {
        console.error('❌ Ошибка отправки сообщения:', error);
        return false;
      }
    },

    broadcastMessage: (text, type = 'broadcast') => {
      try {
        if (!store || typeof store.broadcastMessage !== 'function') {
          console.warn('⚠️ store.broadcastMessage не доступен');
          return false;
        }
        return store.broadcastMessage({
          id: Date.now() + Math.random(),
          ts: Date.now(),
          type: type,
          text: text,
          source: 'react-consumer',
          consumerId: consumerId,
        });
      } catch (error) {
        console.error('❌ Ошибка широковещательной отправки:', error);
        return false;
      }
    },

    getMessages: (limit = 50) => {
      try {
        if (typeof store.getMessages === 'function') {
          return store.getMessages(limit);
        }
        return [];
      } catch (error) {
        console.error('❌ Ошибка получения сообщений:', error);
        return [];
      }
    },

    clearMessages: () => {
      try {
        if (typeof store.clearMessages === 'function') {
          return store.clearMessages();
        }
        return false;
      } catch (error) {
        console.error('❌ Ошибка очистки сообщений:', error);
        return false;
      }
    },

    unmount: cleanup,

    healthCheck: () => {
      try {
        const metrics = store.getMetrics ? store.getMetrics() : [];
        const msgs = typeof store.getMessages === 'function' ? store.getMessages(10) : [];
        return {
          consumerId,
          isMounted: isMounted && !unmountCalled,
          metricsCount: metrics.length,
          messagesCount: msgs.length,
          status: store.getStatus ? store.getStatus() : 'unknown',
          storeVersion: store.__version || 'unknown',
          timestamp: Date.now(),
        };
      } catch (error) {
        return {
          consumerId,
          isMounted: false,
          error: error.message,
          timestamp: Date.now(),
        };
      }
    },

    forceUpdate: () => {
      try {
        if (root && isMounted && !unmountCalled) {
          root.render(
            React.createElement(ReactConsumerComponent, {
              store: store,
              consumerId: consumerId,
            })
          );
          console.log(`🔄 React Consumer ${consumerId} принудительно обновлен`);
          return true;
        }
        return false;
      } catch (error) {
        console.error(`❌ Ошибка принудительного обновления React Consumer ${consumerId}:`, error);
        return false;
      }
    },
  };
}

// ============================================================
// 7. ЭКСПОРТ ПО УМОЛЧАНИЮ
// ============================================================

export default mountReactConsumer;

// ============================================================
// 8. АВТОМАТИЧЕСКАЯ РЕГИСТРАЦИЯ
// ============================================================

if (typeof window !== 'undefined' && typeof document !== 'undefined') {
  window.__mountReactConsumer = function (targetElement, options = {}) {
    return mountReactConsumer(targetElement, options);
  };

  window.__getReactConsumerStatus = function (consumer) {
    if (consumer && typeof consumer.healthCheck === 'function') {
      return consumer.healthCheck();
    }
    return null;
  };

  window.__reactConsumerSendMessage = function (consumer, text, type = 'user') {
    if (consumer && typeof consumer.sendMessage === 'function') {
      return consumer.sendMessage(text, type);
    }
    console.error('❌ Consumer не найден или не имеет метода sendMessage');
    return false;
  };

  window.__reactConsumerBroadcast = function (consumer, text, type = 'broadcast') {
    if (consumer && typeof consumer.broadcastMessage === 'function') {
      return consumer.broadcastMessage(text, type);
    }
    console.error('❌ Consumer не найден или не имеет метода broadcastMessage');
    return false;
  };

  console.log('✅ React Consumer: Глобальная регистрация выполнена');
  console.log('📌 Используйте window.__mountReactConsumer(element, options) для монтирования');
  console.log('📌 Команды для сообщений:');
  console.log('  window.__reactConsumerSendMessage(consumer, text, type)');
  console.log('  window.__reactConsumerBroadcast(consumer, text, type)');
}

// ============================================================
// 9. ЭКСПОРТ КОНСТАНТ
// ============================================================

export const CONSUMER_TYPE = 'react';
export const CONSUMER_VERSION = '2.2.0';

// ============================================================
// 10. ЭКСПОРТ СИМВОЛОВ
// ============================================================

export {
  PRIVATE_SYMBOLS as REACT_CONSUMER_PRIVATE,
  PUBLIC_SYMBOLS as REACT_CONSUMER_PUBLIC,
  CONFIG as REACT_CONSUMER_CONFIG,
};

// ============================================================
// 11. СТАТИСТИКА СИМВОЛОВ
// ============================================================

if (typeof console !== 'undefined') {
  const privateCount = Object.keys(PRIVATE_SYMBOLS).length;
  const publicCount = Object.keys(PUBLIC_SYMBOLS).length;

  console.log(`📊 React Consumer: ${privateCount} приватных, ${publicCount} публичных символов`);
  console.log(`📦 Всего символов: ${privateCount + publicCount}`);
  console.log(`📋 Версия: ${CONFIG.version} (${CONFIG.build})`);
}
