// src/consumers/shared/styles.js

/**
 * Общие стили для всех консюмеров
 * Используются как Vue, так и React компонентами
 */

export const CONSUMER_STYLES = `
    /* ===== БАЗОВЫЙ КОНТЕЙНЕР ===== */
    .consumer-container {
        font-family: system-ui, -apple-system, 'Segoe UI', Roboto, 'Helvetica Neue', sans-serif;
        background: #0b0e14;
        color: #e0e4ee;
        padding: 16px;
        border-radius: 12px;
        max-width: 800px;
        margin: 0 auto;
        border: 1px solid #1e2633;
        box-shadow: 0 4px 24px rgba(0, 0, 0, 0.6);
        position: relative;
        transition: all 0.3s ease;
         width: stretch;
        
    }

    .consumer-container:hover {
        border-color: #2a3444;
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.8);
    }

    /* ===== ЗАГОЛОВОК ===== */
    .consumer-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 12px;
        padding: 8px 12px;
        background: #131a24;
        border-radius: 8px;
        border: 1px solid #1a2230;
    }

    .consumer-title {
        font-size: 16px;
        font-weight: 600;
        color: #c8d0e0;
        display: flex;
        align-items: center;
        gap: 8px;
        letter-spacing: -0.3px;
    }

    .consumer-title .icon {
        font-size: 18px;
    }

    .consumer-title .badge {
        font-size: 10px;
        background: #1e293b;
        padding: 2px 10px;
        border-radius: 20px;
        font-weight: 400;
        color: #8b96b0;
        border: 1px solid #2a3444;
        letter-spacing: 0;
    }

    /* ===== СТАТУС ===== */
    .consumer-status {
        font-size: 13px;
        padding: 4px 14px;
        border-radius: 20px;
        background: #1e293b;
        font-weight: 500;
        display: flex;
        align-items: center;
        gap: 6px;
        transition: all 0.3s ease;
        border: 1px solid transparent;
    }

    .consumer-status .dot {
        display: inline-block;
        width: 8px;
        height: 8px;
        border-radius: 50%;
        transition: background 0.3s ease;
    }

    /* Статусы */
    .consumer-status.playing {
        color: #34d399;
        border-color: rgba(52, 211, 153, 0.2);
    }

    .consumer-status.playing .dot {
        background: #34d399;
        box-shadow: 0 0 12px rgba(52, 211, 153, 0.3);
        animation: pulse-dot 1.5s infinite;
    }

    .consumer-status.paused {
        color: #fbbf24;
        border-color: rgba(251, 191, 36, 0.2);
    }

    .consumer-status.paused .dot {
        background: #fbbf24;
        box-shadow: 0 0 12px rgba(251, 191, 36, 0.2);
    }

    .consumer-status.disconnected {
        color: #ef4444;
        border-color: rgba(239, 68, 68, 0.2);
    }

    .consumer-status.disconnected .dot {
        background: #ef4444;
        box-shadow: 0 0 12px rgba(239, 68, 68, 0.2);
    }

    .consumer-status.connecting {
        color: #60a5fa;
        border-color: rgba(96, 165, 250, 0.2);
    }

    .consumer-status.connecting .dot {
        background: #60a5fa;
        box-shadow: 0 0 12px rgba(96, 165, 250, 0.2);
        animation: pulse-dot 0.8s infinite;
    }

    .consumer-status .count {
        font-weight: 400;
        color: #8b96b0;
        font-size: 12px;
        margin-left: 4px;
    }

    /* ===== АНИМАЦИИ ===== */
    @keyframes pulse-dot {
        0%, 100% {
            opacity: 1;
            transform: scale(1);
        }
        50% {
            opacity: 0.5;
            transform: scale(0.8);
        }
    }

    @keyframes fade-in {
        from {
            opacity: 0;
            transform: translateY(-10px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    @keyframes slide-in {
        from {
            opacity: 0;
            transform: translateX(-20px);
        }
        to {
            opacity: 1;
            transform: translateX(0);
        }
    }

    /* ===== СПИСОК ДАННЫХ ===== */
    .consumer-scroll-box {
        max-height: 420px;
        overflow-y: auto;
        border-radius: 8px;
        background: #0b0e14;
        border: 1px solid #161e2a;
        scroll-behavior: smooth;
    }

    .consumer-scroll-box::-webkit-scrollbar {
        width: 5px;
        height: 5px;
    }

    .consumer-scroll-box::-webkit-scrollbar-track {
        background: #0b0e14;
        border-radius: 10px;
    }

    .consumer-scroll-box::-webkit-scrollbar-thumb {
        background: #2a3444;
        border-radius: 10px;
        transition: background 0.3s;
    }

    .consumer-scroll-box::-webkit-scrollbar-thumb:hover {
        background: #3a4454;
    }

    .consumer-scroll-box .empty-state {
        text-align: center;
        padding: 48px 20px;
        color: #4a5a7a;
        font-size: 14px;
        line-height: 1.8;
        animation: fade-in 0.5s ease;
    }

    .consumer-scroll-box .empty-state .emoji {
        font-size: 32px;
        display: block;
        margin-bottom: 8px;
    }

    .consumer-scroll-box .empty-state .hint {
        font-size: 12px;
        color: #3a4a6a;
        display: block;
        margin-top: 4px;
    }

    /* ===== СТРОКА МЕТРИКИ ===== */
    .consumer-metric-row {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 8px 14px;
        border-bottom: 1px solid #161e2a;
        font-size: 13px;
        font-variant-numeric: tabular-nums;
        transition: all 0.15s ease;
        animation: slide-in 0.2s ease;
        cursor: default;
        position: relative;
    }

    .consumer-metric-row:hover {
        background: #131a24;
        border-left: 3px solid #3b82f6;
        padding-left: 11px;
    }

    .consumer-metric-row:last-child {
        border-bottom: none;
    }

    .consumer-metric-row .time {
        color: #6b7b96;
        font-size: 12px;
        font-weight: 400;
        display: flex;
        align-items: center;
        gap: 6px;
    }

    .consumer-metric-row .time .id {
        color: #4a5a7a;
        font-size: 10px;
        background: #161e2a;
        padding: 1px 6px;
        border-radius: 10px;
    }

    .consumer-metric-row .value {
        font-weight: 600;
        font-size: 14px;
        transition: color 0.3s ease;
        display: flex;
        align-items: center;
        gap: 4px;
    }

    .consumer-metric-row .value .unit {
        font-weight: 400;
        font-size: 11px;
        color: #6b7b96;
    }

    /* Цвета значений */
    .consumer-metric-row .value.high {
        color: #f472b6;
    }

    .consumer-metric-row .value.medium {
        color: #fbbf24;
    }

    .consumer-metric-row .value.low {
        color: #34d399;
    }

    .consumer-metric-row .value.critical {
        color: #ef4444;
        animation: pulse-value 1s infinite;
    }

    @keyframes pulse-value {
        0%, 100% {
            opacity: 1;
        }
        50% {
            opacity: 0.6;
        }
    }

    /* ===== ФУТЕР ===== */
    .consumer-footer {
        margin-top: 12px;
        padding: 10px 12px;
        border-top: 1px solid #161e2a;
        font-size: 11px;
        color: #4a5a7a;
        display: flex;
        justify-content: space-between;
        align-items: center;
        flex-wrap: wrap;
        gap: 8px;
        background: #0b0e14;
        border-radius: 0 0 8px 8px;
    }

    .consumer-footer .info-item {
        display: flex;
        align-items: center;
        gap: 4px;
    }

    .consumer-footer .info-item .label {
        color: #3a4a6a;
    }

    .consumer-footer .info-item .value {
        color: #8b96b0;
        font-weight: 500;
    }

    .consumer-footer .timestamp {
        color: #3a4a6a;
        font-size: 10px;
    }

    /* ===== КНОПКИ УПРАВЛЕНИЯ ===== */
    .consumer-controls {
        display: flex;
        gap: 8px;
        flex-wrap: wrap;
        margin-top: 12px;
        padding: 8px 12px;
        background: #0b0e14;
        border-radius: 8px;
        border: 1px solid #161e2a;
    }

    .consumer-controls .btn {
        padding: 6px 14px;
        border: none;
        border-radius: 6px;
        font-size: 12px;
        font-weight: 500;
        cursor: pointer;
        transition: all 0.2s ease;
        display: flex;
        align-items: center;
        gap: 4px;
    }

    .consumer-controls .btn:hover {
        transform: translateY(-1px);
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
    }

    .consumer-controls .btn:active {
        transform: translateY(0);
    }

    .consumer-controls .btn-primary {
        background: #3b82f6;
        color: white;
    }

    .consumer-controls .btn-primary:hover {
        background: #2563eb;
    }

    .consumer-controls .btn-success {
        background: #10b981;
        color: white;
    }

    .consumer-controls .btn-success:hover {
        background: #059669;
    }

    .consumer-controls .btn-danger {
        background: #ef4444;
        color: white;
    }

    .consumer-controls .btn-danger:hover {
        background: #dc2626;
    }

    .consumer-controls .btn-secondary {
        background: #1e2633;
        color: #c8d0e0;
        border: 1px solid #2a3444;
    }

    .consumer-controls .btn-secondary:hover {
        background: #2a3444;
        border-color: #3a4454;
    }

    /* ===== ИНДИКАТОРЫ ===== */
    .consumer-indicators {
        display: flex;
        gap: 16px;
        flex-wrap: wrap;
        padding: 8px 0;
    }

    .consumer-indicator {
        display: flex;
        align-items: center;
        gap: 6px;
        font-size: 12px;
        color: #6b7b96;
    }

    .consumer-indicator .bar {
        width: 60px;
        height: 3px;
        background: #1e2633;
        border-radius: 2px;
        overflow: hidden;
        position: relative;
    }

    .consumer-indicator .bar .fill {
        height: 100%;
        background: linear-gradient(90deg, #3b82f6, #60a5fa);
        border-radius: 2px;
        transition: width 0.3s ease;
        position: absolute;
        top: 0;
        left: 0;
    }

    /* ===== ТЕМНАЯ ТЕМА (по умолчанию) ===== */
    .consumer-container.dark {
        background: #0b0e14;
        border-color: #1e2633;
    }

    /* ===== СВЕТЛАЯ ТЕМА ===== */
    .consumer-container.light {
        background: #f8f9fc;
        color: #1a2230;
        border-color: #d1d5db;
    }

    .consumer-container.light .consumer-header {
        background: #f1f3f8;
        border-color: #e5e7eb;
    }

    .consumer-container.light .consumer-title {
        color: #1a2230;
    }

    .consumer-container.light .consumer-status {
        background: #e5e7eb;
    }

    .consumer-container.light .consumer-scroll-box {
        background: #ffffff;
        border-color: #e5e7eb;
    }

    .consumer-container.light .consumer-metric-row {
        border-color: #f0f0f0;
    }

    .consumer-container.light .consumer-metric-row:hover {
        background: #f8f9fc;
        border-left-color: #3b82f6;
    }

    .consumer-container.light .consumer-metric-row .time {
        color: #6b7280;
    }

    .consumer-container.light .consumer-footer {
        border-color: #e5e7eb;
        background: #ffffff;
    }

    .consumer-container.light .consumer-scroll-box::-webkit-scrollbar-track {
        background: #f0f0f0;
    }

    .consumer-container.light .consumer-scroll-box::-webkit-scrollbar-thumb {
        background: #d1d5db;
    }

    .consumer-container.light .consumer-scroll-box .empty-state {
        color: #6b7280;
    }

    .consumer-container.light .consumer-scroll-box .empty-state .hint {
        color: #9ca3af;
    }

    /* ===== АДАПТИВНОСТЬ ===== */
    @media (max-width: 640px) {
        .consumer-container {
            padding: 12px;
            margin: 8px;
            border-radius: 8px;
        }

        .consumer-header {
            flex-direction: column;
            align-items: stretch;
            gap: 8px;
        }

        .consumer-title {
            font-size: 14px;
        }

        .consumer-status {
            font-size: 12px;
            padding: 3px 10px;
            justify-content: center;
        }

        .consumer-metric-row {
            padding: 6px 10px;
            font-size: 12px;
        }

        .consumer-metric-row .value {
            font-size: 13px;
        }

        .consumer-footer {
            flex-direction: column;
            align-items: stretch;
            text-align: center;
            gap: 4px;
        }

        .consumer-controls {
            justify-content: center;
        }

        .consumer-controls .btn {
            padding: 4px 12px;
            font-size: 11px;
        }

        .consumer-indicators {
            justify-content: center;
        }
    }

    /* ===== ДОПОЛНИТЕЛЬНЫЕ УТИЛИТЫ ===== */
    .consumer-hidden {
        display: none !important;
    }

    .consumer-text-center {
        text-align: center;
    }

    .consumer-text-muted {
        color: #4a5a7a;
    }

    .consumer-text-small {
        font-size: 11px;
    }

    .consumer-flex {
        display: flex;
    }

    .consumer-flex-center {
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .consumer-gap-2 {
        gap: 8px;
    }

    .consumer-gap-4 {
        gap: 16px;
    }

    .consumer-mt-2 {
        margin-top: 8px;
    }

    .consumer-mt-4 {
        margin-top: 16px;
    }

    .consumer-mb-2 {
        margin-bottom: 8px;
    }

    .consumer-mb-4 {
        margin-bottom: 16px;
    }

    .consumer-p-2 {
        padding: 8px;
    }

    .consumer-p-4 {
        padding: 16px;
    }

    /* ===== СТАТУС БАДЖ ДЛЯ ЗАГОЛОВКА ===== */
    .consumer-status-badge {
        font-size: 11px;
        padding: 2px 12px;
        border-radius: 20px;
        background: #1e293b;
        font-weight: 400;
        transition: all 0.3s ease;
        border: 1px solid transparent;
    }

    .consumer-status-badge.active {
        color: #34d399;
        border-color: rgba(52, 211, 153, 0.2);
    }

    .consumer-status-badge.inactive {
        color: #4a5a7a;
        border-color: transparent;
    }

    .consumer-status-badge.error {
        color: #ef4444;
        border-color: rgba(239, 68, 68, 0.2);
    }

    /* ===== ПОЛОСА ЗАГРУЗКИ ===== */
    .consumer-loader {
        display: inline-block;
        width: 16px;
        height: 16px;
        border: 2px solid #1e2633;
        border-top-color: #3b82f6;
        border-radius: 50%;
        animation: spin 0.8s linear infinite;
    }

    @keyframes spin {
        to {
            transform: rotate(360deg);
        }
    }

    /* ===== КАСТОМНЫЙ СКРОЛЛ ДЛЯ КОНТЕЙНЕРА ===== */
    .consumer-container {
        scroll-behavior: smooth;
    }

    /* ===== ТУЛТИПЫ ===== */
    .consumer-tooltip {
        position: relative;
        cursor: help;
    }

    .consumer-tooltip:hover::after {
        content: attr(data-tooltip);
        position: absolute;
        bottom: 100%;
        left: 50%;
        transform: translateX(-50%);
        padding: 4px 12px;
        background: #1e2633;
        color: #c8d0e0;
        font-size: 11px;
        border-radius: 4px;
        white-space: nowrap;
        z-index: 100;
        border: 1px solid #2a3444;
        margin-bottom: 4px;
    }

    /* ===== МЕДИА ДЛЯ ПЕЧАТИ ===== */
    @media print {
        .consumer-container {
            background: white !important;
            color: black !important;
            border: 1px solid #ccc !important;
            box-shadow: none !important;
        }

        .consumer-status {
            background: #f0f0f0 !important;
            color: black !important;
        }

        .consumer-scroll-box {
            max-height: none !important;
            overflow: visible !important;
        }
    }

    /* ===== HIGH CONTRAST ===== */
    @media (prefers-contrast: high) {
        .consumer-container {
            border-width: 2px;
            border-color: white;
        }

        .consumer-metric-row {
            border-bottom-width: 2px;
        }

        .consumer-status {
            border-width: 2px;
        }
    }

    /* ===== REDUCED MOTION ===== */
    @media (prefers-reduced-motion: reduce) {
        * {
            animation-duration: 0.01ms !important;
            animation-iteration-count: 1 !important;
            transition-duration: 0.01ms !important;
        }

        .consumer-metric-row {
            animation: none !important;
        }

        .consumer-status.playing .dot {
            animation: none !important;
        }

        .consumer-status.connecting .dot {
            animation: none !important;
        }

        .consumer-metric-row .value.critical {
            animation: none !important;
        }
    }
`;

/**
 * Функция для инъекции стилей в DOM
 * @param {string} id - Уникальный ID для style элемента
 * @returns {HTMLElement} - Созданный style элемент
 */
export function injectStyles(id = 'consumer-shared-styles') {
  // Проверяем, не добавлены ли уже стили
  if (document.getElementById(id)) {
    return document.getElementById(id);
  }

  const styleElement = document.createElement('style');
  styleElement.id = id;
  styleElement.textContent = CONSUMER_STYLES;

  // Добавляем в head
  document.head.appendChild(styleElement);

  return styleElement;
}

/**
 * Функция для удаления инжектированных стилей
 * @param {string} id - ID стилей для удаления
 */
export function removeStyles(id = 'consumer-shared-styles') {
  const styleElement = document.getElementById(id);
  if (styleElement && styleElement.parentNode) {
    styleElement.parentNode.removeChild(styleElement);
    return true;
  }
  return false;
}

/**
 * Функция для создания CSS-классов на основе статуса
 * @param {string} status - Статус (playing, paused, disconnected, connecting)
 * @returns {string} - CSS классы для статуса
 */
export function getStatusClasses(status) {
  const baseClass = 'consumer-status';
  const statusMap = {
    playing: `${baseClass} playing`,
    paused: `${baseClass} paused`,
    disconnected: `${baseClass} disconnected`,
    connecting: `${baseClass} connecting`
  };
  return statusMap[status] || `${baseClass} disconnected`;
}

/**
 * Функция для получения CSS-класса значения
 * @param {number} value - Числовое значение
 * @param {Object} thresholds - Пороговые значения { high, medium, low, critical }
 * @returns {string} - CSS класс
 */
export function getValueClass(value, thresholds = { high: 100, medium: 70, low: 30, critical: 150 }) {
  if (value >= thresholds.critical) return 'value critical';
  if (value >= thresholds.high) return 'value high';
  if (value >= thresholds.medium) return 'value medium';
  if (value >= thresholds.low) return 'value low';
  return 'value';
}

/**
 * Функция для форматирования количества записей
 * @param {number} count - Количество записей
 * @returns {string} - Отформатированная строка
 */
export function formatCount(count) {
  if (count === 0) return '0 записей';
  if (count === 1) return '1 запись';
  if (count < 5) return `${count} записи`;
  return `${count} записей`;
}

/**
 * Функция для получения иконки статуса
 * @param {string} status - Статус
 * @returns {string} - Emoji иконка
 */
export function getStatusIcon(status) {
  const icons = {
    playing: '▶',
    paused: '⏸',
    disconnected: '⏹',
    connecting: '⟳'
  };
  return icons[status] || '●';
}

/**
 * Функция для получения цвета статуса (HEX)
 * @param {string} status - Статус
 * @returns {string} - HEX цвет
 */
export function getStatusColor(status) {
  const colors = {
    playing: '#34d399',
    paused: '#fbbf24',
    disconnected: '#ef4444',
    connecting: '#60a5fa'
  };
  return colors[status] || '#4a5a7a';
}

// Экспорт по умолчанию для удобства
export default {
  CONSUMER_STYLES,
  injectStyles,
  removeStyles,
  getStatusClasses,
  getValueClass,
  formatCount,
  getStatusIcon,
  getStatusColor
};