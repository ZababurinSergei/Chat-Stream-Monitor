// src/consumers/shared/mount-helper.js

/**
 * Вспомогательные функции для безопасного монтирования консюмеров
 * Обеспечивают единый интерфейс для всех фреймворков
 */

import { STORE_SYMBOL, checkStoreAccess } from '../../core/store.js';
import { checkEnvironment, generateConsumerId, sanitizeData } from '../../core/security.js';

/**
 * Проверка готовности окружения перед монтированием
 * @param {Object} options - Опции проверки
 * @param {boolean} options.requireSecure - Требовать безопасный контекст
 * @param {boolean} options.requireStore - Требовать наличие хранилища
 * @returns {Object} Результат проверки
 */
export function validateMountEnvironment(options = {}) {
  const {
    requireSecure = true,
    requireStore = true
  } = options;

  const result = {
    valid: true,
    errors: [],
    warnings: [],
    env: null,
    store: null
  };

  // 1. Проверка окружения
  const env = checkEnvironment();
  result.env = env;

  if (requireSecure && !env.isSecureContext) {
    result.valid = false;
    result.errors.push('Небезопасный контекст (isSecureContext = false)');
  }

  if (!env.hasGlobalThis) {
    result.valid = false;
    result.errors.push('globalThis не поддерживается');
  }

  if (!env.hasSymbol) {
    result.valid = false;
    result.errors.push('Symbol не поддерживается');
  }

  // 2. Проверка хранилища
  if (requireStore) {
    const storeCheck = checkStoreAccess(globalThis[STORE_SYMBOL]);
    if (!storeCheck.valid) {
      result.valid = false;
      result.errors.push(`Хранилище не доступно: ${storeCheck.error}`);
    } else {
      result.store = globalThis[STORE_SYMBOL];
    }
  }

  // 3. Проверка на XSS в URL
  const urlParams = new URLSearchParams(window.location?.search || '');
  const suspiciousPatterns = ['<script', 'javascript:', 'onerror=', 'onload=', 'onclick='];
  let hasSuspiciousParams = false;

  for (const [key, value] of urlParams) {
    for (const pattern of suspiciousPatterns) {
      if (value.toLowerCase().includes(pattern)) {
        result.warnings.push(`Обнаружен подозрительный параметр URL: ${key}=${value.substring(0, 30)}...`);
        hasSuspiciousParams = true;
        break;
      }
    }
  }

  if (hasSuspiciousParams && requireSecure) {
    result.valid = false;
    result.errors.push('Обнаружены подозрительные параметры в URL');
  }

  return result;
}

/**
 * Создание безопасного контейнера для консюмера
 * @param {Object} options - Опции контейнера
 * @param {string} options.position - Позиция: 'top-right', 'bottom-right', 'top-left', 'bottom-left'
 * @param {number} options.width - Ширина контейнера
 * @param {number} options.maxHeight - Максимальная высота
 * @param {string} options.title - Заголовок консюмера
 * @param {string} options.consumerType - Тип консюмера ('vue' или 'react')
 * @returns {Object} Объект с контейнером и методами управления
 */
export function createConsumerContainer(options = {}) {
  const {
    position = 'bottom-right',
    width = 420,
    maxHeight = '80vh',
    title = 'Consumer',
    consumerType = 'unknown'
  } = options;

  // Генерируем уникальный ID
  const containerId = `consumer-container-${consumerType}-${Date.now()}-${Math.random().toString(36).substring(2, 8)}`;

  // Создаем контейнер
  const container = document.createElement('div');
  container.id = containerId;

  // Определяем позицию
  const positionMap = {
    'top-right': { top: '20px', right: '20px', bottom: 'auto', left: 'auto' },
    'bottom-right': { top: 'auto', right: '20px', bottom: '20px', left: 'auto' },
    'top-left': { top: '20px', right: 'auto', bottom: 'auto', left: '20px' },
    'bottom-left': { top: 'auto', right: 'auto', bottom: '20px', left: '20px' }
  };

  const pos = positionMap[position] || positionMap['bottom-right'];

  // Применяем стили с проверкой на безопасность
  container.style.cssText = `
        position: fixed;
        ${pos.top !== 'auto' ? `top: ${pos.top};` : ''}
        ${pos.right !== 'auto' ? `right: ${pos.right};` : ''}
        ${pos.bottom !== 'auto' ? `bottom: ${pos.bottom};` : ''}
        ${pos.left !== 'auto' ? `left: ${pos.left};` : ''}
        z-index: 99999;
        width: ${typeof width === 'number' ? width + 'px' : width};
        max-height: ${maxHeight};
        overflow: auto;
        background: #0b0e14;
        border-radius: 12px;
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.8);
        border: 1px solid #1e2633;
        font-family: system-ui, -apple-system, 'Segoe UI', Roboto, sans-serif;
        transition: all 0.3s ease;
    `;

  // Добавляем заголовок с кнопкой закрытия
  const header = document.createElement('div');
  header.style.cssText = `
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 12px 16px;
        background: #131a24;
        border-bottom: 1px solid #1e2633;
        border-radius: 12px 12px 0 0;
        cursor: move;
        user-select: none;
    `;

  const titleElement = document.createElement('span');
  titleElement.style.cssText = `
        font-size: 14px;
        font-weight: 500;
        color: #c8d0e0;
        display: flex;
        align-items: center;
        gap: 8px;
    `;

  // Иконка в зависимости от типа
  const iconMap = {
    'vue': '🟢',
    'react': '⚛️',
    'unknown': '📦'
  };
  titleElement.textContent = `${iconMap[consumerType] || iconMap.unknown} ${title}`;

  // Кнопка закрытия с безопасной обработкой
  const closeBtn = document.createElement('button');
  closeBtn.textContent = '✕';
  closeBtn.style.cssText = `
        background: #ef4444;
        color: white;
        border: none;
        border-radius: 50%;
        width: 28px;
        height: 28px;
        cursor: pointer;
        font-size: 16px;
        transition: all 0.2s;
        display: flex;
        align-items: center;
        justify-content: center;
        line-height: 1;
    `;
  closeBtn.onmouseover = () => {
    closeBtn.style.background = '#dc2626';
    closeBtn.style.transform = 'scale(1.1)';
  };
  closeBtn.onmouseout = () => {
    closeBtn.style.background = '#ef4444';
    closeBtn.style.transform = 'scale(1)';
  };

  // Безопасная обработка закрытия
  let onCloseCallback = null;
  closeBtn.onclick = (event) => {
    event.preventDefault();
    event.stopPropagation();
    if (onCloseCallback) {
      try {
        onCloseCallback();
      } catch (error) {
        console.error('Ошибка при закрытии консюмера:', error);
      }
    }
    // Удаляем контейнер
    try {
      container.remove();
    } catch (error) {
      console.error('Ошибка удаления контейнера:', error);
    }
  };

  header.appendChild(titleElement);
  header.appendChild(closeBtn);
  container.appendChild(header);

  // Создаем область для контента
  const contentArea = document.createElement('div');
  contentArea.id = `${containerId}-content`;
  contentArea.style.cssText = `
        padding: 16px;
        min-height: 100px;
    `;
  container.appendChild(contentArea);

  // Добавляем в DOM
  try {
    document.body.appendChild(container);
  } catch (error) {
    console.error('Ошибка добавления контейнера в DOM:', error);
    return null;
  }

  // Функция для обновления позиции (drag & drop)
  let isDragging = false;
  let dragOffset = { x: 0, y: 0 };

  const onMouseDown = (e) => {
    if (e.target === closeBtn) return;
    isDragging = true;
    const rect = container.getBoundingClientRect();
    dragOffset.x = e.clientX - rect.left;
    dragOffset.y = e.clientY - rect.top;
    container.style.cursor = 'grabbing';
    e.preventDefault();
  };

  const onMouseMove = (e) => {
    if (!isDragging) return;
    const x = e.clientX - dragOffset.x;
    const y = e.clientY - dragOffset.y;
    container.style.left = x + 'px';
    container.style.top = y + 'px';
    container.style.right = 'auto';
    container.style.bottom = 'auto';
  };

  const onMouseUp = () => {
    isDragging = false;
    container.style.cursor = 'move';
  };

  header.addEventListener('mousedown', onMouseDown);
  document.addEventListener('mousemove', onMouseMove);
  document.addEventListener('mouseup', onMouseUp);

  // Возвращаем объект с методами управления
  return {
    container,
    contentArea,
    containerId,

    // Установка callback при закрытии
    onClose: (callback) => {
      if (typeof callback === 'function') {
        onCloseCallback = callback;
      }
    },

    // Обновление содержимого
    setContent: (html) => {
      if (typeof html === 'string') {
        contentArea.innerHTML = html;
      }
    },

    // Безопасное удаление
    destroy: () => {
      // Удаляем обработчики событий
      header.removeEventListener('mousedown', onMouseDown);
      document.removeEventListener('mousemove', onMouseMove);
      document.removeEventListener('mouseup', onMouseUp);

      // Удаляем контейнер
      try {
        container.remove();
      } catch (error) {
        console.error('Ошибка удаления контейнера:', error);
      }
    },

    // Обновление размера
    resize: (newWidth, newMaxHeight) => {
      if (newWidth) {
        container.style.width = typeof newWidth === 'number' ? newWidth + 'px' : newWidth;
      }
      if (newMaxHeight) {
        container.style.maxHeight = newMaxHeight;
      }
    },

    // Показать/скрыть
    show: () => {
      container.style.display = 'block';
    },
    hide: () => {
      container.style.display = 'none';
    },

    // Получение состояния
    getState: () => ({
      id: containerId,
      isVisible: container.style.display !== 'none',
      position: {
        top: container.style.top,
        left: container.style.left,
        right: container.style.right,
        bottom: container.style.bottom
      }
    })
  };
}

/**
 * Безопасная загрузка внешних скриптов
 * @param {string} url - URL скрипта
 * @param {Object} options - Опции загрузки
 * @returns {Promise} Promise с результатом загрузки
 */
export function loadScript(url, options = {}) {
  return new Promise((resolve, reject) => {
    const {
      timeout = 10000,
      integrity = null,
      crossorigin = 'anonymous'
    } = options;

    // Проверка URL на безопасность
    try {
      const urlObj = new URL(url, window.location.origin);
      // Проверяем, что это тот же origin или доверенный CDN
      const trustedDomains = [
        'cdn.jsdelivr.net',
        'unpkg.com',
        'cdnjs.cloudflare.com'
      ];

      if (!trustedDomains.some(domain => urlObj.hostname.includes(domain)) &&
        urlObj.origin !== window.location.origin) {
        reject(new Error('Недоверенный источник скрипта'));
        return;
      }
    } catch (error) {
      reject(new Error('Некорректный URL'));
      return;
    }

    // Проверяем, не загружен ли уже скрипт
    const existingScript = document.querySelector(`script[src="${url}"]`);
    if (existingScript) {
      resolve(existingScript);
      return;
    }

    const script = document.createElement('script');
    script.src = url;
    script.type = 'module';
    script.crossOrigin = crossorigin;
    if (integrity) {
      script.integrity = integrity;
    }

    let timeoutId = null;

    const cleanup = () => {
      if (timeoutId) {
        clearTimeout(timeoutId);
        timeoutId = null;
      }
      script.onload = null;
      script.onerror = null;
    };

    script.onload = () => {
      cleanup();
      resolve(script);
    };

    script.onerror = (error) => {
      cleanup();
      reject(error || new Error(`Ошибка загрузки скрипта: ${url}`));
    };

    if (timeout > 0) {
      timeoutId = setTimeout(() => {
        cleanup();
        script.remove();
        reject(new Error(`Таймаут загрузки скрипта: ${url}`));
      }, timeout);
    }

    document.head.appendChild(script);
  });
}

/**
 * Создание безопасного iframe для изоляции консюмера
 * @param {Object} options - Опции iframe
 * @param {string} options.src - URL для iframe
 * @param {string} options.sandbox - Политика sandbox
 * @param {number} options.width - Ширина
 * @param {number} options.height - Высота
 * @returns {Object} Объект с iframe и методами управления
 */
export function createSecureIframe(options = {}) {
  const {
    src = 'about:blank',
    sandbox = 'allow-scripts allow-same-origin',
    width = '100%',
    height = '400px',
    title = 'Secure Consumer'
  } = options;

  const iframe = document.createElement('iframe');
  iframe.src = src;
  iframe.sandbox = sandbox;
  iframe.width = width;
  iframe.height = height;
  iframe.title = title;
  iframe.style.cssText = `
        border: none;
        border-radius: 8px;
        background: #0b0e14;
    `;

  // Безопасная загрузка
  let isLoaded = false;
  let loadCallbacks = [];

  iframe.onload = () => {
    isLoaded = true;
    loadCallbacks.forEach(callback => {
      try {
        callback(iframe);
      } catch (error) {
        console.error('Ошибка в callback загрузки iframe:', error);
      }
    });
    loadCallbacks = [];
  };

  return {
    iframe,

    // Ожидание загрузки
    ready: () => {
      return new Promise((resolve) => {
        if (isLoaded) {
          resolve(iframe);
        } else {
          loadCallbacks.push(resolve);
        }
      });
    },

    // Безопасное удаление
    destroy: () => {
      try {
        iframe.remove();
      } catch (error) {
        console.error('Ошибка удаления iframe:', error);
      }
    },

    // Пост-сообщение в iframe с валидацией
    postMessage: (data, targetOrigin = '*') => {
      if (!isLoaded) {
        console.warn('iframe еще не загружен');
        return false;
      }

      try {
        // Валидация данных перед отправкой
        const safeData = JSON.parse(JSON.stringify(data));
        console.log('!!!!!!!!!!!!!!!!')
        iframe.contentWindow.postMessage(safeData, targetOrigin);
        return true;
      } catch (error) {
        console.error('Ошибка отправки сообщения в iframe:', error);
        return false;
      }
    }
  };
}

/**
 * Подписка на события с автоматической очисткой
 * @param {Object} target - Целевой объект
 * @param {string} event - Название события
 * @param {Function} handler - Обработчик
 * @param {Object} options - Опции подписки
 * @returns {Function} Функция отписки
 */
export function safeSubscribe(target, event, handler, options = {}) {
  if (!target || typeof target.addEventListener !== 'function') {
    console.warn('Некорректный target для подписки');
    return () => {};
  }

  // Обертка для безопасного вызова
  const safeHandler = (event) => {
    try {
      handler(event);
    } catch (error) {
      console.error(`Ошибка в обработчике события ${event}:`, error);
    }
  };

  target.addEventListener(event, safeHandler, options);

  // Возвращаем функцию отписки
  return () => {
    try {
      target.removeEventListener(event, safeHandler, options);
    } catch (error) {
      console.error(`Ошибка отписки от события ${event}:`, error);
    }
  };
}

/**
 * Экспорт по умолчанию - все утилиты в одном объекте
 */
export default {
  validateMountEnvironment,
  createConsumerContainer,
  loadScript,
  createSecureIframe,
  safeSubscribe,
  generateConsumerId,
  sanitizeData
};
