// src/modules/bookmarklet-template.js
// Модуль для подстановки переменных в шаблон букмарклета
// Версия: 1.0.0
import { escapeString } from '../utils/string-escape.js';
// ============================================================
// 1. КОНСТАНТЫ
// ============================================================

const DEFAULT_MODULE_SCRIPT = `
  console.error('❌ Код букмарклета не загружен');
  alert('❌ Ошибка: код букмарклета не доступен для выполнения');
`;

// ============================================================
// 2. ОСНОВНАЯ ФУНКЦИЯ ЗАМЕНЫ ПЕРЕМЕННЫХ
// ============================================================

/**
 * Заменяет переменные в шаблоне букмарклета
 * @param {string} moduleScript - Код для вставки вместо {{ moduleScript }}
 * @param {string} baseUrl - URL для вставки вместо {{ baseUrl }}
 * @returns {string} - Готовый код букмарклета
 */
// src/modules/bookmarklet-template.js
// Версия: 1.1.0 — Исправлен шаблон

function buildBookmarkletScript(moduleScript, baseUrl) {
  // Удаляем import.meta из кода
  const cleanedModule = moduleScript.replace(/import\.meta\.url/g, '""');

  return `
    (async function(props) {
      const { baseUrl, containerId, contentId, statusBadgeId, consumerId } = props;
      ${cleanedModule}
    })({
      baseUrl: '${baseUrl}',
      containerId: 'react-consumer-container-' + Date.now().toString(36),
      contentId: 'react-consumer-content-' + Date.now().toString(36),
      statusBadgeId: 'react-bookmarklet-status-' + Date.now().toString(36),
      consumerId: 'react_' + Date.now().toString(36) + '_' + Math.random().toString(36).substr(2, 6)
    });
  `;
}

// ============================================================
// 3. ФУНКЦИЯ ДЛЯ СОЗДАНИЯ ПОЛНОГО КОДА БУКМАРКЛЕТА
// ============================================================

/**
 * Создает полный код букмарклета с подстановкой переменных
 * @param {string} moduleScript - Код для вставки вместо {{ moduleScript }}
 * @param {string} baseUrl - URL для вставки вместо {{ baseUrl }}
 * @returns {string} - Полный код букмарклета с префиксом javascript:
 */
function createFullBookmarkletCode(moduleScript, baseUrl) {
  const script = buildBookmarkletScript(moduleScript, baseUrl);
  return `javascript:${script}`;
}

// ============================================================
// 4. ФУНКЦИЯ ДЛЯ ЗАГРУЗКИ КОДА ЧЕРЕЗ FETCH И ПОДСТАНОВКИ
// ============================================================

/**
 * Загружает код букмарклета через fetch и подставляет переменные
 * @param {string} url - URL для загрузки кода
 * @param {string} baseUrl - Базовый URL для подстановки
 * @param {boolean} useFallback - Использовать fallback при ошибке
 * @returns {Promise<string>} - Готовый код букмарклета
 */
async function loadAndBuildBookmarklet(url, baseUrl, useFallback = true) {
  try {
    console.log('------------------------ 📥 Загрузка кода букмарклета для подстановки:', url);

    const response = await fetch(url);

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    }

    const fetchedCode = await response.text();

    // Проверяем, что получили JS код
    if (!fetchedCode || fetchedCode.length < 10) {
      throw new Error('Получен пустой или слишком короткий код');
    }

    console.log(`✅ Код загружен: ${fetchedCode.length} символов`);

    // Подставляем переменные
    const finalBaseUrl = baseUrl || window.location.host;
    const result = buildBookmarkletScript(fetchedCode, finalBaseUrl);

    console.log(`✅ Код собран с подстановкой: baseUrl=${finalBaseUrl}`);
    return result;
  } catch (error) {
    console.error('❌ Ошибка загрузки кода букмарклета:', error);

    if (useFallback) {
      console.warn('⚠️ Используем fallback-заглушку');
      return buildBookmarkletScript(DEFAULT_MODULE_SCRIPT, baseUrl);
    }

    throw error;
  }
}

// ============================================================
// 5. ФУНКЦИЯ ДЛЯ ПОЛУЧЕНИЯ ЗАГОТОВКИ БЕЗ КОДА
// ============================================================

/**
 * Возвращает заготовку букмарклета с заглушкой вместо кода
 * @param {string} baseUrl - Базовый URL для подстановки
 * @returns {string} - Заготовка букмарклета
 */
function getEmptyBookmarklet(baseUrl) {
  return buildBookmarkletScript(DEFAULT_MODULE_SCRIPT, baseUrl);
}

// ============================================================
// 6. ЭКСПОРТЫ
// ============================================================

export {
  buildBookmarkletScript,
  createFullBookmarkletCode,
  loadAndBuildBookmarklet,
  getEmptyBookmarklet,
  DEFAULT_MODULE_SCRIPT,
};

// Экспорт по умолчанию
export default {
  buildBookmarkletScript,
  createFullBookmarkletCode,
  loadAndBuildBookmarklet,
  getEmptyBookmarklet,
  DEFAULT_MODULE_SCRIPT,
};

// ============================================================
// 7. ГЛОБАЛЬНАЯ РЕГИСТРАЦИЯ (только в браузере)
// ============================================================

if (typeof window !== 'undefined' && typeof document !== 'undefined') {
  // Регистрируем глобальные функции
  window.__buildBookmarklet = function (moduleScript, baseUrl) {
    return buildBookmarkletScript(moduleScript, baseUrl);
  };

  window.__createBookmarklet = function (moduleScript, baseUrl) {
    return createFullBookmarkletCode(moduleScript, baseUrl);
  };

  window.__loadAndBuildBookmarklet = async function (url, baseUrl, useFallback = true) {
    return await loadAndBuildBookmarklet(url, baseUrl, useFallback);
  };

  window.__getEmptyBookmarklet = function (baseUrl) {
    return getEmptyBookmarklet(baseUrl);
  };

  console.log('✅ Bookmarklet Template: Глобальная регистрация выполнена');
  console.log('📋 ДОСТУПНЫЕ КОМАНДЫ:');
  console.log('  window.__buildBookmarklet(moduleScript, baseUrl) - собрать букмарклет');
  console.log('  window.__createBookmarklet(moduleScript, baseUrl) - создать полный букмарклет');
  console.log(
    '  window.__loadAndBuildBookmarklet(url, baseUrl, useFallback) - загрузить и собрать'
  );
  console.log('  window.__getEmptyBookmarklet(baseUrl) - получить заготовку');
}
