// src/modules/index-app.js
// 100% СИМВОЛЫ — полная изоляция и безопасность
// Версия: 3.0.8 — Исправлена проверка загрузки букмарклетов

// ============================================================
// 1. ПРИВАТНЫЕ СИМВОЛЫ (100% изоляция)
// ============================================================

const PRIVATE = {
  VERSION: Symbol('index.version'),
  BUILD: Symbol('index.build'),
  NAME: Symbol('index.name'),
  CONFIG: Symbol('index.config'),
  STATE: Symbol('index.state'),
  INITIALIZED: Symbol('index.initialized'),
  DESTROYED: Symbol('index.destroyed'),
  LOAD_START: Symbol('index.loadStart'),
  LOAD_END: Symbol('index.loadEnd'),
  STORE: Symbol('index.store'),
  GLOBAL_STORE: Symbol('index.globalStore'),
  API: Symbol('index.api'),
  LOGGER: Symbol('index.logger'),
  ELEMENTS: Symbol('index.elements'),
  REFS: Symbol('index.refs'),
  SUBSCRIPTIONS: Symbol('index.subscriptions'),
  FREQUENCY: Symbol('index.frequency'),
  IS_ACTIVE: Symbol('index.isActive'),
  INTERVAL: Symbol('index.interval'),
  COUNTER: Symbol('index.counter'),
  INIT: Symbol('index.init'),
  DESTROY: Symbol('index.destroy'),
  SETUP_UI: Symbol('index.setupUI'),
  UPDATE_UI: Symbol('index.updateUI'),
  SETUP_BOOKMARKLETS: Symbol('index.setupBookmarklets'),
  SETUP_KEYBOARD: Symbol('index.setupKeyboard'),
  EXPORT_SYMBOLS: Symbol('index.exportSymbols'),
  GET_STATE: Symbol('index.getState'),
  HEALTH_CHECK: Symbol('index.healthCheck'),
  LOG: Symbol('index.log'),
  DEBUG: Symbol('index.debug'),
  ERROR: Symbol('index.error'),
  WARN: Symbol('index.warn'),
  SUCCESS: Symbol('index.success'),
  CREATE_BOOKMARK: Symbol('index.createBookmark'),
  CREATE_FOLDER: Symbol('index.createFolder'),
  CREATE_BOOKMARKLET: Symbol('index.createBookmarklet'),
  SHOW_NOTIFICATION: Symbol('index.showNotification'),
  GET_BOOKMARKLET_CODE: Symbol('index.getBookmarkletCode'),
  GENERATE_BOOKMARKLET_NAME: Symbol('index.generateBookmarkletName'),
  COPY_BOOKMARKLET_CODE: Symbol('index.copyBookmarkletCode'),
  DOWNLOAD_BOOKMARKLET: Symbol('index.downloadBookmarklet'),
  LOAD_BOOKMARKLETS: Symbol('index.loadBookmarklets'),
  UPDATE_BOOKMARKLET_DISPLAY: Symbol('index.updateBookmarkletDisplay'),
  BM_REQUEST: Symbol('index.bmRequest'),
  VUE_BOOKMARKLET_CODE: Symbol('index.vueBookmarkletCode'),
  REACT_BOOKMARKLET_CODE: Symbol('index.reactBookmarkletCode'),
  VUE_LOADED: Symbol('index.vueLoaded'),
  REACT_LOADED: Symbol('index.reactLoaded'),
  IS_BOOKMARKLET_LOADED: Symbol('index.isBookmarkletLoaded'),
};

// ============================================================
// 2. ПУБЛИЧНЫЕ СИМВОЛЫ (доступны через Symbol.for)
// ============================================================

const PUBLIC = {
  INSTANCE: Symbol.for('index.instance'),
  STATE: Symbol.for('index.state'),
  CONFIG: Symbol.for('index.config'),
  INIT: Symbol.for('index.init'),
  DESTROY: Symbol.for('index.destroy'),
  GET_STATE: Symbol.for('index.getState'),
  HEALTH_CHECK: Symbol.for('index.healthCheck'),
  GET_STORE: Symbol.for('index.getStore'),
  GET_GLOBAL_STORE: Symbol.for('index.getGlobalStore'),
};

// ============================================================
// 3. КОНФИГУРАЦИЯ
// ============================================================

const CONFIG = {
  version: '3.0.8',
  build: '2026-07-27',
  name: 'Index Page — Global Store',
  debug: true,
  defaultFrequency: 200,
  maxItems: 500,
  maxMessages: 100,
  storageKey: 'global_store_autostart',
  apiUrl: '/extension/api-navigator.html',
};

// ============================================================
// 4. ЛОГГЕР
// ============================================================

const LOGGER_SYMBOLS = {
  HISTORY: Symbol('logger.history'),
  MAX_HISTORY: Symbol('logger.maxHistory'),
  DEBUG: Symbol('logger.debug'),
  INSTANCE_ID: Symbol('logger.instanceId'),
  LEVEL: Symbol('logger.level'),
};

function createLogger(debug = true, instanceId = 'Index') {
  const logState = {
    [LOGGER_SYMBOLS.HISTORY]: [],
    [LOGGER_SYMBOLS.MAX_HISTORY]: 200,
    [LOGGER_SYMBOLS.DEBUG]: debug,
    [LOGGER_SYMBOLS.INSTANCE_ID]: instanceId,
    [LOGGER_SYMBOLS.LEVEL]: debug ? 3 : 2,
  };

  const logMethod = function (level, message, data = null) {
    const levels = { error: 0, warn: 1, info: 2, debug: 3, success: 2 };
    const currentLevel = this[LOGGER_SYMBOLS.LEVEL] || 2;
    const msgLevel = levels[level] || 2;

    if (msgLevel > currentLevel) return;

    const timestamp = new Date().toISOString().slice(11, 23);
    const prefix = `[${timestamp}] [${this[LOGGER_SYMBOLS.INSTANCE_ID]}]`;

    this[LOGGER_SYMBOLS.HISTORY].push({
      timestamp,
      level,
      message,
      data,
      id: Date.now() + Math.random(),
    });

    if (this[LOGGER_SYMBOLS.HISTORY].length > this[LOGGER_SYMBOLS.MAX_HISTORY]) {
      this[LOGGER_SYMBOLS.HISTORY].shift();
    }

    const icons = { error: '❌', warn: '⚠️', info: 'ℹ️', debug: '🔍', success: '✅' };
    const icon = icons[level] || '📌';

    if (data !== null && data !== undefined) {
      console.log(`${icon} ${prefix} ${message}`, data);
    } else {
      console.log(`${icon} ${prefix} ${message}`);
    }
  };

  const boundLog = logMethod.bind(logState);

  const methods = {
    error: (msg, d) => boundLog('error', msg, d),
    warn: (msg, d) => boundLog('warn', msg, d),
    info: (msg, d) => boundLog('info', msg, d),
    debug: (msg, d) => boundLog('debug', msg, d),
    success: (msg, d) => boundLog('success', msg, d),

    header: (title, color = '#636e72') => {
      console.log('%c' + '═'.repeat(70), `color: ${color};`);
      console.log(
        '%c  📦 ' + title,
        'background: #1a1a2e; color: #fff; padding: 4px 12px; border-radius: 4px; font-weight: bold;'
      );
      console.log('%c' + '═'.repeat(70), `color: ${color};`);
    },

    separator: (color = '#636e72') => {
      console.log('%c' + '─'.repeat(70), `color: ${color};`);
    },

    getHistory: function () {
      return [...this[LOGGER_SYMBOLS.HISTORY]];
    },

    clearHistory: function () {
      this[LOGGER_SYMBOLS.HISTORY] = [];
      return this;
    },

    setDebug: function (enabled) {
      this[LOGGER_SYMBOLS.DEBUG] = enabled;
      this[LOGGER_SYMBOLS.LEVEL] = enabled ? 3 : 2;
      return this;
    },
  };

  const logger = {};
  for (const [key, fn] of Object.entries(methods)) {
    logger[key] = fn.bind(logState);
  }

  logger[LOGGER_SYMBOLS.HISTORY] = logState[LOGGER_SYMBOLS.HISTORY];
  logger[LOGGER_SYMBOLS.MAX_HISTORY] = logState[LOGGER_SYMBOLS.MAX_HISTORY];
  logger[LOGGER_SYMBOLS.DEBUG] = logState[LOGGER_SYMBOLS.DEBUG];
  logger[LOGGER_SYMBOLS.INSTANCE_ID] = logState[LOGGER_SYMBOLS.INSTANCE_ID];
  logger[LOGGER_SYMBOLS.LEVEL] = logState[LOGGER_SYMBOLS.LEVEL];

  return logger;
}

// ============================================================
// 5. ИМПОРТЫ
// ============================================================

import { getGlobalStore, GLOBAL_STORE_SYMBOL } from '../core/global-store.js';
import { mountVueConsumer as vueConsumerMount } from '../consumers/vue-consumer.js';
import { mountReactConsumer as reactConsumerMount } from '../consumers/react-consumer.js';
import {
  getVueBookmarkletMinifiedCached as vueMinified,
  clearVueCache as vueClearCache,
} from './vue-bookmarklet.js';
import {
  getReactBookmarkletMinifiedCached as reactMinified,
  clearReactBookmarkletCache as reactClearCache,
} from './react-bookmarklet.js';

// ============================================================
// 6. ЛОГГЕР
// ============================================================

const logger = createLogger(CONFIG.debug, 'Index');

// ============================================================
// 7. СОСТОЯНИЕ
// ============================================================

const STATE = {
  [PRIVATE.INITIALIZED]: false,
  [PRIVATE.DESTROYED]: false,
  [PRIVATE.FREQUENCY]: CONFIG.defaultFrequency,
  [PRIVATE.IS_ACTIVE]: false,
  [PRIVATE.INTERVAL]: null,
  [PRIVATE.COUNTER]: 0,
  [PRIVATE.LOAD_START]: Date.now(),
  [PRIVATE.LOAD_END]: null,
  [PRIVATE.VUE_BOOKMARKLET_CODE]: '',
  [PRIVATE.REACT_BOOKMARKLET_CODE]: '',
  [PRIVATE.VUE_LOADED]: false,
  [PRIVATE.REACT_LOADED]: false,
};

// ============================================================
// 8. DOM РЕФЕРЕНСЫ
// ============================================================

const REFS = {};

// ============================================================
// 9. ПОЛУЧАЕМ ХРАНИЛИЩЕ ИЗ GLOBAL-STORE
// ============================================================

const globalStore = getGlobalStore();

const store = {
  getState: () => {
    const state = globalStore.getState();
    const metrics = globalStore.select('metrics') || [];
    return {
      ...state,
      liveMetrics: metrics.map((m) => ({
        id: m.id,
        ts: m.timestamp || m.ts || Date.now(),
        val: m.value || m.val || 0,
        trend: m.trend || 0,
        source: m.source || 'stream',
      })),
      streamStatus: state.streamStatus || 'disconnected',
      totalBatches: state._batches || 0,
      lastUpdate: state.lastUpdate || null,
    };
  },

  getMetrics: () => {
    const metrics = globalStore.select('metrics') || [];
    return metrics.map((m) => ({
      id: m.id,
      ts: m.timestamp || m.ts || Date.now(),
      val: m.value || m.val || 0,
      trend: m.trend || 0,
      source: m.source || 'stream',
    }));
  },

  getStatus: () => {
    const state = globalStore.getState();
    return state.streamStatus || 'disconnected';
  },

  setStatus: (status) => {
    const validStatuses = ['playing', 'paused', 'disconnected', 'connecting'];
    if (!validStatuses.includes(status)) {
      logger.warn(`⚠️ Некорректный статус: ${status}`);
      return false;
    }

    const state = globalStore.getState();
    state.streamStatus = status;
    state.lastUpdate = Date.now();

    globalStore.publish('store-status', {
      type: 'status-change',
      payload: { status, timestamp: Date.now() },
    });

    logger.debug(`📊 Статус обновлен: ${status}`);
    return true;
  },

  appendDataBatch: (batch) => {
    const adaptedBatch = batch.map((item) => ({
      id: item.id || `metric_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`,
      timestamp: item.ts || Date.now(),
      value: item.val || 0,
      trend: item.trend || 0,
      source: item.source || 'stream',
    }));
    return globalStore.insert('metrics', adaptedBatch);
  },

  clearStore: () => {
    globalStore.clearTable('metrics');
    globalStore.clearTable('messages');
    globalStore._batches = 0;
  },

  sendMessage: (msg) => {
    const result = globalStore.insert('messages', {
      id: msg.id || `msg_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`,
      timestamp: msg.ts || Date.now(),
      text: msg.text,
      type: msg.type || 'user',
      source: msg.source || 'unknown',
      consumerId: msg.consumerId || null,
    });
    globalStore.publish('messages', { type: 'user-message', payload: msg });
    return result;
  },

  broadcastMessage: (msg) => {
    const result = globalStore.insert('messages', {
      id: msg.id || `msg_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`,
      timestamp: msg.ts || Date.now(),
      text: msg.text,
      type: 'broadcast',
      source: msg.source || 'broadcast',
      consumerId: msg.consumerId || null,
    });
    globalStore.publish('broadcast', { type: 'broadcast', payload: msg });
    return result;
  },

  getMessages: (limit) => {
    const msgs = globalStore.select('messages', {
      sort: [{ field: 'timestamp', direction: 'desc' }],
      limit: limit || 50,
    });
    return msgs || [];
  },

  clearMessages: () => {
    return globalStore.clearTable('messages');
  },

  replaceMessages: (messages) => {
    globalStore.clearTable('messages');
    if (messages && messages.length > 0) {
      const rows = messages.map((msg) => ({
        id: msg.id || `msg_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`,
        timestamp: msg.ts || Date.now(),
        text: msg.text || '',
        type: msg.type || 'restored',
        source: msg.source || 'restored',
        consumerId: msg.consumerId || null,
      }));
      return globalStore.insert('messages', rows);
    }
    return true;
  },

  subscribe: (callback) => {
    return globalStore.subscribe('*', (channel, message) => {
      if (message.type === 'store-event' || message.type === 'status-change') {
        callback(store.getState());
      }
    });
  },

  healthCheck: () => {
    const state = globalStore.getState();
    return {
      version: state.version || 'unknown',
      metricsCount: (globalStore.select('metrics') || []).length,
      status: state.streamStatus || 'disconnected',
      subscribers: state._subscribersCount || 0,
      messagesCount: (globalStore.select('messages') || []).length,
      batches: state._batches || 0,
      channelActive: true,
      lastUpdate: state.lastUpdate || null,
      isValid: true,
    };
  },

  getAutoStart: () => {
    try {
      return JSON.parse(localStorage.getItem(CONFIG.storageKey) || 'false');
    } catch {
      return false;
    }
  },

  setAutoStart: (value) => {
    try {
      localStorage.setItem(CONFIG.storageKey, JSON.stringify(!!value));
      return true;
    } catch {
      return false;
    }
  },

  __version: '3.0.2',
  __created: Date.now(),
  getGlobalStore: () => globalStore,
};

// ============================================================
// 10. ИНИЦИАЛИЗАЦИЯ ТАБЛИЦ
// ============================================================

function initTables() {
  if (!globalStore.getTable('metrics')) {
    globalStore.createTable('metrics', {
      schema: {
        id: { type: 'string', required: true },
        timestamp: { type: 'number', required: true },
        value: { type: 'number', required: true },
        trend: { type: 'number', default: 0 },
        source: { type: 'string', default: 'stream' },
      },
      indexes: ['timestamp', 'source'],
      metadata: { description: 'Метрики высокой частоты' },
    });
    logger.success('✅ Таблица metrics создана в GlobalStore');
  }

  if (!globalStore.getTable('messages')) {
    globalStore.createTable('messages', {
      schema: {
        id: { type: 'string', required: true },
        timestamp: { type: 'number', required: true },
        text: { type: 'string', required: true },
        type: { type: 'string', default: 'user' },
        source: { type: 'string', default: 'unknown' },
        consumerId: { type: 'string', nullable: true },
      },
      indexes: ['timestamp', 'type', 'source'],
      metadata: { description: 'Сообщения между консюмерами' },
    });
    logger.success('✅ Таблица messages создана в GlobalStore');
  }

  if (!globalStore._detailLinked) {
    globalStore.linkTables('metrics', 'messages', 'metricId');
    globalStore._detailLinked = true;
    logger.success('✅ Мастер-детейл связь настроена: metrics → messages');
  }
}

initTables();

// ============================================================
// 11. ГЕНЕРАТОР ДАННЫХ
// ============================================================

function generateData() {
  STATE[PRIVATE.COUNTER]++;
  return {
    id: `metric_${STATE[PRIVATE.COUNTER]}_${Date.now().toString(36)}`,
    ts: Date.now(),
    val: Math.round((50 + Math.random() * 80) * 100) / 100,
    trend: Math.sin(STATE[PRIVATE.COUNTER] / 50) * 20 + 50,
    source: 'stream',
  };
}

// ============================================================
// 12. УПРАВЛЕНИЕ СТРИМОМ
// ============================================================

function startStream() {
  if (STATE[PRIVATE.IS_ACTIVE]) {
    logger.warn('⚠️ Стриминг уже активен');
    return false;
  }

  STATE[PRIVATE.IS_ACTIVE] = true;

  const intervalMs = 1000 / STATE[PRIVATE.FREQUENCY];
  STATE[PRIVATE.INTERVAL] = setInterval(() => {
    if (!STATE[PRIVATE.IS_ACTIVE]) return;
    const count = 1 + Math.floor(Math.random() * 2);
    const batch = [];
    for (let i = 0; i < count; i++) {
      const data = generateData();
      batch.push(data);
    }

    store.appendDataBatch(batch);

    globalStore.publish('metrics', {
      type: 'metrics-batch',
      payload: { count: batch.length, timestamp: Date.now() },
    });

    const currentState = globalStore.getState();
    const batches = currentState._batches || 0;
    const totalBatchesEl = document.getElementById('totalBatches');
    if (totalBatchesEl) {
      totalBatchesEl.textContent = batches + 1;
    }
    globalStore._batches = batches + 1;
  }, intervalMs);

  store.setStatus('playing');
  logger.success(`✅ Стриминг запущен, частота: ${STATE[PRIVATE.FREQUENCY]} Гц`);
  updateUI();
  return true;
}

function stopStream() {
  if (!STATE[PRIVATE.IS_ACTIVE]) {
    logger.warn('⚠️ Стриминг уже остановлен');
    return false;
  }

  STATE[PRIVATE.IS_ACTIVE] = false;
  if (STATE[PRIVATE.INTERVAL]) {
    clearInterval(STATE[PRIVATE.INTERVAL]);
    STATE[PRIVATE.INTERVAL] = null;
  }

  store.setStatus('disconnected');
  logger.success('⏹ Стриминг остановлен');
  updateUI();
  return true;
}

function clearData() {
  globalStore.clearTable('metrics');
  globalStore.clearTable('messages');
  globalStore.clearSelection('metrics');
  STATE[PRIVATE.COUNTER] = 0;
  globalStore._batches = 0;
  const totalBatchesEl = document.getElementById('totalBatches');
  if (totalBatchesEl) {
    totalBatchesEl.textContent = '0';
  }
  logger.success('🗑 Все данные очищены');
  updateUI();
  return true;
}

function setFrequency(freq) {
  if (typeof freq === 'number' && freq > 0) {
    STATE[PRIVATE.FREQUENCY] = freq;
    if (STATE[PRIVATE.IS_ACTIVE]) {
      stopStream();
      setTimeout(startStream, 100);
      logger.info(`🔄 Частота изменена: ${freq} Гц`);
    }
    return true;
  }
  return false;
}

// ============================================================
// 13. ОБНОВЛЕНИЕ UI
// ============================================================

function updateUI() {
  try {
    const state = store.getState();
    const totalItemsEl = document.getElementById('totalItems');
    const streamStatusEl = document.getElementById('streamStatus');
    const lastUpdateEl = document.getElementById('lastUpdate');

    if (totalItemsEl) {
      totalItemsEl.textContent = state.liveMetrics ? state.liveMetrics.length : 0;
    }
    if (streamStatusEl) {
      const status = state.streamStatus || 'disconnected';
      streamStatusEl.textContent = status;
      streamStatusEl.className = 'value ' + status;
    }
    if (lastUpdateEl) {
      lastUpdateEl.textContent = state.lastUpdate
        ? new Date(state.lastUpdate).toLocaleTimeString()
        : '—';
    }

    const vueStatus = document.getElementById('vueStatus');
    const reactStatus = document.getElementById('reactStatus');
    if (vueStatus) {
      if (window.__vueConsumer && window.__vueConsumer.isMounted) {
        vueStatus.textContent = 'активен';
        vueStatus.className = 'status-badge active';
      }
    }
    if (reactStatus) {
      if (window.__reactConsumer && window.__reactConsumer.isMounted) {
        reactStatus.textContent = 'активен';
        reactStatus.className = 'status-badge active';
      }
    }
  } catch (error) {
    logger.warn('⚠️ Ошибка обновления UI:', error);
  }
}

// ============================================================
// 14. ФУНКЦИИ ДЛЯ РАБОТЫ С API ЗАКЛАДОК
// ============================================================

function bmRequest(action, args) {
  return new Promise((resolve, reject) => {
    const id = Date.now() + '_' + Math.random().toString(36).substr(2, 9);

    const handler = function (event) {
      if (event.data?.action === 'response' && event.data?.id === id) {
        window.removeEventListener('message', handler);
        if (event.data.success) {
          resolve(event.data.result);
        } else {
          reject(new Error(event.data.error || 'Unknown error'));
        }
      }
    };
    window.addEventListener('message', handler);

    window.postMessage(
      {
        action: 'apiCall',
        id: id,
        method: action,
        args: args,
      },
      '*'
    );

    setTimeout(function () {
      window.removeEventListener('message', handler);
      reject(new Error('Timeout: ответ не получен'));
    }, 30000);
  });
}

async function createBookmark(title, url, parentId = '1') {
  try {
    const result = await bmRequest('create', [parentId, title, url]);
    showNotification(`✅ Закладка создана: ${title}`, 'success');
    logger.success(`✅ Закладка создана: ${title} (ID: ${result.id})`);
    return result;
  } catch (error) {
    logger.error('❌ Ошибка создания закладки:', error);
    showNotification(`❌ Ошибка: ${error.message}`, 'error');
    return null;
  }
}

async function createFolder(title, parentId = '1') {
  try {
    const result = await bmRequest('create', [parentId, title, null]);
    showNotification(`✅ Папка создана: ${title}`, 'success');
    logger.success(`✅ Папка создана: ${title} (ID: ${result.id})`);
    return result;
  } catch (error) {
    logger.error('❌ Ошибка создания папки:', error);
    showNotification(`❌ Ошибка: ${error.message}`, 'error');
    return null;
  }
}

function showNotification(message, type = 'info') {
  const colors = {
    success: '#34d399',
    error: '#ef4444',
    info: '#60a5fa',
    warn: '#fbbf24',
  };

  const notification = document.createElement('div');
  notification.className =
    type === 'success' ? 'success-message' : type === 'error' ? 'error-message' : 'info-message';
  notification.textContent = message;
  notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        z-index: 999999;
        max-width: 400px;
        animation: slideIn 0.3s ease;
        box-shadow: 0 4px 12px rgba(0,0,0,0.5);
        font-family: system-ui, -apple-system, sans-serif;
        border-left: 4px solid ${colors[type] || '#60a5fa'};
    `;

  if (!document.getElementById('notification-styles')) {
    const style = document.createElement('style');
    style.id = 'notification-styles';
    style.textContent = `
            @keyframes slideIn {
                from { transform: translateX(100%); opacity: 0; }
                to { transform: translateX(0%); opacity: 1; }
            }
            @keyframes slideOut {
                from { transform: translateX(0%); opacity: 1; }
                to { transform: translateX(100%); opacity: 0; }
            }
        `;
    document.head.appendChild(style);
  }

  document.body.appendChild(notification);

  setTimeout(function () {
    notification.style.animation = 'slideOut 0.3s ease';
    setTimeout(function () {
      if (notification.parentNode) {
        notification.parentNode.removeChild(notification);
      }
    }, 300);
  }, 3000);
}

// ============================================================
// ★★★ 15. ФУНКЦИИ ДЛЯ РАБОТЫ С БУКМАРКЛЕТАМИ ★★★
// ============================================================

function getBookmarkletCode(type) {
  if (type === 'vue') {
    return STATE[PRIVATE.VUE_BOOKMARKLET_CODE] || '';
  }
  if (type === 'react') {
    return STATE[PRIVATE.REACT_BOOKMARKLET_CODE] || '';
  }
  return '';
}

function isBookmarkletLoaded(type) {
  // ★★★ СНАЧАЛА ПРОВЕРЯЕМ ФЛАГ ★★★
  if (type === 'vue' && STATE[PRIVATE.VUE_LOADED]) {
    return true;
  }
  if (type === 'react' && STATE[PRIVATE.REACT_LOADED]) {
    return true;
  }

  const code = getBookmarkletCode(type);

  // Если код пустой
  if (!code || code.length === 0) {
    return false;
  }

  // Проверяем минимальную длину
  if (code.length < 100) {
    return false;
  }

  // ★★★ НЕ ПРОВЕРЯЕМ НА "Загрузка" — ЭТО ЕСТЬ В КОДЕ ★★★
  // Проверяем только явные ошибки
  if (
    code.includes('❌ Ошибка загрузки') ||
    code.includes('не загружен') ||
    code.includes('Failed to load')
  ) {
    return false;
  }

  // Проверяем, что это валидный JS код
  const isValidJS =
    code.includes('async function') ||
    code.includes('function') ||
    code.includes('=>') ||
    code.includes('{') ||
    code.includes('return');

  if (!isValidJS) {
    return false;
  }

  // ★★★ УСТАНАВЛИВАЕМ ФЛАГ ★★★
  if (type === 'vue') {
    STATE[PRIVATE.VUE_LOADED] = true;
  } else if (type === 'react') {
    STATE[PRIVATE.REACT_LOADED] = true;
  }

  return true;
}

function generateBookmarkletName(type) {
  const now = new Date();
  const dateStr = now.toISOString().slice(0, 10);
  const timeStr = now.toTimeString().slice(0, 5).replace(':', '-');

  const names = {
    vue: `Vue Consumer ${dateStr} ${timeStr}`,
    react: `React Consumer ${dateStr} ${timeStr}`,
  };
  return names[type] || `Consumer ${dateStr} ${timeStr}`;
}

async function createBookmarkletFromCode(type) {
  try {
    if (!isBookmarkletLoaded(type)) {
      const code = getBookmarkletCode(type);
      const length = code ? code.length : 0;
      showNotification(`❌ Код букмарклета ${type} не загружен (длина: ${length})`, 'error');
      logger.error(`❌ Код букмарклета ${type} не загружен, длина: ${length}`);
      return;
    }

    const code = getBookmarkletCode(type);
    let url = code;
    if (!url.startsWith('javascript:')) {
      url = 'javascript:' + url;
    }

    const name = generateBookmarkletName(type);
    const typeLabel = type === 'vue' ? 'Vue' : 'React';

    const result = await bmRequest('create', ['1', name, url]);

    if (result && result.id) {
      showNotification(`✅ ${typeLabel} букмарклет создан: ${name}`, 'success');
      logger.success(`✅ ${typeLabel} букмарклет создан: ${name} (ID: ${result.id})`);
      updateUI();
    } else {
      showNotification(`❌ Ошибка создания ${typeLabel} букмарклета`, 'error');
    }
  } catch (error) {
    logger.error(`❌ Ошибка создания букмарклета ${type}:`, error);
    showNotification(`❌ Ошибка: ${error.message}`, 'error');
  }
}

function copyBookmarkletCode(type) {
  if (!isBookmarkletLoaded(type)) {
    const code = getBookmarkletCode(type);
    const length = code ? code.length : 0;
    showNotification(`❌ Код букмарклета ${type} не загружен (длина: ${length})`, 'error');
    logger.error(`❌ Код букмарклета ${type} не загружен, длина: ${length}`);
    return;
  }

  const code = getBookmarkletCode(type);

  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard
      .writeText(code)
      .then(() => {
        const typeLabel = type === 'vue' ? 'Vue' : 'React';
        showNotification(`📋 ${typeLabel} букмарклет скопирован`, 'success');
        logger.success(`📋 ${typeLabel} букмарклет скопирован`);
      })
      .catch(() => {
        fallbackCopy(code, type);
      });
  } else {
    fallbackCopy(code, type);
  }
}

function fallbackCopy(code, type) {
  try {
    const ta = document.createElement('textarea');
    ta.value = code;
    ta.style.cssText =
      'position:fixed;opacity:0;top:0;left:0;width:1px;height:1px;pointer-events:none;';
    document.body.appendChild(ta);
    ta.select();
    document.execCommand('copy');
    document.body.removeChild(ta);
    const typeLabel = type === 'vue' ? 'Vue' : 'React';
    showNotification(`📋 ${typeLabel} букмарклет скопирован (fallback)`, 'success');
    logger.success(`📋 ${typeLabel} букмарклет скопирован (fallback)`);
  } catch (error) {
    showNotification(`❌ Ошибка копирования: ${error.message}`, 'error');
    logger.error(`❌ Ошибка копирования:`, error);
  }
}

function downloadBookmarklet(type) {
  if (!isBookmarkletLoaded(type)) {
    const code = getBookmarkletCode(type);
    const length = code ? code.length : 0;
    showNotification(`❌ Код букмарклета ${type} не загружен (длина: ${length})`, 'error');
    logger.error(`❌ Код букмарклета ${type} не загружен, длина: ${length}`);
    return;
  }

  const code = getBookmarkletCode(type);
  const typeLabel = type === 'vue' ? 'Vue' : 'React';
  const name = generateBookmarkletName(type);

  const html = `<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>${name}</title>
</head>
<body>
    <h1>📌 ${typeLabel} Consumer Bookmarklet</h1>
    <p>Перетащите ссылку ниже в панель закладок:</p>
    <a href="${code}">${name}</a>
    <hr>
    <p><strong>Или скопируйте код:</strong></p>
    <textarea style="width:100%;height:200px;font-family:monospace;font-size:12px;background:#0b0e14;color:#c8d0e0;border:1px solid #1e2633;border-radius:4px;padding:8px;">${code}</textarea>
    <br>
    <button onclick="navigator.clipboard.writeText(document.querySelector('textarea').value).then(()=>alert('✅ Скопировано!'))">📋 Копировать</button>
    <button onclick="window.close()">✕ Закрыть</button>
    <style>
        body { font-family: system-ui, sans-serif; background: #0b0e14; color: #c8d0e0; padding: 20px; max-width: 800px; margin: 0 auto; }
        h1 { color: #c8d0e0; }
        a { display: inline-block; padding: 10px 20px; background: #3b82f6; color: white; border-radius: 6px; text-decoration: none; margin: 10px 0; }
        a:hover { background: #2563eb; }
        button { padding: 6px 16px; border: none; border-radius: 6px; cursor: pointer; font-size: 13px; background: #1e2633; color: #c8d0e0; border: 1px solid #2a3444; margin: 4px; }
        button:hover { background: #2a3444; }
        hr { border-color: #1e2633; margin: 16px 0; }
    </style>
</head>
</html>`;

  const blob = new Blob([html], { type: 'text/html; charset=UTF-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `${typeLabel}_Consumer_${new Date().toISOString().slice(0, 10)}.html`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);

  showNotification(`💾 ${typeLabel} букмарклет скачан`, 'success');
  logger.success(`💾 ${typeLabel} букмарклет скачан`);
}

function updateBookmarkletDisplay(type, code) {
  const displayId = type === 'vue' ? 'vueBookmarkletDisplay' : 'reactBookmarkletDisplay';
  const display = document.getElementById(displayId);
  if (display) {
    const truncated = code.length > 150 ? code.substring(0, 150) + '...' : code;
    display.textContent = truncated;
    display.title = code;
  }
}

async function loadBookmarklets() {
  try {
    const vueCode = await vueMinified();
    STATE[PRIVATE.VUE_BOOKMARKLET_CODE] = vueCode;
    STATE[PRIVATE.VUE_LOADED] = true;

    const reactCode = await reactMinified();
    STATE[PRIVATE.REACT_BOOKMARKLET_CODE] = reactCode;
    STATE[PRIVATE.REACT_LOADED] = true;

    const vueEl = document.getElementById('vueBookmarkletCode');
    if (vueEl) {
      vueEl.textContent = vueCode;
      vueEl.className = 'bookmarklet-code bookmarklet-ready';
      updateBookmarkletDisplay('vue', vueCode);
      const newVueEl = vueEl.cloneNode(true);
      vueEl.parentNode.replaceChild(newVueEl, vueEl);
      newVueEl.addEventListener('click', () => copyBookmarkletCode('vue'));
      REFS.vueBookmarkletCode = newVueEl;
    }

    const reactEl = document.getElementById('reactBookmarkletCode');
    if (reactEl) {
      reactEl.textContent = reactCode;
      reactEl.className = 'bookmarklet-code bookmarklet-ready';
      updateBookmarkletDisplay('react', reactCode);
      const newReactEl = reactEl.cloneNode(true);
      reactEl.parentNode.replaceChild(newReactEl, reactEl);
      newReactEl.addEventListener('click', () => copyBookmarkletCode('react'));
      REFS.reactBookmarkletCode = newReactEl;
    }

    logger.success(
      `✅ Букмарклеты загружены: Vue (${vueCode.length} символов), React (${reactCode.length} символов)`
    );
  } catch (error) {
    logger.error('❌ Ошибка загрузки букмарклетов:', error);
    showNotification('❌ Ошибка загрузки букмарклетов', 'error');
  }
}

// ============================================================
// 16. ИНИЦИАЛИЗАЦИЯ
// ============================================================

function init() {
  if (STATE[PRIVATE.INITIALIZED]) {
    logger.warn('⚠️ Index уже инициализирован');
    return;
  }

  logger.header('ИНИЦИАЛИЗАЦИЯ INDEX (100% СИМВОЛЫ)');
  logger.info(`📦 Версия: ${CONFIG.version}`);
  logger.info(`📅 Сборка: ${CONFIG.build}`);
  logger.separator();

  try {
    REFS.loadTime = document.getElementById('loadTimeDisplay');
    REFS.totalItems = document.getElementById('totalItems');
    REFS.streamStatus = document.getElementById('streamStatus');
    REFS.totalBatches = document.getElementById('totalBatches');
    REFS.lastUpdate = document.getElementById('lastUpdate');
    REFS.vueStatus = document.getElementById('vueStatus');
    REFS.reactStatus = document.getElementById('reactStatus');
    REFS.vueConsumer = document.getElementById('vueConsumer');
    REFS.reactConsumer = document.getElementById('reactConsumer');
    REFS.startBtn = document.getElementById('startBtn');
    REFS.stopBtn = document.getElementById('stopBtn');
    REFS.clearBtn = document.getElementById('clearBtn');
    REFS.frequencySlider = document.getElementById('frequencySlider');
    REFS.frequencyLabel = document.getElementById('frequencyLabel');
    REFS.toggleAutoStartBtn = document.getElementById('toggleAutoStartBtn');
    REFS.vueBookmarkletCode = document.getElementById('vueBookmarkletCode');
    REFS.reactBookmarkletCode = document.getElementById('reactBookmarkletCode');
    REFS.vueBookmarkletDisplay = document.getElementById('vueBookmarkletDisplay');
    REFS.reactBookmarkletDisplay = document.getElementById('reactBookmarkletDisplay');
    REFS.reloadBookmarklets = document.getElementById('reloadBookmarklets');
    REFS.createBookmarkBtn = document.getElementById('createBookmarkBtn');
    REFS.createFolderBtn = document.getElementById('createFolderBtn');
    REFS.vueCreateBtn = document.getElementById('vueCreateBtn');
    REFS.vueCopyBtn = document.getElementById('vueCopyBtn');
    REFS.vueDownloadBtn = document.getElementById('vueDownloadBtn');
    REFS.reactCreateBtn = document.getElementById('reactCreateBtn');
    REFS.reactCopyBtn = document.getElementById('reactCopyBtn');
    REFS.reactDownloadBtn = document.getElementById('reactDownloadBtn');

    if (REFS.loadTime) {
      REFS.loadTime.textContent = new Date().toLocaleTimeString();
    }

    setupUI();
    setupKeyboard();
    mountConsumers();
    setupBookmarklets();

    const autoStart = store.getAutoStart();
    if (REFS.toggleAutoStartBtn) {
      REFS.toggleAutoStartBtn.textContent = autoStart ? '🔓 AutoStart: ON' : '🔒 AutoStart: OFF';
    }

    exportSymbols();

    STATE[PRIVATE.INITIALIZED] = true;
    STATE[PRIVATE.LOAD_END] = Date.now();

    const loadTime = STATE[PRIVATE.LOAD_END] - STATE[PRIVATE.LOAD_START];
    logger.success(`✅ Index инициализирован за ${loadTime}ms`);
    logger.header('ГОТОВ');

    updateUI();

    console.log(
      '╔═══════════════════════════════════════════════════════════════════════════════╗'
    );
    console.log('║              📦 INDEX — GLOBAL STORE (100% СИМВОЛЫ) v3.0.8                  ║');
    console.log(
      '╠═══════════════════════════════════════════════════════════════════════════════╣'
    );
    console.log('║  🔧 Исправлена проверка загрузки букмарклетов                               ║');
    console.log('║  📚 Vue Consumer: В закладки | Копировать | Скачать                          ║');
    console.log('║  ⚛️ React Consumer: В закладки | Копировать | Скачать                        ║');
    console.log('║  🔗 API Navigator: /extension/api-navigator.html                            ║');
    console.log('║  🔑 Полная изоляция через приватные символы                                 ║');
    console.log('║  📊 Все данные через глобальное хранилище                                   ║');
    console.log('║  📡 Брокер сообщений с каналами                                             ║');
    console.log(
      '╠═══════════════════════════════════════════════════════════════════════════════╣'
    );
    console.log('║  ⌨️ Горячие клавиши:                                                         ║');
    console.log('║    Ctrl+Enter — Старт                                                       ║');
    console.log('║    Ctrl+Shift+Enter — Стоп                                                  ║');
    console.log('║    Ctrl+Delete — Очистить                                                   ║');
    console.log('║    Ctrl+A — AutoStart                                                       ║');
    console.log('║    Ctrl+R — Обновить букмарклеты                                            ║');
    console.log('║    Ctrl+B — Создать закладку                                                ║');
    console.log('║    Ctrl+F — Создать папку                                                   ║');
    console.log(
      '╚═══════════════════════════════════════════════════════════════════════════════╝'
    );
  } catch (error) {
    logger.error('❌ Ошибка инициализации:', error);
  }
}

// ============================================================
// 17. НАСТРОЙКА UI
// ============================================================

function setupUI() {
  if (REFS.startBtn) {
    REFS.startBtn.addEventListener('click', () => {
      logger.info('🖱️ Нажата кнопка "Старт"');
      startStream();
    });
  }

  if (REFS.stopBtn) {
    REFS.stopBtn.addEventListener('click', () => {
      logger.info('🖱️ Нажата кнопка "Стоп"');
      stopStream();
    });
  }

  if (REFS.clearBtn) {
    REFS.clearBtn.addEventListener('click', () => {
      logger.info('🖱️ Нажата кнопка "Очистить"');
      clearData();
    });
  }

  if (REFS.frequencySlider) {
    REFS.frequencySlider.addEventListener('input', () => {
      const freq = parseInt(REFS.frequencySlider.value);
      if (REFS.frequencyLabel) {
        REFS.frequencyLabel.textContent = freq + ' Гц';
      }
      setFrequency(freq);
    });
  }

  if (REFS.toggleAutoStartBtn) {
    REFS.toggleAutoStartBtn.addEventListener('click', () => {
      const newState = !store.getAutoStart();
      store.setAutoStart(newState);
      REFS.toggleAutoStartBtn.textContent = newState ? '🔓 AutoStart: ON' : '🔒 AutoStart: OFF';
      logger.info(`🔒 AutoStart: ${newState ? 'ВКЛЮЧЕН' : 'ОТКЛЮЧЕН'}`);
    });
  }

  if (REFS.createBookmarkBtn) {
    REFS.createBookmarkBtn.addEventListener('click', async () => {
      const title = prompt('📝 Введите название закладки:', 'Моя закладка');
      if (!title) return;
      const url = prompt('🔗 Введите URL:', 'https://example.com');
      if (!url) return;
      await createBookmark(title, url);
    });
  }

  if (REFS.createFolderBtn) {
    REFS.createFolderBtn.addEventListener('click', async () => {
      const title = prompt('📁 Введите название папки:', 'Моя папка');
      if (!title) return;
      await createFolder(title);
    });
  }

  if (REFS.vueCreateBtn) {
    REFS.vueCreateBtn.addEventListener('click', async () => {
      await createBookmarkletFromCode('vue');
    });
  }

  if (REFS.vueCopyBtn) {
    REFS.vueCopyBtn.addEventListener('click', () => {
      copyBookmarkletCode('vue');
    });
  }

  if (REFS.vueDownloadBtn) {
    REFS.vueDownloadBtn.addEventListener('click', () => {
      downloadBookmarklet('vue');
    });
  }

  if (REFS.reactCreateBtn) {
    REFS.reactCreateBtn.addEventListener('click', async () => {
      await createBookmarkletFromCode('react');
    });
  }

  if (REFS.reactCopyBtn) {
    REFS.reactCopyBtn.addEventListener('click', () => {
      copyBookmarkletCode('react');
    });
  }

  if (REFS.reactDownloadBtn) {
    REFS.reactDownloadBtn.addEventListener('click', () => {
      downloadBookmarklet('react');
    });
  }

  store.subscribe(() => {
    updateUI();
  });

  logger.success('✅ UI настроен');
}

// ============================================================
// 18. МОНТИРОВАНИЕ КОНСЮМЕРОВ
// ============================================================

function mountConsumers() {
  logger.info('🔌 Монтирование консюмеров...');

  if (REFS.vueConsumer) {
    try {
      const consumer = vueConsumerMount(REFS.vueConsumer, {
        theme: 'dark',
        showStats: true,
        store: store,
      });
      if (consumer) {
        window.__vueConsumer = consumer;
        if (REFS.vueStatus) {
          REFS.vueStatus.textContent = 'активен';
          REFS.vueStatus.className = 'status-badge active';
        }
        logger.success('✅ Vue Consumer смонтирован');
      }
    } catch (error) {
      logger.error('❌ Ошибка монтирования Vue:', error);
      if (REFS.vueConsumer) {
        REFS.vueConsumer.innerHTML = `<div class="error-message">❌ Ошибка: ${error.message}</div>`;
      }
    }
  }

  if (REFS.reactConsumer) {
    try {
      const consumer = reactConsumerMount(REFS.reactConsumer, {
        theme: 'dark',
        showStats: true,
        store: store,
      });
      if (consumer) {
        window.__reactConsumer = consumer;
        if (REFS.reactStatus) {
          REFS.reactStatus.textContent = 'активен';
          REFS.reactStatus.className = 'status-badge active';
        }
        logger.success('✅ React Consumer смонтирован');
      }
    } catch (error) {
      logger.error('❌ Ошибка монтирования React:', error);
      if (REFS.reactConsumer) {
        REFS.reactConsumer.innerHTML = `<div class="error-message">❌ Ошибка: ${error.message}</div>`;
      }
    }
  }
}

// ============================================================
// 19. ЗАГРУЗКА БУКМАРКЛЕТОВ
// ============================================================

function setupBookmarklets() {
  logger.info('📌 Загрузка букмарклетов...');

  loadBookmarklets();

  if (REFS.reloadBookmarklets) {
    REFS.reloadBookmarklets.addEventListener('click', async () => {
      logger.info('🔄 Обновление букмарклетов...');
      vueClearCache();
      reactClearCache();
      await loadBookmarklets();
      showNotification('🔄 Букмарклеты обновлены', 'info');
    });
  }

  logger.success('✅ Букмарклеты настроены');
}

// ============================================================
// 20. ГОРЯЧИЕ КЛАВИШИ
// ============================================================

function setupKeyboard() {
  document.addEventListener('keydown', (event) => {
    if (event.ctrlKey && event.key === 'Enter') {
      event.preventDefault();
      logger.info('⌨️ Ctrl+Enter -> Старт');
      startStream();
    }
    if (event.ctrlKey && event.shiftKey && event.key === 'Enter') {
      event.preventDefault();
      logger.info('⌨️ Ctrl+Shift+Enter -> Стоп');
      stopStream();
    }
    if (event.ctrlKey && event.key === 'Delete') {
      event.preventDefault();
      logger.info('⌨️ Ctrl+Delete -> Очистить');
      clearData();
    }
    if (event.ctrlKey && event.key === 'a') {
      event.preventDefault();
      if (REFS.toggleAutoStartBtn) {
        REFS.toggleAutoStartBtn.click();
      }
    }
    if (event.ctrlKey && event.key === 'r') {
      event.preventDefault();
      if (REFS.reloadBookmarklets) {
        REFS.reloadBookmarklets.click();
      }
    }
    if (event.ctrlKey && event.key === 'b') {
      event.preventDefault();
      if (REFS.createBookmarkBtn) {
        REFS.createBookmarkBtn.click();
      }
    }
    if (event.ctrlKey && event.key === 'f') {
      event.preventDefault();
      if (REFS.createFolderBtn) {
        REFS.createFolderBtn.click();
      }
    }
  });

  logger.success('✅ Горячие клавиши настроены');
}

// ============================================================
// 21. ЭКСПОРТ СИМВОЛОВ
// ============================================================

function exportSymbols() {
  if (typeof window !== 'undefined') {
    window.__INDEX_SYMBOLS = {
      PRIVATE: { ...PRIVATE },
      PUBLIC: { ...PUBLIC },
    };

    window[PUBLIC.INSTANCE] = {
      init,
      destroy: () => {
        STATE[PRIVATE.DESTROYED] = true;
      },
      getState: () => ({ ...STATE }),
      healthCheck: store.healthCheck,
      getStore: () => store,
      getGlobalStore: () => globalStore,
    };

    window.__app = {
      start: startStream,
      stop: stopStream,
      clear: clearData,
      setFrequency: setFrequency,
      toggleAutoStart: () => {
        const newState = !store.getAutoStart();
        store.setAutoStart(newState);
        if (REFS.toggleAutoStartBtn) {
          REFS.toggleAutoStartBtn.textContent = newState ? '🔓 AutoStart: ON' : '🔒 AutoStart: OFF';
        }
        return newState;
      },
      getAutoStart: store.getAutoStart,
      getState: store.getState,
      getStore: () => store,
      getGlobalStore: () => globalStore,
      getMessages: store.getMessages,
      sendMessage: store.sendMessage,
      broadcastMessage: store.broadcastMessage,
      getMetrics: store.getMetrics,
      getStatus: store.getStatus,
      subscribe: store.subscribe,
      getConsumers: () => ({
        vue: window.__vueConsumer,
        react: window.__reactConsumer,
      }),
      reloadBookmarklets: () => {
        if (REFS.reloadBookmarklets) {
          REFS.reloadBookmarklets.click();
        }
      },
      createBookmark: createBookmark,
      createFolder: createFolder,
      createBookmarkletFromCode: createBookmarkletFromCode,
      copyBookmarkletCode: copyBookmarkletCode,
      downloadBookmarklet: downloadBookmarklet,
      getBookmarkletCode: getBookmarkletCode,
      generateBookmarkletName: generateBookmarkletName,
      bmRequest: bmRequest,
      showNotification: showNotification,
    };

    window.__globalStore = globalStore;
    window.__store = store;

    window.copyBookmarkletCode = copyBookmarkletCode;
    window.createBookmarkletFromCode = createBookmarkletFromCode;
    window.downloadBookmarklet = downloadBookmarklet;
    window.getBookmarkletCode = getBookmarkletCode;
    window.generateBookmarkletName = generateBookmarkletName;
    window.bmRequest = bmRequest;
    window.showNotification = showNotification;

    logger.success('✅ Символы экспортированы');
  }
}

// ============================================================
// 22. ЗАПУСК
// ============================================================

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}

// ============================================================
// 23. СТАТИСТИКА СИМВОЛОВ
// ============================================================

if (typeof console !== 'undefined') {
  const privateCount = Object.keys(PRIVATE).length;
  const publicCount = Object.keys(PUBLIC).length;

  console.log(`📊 Index: ${privateCount} приватных, ${publicCount} публичных символов`);
  console.log(`📦 Всего символов: ${privateCount + publicCount}`);
  console.log(`📋 Версия: ${CONFIG.version} (${CONFIG.build})`);
}

// ============================================================
// 24. ЭКСПОРТЫ
// ============================================================

export {
  PRIVATE as INDEX_PRIVATE,
  PUBLIC as INDEX_PUBLIC,
  CONFIG as INDEX_CONFIG,
  init,
  startStream,
  stopStream,
  clearData,
  setFrequency,
  store,
  globalStore,
  createBookmark,
  createFolder,
  createBookmarkletFromCode,
  copyBookmarkletCode,
  downloadBookmarklet,
  getBookmarkletCode,
  generateBookmarkletName,
  bmRequest,
  showNotification,
};

export default {
  init,
  startStream,
  stopStream,
  clearData,
  setFrequency,
  store,
  globalStore,
  createBookmark,
  createFolder,
  createBookmarkletFromCode,
  copyBookmarkletCode,
  downloadBookmarklet,
  getBookmarkletCode,
  generateBookmarkletName,
  bmRequest,
  showNotification,
  PRIVATE,
  PUBLIC,
  CONFIG,
};

console.log('✅ Index модуль загружен (100% символы)');
