// src/modules/bookmarklets.js
// Единый модуль для всех букмарклетов и консюмеров
// Версия: 1.0.7 — ИСПРАВЛЕНА РАБОТА С VUE БУКМАРКЛЕТОМ
// 100% СИМВОЛЫ — полная изоляция и безопасность

// ============================================================
// 1. ИМПОРТЫ С УНИКАЛЬНЫМИ ИМЕНАМИ
// ============================================================

import { mountVueConsumer as vueConsumerMount } from '../consumers/vue-consumer.js';
import { mountReactConsumer as reactConsumerMount } from '../consumers/react-consumer.js';
import {
  getVueBookmarkletMinifiedCached as vueMinified,
  clearVueCache as vueClearCache,
} from './vue-bookmarklet.js';
import {
  getReactBookmarkletMinifiedCached as reactMinified,
  clearReactBookmarkletCache as reactClearCache,
} from './react-bookmarklet.js';
import { globalStore as storeInstance, STORE_SYMBOL as storeSymbol } from '../core/store.js';
import { getStreamService } from '../core/stream-service.js';

// ============================================================
// 2. ПРИВАТНЫЕ СИМВОЛЫ (100% изоляция)
// ============================================================

const PRIVATE = {
  VERSION: Symbol('bookmarklets.module.version'),
  BUILD: Symbol('bookmarklets.module.build'),
  NAME: Symbol('bookmarklets.module.name'),
  CONFIG: Symbol('bookmarklets.module.config'),
  STATE: Symbol('bookmarklets.module.state'),
  FREQUENCY: Symbol('bookmarklets.module.frequency'),
  IS_ACTIVE: Symbol('bookmarklets.module.isActive'),
  INTERVAL: Symbol('bookmarklets.module.interval'),
  COUNTER: Symbol('bookmarklets.module.counter'),
  INITIALIZED: Symbol('bookmarklets.module.initialized'),
  DESTROYED: Symbol('bookmarklets.module.destroyed'),
  LOGGER: Symbol('bookmarklets.module.logger'),
  INIT: Symbol('bookmarklets.module.init'),
  DESTROY: Symbol('bookmarklets.module.destroy'),
  GENERATE_DATA: Symbol('bookmarklets.module.generateData'),
  START_STREAM: Symbol('bookmarklets.module.startStream'),
  STOP_STREAM: Symbol('bookmarklets.module.stopStream'),
  CLEAR_DATA: Symbol('bookmarklets.module.clearData'),
  SET_FREQUENCY: Symbol('bookmarklets.module.setFrequency'),
  GET_FREQUENCY: Symbol('bookmarklets.module.getFrequency'),
  IS_STREAM_ACTIVE: Symbol('bookmarklets.module.isStreamActive'),
  GET_AUTO_START: Symbol('bookmarklets.module.getAutoStart'),
  SET_AUTO_START: Symbol('bookmarklets.module.setAutoStart'),
  TOGGLE_AUTO_START: Symbol('bookmarklets.module.toggleAutoStart'),
  GET_STORE: Symbol('bookmarklets.module.getStore'),
  GET_STORE_SYMBOL: Symbol('bookmarklets.module.getStoreSymbol'),
  HEALTH_CHECK: Symbol('bookmarklets.module.healthCheck'),
  GET_STATE: Symbol('bookmarklets.module.getState'),
  GET_METRICS: Symbol('bookmarklets.module.getMetrics'),
  GET_STATUS: Symbol('bookmarklets.module.getStatus'),
  GET_STREAM_STATS: Symbol('bookmarklets.module.getStreamStats'),
  SEND_MESSAGE: Symbol('bookmarklets.module.sendMessage'),
  BROADCAST_MESSAGE: Symbol('bookmarklets.module.broadcastMessage'),
  GET_MESSAGES: Symbol('bookmarklets.module.getMessages'),
  CLEAR_MESSAGES: Symbol('bookmarklets.module.clearMessages'),
  SUBSCRIBE: Symbol('bookmarklets.module.subscribe'),
  EXPORT_SYMBOLS: Symbol('bookmarklets.module.exportSymbols'),
};

// ============================================================
// 3. ПУБЛИЧНЫЕ СИМВОЛЫ (доступны через Symbol.for)
// ============================================================

const PUBLIC = {
  INSTANCE: Symbol.for('bookmarklets.module.instance'),
  STATE: Symbol.for('bookmarklets.module.state'),
  CONFIG: Symbol.for('bookmarklets.module.config'),
  INIT: Symbol.for('bookmarklets.module.init'),
  DESTROY: Symbol.for('bookmarklets.module.destroy'),
  GET_STATE: Symbol.for('bookmarklets.module.getState'),
  GET_STATS: Symbol.for('bookmarklets.module.getStats'),
  MOUNT_VUE: Symbol.for('bookmarklets.module.mountVue'),
  MOUNT_REACT: Symbol.for('bookmarklets.module.mountReact'),
  START: Symbol.for('bookmarklets.module.start'),
  STOP: Symbol.for('bookmarklets.module.stop'),
  CLEAR: Symbol.for('bookmarklets.module.clear'),
  SEND_MESSAGE: Symbol.for('bookmarklets.module.sendMessage'),
  BROADCAST: Symbol.for('bookmarklets.module.broadcast'),
  SUBSCRIBE: Symbol.for('bookmarklets.module.subscribe'),
};

// ============================================================
// 4. КОНФИГУРАЦИЯ
// ============================================================

const CONFIG = {
  version: '1.0.7',
  build: '2026-07-26',
  name: 'Bookmarklets Module',
  debug: true,
  defaultFrequency: 200,
};

// ============================================================
// 5. ЛОГГЕР (100% символы)
// ============================================================

const LOGGER_SYMBOLS = {
  HISTORY: Symbol('logger.history'),
  MAX_HISTORY: Symbol('logger.maxHistory'),
  DEBUG: Symbol('logger.debug'),
  INSTANCE_ID: Symbol('logger.instanceId'),
  LEVEL: Symbol('logger.level'),
};

function createLogger(debug, instanceId) {
  if (debug === undefined) debug = true;
  if (instanceId === undefined) instanceId = 'Bookmarklets';

  const logState = {
    [LOGGER_SYMBOLS.HISTORY]: [],
    [LOGGER_SYMBOLS.MAX_HISTORY]: 200,
    [LOGGER_SYMBOLS.DEBUG]: debug,
    [LOGGER_SYMBOLS.INSTANCE_ID]: instanceId,
    [LOGGER_SYMBOLS.LEVEL]: debug ? 3 : 2,
  };

  const logMethod = function (level, message, data) {
    const levels = { error: 0, warn: 1, info: 2, debug: 3, success: 2 };
    const currentLevel = this[LOGGER_SYMBOLS.LEVEL] || 2;
    const msgLevel = levels[level] || 2;

    if (msgLevel > currentLevel) return;

    const timestamp = new Date().toISOString().slice(11, 23);
    const prefix = '[' + timestamp + '] [' + this[LOGGER_SYMBOLS.INSTANCE_ID] + ']';

    this[LOGGER_SYMBOLS.HISTORY].push({
      timestamp: timestamp,
      level: level,
      message: message,
      data: data || null,
      id: Date.now() + Math.random(),
    });

    if (this[LOGGER_SYMBOLS.HISTORY].length > this[LOGGER_SYMBOLS.MAX_HISTORY]) {
      this[LOGGER_SYMBOLS.HISTORY].shift();
    }

    var icons = { error: '❌', warn: '⚠️', info: 'ℹ️', debug: '🔍', success: '✅' };
    var icon = icons[level] || '📌';

    if (data !== null && data !== undefined) {
      console.log(icon + ' ' + prefix + ' ' + message, data);
    } else {
      console.log(icon + ' ' + prefix + ' ' + message);
    }
  };

  var boundLog = logMethod.bind(logState);

  var methods = {
    error: function (msg, d) {
      return boundLog('error', msg, d);
    },
    warn: function (msg, d) {
      return boundLog('warn', msg, d);
    },
    info: function (msg, d) {
      return boundLog('info', msg, d);
    },
    debug: function (msg, d) {
      return boundLog('debug', msg, d);
    },
    success: function (msg, d) {
      return boundLog('success', msg, d);
    },
    header: function (title, color) {
      if (color === undefined) color = '#636e72';
      var separator = '═'.repeat(70);
      console.log('%c' + separator, 'color: ' + color + ';');
      console.log(
        '%c  📦 ' + title,
        'background: #1a1a2e; color: #fff; padding: 4px 12px; border-radius: 4px; font-weight: bold;'
      );
      console.log('%c' + separator, 'color: ' + color + ';');
    },
    separator: function (color) {
      if (color === undefined) color = '#636e72';
      console.log('%c' + '─'.repeat(70), 'color: ' + color + ';');
    },
    getHistory: function () {
      return [...this[LOGGER_SYMBOLS.HISTORY]];
    },
    clearHistory: function () {
      this[LOGGER_SYMBOLS.HISTORY] = [];
      return this;
    },
    setDebug: function (enabled) {
      this[LOGGER_SYMBOLS.DEBUG] = enabled;
      this[LOGGER_SYMBOLS.LEVEL] = enabled ? 3 : 2;
      return this;
    },
  };

  var logger = {};
  var keys = Object.keys(methods);
  for (var i = 0; i < keys.length; i++) {
    var key = keys[i];
    logger[key] = methods[key].bind(logState);
  }

  logger[LOGGER_SYMBOLS.HISTORY] = logState[LOGGER_SYMBOLS.HISTORY];
  logger[LOGGER_SYMBOLS.MAX_HISTORY] = logState[LOGGER_SYMBOLS.MAX_HISTORY];
  logger[LOGGER_SYMBOLS.DEBUG] = logState[LOGGER_SYMBOLS.DEBUG];
  logger[LOGGER_SYMBOLS.INSTANCE_ID] = logState[LOGGER_SYMBOLS.INSTANCE_ID];
  logger[LOGGER_SYMBOLS.LEVEL] = logState[LOGGER_SYMBOLS.LEVEL];

  return logger;
}

// ============================================================
// 6. СОЗДАНИЕ ЛОГГЕРА
// ============================================================

var logger = createLogger(CONFIG.debug, 'Bookmarklets');

// ============================================================
// 7. СОСТОЯНИЕ МОДУЛЯ
// ============================================================

const MODULE_STATE = {
  [PRIVATE.FREQUENCY]: CONFIG.defaultFrequency,
  [PRIVATE.IS_ACTIVE]: false,
  [PRIVATE.INTERVAL]: null,
  [PRIVATE.COUNTER]: 0,
  [PRIVATE.INITIALIZED]: false,
  [PRIVATE.DESTROYED]: false,
};

// ============================================================
// 8. ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ
// ============================================================

function generateData() {
  var state = MODULE_STATE;
  state[PRIVATE.COUNTER] = state[PRIVATE.COUNTER] + 1;
  return {
    id: state[PRIVATE.COUNTER],
    ts: Date.now(),
    val: Math.round((50 + Math.random() * 80) * 100) / 100,
    trend: Math.sin(state[PRIVATE.COUNTER] / 50) * 20 + 50,
  };
}

// ============================================================
// 9. МОНТИРОВАНИЕ КОНСЮМЕРОВ
// ============================================================

/**
 * Монтирование Vue Consumer
 * @param {HTMLElement|string} element - Элемент или селектор
 * @param {Object} options - Опции монтирования
 * @returns {Object} Объект с методами управления
 */
function mountVueConsumerWrapper(element, options = {}) {
  logger.info('🔌 Монтирование Vue Consumer...');
  try {
    let targetElement = element;
    if (typeof element === 'string') {
      targetElement = document.querySelector(element);
      if (!targetElement) {
        throw new Error('Элемент не найден: ' + element);
      }
    }
    const store = options.store || storeInstance;
    if (!store) {
      throw new Error('Хранилище не найдено');
    }
    const consumer = vueConsumerMount(targetElement, {
      ...options,
      store: store,
    });
    logger.success('✅ Vue Consumer смонтирован');
    return consumer;
  } catch (error) {
    logger.error('❌ Ошибка монтирования Vue Consumer:', error);
    throw error;
  }
}

/**
 * Монтирование React Consumer
 * @param {HTMLElement|string} element - Элемент или селектор
 * @param {Object} options - Опции монтирования
 * @returns {Object} Объект с методами управления
 */
function mountReactConsumerWrapper(element, options = {}) {
  logger.info('🔌 Монтирование React Consumer...');
  try {
    let targetElement = element;
    if (typeof element === 'string') {
      targetElement = document.querySelector(element);
      if (!targetElement) {
        throw new Error('Элемент не найден: ' + element);
      }
    }
    const store = options.store || storeInstance;
    if (!store) {
      throw new Error('Хранилище не найдено');
    }
    const consumer = reactConsumerMount(targetElement, {
      ...options,
      store: store,
    });
    logger.success('✅ React Consumer смонтирован');
    return consumer;
  } catch (error) {
    logger.error('❌ Ошибка монтирования React Consumer:', error);
    throw error;
  }
}

// ============================================================
// 10. БУКМАРКЛЕТЫ
// ============================================================

/**
 * Получить минифицированную версию Vue букмарклета с кэшированием
 */
async function getVueBookmarkletMinifiedCached(options = {}) {
  return await vueMinified(options);
}

/**
 * Получить минифицированную версию React букмарклета с кэшированием
 */
async function getReactBookmarkletMinifiedCached(options = {}) {
  return await reactMinified(options);
}

/**
 * Очистить кэш Vue букмарклета
 */
function clearVueCache() {
  return vueClearCache();
}

/**
 * Очистить кэш React букмарклета
 */
function clearReactCache() {
  return reactClearCache();
}

/**
 * Очистить все кэши букмарклетов
 */
function clearAllCache() {
  vueClearCache();
  reactClearCache();
  logger.success('🧹 Все кэши букмарклетов очищены');
  return true;
}

// ============================================================
// 11. УПРАВЛЕНИЕ СТРИМОМ
// ============================================================

/**
 * Запустить стриминг данных
 */
function startStream() {
  logger.info('▶️ startStream() вызван');

  var state = MODULE_STATE;
  if (state[PRIVATE.IS_ACTIVE]) {
    logger.warn('⚠️ Стриминг уже активен');
    return false;
  }

  var service = getStreamService();
  if (!service) {
    logger.error('❌ Стрим-сервис не доступен');
    return false;
  }

  var source = {
    emit: function (item) {
      service.emit(item);
    },
  };

  var started = service.start(source);
  if (!started) {
    logger.error('❌ Не удалось запустить стриминг');
    return false;
  }

  state[PRIVATE.IS_ACTIVE] = true;
  storeInstance.setStatus('playing');

  var intervalMs = 1000 / state[PRIVATE.FREQUENCY];
  state[PRIVATE.INTERVAL] = setInterval(function () {
    if (!state[PRIVATE.IS_ACTIVE]) return;
    var count = 1 + Math.floor(Math.random() * 2);
    for (var i = 0; i < count; i++) {
      var data = generateData();
      service.emit(data);
    }
  }, intervalMs);

  logger.success('✅ Стриминг запущен, частота: ' + state[PRIVATE.FREQUENCY] + ' Гц');
  return true;
}

/**
 * Остановить стриминг данных
 */
function stopStream() {
  logger.info('⏹️ stopStream() вызван');

  var state = MODULE_STATE;
  state[PRIVATE.IS_ACTIVE] = false;
  if (state[PRIVATE.INTERVAL]) {
    clearInterval(state[PRIVATE.INTERVAL]);
    state[PRIVATE.INTERVAL] = null;
  }

  var service = getStreamService();
  if (service) {
    service.stop();
  }

  storeInstance.setStatus('disconnected');
  logger.success('✅ Стриминг остановлен');
  return true;
}

/**
 * Очистить данные
 */
function clearData() {
  logger.info('🗑️ clearData() вызван');
  storeInstance.clearStore();
  MODULE_STATE[PRIVATE.COUNTER] = 0;
  logger.success('✅ Данные очищены');
  return true;
}

/**
 * Установить частоту стриминга
 */
function setFrequency(frequency) {
  var state = MODULE_STATE;
  if (typeof frequency === 'number' && frequency > 0) {
    state[PRIVATE.FREQUENCY] = frequency;
    logger.info('🔄 Частота установлена: ' + frequency + ' Гц');

    if (state[PRIVATE.IS_ACTIVE]) {
      logger.info('🔄 Перезапуск стрима с новой частотой...');
      stopStream();
      setTimeout(function () {
        startStream();
      }, 50);
    }
    return true;
  }
  logger.warn('⚠️ Некорректная частота: ' + frequency);
  return false;
}

/**
 * Получить текущую частоту
 */
function getFrequency() {
  return MODULE_STATE[PRIVATE.FREQUENCY];
}

/**
 * Проверить, активен ли стриминг
 */
function isStreamActive() {
  return MODULE_STATE[PRIVATE.IS_ACTIVE];
}

// ============================================================
// 12. УПРАВЛЕНИЕ AUTO_START
// ============================================================

function getAutoStart() {
  if (storeInstance && typeof storeInstance.getAutoStart === 'function') {
    return storeInstance.getAutoStart();
  }
  return false;
}

function setAutoStart(value) {
  if (storeInstance && typeof storeInstance.setAutoStart === 'function') {
    var result = storeInstance.setAutoStart(value);
    logger.info('🔒 AutoStart установлен: ' + (result ? 'ВКЛЮЧЕН' : 'ОТКЛЮЧЕН'));
    return result;
  }
  return false;
}

function toggleAutoStart() {
  var current = getAutoStart();
  var newValue = !current;
  setAutoStart(newValue);
  return newValue;
}

// ============================================================
// 13. ДОСТУП К ХРАНИЛИЩУ
// ============================================================

function getStore() {
  return storeInstance;
}

function getStoreSymbol() {
  return storeSymbol;
}

function healthCheck() {
  if (storeInstance && typeof storeInstance.healthCheck === 'function') {
    return storeInstance.healthCheck();
  }
  return null;
}

// ============================================================
// 14. СОСТОЯНИЕ И СТАТИСТИКА
// ============================================================

function getState() {
  if (storeInstance && typeof storeInstance.getState === 'function') {
    return storeInstance.getState();
  }
  return null;
}

function getMetrics() {
  if (storeInstance && typeof storeInstance.getMetrics === 'function') {
    return storeInstance.getMetrics();
  }
  return [];
}

function getStatus() {
  if (storeInstance && typeof storeInstance.getStatus === 'function') {
    return storeInstance.getStatus();
  }
  return 'unknown';
}

function getStreamStats() {
  var service = getStreamService();
  if (service && typeof service.getStats === 'function') {
    return service.getStats();
  }
  return null;
}

// ============================================================
// 15. СООБЩЕНИЯ
// ============================================================

function sendMessage(message) {
  if (storeInstance && typeof storeInstance.sendMessage === 'function') {
    return storeInstance.sendMessage(message);
  }
  return false;
}

function broadcastMessage(message) {
  if (storeInstance && typeof storeInstance.broadcastMessage === 'function') {
    return storeInstance.broadcastMessage(message);
  }
  return false;
}

function getMessages(limit) {
  if (storeInstance && typeof storeInstance.getMessages === 'function') {
    return storeInstance.getMessages(limit || 50);
  }
  return [];
}

function clearMessages() {
  if (storeInstance && typeof storeInstance.clearMessages === 'function') {
    return storeInstance.clearMessages();
  }
  return false;
}

// ============================================================
// 16. ПОДПИСКА
// ============================================================

function subscribe(callback) {
  if (storeInstance && typeof storeInstance.subscribe === 'function') {
    return storeInstance.subscribe(callback);
  }
  return null;
}

// ============================================================
// 17. ИНИЦИАЛИЗАЦИЯ
// ============================================================

function init() {
  var state = MODULE_STATE;

  if (state[PRIVATE.INITIALIZED]) {
    logger.warn('⚠️ Модуль уже инициализирован');
    return;
  }

  logger.header('ИНИЦИАЛИЗАЦИЯ BOOKMARKLETS MODULE (100% СИМВОЛЫ)');
  logger.info('📦 Версия: ' + CONFIG.version);
  logger.info('📅 Сборка: ' + CONFIG.build);
  logger.separator();

  state[PRIVATE.INITIALIZED] = true;
  state[PRIVATE.DESTROYED] = false;

  if (storeInstance) {
    logger.success('✅ Хранилище доступно');
    var health = healthCheck();
    if (health) {
      logger.info('  📊 Версия: ' + health.version);
      logger.info('  📈 Метрик: ' + health.metricsCount);
      logger.info('  📡 Статус: ' + health.status);
    }
  } else {
    logger.warn('⚠️ Хранилище не доступно');
  }

  var autoStart = getAutoStart();
  logger.info('🔒 AutoStart: ' + (autoStart ? 'ВКЛЮЧЕН' : 'ОТКЛЮЧЕН'));

  // Экспорт символов
  if (typeof window !== 'undefined') {
    window.__BOOKMARKLETS_SYMBOLS = {
      PRIVATE: { ...PRIVATE },
      PUBLIC: { ...PUBLIC },
    };
    window[PUBLIC.INSTANCE] = {
      mountVueConsumer: mountVueConsumerWrapper,
      mountReactConsumer: mountReactConsumerWrapper,
      getVueBookmarkletMinifiedCached,
      getReactBookmarkletMinifiedCached,
      clearVueCache,
      clearReactCache,
      clearAllCache,
      startStream,
      stopStream,
      clearData,
      setFrequency,
      getFrequency,
      isStreamActive,
      getAutoStart,
      setAutoStart,
      toggleAutoStart,
      getStore,
      getStoreSymbol,
      healthCheck,
      getState,
      getMetrics,
      getStatus,
      getStreamStats,
      sendMessage,
      broadcastMessage,
      getMessages,
      clearMessages,
      subscribe,
      init,
      destroy,
    };
  }

  logger.success('✅ Bookmarklets Module инициализирован');
  logger.header('ГОТОВ');

  return true;
}

// ============================================================
// 18. УНИЧТОЖЕНИЕ
// ============================================================

function destroy() {
  var state = MODULE_STATE;

  if (state[PRIVATE.DESTROYED]) {
    logger.warn('⚠️ Модуль уже уничтожен');
    return;
  }

  logger.info('🧹 Уничтожение Bookmarklets Module...');

  if (state[PRIVATE.IS_ACTIVE]) {
    stopStream();
  }

  state[PRIVATE.DESTROYED] = true;
  state[PRIVATE.INITIALIZED] = false;
  state[PRIVATE.COUNTER] = 0;

  if (typeof window !== 'undefined') {
    delete window.__BOOKMARKLETS_SYMBOLS;
    delete window[PUBLIC.INSTANCE];
    delete window.__bookmarklets;
  }

  logger.success('✅ Bookmarklets Module уничтожен');
}

// ============================================================
// 19. ЭКСПОРТЫ (100% СИМВОЛЫ)
// ============================================================

// Основные экспорты
export {
  // Монтирование консюмеров
  mountVueConsumerWrapper as mountVueConsumer,
  mountReactConsumerWrapper as mountReactConsumer,

  // Букмарклеты
  getVueBookmarkletMinifiedCached,
  getReactBookmarkletMinifiedCached,
  clearVueCache,
  clearReactCache,
  clearAllCache,

  // Управление стримом
  startStream,
  stopStream,
  clearData,
  setFrequency,
  getFrequency,
  isStreamActive,

  // AutoStart
  getAutoStart,
  setAutoStart,
  toggleAutoStart,

  // Хранилище
  getStore,
  getStoreSymbol,
  healthCheck,

  // Состояние
  getState,
  getMetrics,
  getStatus,
  getStreamStats,

  // Сообщения
  sendMessage,
  broadcastMessage,
  getMessages,
  clearMessages,

  // Подписка
  subscribe,

  // Жизненный цикл
  init,
  destroy,
};

// Экспорт символов
export {
  PRIVATE as BOOKMARKLETS_PRIVATE,
  PUBLIC as BOOKMARKLETS_PUBLIC,
  CONFIG as BOOKMARKLETS_CONFIG,
};

// ============================================================
// 20. ЭКСПОРТ ПО УМОЛЧАНИЮ
// ============================================================

export default {
  // Монтирование консюмеров
  mountVueConsumer: mountVueConsumerWrapper,
  mountReactConsumer: mountReactConsumerWrapper,

  // Букмарклеты
  getVueBookmarkletMinifiedCached,
  getReactBookmarkletMinifiedCached,
  clearVueCache,
  clearReactCache,
  clearAllCache,

  // Управление стримом
  startStream,
  stopStream,
  clearData,
  setFrequency,
  getFrequency,
  isStreamActive,

  // AutoStart
  getAutoStart,
  setAutoStart,
  toggleAutoStart,

  // Хранилище
  getStore,
  getStoreSymbol,
  healthCheck,

  // Состояние
  getState,
  getMetrics,
  getStatus,
  getStreamStats,

  // Сообщения
  sendMessage,
  broadcastMessage,
  getMessages,
  clearMessages,

  // Подписка
  subscribe,

  // Жизненный цикл
  init,
  destroy,

  // Символы
  PRIVATE,
  PUBLIC,
  CONFIG,
};

// ============================================================
// 21. ГЛОБАЛЬНАЯ РЕГИСТРАЦИЯ
// ============================================================

if (typeof window !== 'undefined') {
  // Регистрируем глобальный объект
  window.__bookmarklets = {
    mountVueConsumer: mountVueConsumerWrapper,
    mountReactConsumer: mountReactConsumerWrapper,
    getVueBookmarkletMinifiedCached,
    getReactBookmarkletMinifiedCached,
    clearVueCache,
    clearReactCache,
    clearAllCache,
    startStream,
    stopStream,
    clearData,
    setFrequency,
    getFrequency,
    isStreamActive,
    getAutoStart,
    setAutoStart,
    toggleAutoStart,
    getStore,
    getStoreSymbol,
    healthCheck,
    getState,
    getMetrics,
    getStatus,
    getStreamStats,
    sendMessage,
    broadcastMessage,
    getMessages,
    clearMessages,
    subscribe,
    init,
    destroy,
    getSymbols: function () {
      return {
        PRIVATE: { ...PRIVATE },
        PUBLIC: { ...PUBLIC },
      };
    },
    getConfig: function () {
      return { ...CONFIG };
    },
  };

  // Добавляем отладочную информацию
  window.__BOOKMARKLETS_CONFIG = { ...CONFIG };
  window.__BOOKMARKLETS_SYMBOLS = {
    PRIVATE: { ...PRIVATE },
    PUBLIC: { ...PUBLIC },
  };

  // Инициализация
  init();

  console.log('✅ Bookmarklets Module: Глобальная регистрация выполнена');
  console.log('📋 ДОСТУПНЫЕ КОМАНДЫ:');
  console.log('  window.__bookmarklets.mountVueConsumer() - монтирование Vue Consumer');
  console.log('  window.__bookmarklets.mountReactConsumer() - монтирование React Consumer');
  console.log(
    '  window.__bookmarklets.getVueBookmarkletMinifiedCached() - получить Vue букмарклет'
  );
  console.log(
    '  window.__bookmarklets.getReactBookmarkletMinifiedCached() - получить React букмарклет'
  );
  console.log('  window.__bookmarklets.startStream() - запустить стриминг');
  console.log('  window.__bookmarklets.stopStream() - остановить стриминг');
  console.log('  window.__bookmarklets.clearData() - очистить данные');
  console.log('  window.__bookmarklets.setFrequency(freq) - установить частоту');
  console.log('  window.__bookmarklets.toggleAutoStart() - переключить AutoStart');
  console.log('  window.__bookmarklets.getAutoStart() - получить AutoStart');
  console.log('  window.__bookmarklets.getStore() - получить хранилище');
  console.log('  window.__bookmarklets.getState() - получить состояние');
  console.log('  window.__bookmarklets.sendMessage(msg) - отправить сообщение');
  console.log('  window.__bookmarklets.broadcastMessage(msg) - широковещательное сообщение');
  console.log('  window.__bookmarklets.getMessages(limit) - получить сообщения');
  console.log('  window.__bookmarklets.subscribe(callback) - подписаться');
  console.log('  window.__bookmarklets.init() - инициализация');
  console.log('  window.__bookmarklets.destroy() - уничтожение');
}

// ============================================================
// 22. СТАТИСТИКА СИМВОЛОВ
// ============================================================

if (typeof console !== 'undefined') {
  var privateCount = Object.keys(PRIVATE).length;
  var publicCount = Object.keys(PUBLIC).length;

  console.log(
    '📊 Bookmarklets Module: ' + privateCount + ' приватных, ' + publicCount + ' публичных символов'
  );
  console.log('📦 Всего символов: ' + (privateCount + publicCount));
  console.log('📋 Версия: ' + CONFIG.version + ' (' + CONFIG.build + ')');
}

// ============================================================
// 23. ОБРАБОТЧИКИ ДЛЯ ОТЛАДКИ
// ============================================================

if (typeof window !== 'undefined' && CONFIG.debug) {
  window.__debugBookmarklets = {
    getState: () => ({
      initialized: MODULE_STATE[PRIVATE.INITIALIZED],
      destroyed: MODULE_STATE[PRIVATE.DESTROYED],
      isActive: MODULE_STATE[PRIVATE.IS_ACTIVE],
      frequency: MODULE_STATE[PRIVATE.FREQUENCY],
      counter: MODULE_STATE[PRIVATE.COUNTER],
    }),
    getSymbols: () => ({
      PRIVATE: { ...PRIVATE },
      PUBLIC: { ...PUBLIC },
    }),
    getConfig: () => ({ ...CONFIG }),
    healthCheck: healthCheck,
    getStore: getStore,
  };

  console.log('📋 КОМАНДЫ ОТЛАДКИ (__debugBookmarklets):');
  console.log('  __debugBookmarklets.getState() - состояние модуля');
  console.log('  __debugBookmarklets.getSymbols() - получить символы');
  console.log('  __debugBookmarklets.getConfig() - получить конфигурацию');
  console.log('  __debugBookmarklets.healthCheck() - проверка хранилища');
  console.log('  __debugBookmarklets.getStore() - получить хранилище');
}
