// src/modules/vue-bookmarklet.js
// 100% СИМВОЛЫ — полная изоляция и безопасность
// Версия: 4.3.0 — Полная синхронизация с react-bookmarklet.js
// Единый API для Vue

// ============================================================
// 1. ИМПОРТЫ
// ============================================================

import { mountVueConsumer } from '../consumers/vue-consumer.js';
import { globalStore, STORE_SYMBOL } from '../core/store.js';
import { getStreamService } from '../core/stream-service.js';
import { minifyBookmarkletCode } from '../utils/minify.js';

// ============================================================
// 2. ПРИВАТНЫЕ СИМВОЛЫ (100% изоляция)
// ============================================================

const PRIVATE = {
  VERSION: Symbol('vue.module.version'),
  BUILD: Symbol('vue.module.build'),
  NAME: Symbol('vue.module.name'),
  CONFIG: Symbol('vue.module.config'),
  STATE: Symbol('vue.module.state'),
  FREQUENCY: Symbol('vue.module.frequency'),
  IS_ACTIVE: Symbol('vue.module.isActive'),
  INTERVAL: Symbol('vue.module.interval'),
  COUNTER: Symbol('vue.module.counter'),
  LOGGER: Symbol('vue.module.logger'),
  INIT: Symbol('vue.module.init'),
  DESTROY: Symbol('vue.module.destroy'),
  GENERATE_DATA: Symbol('vue.module.generateData'),
  START_STREAM: Symbol('vue.module.startStream'),
  STOP_STREAM: Symbol('vue.module.stopStream'),
  CLEAR_DATA: Symbol('vue.module.clearData'),
  SET_FREQUENCY: Symbol('vue.module.setFrequency'),
  GET_FREQUENCY: Symbol('vue.module.getFrequency'),
  IS_STREAM_ACTIVE: Symbol('vue.module.isStreamActive'),
  GET_AUTO_START: Symbol('vue.module.getAutoStart'),
  SET_AUTO_START: Symbol('vue.module.setAutoStart'),
  TOGGLE_AUTO_START: Symbol('vue.module.toggleAutoStart'),
  GET_STORE: Symbol('vue.module.getStore'),
  GET_STORE_SYMBOL: Symbol('vue.module.getStoreSymbol'),
  HEALTH_CHECK: Symbol('vue.module.healthCheck'),
  GET_STATE: Symbol('vue.module.getState'),
  GET_METRICS: Symbol('vue.module.getMetrics'),
  GET_STATUS: Symbol('vue.module.getStatus'),
  GET_STREAM_STATS: Symbol('vue.module.getStreamStats'),
  SEND_MESSAGE: Symbol('vue.module.sendMessage'),
  BROADCAST_MESSAGE: Symbol('vue.module.broadcastMessage'),
  GET_MESSAGES: Symbol('vue.module.getMessages'),
  CLEAR_MESSAGES: Symbol('vue.module.clearMessages'),
  SUBSCRIBE: Symbol('vue.module.subscribe'),
  EXPORT_SYMBOLS: Symbol('vue.module.exportSymbols'),
  UPDATE_UI: Symbol('vue.module.updateUI'),
  CACHE: Symbol('vue.module.cache'),
  GET_BOOKMARKLET_CODE: Symbol('vue.module.getBookmarkletCode'),
  GET_MINIFIED: Symbol('vue.module.getMinified'),
  GET_MINIFIED_CACHED: Symbol('vue.module.getMinifiedCached'),
  CLEAR_CACHE: Symbol('vue.module.clearCache'),
  GET_STATS: Symbol('vue.module.getStats'),
  RESET_STATS: Symbol('vue.module.resetStats'),
  FETCH_CACHE: Symbol('vue.module.fetchCache'),
  FETCH_PROMISE: Symbol('vue.module.fetchPromise'),
  MINIFY_CACHE: Symbol('vue.module.minifyCache'),
  IS_MINIFYING: Symbol('vue.module.isMinifying'),
  MINIFY_PROMISE: Symbol('vue.module.minifyPromise'),
  MINIFY_STATS: Symbol('vue.module.minifyStats'),
};

// ============================================================
// 3. ПУБЛИЧНЫЕ СИМВОЛЫ (доступны через Symbol.for)
// ============================================================

const PUBLIC = {
  INSTANCE: Symbol.for('vue.module.instance'),
  STATE: Symbol.for('vue.module.state'),
  CONFIG: Symbol.for('vue.module.config'),
  MOUNT: Symbol.for('vue.module.mount'),
  GET_BOOKMARKLET: Symbol.for('vue.module.getBookmarklet'),
  START: Symbol.for('vue.module.start'),
  STOP: Symbol.for('vue.module.stop'),
  CLEAR: Symbol.for('vue.module.clear'),
  GET_STATE: Symbol.for('vue.module.getState'),
  GET_STORE: Symbol.for('vue.module.getStore'),
  SEND_MESSAGE: Symbol.for('vue.module.sendMessage'),
  BROADCAST: Symbol.for('vue.module.broadcast'),
  SUBSCRIBE: Symbol.for('vue.module.subscribe'),
};

// ============================================================
// 4. КОНФИГУРАЦИЯ
// ============================================================

const CONFIG = {
  version: '4.3.0',
  build: '2026-07-26',
  name: 'Vue Bookmarklet Module',
  debug: true,
  defaultFrequency: 200,
};

// ============================================================
// 5. ЛОГГЕР (100% символы)
// ============================================================

const LOGGER_SYMBOLS = {
  HISTORY: Symbol('logger.history'),
  MAX_HISTORY: Symbol('logger.maxHistory'),
  DEBUG: Symbol('logger.debug'),
  INSTANCE_ID: Symbol('logger.instanceId'),
  LEVEL: Symbol('logger.level'),
};

function createLogger(debug, instanceId) {
  if (debug === undefined) debug = true;
  if (instanceId === undefined) instanceId = 'VueModule';

  const logState = {
    [LOGGER_SYMBOLS.HISTORY]: [],
    [LOGGER_SYMBOLS.MAX_HISTORY]: 200,
    [LOGGER_SYMBOLS.DEBUG]: debug,
    [LOGGER_SYMBOLS.INSTANCE_ID]: instanceId,
    [LOGGER_SYMBOLS.LEVEL]: debug ? 3 : 2,
  };

  const logMethod = function (level, message, data) {
    const levels = { error: 0, warn: 1, info: 2, debug: 3, success: 2 };
    const currentLevel = this[LOGGER_SYMBOLS.LEVEL] || 2;
    const msgLevel = levels[level] || 2;

    if (msgLevel > currentLevel) return;

    const timestamp = new Date().toISOString().slice(11, 23);
    const prefix = '[' + timestamp + '] [' + this[LOGGER_SYMBOLS.INSTANCE_ID] + ']';

    this[LOGGER_SYMBOLS.HISTORY].push({
      timestamp: timestamp,
      level: level,
      message: message,
      data: data || null,
      id: Date.now() + Math.random(),
    });

    if (this[LOGGER_SYMBOLS.HISTORY].length > this[LOGGER_SYMBOLS.MAX_HISTORY]) {
      this[LOGGER_SYMBOLS.HISTORY].shift();
    }

    var icons = { error: '❌', warn: '⚠️', info: 'ℹ️', debug: '🔍', success: '✅' };
    var icon = icons[level] || '📌';

    if (data !== null && data !== undefined) {
      console.log(icon + ' ' + prefix + ' ' + message, data);
    } else {
      console.log(icon + ' ' + prefix + ' ' + message);
    }
  };

  var boundLog = logMethod.bind(logState);

  var methods = {
    error: function (msg, d) {
      return boundLog('error', msg, d);
    },
    warn: function (msg, d) {
      return boundLog('warn', msg, d);
    },
    info: function (msg, d) {
      return boundLog('info', msg, d);
    },
    debug: function (msg, d) {
      return boundLog('debug', msg, d);
    },
    success: function (msg, d) {
      return boundLog('success', msg, d);
    },
    header: function (title, color) {
      if (color === undefined) color = '#636e72';
      var separator = '═'.repeat(70);
      console.log('%c' + separator, 'color: ' + color + ';');
      console.log(
        '%c  📦 ' + title,
        'background: #1a1a2e; color: #fff; padding: 4px 12px; border-radius: 4px; font-weight: bold;'
      );
      console.log('%c' + separator, 'color: ' + color + ';');
    },
    separator: function (color) {
      if (color === undefined) color = '#636e72';
      console.log('%c' + '─'.repeat(70), 'color: ' + color + ';');
    },
    getHistory: function () {
      return [...this[LOGGER_SYMBOLS.HISTORY]];
    },
    clearHistory: function () {
      this[LOGGER_SYMBOLS.HISTORY] = [];
      return this;
    },
    setDebug: function (enabled) {
      this[LOGGER_SYMBOLS.DEBUG] = enabled;
      this[LOGGER_SYMBOLS.LEVEL] = enabled ? 3 : 2;
      return this;
    },
  };

  var logger = {};
  var keys = Object.keys(methods);
  for (var i = 0; i < keys.length; i++) {
    var key = keys[i];
    logger[key] = methods[key].bind(logState);
  }

  logger[LOGGER_SYMBOLS.HISTORY] = logState[LOGGER_SYMBOLS.HISTORY];
  logger[LOGGER_SYMBOLS.MAX_HISTORY] = logState[LOGGER_SYMBOLS.MAX_HISTORY];
  logger[LOGGER_SYMBOLS.DEBUG] = logState[LOGGER_SYMBOLS.DEBUG];
  logger[LOGGER_SYMBOLS.INSTANCE_ID] = logState[LOGGER_SYMBOLS.INSTANCE_ID];
  logger[LOGGER_SYMBOLS.LEVEL] = logState[LOGGER_SYMBOLS.LEVEL];

  return logger;
}

// ============================================================
// 6. СОЗДАНИЕ ЛОГГЕРА
// ============================================================

var logger = createLogger(CONFIG.debug, 'VueModule');

// ============================================================
// 7. СОСТОЯНИЕ МОДУЛЯ
// ============================================================

const MODULE_STATE = {
  [PRIVATE.FREQUENCY]: CONFIG.defaultFrequency,
  [PRIVATE.IS_ACTIVE]: false,
  [PRIVATE.INTERVAL]: null,
  [PRIVATE.COUNTER]: 0,
  [PRIVATE.INITIALIZED]: false,
  [PRIVATE.DESTROYED]: false,
  [PRIVATE.CACHE]: null,
  [PRIVATE.FETCH_CACHE]: null,
  [PRIVATE.FETCH_PROMISE]: null,
  [PRIVATE.MINIFY_CACHE]: null,
  [PRIVATE.IS_MINIFYING]: false,
  [PRIVATE.MINIFY_PROMISE]: null,
  [PRIVATE.MINIFY_STATS]: {
    calls: 0,
    cacheHits: 0,
    fallbackCalls: 0,
    lastMinifyTime: null,
    totalMinifyTime: 0,
  },
};

// ============================================================
// 8. ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ
// ============================================================

function getBaseUrl() {
  return window.location.origin + window.location.pathname.replace(/[^/]*$/, '');
}

function validateCode(code) {
  if (typeof code !== 'string') return false;
  if (code.length === 0) return false;
  if (code.length > 10 * 1024 * 1024) return false;
  return true;
}

function generateData() {
  var state = MODULE_STATE;
  state[PRIVATE.COUNTER] = state[PRIVATE.COUNTER] + 1;
  return {
    id: state[PRIVATE.COUNTER],
    ts: Date.now(),
    val: Math.round((50 + Math.random() * 80) * 100) / 100,
    trend: Math.sin(state[PRIVATE.COUNTER] / 50) * 20 + 50,
  };
}

// ============================================================
// 9. ФУНКЦИИ УПРАВЛЕНИЯ СТРИМОМ
// ============================================================

function startStream() {
  var logger = createLogger(CONFIG.debug, 'VueModule');
  var state = MODULE_STATE;

  logger.info('▶️ startStream() вызван');

  if (state[PRIVATE.IS_ACTIVE]) {
    logger.warn('⚠️ Стриминг уже активен');
    return false;
  }

  var service = getStreamService();
  if (!service) {
    logger.error('❌ Стрим-сервис не доступен');
    return false;
  }

  var source = {
    emit: function (item) {
      service.emit(item);
    },
  };

  var started = service.start(source);
  if (!started) {
    logger.error('❌ Не удалось запустить стриминг');
    return false;
  }

  state[PRIVATE.IS_ACTIVE] = true;
  globalStore.setStatus('playing');

  var intervalMs = 1000 / state[PRIVATE.FREQUENCY];
  state[PRIVATE.INTERVAL] = setInterval(function () {
    if (!state[PRIVATE.IS_ACTIVE]) return;
    var count = 1 + Math.floor(Math.random() * 2);
    for (var i = 0; i < count; i++) {
      var data = generateData();
      service.emit(data);
    }
  }, intervalMs);

  logger.success('✅ Стриминг запущен, частота: ' + state[PRIVATE.FREQUENCY] + ' Гц');
  return true;
}

function stopStream() {
  var logger = createLogger(CONFIG.debug, 'VueModule');
  var state = MODULE_STATE;

  logger.info('⏹️ stopStream() вызван');

  state[PRIVATE.IS_ACTIVE] = false;
  if (state[PRIVATE.INTERVAL]) {
    clearInterval(state[PRIVATE.INTERVAL]);
    state[PRIVATE.INTERVAL] = null;
  }

  var service = getStreamService();
  if (service) {
    service.stop();
  }

  globalStore.setStatus('disconnected');
  logger.success('✅ Стриминг остановлен');
  return true;
}

function clearData() {
  var logger = createLogger(CONFIG.debug, 'VueModule');
  var state = MODULE_STATE;

  logger.info('🗑️ clearData() вызван');
  globalStore.clearStore();
  state[PRIVATE.COUNTER] = 0;
  logger.success('✅ Данные очищены');
  return true;
}

function setFrequency(frequency) {
  var logger = createLogger(CONFIG.debug, 'VueModule');
  var state = MODULE_STATE;

  if (typeof frequency === 'number' && frequency > 0) {
    state[PRIVATE.FREQUENCY] = frequency;
    logger.info('🔄 Частота установлена: ' + frequency + ' Гц');

    if (state[PRIVATE.IS_ACTIVE]) {
      logger.info('🔄 Перезапуск стрима с новой частотой...');
      stopStream();
      setTimeout(function () {
        startStream();
      }, 50);
    }
    return true;
  }
  logger.warn('⚠️ Некорректная частота: ' + frequency);
  return false;
}

function getFrequency() {
  return MODULE_STATE[PRIVATE.FREQUENCY];
}

function isStreamActive() {
  return MODULE_STATE[PRIVATE.IS_ACTIVE];
}

// ============================================================
// 10. ФУНКЦИИ AUTO_START
// ============================================================

function getAutoStart() {
  if (globalStore && typeof globalStore.getAutoStart === 'function') {
    return globalStore.getAutoStart();
  }
  return false;
}

function setAutoStart(value) {
  if (globalStore && typeof globalStore.setAutoStart === 'function') {
    var result = globalStore.setAutoStart(value);
    var logger = createLogger(CONFIG.debug, 'VueModule');
    logger.info('🔒 AutoStart установлен: ' + (result ? 'ВКЛЮЧЕН' : 'ОТКЛЮЧЕН'));
    return result;
  }
  return false;
}

function toggleAutoStart() {
  var current = getAutoStart();
  var newValue = !current;
  setAutoStart(newValue);
  return newValue;
}

// ============================================================
// 11. ФУНКЦИИ ДОСТУПА К ХРАНИЛИЩУ
// ============================================================

function getStore() {
  return globalStore;
}

function getStoreSymbol() {
  return STORE_SYMBOL;
}

function healthCheck() {
  if (globalStore && typeof globalStore.healthCheck === 'function') {
    return globalStore.healthCheck();
  }
  return null;
}

function getState() {
  if (globalStore && typeof globalStore.getState === 'function') {
    return globalStore.getState();
  }
  return null;
}

function getMetrics() {
  if (globalStore && typeof globalStore.getMetrics === 'function') {
    return globalStore.getMetrics();
  }
  return [];
}

function getStatus() {
  if (globalStore && typeof globalStore.getStatus === 'function') {
    return globalStore.getStatus();
  }
  return 'unknown';
}

function getStreamStats() {
  var service = getStreamService();
  if (service && typeof service.getStats === 'function') {
    return service.getStats();
  }
  return null;
}

// ============================================================
// 12. ФУНКЦИИ СООБЩЕНИЙ
// ============================================================

function sendMessage(message) {
  if (globalStore && typeof globalStore.sendMessage === 'function') {
    return globalStore.sendMessage(message);
  }
  return false;
}

function broadcastMessage(message) {
  if (globalStore && typeof globalStore.broadcastMessage === 'function') {
    return globalStore.broadcastMessage(message);
  }
  return false;
}

function getMessages(limit) {
  if (globalStore && typeof globalStore.getMessages === 'function') {
    return globalStore.getMessages(limit || 50);
  }
  return [];
}

function clearMessages() {
  if (globalStore && typeof globalStore.clearMessages === 'function') {
    return globalStore.clearMessages();
  }
  return false;
}

function subscribe(callback) {
  if (globalStore && typeof globalStore.subscribe === 'function') {
    return globalStore.subscribe(callback);
  }
  return null;
}

// ============================================================
// 13. БУКМАРКЛЕТЫ (ПОЛНОСТЬЮ КАК В REACT)
// ============================================================

/**
 * Получить код Vue букмарклета через fetch
 */
async function getVueBookmarkletCode() {
  logger.debug('📥 Получение кода Vue букмарклета...');
  try {
    const baseUrl = getBaseUrl();
    const url = baseUrl + '/src/bookmarklets/vue-bookmarklet.js';

    if (MODULE_STATE[PRIVATE.FETCH_CACHE]) {
      logger.debug('📦 Код получен из кэша');
      return MODULE_STATE[PRIVATE.FETCH_CACHE];
    }

    if (MODULE_STATE[PRIVATE.FETCH_PROMISE]) {
      logger.debug('⏳ Ожидание выполняющегося запроса');
      return await MODULE_STATE[PRIVATE.FETCH_PROMISE];
    }

    MODULE_STATE[PRIVATE.FETCH_PROMISE] = (async () => {
      try {
        logger.debug('📡 Загрузка кода по URL: ' + url);

        const response = await fetch(url);
        if (!response.ok) {
          throw new Error('HTTP ' + response.status + ': ' + response.statusText);
        }

        const text = await response.text();

        if (!text || text.length < 10) {
          throw new Error('Получен пустой или слишком короткий код');
        }

        MODULE_STATE[PRIVATE.FETCH_CACHE] = text;
        logger.success('✅ Код загружен: ' + text.length + ' символов');

        return text;
      } catch (error) {
        logger.error('❌ Ошибка загрузки кода:', error);
        throw error;
      } finally {
        MODULE_STATE[PRIVATE.FETCH_PROMISE] = null;
      }
    })();

    return await MODULE_STATE[PRIVATE.FETCH_PROMISE];
  } catch (error) {
    logger.error('❌ Ошибка получения кода:', error);
    return `(function(){alert('❌ Ошибка загрузки Vue букмарклета: ${error.message}')})();`;
  }
}

/**
 * Получить минифицированную версию Vue букмарклета
 */
async function getVueBookmarkletMinified(options = {}) {
  const startTime = Date.now();
  const stats = MODULE_STATE[PRIVATE.MINIFY_STATS];

  try {
    const code = await getVueBookmarkletCode();
    if (!validateCode(code)) {
      throw new Error('Некорректный код для минификации');
    }

    const result = minifyBookmarkletCode('javascript:' + code, {
      minify: true,
      keepNames: false,
      preserveStrings: true,
      ...options,
    });

    stats.calls++;
    stats.lastMinifyTime = Date.now();
    stats.totalMinifyTime += Date.now() - startTime;

    logger.success(
      '✅ Минификация завершена: ' + code.length + ' → ' + result.length + ' символов'
    );
    return result;
  } catch (error) {
    stats.fallbackCalls++;
    logger.error('❌ Ошибка минификации:', error);
    try {
      const code = await getVueBookmarkletCode();
      return 'javascript:' + code;
    } catch (fallbackError) {
      return 'javascript:(function(){alert("❌ Ошибка загрузки Vue букмарклета")})();';
    }
  }
}

/**
 * Получить минифицированную версию с кэшированием
 */
async function getVueBookmarkletMinifiedCached(options = {}) {
  const cacheKey = JSON.stringify({ ...options, baseUrl: getBaseUrl() });

  if (
    MODULE_STATE[PRIVATE.MINIFY_CACHE] &&
    MODULE_STATE[PRIVATE.MINIFY_CACHE]._optionsKey === cacheKey
  ) {
    MODULE_STATE[PRIVATE.MINIFY_STATS].cacheHits++;
    logger.debug('📦 Минифицированный код получен из кэша');
    return MODULE_STATE[PRIVATE.MINIFY_CACHE].result;
  }

  if (MODULE_STATE[PRIVATE.IS_MINIFYING] && MODULE_STATE[PRIVATE.MINIFY_PROMISE]) {
    logger.debug('⏳ Ожидание выполняющейся минификации');
    return await MODULE_STATE[PRIVATE.MINIFY_PROMISE];
  }

  MODULE_STATE[PRIVATE.IS_MINIFYING] = true;
  MODULE_STATE[PRIVATE.MINIFY_PROMISE] = (async () => {
    try {
      const result = await getVueBookmarkletMinified(options);
      MODULE_STATE[PRIVATE.MINIFY_CACHE] = {
        result: result,
        _optionsKey: cacheKey,
        timestamp: Date.now(),
      };
      return result;
    } finally {
      MODULE_STATE[PRIVATE.IS_MINIFYING] = false;
      MODULE_STATE[PRIVATE.MINIFY_PROMISE] = null;
    }
  })();

  return await MODULE_STATE[PRIVATE.MINIFY_PROMISE];
}

/**
 * Очистить кэш
 */
function clearVueCache() {
  var logger = createLogger(CONFIG.debug, 'VueModule');
  logger.info('🧹 clearVueCache()');
  MODULE_STATE[PRIVATE.CACHE] = null;
  MODULE_STATE[PRIVATE.FETCH_CACHE] = null;
  MODULE_STATE[PRIVATE.FETCH_PROMISE] = null;
  MODULE_STATE[PRIVATE.MINIFY_CACHE] = null;
  MODULE_STATE[PRIVATE.IS_MINIFYING] = false;
  MODULE_STATE[PRIVATE.MINIFY_PROMISE] = null;
  return true;
}

/**
 * Получить статистику минификации
 */
function getVueBookmarkletMinifyStats() {
  return { ...MODULE_STATE[PRIVATE.MINIFY_STATS] };
}

/**
 * Сбросить статистику минификации
 */
function resetVueBookmarkletMinifyStats() {
  MODULE_STATE[PRIVATE.MINIFY_STATS] = {
    calls: 0,
    cacheHits: 0,
    fallbackCalls: 0,
    lastMinifyTime: null,
    totalMinifyTime: 0,
  };
  var logger = createLogger(CONFIG.debug, 'VueModule');
  logger.debug('🔄 Статистика минификации сброшена');
  return true;
}

// ============================================================
// 14. МОНТИРОВАНИЕ VUE CONSUMER
// ============================================================

/**
 * Монтирование Vue Consumer
 * @param {HTMLElement|string} element - Элемент или селектор
 * @param {Object} options - Опции монтирования
 * @returns {Object} Объект с методами управления
 */
function mountVueConsumerWrapper(element, options = {}) {
  var logger = createLogger(CONFIG.debug, 'VueModule');
  logger.info('🔌 Монтирование Vue Consumer...');

  try {
    let targetElement = element;
    if (typeof element === 'string') {
      targetElement = document.querySelector(element);
      if (!targetElement) {
        throw new Error('Элемент не найден: ' + element);
      }
    }

    const store = options.store || window[Symbol.for('__HIGH_FREQ_STREAM_STORE__')];
    if (!store) {
      throw new Error('Хранилище не найдено');
    }

    const consumer = mountVueConsumer(targetElement, {
      ...options,
      store: store,
    });

    logger.success('✅ Vue Consumer смонтирован');
    return consumer;
  } catch (error) {
    logger.error('❌ Ошибка монтирования Vue Consumer:', error);
    throw error;
  }
}

// ============================================================
// 15. ИНИЦИАЛИЗАЦИЯ
// ============================================================

function init() {
  var logger = createLogger(CONFIG.debug, 'VueModule');
  var state = MODULE_STATE;

  if (state[PRIVATE.INITIALIZED]) {
    logger.warn('⚠️ Модуль уже инициализирован');
    return;
  }

  logger.header('ИНИЦИАЛИЗАЦИЯ VUE МОДУЛЯ (100% СИМВОЛЫ)');
  logger.info('📦 Версия: ' + CONFIG.version);
  logger.info('📅 Сборка: ' + CONFIG.build);
  logger.separator();

  state[PRIVATE.INITIALIZED] = true;
  state[PRIVATE.DESTROYED] = false;

  if (globalStore) {
    logger.success('✅ Хранилище доступно');
    var health = healthCheck();
    if (health) {
      logger.info('  📊 Версия: ' + health.version);
      logger.info('  📈 Метрик: ' + health.metricsCount);
      logger.info('  📡 Статус: ' + health.status);
    }
  } else {
    logger.warn('⚠️ Хранилище не доступно');
  }

  if (CONFIG.debug) {
    getVueBookmarkletMinifiedCached()
      .then((result) => {
        logger.success('✅ Кэш предварительно загружен: ' + result.length + ' символов');
      })
      .catch((error) => {
        logger.warn('⚠️ Не удалось предварительно загрузить кэш:', error);
      });
  }

  var autoStart = getAutoStart();
  logger.info('🔒 AutoStart: ' + (autoStart ? 'ВКЛЮЧЕН' : 'ОТКЛЮЧЕН'));

  logger.success('✅ Vue модуль инициализирован');
  logger.header('ГОТОВ');

  return true;
}

function destroy() {
  var logger = createLogger(CONFIG.debug, 'VueModule');
  var state = MODULE_STATE;

  if (state[PRIVATE.DESTROYED]) {
    logger.warn('⚠️ Модуль уже уничтожен');
    return;
  }

  logger.info('🧹 Уничтожение Vue модуля...');

  if (state[PRIVATE.IS_ACTIVE]) {
    stopStream();
  }

  state[PRIVATE.DESTROYED] = true;
  state[PRIVATE.INITIALIZED] = false;
  state[PRIVATE.COUNTER] = 0;
  state[PRIVATE.CACHE] = null;
  state[PRIVATE.FETCH_CACHE] = null;
  state[PRIVATE.FETCH_PROMISE] = null;
  state[PRIVATE.MINIFY_CACHE] = null;

  if (typeof window !== 'undefined') {
    delete window.__VUE_MODULE_SYMBOLS;
    delete window.__vueModule;
    delete window[PUBLIC.INSTANCE];
  }

  logger.success('✅ Vue модуль уничтожен');
}

// ============================================================
// 16. ЭКСПОРТЫ (100% СИМВОЛЫ) - КАК В REACT
// ============================================================

export {
  mountVueConsumerWrapper as mountVueConsumer,
  getVueBookmarkletCode,
  getVueBookmarkletMinified,
  getVueBookmarkletMinifiedCached,
  clearVueCache,
  getVueBookmarkletMinifyStats,
  resetVueBookmarkletMinifyStats,
  startStream,
  stopStream,
  clearData,
  setFrequency,
  getFrequency,
  isStreamActive,
  getAutoStart,
  setAutoStart,
  toggleAutoStart,
  getStore,
  getStoreSymbol,
  healthCheck,
  getState,
  getMetrics,
  getStatus,
  getStreamStats,
  sendMessage,
  broadcastMessage,
  getMessages,
  clearMessages,
  subscribe,
  init,
  destroy,
};

export { PRIVATE as VUE_MODULE_PRIVATE, PUBLIC as VUE_MODULE_PUBLIC, CONFIG as VUE_MODULE_CONFIG };

// ============================================================
// 17. ЭКСПОРТ ПО УМОЛЧАНИЮ
// ============================================================

export default {
  mountVueConsumer: mountVueConsumerWrapper,
  getVueBookmarkletCode,
  getVueBookmarkletMinified,
  getVueBookmarkletMinifiedCached,
  clearVueCache,
  getVueBookmarkletMinifyStats,
  resetVueBookmarkletMinifyStats,
  startStream,
  stopStream,
  clearData,
  setFrequency,
  getFrequency,
  isStreamActive,
  getAutoStart,
  setAutoStart,
  toggleAutoStart,
  getStore,
  getStoreSymbol,
  healthCheck,
  getState,
  getMetrics,
  getStatus,
  getStreamStats,
  sendMessage,
  broadcastMessage,
  getMessages,
  clearMessages,
  subscribe,
  init,
  destroy,
  PRIVATE,
  PUBLIC,
  CONFIG,
};

// ============================================================
// 18. ГЛОБАЛЬНАЯ РЕГИСТРАЦИЯ
// ============================================================

if (typeof window !== 'undefined' && typeof document !== 'undefined') {
  window.__mountVueConsumer = mountVueConsumerWrapper;
  window.__getVueBookmarkletMinifiedCached = getVueBookmarkletMinifiedCached;
  window.__clearVueBookmarkletCache = clearVueCache;
  window.__getVueBookmarkletMinifyStats = getVueBookmarkletMinifyStats;
  window.__resetVueBookmarkletMinifyStats = resetVueBookmarkletMinifyStats;

  window.__VUE_MODULE_CONFIG = { ...CONFIG };
  window.__VUE_MODULE_SYMBOLS = {
    PRIVATE: { ...PRIVATE },
    PUBLIC: { ...PUBLIC },
  };

  window.__VUE_MODULE_CACHE = {
    get: () => MODULE_STATE[PRIVATE.MINIFY_CACHE],
    clear: clearVueCache,
    getStats: getVueBookmarkletMinifyStats,
    resetStats: resetVueBookmarkletMinifyStats,
  };

  window.__vueModule = {
    mountVueConsumer: mountVueConsumerWrapper,
    getVueBookmarkletMinifiedCached,
    clearVueCache,
    getVueBookmarkletMinifyStats,
    resetVueBookmarkletMinifyStats,
    startStream,
    stopStream,
    clearData,
    setFrequency,
    getFrequency,
    isStreamActive,
    getAutoStart,
    setAutoStart,
    toggleAutoStart,
    getStore,
    getStoreSymbol,
    healthCheck,
    getState,
    getMetrics,
    getStatus,
    getStreamStats,
    sendMessage,
    broadcastMessage,
    getMessages,
    clearMessages,
    subscribe,
    init,
    destroy,
    getSymbols: () => ({
      PRIVATE: { ...PRIVATE },
      PUBLIC: { ...PUBLIC },
    }),
    getConfig: () => ({ ...CONFIG }),
  };

  init();

  console.log('✅ Vue Module: Глобальная регистрация выполнена');
  console.log('📋 ДОСТУПНЫЕ КОМАНДЫ:');
  console.log('  window.__mountVueConsumer(element, options) - монтирование Vue Consumer');
  console.log(
    '  window.__getVueBookmarkletMinifiedCached(options) - получить минифицированный букмарклет'
  );
  console.log('  window.__clearVueBookmarkletCache() - очистить кэш');
  console.log('  window.__getVueBookmarkletMinifyStats() - статистика минификации');
  console.log('  window.__resetVueBookmarkletMinifyStats() - сбросить статистику');
  console.log('  window.__vueModule.startStream() - запустить стриминг');
  console.log('  window.__vueModule.stopStream() - остановить стриминг');
  console.log('  window.__vueModule.getState() - получить состояние');
  console.log('  window.__vueModule.sendMessage(msg) - отправить сообщение');
  console.log('  window.__vueModule.subscribe(callback) - подписаться');
}

// ============================================================
// 19. СТАТИСТИКА СИМВОЛОВ
// ============================================================

if (typeof console !== 'undefined') {
  var privateCount = Object.keys(PRIVATE).length;
  var publicCount = Object.keys(PUBLIC).length;

  console.log(
    '📊 Vue Module: ' + privateCount + ' приватных, ' + publicCount + ' публичных символов'
  );
  console.log('📦 Всего символов: ' + (privateCount + publicCount));
  console.log('📋 Версия: ' + CONFIG.version + ' (' + CONFIG.build + ')');
}

// ============================================================
// 20. ОБРАБОТЧИКИ ДЛЯ ОТЛАДКИ
// ============================================================

if (typeof window !== 'undefined' && CONFIG.debug) {
  window.__debugVueModule = {
    getState: () => ({
      initialized: MODULE_STATE[PRIVATE.INITIALIZED],
      destroyed: MODULE_STATE[PRIVATE.DESTROYED],
      cacheSize: MODULE_STATE[PRIVATE.MINIFY_CACHE] ? 1 : 0,
      isMinifying: MODULE_STATE[PRIVATE.IS_MINIFYING],
      fetchCacheSize: MODULE_STATE[PRIVATE.FETCH_CACHE]
        ? MODULE_STATE[PRIVATE.FETCH_CACHE].length
        : 0,
    }),
    getStats: getVueBookmarkletMinifyStats,
    clearCache: clearVueCache,
    resetStats: resetVueBookmarkletMinifyStats,
    getSymbols: () => ({
      PRIVATE: { ...PRIVATE },
      PUBLIC: { ...PUBLIC },
    }),
    testMinify: async (options = {}) => {
      const start = Date.now();
      const result = await getVueBookmarkletMinified(options);
      const time = Date.now() - start;
      return {
        time: time + 'ms',
        length: result.length,
        preview: result.substring(0, 100) + '...',
      };
    },
  };

  console.log('📋 КОМАНДЫ ОТЛАДКИ (__debugVueModule):');
  console.log('  __debugVueModule.getState() - состояние модуля');
  console.log('  __debugVueModule.getStats() - статистика минификации');
  console.log('  __debugVueModule.clearCache() - очистить кэш');
  console.log('  __debugVueModule.resetStats() - сбросить статистику');
  console.log('  __debugVueModule.getSymbols() - получить символы');
  console.log('  __debugVueModule.testMinify(options) - тест минификации');
}
