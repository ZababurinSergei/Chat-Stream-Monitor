// src/modules/react-bookmarklet.js
// 100% СИМВОЛЫ — полная изоляция и безопасность
// Версия: 4.0.1 — ИСПРАВЛЕНА ОШИБКА ДУБЛИРОВАНИЯ getStreamService
// Использует единый импорт из core/stream-service.js

// ============================================================
// 1. ПРИВАТНЫЕ СИМВОЛЫ (100% изоляция)
// ============================================================

const PRIVATE_SYMBOLS = {
  VERSION: Symbol('react.module.version'),
  BUILD: Symbol('react.module.build'),
  NAME: Symbol('react.module.name'),
  CONFIG: Symbol('react.module.config'),
  STATE: Symbol('react.module.state'),
  INITIALIZED: Symbol('react.module.initialized'),
  DESTROYED: Symbol('react.module.destroyed'),
  CACHE: Symbol('react.module.cache'),
  STATS: Symbol('react.module.stats'),
  BOOKMARKLET: Symbol('react.module.bookmarklet'),
  MINIFY_CACHE: Symbol('react.module.minifyCache'),
  IS_MINIFYING: Symbol('react.module.isMinifying'),
  MINIFY_PROMISE: Symbol('react.module.minifyPromise'),
  FETCH_CACHE: Symbol('react.module.fetchCache'),
  FETCH_PROMISE: Symbol('react.module.fetchPromise'),
  MINIFY_STATS: Symbol('react.module.minifyStats'),
  INIT: Symbol('react.module.init'),
  DESTROY: Symbol('react.module.destroy'),
  GET_STATE: Symbol('react.module.getState'),
  GET_STATS: Symbol('react.module.getStats'),
  CLEAR_CACHE: Symbol('react.module.clearCache'),
  RESET_STATS: Symbol('react.module.resetStats'),
  GET_MINIFIED: Symbol('react.module.getMinified'),
  GET_MINIFIED_CACHED: Symbol('react.module.getMinifiedCached'),
  FETCH_CODE: Symbol('react.module.fetchCode'),
  VALIDATE: Symbol('react.module.validate'),
  SANITIZE: Symbol('react.module.sanitize'),
  ESCAPE: Symbol('react.module.escape'),
  LOG: Symbol('react.module.log'),
  DEBUG: Symbol('react.module.debug'),
  ERROR: Symbol('react.module.error'),
  WARN: Symbol('react.module.warn'),
  SUCCESS: Symbol('react.module.success'),
  EXPORT_SYMBOLS: Symbol('react.module.exportSymbols'),
};

// ============================================================
// 2. ПУБЛИЧНЫЕ СИМВОЛЫ (доступны через Symbol.for)
// ============================================================

const PUBLIC_SYMBOLS = {
  INSTANCE: Symbol.for('react.module.instance'),
  STATE: Symbol.for('react.module.state'),
  CONFIG: Symbol.for('react.module.config'),
  INIT: Symbol.for('react.module.init'),
  DESTROY: Symbol.for('react.module.destroy'),
  GET_STATE: Symbol.for('react.module.getState'),
  GET_STATS: Symbol.for('react.module.getStats'),
  CLEAR_CACHE: Symbol.for('react.module.clearCache'),
  GET_MINIFIED: Symbol.for('react.module.getMinified'),
  GET_MINIFIED_CACHED: Symbol.for('react.module.getMinifiedCached'),
  MOUNT_REACT: Symbol.for('react.module.mountReact'),
};

// ============================================================
// 3. КОНФИГУРАЦИЯ
// ============================================================

const CONFIG = {
  version: '4.0.1',
  build: '2026-07-26',
  name: 'React Bookmarklet Module',
  debug: true,
  minifyOptions: {
    minify: true,
    keepNames: false,
    preserveStrings: true,
    compress: {
      sequences: true,
      dead_code: true,
      conditionals: true,
      booleans: true,
      unused: true,
      if_return: true,
      join_vars: true,
      drop_console: false,
      drop_debugger: true,
      passes: 2,
    },
    mangle: {
      toplevel: true,
      keep_fnames: false,
    },
    output: {
      beautify: false,
      comments: false,
      indent_level: 0,
      quote_style: 3,
    },
  },
};

// ============================================================
// 4. СОСТОЯНИЕ
// ============================================================

const STATE = {
  [PRIVATE_SYMBOLS.INITIALIZED]: false,
  [PRIVATE_SYMBOLS.DESTROYED]: false,
  [PRIVATE_SYMBOLS.CACHE]: null,
  [PRIVATE_SYMBOLS.MINIFY_CACHE]: null,
  [PRIVATE_SYMBOLS.IS_MINIFYING]: false,
  [PRIVATE_SYMBOLS.MINIFY_PROMISE]: null,
  [PRIVATE_SYMBOLS.FETCH_CACHE]: null,
  [PRIVATE_SYMBOLS.FETCH_PROMISE]: null,
  [PRIVATE_SYMBOLS.MINIFY_STATS]: {
    calls: 0,
    cacheHits: 0,
    fallbackCalls: 0,
    lastMinifyTime: null,
    totalMinifyTime: 0,
  },
};

// ============================================================
// 5. ЛОГГЕР (100% символы)
// ============================================================

const LOGGER_SYMBOLS = {
  HISTORY: Symbol('logger.history'),
  MAX_HISTORY: Symbol('logger.maxHistory'),
  DEBUG: Symbol('logger.debug'),
  INSTANCE_ID: Symbol('logger.instanceId'),
  LEVEL: Symbol('logger.level'),
};

function createLogger(debug, instanceId) {
  if (debug === undefined) debug = true;
  if (instanceId === undefined) instanceId = 'ReactModule';

  const logState = {
    [LOGGER_SYMBOLS.HISTORY]: [],
    [LOGGER_SYMBOLS.MAX_HISTORY]: 200,
    [LOGGER_SYMBOLS.DEBUG]: debug,
    [LOGGER_SYMBOLS.INSTANCE_ID]: instanceId,
    [LOGGER_SYMBOLS.LEVEL]: debug ? 3 : 2,
  };

  const logMethod = function (level, message, data) {
    const levels = { error: 0, warn: 1, info: 2, debug: 3, success: 2 };
    const currentLevel = this[LOGGER_SYMBOLS.LEVEL] || 2;
    const msgLevel = levels[level] || 2;

    if (msgLevel > currentLevel) return;

    const timestamp = new Date().toISOString().slice(11, 23);
    const prefix = '[' + timestamp + '] [' + this[LOGGER_SYMBOLS.INSTANCE_ID] + ']';

    this[LOGGER_SYMBOLS.HISTORY].push({
      timestamp: timestamp,
      level: level,
      message: message,
      data: data || null,
      id: Date.now() + Math.random(),
    });

    if (this[LOGGER_SYMBOLS.HISTORY].length > this[LOGGER_SYMBOLS.MAX_HISTORY]) {
      this[LOGGER_SYMBOLS.HISTORY].shift();
    }

    var icons = { error: '❌', warn: '⚠️', info: 'ℹ️', debug: '🔍', success: '✅' };
    var icon = icons[level] || '📌';

    if (data !== null && data !== undefined) {
      console.log(icon + ' ' + prefix + ' ' + message, data);
    } else {
      console.log(icon + ' ' + prefix + ' ' + message);
    }
  };

  var boundLog = logMethod.bind(logState);

  var methods = {
    error: function (msg, d) {
      return boundLog('error', msg, d);
    },
    warn: function (msg, d) {
      return boundLog('warn', msg, d);
    },
    info: function (msg, d) {
      return boundLog('info', msg, d);
    },
    debug: function (msg, d) {
      return boundLog('debug', msg, d);
    },
    success: function (msg, d) {
      return boundLog('success', msg, d);
    },
    header: function (title, color) {
      if (color === undefined) color = '#636e72';
      var separator = '═'.repeat(70);
      console.log('%c' + separator, 'color: ' + color + ';');
      console.log(
        '%c  📦 ' + title,
        'background: #1a1a2e; color: #fff; padding: 4px 12px; border-radius: 4px; font-weight: bold;'
      );
      console.log('%c' + separator, 'color: ' + color + ';');
    },
    separator: function (color) {
      if (color === undefined) color = '#636e72';
      console.log('%c' + '─'.repeat(70), 'color: ' + color + ';');
    },
    getHistory: function () {
      return [...this[LOGGER_SYMBOLS.HISTORY]];
    },
    clearHistory: function () {
      this[LOGGER_SYMBOLS.HISTORY] = [];
      return this;
    },
    setDebug: function (enabled) {
      this[LOGGER_SYMBOLS.DEBUG] = enabled;
      this[LOGGER_SYMBOLS.LEVEL] = enabled ? 3 : 2;
      return this;
    },
  };

  var logger = {};
  var keys = Object.keys(methods);
  for (var i = 0; i < keys.length; i++) {
    var key = keys[i];
    logger[key] = methods[key].bind(logState);
  }

  logger[LOGGER_SYMBOLS.HISTORY] = logState[LOGGER_SYMBOLS.HISTORY];
  logger[LOGGER_SYMBOLS.MAX_HISTORY] = logState[LOGGER_SYMBOLS.MAX_HISTORY];
  logger[LOGGER_SYMBOLS.DEBUG] = logState[LOGGER_SYMBOLS.DEBUG];
  logger[LOGGER_SYMBOLS.INSTANCE_ID] = logState[LOGGER_SYMBOLS.INSTANCE_ID];
  logger[LOGGER_SYMBOLS.LEVEL] = logState[LOGGER_SYMBOLS.LEVEL];

  return logger;
}

var logger = createLogger(CONFIG.debug, 'ReactModule');

// ============================================================
// 6. ИМПОРТЫ (динамические для избежания циклических зависимостей)
// ============================================================

// Импортируем mountReactConsumer из consumers
let _mountReactConsumer = null;

async function getMountReactConsumer() {
  if (_mountReactConsumer) return _mountReactConsumer;
  try {
    const module = await import('../consumers/react-consumer.js');
    _mountReactConsumer = module.mountReactConsumer || module.default;
    return _mountReactConsumer;
  } catch (error) {
    logger.error('❌ Ошибка импорта mountReactConsumer:', error);
    return null;
  }
}

// Импортируем minifyBookmarkletCode из utils
let _minifyFn = null;

async function getMinifyFn() {
  if (_minifyFn) return _minifyFn;
  try {
    const module = await import('../utils/minify.js');
    _minifyFn = module.minifyBookmarkletCode;
    return _minifyFn;
  } catch (error) {
    logger.warn('⚠️ Ошибка импорта minifyBookmarkletCode:', error);
    return null;
  }
}

// ============================================================
// 7. ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ
// ============================================================

function getBaseUrl() {
  return window.location.origin + window.location.pathname.replace(/[^/]*$/, '');
}

function validateCode(code) {
  if (typeof code !== 'string') return false;
  if (code.length === 0) return false;
  if (code.length > 10 * 1024 * 1024) return false;
  return true;
}

function escapeHtml(text) {
  if (!text) return '';
  return String(text)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

// ============================================================
// 8. ОСНОВНЫЕ ФУНКЦИИ
// ============================================================

/**
 * Получить код React букмарклета
 */
async function getReactBookmarkletCode() {
  logger.debug('📥 Получение кода React букмарклета...');

  try {
    const baseUrl = getBaseUrl();
    const url = baseUrl + '/src/bookmarklets/react-bookmarklet.js';

    // Проверяем кэш
    if (STATE[PRIVATE_SYMBOLS.FETCH_CACHE]) {
      logger.debug('📦 Код получен из кэша');
      return STATE[PRIVATE_SYMBOLS.FETCH_CACHE];
    }

    // Проверяем выполняющийся запрос
    if (STATE[PRIVATE_SYMBOLS.FETCH_PROMISE]) {
      logger.debug('⏳ Ожидание выполняющегося запроса');
      return await STATE[PRIVATE_SYMBOLS.FETCH_PROMISE];
    }

    // Создаем новый запрос
    STATE[PRIVATE_SYMBOLS.FETCH_PROMISE] = (async () => {
      try {
        logger.debug('📡 Загрузка кода по URL: ' + url);

        const response = await fetch(url);
        if (!response.ok) {
          throw new Error('HTTP ' + response.status + ': ' + response.statusText);
        }

        const text = await response.text();

        if (!text || text.length < 10) {
          throw new Error('Получен пустой или слишком короткий код');
        }

        // Сохраняем в кэш
        STATE[PRIVATE_SYMBOLS.FETCH_CACHE] = text;
        logger.success('✅ Код загружен: ' + text.length + ' символов');

        return text;
      } catch (error) {
        logger.error('❌ Ошибка загрузки кода:', error);
        throw error;
      } finally {
        STATE[PRIVATE_SYMBOLS.FETCH_PROMISE] = null;
      }
    })();

    return await STATE[PRIVATE_SYMBOLS.FETCH_PROMISE];
  } catch (error) {
    logger.error('❌ Ошибка получения кода:', error);
    // Fallback: возвращаем заглушку
    return `(function(){alert('❌ Ошибка загрузки React букмарклета: ${escapeHtml(error.message)}')})();`;
  }
}

/**
 * Получить минифицированную версию React букмарклета
 */
async function getReactBookmarkletMinified(options = {}) {
  const startTime = Date.now();
  const stats = STATE[PRIVATE_SYMBOLS.MINIFY_STATS];

  try {
    // Получаем код
    const code = await getReactBookmarkletCode();
    if (!validateCode(code)) {
      throw new Error('Некорректный код для минификации');
    }

    // Получаем функцию минификации
    const minifyFn = await getMinifyFn();
    if (!minifyFn) {
      logger.warn('⚠️ Минификация не доступна, возвращаем исходный код');
      return 'javascript:' + code;
    }

    // Минифицируем
    const result = await minifyFn('javascript:' + code, {
      ...CONFIG.minifyOptions,
      ...options,
    });

    // Обновляем статистику
    stats.calls++;
    stats.lastMinifyTime = Date.now();
    stats.totalMinifyTime += Date.now() - startTime;

    logger.success(
      '✅ Минификация завершена: ' + code.length + ' → ' + result.length + ' символов'
    );
    return result;
  } catch (error) {
    stats.fallbackCalls++;
    logger.error('❌ Ошибка минификации:', error);
    // Возвращаем исходный код с префиксом
    try {
      const code = await getReactBookmarkletCode();
      return 'javascript:' + code;
    } catch (fallbackError) {
      return 'javascript:(function(){alert("❌ Ошибка загрузки React букмарклета")})();';
    }
  }
}

/**
 * Получить минифицированную версию с кэшированием
 */
async function getReactBookmarkletMinifiedCached(options = {}) {
  const cacheKey = JSON.stringify({ ...options, baseUrl: getBaseUrl() });

  // Проверяем кэш
  if (
    STATE[PRIVATE_SYMBOLS.MINIFY_CACHE] &&
    STATE[PRIVATE_SYMBOLS.MINIFY_CACHE]._optionsKey === cacheKey
  ) {
    STATE[PRIVATE_SYMBOLS.MINIFY_STATS].cacheHits++;
    logger.debug('📦 Минифицированный код получен из кэша');
    return STATE[PRIVATE_SYMBOLS.MINIFY_CACHE].result;
  }

  // Проверяем выполняющуюся минификацию
  if (STATE[PRIVATE_SYMBOLS.IS_MINIFYING] && STATE[PRIVATE_SYMBOLS.MINIFY_PROMISE]) {
    logger.debug('⏳ Ожидание выполняющейся минификации');
    return await STATE[PRIVATE_SYMBOLS.MINIFY_PROMISE];
  }

  // Запускаем минификацию
  STATE[PRIVATE_SYMBOLS.IS_MINIFYING] = true;
  STATE[PRIVATE_SYMBOLS.MINIFY_PROMISE] = (async () => {
    try {
      const result = await getReactBookmarkletMinified(options);
      STATE[PRIVATE_SYMBOLS.MINIFY_CACHE] = {
        result: result,
        _optionsKey: cacheKey,
        timestamp: Date.now(),
      };
      return result;
    } finally {
      STATE[PRIVATE_SYMBOLS.IS_MINIFYING] = false;
      STATE[PRIVATE_SYMBOLS.MINIFY_PROMISE] = null;
    }
  })();

  return await STATE[PRIVATE_SYMBOLS.MINIFY_PROMISE];
}

/**
 * Очистить кэш
 */
function clearReactBookmarkletCache() {
  STATE[PRIVATE_SYMBOLS.FETCH_CACHE] = null;
  STATE[PRIVATE_SYMBOLS.FETCH_PROMISE] = null;
  STATE[PRIVATE_SYMBOLS.MINIFY_CACHE] = null;
  STATE[PRIVATE_SYMBOLS.IS_MINIFYING] = false;
  STATE[PRIVATE_SYMBOLS.MINIFY_PROMISE] = null;
  logger.debug('🧹 Кэш React букмарклета очищен');
  return true;
}

/**
 * Получить статистику минификации
 */
function getReactBookmarkletMinifyStats() {
  return { ...STATE[PRIVATE_SYMBOLS.MINIFY_STATS] };
}

/**
 * Сбросить статистику минификации
 */
function resetReactBookmarkletMinifyStats() {
  STATE[PRIVATE_SYMBOLS.MINIFY_STATS] = {
    calls: 0,
    cacheHits: 0,
    fallbackCalls: 0,
    lastMinifyTime: null,
    totalMinifyTime: 0,
  };
  logger.debug('🔄 Статистика минификации сброшена');
  return true;
}

// ============================================================
// 9. МОНТИРОВАНИЕ REACT CONSUMER
// ============================================================

/**
 * Монтирование React Consumer
 * @param {HTMLElement|string} element - Элемент или селектор
 * @param {Object} options - Опции монтирования
 * @returns {Object} Объект с методами управления
 */
async function mountReactConsumer(element, options = {}) {
  logger.info('🔌 Монтирование React Consumer...');

  try {
    // Получаем mountReactConsumer
    const mountFn = await getMountReactConsumer();
    if (!mountFn) {
      throw new Error('mountReactConsumer не доступен');
    }

    // Получаем элемент
    let targetElement = element;
    if (typeof element === 'string') {
      targetElement = document.querySelector(element);
      if (!targetElement) {
        throw new Error('Элемент не найден: ' + element);
      }
    }

    // Получаем хранилище
    const store = window[Symbol.for('__HIGH_FREQ_STREAM_STORE__')];
    if (!store) {
      throw new Error('Хранилище не найдено');
    }

    // Монтируем
    const consumer = mountFn(targetElement, {
      ...options,
      store: options.store || store,
    });

    logger.success('✅ React Consumer смонтирован');
    return consumer;
  } catch (error) {
    logger.error('❌ Ошибка монтирования React Consumer:', error);
    throw error;
  }
}

// ============================================================
// 10. ИНИЦИАЛИЗАЦИЯ
// ============================================================

function initReactBookmarkletModule() {
  if (STATE[PRIVATE_SYMBOLS.INITIALIZED]) {
    logger.warn('⚠️ Модуль уже инициализирован');
    return;
  }

  logger.header('ИНИЦИАЛИЗАЦИЯ REACT BOOKMARKLET MODULE (100% СИМВОЛЫ)');
  logger.info('📦 Версия: ' + CONFIG.version);
  logger.info('📅 Сборка: ' + CONFIG.build);
  logger.info('📌 Отладка: ' + (CONFIG.debug ? '✅' : '❌'));
  logger.separator();

  STATE[PRIVATE_SYMBOLS.INITIALIZED] = true;
  STATE[PRIVATE_SYMBOLS.DESTROYED] = false;

  // Предварительная загрузка кэша
  if (CONFIG.debug) {
    getReactBookmarkletMinifiedCached()
      .then((result) => {
        logger.success('✅ Кэш предварительно загружен: ' + result.length + ' символов');
      })
      .catch((error) => {
        logger.warn('⚠️ Не удалось предварительно загрузить кэш:', error);
      });
  }

  // Экспорт символов
  if (typeof window !== 'undefined') {
    window.__REACT_MODULE_SYMBOLS = {
      PRIVATE: { ...PRIVATE_SYMBOLS },
      PUBLIC: { ...PUBLIC_SYMBOLS },
    };
    window[PUBLIC_SYMBOLS.INSTANCE] = {
      mountReactConsumer,
      getReactBookmarkletMinifiedCached,
      clearReactBookmarkletCache,
      getReactBookmarkletMinifyStats,
      resetReactBookmarkletMinifyStats,
    };
  }

  logger.success('✅ React Bookmarklet Module инициализирован');
  logger.header('ГОТОВ');
}

function destroyReactBookmarkletModule() {
  if (STATE[PRIVATE_SYMBOLS.DESTROYED]) {
    logger.warn('⚠️ Модуль уже уничтожен');
    return;
  }

  logger.info('🧹 Уничтожение React Bookmarklet Module...');

  clearReactBookmarkletCache();
  STATE[PRIVATE_SYMBOLS.DESTROYED] = true;
  STATE[PRIVATE_SYMBOLS.INITIALIZED] = false;

  if (typeof window !== 'undefined') {
    delete window.__REACT_MODULE_SYMBOLS;
    delete window[PUBLIC_SYMBOLS.INSTANCE];
  }

  logger.success('✅ React Bookmarklet Module уничтожен');
}

// ============================================================
// 11. ЭКСПОРТЫ (100% символы)
// ============================================================

// Основные экспорты
export {
  mountReactConsumer,
  getReactBookmarkletCode,
  getReactBookmarkletMinified,
  getReactBookmarkletMinifiedCached,
  clearReactBookmarkletCache,
  getReactBookmarkletMinifyStats,
  resetReactBookmarkletMinifyStats,
  initReactBookmarkletModule,
  destroyReactBookmarkletModule,
};

// Экспорт символов
export {
  PRIVATE_SYMBOLS as REACT_MODULE_PRIVATE,
  PUBLIC_SYMBOLS as REACT_MODULE_PUBLIC,
  CONFIG as REACT_MODULE_CONFIG,
};

// Экспорт по умолчанию
export default {
  mountReactConsumer,
  getReactBookmarkletCode,
  getReactBookmarkletMinified,
  getReactBookmarkletMinifiedCached,
  clearReactBookmarkletCache,
  getReactBookmarkletMinifyStats,
  resetReactBookmarkletMinifyStats,
  initReactBookmarkletModule,
  destroyReactBookmarkletModule,
};

// ============================================================
// 12. ГЛОБАЛЬНАЯ РЕГИСТРАЦИЯ (только в браузере)
// ============================================================

if (typeof window !== 'undefined' && typeof document !== 'undefined') {
  // Регистрируем глобальные функции
  window.__mountReactConsumer = mountReactConsumer;
  window.__getReactBookmarkletMinifiedCached = getReactBookmarkletMinifiedCached;
  window.__clearReactBookmarkletCache = clearReactBookmarkletCache;
  window.__getReactBookmarkletMinifyStats = getReactBookmarkletMinifyStats;
  window.__resetReactBookmarkletMinifyStats = resetReactBookmarkletMinifyStats;

  // Добавляем отладочную информацию
  window.__REACT_MODULE_CONFIG = { ...CONFIG };

  // Кэш для быстрого доступа
  window.__REACT_MODULE_CACHE = {
    get: () => STATE[PRIVATE_SYMBOLS.MINIFY_CACHE],
    clear: clearReactBookmarkletCache,
    getStats: getReactBookmarkletMinifyStats,
    resetStats: resetReactBookmarkletMinifyStats,
  };

  // Инициализация
  initReactBookmarkletModule();

  console.log('✅ React Bookmarklet Module: Глобальная регистрация выполнена');
  console.log('📋 ДОСТУПНЫЕ КОМАНДЫ:');
  console.log('  window.__mountReactConsumer(element, options) - монтирование React Consumer');
  console.log(
    '  window.__getReactBookmarkletMinifiedCached(options) - получить минифицированный букмарклет'
  );
  console.log('  window.__clearReactBookmarkletCache() - очистить кэш');
  console.log('  window.__getReactBookmarkletMinifyStats() - статистика минификации');
  console.log('  window.__resetReactBookmarkletMinifyStats() - сбросить статистику');
}

// ============================================================
// 13. СТАТИСТИКА СИМВОЛОВ
// ============================================================

if (typeof console !== 'undefined') {
  const privateCount = Object.keys(PRIVATE_SYMBOLS).length;
  const publicCount = Object.keys(PUBLIC_SYMBOLS).length;

  console.log(
    '📊 React Module: ' + privateCount + ' приватных, ' + publicCount + ' публичных символов'
  );
  console.log('📦 Всего символов: ' + (privateCount + publicCount));
  console.log('📋 Версия: ' + CONFIG.version + ' (' + CONFIG.build + ')');
}

// ============================================================
// 14. ОБРАБОТЧИКИ ДЛЯ ОТЛАДКИ
// ============================================================

if (typeof window !== 'undefined' && CONFIG.debug) {
  window.__debugReactModule = {
    getState: () => ({
      initialized: STATE[PRIVATE_SYMBOLS.INITIALIZED],
      destroyed: STATE[PRIVATE_SYMBOLS.DESTROYED],
      cacheSize: STATE[PRIVATE_SYMBOLS.MINIFY_CACHE] ? 1 : 0,
      isMinifying: STATE[PRIVATE_SYMBOLS.IS_MINIFYING],
      fetchCacheSize: STATE[PRIVATE_SYMBOLS.FETCH_CACHE]
        ? STATE[PRIVATE_SYMBOLS.FETCH_CACHE].length
        : 0,
    }),
    getStats: getReactBookmarkletMinifyStats,
    clearCache: clearReactBookmarkletCache,
    resetStats: resetReactBookmarkletMinifyStats,
    getSymbols: () => ({
      PRIVATE: { ...PRIVATE_SYMBOLS },
      PUBLIC: { ...PUBLIC_SYMBOLS },
    }),
    testMinify: async (options = {}) => {
      const start = Date.now();
      const result = await getReactBookmarkletMinified(options);
      const time = Date.now() - start;
      return {
        time: time + 'ms',
        length: result.length,
        preview: result.substring(0, 100) + '...',
      };
    },
  };

  console.log('📋 КОМАНДЫ ОТЛАДКИ (__debugReactModule):');
  console.log('  __debugReactModule.getState() - состояние модуля');
  console.log('  __debugReactModule.getStats() - статистика минификации');
  console.log('  __debugReactModule.clearCache() - очистить кэш');
  console.log('  __debugReactModule.resetStats() - сбросить статистику');
  console.log('  __debugReactModule.getSymbols() - получить символы');
  console.log('  __debugReactModule.testMinify(options) - тест минификации');
}
