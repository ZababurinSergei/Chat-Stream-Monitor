// src/modules/index.js
// Экспорт букмарклетов и утилит

export { vueBookmarkletString, vueBookmarkletMinified } from './vue-bookmarklet.js';
export {
  reactBookmarkletString,
  reactBookmarkletMinified,
  getMinifiedReactBookmarklet
} from './react-bookmarklet.js';

// Импортируем и реэкспортируем функции минификации
export {
  minifyJS,
  minifyBookmarkletCode,
  minifyWithCache,
  getMinifyState,
  getMinifyStats,
  resetMinify,
  destroyMinify,
  initMinify
} from '../utils/minify.js';
