// src/bookmarklets/vue-bookmarklet.js
// 100% СИМВОЛЫ — полная изоляция и безопасность
// Версия: 7.3.2 — ИСПРАВЛЕНА ВЫСОТА ПРИ РЕСАЙЗЕ

(async function (props) {
  'use strict';

  // ============================================================
  // 1. ПОЛУЧАЕМ ПАРАМЕТРЫ
  // ============================================================
  var baseUrl =
    props && props.baseUrl
      ? props.baseUrl
      : window.location.origin + window.location.pathname.replace(/[^/]*$/, '');

  var consumerId =
    props && props.consumerId
      ? props.consumerId
      : 'vue_' + Date.now().toString(36) + '_' + Math.random().toString(36).substr(2, 6);

  var containerId =
    props && props.containerId ? props.containerId : 'vue-consumer-container-' + consumerId;

  var contentId = props && props.contentId ? props.contentId : 'vue-consumer-content-' + consumerId;

  var statusBadgeId =
    props && props.statusBadgeId ? props.statusBadgeId : 'vue-bookmarklet-status-' + consumerId;

  console.log('📌 Vue Bookmarklet: baseUrl =', baseUrl);
  console.log('📌 Vue Bookmarklet: consumerId =', consumerId);

  // ============================================================
  // 2. ПРОВЕРКА БЕЗОПАСНОСТИ
  // ============================================================
  if (!window.isSecureContext) {
    alert('⚠️ Небезопасный контекст. Запустите через HTTPS или localhost.');
    return;
  }
  if (typeof window === 'undefined') {
    console.error('❌ Vue Bookmarklet: Окружение не поддерживается');
    return;
  }

  // ============================================================
  // 3. ПОЛУЧАЕМ GLOBAL STORE
  // ============================================================
  var GLOBAL_STORE_SYMBOL = Symbol.for('__GLOBAL_STORE__');
  var globalStore = window[GLOBAL_STORE_SYMBOL];

  if (!globalStore) {
    try {
      var module = await import(baseUrl + 'src/core/global-store.js');
      globalStore = module.getGlobalStore();
      window[GLOBAL_STORE_SYMBOL] = globalStore;
      console.log('✅ Global Store загружен через динамический импорт');
    } catch (error) {
      console.error('❌ Не удалось загрузить Global Store:', error);
      alert('❌ Хранилище не найдено. Запустите основное приложение сначала.');
      return;
    }
  }

  if (!globalStore) {
    alert('❌ Хранилище не найдено. Запустите основное приложение сначала.');
    console.error('❌ Vue Bookmarklet: Хранилище не найдено');
    return;
  }

  var OLD_STORE_SYMBOL = Symbol.for('__HIGH_FREQ_STREAM_STORE__');
  if (window[OLD_STORE_SYMBOL]) {
    console.log('🧹 Удаляем старое хранилище (__HIGH_FREQ_STREAM_STORE__)');
    delete window[OLD_STORE_SYMBOL];
  }

  console.log(
    '✅ Vue Bookmarklet: Global Store найден, версия:',
    globalStore.__version || 'unknown'
  );

  // ============================================================
  // 4. СОЗДАЁМ СОВМЕСТИМУЮ ОБЁРТКУ
  // ============================================================
  var store = {
    __version: globalStore.__version || '3.0.0',
    __created: Date.now(),

    getState: function () {
      var state = globalStore.getState();
      var metrics = globalStore.select('metrics') || [];
      var adaptedMetrics = metrics.map(function (m) {
        return {
          id: m.id,
          ts: m.timestamp || m.ts || Date.now(),
          val: m.value || m.val || 0,
          trend: m.trend || 0,
          source: m.source || 'stream',
        };
      });
      var messages = globalStore.select('messages') || [];
      return {
        liveMetrics: adaptedMetrics,
        streamStatus: state.streamStatus || 'disconnected',
        totalBatches: state._batches || 0,
        lastUpdate: state.lastUpdate || null,
        messages: messages,
        _messages: messages,
      };
    },

    setStatus: function (status) {
      return globalStore.setStatus(status);
    },

    getStatus: function () {
      return globalStore.getStatus() || 'disconnected';
    },

    appendDataBatch: function (batch) {
      if (!batch || !Array.isArray(batch)) return false;
      var adaptedBatch = batch.map(function (item) {
        return {
          id: item.id || 'metric_' + Date.now() + '_' + Math.random().toString(36).substr(2, 6),
          timestamp: item.ts || Date.now(),
          value: item.val || 0,
          trend: item.trend || 0,
          source: item.source || 'stream',
        };
      });
      return globalStore.insert('metrics', adaptedBatch);
    },

    clearStore: function () {
      globalStore.clearTable('metrics');
      globalStore.clearTable('messages');
      return true;
    },

    getMessages: function (limit) {
      var msgs = globalStore.select('messages', {
        sort: [{ field: 'timestamp', direction: 'desc' }],
        limit: limit || 50,
      });
      return msgs || [];
    },

    clearMessages: function () {
      return globalStore.clearTable('messages');
    },

    replaceMessages: function (messages) {
      globalStore.clearTable('messages');
      if (messages && messages.length > 0) {
        var rows = messages.map(function (msg) {
          return {
            id: msg.id || 'msg_' + Date.now() + '_' + Math.random().toString(36).substr(2, 6),
            timestamp: msg.ts || Date.now(),
            text: msg.text || '',
            type: msg.type || 'restored',
            source: msg.source || 'restored',
            consumerId: msg.consumerId || null,
          };
        });
        return globalStore.insert('messages', rows);
      }
      return true;
    },

    subscribe: function (callback) {
      if (typeof callback !== 'function') {
        console.warn('⚠️ subscribe: callback должен быть функцией');
        return function () {};
      }
      var originalCallback = callback;
      var wrappedCallback = function (channel, message) {
        if (message.type === 'store-event' || message.type === 'status-change') {
          try {
            var adaptedState = store.getState();
            originalCallback(adaptedState);
          } catch (error) {
            console.warn('⚠️ Ошибка в callback подписки:', error);
          }
        }
      };
      var subId = globalStore.subscribe('*', wrappedCallback);
      return function () {
        if (subId) {
          globalStore.unsubscribe('*', subId);
        }
      };
    },

    healthCheck: function () {
      return globalStore.healthCheck();
    },

    getGlobalStore: function () {
      return globalStore;
    },
  };

  window[GLOBAL_STORE_SYMBOL] = globalStore;
  window.__store = store;
  window.__globalStore = globalStore;
  window[OLD_STORE_SYMBOL] = store;

  // ============================================================
  // 5. ПРИВАТНЫЕ СИМВОЛЫ (100% изоляция)
  // ============================================================
  var PRIVATE = {
    VERSION: Symbol('vue.bookmarklet.version'),
    BUILD: Symbol('vue.bookmarklet.build'),
    NAME: Symbol('vue.bookmarklet.name'),
    CONFIG: Symbol('vue.bookmarklet.config'),
    STATE: Symbol('vue.bookmarklet.state'),
    CONSUMER_ID: Symbol('vue.bookmarklet.consumerId'),
    CONTAINER_ID: Symbol('vue.bookmarklet.containerId'),
    MODE: Symbol('vue.bookmarklet.mode'),
    IS_SINGLETON: Symbol('vue.bookmarklet.isSingleton'),
    IS_HIDDEN: Symbol('vue.bookmarklet.isHidden'),
    IS_MAXIMIZED: Symbol('vue.bookmarklet.isMaximized'),
    PREV_SIZE: Symbol('vue.bookmarklet.prevSize'),
    PREV_POS: Symbol('vue.bookmarklet.prevPos'),
    INSTANCE_INDEX: Symbol('vue.bookmarklet.instanceIndex'),
    BASE_URL: Symbol('vue.bookmarklet.baseUrl'),
    REGISTRY: Symbol('vue.bookmarklet.registry'),
    MANAGER: Symbol('vue.bookmarklet.manager'),
    SNAPSHOTS: Symbol('vue.bookmarklet.snapshots'),
    PERSISTENT_STATE: Symbol('vue.bookmarklet.persistentState'),
    WINDOW_STATE: Symbol('vue.bookmarklet.windowState'),
    INIT: Symbol('vue.bookmarklet.init'),
    LAUNCH: Symbol('vue.bookmarklet.launch'),
    DESTROY: Symbol('vue.bookmarklet.destroy'),
    DESTROY_ALL: Symbol('vue.bookmarklet.destroyAll'),
    GET_STATE: Symbol('vue.bookmarklet.getState'),
    GET_LIST: Symbol('vue.bookmarklet.getList'),
    SET_MODE: Symbol('vue.bookmarklet.setMode'),
    GET_MODE: Symbol('vue.bookmarklet.getMode'),
    SHOW: Symbol('vue.bookmarklet.show'),
    HIDE: Symbol('vue.bookmarklet.hide'),
    TOGGLE: Symbol('vue.bookmarklet.toggle'),
    TOGGLE_MAXIMIZE: Symbol('vue.bookmarklet.toggleMaximize'),
    IS_HIDDEN_CHECK: Symbol('vue.bookmarklet.isHiddenCheck'),
    IS_MAXIMIZED_CHECK: Symbol('vue.bookmarklet.isMaximizedCheck'),
    GET_CONTAINER: Symbol('vue.bookmarklet.getContainer'),
    CREATE_CONTAINER: Symbol('vue.bookmarklet.createContainer'),
    SHOW_ERROR: Symbol('vue.bookmarklet.showError'),
    UPDATE_STATUS: Symbol('vue.bookmarklet.updateStatus'),
    CHECK_STORE: Symbol('vue.bookmarklet.checkStore'),
    SETUP_DRAG: Symbol('vue.bookmarklet.setupDrag'),
    SETUP_RESIZE: Symbol('vue.bookmarklet.setupResize'),
    SETUP_FOCUS: Symbol('vue.bookmarklet.setupFocus'),
    EXPORT_SYMBOLS: Symbol('vue.bookmarklet.exportSymbols'),
    CLEANUP: Symbol('vue.bookmarklet.cleanup'),
    BEFORE_UNLOAD: Symbol('vue.bookmarklet.beforeUnload'),
    SAVE_PERSISTENT: Symbol('vue.bookmarklet.savePersistent'),
    LOAD_PERSISTENT: Symbol('vue.bookmarklet.loadPersistent'),
    CLEAR_PERSISTENT: Symbol('vue.bookmarklet.clearPersistent'),
    SAVE_WINDOW_STATE: Symbol('vue.bookmarklet.saveWindowState'),
    LOAD_WINDOW_STATE: Symbol('vue.bookmarklet.loadWindowState'),
    CLEAR_WINDOW_STATE: Symbol('vue.bookmarklet.clearWindowState'),
    SAVE_SNAPSHOT: Symbol('vue.bookmarklet.saveSnapshot'),
    LOAD_SNAPSHOT: Symbol('vue.bookmarklet.loadSnapshot'),
    LIST_SNAPSHOTS: Symbol('vue.bookmarklet.listSnapshots'),
    CLEAR_SNAPSHOTS: Symbol('vue.bookmarklet.clearSnapshots'),
    RESTORE_SNAPSHOT: Symbol('vue.bookmarklet.restoreSnapshot'),
    RESTORE_SNAPSHOT_DATA_ONLY: Symbol('vue.bookmarklet.restoreSnapshotDataOnly'),
    IS_VISIBLE: Symbol('vue.bookmarklet.isVisible'),
    FOCUS: Symbol('vue.bookmarklet.focus'),
    MOUNT_VUE: Symbol('vue.bookmarklet.mountVue'),
    STORE: Symbol('vue.bookmarklet.store'),
    STORE_SYMBOL: Symbol('vue.bookmarklet.storeSymbol'),
    LOGGER: Symbol('vue.bookmarklet.logger'),
    CONSUMER_TYPE: Symbol('vue.bookmarklet.consumerType'),
    LOAD_CONSUMER: Symbol('vue.bookmarklet.loadConsumer'),
    EXECUTE_LOADER: Symbol('vue.bookmarklet.executeLoader'),
    CLEAN_INVALID_MESSAGES: Symbol('vue.bookmarklet.cleanInvalidMessages'),
    SUBSCRIPTION: Symbol('vue.bookmarklet.subscription'),
  };

  // ============================================================
  // 6. ПУБЛИЧНЫЕ СИМВОЛЫ (доступны через Symbol.for)
  // ============================================================
  var PUBLIC = {
    INSTANCE: Symbol.for('vue.bookmarklet.instance'),
    STATE: Symbol.for('vue.bookmarklet.state'),
    CONFIG: Symbol.for('vue.bookmarklet.config'),
    MANAGER: Symbol.for('vue.bookmarklet.manager'),
    LAUNCH: Symbol.for('vue.bookmarklet.launch'),
    DESTROY: Symbol.for('vue.bookmarklet.destroy'),
    DESTROY_ALL: Symbol.for('vue.bookmarklet.destroyAll'),
    GET_STATE: Symbol.for('vue.bookmarklet.getState'),
    GET_LIST: Symbol.for('vue.bookmarklet.getList'),
    SET_MODE: Symbol.for('vue.bookmarklet.setMode'),
    GET_MODE: Symbol.for('vue.bookmarklet.getMode'),
    SHOW: Symbol.for('vue.bookmarklet.show'),
    HIDE: Symbol.for('vue.bookmarklet.hide'),
    TOGGLE: Symbol.for('vue.bookmarklet.toggle'),
    TOGGLE_MAXIMIZE: Symbol.for('vue.bookmarklet.toggleMaximize'),
    IS_HIDDEN: Symbol.for('vue.bookmarklet.isHidden'),
    IS_MAXIMIZED: Symbol.for('vue.bookmarklet.isMaximized'),
    GET_CONTAINER: Symbol.for('vue.bookmarklet.getContainer'),
    SAVE_SNAPSHOT: Symbol.for('vue.bookmarklet.saveSnapshot'),
    LOAD_SNAPSHOT: Symbol.for('vue.bookmarklet.loadSnapshot'),
    LIST_SNAPSHOTS: Symbol.for('vue.bookmarklet.listSnapshots'),
    CLEAR_SNAPSHOTS: Symbol.for('vue.bookmarklet.clearSnapshots'),
    RESTORE: Symbol.for('vue.bookmarklet.restore'),
    SAVE_PERSISTENT: Symbol.for('vue.bookmarklet.savePersistent'),
    LOAD_PERSISTENT: Symbol.for('vue.bookmarklet.loadPersistent'),
    CLEAR_PERSISTENT: Symbol.for('vue.bookmarklet.clearPersistent'),
    SAVE_WINDOW_STATE: Symbol.for('vue.bookmarklet.saveWindowState'),
    LOAD_WINDOW_STATE: Symbol.for('vue.bookmarklet.loadWindowState'),
    CLEAR_WINDOW_STATE: Symbol.for('vue.bookmarklet.clearWindowState'),
    FOCUS: Symbol.for('vue.bookmarklet.focus'),
  };

  // ============================================================
  // 7. КОНФИГУРАЦИЯ
  // ============================================================
  var CONFIG = {
    version: '7.3.2',
    build: '2026-07-26',
    name: 'Vue Bookmarklet',
    debug: true,
    containerWidth: 420,
    containerHeight: 520,
    containerMaxHeight: '80vh',
    modes: {
      SINGLETON: 'singleton',
      MULTI: 'multi',
      HYBRID: 'hybrid',
    },
    defaultMode: 'singleton',
    storageKey: 'vue_bookmarklet_mode',
    snapshotsKey: 'vue_bookmarklet_snapshots',
    persistentKey: 'vue_bookmarklet_persistent_state',
    windowStateKey: 'vue_bookmarklet_window_state',
    animationDuration: 300,
    maxSnapshots: 10,
    minWidth: 320,
    minHeight: 200,
    maxWidth: window.screen ? window.screen.width : 1200,
    maxHeight: window.screen ? window.screen.height : 800,
    zIndexBase: 999999,
    zIndexActive: 9999999,
  };

  var MODE = {
    SINGLETON: 'singleton',
    MULTI: 'multi',
    HYBRID: 'hybrid',
  };

  // ============================================================
  // 8. ЛОГГЕР (100% символы)
  // ============================================================
  var LOGGER_SYMBOLS = {
    HISTORY: Symbol('logger.history'),
    MAX_HISTORY: Symbol('logger.maxHistory'),
    DEBUG: Symbol('logger.debug'),
    INSTANCE_ID: Symbol('logger.instanceId'),
    LEVEL: Symbol('logger.level'),
  };

  function createLogger(debug, instanceId) {
    if (debug === undefined) debug = true;
    if (instanceId === undefined) instanceId = 'VueBookmarklet';
    var logState = {
      [LOGGER_SYMBOLS.HISTORY]: [],
      [LOGGER_SYMBOLS.MAX_HISTORY]: 200,
      [LOGGER_SYMBOLS.DEBUG]: debug,
      [LOGGER_SYMBOLS.INSTANCE_ID]: instanceId,
      [LOGGER_SYMBOLS.LEVEL]: debug ? 3 : 2,
    };
    var logMethod = function (level, message, data) {
      var levels = { error: 0, warn: 1, info: 2, debug: 3, success: 2 };
      var currentLevel = this[LOGGER_SYMBOLS.LEVEL] || 2;
      var msgLevel = levels[level] || 2;
      if (msgLevel > currentLevel) return;
      var timestamp = new Date().toISOString().slice(11, 23);
      var prefix = '[' + timestamp + '] [' + this[LOGGER_SYMBOLS.INSTANCE_ID] + ']';
      this[LOGGER_SYMBOLS.HISTORY].push({
        timestamp: timestamp,
        level: level,
        message: message,
        data: data || null,
        id: Date.now() + Math.random(),
      });
      if (this[LOGGER_SYMBOLS.HISTORY].length > this[LOGGER_SYMBOLS.MAX_HISTORY]) {
        this[LOGGER_SYMBOLS.HISTORY].shift();
      }
      var icons = { error: '❌', warn: '⚠️', info: 'ℹ️', debug: '🔍', success: '✅' };
      var icon = icons[level] || '📌';
      if (data !== null && data !== undefined) {
        console.log(icon + ' ' + prefix + ' ' + message, data);
      } else {
        console.log(icon + ' ' + prefix + ' ' + message);
      }
    };
    var boundLog = logMethod.bind(logState);
    var methods = {
      error: function (msg, d) {
        return boundLog('error', msg, d);
      },
      warn: function (msg, d) {
        return boundLog('warn', msg, d);
      },
      info: function (msg, d) {
        return boundLog('info', msg, d);
      },
      debug: function (msg, d) {
        return boundLog('debug', msg, d);
      },
      success: function (msg, d) {
        return boundLog('success', msg, d);
      },
      header: function (title, color) {
        if (color === undefined) color = '#636e72';
        var separator = '═'.repeat(70);
        console.log('%c' + separator, 'color: ' + color + ';');
        console.log(
          '%c  📦 ' + title,
          'background: #1a1a2e; color: #fff; padding: 4px 12px; border-radius: 4px; font-weight: bold;'
        );
        console.log('%c' + separator, 'color: ' + color + ';');
      },
      separator: function (color) {
        if (color === undefined) color = '#636e72';
        console.log('%c' + '─'.repeat(70), 'color: ' + color + ';');
      },
      getHistory: function () {
        return [...this[LOGGER_SYMBOLS.HISTORY]];
      },
      clearHistory: function () {
        this[LOGGER_SYMBOLS.HISTORY] = [];
        return this;
      },
      setDebug: function (enabled) {
        this[LOGGER_SYMBOLS.DEBUG] = enabled;
        this[LOGGER_SYMBOLS.LEVEL] = enabled ? 3 : 2;
        return this;
      },
    };
    var logger = {};
    var keys = Object.keys(methods);
    for (var i = 0; i < keys.length; i++) {
      var key = keys[i];
      logger[key] = methods[key].bind(logState);
    }
    logger[LOGGER_SYMBOLS.HISTORY] = logState[LOGGER_SYMBOLS.HISTORY];
    logger[LOGGER_SYMBOLS.MAX_HISTORY] = logState[LOGGER_SYMBOLS.MAX_HISTORY];
    logger[LOGGER_SYMBOLS.DEBUG] = logState[LOGGER_SYMBOLS.DEBUG];
    logger[LOGGER_SYMBOLS.INSTANCE_ID] = logState[LOGGER_SYMBOLS.INSTANCE_ID];
    logger[LOGGER_SYMBOLS.LEVEL] = logState[LOGGER_SYMBOLS.LEVEL];
    return logger;
  }

  var logger = createLogger(CONFIG.debug, 'VueBookmarklet');

  // ============================================================
  // 9. РЕЕСТР КОНСЮМЕРОВ
  // ============================================================
  if (!window.__VUE_CONSUMERS__) {
    window.__VUE_CONSUMERS__ = {
      singleton: null,
      instances: new Map(),
      hybridInstances: new Map(),
      mode: localStorage.getItem(CONFIG.storageKey) || CONFIG.defaultMode,
      launched: false,
      snapshots: new Map(),
      focusTimeout: null,
      activeId: null,
      subscription: null,
      baseUrl: baseUrl,
    };
  }

  var registry = window.__VUE_CONSUMERS__;

  // ============================================================
  // 10. СОХРАНЕНИЕ СОСТОЯНИЯ ОКНА
  // ============================================================
  function saveWindowState(consumerId, state) {
    try {
      var allStates = JSON.parse(localStorage.getItem(CONFIG.windowStateKey) || '{}');
      allStates[consumerId] = {
        left: state.left || 20,
        top: state.top || 20,
        width: state.width || CONFIG.containerWidth,
        height: state.height || CONFIG.containerHeight,
        isMaximized: state.isMaximized || false,
        timestamp: Date.now(),
      };
      localStorage.setItem(CONFIG.windowStateKey, JSON.stringify(allStates));
      logger.debug('💾 Состояние окна сохранено для ' + consumerId);
      return true;
    } catch (error) {
      logger.warn('⚠️ Не удалось сохранить состояние окна:', error);
      return false;
    }
  }

  function loadWindowState(consumerId) {
    try {
      var allStates = JSON.parse(localStorage.getItem(CONFIG.windowStateKey) || '{}');
      var state = allStates[consumerId];
      if (state) {
        logger.debug('📂 Состояние окна загружено для ' + consumerId);
        return state;
      }
    } catch (error) {
      logger.warn('⚠️ Не удалось загрузить состояние окна:', error);
    }
    return null;
  }

  function clearWindowState(consumerId) {
    try {
      var allStates = JSON.parse(localStorage.getItem(CONFIG.windowStateKey) || '{}');
      if (consumerId) {
        delete allStates[consumerId];
      } else {
        allStates = {};
      }
      localStorage.setItem(CONFIG.windowStateKey, JSON.stringify(allStates));
      logger.debug('🧹 Состояние окна очищено для ' + (consumerId || 'всех'));
      return true;
    } catch (error) {
      logger.warn('⚠️ Не удалось очистить состояние окна:', error);
      return false;
    }
  }

  // ============================================================
  // 11. ПОСТОЯННОЕ СОХРАНЕНИЕ ДАННЫХ
  // ============================================================
  function savePersistentState(data) {
    try {
      var stateData = {
        data: {
          liveMetrics: data.liveMetrics || [],
          totalBatches: data.totalBatches || 0,
          lastUpdate: data.lastUpdate || null,
          messages: data.messages || [],
          timestamp: Date.now(),
        },
        timestamp: Date.now(),
        version: CONFIG.version,
      };
      localStorage.setItem(CONFIG.persistentKey, JSON.stringify(stateData));
      logger.debug('💾 Постоянное состояние сохранено (без статуса)');
      return true;
    } catch (error) {
      logger.warn('⚠️ Не удалось сохранить постоянное состояние:', error);
      return false;
    }
  }

  function loadPersistentState() {
    try {
      var raw = localStorage.getItem(CONFIG.persistentKey);
      if (!raw) return null;
      var parsed = JSON.parse(raw);
      logger.debug('📂 Постоянное состояние загружено');
      var data = parsed.data || {};
      delete data.streamStatus;
      return data;
    } catch (error) {
      logger.warn('⚠️ Не удалось загрузить постоянное состояние:', error);
      return null;
    }
  }

  function clearPersistentState() {
    try {
      localStorage.removeItem(CONFIG.persistentKey);
      logger.debug('🧹 Постоянное состояние очищено');
      return true;
    } catch (error) {
      logger.warn('⚠️ Не удалось очистить постоянное состояние:', error);
      return false;
    }
  }

  // ============================================================
  // 12. СНАПШОТЫ
  // ============================================================
  function saveSnapshot(consumerId, data) {
    var snapshotId =
      'snapshot_' + Date.now().toString(36) + '_' + Math.random().toString(36).substr(2, 6);
    var snapshot = {
      id: snapshotId,
      consumerId: consumerId,
      data: {
        liveMetrics: data.liveMetrics || [],
        totalBatches: data.totalBatches || 0,
        lastUpdate: data.lastUpdate || null,
        messages: data.messages || [],
        timestamp: Date.now(),
      },
      timestamp: Date.now(),
      created: new Date().toISOString(),
      mode: registry.mode,
    };
    registry.snapshots.set(snapshotId, snapshot);
    try {
      var snapshotsList = JSON.parse(localStorage.getItem(CONFIG.snapshotsKey) || '[]');
      snapshotsList.push(snapshot);
      if (snapshotsList.length > CONFIG.maxSnapshots) {
        snapshotsList = snapshotsList.slice(-CONFIG.maxSnapshots);
      }
      localStorage.setItem(CONFIG.snapshotsKey, JSON.stringify(snapshotsList));
    } catch (error) {
      logger.warn('⚠️ Не удалось сохранить снапшот в localStorage:', error);
    }
    logger.success('📸 Снапшот сохранен (без статуса): ' + snapshotId);
    return snapshotId;
  }

  function loadSnapshot(snapshotId) {
    if (registry.snapshots.has(snapshotId)) {
      return registry.snapshots.get(snapshotId);
    }
    try {
      var snapshotsList = JSON.parse(localStorage.getItem(CONFIG.snapshotsKey) || '[]');
      var found = snapshotsList.find(function (s) {
        return s.id === snapshotId;
      });
      if (found) {
        registry.snapshots.set(snapshotId, found);
        return found;
      }
    } catch (error) {
      logger.warn('⚠️ Не удалось загрузить снапшот из localStorage:', error);
    }
    return null;
  }

  function listSnapshots() {
    var result = [];
    for (var entry of registry.snapshots) {
      result.push({
        id: entry[0],
        consumerId: entry[1].consumerId,
        created: entry[1].created,
        fields: Object.keys(entry[1].data || {}).length,
        mode: entry[1].mode,
      });
    }
    return result;
  }

  function clearSnapshots() {
    registry.snapshots.clear();
    try {
      localStorage.removeItem(CONFIG.snapshotsKey);
    } catch (error) {
      logger.warn('⚠️ Не удалось очистить снапшоты в localStorage:', error);
    }
    logger.success('🧹 Все снапшоты очищены');
    return true;
  }

  function restoreSnapshotDataOnly(snapshotId, targetConsumerId) {
    var snapshot = loadSnapshot(snapshotId);
    if (!snapshot) {
      logger.warn('⚠️ Снапшот не найден:', snapshotId);
      return false;
    }
    var data = snapshot.data;
    logger.info('🔄 Восстановление данных из снапшота (без статуса):', snapshotId);
    try {
      if (data.liveMetrics && data.liveMetrics.length > 0) {
        store.appendDataBatch(data.liveMetrics);
      }
      if (data.messages && data.messages.length > 0) {
        if (typeof store.replaceMessages === 'function') {
          store.replaceMessages(data.messages);
          logger.success('💬 Восстановлено ' + data.messages.length + ' сообщений (без отправки)');
        } else {
          var messages = data.messages.map(function (msg) {
            return { ...msg, _restored: true, _fromChannel: false, _processed: true };
          });
          var state = store.getState();
          if (state._messages) {
            state._messages = [...state._messages, ...messages];
          }
          logger.warn('⚠️ replaceMessages не доступен, используем fallback');
        }
      }
      logger.success('✅ Данные восстановлены из снапшота: ' + snapshotId);
      return true;
    } catch (error) {
      logger.error('❌ Ошибка восстановления данных из снапшота:', error);
      return false;
    }
  }

  // ============================================================
  // 13. ОЧИСТКА НЕКОРРЕКТНЫХ СООБЩЕНИЙ
  // ============================================================
  function cleanInvalidMessages() {
    try {
      var state = store.getState();
      if (!state || !state.messages || state.messages.length === 0) {
        return 0;
      }
      var invalidMessages = state.messages.filter(function (msg) {
        return (
          msg.text === 'undefined' ||
          msg.text === null ||
          msg.text === '' ||
          (typeof msg.text === 'string' && msg.text.trim() === '')
        );
      });
      if (invalidMessages.length === 0) {
        return 0;
      }
      logger.info(
        '🧹 Обнаружено ' + invalidMessages.length + ' некорректных сообщений, очищаем...'
      );
      var validMessages = state.messages.filter(function (msg) {
        return (
          msg.text !== 'undefined' &&
          msg.text !== null &&
          msg.text !== '' &&
          (typeof msg.text !== 'string' || msg.text.trim() !== '')
        );
      });
      if (typeof store.replaceMessages === 'function') {
        store.replaceMessages(validMessages);
        logger.success('🧹 Очищено ' + invalidMessages.length + ' некорректных сообщений');
      } else {
        store.clearMessages();
        for (var i = 0; i < validMessages.length; i++) {
          store.sendMessage(validMessages[i]);
        }
        logger.success(
          '🧹 Очищено ' + invalidMessages.length + ' некорректных сообщений (fallback)'
        );
      }
      return invalidMessages.length;
    } catch (error) {
      logger.warn('⚠️ Ошибка очистки некорректных сообщений:', error);
      return 0;
    }
  }

  // ============================================================
  // 14. ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ
  // ============================================================
  function isContainerVisible(container) {
    if (!container) return false;
    if (container.style.display === 'none') return false;
    if (container.style.opacity === '0') return false;
    if (container.dataset.isHidden === 'true') return false;
    return true;
  }

  function focusContainer(container, consumerId) {
    if (!container) return;

    if (consumerId) {
      registry.activeId = consumerId;
    }

    container.style.zIndex = CONFIG.zIndexActive;

    container.style.boxShadow = '0 0 60px rgba(59, 130, 246, 0.5)';
    container.style.borderColor = '#60a5fa';
    container.style.transition = 'box-shadow 0.3s ease, border-color 0.3s ease, z-index 0.1s ease';

    if (registry.focusTimeout) {
      clearTimeout(registry.focusTimeout);
    }

    registry.focusTimeout = setTimeout(function () {
      container.style.boxShadow = '0 8px 32px rgba(0,0,0,0.85)';
      container.style.borderColor = '#1e2633';
      registry.focusTimeout = null;
    }, 1000);

    var allContainers = document.querySelectorAll('[id^="vue-consumer-container-"]');
    for (var i = 0; i < allContainers.length; i++) {
      var el = allContainers[i];
      if (el !== container && el.dataset.consumerId !== consumerId) {
        var zIndex = parseInt(el.style.zIndex) || CONFIG.zIndexBase;
        if (zIndex > CONFIG.zIndexBase) {
          el.style.zIndex = CONFIG.zIndexBase;
        }
      }
    }
  }

  // ============================================================
  // 15. ФУНКЦИИ ДЛЯ SINGLETON
  // ============================================================
  function hideSingleton(consumerId) {
    var singleton = registry.singleton;
    if (!singleton) {
      logger.debug('ℹ️ Синглтон не существует, пропускаем скрытие');
      return true;
    }
    if (singleton.id !== consumerId) {
      logger.warn('⚠️ Синглтон не найден для скрытия:', consumerId);
      return false;
    }
    try {
      var state = store.getState();
      var snapshotData = {
        liveMetrics: state.liveMetrics || [],
        streamStatus: state.streamStatus || 'disconnected',
        totalBatches: state.totalBatches || 0,
        lastUpdate: state.lastUpdate || null,
        messages: state.messages || [],
        timestamp: Date.now(),
      };
      savePersistentState(snapshotData);
      saveSnapshot(consumerId, snapshotData);
      logger.success('💾 Состояние сохранено перед скрытием (без статуса)');
    } catch (error) {
      logger.warn('⚠️ Не удалось сохранить состояние:', error);
    }
    var container = document.getElementById('vue-consumer-container-' + consumerId);
    if (!container) {
      logger.warn('⚠️ Контейнер не найден для скрытия:', consumerId);
      return false;
    }
    container.style.opacity = '0';
    container.style.transform = 'scale(0.95)';
    container.dataset.isHidden = 'true';

    singleton.isHidden = true;
    singleton.hideTime = Date.now();

    setTimeout(function () {
      container.style.display = 'none';
    }, CONFIG.animationDuration);

    logger.success('🧹 [Singleton] Консюмер ' + consumerId + ' скрыт');

    var statusBadge = document.getElementById('vue-bookmarklet-status-' + consumerId);
    if (statusBadge) {
      statusBadge.textContent = '⏸ скрыт';
      statusBadge.style.color = '#4a5a7a';
      statusBadge.style.borderColor = 'rgba(74,90,122,0.2)';
    }

    if (registry.activeId === consumerId) {
      registry.activeId = null;
    }

    return true;
  }

  function showSingleton(consumerId) {
    var singleton = registry.singleton;
    if (!singleton || singleton.id !== consumerId) {
      logger.warn('⚠️ Синглтон не найден для показа:', consumerId);
      return false;
    }
    var container = document.getElementById('vue-consumer-container-' + consumerId);
    if (!container) {
      logger.warn('⚠️ Контейнер не найден для показа:', consumerId);
      return false;
    }

    focusContainer(container, consumerId);

    if (isContainerVisible(container)) {
      logger.info('ℹ️ [Singleton] Консюмер уже видим, фокусируем');
      return true;
    }

    container.style.display = 'block';
    container.style.opacity = '0';
    container.style.transform = 'scale(0.95)';
    container.dataset.isHidden = 'false';

    requestAnimationFrame(function () {
      container.style.opacity = '1';
      container.style.transform = 'scale(1)';
    });

    singleton.isHidden = false;
    singleton.hideTime = null;

    try {
      cleanInvalidMessages();
      var persistentState = loadPersistentState();
      if (persistentState) {
        if (persistentState.liveMetrics && persistentState.liveMetrics.length > 0) {
          store.appendDataBatch(persistentState.liveMetrics);
          logger.success('📊 Восстановлено ' + persistentState.liveMetrics.length + ' записей');
        }
        if (persistentState.messages && persistentState.messages.length > 0) {
          if (typeof store.replaceMessages === 'function') {
            store.replaceMessages(persistentState.messages);
            logger.success(
              '💬 Восстановлено ' + persistentState.messages.length + ' сообщений (без отправки)'
            );
          } else {
            var messages = persistentState.messages.map(function (msg) {
              return { ...msg, _restored: true, _fromChannel: false, _processed: true };
            });
            var state = store.getState();
            if (state._messages) {
              state._messages = [...state._messages, ...messages];
            }
            logger.warn('⚠️ replaceMessages не доступен, используем fallback');
          }
        }
        logger.success('✅ Данные восстановлены');
      } else {
        var snapshots = listSnapshots();
        var foundSnapshot = snapshots.find(function (s) {
          return s.consumerId === consumerId;
        });
        if (foundSnapshot) {
          restoreSnapshotDataOnly(foundSnapshot.id, consumerId);
          logger.info('🔄 Данные восстановлены из снапшота');
        }
      }
    } catch (error) {
      logger.warn('⚠️ Не удалось восстановить данные:', error);
    }

    store.setStatus('disconnected');
    logger.info('🔒 Статус установлен в "disconnected" (стриминг остановлен)');

    setTimeout(function () {
      focusContainer(container, consumerId);
    }, 400);

    logger.success('✅ [Singleton] Консюмер ' + consumerId + ' показан');

    updateStatusBadge(consumerId);

    return true;
  }

  function updateStatusBadge(consumerId) {
    var statusBadge = document.getElementById('vue-bookmarklet-status-' + consumerId);
    if (!statusBadge) return;

    var state = store.getState();
    var status = state.streamStatus || 'disconnected';
    var count = state.liveMetrics ? state.liveMetrics.length : 0;
    var statusMap = {
      playing: '▶ играет',
      paused: '⏸ пауза',
      disconnected: '⏹ отключен',
      connecting: '⟳ подключение...',
    };
    var statusClass = status;
    var statusText = statusMap[status] || status;
    statusBadge.className = 'consumer-status ' + statusClass;
    statusBadge.innerHTML =
      '<span class="dot" style="display:inline-block;width:6px;height:6px;border-radius:50%;background:' +
      (status === 'playing' ? '#34d399' : '#4a5a7a') +
      ';"></span>' +
      statusText +
      '<span class="count" style="font-weight:400;color:#8b96b0;font-size:10px;margin-left:2px;">(' +
      count +
      ' записей)</span>';
    statusBadge.style.color = status === 'playing' ? '#34d399' : '#4a5a7a';
    statusBadge.style.borderColor = status === 'playing' ? 'rgba(52,211,153,0.2)' : 'transparent';
  }

  function toggleSingletonVisibility(consumerId) {
    var singleton = registry.singleton;
    if (!singleton || singleton.id !== consumerId) return false;
    if (singleton.isHidden) {
      return showSingleton(consumerId);
    } else {
      return hideSingleton(consumerId);
    }
  }

  function isSingletonHidden(consumerId) {
    var singleton = registry.singleton;
    if (!singleton || (consumerId && singleton.id !== consumerId)) return false;
    return singleton.isHidden === true;
  }

  function getSingletonContainer(consumerId) {
    var singleton = registry.singleton;
    if (!singleton || (consumerId && singleton.id !== consumerId)) return null;
    return document.getElementById('vue-consumer-container-' + singleton.id);
  }

  // ============================================================
  // 16. УНИЧТОЖЕНИЕ
  // ============================================================
  function destroyConsumer(consumerId) {
    if (registry.singleton && registry.singleton.id === consumerId) {
      try {
        var state = store.getState();
        var snapshotData = {
          liveMetrics: state.liveMetrics || [],
          streamStatus: state.streamStatus || 'disconnected',
          totalBatches: state.totalBatches || 0,
          lastUpdate: state.lastUpdate || null,
          messages: state.messages || [],
          timestamp: Date.now(),
        };
        savePersistentState(snapshotData);
        saveSnapshot(consumerId, snapshotData);
        var container = document.getElementById('vue-consumer-container-' + consumerId);
        if (container) {
          saveWindowState(consumerId, {
            left: parseInt(container.style.left) || 20,
            top: parseInt(container.style.top) || 20,
            width: container.offsetWidth || CONFIG.containerWidth,
            height: container.offsetHeight || CONFIG.containerHeight,
            isMaximized: container.dataset.isMaximized === 'true',
          });
        }
      } catch (error) {
        logger.warn('⚠️ Не удалось сохранить состояние:', error);
      }
      return hideSingleton(consumerId);
    }
    if (registry.instances.has(consumerId)) {
      var entry = registry.instances.get(consumerId);
      try {
        if (entry.instance && typeof entry.instance.unmount === 'function') {
          entry.instance.unmount();
        }
        logger.success('🧹 [Multi] Консюмер ' + consumerId + ' уничтожен');
      } catch (error) {
        logger.warn('⚠️ Ошибка при уничтожении:', error);
      }
      registry.instances.delete(consumerId);
      var container = document.getElementById('vue-consumer-container-' + consumerId);
      if (container && container.parentNode) {
        container.parentNode.removeChild(container);
      }
      return true;
    }
    if (registry.hybridInstances && registry.hybridInstances.has(consumerId)) {
      var hybridEntry = registry.hybridInstances.get(consumerId);
      try {
        if (hybridEntry.instance && typeof hybridEntry.instance.unmount === 'function') {
          hybridEntry.instance.unmount();
        }
        logger.success('🧹 [Hybrid] Консюмер ' + consumerId + ' уничтожен');
      } catch (error) {
        logger.warn('⚠️ Ошибка при уничтожении:', error);
      }
      registry.hybridInstances.delete(consumerId);
      var container = document.getElementById('vue-consumer-container-' + consumerId);
      if (container && container.parentNode) {
        container.parentNode.removeChild(container);
      }
      return true;
    }
    logger.warn('⚠️ Консюмер ' + consumerId + ' не найден');
    return false;
  }

  function destroyAllConsumers() {
    var count = 0;
    if (registry.singleton) {
      try {
        var state = store.getState();
        var snapshotData = {
          liveMetrics: state.liveMetrics || [],
          streamStatus: state.streamStatus || 'disconnected',
          totalBatches: state.totalBatches || 0,
          lastUpdate: state.lastUpdate || null,
          messages: state.messages || [],
          timestamp: Date.now(),
        };
        savePersistentState(snapshotData);
        saveSnapshot(registry.singleton.id, snapshotData);
      } catch (error) {
        logger.warn('⚠️ Не удалось сохранить состояние:', error);
      }
      hideSingleton(registry.singleton.id);
      count++;
    }
    var entries = Array.from(registry.instances.entries());
    for (var i = 0; i < entries.length; i++) {
      var id = entries[i][0];
      var entry = entries[i][1];
      try {
        if (entry.instance && typeof entry.instance.unmount === 'function') {
          entry.instance.unmount();
        }
        count++;
      } catch (error) {
        logger.warn('⚠️ Ошибка при уничтожении ' + id + ':', error);
      }
      var container = document.getElementById('vue-consumer-container-' + id);
      if (container && container.parentNode) {
        container.parentNode.removeChild(container);
      }
    }
    registry.instances.clear();
    if (registry.hybridInstances) {
      registry.hybridInstances.clear();
    }
    logger.success('🧹 Уничтожено/скрыто ' + count + ' консюмеров');
    return count;
  }

  // ============================================================
  // 17. ИНФОРМАЦИЯ О СОСТОЯНИИ
  // ============================================================
  function getConsumerState() {
    var persistentState = loadPersistentState();
    return {
      mode: registry.mode,
      singleton: registry.singleton
        ? {
            id: registry.singleton.id,
            active: true,
            isHidden: registry.singleton.isHidden === true,
            containerId: registry.singleton.containerId,
            hasPersistentState: persistentState !== null,
          }
        : null,
      instances: Array.from(registry.instances.keys()),
      hybridInstances: registry.hybridInstances ? Array.from(registry.hybridInstances.keys()) : [],
      total:
        (registry.singleton ? 1 : 0) +
        registry.instances.size +
        (registry.hybridInstances ? registry.hybridInstances.size : 0),
      launched: registry.launched,
      snapshots: listSnapshots(),
      persistentState: persistentState
        ? {
            metricsCount: (persistentState.liveMetrics || []).length,
            messagesCount: (persistentState.messages || []).length,
            timestamp: persistentState.timestamp,
          }
        : null,
    };
  }

  function getConsumerList() {
    var list = [];
    if (registry.singleton) {
      list.push({
        id: registry.singleton.id,
        type: 'singleton',
        isHidden: registry.singleton.isHidden === true,
        containerId: registry.singleton.containerId,
        active: true,
        hasPersistentState: loadPersistentState() !== null,
      });
    }
    var entries = Array.from(registry.instances.entries());
    for (var i = 0; i < entries.length; i++) {
      var id = entries[i][0];
      var entry = entries[i][1];
      list.push({
        id: id,
        type: 'multi',
        containerId: entry.containerId,
        active: true,
        createdAt: entry.createdAt,
      });
    }
    if (registry.hybridInstances) {
      var hybridEntries = Array.from(registry.hybridInstances.entries());
      for (var j = 0; j < hybridEntries.length; j++) {
        var hid = hybridEntries[j][0];
        var hentry = hybridEntries[j][1];
        list.push({
          id: hid,
          type: 'hybrid',
          containerId: hentry.containerId,
          active: true,
          createdAt: hentry.createdAt,
          hasSnapshot: hentry.hasSnapshot || false,
        });
      }
    }
    return list;
  }

  // ============================================================
  // 18. ПОКАЗ ОШИБКИ
  // ============================================================
  function showErrorUI(error, containerId) {
    var container = document.getElementById(containerId || 'vue-consumer-content');
    if (container) {
      container.innerHTML =
        '<div style="text-align:center;padding:40px 20px;color:#ef4444;">' +
        '<div style="font-size:32px;margin-bottom:12px;">❌</div>' +
        '<div>Ошибка загрузки Vue Consumer</div>' +
        '<div style="font-size:12px;color:#4a5a7a;margin-top:8px;">' +
        (error.message || 'Неизвестная ошибка') +
        '</div>' +
        '</div>';
    }
    var statusBadge = document.getElementById('vue-bookmarklet-status');
    if (statusBadge) {
      statusBadge.textContent = '❌ ошибка';
      statusBadge.style.color = '#ef4444';
      statusBadge.style.borderColor = 'rgba(239,68,68,0.2)';
    }
  }

  // ============================================================
  // ★★★ 19. СОЗДАНИЕ КОНТЕЙНЕРА (100% РАСТЯЖЕНИЕ) ★★★
  // ============================================================
  function createContainer(consumerId, isSingleton, instanceIndex) {
    var containerId = 'vue-consumer-container-' + consumerId;
    var container = document.createElement('div');
    container.id = containerId;
    container.dataset.consumerId = consumerId;
    container.dataset.isSingleton = isSingleton ? 'true' : 'false';
    container.dataset.isHidden = 'false';
    container.dataset.isMaximized = 'false';

    // Загружаем сохраненное состояние окна
    var savedState = loadWindowState(consumerId);
    var offset = isSingleton ? 0 : instanceIndex || 0;

    var left = savedState ? savedState.left : 20 + (offset % 5) * 30;
    var top = savedState ? savedState.top : 20 + Math.floor(offset / 5) * 30;
    var width = savedState ? savedState.width : CONFIG.containerWidth;
    var height = savedState ? savedState.height : CONFIG.containerHeight;
    var isMaximized = savedState ? savedState.isMaximized : false;

    // ★★★ ОСНОВНОЕ ИЗМЕНЕНИЕ: контейнер — flex-контейнер с 100% высотой ★★★
    container.style.cssText =
      'position:fixed;' +
      'left:' +
      left +
      'px;' +
      'top:' +
      top +
      'px;' +
      'z-index:' +
      (CONFIG.zIndexBase + offset) +
      ';' +
      'width:' +
      width +
      'px;' +
      'height:' +
      height +
      'px;' +
      'min-width:' +
      CONFIG.minWidth +
      'px;' +
      'min-height:' +
      CONFIG.minHeight +
      'px;' +
      'max-width:100vw;' +
      'max-height:100vh;' +
      'background:#0b0e14;' +
      'border-radius:12px;' +
      'box-shadow:0 8px 32px rgba(0,0,0,0.85);' +
      'border:2px solid #1e2633;' +
      'overflow:hidden;' +
      'font-family:system-ui,-apple-system,sans-serif;' +
      'transition: opacity ' +
      CONFIG.animationDuration +
      'ms ease, transform ' +
      CONFIG.animationDuration +
      'ms ease;' +
      'display:flex;' +
      'flex-direction:column;' +
      'min-height:0;' +
      'min-width:0;' +
      'box-sizing:border-box;' +
      'opacity:1;';

    if (isMaximized) {
      container.style.width = '100vw';
      container.style.height = '100vh';
      container.style.left = '0';
      container.style.top = '0';
      container.style.borderRadius = '0';
      container.dataset.isMaximized = 'true';
    }

    document.body.appendChild(container);

    // Заголовок (фиксированная высота)
    var header = document.createElement('div');
    header.style.cssText =
      'display:flex;' +
      'justify-content:space-between;' +
      'align-items:center;' +
      'padding:8px 12px;' +
      'background:#131a24;' +
      'border-bottom:1px solid #1e2633;' +
      'cursor:move;' +
      'user-select:none;' +
      'min-height:36px;' +
      'flex-shrink:0;';

    var title = document.createElement('span');
    title.style.cssText =
      'font-size:13px;' +
      'font-weight:600;' +
      'color:#c8d0e0;' +
      'display:flex;' +
      'align-items:center;' +
      'gap:6px;';

    var modeLabel = '';
    if (registry.mode === MODE.HYBRID) {
      modeLabel = ' 🔄';
    } else if (registry.mode === MODE.SINGLETON) {
      modeLabel = ' 💾';
    }
    title.innerHTML =
      '🟢 Vue Consumer' + (isSingleton ? '' : ' #' + (instanceIndex + 1)) + modeLabel;

    var statusBadge = document.createElement('span');
    statusBadge.id = 'vue-bookmarklet-status-' + consumerId;
    statusBadge.className = 'consumer-status disconnected';
    statusBadge.style.cssText =
      'font-size:10px;' +
      'padding:2px 10px;' +
      'border-radius:20px;' +
      'background:#1e293b;' +
      'color:#4a5a7a;' +
      'transition:all 0.3s ease;' +
      'border:1px solid transparent;' +
      'display:inline-flex;' +
      'align-items:center;' +
      'gap:4px;' +
      'flex-shrink:0;' +
      'white-space:nowrap;';
    statusBadge.innerHTML =
      '<span class="dot" style="display:inline-block;width:6px;height:6px;border-radius:50%;background:#4a5a7a;"></span>⏹ Загрузка...';

    // Кнопки управления
    var controls = document.createElement('div');
    controls.style.cssText = 'display:flex;gap:4px;align-items:center;flex-shrink:0;';

    var maximizeBtn = document.createElement('button');
    maximizeBtn.className = 'bookmarklet-maximize-btn';
    maximizeBtn.innerHTML = isMaximized ? '⤡' : '⤢';
    maximizeBtn.title = isMaximized ? 'Свернуть' : 'Развернуть на весь экран';
    maximizeBtn.style.cssText =
      'background:transparent;' +
      'color:#4a5a7a;' +
      'border:none;' +
      'border-radius:4px;' +
      'width:24px;' +
      'height:24px;' +
      'cursor:pointer;' +
      'font-size:14px;' +
      'transition:all 0.2s ease;' +
      'display:flex;' +
      'align-items:center;' +
      'justify-content:center;';
    maximizeBtn.onmouseover = function () {
      this.style.color = '#60a5fa';
    };
    maximizeBtn.onmouseout = function () {
      this.style.color = '#4a5a7a';
    };

    var closeBtn = document.createElement('button');
    closeBtn.className = 'bookmarklet-close-btn';
    closeBtn.style.cssText =
      'background:#ef4444;' +
      'color:white;' +
      'border:none;' +
      'border-radius:50%;' +
      'width:24px;' +
      'height:24px;' +
      'cursor:pointer;' +
      'font-size:14px;' +
      'line-height:1;' +
      'display:flex;' +
      'align-items:center;' +
      'justify-content:center;' +
      'transition:all 0.2s ease;' +
      'flex-shrink:0;';
    closeBtn.textContent = '✕';
    closeBtn.title = isSingleton ? 'Скрыть Vue Consumer' : 'Закрыть Vue Consumer';
    closeBtn.onmouseover = function () {
      this.style.background = '#dc2626';
      this.style.transform = 'scale(1.1)';
    };
    closeBtn.onmouseout = function () {
      this.style.background = '#ef4444';
      this.style.transform = 'scale(1)';
    };

    controls.appendChild(maximizeBtn);
    controls.appendChild(closeBtn);

    var headerLeft = document.createElement('div');
    headerLeft.style.cssText = 'display:flex;align-items:center;gap:8px;';
    headerLeft.appendChild(title);
    headerLeft.appendChild(statusBadge);

    header.appendChild(headerLeft);
    header.appendChild(controls);
    container.appendChild(header);

    // ★★★ КОНТЕНТНАЯ ОБЛАСТЬ — flex: 1 (занимает всё оставшееся место) ★★★
    var contentContainer = document.createElement('div');
    contentContainer.id = 'vue-consumer-content-' + consumerId;
    contentContainer.style.cssText =
      'padding:8px;' +
      'flex:1;' +
      'min-height:0;' +
      'min-width:0;' +
      'overflow-y:auto;' +
      'overflow-x:hidden;' +
      'background:#0b0e14;' +
      'color:#c8d0e0;' +
      'position:relative;' +
      'display:flex;' +
      'flex-direction:column;' +
      'box-sizing:border-box;' +
      'width:100%;';
    container.appendChild(contentContainer);

    // ★★★ ВНУТРЕННИЙ КОНТЕЙНЕР ДЛЯ КОНСЮМЕРА ★★★
    var consumerWrapper = document.createElement('div');
    consumerWrapper.id = 'vue-consumer-wrapper-' + consumerId;
    consumerWrapper.style.cssText =
      'flex:1;' +
      'min-height:0;' +
      'min-width:0;' +
      'display:flex;' +
      'flex-direction:column;' +
      'width:100%;' +
      'height:100%;' +
      'overflow:hidden;' +
      'position:relative;' +
      'box-sizing:border-box;';
    contentContainer.appendChild(consumerWrapper);

    // Индикатор загрузки
    var loadingIndicator = document.createElement('div');
    loadingIndicator.style.cssText =
      'text-align:center;padding:40px 20px;color:#4a5a7a;font-size:14px;flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;';
    loadingIndicator.innerHTML =
      '<div style="font-size:32px;margin-bottom:12px;">⏳</div>' +
      '<div>Загрузка Vue Consumer...</div>' +
      '<div style="font-size:12px;color:#3a4a6a;margin-top:8px;">Подключение к хранилищу...</div>';
    consumerWrapper.appendChild(loadingIndicator);

    // Настройка взаимодействий
    setupDrag(container, header, consumerId);
    setupResize(container, consumerId);
    setupFocus(container, consumerId);

    // Обработчик кнопки развернуть/свернуть
    maximizeBtn.onclick = function () {
      toggleMaximize(container, consumerId);
    };

    // Обработчик закрытия
    closeBtn.onclick = function () {
      if (isSingleton) {
        try {
          var state = store.getState();
          var snapshotData = {
            liveMetrics: state.liveMetrics || [],
            streamStatus: state.streamStatus || 'disconnected',
            totalBatches: state.totalBatches || 0,
            lastUpdate: state.lastUpdate || null,
            messages: state.messages || [],
            timestamp: Date.now(),
          };
          savePersistentState(snapshotData);
          saveSnapshot(consumerId, snapshotData);
          saveWindowState(consumerId, {
            left: parseInt(container.style.left) || 20,
            top: parseInt(container.style.top) || 20,
            width: container.offsetWidth || CONFIG.containerWidth,
            height: container.offsetHeight || CONFIG.containerHeight,
            isMaximized: container.dataset.isMaximized === 'true',
          });
        } catch (error) {
          logger.warn('⚠️ Не удалось сохранить состояние:', error);
        }
        if (registry.singleton && registry.singleton.id === consumerId) {
          hideSingleton(consumerId);
        } else {
          var containerEl = document.getElementById(containerId);
          if (containerEl && containerEl.parentNode) {
            containerEl.parentNode.removeChild(containerEl);
          }
          logger.success('🧹 Контейнер удален (синглтон уже неактивен)');
        }
      } else if (registry.mode === MODE.HYBRID) {
        var state = store.getState();
        var snapshotData = {
          liveMetrics: state.liveMetrics || [],
          streamStatus: state.streamStatus || 'disconnected',
          totalBatches: state.totalBatches || 0,
          lastUpdate: state.lastUpdate || null,
          messages: state.messages || [],
          timestamp: Date.now(),
        };
        saveSnapshot(consumerId, snapshotData);
        destroyConsumer(consumerId);
      } else {
        destroyConsumer(consumerId);
      }
    };

    return {
      container: container,
      containerId: containerId,
      contentContainer: contentContainer,
      consumerWrapper: consumerWrapper,
      statusBadge: statusBadge,
      header: header,
      closeBtn: closeBtn,
      maximizeBtn: maximizeBtn,
    };
  }

  // ============================================================
  // 20. НАСТРОЙКА ПЕРЕТАСКИВАНИЯ
  // ============================================================
  function setupDrag(container, header, consumerId) {
    var isDragging = false;
    var dragStartX = 0;
    var dragStartY = 0;

    header.addEventListener('mousedown', function (e) {
      if (e.target.closest('.bookmarklet-close-btn')) return;
      if (e.target.closest('.bookmarklet-maximize-btn')) return;
      isDragging = true;
      var rect = container.getBoundingClientRect();
      dragStartX = e.clientX - rect.left;
      dragStartY = e.clientY - rect.top;
      container.style.cursor = 'grabbing';
      e.preventDefault();

      if (consumerId) {
        focusContainer(container, consumerId);
      }
    });

    document.addEventListener('mousemove', function (e) {
      if (!isDragging) return;
      var x = e.clientX - dragStartX;
      var y = e.clientY - dragStartY;
      container.style.left = x + 'px';
      container.style.top = y + 'px';
      container.style.right = 'auto';
      container.style.bottom = 'auto';
    });

    document.addEventListener('mouseup', function () {
      if (isDragging) {
        isDragging = false;
        container.style.cursor = 'default';
        // Сохраняем позицию
        saveWindowState(consumerId, {
          left: parseInt(container.style.left) || 20,
          top: parseInt(container.style.top) || 20,
          width: container.offsetWidth || CONFIG.containerWidth,
          height: container.offsetHeight || CONFIG.containerHeight,
          isMaximized: container.dataset.isMaximized === 'true',
        });
      }
    });
  }

  // ============================================================
  // ★★★ 21. НАСТРОЙКА РЕСАЙЗА (ОБНОВЛЕНА) ★★★
  // ============================================================
  function setupResize(container, consumerId) {
    var resizeHandle = document.createElement('div');
    resizeHandle.style.cssText =
      'position:absolute;' +
      'bottom:0;' +
      'right:0;' +
      'width:14px;' +
      'height:14px;' +
      'cursor:se-resize;' +
      'z-index:100;' +
      'opacity:0.3;' +
      'transition:opacity 0.2s;' +
      'display:flex;' +
      'align-items:flex-end;' +
      'justify-content:flex-end;' +
      'padding:2px;';
    resizeHandle.onmouseover = function () {
      this.style.opacity = '1';
    };
    resizeHandle.onmouseout = function () {
      this.style.opacity = '0.3';
    };

    var grip = document.createElement('div');
    grip.style.cssText =
      'width:8px;' +
      'height:8px;' +
      'border-right:2px solid #4a5a7a;' +
      'border-bottom:2px solid #4a5a7a;' +
      'border-radius:0 0 4px 0;';
    resizeHandle.appendChild(grip);
    container.appendChild(resizeHandle);

    var isResizing = false;
    var startX = 0;
    var startY = 0;
    var startWidth = 0;
    var startHeight = 0;

    resizeHandle.addEventListener('mousedown', function (e) {
      isResizing = true;
      startX = e.clientX;
      startY = e.clientY;
      startWidth = container.offsetWidth;
      startHeight = container.offsetHeight;
      container.style.cursor = 'se-resize';
      document.body.style.userSelect = 'none';
      e.preventDefault();
      e.stopPropagation();
    });

    document.addEventListener('mousemove', function (e) {
      if (!isResizing) return;

      var deltaX = e.clientX - startX;
      var deltaY = e.clientY - startY;

      var newWidth = Math.max(CONFIG.minWidth, Math.min(CONFIG.maxWidth, startWidth + deltaX));
      var newHeight = Math.max(CONFIG.minHeight, Math.min(CONFIG.maxHeight, startHeight + deltaY));

      container.style.width = newWidth + 'px';
      container.style.height = newHeight + 'px';

      // ★★★ ПРИНУДИТЕЛЬНО ОБНОВЛЯЕМ ВНУТРЕННИЙ КОНТЕЙНЕР ★★★
      var wrapper = container.querySelector('[id^="vue-consumer-wrapper-"]');
      if (wrapper) {
        wrapper.style.width = '100%';
        wrapper.style.height = '100%';
        wrapper.style.flex = '1';
        wrapper.style.minHeight = '0';
      }

      // Триггерим событие ресайза для React/Vue компонентов
      var resizeEvent = new CustomEvent('consumer-resize', {
        detail: {
          width: newWidth,
          height: newHeight,
          consumerId: consumerId,
        },
      });
      container.dispatchEvent(resizeEvent);
      window.dispatchEvent(resizeEvent);

      // Сохраняем промежуточное состояние
      saveWindowState(consumerId, {
        left: parseInt(container.style.left) || 20,
        top: parseInt(container.style.top) || 20,
        width: newWidth,
        height: newHeight,
        isMaximized: container.dataset.isMaximized === 'true',
      });
    });

    document.addEventListener('mouseup', function () {
      if (isResizing) {
        isResizing = false;
        container.style.cursor = 'default';
        document.body.style.userSelect = '';
      }
    });
  }

  // ============================================================
  // 22. НАСТРОЙКА ФОКУСА
  // ============================================================
  function setupFocus(container, consumerId) {
    container.addEventListener('click', function () {
      focusContainer(container, consumerId);
    });
  }

  // ============================================================
  // 23. РАЗВЕРНУТЬ/СВЕРНУТЬ
  // ============================================================
  function toggleMaximize(container, consumerId) {
    var isMaximized = container.dataset.isMaximized === 'true';
    var maximizeBtn = container.querySelector('.bookmarklet-maximize-btn');

    if (!isMaximized) {
      container.dataset.prevWidth = container.offsetWidth;
      container.dataset.prevHeight = container.offsetHeight;
      container.dataset.prevLeft = container.style.left || 'auto';
      container.dataset.prevTop = container.style.top || 'auto';

      container.style.width = '100vw';
      container.style.height = '100vh';
      container.style.maxWidth = '100vw';
      container.style.maxHeight = '100vh';
      container.style.left = '0';
      container.style.top = '0';
      container.style.right = '0';
      container.style.bottom = '0';
      container.style.borderRadius = '0';
      container.dataset.isMaximized = 'true';

      if (maximizeBtn) {
        maximizeBtn.innerHTML = '⤡';
        maximizeBtn.title = 'Свернуть';
      }

      focusContainer(container, consumerId);

      // Обновляем внутренний контейнер
      var wrapper = container.querySelector('[id^="vue-consumer-wrapper-"]');
      if (wrapper) {
        wrapper.style.width = '100%';
        wrapper.style.height = '100%';
      }

      logger.info('⤢ Консюмер ' + consumerId + ' развернут на весь экран');
    } else {
      var prevWidth = parseInt(container.dataset.prevWidth) || CONFIG.containerWidth;
      var prevHeight = parseInt(container.dataset.prevHeight) || CONFIG.containerHeight;
      var prevLeft = container.dataset.prevLeft || '20px';
      var prevTop = container.dataset.prevTop || '20px';

      container.style.width = prevWidth + 'px';
      container.style.height = prevHeight + 'px';
      container.style.maxWidth = '100vw';
      container.style.maxHeight = '100vh';
      container.style.left = prevLeft;
      container.style.top = prevTop;
      container.style.right = 'auto';
      container.style.bottom = 'auto';
      container.style.borderRadius = '12px';
      container.dataset.isMaximized = 'false';

      if (maximizeBtn) {
        maximizeBtn.innerHTML = '⤢';
        maximizeBtn.title = 'Развернуть на весь экран';
      }

      // Обновляем внутренний контейнер
      var wrapper = container.querySelector('[id^="vue-consumer-wrapper-"]');
      if (wrapper) {
        wrapper.style.width = '100%';
        wrapper.style.height = '100%';
      }

      saveWindowState(consumerId, {
        left: parseInt(prevLeft) || 20,
        top: parseInt(prevTop) || 20,
        width: prevWidth,
        height: prevHeight,
        isMaximized: false,
      });

      logger.info('⤡ Консюмер ' + consumerId + ' свернут');
    }
  }

  // ============================================================
  // 24. ЗАГРУЗКА И ВЫПОЛНЕНИЕ VUE CONSUMER
  // ============================================================
  async function loadAndExecuteVueConsumer(mode) {
    var targetMode = mode || registry.mode || CONFIG.defaultMode;
    var isSingleton = targetMode === MODE.SINGLETON;
    try {
      logger.info('📥 Загрузка Vue консюмера (режим: ' + targetMode + ')...');
      cleanInvalidMessages();

      if (isSingleton && registry.singleton) {
        var existingId = registry.singleton.id;
        var existingContainer = document.getElementById('vue-consumer-container-' + existingId);

        if (existingContainer) {
          if (registry.singleton.isHidden || existingContainer.style.display === 'none') {
            logger.info('🔄 [Singleton] Синглтон скрыт, показываем...');
            showSingleton(existingId);
          } else {
            logger.info('🔄 [Singleton] Синглтон уже видим, фокусируем...');
            focusContainer(existingContainer, existingId);
            updateStatusBadge(existingId);
          }
          return {
            id: existingId,
            mode: MODE.SINGLETON,
            restored: true,
            action: 'shown',
          };
        } else {
          logger.warn('⚠️ [Singleton] Контейнер не найден в DOM, создаем новый');
          registry.singleton = null;
        }
      }

      if (
        targetMode === MODE.HYBRID &&
        registry.hybridInstances &&
        registry.hybridInstances.size > 0
      ) {
        var entries = Array.from(registry.hybridInstances.entries());
        for (var i = entries.length - 1; i >= 0; i--) {
          var hid = entries[i][0];
          var hentry = entries[i][1];
          if (hentry.isHidden) {
            var container = document.getElementById('vue-consumer-container-' + hid);
            if (container) {
              container.style.display = 'block';
              container.style.opacity = '0';
              container.style.transform = 'scale(0.95)';
              container.dataset.isHidden = 'false';
              requestAnimationFrame(function () {
                container.style.opacity = '1';
                container.style.transform = 'scale(1)';
              });
              hentry.isHidden = false;
              var snapshots = listSnapshots();
              var foundSnapshot = snapshots.find(function (s) {
                return s.consumerId === hid;
              });
              if (foundSnapshot) {
                restoreSnapshotDataOnly(foundSnapshot.id, hid);
              }
              focusContainer(container, hid);
              updateStatusBadge(hid);
              logger.success('✅ [Hybrid] Экземпляр ' + hid + ' восстановлен');
              return { id: hid, mode: MODE.HYBRID, restored: true, action: 'shown' };
            }
          }
        }
      }

      var persistentState = null;
      var hasPersistentState = false;
      if (isSingleton) {
        persistentState = loadPersistentState();
        hasPersistentState = persistentState !== null;
        if (persistentState) {
          logger.info('🔄 [Singleton] Найдено сохраненное состояние, данные будут восстановлены');
        }
      }

      var consumerId =
        'vue_' + Date.now().toString(36) + '_' + Math.random().toString(36).substr(2, 6);
      var instanceIndex = isSingleton ? 0 : registry.instances.size;
      var containerData = createContainer(consumerId, isSingleton, instanceIndex);

      if (hasPersistentState && persistentState) {
        try {
          if (persistentState.liveMetrics && persistentState.liveMetrics.length > 0) {
            store.appendDataBatch(persistentState.liveMetrics);
            logger.success('📊 Восстановлено ' + persistentState.liveMetrics.length + ' записей');
          }
          if (persistentState.messages && persistentState.messages.length > 0) {
            if (typeof store.replaceMessages === 'function') {
              store.replaceMessages(persistentState.messages);
              logger.success(
                '💬 Восстановлено ' + persistentState.messages.length + ' сообщений (без отправки)'
              );
            } else {
              var messages = persistentState.messages.map(function (msg) {
                return { ...msg, _restored: true, _fromChannel: false, _processed: true };
              });
              var state = store.getState();
              if (state._messages) {
                state._messages = [...state._messages, ...messages];
              }
              logger.warn('⚠️ replaceMessages не доступен, используем fallback');
            }
          }
          logger.success('✅ Данные восстановлены');
        } catch (error) {
          logger.warn('⚠️ Ошибка восстановления данных:', error);
        }
      }

      store.setStatus('disconnected');
      logger.info('🔒 Статус установлен в "disconnected" (стриминг остановлен)');

      var module = await import(baseUrl + '/src/consumers/vue-consumer.js');
      var mountVueConsumer = module.mountVueConsumer || module.default;

      if (!mountVueConsumer) {
        throw new Error('mountVueConsumer не найден в модуле');
      }

      var statusBadge = containerData.statusBadge;
      if (statusBadge) {
        statusBadge.innerHTML =
          '<span class="dot" style="display:inline-block;width:6px;height:6px;border-radius:50%;background:#60a5fa;"></span>⟳ подключение...';
        statusBadge.style.color = '#60a5fa';
        statusBadge.style.borderColor = 'rgba(96,165,250,0.2)';
      }

      var consumerWrapper = containerData.consumerWrapper;

      var consumer = mountVueConsumer(consumerWrapper, {
        store: store,
        consumerId: consumerId,
        onMount: function (instance) {
          console.log('✅ [VueBookmarklet] Консюмер смонтирован:', consumerId);
          updateStatusBadge(consumerId);
          window.__VUE_CONSUMER_INSTANCE__ = instance;
        },
        onError: function (error) {
          console.error('❌ [VueBookmarklet] Ошибка:', error);
          if (statusBadge) {
            statusBadge.innerHTML =
              '<span class="dot" style="display:inline-block;width:6px;height:6px;border-radius:50%;background:#ef4444;"></span>❌ ошибка';
            statusBadge.style.color = '#ef4444';
            statusBadge.style.borderColor = 'rgba(239,68,68,0.2)';
          }
        },
      });

      if (!consumer) {
        throw new Error('Не удалось создать консюмер');
      }

      window.__VUE_CONSUMER_ACTIVE__ = true;
      window.__VUE_CONSUMER_UNMOUNT__ = consumer.unmount;

      // ★★★ ПОДПИСКА НА ОБНОВЛЕНИЯ (без поллинга) ★★★
      var unsubscribe = store.subscribe(function (state) {
        updateStatusBadge(consumerId);
        if (
          window.__VUE_CONSUMER_INSTANCE__ &&
          typeof window.__VUE_CONSUMER_INSTANCE__.forceUpdate === 'function'
        ) {
          try {
            window.__VUE_CONSUMER_INSTANCE__.forceUpdate();
          } catch (e) {}
        }
      });

      window.__VUE_CONSUMER_UNSUBSCRIBE__ = unsubscribe;

      if (isSingleton) {
        registry.mode = MODE.SINGLETON;
        localStorage.setItem(CONFIG.storageKey, MODE.SINGLETON);
        registry.singleton = {
          id: consumerId,
          instance: consumer,
          containerId: containerData.containerId,
          isHidden: false,
          hideTime: null,
          createdAt: Date.now(),
          isMaximized: false,
        };
      } else if (targetMode === MODE.HYBRID) {
        registry.mode = MODE.HYBRID;
        localStorage.setItem(CONFIG.storageKey, MODE.HYBRID);
        if (!registry.hybridInstances) {
          registry.hybridInstances = new Map();
        }
        registry.hybridInstances.set(consumerId, {
          id: consumerId,
          instance: consumer,
          containerId: containerData.containerId,
          createdAt: Date.now(),
          isHidden: false,
          hasSnapshot: false,
          index: registry.hybridInstances.size,
          isMaximized: false,
        });
      } else {
        registry.mode = MODE.MULTI;
        localStorage.setItem(CONFIG.storageKey, MODE.MULTI);
        registry.instances.set(consumerId, {
          id: consumerId,
          instance: consumer,
          containerId: containerData.containerId,
          createdAt: Date.now(),
          index: registry.instances.size,
          isMaximized: false,
        });
      }

      registry.launched = true;
      registry.activeId = consumerId;

      setTimeout(function () {
        focusContainer(containerData.container, consumerId);
        updateStatusBadge(consumerId);
      }, 500);

      logger.success('✅ [Singleton] Консюмер ' + consumerId + ' создан');
      if (hasPersistentState) {
        logger.success('💾 Данные восстановлены из постоянного хранилища');
      }

      return {
        id: consumerId,
        mode: registry.mode,
        containerId: containerData.containerId,
        action: 'created',
      };
    } catch (error) {
      logger.error('❌ Ошибка загрузки Vue консюмера:', error);
      showErrorUI(error);
      return null;
    }
  }

  // ============================================================
  // 25. МЕНЕДЖЕР
  // ============================================================
  var Manager = {
    MODE: MODE,

    getMode: function () {
      return registry.mode;
    },

    setMode: function (mode) {
      if (mode === MODE.SINGLETON || mode === MODE.MULTI || mode === MODE.HYBRID) {
        registry.mode = mode;
        localStorage.setItem(CONFIG.storageKey, mode);
        logger.success('🔄 Режим переключен на: ' + mode);
        return true;
      }
      return false;
    },

    launch: async function (mode) {
      var targetMode = mode || registry.mode;
      return await loadAndExecuteVueConsumer(targetMode);
    },

    destroy: destroyConsumer,
    destroyAll: destroyAllConsumers,
    info: getConsumerState,
    list: getConsumerList,

    getSingleton: function () {
      return registry.singleton;
    },
    getInstances: function () {
      return Array.from(registry.instances.entries());
    },
    getHybridInstances: function () {
      return registry.hybridInstances ? Array.from(registry.hybridInstances.entries()) : [];
    },

    isSingletonMode: function () {
      return registry.mode === MODE.SINGLETON;
    },
    isMultiMode: function () {
      return registry.mode === MODE.MULTI;
    },
    isHybridMode: function () {
      return registry.mode === MODE.HYBRID;
    },

    show: function (consumerId) {
      if (!consumerId) {
        if (registry.singleton) {
          consumerId = registry.singleton.id;
        } else {
          logger.warn('⚠️ Нет активного синглтона для показа');
          return false;
        }
      }
      return showSingleton(consumerId);
    },

    hide: function (consumerId) {
      if (!consumerId) {
        if (registry.singleton) {
          consumerId = registry.singleton.id;
        } else {
          logger.warn('⚠️ Нет активного синглтона для скрытия');
          return false;
        }
      }
      return hideSingleton(consumerId);
    },

    toggle: function (consumerId) {
      if (!consumerId) {
        if (registry.singleton) {
          consumerId = registry.singleton.id;
        } else {
          logger.warn('⚠️ Нет активного синглтона для переключения');
          return false;
        }
      }
      return toggleSingletonVisibility(consumerId);
    },

    toggleMaximize: function (consumerId) {
      var container = null;
      if (registry.singleton && registry.singleton.id === consumerId) {
        container = document.getElementById('vue-consumer-container-' + consumerId);
      } else if (registry.instances.has(consumerId)) {
        container = document.getElementById('vue-consumer-container-' + consumerId);
      } else if (registry.hybridInstances && registry.hybridInstances.has(consumerId)) {
        container = document.getElementById('vue-consumer-container-' + consumerId);
      }
      if (container) {
        toggleMaximize(container, consumerId);
        return true;
      }
      return false;
    },

    isHidden: function (consumerId) {
      return isSingletonHidden(consumerId);
    },

    isMaximized: function (consumerId) {
      var container = null;
      if (registry.singleton && registry.singleton.id === consumerId) {
        container = document.getElementById('vue-consumer-container-' + consumerId);
      } else if (registry.instances.has(consumerId)) {
        container = document.getElementById('vue-consumer-container-' + consumerId);
      } else if (registry.hybridInstances && registry.hybridInstances.has(consumerId)) {
        container = document.getElementById('vue-consumer-container-' + consumerId);
      }
      return container ? container.dataset.isMaximized === 'true' : false;
    },

    getContainer: function (consumerId) {
      return getSingletonContainer(consumerId);
    },

    saveSnapshot: function (consumerId) {
      if (!consumerId) {
        if (registry.singleton) {
          consumerId = registry.singleton.id;
        } else {
          logger.warn('⚠️ Нет активного консюмера для сохранения снапшота');
          return null;
        }
      }
      try {
        var state = store.getState();
        var snapshotData = {
          liveMetrics: state.liveMetrics || [],
          streamStatus: state.streamStatus || 'disconnected',
          totalBatches: state.totalBatches || 0,
          lastUpdate: state.lastUpdate || null,
          messages: state.messages || [],
          timestamp: Date.now(),
        };
        return saveSnapshot(consumerId, snapshotData);
      } catch (error) {
        logger.error('❌ Ошибка сохранения снапшота:', error);
        return null;
      }
    },

    loadSnapshot: function (snapshotId, consumerId) {
      return restoreSnapshotDataOnly(snapshotId, consumerId);
    },

    listSnapshots: listSnapshots,
    clearSnapshots: clearSnapshots,

    restore: function (snapshotId) {
      var snapshot = loadSnapshot(snapshotId);
      if (!snapshot) {
        logger.warn('⚠️ Снапшот не найден:', snapshotId);
        return false;
      }
      return restoreSnapshotDataOnly(snapshotId, snapshot.consumerId);
    },

    savePersistent: function () {
      try {
        var state = store.getState();
        var snapshotData = {
          liveMetrics: state.liveMetrics || [],
          streamStatus: state.streamStatus || 'disconnected',
          totalBatches: state.totalBatches || 0,
          lastUpdate: state.lastUpdate || null,
          messages: state.messages || [],
          timestamp: Date.now(),
        };
        return savePersistentState(snapshotData);
      } catch (error) {
        logger.error('❌ Ошибка сохранения постоянного состояния:', error);
        return false;
      }
    },

    loadPersistent: function () {
      return loadPersistentState();
    },
    clearPersistent: function () {
      return clearPersistentState();
    },
    hasPersistent: function () {
      return loadPersistentState() !== null;
    },

    saveWindowState: function (consumerId) {
      var container = document.getElementById('vue-consumer-container-' + consumerId);
      if (container) {
        return saveWindowState(consumerId, {
          left: parseInt(container.style.left) || 20,
          top: parseInt(container.style.top) || 20,
          width: container.offsetWidth || CONFIG.containerWidth,
          height: container.offsetHeight || CONFIG.containerHeight,
          isMaximized: container.dataset.isMaximized === 'true',
        });
      }
      return false;
    },

    loadWindowState: function (consumerId) {
      return loadWindowState(consumerId);
    },

    clearWindowState: function (consumerId) {
      return clearWindowState(consumerId);
    },

    focus: function (consumerId) {
      if (!consumerId) {
        if (registry.singleton) {
          consumerId = registry.singleton.id;
        } else {
          logger.warn('⚠️ Нет активного консюмера для фокусировки');
          return false;
        }
      }
      var container = document.getElementById('vue-consumer-container-' + consumerId);
      if (container) {
        focusContainer(container, consumerId);
        return true;
      }
      return false;
    },

    cleanInvalidMessages: function () {
      return cleanInvalidMessages();
    },
  };

  // ============================================================
  // 26. РЕГИСТРАЦИЯ В ГЛОБАЛЬНОМ ОБЪЕКТЕ
  // ============================================================
  window.__VueConsumerManager = Manager;
  window.__VUE_BOOKMARKLET_SYMBOLS__ = {
    PRIVATE: { ...PRIVATE },
    PUBLIC: { ...PUBLIC },
  };

  // ============================================================
  // 27. АВТОМАТИЧЕСКАЯ ОЧИСТКА
  // ============================================================
  var beforeUnloadHandler = function () {
    try {
      var state = store.getState();
      var snapshotData = {
        liveMetrics: state.liveMetrics || [],
        streamStatus: state.streamStatus || 'disconnected',
        totalBatches: state.totalBatches || 0,
        lastUpdate: state.lastUpdate || null,
        messages: state.messages || [],
        timestamp: Date.now(),
      };
      if (registry.singleton) {
        savePersistentState(snapshotData);
        saveSnapshot(registry.singleton.id, snapshotData);
        var container = document.getElementById('vue-consumer-container-' + registry.singleton.id);
        if (container) {
          saveWindowState(registry.singleton.id, {
            left: parseInt(container.style.left) || 20,
            top: parseInt(container.style.top) || 20,
            width: container.offsetWidth || CONFIG.containerWidth,
            height: container.offsetHeight || CONFIG.containerHeight,
            isMaximized: container.dataset.isMaximized === 'true',
          });
        }
      }
    } catch (error) {}
    destroyAllConsumers();
    delete window.__VUE_CONSUMER_ACTIVE__;
    delete window.__VUE_CONSUMER_UNMOUNT__;
    delete window.__VUE_CONSUMER_UNSUBSCRIBE__;
  };

  window.addEventListener('beforeunload', beforeUnloadHandler);
  window.__VUE_BOOKMARKLET_CLEANUP__ = beforeUnloadHandler;

  // ============================================================
  // 28. ЗАПУСК
  // ============================================================
  loadAndExecuteVueConsumer(registry.mode);

  // ============================================================
  // 29. КОНСОЛЬНЫЙ ИНТЕРФЕЙС
  // ============================================================
  console.log('╔═══════════════════════════════════════════════════════════════════════════════╗');
  console.log('║              📦 VUE BOOKMARKLET (100% СИМВОЛЫ) v7.3.2                       ║');
  console.log('╠═══════════════════════════════════════════════════════════════════════════════╣');
  console.log('║  📡 Только подписка на обновления (БЕЗ ПОЛЛИНГА)                             ║');
  console.log('║  ⤢ Кнопка развернуть/свернуть на весь экран                                 ║');
  console.log('║  🔍 Фокус: клик по окну поднимает z-index                                    ║');
  console.log('║  📐 Ресайз: тяните за правый нижний угол (увеличение)                       ║');
  console.log('║  💾 Сохранение позиции и размеров окна в localStorage                        ║');
  console.log('║  📂 Загрузка истории из localStorage                                         ║');
  console.log('║  🔑 Полная изоляция через приватные символы                                 ║');
  console.log('║  🔓 Публичные символы через Symbol.for                                      ║');
  console.log('║  📦 ТРИ режима работы: Singleton, Multi, Hybrid                             ║');
  console.log('║  💾 Singleton: постоянное сохранение состояния (localStorage)                ║');
  console.log('║  🔄 Singleton: автоматическое восстановление при повторном открытии          ║');
  console.log('║  📸 Hybrid: сохранение снапшотов и восстановление состояния                  ║');
  console.log('║  🚫 СТРИМИНГ НЕ ЗАПУСКАЕТСЯ АВТОМАТИЧЕСКИ                                  ║');
  console.log('║  🔒 Статус всегда "disconnected" при открытии/показе                        ║');
  console.log('║  ▶️ Только по кнопке "Старт" в интерфейсе                                   ║');
  console.log('║  💾 Сохраняются только данные, статус НЕ сохраняется                        ║');
  console.log('║  🧹 АВТОМАТИЧЕСКАЯ ОЧИСТКА НЕКОРРЕКТНЫХ СООБЩЕНИЙ                          ║');
  console.log('║  🛡️ ЗАЩИТА ОТ БЕСКОНЕЧНОЙ ПЕРЕСЫЛКИ СООБЩЕНИЙ                               ║');
  console.log('║  📐 100% РАСТЯЖЕНИЕ КОНТЕЙНЕРА (flex: 1)                                    ║');
  console.log('║  🔄 АВТОМАТИЧЕСКОЕ ОБНОВЛЕНИЕ ПРИ РЕСАЙЗЕ                                  ║');
  console.log('║  🎯 Полное управление через window.__VueConsumerManager                     ║');
  console.log('╚═══════════════════════════════════════════════════════════════════════════════╝');

  console.log('📋 УПРАВЛЕНИЕ КОНСЮМЕРАМИ:');
  console.log('  window.__VueConsumerManager.launch() - запустить/показать');
  console.log('  window.__VueConsumerManager.launch("singleton") - запустить в singleton');
  console.log('  window.__VueConsumerManager.launch("multi") - запустить в multi');
  console.log('  window.__VueConsumerManager.launch("hybrid") - запустить в hybrid');
  console.log('  window.__VueConsumerManager.destroy(id) - уничтожить по ID');
  console.log('  window.__VueConsumerManager.destroyAll() - уничтожить все');
  console.log(
    '  window.__VueConsumerManager.setMode("singleton"|"multi"|"hybrid") - переключить режим'
  );
  console.log('  window.__VueConsumerManager.info() - состояние');
  console.log('  window.__VueConsumerManager.list() - список');
  console.log('  window.__VueConsumerManager.getSingleton() - получить синглтон');
  console.log('  window.__VueConsumerManager.getInstances() - получить все экземпляры');
  console.log('  window.__VueConsumerManager.getHybridInstances() - получить гибридные экземпляры');
  console.log('  window.__VueConsumerManager.focus() - подсветить окно');
  console.log('  window.__VueConsumerManager.toggleMaximize() - развернуть/свернуть');
  console.log('  window.__VueConsumerManager.saveWindowState(id) - сохранить состояние окна');
  console.log('  window.__VueConsumerManager.loadWindowState(id) - загрузить состояние окна');
  console.log(
    '  window.__VueConsumerManager.cleanInvalidMessages() - очистить некорректные сообщения'
  );

  console.log('📊 СТАТИСТИКА СИМВОЛОВ:');
  console.log('  🔑 Приватных символов: ' + Object.keys(PRIVATE).length);
  console.log('  🔓 Публичных символов: ' + Object.keys(PUBLIC).length);
  console.log('  📦 Всего символов: ' + (Object.keys(PRIVATE).length + Object.keys(PUBLIC).length));

  console.log('🚀 Vue Bookmarklet: Запущен успешно');
  console.log('📌 Для закрытия нажмите ✕ в углу окна');
})({
  baseUrl: window.location.origin + window.location.pathname.replace(/[^/]*$/, ''),
  consumerId: 'vue_' + Date.now().toString(36) + '_' + Math.random().toString(36).substr(2, 6),
});
