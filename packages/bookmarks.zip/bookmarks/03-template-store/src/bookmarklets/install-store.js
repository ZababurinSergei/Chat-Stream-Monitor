// install-store.js
// Bookmarklet для установки Global Store на любой странице
// Версия: 2.1.0 — Только GLOBAL_STORE_SYMBOL

(function () {
  'use strict';

  // ============================================================
  // 1. ПРОВЕРКА БЕЗОПАСНОСТИ
  // ============================================================
  if (!window.isSecureContext) {
    alert('⚠️ Небезопасный контекст. Используйте HTTPS или localhost.');
    return;
  }

  // ============================================================
  // 2. ПРОВЕРКА НА ДУБЛИРОВАНИЕ
  // ============================================================
  const GLOBAL_STORE_SYMBOL = Symbol.for('__GLOBAL_STORE__');

  if (window[GLOBAL_STORE_SYMBOL]) {
    const shouldReload = confirm(
      '⚠️ Хранилище уже установлено на этой странице.\n' + 'Хотите переустановить его?'
    );
    if (!shouldReload) return;
  }

  // ============================================================
  // 3. КОНФИГУРАЦИЯ
  // ============================================================
  // ★★★ ИЗМЕНИТЕ ЭТОТ URL НА ВАШ СЕРВЕР ★★★
  const BASE_URL = 'http://localhost:3029';

  // ============================================================
  // 4. СОЗДАНИЕ UI КОНТЕЙНЕРА
  // ============================================================
  const container = document.createElement('div');
  container.id = 'store-installer';
  container.style.cssText = `
    position: fixed;
    bottom: 20px;
    left: 20px;
    z-index: 999999;
    background: #0b0e14;
    color: #c8d0e0;
    padding: 12px 16px;
    border-radius: 8px;
    border: 1px solid #1e2633;
    font-family: system-ui, sans-serif;
    font-size: 13px;
    max-width: 400px;
    box-shadow: 0 4px 20px rgba(0,0,0,0.8);
    display: none;
  `;
  container.innerHTML = `
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;">
      <span style="font-weight:600;">📦 Установка Global Store</span>
      <button id="storeInstallerClose" style="background:#ef4444;color:white;border:none;border-radius:50%;width:24px;height:24px;cursor:pointer;font-size:14px;">✕</button>
    </div>
    <div id="storeInstallerLog" style="font-size:12px;color:#8b96b0;max-height:200px;overflow-y:auto;"></div>
  `;
  document.body.appendChild(container);

  function showLog(message, status = 'info') {
    const log = document.getElementById('storeInstallerLog');
    if (!log) return;

    const colors = {
      success: '#34d399',
      error: '#ef4444',
      warn: '#fbbf24',
      info: '#60a5fa',
    };

    const entry = document.createElement('div');
    entry.style.cssText = `padding:2px 0;color:${colors[status] || '#8b96b0'};`;
    entry.textContent = message;
    log.appendChild(entry);
    log.scrollTop = log.scrollHeight;
    container.style.display = 'block';
  }

  // Кнопка закрытия
  document.getElementById('storeInstallerClose')?.addEventListener('click', () => {
    container.style.display = 'none';
  });

  showLog(`⏳ Загрузка Global Store из ${BASE_URL}...`, 'info');

  // ============================================================
  // 5. ЗАГРУЗКА ГЛОБАЛЬНОГО СТОРА
  // ============================================================
  const script = document.createElement('script');
  script.type = 'module';
  script.textContent = `
    // ============================================================
    // ИМПОРТЫ
    // ============================================================
    import { getGlobalStore, GLOBAL_STORE_SYMBOL } from '${BASE_URL}/src/core/global-store.js';

    // ============================================================
    // 1. ПОЛУЧАЕМ И СОХРАНЯЕМ ХРАНИЛИЩЕ
    // ============================================================
    const globalStore = getGlobalStore();

    // Сохраняем в глобальный объект
    window[GLOBAL_STORE_SYMBOL] = globalStore;

    // Удобный алиас
    window.__store = globalStore;

    // Добавляем информацию о версии
    window.__store.__version = globalStore.__version || '1.0.2';
    window.__store.__installed = Date.now();

    // ============================================================
    // 2. ДОБАВЛЯЕМ МЕТОДЫ ДЛЯ УДОБСТВА
    // ============================================================
    window.__store.sendMessage = function(msg) {
      return globalStore.insert('messages', {
        id: msg.id || 'msg_' + Date.now() + '_' + Math.random().toString(36).substr(2, 6),
        timestamp: msg.ts || Date.now(),
        text: msg.text,
        type: msg.type || 'user',
        source: msg.source || 'unknown',
        consumerId: msg.consumerId || null,
      });
    };

    window.__store.broadcastMessage = function(msg) {
      const result = globalStore.insert('messages', {
        id: msg.id || 'msg_' + Date.now() + '_' + Math.random().toString(36).substr(2, 6),
        timestamp: msg.ts || Date.now(),
        text: msg.text,
        type: 'broadcast',
        source: msg.source || 'broadcast',
        consumerId: msg.consumerId || null,
      });
      globalStore.publish('broadcast', { type: 'broadcast', payload: msg });
      return result;
    };

    window.__store.getMessages = function(limit) {
      const msgs = globalStore.select('messages', {
        sort: [{ field: 'timestamp', direction: 'desc' }],
        limit: limit || 50,
      });
      return msgs || [];
    };

    window.__store.clearMessages = function() {
      return globalStore.clearTable('messages');
    };

    window.__store.getState = function() {
      const state = globalStore.getState();
      const metrics = globalStore.select('metrics') || [];
      return {
        ...state,
        liveMetrics: metrics.map(function(m) {
          return {
            id: m.id,
            ts: m.timestamp || m.ts || Date.now(),
            val: m.value || m.val || 0,
            trend: m.trend || 0,
            source: m.source || 'stream',
          };
        }),
        streamStatus: state.streamStatus || 'disconnected',
        totalBatches: state._batches || 0,
        lastUpdate: state.lastUpdate || null,
        version: state.version || 'unknown',
        tables: globalStore.listTables(),
      };
    };

    window.__store.getMetrics = function() {
      const metrics = globalStore.select('metrics') || [];
      return metrics.map(function(m) {
        return {
          id: m.id,
          ts: m.timestamp || m.ts || Date.now(),
          val: m.value || m.val || 0,
          trend: m.trend || 0,
          source: m.source || 'stream',
        };
      });
    };

    window.__store.getStatus = function() {
      const state = globalStore.getState();
      return state.streamStatus || 'disconnected';
    };

    window.__store.setStatus = function(status) {
      const validStatuses = ['playing', 'paused', 'disconnected', 'connecting'];
      if (!validStatuses.includes(status)) {
        console.warn('⚠️ Некорректный статус:', status);
        return false;
      }
      const state = globalStore.getState();
      state.streamStatus = status;
      state.lastUpdate = Date.now();
      globalStore.publish('store-status', {
        type: 'status-change',
        payload: { status: status, timestamp: Date.now() },
      });
      return true;
    };

    window.__store.appendDataBatch = function(batch) {
      if (!batch || !Array.isArray(batch)) return false;
      if (batch.length === 0) return false;

      const adaptedBatch = batch.map(function(item) {
        return {
          id: item.id || 'metric_' + Date.now() + '_' + Math.random().toString(36).substr(2, 6),
          timestamp: item.ts || Date.now(),
          value: item.val || 0,
          trend: item.trend || 0,
          source: item.source || 'stream',
        };
      });
      return globalStore.insert('metrics', adaptedBatch);
    };

    window.__store.clearStore = function() {
      globalStore.clearTable('metrics');
      globalStore.clearTable('messages');
      globalStore._batches = 0;
      return true;
    };

    window.__store.subscribe = function(callback) {
      if (typeof callback !== 'function') {
        console.warn('⚠️ callback должен быть функцией');
        return null;
      }
      return globalStore.subscribe('*', function(channel, message) {
        if (message.type === 'store-event' || message.type === 'status-change') {
          try {
            callback(window.__store.getState());
          } catch (error) {
            console.error('❌ Ошибка в callback подписки:', error);
          }
        }
      });
    };

    window.__store.healthCheck = function() {
      const state = globalStore.getState();
      const metrics = globalStore.select('metrics') || [];
      const messages = globalStore.select('messages') || [];
      const tables = globalStore.listTables();

      return {
        version: globalStore.__version || 'unknown',
        metricsCount: metrics.length,
        status: state.streamStatus || 'disconnected',
        subscribers: state._subscribersCount || 0,
        messagesCount: messages.length,
        batches: state._batches || 0,
        channelActive: true,
        lastUpdate: state.lastUpdate || null,
        isValid: true,
        tables: tables,
        tablesCount: tables.length,
        initialized: state.initialized || false,
        ready: state.ready || false,
        timestamp: Date.now(),
      };
    };

    window.__store.getGlobalStore = function() {
      return globalStore;
    };

    window.__store.listTables = function() {
      return globalStore.listTables();
    };

    window.__store.createTable = function(name, options) {
      return globalStore.createTable(name, options);
    };

    window.__store.dropTable = function(name) {
      return globalStore.dropTable(name);
    };

    window.__store.insert = function(tableName, rows) {
      return globalStore.insert(tableName, rows);
    };

    window.__store.select = function(tableName, options) {
      return globalStore.select(tableName, options);
    };

    window.__store.update = function(tableName, updates, where) {
      return globalStore.update(tableName, updates, where);
    };

    window.__store.delete = function(tableName, where) {
      return globalStore.delete(tableName, where);
    };

    // Мастер-детейл
    window.__store.linkTables = function(masterTable, detailTable, relationKey) {
      return globalStore.linkTables(masterTable, detailTable, relationKey);
    };

    window.__store.unlinkTables = function(masterTable, detailTable) {
      return globalStore.unlinkTables(masterTable, detailTable);
    };

    window.__store.setMaster = function(masterTable, masterId) {
      return globalStore.setMaster(masterTable, masterId);
    };

    window.__store.getDetails = function(masterTable, masterId) {
      return globalStore.getDetails(masterTable, masterId);
    };

    // Выделение
    window.__store.selectRow = function(tableName, rowId) {
      return globalStore.selectRow(tableName, rowId);
    };

    window.__store.clearSelection = function(tableName) {
      return globalStore.clearSelection(tableName);
    };

    window.__store.getSelection = function(tableName) {
      return globalStore.getSelection(tableName);
    };

    // Транзакции
    window.__store.beginTransaction = function(name) {
      return globalStore.beginTransaction(name);
    };

    window.__store.commitTransaction = function() {
      return globalStore.commitTransaction();
    };

    window.__store.rollbackTransaction = function() {
      return globalStore.rollbackTransaction();
    };

    window.__store.undo = function() {
      return globalStore.undo();
    };

    window.__store.redo = function() {
      return globalStore.redo();
    };

    // ============================================================
    // 3. ОПОВЕЩЕНИЕ В UI
    // ============================================================
    const log = document.getElementById('storeInstallerLog');
    if (log) {
      const entry1 = document.createElement('div');
      entry1.style.cssText = 'padding:2px 0;color:#34d399;';
      entry1.textContent = '✅ Global Store успешно установлен!';
      log.appendChild(entry1);

      const entry2 = document.createElement('div');
      entry2.style.cssText = 'padding:2px 0;color:#8b96b0;font-size:11px;';
      entry2.textContent = '📌 Используйте window.__store для доступа';
      log.appendChild(entry2);

      const entry3 = document.createElement('div');
      entry3.style.cssText = 'padding:2px 0;color:#4a5a7a;font-size:10px;';
      const state = window.__store.getState();
      entry3.textContent = '📊 Состояние: ' + (state.streamStatus || 'disconnected') +
        ' | Метрик: ' + (state.liveMetrics ? state.liveMetrics.length : 0) +
        ' | Таблиц: ' + (state.tables ? state.tables.length : 0);
      log.appendChild(entry3);

      setTimeout(function() {
        const container = document.getElementById('store-installer');
        if (container) {
          container.style.display = 'none';
        }
      }, 4000);
    }

    // ============================================================
    // 4. СОБЫТИЕ О ГОТОВНОСТИ
    // ============================================================
    const event = new CustomEvent('store-ready', {
      detail: {
        store: globalStore,
        timestamp: Date.now(),
        version: globalStore.__version || 'unknown',
        tables: globalStore.listTables(),
      }
    });
    window.dispatchEvent(event);

    // ============================================================
    // 5. КОНСОЛЬНЫЙ ИНТЕРФЕЙС
    // ============================================================
    console.log('╔═══════════════════════════════════════════════════════════════════════════════╗');
    console.log('║              📦 GLOBAL STORE INSTALLED v2.1.0                               ║');
    console.log('╠═══════════════════════════════════════════════════════════════════════════════╣');
    console.log('║  📌 Используйте window.__store для доступа                                  ║');
    console.log('║  📋 ДОСТУПНЫЕ КОМАНДЫ:                                                      ║');
    console.log('║    📊 ДАННЫЕ:                                                               ║');
    console.log('║      window.__store.getState() - полное состояние                           ║');
    console.log('║      window.__store.getMetrics() - метрики                                  ║');
    console.log('║      window.__store.getStatus() - статус                                    ║');
    console.log('║      window.__store.setStatus(status) - установить статус                   ║');
    console.log('║      window.__store.appendDataBatch(batch) - добавить данные                ║');
    console.log('║      window.__store.clearStore() - очистить данные                          ║');
    console.log('║    📨 СООБЩЕНИЯ:                                                           ║');
    console.log('║      window.__store.sendMessage(msg) - отправить сообщение                  ║');
    console.log('║      window.__store.broadcastMessage(msg) - широковещательное               ║');
    console.log('║      window.__store.getMessages(limit) - получить сообщения                 ║');
    console.log('║      window.__store.clearMessages() - очистить сообщения                    ║');
    console.log('║    📁 ТАБЛИЦЫ:                                                             ║');
    console.log('║      window.__store.listTables() - список таблиц                            ║');
    console.log('║      window.__store.insert(table, rows) - вставить данные                   ║');
    console.log('║      window.__store.select(table, options) - выбрать данные                 ║');
    console.log('║      window.__store.update(table, updates, where) - обновить                ║');
    console.log('║      window.__store.delete(table, where) - удалить                          ║');
    console.log('║    🔗 МАСТЕР-ДЕТЕЙЛ:                                                       ║');
    console.log('║      window.__store.linkTables(master, detail, key) - связать таблицы       ║');
    console.log('║      window.__store.setMaster(table, id) - установить мастер                ║');
    console.log('║      window.__store.getDetails(table, id) - получить детали                 ║');
    console.log('║    🔒 ТРАНЗАКЦИИ:                                                          ║');
    console.log('║      window.__store.beginTransaction(name) - начать транзакцию              ║');
    console.log('║      window.__store.commitTransaction() - зафиксировать                     ║');
    console.log('║      window.__store.rollbackTransaction() - откатить                        ║');
    console.log('║      window.__store.undo() - отменить                                       ║');
    console.log('║      window.__store.redo() - повторить                                     ║');
    console.log('║    🔌 ПОДПИСКА:                                                            ║');
    console.log('║      window.__store.subscribe(callback) - подписка на изменения             ║');
    console.log('║      window.__store.healthCheck() - проверка целостности                    ║');
    console.log('║      window.__store.getGlobalStore() - доступ к GlobalStore                 ║');
    console.log('╚═══════════════════════════════════════════════════════════════════════════════╝');

    // ============================================================
    // 6. ТЕСТОВЫЕ ПРИМЕРЫ
    // ============================================================
    console.log('📊 ТЕСТОВЫЕ КОМАНДЫ:');
    console.log('  // Добавить тестовые метрики');
    console.log('  window.__store.appendDataBatch([');
    console.log('    { id: 1, ts: Date.now(), val: 42.5, trend: 50 },');
    console.log('    { id: 2, ts: Date.now(), val: 67.8, trend: 55 }');
    console.log('  ]);');
    console.log('  ');
    console.log('  // Отправить тестовое сообщение');
    console.log('  window.__store.sendMessage({ text: "Привет из Global Store!" });');
    console.log('  ');
    console.log('  // Получить состояние');
    console.log('  const state = window.__store.getState();');
    console.log('  console.log(state);');
    console.log('  ');
    console.log('  // Подписаться на изменения');
    console.log('  const unsub = window.__store.subscribe(function(state) {');
    console.log('    console.log("📡 Обновление:", state.streamStatus);');
    console.log('  });');
  `;

  // ============================================================
  // 6. ОБРАБОТКА ОШИБОК
  // ============================================================
  script.onerror = function (error) {
    showLog('❌ Ошибка загрузки Global Store: ' + (error.message || 'Неизвестная ошибка'), 'error');
    console.error('❌ Ошибка установки Global Store:', error);

    const log = document.getElementById('storeInstallerLog');
    if (log) {
      const entry = document.createElement('div');
      entry.style.cssText = 'padding:2px 0;color:#ef4444;';
      entry.textContent = '❌ Ошибка: ' + (error.message || 'Неизвестная ошибка');
      log.appendChild(entry);

      const entry2 = document.createElement('div');
      entry2.style.cssText = 'padding:2px 0;color:#4a5a7a;font-size:11px;';
      entry2.textContent = 'Проверьте доступность сервера: ' + BASE_URL;
      log.appendChild(entry2);
    }
  };

  document.head.appendChild(script);

  // ============================================================
  // 7. ТАЙМАУТ
  // ============================================================
  let timeoutId = setTimeout(function () {
    if (!window[GLOBAL_STORE_SYMBOL]) {
      showLog('⚠️ Таймаут загрузки. Проверьте доступность сервера.', 'warn');
      console.warn('⚠️ Таймаут загрузки Global Store. Проверьте сервер на ' + BASE_URL);
    }
  }, 10000);

  // Отменяем таймаут при успешной загрузке
  window.addEventListener(
    'store-ready',
    function () {
      clearTimeout(timeoutId);
    },
    { once: true }
  );

  // ============================================================
  // 8. КОНСОЛЬНЫЙ ИНТЕРФЕЙС
  // ============================================================
  console.log('╔═══════════════════════════════════════════════════════════════════════════════╗');
  console.log('║              📦 GLOBAL STORE INSTALLER v2.1.0                               ║');
  console.log('╠═══════════════════════════════════════════════════════════════════════════════╣');
  console.log('║  📡 Источник: ' + BASE_URL + '                                                 ║');
  console.log('║  🔑 Используется GLOBAL_STORE_SYMBOL (Symbol.for)                            ║');
  console.log('║  📊 Полный набор методов для работы с данными                                ║');
  console.log('║  📨 Сообщения через Global Store                                             ║');
  console.log('║  🔗 Мастер-детейл связи между таблицами                                      ║');
  console.log('║  🔒 Транзакции с Undo/Redo                                                  ║');
  console.log('║  📡 Подписка на изменения                                                   ║');
  console.log('╚═══════════════════════════════════════════════════════════════════════════════╝');

  console.log('🚀 Global Store Installer запущен');
  console.log('📍 Источник:', BASE_URL);
  console.log('📋 После установки используйте window.__store');
})();
