// src/bookmarklets/react-bookmarklet.js
// 100% СИМВОЛЫ — полная изоляция и безопасность
// Версия: 5.3.0 — Не сохраняем и не восстанавливаем статус стриминга

(async function () {
  'use strict';

  // ============================================================
  // 1. ПРИВАТНЫЕ СИМВОЛЫ (100% изоляция)
  // ============================================================

  const PRIVATE = {
    VERSION: Symbol('react.bookmarklet.version'),
    BUILD: Symbol('react.bookmarklet.build'),
    NAME: Symbol('react.bookmarklet.name'),
    CONFIG: Symbol('react.bookmarklet.config'),
    STATE: Symbol('react.bookmarklet.state'),
    CONSUMER_ID: Symbol('react.bookmarklet.consumerId'),
    CONTAINER_ID: Symbol('react.bookmarklet.containerId'),
    MODE: Symbol('react.bookmarklet.mode'),
    IS_SINGLETON: Symbol('react.bookmarklet.isSingleton'),
    IS_HIDDEN: Symbol('react.bookmarklet.isHidden'),
    INSTANCE_INDEX: Symbol('react.bookmarklet.instanceIndex'),
    BASE_URL: Symbol('react.bookmarklet.baseUrl'),
    REGISTRY: Symbol('react.bookmarklet.registry'),
    MANAGER: Symbol('react.bookmarklet.manager'),
    SNAPSHOTS: Symbol('react.bookmarklet.snapshots'),
    PERSISTENT_STATE: Symbol('react.bookmarklet.persistentState'),
    INIT: Symbol('react.bookmarklet.init'),
    LAUNCH: Symbol('react.bookmarklet.launch'),
    DESTROY: Symbol('react.bookmarklet.destroy'),
    DESTROY_ALL: Symbol('react.bookmarklet.destroyAll'),
    GET_STATE: Symbol('react.bookmarklet.getState'),
    GET_LIST: Symbol('react.bookmarklet.getList'),
    SET_MODE: Symbol('react.bookmarklet.setMode'),
    GET_MODE: Symbol('react.bookmarklet.getMode'),
    SHOW: Symbol('react.bookmarklet.show'),
    HIDE: Symbol('react.bookmarklet.hide'),
    TOGGLE: Symbol('react.bookmarklet.toggle'),
    IS_HIDDEN_CHECK: Symbol('react.bookmarklet.isHiddenCheck'),
    GET_CONTAINER: Symbol('react.bookmarklet.getContainer'),
    CREATE_CONTAINER: Symbol('react.bookmarklet.createContainer'),
    SHOW_ERROR: Symbol('react.bookmarklet.showError'),
    UPDATE_STATUS: Symbol('react.bookmarklet.updateStatus'),
    CHECK_STORE: Symbol('react.bookmarklet.checkStore'),
    SETUP_DRAG: Symbol('react.bookmarklet.setupDrag'),
    EXPORT_SYMBOLS: Symbol('react.bookmarklet.exportSymbols'),
    CLEANUP: Symbol('react.bookmarklet.cleanup'),
    BEFORE_UNLOAD: Symbol('react.bookmarklet.beforeUnload'),
    SAVE_PERSISTENT: Symbol('react.bookmarklet.savePersistent'),
    LOAD_PERSISTENT: Symbol('react.bookmarklet.loadPersistent'),
    CLEAR_PERSISTENT: Symbol('react.bookmarklet.clearPersistent'),
    SAVE_SNAPSHOT: Symbol('react.bookmarklet.saveSnapshot'),
    LOAD_SNAPSHOT: Symbol('react.bookmarklet.loadSnapshot'),
    LIST_SNAPSHOTS: Symbol('react.bookmarklet.listSnapshots'),
    CLEAR_SNAPSHOTS: Symbol('react.bookmarklet.clearSnapshots'),
    RESTORE_SNAPSHOT: Symbol('react.bookmarklet.restoreSnapshot'),
    RESTORE_SNAPSHOT_DATA_ONLY: Symbol('react.bookmarklet.restoreSnapshotDataOnly'),
    IS_VISIBLE: Symbol('react.bookmarklet.isVisible'),
    FOCUS: Symbol('react.bookmarklet.focus'),
  };

  // ============================================================
  // 2. ПУБЛИЧНЫЕ СИМВОЛЫ
  // ============================================================

  const PUBLIC = {
    INSTANCE: Symbol.for('react.bookmarklet.instance'),
    STATE: Symbol.for('react.bookmarklet.state'),
    CONFIG: Symbol.for('react.bookmarklet.config'),
    MANAGER: Symbol.for('react.bookmarklet.manager'),
    LAUNCH: Symbol.for('react.bookmarklet.launch'),
    DESTROY: Symbol.for('react.bookmarklet.destroy'),
    DESTROY_ALL: Symbol.for('react.bookmarklet.destroyAll'),
    GET_STATE: Symbol.for('react.bookmarklet.getState'),
    GET_LIST: Symbol.for('react.bookmarklet.getList'),
    SET_MODE: Symbol.for('react.bookmarklet.setMode'),
    GET_MODE: Symbol.for('react.bookmarklet.getMode'),
    SHOW: Symbol.for('react.bookmarklet.show'),
    HIDE: Symbol.for('react.bookmarklet.hide'),
    TOGGLE: Symbol.for('react.bookmarklet.toggle'),
    IS_HIDDEN: Symbol.for('react.bookmarklet.isHidden'),
    GET_CONTAINER: Symbol.for('react.bookmarklet.getContainer'),
    SAVE_SNAPSHOT: Symbol.for('react.bookmarklet.saveSnapshot'),
    LOAD_SNAPSHOT: Symbol.for('react.bookmarklet.loadSnapshot'),
    LIST_SNAPSHOTS: Symbol.for('react.bookmarklet.listSnapshots'),
    CLEAR_SNAPSHOTS: Symbol.for('react.bookmarklet.clearSnapshots'),
    RESTORE: Symbol.for('react.bookmarklet.restore'),
    SAVE_PERSISTENT: Symbol.for('react.bookmarklet.savePersistent'),
    LOAD_PERSISTENT: Symbol.for('react.bookmarklet.loadPersistent'),
    CLEAR_PERSISTENT: Symbol.for('react.bookmarklet.clearPersistent'),
    FOCUS: Symbol.for('react.bookmarklet.focus'),
  };

  // ============================================================
  // 3. КОНФИГУРАЦИЯ
  // ============================================================

  const CONFIG = {
    version: '5.3.0',
    build: '2026-07-25',
    name: 'React Bookmarklet',
    debug: true,
    containerWidth: 420,
    containerMaxHeight: '80vh',
    modes: {
      SINGLETON: 'singleton',
      MULTI: 'multi',
      HYBRID: 'hybrid',
    },
    defaultMode: 'singleton',
    storageKey: 'react_bookmarklet_mode',
    snapshotsKey: 'react_bookmarklet_snapshots',
    persistentKey: 'react_bookmarklet_persistent_state',
    animationDuration: 300,
    maxSnapshots: 10,
  };

  const MODE = {
    SINGLETON: 'singleton',
    MULTI: 'multi',
    HYBRID: 'hybrid',
  };

  // ============================================================
  // 4. ЛОГГЕР
  // ============================================================

  const LOGGER_SYMBOLS = {
    HISTORY: Symbol('logger.history'),
    MAX_HISTORY: Symbol('logger.maxHistory'),
    DEBUG: Symbol('logger.debug'),
    INSTANCE_ID: Symbol('logger.instanceId'),
    LEVEL: Symbol('logger.level'),
  };

  function createLogger(debug, instanceId) {
    if (debug === undefined) debug = true;
    if (instanceId === undefined) instanceId = 'ReactBookmarklet';

    const logState = {
      [LOGGER_SYMBOLS.HISTORY]: [],
      [LOGGER_SYMBOLS.MAX_HISTORY]: 200,
      [LOGGER_SYMBOLS.DEBUG]: debug,
      [LOGGER_SYMBOLS.INSTANCE_ID]: instanceId,
      [LOGGER_SYMBOLS.LEVEL]: debug ? 3 : 2,
    };

    const logMethod = function (level, message, data) {
      const levels = { error: 0, warn: 1, info: 2, debug: 3, success: 2 };
      const currentLevel = this[LOGGER_SYMBOLS.LEVEL] || 2;
      const msgLevel = levels[level] || 2;

      if (msgLevel > currentLevel) return;

      const timestamp = new Date().toISOString().slice(11, 23);
      const prefix = '[' + timestamp + '] [' + this[LOGGER_SYMBOLS.INSTANCE_ID] + ']';

      this[LOGGER_SYMBOLS.HISTORY].push({
        timestamp: timestamp,
        level: level,
        message: message,
        data: data || null,
        id: Date.now() + Math.random(),
      });

      if (this[LOGGER_SYMBOLS.HISTORY].length > this[LOGGER_SYMBOLS.MAX_HISTORY]) {
        this[LOGGER_SYMBOLS.HISTORY].shift();
      }

      var icons = { error: '❌', warn: '⚠️', info: 'ℹ️', debug: '🔍', success: '✅' };
      var icon = icons[level] || '📌';

      if (data !== null && data !== undefined) {
        console.log(icon + ' ' + prefix + ' ' + message, data);
      } else {
        console.log(icon + ' ' + prefix + ' ' + message);
      }
    };

    var boundLog = logMethod.bind(logState);

    var methods = {
      error: function (msg, d) {
        return boundLog('error', msg, d);
      },
      warn: function (msg, d) {
        return boundLog('warn', msg, d);
      },
      info: function (msg, d) {
        return boundLog('info', msg, d);
      },
      debug: function (msg, d) {
        return boundLog('debug', msg, d);
      },
      success: function (msg, d) {
        return boundLog('success', msg, d);
      },
      header: function (title, color) {
        if (color === undefined) color = '#636e72';
        var separator = '═'.repeat(70);
        console.log('%c' + separator, 'color: ' + color + ';');
        console.log(
          '%c  📦 ' + title,
          'background: #1a1a2e; color: #fff; padding: 4px 12px; border-radius: 4px; font-weight: bold;'
        );
        console.log('%c' + separator, 'color: ' + color + ';');
      },
      separator: function (color) {
        if (color === undefined) color = '#636e72';
        console.log('%c' + '─'.repeat(70), 'color: ' + color + ';');
      },
      getHistory: function () {
        return [...this[LOGGER_SYMBOLS.HISTORY]];
      },
      clearHistory: function () {
        this[LOGGER_SYMBOLS.HISTORY] = [];
        return this;
      },
      setDebug: function (enabled) {
        this[LOGGER_SYMBOLS.DEBUG] = enabled;
        this[LOGGER_SYMBOLS.LEVEL] = enabled ? 3 : 2;
        return this;
      },
    };

    var logger = {};
    var keys = Object.keys(methods);
    for (var i = 0; i < keys.length; i++) {
      var key = keys[i];
      logger[key] = methods[key].bind(logState);
    }

    logger[LOGGER_SYMBOLS.HISTORY] = logState[LOGGER_SYMBOLS.HISTORY];
    logger[LOGGER_SYMBOLS.MAX_HISTORY] = logState[LOGGER_SYMBOLS.MAX_HISTORY];
    logger[LOGGER_SYMBOLS.DEBUG] = logState[LOGGER_SYMBOLS.DEBUG];
    logger[LOGGER_SYMBOLS.INSTANCE_ID] = logState[LOGGER_SYMBOLS.INSTANCE_ID];
    logger[LOGGER_SYMBOLS.LEVEL] = logState[LOGGER_SYMBOLS.LEVEL];

    return logger;
  }

  var logger = createLogger(CONFIG.debug, 'ReactBookmarklet');

  // ============================================================
  // 5. ПРОВЕРКА БЕЗОПАСНОСТИ
  // ============================================================

  if (!window.isSecureContext) {
    alert('⚠️ Небезопасный контекст. Запустите через HTTPS или localhost.');
    return;
  }

  if (typeof window === 'undefined') {
    console.error('❌ React Bookmarklet: Окружение не поддерживается');
    return;
  }

  // ============================================================
  // 6. ПРОВЕРКА ХРАНИЛИЩА
  // ============================================================

  var STORE_SYMBOL = Symbol.for('__HIGH_FREQ_STREAM_STORE__');
  var store = window[STORE_SYMBOL];

  if (!store) {
    alert('❌ Хранилище не найдено. Запустите основное приложение сначала.');
    console.error('❌ React Bookmarklet: Хранилище не найдено');
    return;
  }

  if (!store.__version) {
    alert('❌ Некорректная версия хранилища');
    console.error('❌ React Bookmarklet: Некорректная версия хранилища');
    return;
  }

  console.log('✅ React Bookmarklet: Хранилище найдено, версия:', store.__version);

  // ============================================================
  // 7. ПОЛУЧЕНИЕ БАЗОВОГО URL
  // ============================================================

  function getBaseUrl() {
    return window.location.origin + window.location.pathname.replace(/[^/]*$/, '');
  }

  var baseUrl = getBaseUrl();

  // ============================================================
  // 8. РЕЕСТР КОНСЮМЕРОВ
  // ============================================================

  if (!window.__REACT_CONSUMERS__) {
    window.__REACT_CONSUMERS__ = {
      singleton: null,
      instances: new Map(),
      hybridInstances: new Map(),
      mode: localStorage.getItem(CONFIG.storageKey) || CONFIG.defaultMode,
      launched: false,
      snapshots: new Map(),
      focusTimeout: null,
    };
  }

  var registry = window.__REACT_CONSUMERS__;

  // ============================================================
  // 9. ПОСТОЯННОЕ СОХРАНЕНИЕ СОСТОЯНИЯ (БЕЗ СТАТУСА)
  // ============================================================

  function savePersistentState(data) {
    try {
      // ★★★ СОХРАНЯЕМ ВСЁ, КРОМЕ СТАТУСА ★★★
      var stateData = {
        data: {
          liveMetrics: data.liveMetrics || [],
          totalBatches: data.totalBatches || 0,
          lastUpdate: data.lastUpdate || null,
          messages: data.messages || [],
          timestamp: Date.now(),
        },
        timestamp: Date.now(),
        version: CONFIG.version,
      };
      localStorage.setItem(CONFIG.persistentKey, JSON.stringify(stateData));
      logger.debug('💾 Постоянное состояние сохранено (без статуса)');
      return true;
    } catch (error) {
      logger.warn('⚠️ Не удалось сохранить постоянное состояние:', error);
      return false;
    }
  }

  function loadPersistentState() {
    try {
      var raw = localStorage.getItem(CONFIG.persistentKey);
      if (!raw) return null;
      var parsed = JSON.parse(raw);
      logger.debug('📂 Постоянное состояние загружено');

      // ★★★ ВОЗВРАЩАЕМ ДАННЫЕ БЕЗ СТАТУСА ★★★
      var data = parsed.data || {};
      // Удаляем статус, если он есть
      delete data.streamStatus;
      return data;
    } catch (error) {
      logger.warn('⚠️ Не удалось загрузить постоянное состояние:', error);
      return null;
    }
  }

  function clearPersistentState() {
    try {
      localStorage.removeItem(CONFIG.persistentKey);
      logger.debug('🧹 Постоянное состояние очищено');
      return true;
    } catch (error) {
      logger.warn('⚠️ Не удалось очистить постоянное состояние:', error);
      return false;
    }
  }

  // ============================================================
  // 10. СНАПШОТЫ (БЕЗ СТАТУСА)
  // ============================================================

  function saveSnapshot(consumerId, data) {
    var snapshotId =
      'snapshot_' + Date.now().toString(36) + '_' + Math.random().toString(36).substr(2, 6);

    var snapshot = {
      id: snapshotId,
      consumerId: consumerId,
      data: {
        liveMetrics: data.liveMetrics || [],
        totalBatches: data.totalBatches || 0,
        lastUpdate: data.lastUpdate || null,
        messages: data.messages || [],
        timestamp: Date.now(),
      },
      timestamp: Date.now(),
      created: new Date().toISOString(),
      mode: registry.mode,
    };

    registry.snapshots.set(snapshotId, snapshot);

    try {
      var snapshotsList = JSON.parse(localStorage.getItem(CONFIG.snapshotsKey) || '[]');
      snapshotsList.push(snapshot);
      if (snapshotsList.length > CONFIG.maxSnapshots) {
        snapshotsList = snapshotsList.slice(-CONFIG.maxSnapshots);
      }
      localStorage.setItem(CONFIG.snapshotsKey, JSON.stringify(snapshotsList));
    } catch (error) {
      logger.warn('⚠️ Не удалось сохранить снапшот в localStorage:', error);
    }

    logger.success('📸 Снапшот сохранен (без статуса): ' + snapshotId);
    return snapshotId;
  }

  function loadSnapshot(snapshotId) {
    if (registry.snapshots.has(snapshotId)) {
      return registry.snapshots.get(snapshotId);
    }

    try {
      var snapshotsList = JSON.parse(localStorage.getItem(CONFIG.snapshotsKey) || '[]');
      var found = snapshotsList.find(function (s) {
        return s.id === snapshotId;
      });
      if (found) {
        registry.snapshots.set(snapshotId, found);
        return found;
      }
    } catch (error) {
      logger.warn('⚠️ Не удалось загрузить снапшот из localStorage:', error);
    }

    return null;
  }

  function listSnapshots() {
    var result = [];
    for (var entry of registry.snapshots) {
      result.push({
        id: entry[0],
        consumerId: entry[1].consumerId,
        created: entry[1].created,
        fields: Object.keys(entry[1].data || {}).length,
        mode: entry[1].mode,
      });
    }
    return result;
  }

  function clearSnapshots() {
    registry.snapshots.clear();
    try {
      localStorage.removeItem(CONFIG.snapshotsKey);
    } catch (error) {
      logger.warn('⚠️ Не удалось очистить снапшоты в localStorage:', error);
    }
    logger.success('🧹 Все снапшоты очищены');
    return true;
  }

  function restoreSnapshotDataOnly(snapshotId, targetConsumerId) {
    var snapshot = loadSnapshot(snapshotId);
    if (!snapshot) {
      logger.warn('⚠️ Снапшот не найден:', snapshotId);
      return false;
    }

    var data = snapshot.data;
    logger.info('🔄 Восстановление данных из снапшота (без статуса):', snapshotId);

    try {
      if (data.liveMetrics && data.liveMetrics.length > 0) {
        store.appendDataBatch(data.liveMetrics);
      }
      // ★★★ НЕ ВОССТАНАВЛИВАЕМ СТАТУС ★★★
      if (data.messages && data.messages.length > 0) {
        for (var i = 0; i < data.messages.length; i++) {
          store.sendMessage(data.messages[i]);
        }
      }
      logger.success('✅ Данные восстановлены из снапшота: ' + snapshotId);
      return true;
    } catch (error) {
      logger.error('❌ Ошибка восстановления данных из снапшота:', error);
      return false;
    }
  }

  // ============================================================
  // 11. ФУНКЦИИ ДЛЯ SINGLETON
  // ============================================================

  function isContainerVisible(container) {
    if (!container) return false;
    if (container.style.display === 'none') return false;
    if (container.style.opacity === '0') return false;
    if (container.dataset.isHidden === 'true') return false;
    return true;
  }

  function focusContainer(container) {
    if (!container) return;
    container.style.boxShadow = '0 0 40px rgba(59, 130, 246, 0.6)';
    container.style.borderColor = '#60a5fa';
    container.style.transition = 'box-shadow 0.3s ease, border-color 0.3s ease';

    if (registry.focusTimeout) {
      clearTimeout(registry.focusTimeout);
    }

    registry.focusTimeout = setTimeout(function () {
      container.style.boxShadow = '0 8px 32px rgba(0,0,0,0.85)';
      container.style.borderColor = '#1e2633';
      registry.focusTimeout = null;
    }, 800);
  }

  function hideSingleton(consumerId) {
    var singleton = registry.singleton;

    if (!singleton || singleton.id !== consumerId) {
      logger.warn('⚠️ Синглтон не найден для скрытия:', consumerId);
      return false;
    }

    try {
      var state = store.getState();
      var snapshotData = {
        liveMetrics: state.liveMetrics || [],
        streamStatus: state.streamStatus || 'disconnected',
        totalBatches: state.totalBatches || 0,
        lastUpdate: state.lastUpdate || null,
        messages: state.messages || [],
        timestamp: Date.now(),
      };

      savePersistentState(snapshotData);
      saveSnapshot(consumerId, snapshotData);
      logger.success('💾 Состояние сохранено перед скрытием (без статуса)');
    } catch (error) {
      logger.warn('⚠️ Не удалось сохранить состояние:', error);
    }

    var container = document.getElementById('react-consumer-container-' + consumerId);
    if (!container) {
      logger.warn('⚠️ Контейнер не найден для скрытия:', consumerId);
      return false;
    }

    container.style.opacity = '0';
    container.style.transform = 'scale(0.95)';
    container.dataset.isHidden = 'true';

    singleton.isHidden = true;
    singleton.hideTime = Date.now();

    setTimeout(function () {
      container.style.display = 'none';
    }, CONFIG.animationDuration);

    logger.success('🧹 [Singleton] Консюмер ' + consumerId + ' скрыт');

    var statusBadge = document.getElementById('react-bookmarklet-status-' + consumerId);
    if (statusBadge) {
      statusBadge.textContent = '⏸ скрыт';
      statusBadge.style.color = '#4a5a7a';
      statusBadge.style.borderColor = 'rgba(74,90,122,0.2)';
    }

    return true;
  }

  function showSingleton(consumerId) {
    var singleton = registry.singleton;

    if (!singleton || singleton.id !== consumerId) {
      logger.warn('⚠️ Синглтон не найден для показа:', consumerId);
      return false;
    }

    var container = document.getElementById('react-consumer-container-' + consumerId);
    if (!container) {
      logger.warn('⚠️ Контейнер не найден для показа:', consumerId);
      return false;
    }

    // Если уже видим — фокусируем
    if (isContainerVisible(container)) {
      logger.info('ℹ️ [Singleton] Консюмер уже видим, фокусируем');
      focusContainer(container);
      return true;
    }

    // ★★★ ПОКАЗЫВАЕМ КОНТЕЙНЕР ★★★
    container.style.display = 'block';
    container.style.opacity = '0';
    container.style.transform = 'scale(0.95)';
    container.dataset.isHidden = 'false';

    requestAnimationFrame(function () {
      container.style.opacity = '1';
      container.style.transform = 'scale(1)';
    });

    singleton.isHidden = false;
    singleton.hideTime = null;

    // ★★★ ВОССТАНАВЛИВАЕМ ТОЛЬКО ДАННЫЕ, НЕ СТАТУС ★★★
    try {
      var persistentState = loadPersistentState();
      if (persistentState) {
        if (persistentState.liveMetrics && persistentState.liveMetrics.length > 0) {
          store.appendDataBatch(persistentState.liveMetrics);
          console.log('33333333333333')
          logger.success('📊 Восстановлено ' + persistentState.liveMetrics.length + ' записей');
        }
        // ★★★ НЕ ВОССТАНАВЛИВАЕМ СТАТУС ★★★
        if (persistentState.messages && persistentState.messages.length > 0) {
          for (var i = 0; i < persistentState.messages.length; i++) {
            store.sendMessage(persistentState.messages[i]);
          }
          logger.success('💬 Восстановлено ' + persistentState.messages.length + ' сообщений');
        }
        logger.success('✅ Данные восстановлены');
      } else {
        var snapshots = listSnapshots();
        var foundSnapshot = snapshots.find(function (s) {
          return s.consumerId === consumerId;
        });
        if (foundSnapshot) {
          restoreSnapshotDataOnly(foundSnapshot.id, consumerId);
          logger.info('🔄 Данные восстановлены из снапшота');
        }
      }
    } catch (error) {
      logger.warn('⚠️ Не удалось восстановить данные:', error);
    }

    // ★★★ ВСЕГДА УСТАНАВЛИВАЕМ СТАТУС "disconnected" ПРИ ПОКАЗЕ ★★★
    store.setStatus('disconnected');
    logger.info('🔒 Статус установлен в "disconnected" (стриминг остановлен)');

    // Фокусируем после показа
    setTimeout(function () {
      focusContainer(container);
    }, 400);

    logger.success('✅ [Singleton] Консюмер ' + consumerId + ' показан');

    var statusBadge = document.getElementById('react-bookmarklet-status-' + consumerId);
    if (statusBadge) {
      var state = store.getState();
      var status = state.streamStatus || 'disconnected';
      var statusMap = {
        playing: '▶ играет',
        paused: '⏸ пауза',
        disconnected: '⏹ отключен',
        connecting: '⟳ подключение...',
      };
      statusBadge.textContent = statusMap[status] || status;
      statusBadge.style.color = status === 'playing' ? '#34d399' : '#4a5a7a';
      statusBadge.style.borderColor = status === 'playing' ? 'rgba(52,211,153,0.2)' : 'transparent';
    }

    return true;
  }

  function toggleSingletonVisibility(consumerId) {
    var singleton = registry.singleton;
    if (!singleton || singleton.id !== consumerId) return false;

    if (singleton.isHidden) {
      return showSingleton(consumerId);
    } else {
      return hideSingleton(consumerId);
    }
  }

  function isSingletonHidden(consumerId) {
    var singleton = registry.singleton;
    if (!singleton || (consumerId && singleton.id !== consumerId)) return false;
    return singleton.isHidden === true;
  }

  function getSingletonContainer(consumerId) {
    var singleton = registry.singleton;
    if (!singleton || (consumerId && singleton.id !== consumerId)) return null;
    return document.getElementById('react-consumer-container-' + singleton.id);
  }

  // ============================================================
  // 12. УНИЧТОЖЕНИЕ
  // ============================================================

  function destroyConsumer(consumerId) {
    if (registry.singleton && registry.singleton.id === consumerId) {
      try {
        var state = store.getState();
        var snapshotData = {
          liveMetrics: state.liveMetrics || [],
          streamStatus: state.streamStatus || 'disconnected',
          totalBatches: state.totalBatches || 0,
          lastUpdate: state.lastUpdate || null,
          messages: state.messages || [],
          timestamp: Date.now(),
        };
        savePersistentState(snapshotData);
        saveSnapshot(consumerId, snapshotData);
      } catch (error) {
        logger.warn('⚠️ Не удалось сохранить состояние:', error);
      }
      return hideSingleton(consumerId);
    }

    if (registry.instances.has(consumerId)) {
      var entry = registry.instances.get(consumerId);
      try {
        if (entry.instance && typeof entry.instance.unmount === 'function') {
          entry.instance.unmount();
        }
        logger.success('🧹 [Multi] Консюмер ' + consumerId + ' уничтожен');
      } catch (error) {
        logger.warn('⚠️ Ошибка при уничтожении:', error);
      }
      registry.instances.delete(consumerId);

      var container = document.getElementById('react-consumer-container-' + consumerId);
      if (container && container.parentNode) {
        container.parentNode.removeChild(container);
      }
      return true;
    }

    if (registry.hybridInstances && registry.hybridInstances.has(consumerId)) {
      var hybridEntry = registry.hybridInstances.get(consumerId);
      try {
        if (hybridEntry.instance && typeof hybridEntry.instance.unmount === 'function') {
          hybridEntry.instance.unmount();
        }
        logger.success('🧹 [Hybrid] Консюмер ' + consumerId + ' уничтожен');
      } catch (error) {
        logger.warn('⚠️ Ошибка при уничтожении:', error);
      }
      registry.hybridInstances.delete(consumerId);

      var container = document.getElementById('react-consumer-container-' + consumerId);
      if (container && container.parentNode) {
        container.parentNode.removeChild(container);
      }
      return true;
    }

    logger.warn('⚠️ Консюмер ' + consumerId + ' не найден');
    return false;
  }

  function destroyAllConsumers() {
    var count = 0;

    if (registry.singleton) {
      try {
        var state = store.getState();
        var snapshotData = {
          liveMetrics: state.liveMetrics || [],
          streamStatus: state.streamStatus || 'disconnected',
          totalBatches: state.totalBatches || 0,
          lastUpdate: state.lastUpdate || null,
          messages: state.messages || [],
          timestamp: Date.now(),
        };
        savePersistentState(snapshotData);
        saveSnapshot(registry.singleton.id, snapshotData);
      } catch (error) {
        logger.warn('⚠️ Не удалось сохранить состояние:', error);
      }
      hideSingleton(registry.singleton.id);
      count++;
    }

    var entries = Array.from(registry.instances.entries());
    for (var i = 0; i < entries.length; i++) {
      var id = entries[i][0];
      var entry = entries[i][1];
      try {
        if (entry.instance && typeof entry.instance.unmount === 'function') {
          entry.instance.unmount();
        }
        count++;
      } catch (error) {
        logger.warn('⚠️ Ошибка при уничтожении ' + id + ':', error);
      }

      var container = document.getElementById('react-consumer-container-' + id);
      if (container && container.parentNode) {
        container.parentNode.removeChild(container);
      }
    }
    registry.instances.clear();

    if (registry.hybridInstances) {
      registry.hybridInstances.clear();
    }

    logger.success('🧹 Уничтожено/скрыто ' + count + ' консюмеров');
    return count;
  }

  // ============================================================
  // 13. ИНФОРМАЦИЯ О СОСТОЯНИИ
  // ============================================================

  function getConsumerState() {
    var persistentState = loadPersistentState();

    return {
      mode: registry.mode,
      singleton: registry.singleton
        ? {
            id: registry.singleton.id,
            active: true,
            isHidden: registry.singleton.isHidden === true,
            containerId: registry.singleton.containerId,
            hasPersistentState: persistentState !== null,
          }
        : null,
      instances: Array.from(registry.instances.keys()),
      hybridInstances: registry.hybridInstances ? Array.from(registry.hybridInstances.keys()) : [],
      total:
        (registry.singleton ? 1 : 0) +
        registry.instances.size +
        (registry.hybridInstances ? registry.hybridInstances.size : 0),
      launched: registry.launched,
      snapshots: listSnapshots(),
      persistentState: persistentState
        ? {
            metricsCount: (persistentState.liveMetrics || []).length,
            messagesCount: (persistentState.messages || []).length,
            // status: persistentState.streamStatus || 'unknown', // ★★★ НЕ ВОССТАНАВЛИВАЕМ ★★★
            timestamp: persistentState.timestamp,
          }
        : null,
    };
  }

  function getConsumerList() {
    var list = [];

    if (registry.singleton) {
      list.push({
        id: registry.singleton.id,
        type: 'singleton',
        isHidden: registry.singleton.isHidden === true,
        containerId: registry.singleton.containerId,
        active: true,
        hasPersistentState: loadPersistentState() !== null,
      });
    }

    var entries = Array.from(registry.instances.entries());
    for (var i = 0; i < entries.length; i++) {
      var id = entries[i][0];
      var entry = entries[i][1];
      list.push({
        id: id,
        type: 'multi',
        containerId: entry.containerId,
        active: true,
        createdAt: entry.createdAt,
      });
    }

    if (registry.hybridInstances) {
      var hybridEntries = Array.from(registry.hybridInstances.entries());
      for (var j = 0; j < hybridEntries.length; j++) {
        var hid = hybridEntries[j][0];
        var hentry = hybridEntries[j][1];
        list.push({
          id: hid,
          type: 'hybrid',
          containerId: hentry.containerId,
          active: true,
          createdAt: hentry.createdAt,
          hasSnapshot: hentry.hasSnapshot || false,
        });
      }
    }

    return list;
  }

  // ============================================================
  // 14. ПОКАЗ ОШИБКИ
  // ============================================================

  function showErrorUI(error, containerId) {
    var container = document.getElementById(containerId || 'react-consumer-content');
    if (container) {
      container.innerHTML =
        '<div style="text-align:center;padding:40px 20px;color:#ef4444;">' +
        '<div style="font-size:32px;margin-bottom:12px;">❌</div>' +
        '<div>Ошибка загрузки React Consumer</div>' +
        '<div style="font-size:12px;color:#4a5a7a;margin-top:8px;">' +
        (error.message || 'Неизвестная ошибка') +
        '</div>' +
        '</div>';
    }

    var statusBadge = document.getElementById('react-bookmarklet-status');
    if (statusBadge) {
      statusBadge.textContent = '❌ ошибка';
      statusBadge.style.color = '#ef4444';
      statusBadge.style.borderColor = 'rgba(239,68,68,0.2)';
    }
  }

  // ============================================================
  // 15. СОЗДАНИЕ КОНТЕЙНЕРА
  // ============================================================

  function createContainer(consumerId, isSingleton, instanceIndex) {
    var containerId = 'react-consumer-container-' + consumerId;
    var container = document.createElement('div');
    container.id = containerId;

    container.dataset.consumerId = consumerId;
    container.dataset.isSingleton = isSingleton ? 'true' : 'false';
    container.dataset.isHidden = 'false';

    var offset = isSingleton ? 0 : instanceIndex || 0;
    var posX = 20 + (offset % 5) * 30;
    var posY = 20 + Math.floor(offset / 5) * 30;

    container.style.cssText =
      'position:fixed;' +
      'bottom:' +
      posY +
      'px;' +
      'right:' +
      posX +
      'px;' +
      'z-index:' +
      (999999 + offset) +
      ';' +
      'width:' +
      CONFIG.containerWidth +
      'px;' +
      'max-width:90vw;' +
      'max-height:' +
      CONFIG.containerMaxHeight +
      ';' +
      'background:#0b0e14;' +
      'border-radius:12px;' +
      'box-shadow:0 8px 32px rgba(0,0,0,0.85);' +
      'border:1px solid #1e2633;' +
      'overflow:hidden;' +
      'font-family:system-ui,-apple-system,sans-serif;' +
      'transition: opacity ' +
      CONFIG.animationDuration +
      'ms ease, transform ' +
      CONFIG.animationDuration +
      'ms ease;';

    document.body.appendChild(container);

    var header = document.createElement('div');
    header.style.cssText =
      'display:flex;' +
      'justify-content:space-between;' +
      'align-items:center;' +
      'padding:10px 14px;' +
      'background:#131a24;' +
      'border-bottom:1px solid #1e2633;' +
      'cursor:move;' +
      'user-select:none;';

    var title = document.createElement('span');
    title.style.cssText =
      'font-size:14px;' +
      'font-weight:600;' +
      'color:#c8d0e0;' +
      'display:flex;' +
      'align-items:center;' +
      'gap:6px;';

    var modeLabel = '';
    if (registry.mode === MODE.HYBRID) {
      modeLabel = ' 🔄';
    } else if (registry.mode === MODE.SINGLETON) {
      modeLabel = ' 💾';
    }
    title.innerHTML =
      '⚛️ React Consumer' + (isSingleton ? '' : ' #' + (instanceIndex + 1)) + modeLabel;

    var statusBadge = document.createElement('span');
    statusBadge.id = 'react-bookmarklet-status-' + consumerId;
    statusBadge.style.cssText =
      'font-size:11px;' +
      'padding:2px 12px;' +
      'border-radius:20px;' +
      'background:#1e293b;' +
      'color:#4a5a7a;' +
      'transition:all 0.3s ease;' +
      'border:1px solid transparent;';
    statusBadge.textContent = '⏳ загрузка...';

    var closeBtn = document.createElement('button');
    closeBtn.className = 'bookmarklet-close-btn';
    closeBtn.style.cssText =
      'background:#ef4444;' +
      'color:white;' +
      'border:none;' +
      'border-radius:50%;' +
      'width:28px;' +
      'height:28px;' +
      'cursor:pointer;' +
      'font-size:16px;' +
      'line-height:1;' +
      'display:flex;' +
      'align-items:center;' +
      'justify-content:center;' +
      'transition:all 0.2s ease;' +
      'flex-shrink:0;';
    closeBtn.textContent = '✕';
    closeBtn.title = isSingleton ? 'Скрыть React Consumer' : 'Закрыть React Consumer';

    closeBtn.onmouseover = function () {
      this.style.background = '#dc2626';
      this.style.transform = 'scale(1.1)';
    };
    closeBtn.onmouseout = function () {
      this.style.background = '#ef4444';
      this.style.transform = 'scale(1)';
    };

    closeBtn.onclick = function () {
      if (isSingleton) {
        try {
          var state = store.getState();
          var snapshotData = {
            liveMetrics: state.liveMetrics || [],
            streamStatus: state.streamStatus || 'disconnected',
            totalBatches: state.totalBatches || 0,
            lastUpdate: state.lastUpdate || null,
            messages: state.messages || [],
            timestamp: Date.now(),
          };
          savePersistentState(snapshotData);
          saveSnapshot(consumerId, snapshotData);
        } catch (error) {
          logger.warn('⚠️ Не удалось сохранить состояние:', error);
        }
        hideSingleton(consumerId);
      } else if (registry.mode === MODE.HYBRID) {
        var state = store.getState();
        var snapshotData = {
          liveMetrics: state.liveMetrics || [],
          streamStatus: state.streamStatus || 'disconnected',
          totalBatches: state.totalBatches || 0,
          lastUpdate: state.lastUpdate || null,
          messages: state.messages || [],
          timestamp: Date.now(),
        };
        saveSnapshot(consumerId, snapshotData);
        destroyConsumer(consumerId);
      } else {
        destroyConsumer(consumerId);
      }
    };

    var headerLeft = document.createElement('div');
    headerLeft.style.cssText = 'display:flex;align-items:center;gap:10px;';
    headerLeft.appendChild(title);
    headerLeft.appendChild(statusBadge);

    header.appendChild(headerLeft);
    header.appendChild(closeBtn);
    container.appendChild(header);

    var contentContainer = document.createElement('div');
    contentContainer.id = 'react-consumer-content-' + consumerId;
    contentContainer.style.cssText =
      'padding:12px;' +
      'max-height:calc(80vh - 60px);' +
      'overflow-y:auto;' +
      'background:#0b0e14;' +
      'min-height:100px;' +
      'color:#c8d0e0;';
    container.appendChild(contentContainer);

    var loadingIndicator = document.createElement('div');
    loadingIndicator.style.cssText =
      'text-align:center;' + 'padding:40px 20px;' + 'color:#4a5a7a;' + 'font-size:14px;';
    loadingIndicator.innerHTML =
      '<div style="font-size:32px;margin-bottom:12px;">⏳</div>' +
      '<div>Загрузка React Consumer...</div>' +
      '<div style="font-size:12px;color:#3a4a6a;margin-top:8px;">Подключение к хранилищу...</div>';
    contentContainer.appendChild(loadingIndicator);

    setupDrag(container, header);

    return {
      container: container,
      containerId: containerId,
      contentContainer: contentContainer,
      statusBadge: statusBadge,
      header: header,
      closeBtn: closeBtn,
    };
  }

  // ============================================================
  // 16. НАСТРОЙКА ПЕРЕТАСКИВАНИЯ
  // ============================================================

  function setupDrag(container, header) {
    var isDragging = false;
    var dragStartX = 0;
    var dragStartY = 0;

    header.addEventListener('mousedown', function (e) {
      if (e.target.closest('.bookmarklet-close-btn')) return;
      isDragging = true;
      var rect = container.getBoundingClientRect();
      dragStartX = e.clientX - rect.left;
      dragStartY = e.clientY - rect.top;
      container.style.cursor = 'grabbing';
      e.preventDefault();
    });

    document.addEventListener('mousemove', function (e) {
      if (!isDragging) return;
      var x = e.clientX - dragStartX;
      var y = e.clientY - dragStartY;
      container.style.left = x + 'px';
      container.style.top = y + 'px';
      container.style.right = 'auto';
      container.style.bottom = 'auto';
    });

    document.addEventListener('mouseup', function () {
      if (isDragging) {
        isDragging = false;
        container.style.cursor = 'default';
      }
    });
  }

  // ============================================================
  // 17. ЗАГРУЗКА И ВЫПОЛНЕНИЕ КОНСЮМЕРА
  // ============================================================

  async function loadAndExecuteReactConsumer(mode) {
    var targetMode = mode || registry.mode || CONFIG.defaultMode;
    var isSingleton = targetMode === MODE.SINGLETON;

    try {
      logger.info('📥 Загрузка React консюмера (режим: ' + targetMode + ')...');

      // ★★★ SINGLETON: ПРОВЕРЯЕМ СУЩЕСТВУЮЩИЙ ЭКЗЕМПЛЯР ★★★
      if (isSingleton && registry.singleton) {
        var existingId = registry.singleton.id;
        var existingContainer = document.getElementById('react-consumer-container-' + existingId);

        if (existingContainer) {
          // ★★★ ВСЕГДА ПОКАЗЫВАЕМ/ФОКУСИРУЕМ ★★★
          if (registry.singleton.isHidden || existingContainer.style.display === 'none') {
            logger.info('🔄 [Singleton] Синглтон скрыт, показываем...');
            showSingleton(existingId);
          } else {
            logger.info('🔄 [Singleton] Синглтон уже видим, фокусируем...');
            focusContainer(existingContainer);
          }
          return {
            id: existingId,
            mode: MODE.SINGLETON,
            restored: true,
            action: 'shown',
          };
        } else {
          logger.warn('⚠️ [Singleton] Контейнер не найден в DOM, создаем новый');
          registry.singleton = null;
        }
      }

      // ★★★ HYBRID: ПРОВЕРЯЕМ СКРЫТЫЕ ЭКЗЕМПЛЯРЫ ★★★
      if (
        targetMode === MODE.HYBRID &&
        registry.hybridInstances &&
        registry.hybridInstances.size > 0
      ) {
        var entries = Array.from(registry.hybridInstances.entries());
        for (var i = entries.length - 1; i >= 0; i--) {
          var hid = entries[i][0];
          var hentry = entries[i][1];
          if (hentry.isHidden) {
            var container = document.getElementById('react-consumer-container-' + hid);
            if (container) {
              container.style.display = 'block';
              container.style.opacity = '0';
              container.style.transform = 'scale(0.95)';
              container.dataset.isHidden = 'false';

              requestAnimationFrame(function () {
                container.style.opacity = '1';
                container.style.transform = 'scale(1)';
              });

              hentry.isHidden = false;

              var snapshots = listSnapshots();
              var foundSnapshot = snapshots.find(function (s) {
                return s.consumerId === hid;
              });
              if (foundSnapshot) {
                restoreSnapshotDataOnly(foundSnapshot.id, hid);
              }

              logger.success('✅ [Hybrid] Экземпляр ' + hid + ' восстановлен');
              return { id: hid, mode: MODE.HYBRID, restored: true, action: 'shown' };
            }
          }
        }
      }

      // ★★★ СОЗДАЕМ НОВЫЙ ЭКЗЕМПЛЯР ★★★
      var persistentState = null;
      var hasPersistentState = false;
      if (isSingleton) {
        persistentState = loadPersistentState();
        hasPersistentState = persistentState !== null;
        if (persistentState) {
          logger.info('🔄 [Singleton] Найдено сохраненное состояние, данные будут восстановлены');
        }
      }

      var consumerId =
        'react_' + Date.now().toString(36) + '_' + Math.random().toString(36).substr(2, 6);
      var instanceIndex = isSingleton ? 0 : registry.instances.size;
      var containerData = createContainer(consumerId, isSingleton, instanceIndex);

      // ★★★ ВОССТАНАВЛИВАЕМ ТОЛЬКО ДАННЫЕ, НЕ СТАТУС ★★★
      if (hasPersistentState && persistentState) {
        try {
          if (persistentState.liveMetrics && persistentState.liveMetrics.length > 0) {
            store.appendDataBatch(persistentState.liveMetrics);
            logger.success('📊 Восстановлено ' + persistentState.liveMetrics.length + ' записей');
          }
          // ★★★ НЕ ВОССТАНАВЛИВАЕМ СТАТУС ★★★
          if (persistentState.messages && persistentState.messages.length > 0) {
            for (var j = 0; j < persistentState.messages.length; j++) {
              store.sendMessage(persistentState.messages[j]);
            }
            logger.success('💬 Восстановлено ' + persistentState.messages.length + ' сообщений');
          }
          logger.success('✅ Данные восстановлены');
        } catch (error) {
          logger.warn('⚠️ Ошибка восстановления данных:', error);
        }
      }

      // ★★★ ВСЕГДА УСТАНАВЛИВАЕМ СТАТУС "disconnected" ПОСЛЕ ВОССТАНОВЛЕНИЯ ★★★
      store.setStatus('disconnected');
      logger.info('🔒 Статус установлен в "disconnected" (стриминг остановлен)');

      // ★★★ ДИНАМИЧЕСКИЙ ИМПОРТ ★★★
      try {
        var module = await import(baseUrl + '/src/consumers/react-consumer.js');
        var mountReactConsumer = module.mountReactConsumer || module.default;

        if (!mountReactConsumer) {
          throw new Error('mountReactConsumer не найден в модуле');
        }

        var statusBadge = containerData.statusBadge;
        if (statusBadge) {
          statusBadge.textContent = '🔄 подключение...';
          statusBadge.style.color = '#60a5fa';
          statusBadge.style.borderColor = 'rgba(96,165,250,0.2)';
        }

        // Монтируем
        var consumer = mountReactConsumer(containerData.contentContainer, {
          store: store,
          consumerId: consumerId,
          onMount: function () {
            console.log('✅ [ReactBookmarklet] Консюмер смонтирован:', consumerId);
            if (statusBadge) {
              var state = store.getState();
              var status = state.streamStatus || 'disconnected';
              var statusMap = {
                playing: '▶ играет',
                paused: '⏸ пауза',
                disconnected: '⏹ отключен',
                connecting: '⟳ подключение...',
              };
              statusBadge.textContent = statusMap[status] || status;
              statusBadge.style.color = status === 'playing' ? '#34d399' : '#4a5a7a';
              statusBadge.style.borderColor =
                status === 'playing' ? 'rgba(52,211,153,0.2)' : 'transparent';
            }
          },
          onError: function (error) {
            console.error('❌ [ReactBookmarklet] Ошибка:', error);
            if (statusBadge) {
              statusBadge.textContent = '❌ ошибка';
              statusBadge.style.color = '#ef4444';
              statusBadge.style.borderColor = 'rgba(239,68,68,0.2)';
            }
          },
        });

        if (!consumer) {
          throw new Error('Не удалось создать консюмер');
        }

        console.log('✅ [ReactBookmarklet] Консюмер создан:', consumerId);

        // Сохраняем в реестр
        if (isSingleton) {
          registry.mode = MODE.SINGLETON;
          localStorage.setItem(CONFIG.storageKey, MODE.SINGLETON);
          registry.singleton = {
            id: consumerId,
            instance: consumer,
            containerId: containerData.containerId,
            isHidden: false,
            hideTime: null,
            createdAt: Date.now(),
          };
        } else if (targetMode === MODE.HYBRID) {
          registry.mode = MODE.HYBRID;
          localStorage.setItem(CONFIG.storageKey, MODE.HYBRID);
          if (!registry.hybridInstances) {
            registry.hybridInstances = new Map();
          }
          registry.hybridInstances.set(consumerId, {
            id: consumerId,
            instance: consumer,
            containerId: containerData.containerId,
            createdAt: Date.now(),
            isHidden: false,
            hasSnapshot: false,
            index: registry.hybridInstances.size,
          });
        } else {
          registry.mode = MODE.MULTI;
          localStorage.setItem(CONFIG.storageKey, MODE.MULTI);
          registry.instances.set(consumerId, {
            id: consumerId,
            instance: consumer,
            containerId: containerData.containerId,
            createdAt: Date.now(),
            index: registry.instances.size,
          });
        }

        window.__REACT_CONSUMER_ACTIVE__ = true;
        window.__REACT_CONSUMER_UNMOUNT__ = consumer.unmount;

        // Подписка на обновления статуса
        var unsubscribe = store.subscribe(function (state) {
          if (statusBadge) {
            var status = state.streamStatus || 'disconnected';
            var statusMap = {
              playing: '▶ играет',
              paused: '⏸ пауза',
              disconnected: '⏹ отключен',
              connecting: '⟳ подключение...',
            };
            statusBadge.textContent = statusMap[status] || status;
            statusBadge.style.color = status === 'playing' ? '#34d399' : '#4a5a7a';
            statusBadge.style.borderColor =
              status === 'playing' ? 'rgba(52,211,153,0.2)' : 'transparent';
          }
        });

        window.__REACT_CONSUMER_UNSUBSCRIBE__ = unsubscribe;

        logger.success('✅ [Singleton] Консюмер ' + consumerId + ' создан');
        if (hasPersistentState) {
          logger.success('💾 Данные восстановлены из постоянного хранилища');
        }

        registry.launched = true;

        // Фокусируем после создания
        setTimeout(function () {
          focusContainer(containerData.container);
        }, 500);

        return {
          id: consumerId,
          mode: registry.mode,
          containerId: containerData.containerId,
          action: 'created',
        };
      } catch (importError) {
        logger.error('❌ Ошибка импорта React Consumer:', importError);
        showErrorUI(importError, containerData.contentContainer.id);
        return null;
      }
    } catch (error) {
      logger.error('❌ Ошибка загрузки React консюмера:', error);
      showErrorUI(error);
      return null;
    }
  }

  // ============================================================
  // 18. МЕНЕДЖЕР
  // ============================================================

  var Manager = {
    MODE: MODE,

    getMode: function () {
      return registry.mode;
    },

    setMode: function (mode) {
      if (mode === MODE.SINGLETON || mode === MODE.MULTI || mode === MODE.HYBRID) {
        registry.mode = mode;
        localStorage.setItem(CONFIG.storageKey, mode);
        logger.success('🔄 Режим переключен на: ' + mode);
        return true;
      }
      return false;
    },

    launch: async function (mode) {
      var targetMode = mode || registry.mode;
      return await loadAndExecuteReactConsumer(targetMode);
    },

    destroy: destroyConsumer,

    destroyAll: destroyAllConsumers,

    info: getConsumerState,

    list: getConsumerList,

    getSingleton: function () {
      return registry.singleton;
    },

    getInstances: function () {
      return Array.from(registry.instances.entries());
    },

    getHybridInstances: function () {
      return registry.hybridInstances ? Array.from(registry.hybridInstances.entries()) : [];
    },

    isSingletonMode: function () {
      return registry.mode === MODE.SINGLETON;
    },

    isMultiMode: function () {
      return registry.mode === MODE.MULTI;
    },

    isHybridMode: function () {
      return registry.mode === MODE.HYBRID;
    },

    show: function (consumerId) {
      if (!consumerId) {
        if (registry.singleton) {
          consumerId = registry.singleton.id;
        } else {
          logger.warn('⚠️ Нет активного синглтона для показа');
          return false;
        }
      }
      return showSingleton(consumerId);
    },

    hide: function (consumerId) {
      if (!consumerId) {
        if (registry.singleton) {
          consumerId = registry.singleton.id;
        } else {
          logger.warn('⚠️ Нет активного синглтона для скрытия');
          return false;
        }
      }
      return hideSingleton(consumerId);
    },

    toggle: function (consumerId) {
      if (!consumerId) {
        if (registry.singleton) {
          consumerId = registry.singleton.id;
        } else {
          logger.warn('⚠️ Нет активного синглтона для переключения');
          return false;
        }
      }
      return toggleSingletonVisibility(consumerId);
    },

    isHidden: function (consumerId) {
      return isSingletonHidden(consumerId);
    },

    getContainer: function (consumerId) {
      return getSingletonContainer(consumerId);
    },

    saveSnapshot: function (consumerId) {
      if (!consumerId) {
        if (registry.singleton) {
          consumerId = registry.singleton.id;
        } else {
          logger.warn('⚠️ Нет активного консюмера для сохранения снапшота');
          return null;
        }
      }

      try {
        var state = store.getState();
        var snapshotData = {
          liveMetrics: state.liveMetrics || [],
          streamStatus: state.streamStatus || 'disconnected',
          totalBatches: state.totalBatches || 0,
          lastUpdate: state.lastUpdate || null,
          messages: state.messages || [],
          timestamp: Date.now(),
        };
        return saveSnapshot(consumerId, snapshotData);
      } catch (error) {
        logger.error('❌ Ошибка сохранения снапшота:', error);
        return null;
      }
    },

    loadSnapshot: function (snapshotId, consumerId) {
      return restoreSnapshotDataOnly(snapshotId, consumerId);
    },

    listSnapshots: listSnapshots,

    clearSnapshots: clearSnapshots,

    restore: function (snapshotId) {
      var snapshot = loadSnapshot(snapshotId);
      if (!snapshot) {
        logger.warn('⚠️ Снапшот не найден:', snapshotId);
        return false;
      }
      return restoreSnapshotDataOnly(snapshotId, snapshot.consumerId);
    },

    savePersistent: function () {
      try {
        var state = store.getState();
        var snapshotData = {
          liveMetrics: state.liveMetrics || [],
          streamStatus: state.streamStatus || 'disconnected',
          totalBatches: state.totalBatches || 0,
          lastUpdate: state.lastUpdate || null,
          messages: state.messages || [],
          timestamp: Date.now(),
        };
        return savePersistentState(snapshotData);
      } catch (error) {
        logger.error('❌ Ошибка сохранения постоянного состояния:', error);
        return false;
      }
    },

    loadPersistent: function () {
      return loadPersistentState();
    },

    clearPersistent: function () {
      return clearPersistentState();
    },

    hasPersistent: function () {
      return loadPersistentState() !== null;
    },

    focus: function (consumerId) {
      if (!consumerId) {
        if (registry.singleton) {
          consumerId = registry.singleton.id;
        } else {
          logger.warn('⚠️ Нет активного консюмера для фокусировки');
          return false;
        }
      }
      var container = document.getElementById('react-consumer-container-' + consumerId);
      if (container) {
        focusContainer(container);
        return true;
      }
      return false;
    },
  };

  // ============================================================
  // 19. ЭКСПОРТ В ГЛОБАЛЬНЫЙ ОБЪЕКТ
  // ============================================================

  window.__ReactConsumerManager = Manager;
  window[PUBLIC.MANAGER] = Manager;

  window.__REACT_BOOKMARKLET_SYMBOLS__ = {
    PRIVATE: { ...PRIVATE },
    PUBLIC: { ...PUBLIC },
  };

  // ============================================================
  // 20. АВТОМАТИЧЕСКАЯ ОЧИСТКА
  // ============================================================

  var beforeUnloadHandler = function () {
    try {
      var state = store.getState();
      var snapshotData = {
        liveMetrics: state.liveMetrics || [],
        streamStatus: state.streamStatus || 'disconnected',
        totalBatches: state.totalBatches || 0,
        lastUpdate: state.lastUpdate || null,
        messages: state.messages || [],
        timestamp: Date.now(),
      };
      if (registry.singleton) {
        savePersistentState(snapshotData);
        saveSnapshot(registry.singleton.id, snapshotData);
      }
    } catch (error) {
      // Игнорируем ошибки при закрытии
    }

    destroyAllConsumers();
    delete window.__REACT_CONSUMER_ACTIVE__;
    delete window.__REACT_CONSUMER_UNMOUNT__;
    delete window.__REACT_CONSUMER_UNSUBSCRIBE__;
  };

  window.addEventListener('beforeunload', beforeUnloadHandler);
  window.__REACT_BOOKMARKLET_CLEANUP__ = beforeUnloadHandler;

  // ============================================================
  // 21. ЗАПУСК — ВСЕГДА ПРИ КАЖДОМ КЛИКЕ
  // ============================================================

  // ★★★ ВСЕГДА ВЫЗЫВАЕМ, НЕЗАВИСИМО ОТ registry.launched ★★★
  // При каждом запуске букмарклета проверяем/показываем/создаем
  loadAndExecuteReactConsumer(registry.mode);

  // ============================================================
  // 22. КОНСОЛЬНЫЙ ИНТЕРФЕЙС
  // ============================================================

  console.log('╔═══════════════════════════════════════════════════════════════════════════════╗');
  console.log('║              📦 REACT BOOKMARKLET (100% СИМВОЛЫ) v5.3.0                     ║');
  console.log('╠═══════════════════════════════════════════════════════════════════════════════╣');
  console.log('║  📋 Каждый клик на букмарклет — проверка/показ/создание                       ║');
  console.log('║  🔑 Полная изоляция через приватные символы                                 ║');
  console.log('║  🔓 Публичные символы через Symbol.for                                      ║');
  console.log('║  📦 ТРИ режима работы: Singleton, Multi, Hybrid                             ║');
  console.log('║  💾 Singleton: постоянное сохранение состояния (localStorage)                ║');
  console.log('║  🔄 Singleton: автоматическое восстановление при повторном открытии          ║');
  console.log('║  📸 Hybrid: сохранение снапшотов и восстановление состояния                  ║');
  console.log('║  🚫 СТРИМИНГ НЕ ЗАПУСКАЕТСЯ АВТОМАТИЧЕСКИ                                  ║');
  console.log('║  🔒 Статус всегда "disconnected" при открытии/показе                        ║');
  console.log('║  ▶️ Только по кнопке "Старт" в интерфейсе                                   ║');
  console.log('║  💾 Сохраняются только данные, статус НЕ сохраняется                        ║');
  console.log('║  🎯 Полное управление через window.__ReactConsumerManager                   ║');
  console.log('╚═══════════════════════════════════════════════════════════════════════════════╝');

  console.log('📋 УПРАВЛЕНИЕ КОНСЮМЕРАМИ:');
  console.log('  window.__ReactConsumerManager.launch() - запустить/показать');
  console.log('  window.__ReactConsumerManager.launch("singleton") - запустить в singleton');
  console.log('  window.__ReactConsumerManager.launch("multi") - запустить в multi');
  console.log('  window.__ReactConsumerManager.launch("hybrid") - запустить в hybrid');
  console.log('  window.__ReactConsumerManager.destroy(id) - уничтожить по ID');
  console.log('  window.__ReactConsumerManager.destroyAll() - уничтожить все');
  console.log(
    '  window.__ReactConsumerManager.setMode("singleton"|"multi"|"hybrid") - переключить режим'
  );
  console.log('  window.__ReactConsumerManager.info() - состояние');
  console.log('  window.__ReactConsumerManager.list() - список');
  console.log('  window.__ReactConsumerManager.getSingleton() - получить синглтон');
  console.log('  window.__ReactConsumerManager.getInstances() - получить все экземпляры');
  console.log(
    '  window.__ReactConsumerManager.getHybridInstances() - получить гибридные экземпляры'
  );
  console.log('  window.__ReactConsumerManager.focus() - подсветить окно');

  console.log('📊 СТАТИСТИКА СИМВОЛОВ:');
  console.log('  🔑 Приватных символов: ' + Object.keys(PRIVATE).length);
  console.log('  🔓 Публичных символов: ' + Object.keys(PUBLIC).length);
  console.log('  📦 Всего символов: ' + (Object.keys(PRIVATE).length + Object.keys(PUBLIC).length));

  console.log('🚀 React Bookmarklet: Запущен успешно');
  console.log('📌 Для закрытия нажмите ✕ в углу окна');
})();
